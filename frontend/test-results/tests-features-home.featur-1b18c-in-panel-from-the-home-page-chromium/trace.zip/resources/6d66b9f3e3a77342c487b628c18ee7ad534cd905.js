import { n as __exportAll } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=99106a80";
//#region node_modules/axios/lib/helpers/bind.js
/**
* Create a bound version of a function with a specified `this` context
*
* @param {Function} fn - The function to bind
* @param {*} thisArg - The value to be passed as the `this` parameter
* @returns {Function} A new function that will call the original function with the specified `this` context
*/
function bind(fn, thisArg) {
	return function wrap() {
		return fn.apply(thisArg, arguments);
	};
}
//#endregion
//#region node_modules/axios/lib/utils.js
var { toString } = Object.prototype;
var { getPrototypeOf } = Object;
var { iterator, toStringTag } = Symbol;
var hasOwnProperty = (({ hasOwnProperty }) => (obj, prop) => hasOwnProperty.call(obj, prop))(Object.prototype);
var isUnsafeObjectKey = (prop) => typeof prop === "string" && (prop === "__proto__" || prop === "constructor" || prop === "prototype");
/**
* Determine whether an inherited object must be treated as a shared-prototype
* boundary. Cross-realm Object.prototype objects cannot be distinguished
* reliably from application-created null-prototype objects because their
* properties are mutable, so all inherited terminal prototypes are excluded
* as a fail-closed boundary. A null-prototype source still keeps its own
* properties, as produced by mergeConfig and other safe materialization paths.
*
* @param {*} obj The object to inspect
* @param {*} prototype The object's prototype
* @param {boolean} source Whether obj is the original traversal source
*
* @returns {boolean} True when obj is a safe prototype traversal boundary
*/
var isPrototypeBoundary = (obj, prototype, source) => obj === Object.prototype || !source && prototype === null;
/**
* Determine whether an object can retain its identity through code paths that
* add, replace, and remove config properties without bypassing unsafe-key
* filtering. Immutable objects, unsafe-key-bearing objects, and objects with
* accessor or restricted data properties must be materialized instead.
*
* @param {*} obj The object to inspect
*
* @returns {boolean} True when every own property is safe and fully mutable
*/
var isSafeAndFullyMutable = (obj) => {
	if (!Object.isExtensible(obj)) return false;
	const props = Object.getOwnPropertyNames(obj);
	if (Object.getOwnPropertySymbols) props.push(...Object.getOwnPropertySymbols(obj));
	return props.every((prop) => {
		if (isUnsafeObjectKey(prop)) return false;
		const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
		return !!descriptor && descriptor.configurable && descriptor.writable === true;
	});
};
/**
* Walk the prototype chain (excluding the source realm's Object.prototype)
* looking for an own `prop`. This distinguishes genuine own/inherited members
* — including class accessors and template prototypes — from members injected
* via Object.prototype pollution (e.g. `Object.prototype.username = '...'`),
* which live on Object.prototype itself and are therefore never matched.
*
* @param {*} thing The value whose chain to inspect
* @param {string|symbol} prop The property key to look for
*
* @returns {boolean} True when `prop` is owned below Object.prototype
*/
var hasOwnInPrototypeChain = (thing, prop) => {
	let obj = thing;
	const seen = [];
	while (obj != null) {
		if (seen.indexOf(obj) !== -1) return false;
		seen.push(obj);
		const prototype = getPrototypeOf(obj);
		if (isPrototypeBoundary(obj, prototype, obj === thing)) return false;
		if (hasOwnProperty(obj, prop)) return true;
		obj = prototype;
	}
	return false;
};
/**
* Read `obj[prop]` only when it is safe from Object.prototype pollution. Own
* properties and members inherited from a non-Object.prototype source (a class
* instance or template object) are honored; a value reachable only through a
* polluted Object.prototype is ignored and `undefined` is returned.
*
* @param {*} obj The source object
* @param {string|symbol} prop The property key to read
*
* @returns {*} The resolved value, or undefined when unsafe/absent
*/
var getSafeProp = (obj, prop) => obj != null && hasOwnInPrototypeChain(obj, prop) ? obj[prop] : void 0;
/**
* Flatten an object and its application-defined prototype chain into a
* null-prototype object. Members inherited only from the source realm's
* Object.prototype are deliberately excluded, while class/template members
* below that boundary are preserved.
*
* @param {*} thing The value to flatten
*
* @returns {*} A null-prototype copy, or the original value when it is already
* structurally safe or is not an object
*/
var toSafeFlatObject = (thing) => {
	if (thing == null || typeof thing !== "object" && typeof thing !== "function") return thing;
	const sourcePrototype = getPrototypeOf(thing);
	if (sourcePrototype === null && isSafeAndFullyMutable(thing)) return thing;
	const result = Object.create(null);
	const merged = Object.create(null);
	const seen = [];
	let current = thing;
	while (current != null) {
		if (seen.indexOf(current) !== -1) break;
		seen.push(current);
		const prototype = current === thing ? sourcePrototype : getPrototypeOf(current);
		if (isPrototypeBoundary(current, prototype, current === thing)) break;
		const props = Object.getOwnPropertyNames(current);
		if (Object.getOwnPropertySymbols) props.push(...Object.getOwnPropertySymbols(current));
		for (const prop of props) {
			if (isUnsafeObjectKey(prop)) continue;
			if (!hasOwnProperty(merged, prop)) {
				result[prop] = thing[prop];
				merged[prop] = true;
			}
		}
		current = prototype;
	}
	return result;
};
var kindOf = ((cache) => (thing) => {
	const str = toString.call(thing);
	return cache[str] || (cache[str] = str.slice(8, -1).toLowerCase());
})(Object.create(null));
var kindOfTest = (type) => {
	type = type.toLowerCase();
	return (thing) => kindOf(thing) === type;
};
var typeOfTest = (type) => (thing) => typeof thing === type;
/**
* Determine if a value is a non-null object
*
* @param {Object} val The value to test
*
* @returns {boolean} True if value is an Array, otherwise false
*/
var { isArray } = Array;
/**
* Determine if a value is undefined
*
* @param {*} val The value to test
*
* @returns {boolean} True if the value is undefined, otherwise false
*/
var isUndefined = typeOfTest("undefined");
/**
* Determine if a value is a Buffer
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a Buffer, otherwise false
*/
function isBuffer(val) {
	return val !== null && !isUndefined(val) && val.constructor !== null && !isUndefined(val.constructor) && isFunction$1(val.constructor.isBuffer) && val.constructor.isBuffer(val);
}
/**
* Determine if a value is an ArrayBuffer
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is an ArrayBuffer, otherwise false
*/
var isArrayBuffer = kindOfTest("ArrayBuffer");
/**
* Determine if a value is a view on an ArrayBuffer
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a view on an ArrayBuffer, otherwise false
*/
function isArrayBufferView(val) {
	let result;
	if (typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView) result = ArrayBuffer.isView(val);
	else result = val && val.buffer && isArrayBuffer(val.buffer);
	return result;
}
/**
* Determine if a value is a String
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a String, otherwise false
*/
var isString = typeOfTest("string");
/**
* Determine if a value is a Function
*
* @param {*} val The value to test
* @returns {boolean} True if value is a Function, otherwise false
*/
var isFunction$1 = typeOfTest("function");
/**
* Determine if a value is a Number
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a Number, otherwise false
*/
var isNumber = typeOfTest("number");
/**
* Determine if a value is an Object
*
* @param {*} thing The value to test
*
* @returns {boolean} True if value is an Object, otherwise false
*/
var isObject = (thing) => thing !== null && typeof thing === "object";
/**
* Determine if a value is a Boolean
*
* @param {*} thing The value to test
* @returns {boolean} True if value is a Boolean, otherwise false
*/
var isBoolean = (thing) => thing === true || thing === false;
/**
* Determine if a value is a plain Object
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a plain Object, otherwise false
*/
var isPlainObject = (val) => {
	if (!isObject(val)) return false;
	const prototype = getPrototypeOf(val);
	return (prototype === null || prototype === Object.prototype || getPrototypeOf(prototype) === null) && !hasOwnInPrototypeChain(val, toStringTag) && !hasOwnInPrototypeChain(val, iterator);
};
/**
* Determine if a value is an empty object (safely handles Buffers)
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is an empty object, otherwise false
*/
var isEmptyObject = (val) => {
	if (!isObject(val) || isBuffer(val)) return false;
	try {
		return Object.keys(val).length === 0 && Object.getPrototypeOf(val) === Object.prototype;
	} catch (e) {
		return false;
	}
};
/**
* Determine if a value is a Date
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a Date, otherwise false
*/
var isDate = kindOfTest("Date");
/**
* Determine if a value is a File
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a File, otherwise false
*/
var isFile = kindOfTest("File");
/**
* Determine if a value is a React Native Blob
* React Native "blob": an object with a `uri` attribute. Optionally, it can
* also have a `name` and `type` attribute to specify filename and content type
*
* @see https://github.com/facebook/react-native/blob/26684cf3adf4094eb6c405d345a75bf8c7c0bf88/Libraries/Network/FormData.js#L68-L71
*
* @param {*} value The value to test
*
* @returns {boolean} True if value is a React Native Blob, otherwise false
*/
var isReactNativeBlob = (value) => {
	return !!(value && typeof value.uri !== "undefined");
};
/**
* Determine if environment is React Native
* ReactNative `FormData` has a non-standard `getParts()` method
*
* @param {*} formData The formData to test
*
* @returns {boolean} True if environment is React Native, otherwise false
*/
var isReactNative = (formData) => formData && typeof formData.getParts !== "undefined";
/**
* Determine if a value is a Blob
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a Blob, otherwise false
*/
var isBlob = kindOfTest("Blob");
/**
* Determine if a value is a FileList
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a FileList, otherwise false
*/
var isFileList = kindOfTest("FileList");
var isSet = kindOfTest("Set");
/**
* Determine if a value is a Stream
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a Stream, otherwise false
*/
var isStream = (val) => isObject(val) && isFunction$1(val.pipe);
/**
* Determine if a value is a FormData
*
* @param {*} thing The value to test
*
* @returns {boolean} True if value is an FormData, otherwise false
*/
function getGlobal() {
	if (typeof globalThis !== "undefined") return globalThis;
	if (typeof self !== "undefined") return self;
	if (typeof window !== "undefined") return window;
	if (typeof global !== "undefined") return global;
	return {};
}
var G = getGlobal();
var FormDataCtor = typeof G.FormData !== "undefined" ? G.FormData : void 0;
var isFormData = (thing) => {
	if (!thing) return false;
	if (FormDataCtor && thing instanceof FormDataCtor) return true;
	const proto = getPrototypeOf(thing);
	if (!proto || proto === Object.prototype) return false;
	if (!isFunction$1(thing.append)) return false;
	const kind = kindOf(thing);
	return kind === "formdata" || kind === "object" && isFunction$1(thing.toString) && thing.toString() === "[object FormData]";
};
/**
* Determine if a value is a URLSearchParams object
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a URLSearchParams object, otherwise false
*/
var isURLSearchParams = kindOfTest("URLSearchParams");
var [isReadableStream, isRequest, isResponse, isHeaders] = [
	"ReadableStream",
	"Request",
	"Response",
	"Headers"
].map(kindOfTest);
/**
* Trim excess whitespace off the beginning and end of a string
*
* @param {String} str The String to trim
*
* @returns {String} The String freed of excess whitespace
*/
var trim = (str) => {
	return str.trim ? str.trim() : str.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
};
/**
* Iterate over an Array or an Object invoking a function for each item.
*
* If `obj` is an Array callback will be called passing
* the value, index, and complete array for each item.
*
* If 'obj' is an Object callback will be called passing
* the value, key, and complete object for each property.
*
* @param {Object|Array<unknown>} obj The object to iterate
* @param {Function} fn The callback to invoke for each item
*
* @param {Object} [options]
* @param {Boolean} [options.allOwnKeys = false]
* @returns {any}
*/
function forEach(obj, fn, { allOwnKeys = false } = {}) {
	if (obj === null || typeof obj === "undefined") return;
	let i;
	let l;
	if (typeof obj !== "object") obj = [obj];
	if (isArray(obj)) for (i = 0, l = obj.length; i < l; i++) fn.call(null, obj[i], i, obj);
	else {
		if (isBuffer(obj)) return;
		const keys = allOwnKeys ? Object.getOwnPropertyNames(obj) : Object.keys(obj);
		const len = keys.length;
		let key;
		for (i = 0; i < len; i++) {
			key = keys[i];
			fn.call(null, obj[key], key, obj);
		}
	}
}
/**
* Finds a key in an object, case-insensitive, returning the actual key name.
* Returns null if the object is a Buffer or if no match is found.
*
* @param {Object} obj - The object to search.
* @param {string} key - The key to find (case-insensitive).
* @returns {?string} The actual key name if found, otherwise null.
*/
function findKey(obj, key) {
	if (isBuffer(obj)) return null;
	key = key.toLowerCase();
	const keys = Object.keys(obj);
	let i = keys.length;
	let _key;
	while (i-- > 0) {
		_key = keys[i];
		if (key === _key.toLowerCase()) return _key;
	}
	return null;
}
var _global = (() => {
	if (typeof globalThis !== "undefined") return globalThis;
	return typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : global;
})();
var isContextDefined = (context) => !isUndefined(context) && context !== _global;
/**
* Accepts varargs expecting each argument to be an object, then
* immutably merges the properties of each object and returns result.
*
* When multiple objects contain the same key the later object in
* the arguments list will take precedence.
*
* Example:
*
* ```js
* const result = merge({foo: 123}, {foo: 456});
* console.log(result.foo); // outputs 456
* ```
*
* @param {Object} obj1 Object to merge
*
* @returns {Object} Result of all merge properties
*/
function merge(...objs) {
	const { caseless, skipUndefined } = isContextDefined(this) && this || {};
	const result = {};
	const assignValue = (val, key) => {
		if (key === "__proto__" || key === "constructor" || key === "prototype") return;
		const targetKey = caseless && typeof key === "string" && findKey(result, key) || key;
		const existing = hasOwnProperty(result, targetKey) ? result[targetKey] : void 0;
		if (isPlainObject(existing) && isPlainObject(val)) result[targetKey] = merge(existing, val);
		else if (isPlainObject(val)) result[targetKey] = merge({}, val);
		else if (isArray(val)) result[targetKey] = val.slice();
		else if (!skipUndefined || !isUndefined(val)) result[targetKey] = val;
	};
	for (let i = 0, l = objs.length; i < l; i++) {
		const source = objs[i];
		if (!source || isBuffer(source)) continue;
		forEach(source, assignValue);
		if (typeof source !== "object" || isArray(source)) continue;
		const symbols = Object.getOwnPropertySymbols(source);
		for (let j = 0; j < symbols.length; j++) {
			const symbol = symbols[j];
			if (propertyIsEnumerable.call(source, symbol)) assignValue(source[symbol], symbol);
		}
	}
	return result;
}
/**
* Extends object a by mutably adding to it the properties of object b.
*
* @param {Object} a The object to be extended
* @param {Object} b The object to copy properties from
* @param {Object} thisArg The object to bind function to
*
* @param {Object} [options]
* @param {Boolean} [options.allOwnKeys]
* @returns {Object} The resulting value of object a
*/
var extend = (a, b, thisArg, { allOwnKeys } = {}) => {
	forEach(b, (val, key) => {
		if (thisArg && isFunction$1(val)) Object.defineProperty(a, key, {
			__proto__: null,
			value: bind(val, thisArg),
			writable: true,
			enumerable: true,
			configurable: true
		});
		else Object.defineProperty(a, key, {
			__proto__: null,
			value: val,
			writable: true,
			enumerable: true,
			configurable: true
		});
	}, { allOwnKeys });
	return a;
};
/**
* Remove byte order marker. This catches EF BB BF (the UTF-8 BOM)
*
* @param {string} content with BOM
*
* @returns {string} content value without BOM
*/
var stripBOM = (content) => {
	if (content.charCodeAt(0) === 65279) content = content.slice(1);
	return content;
};
/**
* Inherit the prototype methods from one constructor into another
* @param {function} constructor
* @param {function} superConstructor
* @param {object} [props]
* @param {object} [descriptors]
*
* @returns {void}
*/
var inherits = (constructor, superConstructor, props, descriptors) => {
	constructor.prototype = Object.create(superConstructor.prototype, descriptors);
	Object.defineProperty(constructor.prototype, "constructor", {
		__proto__: null,
		value: constructor,
		writable: true,
		enumerable: false,
		configurable: true
	});
	Object.defineProperty(constructor, "super", {
		__proto__: null,
		value: superConstructor.prototype
	});
	props && Object.assign(constructor.prototype, props);
};
/**
* Resolve object with deep prototype chain to a flat object
* @param {Object} sourceObj source object
* @param {Object} [destObj]
* @param {Function|Boolean} [filter]
* @param {Function} [propFilter]
*
* @returns {Object}
*/
var toFlatObject = (sourceObj, destObj, filter, propFilter) => {
	let props;
	let i;
	let prop;
	const merged = {};
	destObj = destObj || {};
	if (sourceObj == null) return destObj;
	do {
		props = Object.getOwnPropertyNames(sourceObj);
		i = props.length;
		while (i-- > 0) {
			prop = props[i];
			if ((!propFilter || propFilter(prop, sourceObj, destObj)) && !merged[prop]) {
				destObj[prop] = sourceObj[prop];
				merged[prop] = true;
			}
		}
		sourceObj = filter !== false && getPrototypeOf(sourceObj);
	} while (sourceObj && (!filter || filter(sourceObj, destObj)) && sourceObj !== Object.prototype);
	return destObj;
};
/**
* Determines whether a string ends with the characters of a specified string
*
* @param {String} str
* @param {String} searchString
* @param {Number} [position= 0]
*
* @returns {boolean}
*/
var endsWith = (str, searchString, position) => {
	str = String(str);
	if (position === void 0 || position > str.length) position = str.length;
	position -= searchString.length;
	const lastIndex = str.indexOf(searchString, position);
	return lastIndex !== -1 && lastIndex === position;
};
/**
* Returns new array from array like object or null if failed
*
* @param {*} [thing]
*
* @returns {?Array}
*/
var toArray = (thing) => {
	if (!thing) return null;
	if (isArray(thing)) return thing;
	let i = thing.length;
	if (!isNumber(i)) return null;
	const arr = new Array(i);
	while (i-- > 0) arr[i] = thing[i];
	return arr;
};
/**
* Checking if the Uint8Array exists and if it does, it returns a function that checks if the
* thing passed in is an instance of Uint8Array
*
* @param {TypedArray}
*
* @returns {Array}
*/
var isTypedArray = ((TypedArray) => {
	return (thing) => {
		return TypedArray && thing instanceof TypedArray;
	};
})(typeof Uint8Array !== "undefined" && getPrototypeOf(Uint8Array));
/**
* For each entry in the object, call the function with the key and value.
*
* @param {Object<any, any>} obj - The object to iterate over.
* @param {Function} fn - The function to call for each entry.
*
* @returns {void}
*/
var forEachEntry = (obj, fn) => {
	const _iterator = (obj && obj[iterator]).call(obj);
	let result;
	while ((result = _iterator.next()) && !result.done) {
		const pair = result.value;
		fn.call(obj, pair[0], pair[1]);
	}
};
/**
* It takes a regular expression and a string, and returns an array of all the matches
*
* @param {string} regExp - The regular expression to match against.
* @param {string} str - The string to search.
*
* @returns {Array<boolean>}
*/
var matchAll = (regExp, str) => {
	let matches;
	const arr = [];
	while ((matches = regExp.exec(str)) !== null) arr.push(matches);
	return arr;
};
var isHTMLForm = kindOfTest("HTMLFormElement");
var toCamelCase = (str) => {
	return str.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g, function replacer(m, p1, p2) {
		return p1.toUpperCase() + p2;
	});
};
var { propertyIsEnumerable } = Object.prototype;
/**
* Determine if a value is a RegExp object
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a RegExp object, otherwise false
*/
var isRegExp = kindOfTest("RegExp");
var reduceDescriptors = (obj, reducer) => {
	const descriptors = Object.getOwnPropertyDescriptors(obj);
	const reducedDescriptors = {};
	forEach(descriptors, (descriptor, name) => {
		let ret;
		if ((ret = reducer(descriptor, name, obj)) !== false) reducedDescriptors[name] = ret || descriptor;
	});
	Object.defineProperties(obj, reducedDescriptors);
};
/**
* Makes all methods read-only
* @param {Object} obj
*/
var freezeMethods = (obj) => {
	reduceDescriptors(obj, (descriptor, name) => {
		if (isFunction$1(obj) && [
			"arguments",
			"caller",
			"callee"
		].includes(name)) return false;
		const value = obj[name];
		if (!isFunction$1(value)) return;
		descriptor.enumerable = false;
		if ("writable" in descriptor) {
			descriptor.writable = false;
			return;
		}
		if (!descriptor.set) descriptor.set = () => {
			throw Error("Can not rewrite read-only method '" + name + "'");
		};
	});
};
/**
* Converts an array or a delimited string into an object set with values as keys and true as values.
* Useful for fast membership checks.
*
* @param {Array|string} arrayOrString - The array or string to convert.
* @param {string} delimiter - The delimiter to use if input is a string.
* @returns {Object} An object with keys from the array or string, values set to true.
*/
var toObjectSet = (arrayOrString, delimiter) => {
	const obj = {};
	const define = (arr) => {
		arr.forEach((value) => {
			obj[value] = true;
		});
	};
	isArray(arrayOrString) ? define(arrayOrString) : define(String(arrayOrString).split(delimiter));
	return obj;
};
var noop = () => {};
var toFiniteNumber = (value, defaultValue) => {
	return value != null && Number.isFinite(value = +value) ? value : defaultValue;
};
/**
* If the thing is a FormData object, return true, otherwise return false.
*
* @param {unknown} thing - The thing to check.
*
* @returns {boolean}
*/
function isSpecCompliantForm(thing) {
	return !!(thing && isFunction$1(thing.append) && thing[toStringTag] === "FormData" && thing[iterator]);
}
/**
* Recursively converts an object to a JSON-compatible object, handling circular references and Buffers.
*
* @param {Object} obj - The object to convert.
* @returns {Object} The JSON-compatible object.
*/
var toJSONObject = (obj) => {
	const visited = /* @__PURE__ */ new WeakSet();
	const visit = (source) => {
		if (isObject(source)) {
			if (visited.has(source)) return;
			if (isBuffer(source)) return source;
			if (!("toJSON" in source)) {
				visited.add(source);
				let target;
				if (isSet(source)) {
					target = [];
					for (const value of source) {
						const reducedValue = visit(value);
						!isUndefined(reducedValue) && target.push(reducedValue);
					}
				} else {
					target = isArray(source) ? [] : {};
					forEach(source, (value, key) => {
						const reducedValue = visit(value);
						!isUndefined(reducedValue) && (target[key] = reducedValue);
					});
				}
				visited.delete(source);
				return target;
			}
		}
		return source;
	};
	return visit(obj);
};
/**
* Determines if a value is an async function.
*
* @param {*} thing - The value to test.
* @returns {boolean} True if value is an async function, otherwise false.
*/
var isAsyncFn = kindOfTest("AsyncFunction");
/**
* Determines if a value is thenable (has then and catch methods).
*
* @param {*} thing - The value to test.
* @returns {boolean} True if value is thenable, otherwise false.
*/
var isThenable = (thing) => thing && (isObject(thing) || isFunction$1(thing)) && isFunction$1(thing.then) && isFunction$1(thing.catch);
/**
* Provides a cross-platform setImmediate implementation.
* Uses native setImmediate if available, otherwise falls back to postMessage or setTimeout.
*
* @param {boolean} setImmediateSupported - Whether setImmediate is supported.
* @param {boolean} postMessageSupported - Whether postMessage is supported.
* @returns {Function} A function to schedule a callback asynchronously.
*/
var _setImmediate = ((setImmediateSupported, postMessageSupported) => {
	if (setImmediateSupported) return setImmediate;
	return postMessageSupported ? ((token, callbacks) => {
		_global.addEventListener("message", ({ source, data }) => {
			if (source === _global && data === token) callbacks.length && callbacks.shift()();
		}, false);
		return (cb) => {
			callbacks.push(cb);
			_global.postMessage(token, "*");
		};
	})(`axios@${Math.random()}`, []) : (cb) => setTimeout(cb);
})(typeof setImmediate === "function", isFunction$1(_global.postMessage));
/**
* Schedules a microtask or asynchronous callback as soon as possible.
* Uses queueMicrotask if available, otherwise falls back to process.nextTick or _setImmediate.
*
* @type {Function}
*/
var asap = typeof queueMicrotask !== "undefined" ? queueMicrotask.bind(_global) : typeof process !== "undefined" && process.nextTick || _setImmediate;
var isIterable = (thing) => thing != null && isFunction$1(thing[iterator]);
/**
* Determine if a value is iterable via an iterator that is NOT sourced solely
* from a polluted Object.prototype. Use this instead of `isIterable` whenever
* the iterable comes from untrusted input (e.g. user-supplied header sources),
* so `Object.prototype[Symbol.iterator] = ...` cannot turn an ordinary object
* into an attacker-controlled entries iterator.
*
* @param {*} thing The value to test
*
* @returns {boolean} True if value has a non-polluted iterator
*/
var isSafeIterable = (thing) => thing != null && hasOwnInPrototypeChain(thing, iterator) && isIterable(thing);
var utils_default = {
	isArray,
	isArrayBuffer,
	isBuffer,
	isFormData,
	isArrayBufferView,
	isString,
	isNumber,
	isBoolean,
	isObject,
	isPlainObject,
	isEmptyObject,
	isReadableStream,
	isRequest,
	isResponse,
	isHeaders,
	isUndefined,
	isDate,
	isFile,
	isReactNativeBlob,
	isReactNative,
	isBlob,
	isRegExp,
	isFunction: isFunction$1,
	isStream,
	isURLSearchParams,
	isTypedArray,
	isFileList,
	forEach,
	merge,
	extend,
	trim,
	stripBOM,
	inherits,
	toFlatObject,
	kindOf,
	kindOfTest,
	endsWith,
	toArray,
	forEachEntry,
	matchAll,
	isHTMLForm,
	hasOwnProperty,
	hasOwnProp: hasOwnProperty,
	hasOwnInPrototypeChain,
	getSafeProp,
	toSafeFlatObject,
	reduceDescriptors,
	freezeMethods,
	toObjectSet,
	toCamelCase,
	noop,
	toFiniteNumber,
	findKey,
	global: _global,
	isContextDefined,
	isSpecCompliantForm,
	toJSONObject,
	isAsyncFn,
	isThenable,
	setImmediate: _setImmediate,
	asap,
	isIterable,
	isSafeIterable
};
//#endregion
//#region node_modules/axios/lib/helpers/parseHeaders.js
var ignoreDuplicateOf = utils_default.toObjectSet([
	"age",
	"authorization",
	"content-length",
	"content-type",
	"etag",
	"expires",
	"from",
	"host",
	"if-modified-since",
	"if-unmodified-since",
	"last-modified",
	"location",
	"max-forwards",
	"proxy-authorization",
	"referer",
	"retry-after",
	"user-agent"
]);
/**
* Parse headers into an object
*
* ```
* Date: Wed, 27 Aug 2014 08:58:49 GMT
* Content-Type: application/json
* Connection: keep-alive
* Transfer-Encoding: chunked
* ```
*
* @param {String} rawHeaders Headers needing to be parsed
*
* @returns {Object} Headers parsed into an object
*/
var parseHeaders_default = (rawHeaders) => {
	const parsed = {};
	let key;
	let val;
	let i;
	rawHeaders && rawHeaders.split("\n").forEach(function parser(line) {
		i = line.indexOf(":");
		key = line.substring(0, i).trim().toLowerCase();
		val = line.substring(i + 1).trim();
		const hasKey = utils_default.hasOwnProp(parsed, key);
		if (!key || hasKey && utils_default.hasOwnProp(ignoreDuplicateOf, key)) return;
		if (key === "set-cookie") {
			if (hasKey) parsed[key].push(val);
			else parsed[key] = [val];
		} else parsed[key] = hasKey ? parsed[key] + ", " + val : val;
	});
	return parsed;
};
//#endregion
//#region node_modules/axios/lib/helpers/sanitizeHeaderValue.js
function trimSPorHTAB(str) {
	let start = 0;
	let end = str.length;
	while (start < end) {
		const code = str.charCodeAt(start);
		if (code !== 9 && code !== 32) break;
		start += 1;
	}
	while (end > start) {
		const code = str.charCodeAt(end - 1);
		if (code !== 9 && code !== 32) break;
		end -= 1;
	}
	return start === 0 && end === str.length ? str : str.slice(start, end);
}
var INVALID_UNICODE_HEADER_VALUE_CHARS = /* @__PURE__ */ new RegExp("[\\u0000-\\u0008\\u000a-\\u001f\\u007f]+", "g");
var INVALID_BYTE_STRING_HEADER_VALUE_CHARS = /* @__PURE__ */ new RegExp("[^\\u0009\\u0020-\\u007e\\u0080-\\u00ff]+", "g");
function sanitizeValue(value, invalidChars) {
	if (utils_default.isArray(value)) return value.map((item) => sanitizeValue(item, invalidChars));
	return trimSPorHTAB(String(value).replace(invalidChars, ""));
}
var sanitizeHeaderValue = (value) => sanitizeValue(value, INVALID_UNICODE_HEADER_VALUE_CHARS);
var sanitizeByteStringHeaderValue = (value) => sanitizeValue(value, INVALID_BYTE_STRING_HEADER_VALUE_CHARS);
function toByteStringHeaderObject(headers) {
	const byteStringHeaders = Object.create(null);
	utils_default.forEach(headers.toJSON(), (value, header) => {
		byteStringHeaders[header] = sanitizeByteStringHeaderValue(value);
	});
	return byteStringHeaders;
}
//#endregion
//#region node_modules/axios/lib/core/AxiosHeaders.js
var $internals$1 = Symbol("internals");
function normalizeHeader(header) {
	return header && String(header).trim().toLowerCase();
}
function normalizeValue(value) {
	if (value === false || value == null) return value;
	return utils_default.isArray(value) ? value.map(normalizeValue) : sanitizeHeaderValue(String(value));
}
function parseTokens(str) {
	const tokens = Object.create(null);
	const tokensRE = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
	let match;
	while (match = tokensRE.exec(str)) tokens[match[1]] = match[2];
	return tokens;
}
var parameterNameRE = /^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/;
function trimOWS(value) {
	let start = 0;
	let end = value.length;
	while (start < end) {
		const code = value.charCodeAt(start);
		if (code !== 9 && code !== 32) break;
		start += 1;
	}
	while (end > start) {
		const code = value.charCodeAt(end - 1);
		if (code !== 9 && code !== 32) break;
		end -= 1;
	}
	return start === 0 && end === value.length ? value : value.slice(start, end);
}
function decodeQuotedString(value) {
	const last = value.length - 1;
	if (last < 1 || value.charCodeAt(0) !== 34 || value.charCodeAt(last) !== 34) return value;
	let decoded = "";
	for (let i = 1; i < last; i++) {
		const code = value.charCodeAt(i);
		if (code === 34) return value;
		if (code === 92) {
			i += 1;
			if (i >= last) return value;
		}
		decoded += value[i];
	}
	return decoded;
}
function parseParameters(value) {
	const parameters = Object.create(null);
	const str = String(value);
	let start = 0;
	let quoted = false;
	let escaped = false;
	function parseParameter(end) {
		const part = trimOWS(str.slice(start, end));
		const equals = part.indexOf("=");
		if (equals < 1) return;
		const name = trimOWS(part.slice(0, equals));
		if (!parameterNameRE.test(name)) return;
		const normalizedName = name.toLowerCase();
		if (normalizedName === "__proto__" || normalizedName === "constructor" || normalizedName === "prototype") return;
		const parameterValue = trimOWS(part.slice(equals + 1));
		parameters[normalizedName] = decodeQuotedString(parameterValue);
	}
	for (let i = 0; i < str.length; i++) {
		const code = str.charCodeAt(i);
		if (quoted) {
			if (escaped) escaped = false;
			else if (code === 92) escaped = true;
			else if (code === 34) quoted = false;
		} else if (code === 34) quoted = true;
		else if (code === 44 || code === 59) {
			parseParameter(i);
			start = i + 1;
		}
	}
	parseParameter(str.length);
	return parameters;
}
var isValidHeaderName = (str) => /^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(str.trim());
function matchHeaderValue(context, value, header, filter, isHeaderNameFilter) {
	if (utils_default.isFunction(filter)) return filter.call(this, value, header);
	if (isHeaderNameFilter) value = header;
	if (!utils_default.isString(value)) return;
	if (utils_default.isString(filter)) return value.indexOf(filter) !== -1;
	if (utils_default.isRegExp(filter)) return filter.test(value);
}
function formatHeader(header) {
	return header.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (w, char, str) => {
		return char.toUpperCase() + str;
	});
}
function buildAccessors(obj, header) {
	const accessorName = utils_default.toCamelCase(" " + header);
	[
		"get",
		"set",
		"has"
	].forEach((methodName) => {
		Object.defineProperty(obj, methodName + accessorName, {
			__proto__: null,
			value: function(arg1, arg2, arg3) {
				return this[methodName].call(this, header, arg1, arg2, arg3);
			},
			configurable: true
		});
	});
}
var AxiosHeaders$1 = class {
	constructor(headers) {
		headers && this.set(headers);
	}
	set(header, valueOrRewrite, rewrite) {
		const self = this;
		function setHeader(_value, _header, _rewrite) {
			const lHeader = normalizeHeader(_header);
			if (!lHeader) return;
			const key = utils_default.findKey(self, lHeader);
			if (!key || self[key] === void 0 || _rewrite === true || _rewrite === void 0 && self[key] !== false) self[key || _header] = normalizeValue(_value);
		}
		const setHeaders = (headers, _rewrite) => utils_default.forEach(headers, (_value, _header) => setHeader(_value, _header, _rewrite));
		if (utils_default.isPlainObject(header) || header instanceof this.constructor) setHeaders(header, valueOrRewrite);
		else if (utils_default.isString(header) && (header = header.trim()) && !isValidHeaderName(header)) setHeaders(parseHeaders_default(header), valueOrRewrite);
		else if (utils_default.isObject(header) && utils_default.isSafeIterable(header)) {
			let obj = Object.create(null), dest, key;
			for (const entry of header) {
				if (!utils_default.isArray(entry)) throw new TypeError("Object iterator must return a key-value pair");
				key = entry[0];
				if (utils_default.hasOwnProp(obj, key)) {
					dest = obj[key];
					obj[key] = utils_default.isArray(dest) ? [...dest, entry[1]] : [dest, entry[1]];
				} else obj[key] = entry[1];
			}
			setHeaders(obj, valueOrRewrite);
		} else header != null && setHeader(valueOrRewrite, header, rewrite);
		return this;
	}
	get(header, parser) {
		header = normalizeHeader(header);
		if (header) {
			const key = utils_default.findKey(this, header);
			if (key) {
				const value = this[key];
				if (!parser) return value;
				if (parser === true) return parseTokens(value);
				if (utils_default.isFunction(parser)) return parser.call(this, value, key);
				if (utils_default.isRegExp(parser)) return parser.exec(value);
				throw new TypeError("parser must be boolean|regexp|function");
			}
		}
	}
	has(header, matcher) {
		header = normalizeHeader(header);
		if (header) {
			const key = utils_default.findKey(this, header);
			return !!(key && this[key] !== void 0 && (!matcher || matchHeaderValue(this, this[key], key, matcher)));
		}
		return false;
	}
	delete(header, matcher) {
		const self = this;
		let deleted = false;
		function deleteHeader(_header) {
			_header = normalizeHeader(_header);
			if (_header) {
				const key = utils_default.findKey(self, _header);
				if (key && (!matcher || matchHeaderValue(self, self[key], key, matcher))) {
					delete self[key];
					deleted = true;
				}
			}
		}
		if (utils_default.isArray(header)) header.forEach(deleteHeader);
		else deleteHeader(header);
		return deleted;
	}
	clear(matcher) {
		const keys = Object.keys(this);
		let i = keys.length;
		let deleted = false;
		while (i--) {
			const key = keys[i];
			if (!matcher || matchHeaderValue(this, this[key], key, matcher, true)) {
				delete this[key];
				deleted = true;
			}
		}
		return deleted;
	}
	normalize(format) {
		const self = this;
		const headers = {};
		utils_default.forEach(this, (value, header) => {
			const key = utils_default.findKey(headers, header);
			if (key) {
				self[key] = normalizeValue(value);
				delete self[header];
				return;
			}
			const normalized = format ? formatHeader(header) : String(header).trim();
			if (normalized !== header) delete self[header];
			self[normalized] = normalizeValue(value);
			headers[normalized] = true;
		});
		return this;
	}
	concat(...targets) {
		return this.constructor.concat(this, ...targets);
	}
	toJSON(asStrings) {
		const obj = Object.create(null);
		utils_default.forEach(this, (value, header) => {
			value != null && value !== false && (obj[header] = asStrings && utils_default.isArray(value) ? value.join(", ") : value);
		});
		return obj;
	}
	[Symbol.iterator]() {
		return Object.entries(this.toJSON())[Symbol.iterator]();
	}
	toString() {
		return Object.entries(this.toJSON()).map(([header, value]) => header + ": " + value).join("\n");
	}
	getSetCookie() {
		const value = this.get("set-cookie");
		return utils_default.isArray(value) ? value : value == null || value === false ? [] : [value];
	}
	get [Symbol.toStringTag]() {
		return "AxiosHeaders";
	}
	static from(thing) {
		return thing instanceof this ? thing : new this(thing);
	}
	static parseParameters(value) {
		return parseParameters(value);
	}
	static concat(first, ...targets) {
		const computed = new this(first);
		targets.forEach((target) => computed.set(target));
		return computed;
	}
	static accessor(header) {
		const accessors = (this[$internals$1] = this[$internals$1] = { accessors: {} }).accessors;
		const prototype = this.prototype;
		function defineAccessor(_header) {
			const lHeader = normalizeHeader(_header);
			if (!accessors[lHeader]) {
				buildAccessors(prototype, _header);
				accessors[lHeader] = true;
			}
		}
		utils_default.isArray(header) ? header.forEach(defineAccessor) : defineAccessor(header);
		return this;
	}
};
AxiosHeaders$1.accessor([
	"Content-Type",
	"Content-Length",
	"Accept",
	"Accept-Encoding",
	"User-Agent",
	"Authorization"
]);
utils_default.reduceDescriptors(AxiosHeaders$1.prototype, ({ value }, key) => {
	let mapped = key[0].toUpperCase() + key.slice(1);
	return {
		get: () => value,
		set(headerValue) {
			this[mapped] = headerValue;
		}
	};
});
utils_default.freezeMethods(AxiosHeaders$1);
//#endregion
//#region node_modules/axios/lib/core/AxiosError.js
var REDACTED = "[REDACTED ****]";
function hasOwnOrPrototypeToJSON(source) {
	if (utils_default.hasOwnProp(source, "toJSON")) return true;
	let prototype = Object.getPrototypeOf(source);
	while (prototype && prototype !== Object.prototype) {
		if (utils_default.hasOwnProp(prototype, "toJSON")) return true;
		prototype = Object.getPrototypeOf(prototype);
	}
	return false;
}
function redactConfig(config, redactKeys) {
	const lowerKeys = new Set(redactKeys.map((k) => String(k).toLowerCase()));
	const seen = [];
	const visit = (source) => {
		if (source === null || typeof source !== "object") return source;
		if (utils_default.isBuffer(source)) return source;
		if (seen.indexOf(source) !== -1) return void 0;
		if (source instanceof AxiosHeaders$1) source = source.toJSON();
		seen.push(source);
		let result;
		if (utils_default.isArray(source)) {
			result = [];
			source.forEach((v, i) => {
				const reducedValue = visit(v);
				if (!utils_default.isUndefined(reducedValue)) result[i] = reducedValue;
			});
		} else {
			if (!utils_default.isPlainObject(source) && hasOwnOrPrototypeToJSON(source)) {
				seen.pop();
				return source;
			}
			result = Object.create(null);
			for (const [key, value] of Object.entries(source)) {
				const reducedValue = lowerKeys.has(key.toLowerCase()) ? REDACTED : visit(value);
				if (!utils_default.isUndefined(reducedValue)) result[key] = reducedValue;
			}
		}
		seen.pop();
		return result;
	};
	return visit(config);
}
function stringifySafely$1(value) {
	try {
		return String(value);
	} catch (err) {
		return "";
	}
}
function aggregateErrorMessage(error) {
	return error.errors.map((entry) => {
		try {
			return entry && entry.message ? stringifySafely$1(entry.message) : stringifySafely$1(entry);
		} catch (err) {
			return "";
		}
	}).filter(Boolean).join("; ") || error.name || "AggregateError";
}
var AxiosError$1 = class AxiosError$1 extends Error {
	static from(error, code, config, request, response, customProps) {
		let message = error.message;
		if (!message && utils_default.isArray(error.errors) && error.errors.length) message = aggregateErrorMessage(error);
		const axiosError = new AxiosError$1(message, code || error.code, config, request, response);
		Object.defineProperty(axiosError, "cause", {
			__proto__: null,
			value: error,
			writable: true,
			enumerable: false,
			configurable: true
		});
		axiosError.name = error.name;
		if (error.status != null && axiosError.status == null) axiosError.status = error.status;
		customProps && Object.assign(axiosError, customProps);
		return axiosError;
	}
	/**
	* Create an Error with the specified message, config, error code, request and response.
	*
	* @param {string} message The error message.
	* @param {string} [code] The error code (for example, 'ECONNABORTED').
	* @param {Object} [config] The config.
	* @param {Object} [request] The request.
	* @param {Object} [response] The response.
	*
	* @returns {Error} The created error.
	*/
	constructor(message, code, config, request, response) {
		super(message);
		Object.defineProperty(this, "message", {
			__proto__: null,
			value: message,
			enumerable: true,
			writable: true,
			configurable: true
		});
		this.name = "AxiosError";
		this.isAxiosError = true;
		code && (this.code = code);
		config && (this.config = config);
		request && (this.request = request);
		if (response) {
			this.response = response;
			this.status = response.status;
		}
	}
	toJSON() {
		const config = this.config;
		const redactKeys = config && utils_default.hasOwnProp(config, "redact") ? config.redact : void 0;
		const serializedConfig = utils_default.isArray(redactKeys) && redactKeys.length > 0 ? redactConfig(config, redactKeys) : utils_default.toJSONObject(config);
		return {
			message: this.message,
			name: this.name,
			description: this.description,
			number: this.number,
			fileName: this.fileName,
			lineNumber: this.lineNumber,
			columnNumber: this.columnNumber,
			stack: this.stack,
			config: serializedConfig,
			code: this.code,
			status: this.status
		};
	}
};
AxiosError$1.ERR_BAD_OPTION_VALUE = "ERR_BAD_OPTION_VALUE";
AxiosError$1.ERR_BAD_OPTION = "ERR_BAD_OPTION";
AxiosError$1.ECONNABORTED = "ECONNABORTED";
AxiosError$1.ETIMEDOUT = "ETIMEDOUT";
AxiosError$1.ECONNREFUSED = "ECONNREFUSED";
AxiosError$1.ERR_NETWORK = "ERR_NETWORK";
AxiosError$1.ERR_FR_TOO_MANY_REDIRECTS = "ERR_FR_TOO_MANY_REDIRECTS";
AxiosError$1.ERR_DEPRECATED = "ERR_DEPRECATED";
AxiosError$1.ERR_BAD_RESPONSE = "ERR_BAD_RESPONSE";
AxiosError$1.ERR_BAD_REQUEST = "ERR_BAD_REQUEST";
AxiosError$1.ERR_CANCELED = "ERR_CANCELED";
AxiosError$1.ERR_NOT_SUPPORT = "ERR_NOT_SUPPORT";
AxiosError$1.ERR_INVALID_URL = "ERR_INVALID_URL";
AxiosError$1.ERR_FORM_DATA_DEPTH_EXCEEDED = "ERR_FORM_DATA_DEPTH_EXCEEDED";
/**
* Determines if the given thing is a array or js object.
*
* @param {string} thing - The object or array to be visited.
*
* @returns {boolean}
*/
function isVisitable(thing) {
	return utils_default.isPlainObject(thing) || utils_default.isArray(thing);
}
/**
* It removes the brackets from the end of a string
*
* @param {string} key - The key of the parameter.
*
* @returns {string} the key without the brackets.
*/
function removeBrackets(key) {
	return utils_default.endsWith(key, "[]") ? key.slice(0, -2) : key;
}
/**
* It takes a path, a key, and a boolean, and returns a string
*
* @param {string} path - The path to the current key.
* @param {string} key - The key of the current object being iterated over.
* @param {string} dots - If true, the key will be rendered with dots instead of brackets.
*
* @returns {string} The path to the current key.
*/
function renderKey(path, key, dots) {
	if (!path) return key;
	return path.concat(key).map(function each(token, i) {
		token = removeBrackets(token);
		return !dots && i ? "[" + token + "]" : token;
	}).join(dots ? "." : "");
}
/**
* If the array is an array and none of its elements are visitable, then it's a flat array.
*
* @param {Array<any>} arr - The array to check
*
* @returns {boolean}
*/
function isFlatArray(arr) {
	return utils_default.isArray(arr) && !arr.some(isVisitable);
}
var predicates = utils_default.toFlatObject(utils_default, {}, null, function filter(prop) {
	return /^is[A-Z]/.test(prop);
});
/**
* Convert a data object to FormData
*
* @param {Object} obj
* @param {?Object} [formData]
* @param {?Object} [options]
* @param {Function} [options.visitor]
* @param {Boolean} [options.metaTokens = true]
* @param {Boolean} [options.dots = false]
* @param {?Boolean} [options.indexes = false]
*
* @returns {Object}
**/
/**
* It converts an object into a FormData object
*
* @param {Object<any, any>} obj - The object to convert to form data.
* @param {string} formData - The FormData object to append to.
* @param {Object<string, any>} options
*
* @returns
*/
function toFormData$1(obj, formData, options) {
	if (!utils_default.isObject(obj)) throw new TypeError("target must be an object");
	formData = formData || new FormData();
	const option = (name, fallback) => {
		const value = utils_default.getSafeProp(options, name);
		return utils_default.isUndefined(value) ? fallback : value;
	};
	const metaTokens = option("metaTokens", true);
	const visitor = option("visitor") || defaultVisitor;
	const dots = option("dots", false);
	const indexes = option("indexes", false);
	const _Blob = option("Blob") || typeof Blob !== "undefined" && Blob;
	const maxDepth = option("maxDepth", 100);
	const useBlob = _Blob && utils_default.isSpecCompliantForm(formData);
	const stack = [];
	if (!utils_default.isFunction(visitor)) throw new TypeError("visitor must be a function");
	function convertValue(value) {
		if (value === null) return "";
		if (utils_default.isDate(value)) return value.toISOString();
		if (utils_default.isBoolean(value)) return value.toString();
		if (!useBlob && utils_default.isBlob(value)) throw new AxiosError$1("Blob is not supported. Use a Buffer instead.");
		if (utils_default.isArrayBuffer(value) || utils_default.isTypedArray(value)) {
			if (useBlob && typeof _Blob === "function") return new _Blob([value]);
			throw new AxiosError$1("Blob is not supported. Use a Buffer instead.", AxiosError$1.ERR_NOT_SUPPORT);
		}
		return value;
	}
	function throwIfMaxDepthExceeded(depth) {
		if (depth > maxDepth) throw new AxiosError$1("Object is too deeply nested (" + depth + " levels). Max depth: " + maxDepth, AxiosError$1.ERR_FORM_DATA_DEPTH_EXCEEDED);
	}
	function stringifyWithDepthLimit(value, depth) {
		if (maxDepth === Infinity) return JSON.stringify(value);
		const ancestors = [];
		return JSON.stringify(value, function limitDepth(_key, currentValue) {
			if (!utils_default.isObject(currentValue)) return currentValue;
			while (ancestors.length && ancestors[ancestors.length - 1] !== this) ancestors.pop();
			ancestors.push(currentValue);
			throwIfMaxDepthExceeded(depth + ancestors.length - 1);
			return currentValue;
		});
	}
	/**
	* Default visitor.
	*
	* @param {*} value
	* @param {String|Number} key
	* @param {Array<String|Number>} path
	* @this {FormData}
	*
	* @returns {boolean} return true to visit the each prop of the value recursively
	*/
	function defaultVisitor(value, key, path) {
		let arr = value;
		if (utils_default.isReactNative(formData) && utils_default.isReactNativeBlob(value)) {
			formData.append(renderKey(path, key, dots), convertValue(value));
			return false;
		}
		if (value && !path && typeof value === "object") {
			if (utils_default.endsWith(key, "{}")) {
				key = metaTokens ? key : key.slice(0, -2);
				value = stringifyWithDepthLimit(value, 1);
			} else if (utils_default.isArray(value) && isFlatArray(value) || (utils_default.isFileList(value) || utils_default.endsWith(key, "[]")) && (arr = utils_default.toArray(value))) {
				key = removeBrackets(key);
				arr.forEach(function each(el, index) {
					!(utils_default.isUndefined(el) || el === null) && formData.append(indexes === true ? renderKey([key], index, dots) : indexes === null ? key : key + "[]", convertValue(el));
				});
				return false;
			}
		}
		if (isVisitable(value)) return true;
		formData.append(renderKey(path, key, dots), convertValue(value));
		return false;
	}
	const exposedHelpers = Object.assign(predicates, {
		defaultVisitor,
		convertValue,
		isVisitable
	});
	function build(value, path, depth = 0) {
		if (utils_default.isUndefined(value)) return;
		throwIfMaxDepthExceeded(depth);
		if (stack.indexOf(value) !== -1) throw new Error("Circular reference detected in " + path.join("."));
		stack.push(value);
		utils_default.forEach(value, function each(el, key) {
			if ((!(utils_default.isUndefined(el) || el === null) && visitor.call(formData, el, utils_default.isString(key) ? key.trim() : key, path, exposedHelpers)) === true) build(el, path ? path.concat(key) : [key], depth + 1);
		});
		stack.pop();
	}
	if (!utils_default.isObject(obj)) throw new TypeError("data must be an object");
	build(obj);
	return formData;
}
//#endregion
//#region node_modules/axios/lib/helpers/AxiosURLSearchParams.js
/**
* It encodes a string by replacing all characters that are not in the unreserved set with
* their percent-encoded equivalents
*
* @param {string} str - The string to encode.
*
* @returns {string} The encoded string.
*/
function encode$1(str) {
	const charMap = {
		"!": "%21",
		"'": "%27",
		"(": "%28",
		")": "%29",
		"~": "%7E",
		"%20": "+"
	};
	return encodeURIComponent(str).replace(/[!'()~]|%20/g, function replacer(match) {
		return charMap[match];
	});
}
/**
* It takes a params object and converts it to a FormData object
*
* @param {Object<string, any>} params - The parameters to be converted to a FormData object.
* @param {Object<string, any>} options - The options object passed to the Axios constructor.
*
* @returns {void}
*/
function AxiosURLSearchParams(params, options) {
	this._pairs = [];
	params && toFormData$1(params, this, options);
}
var prototype = AxiosURLSearchParams.prototype;
prototype.append = function append(name, value) {
	this._pairs.push([name, value]);
};
prototype.toString = function toString(encoder) {
	const _encode = encoder ? (value) => encoder.call(this, value, encode$1) : encode$1;
	return this._pairs.map(function each(pair) {
		return _encode(pair[0]) + "=" + _encode(pair[1]);
	}, "").join("&");
};
//#endregion
//#region node_modules/axios/lib/helpers/buildURL.js
/**
* It replaces URL-encoded forms of `:`, `$`, `,`, and spaces with
* their plain counterparts (`:`, `$`, `,`, `+`).
*
* @param {string} val The value to be encoded.
*
* @returns {string} The encoded value.
*/
function encode(val) {
	return encodeURIComponent(val).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+");
}
/**
* Build a URL by appending params to the end
*
* @param {string} url The base of the url (e.g., http://www.google.com)
* @param {object} [params] The params to be appended
* @param {?(object|Function)} options
*
* @returns {string} The formatted url
*/
function buildURL(url, params, options) {
	if (!params) return url;
	url = url || "";
	const _options = utils_default.isFunction(options) ? { serialize: options } : options;
	const _encode = utils_default.getSafeProp(_options, "encode") || encode;
	const serializeFn = utils_default.getSafeProp(_options, "serialize");
	let serializedParams;
	if (serializeFn) serializedParams = serializeFn(params, _options);
	else serializedParams = utils_default.isURLSearchParams(params) ? params.toString() : new AxiosURLSearchParams(params, _options).toString(_encode);
	if (serializedParams) {
		const hashmarkIndex = url.indexOf("#");
		if (hashmarkIndex !== -1) url = url.slice(0, hashmarkIndex);
		url += (url.indexOf("?") === -1 ? "?" : "&") + serializedParams;
	}
	return url;
}
//#endregion
//#region node_modules/axios/lib/core/InterceptorManager.js
var $internals = Symbol("internals");
function countHandlers(handlers) {
	return handlers ? handlers.length : 0;
}
function trimHandlers(handlers) {
	if (!handlers) return;
	while (handlers.length && handlers[handlers.length - 1] === null) handlers.pop();
}
function syncHandlerEntries(manager, internals) {
	const handlers = manager.handlers;
	const length = countHandlers(handlers);
	if (handlers !== internals.handlersRef) {
		internals.handlersRef = handlers;
		internals.handlerEntries.clear();
	} else if (length !== internals.handlersLength) {
		if (!length) internals.handlerEntries.clear();
		else internals.handlerEntries.forEach(function removeStaleEntry(entry, id) {
			if (handlers[entry.index] !== entry.handler) internals.handlerEntries.delete(id);
		});
	}
	internals.handlersLength = length;
}
var InterceptorManager = class {
	constructor() {
		this.handlers = [];
		this[$internals] = {
			handlersRef: this.handlers,
			handlersLength: this.handlers.length,
			handlerEntries: /* @__PURE__ */ new Map(),
			iterationDepth: 0,
			nextId: 0
		};
	}
	/**
	* Add a new interceptor to the stack
	*
	* @param {Function} fulfilled The function to handle `then` for a `Promise`
	* @param {Function} rejected The function to handle `reject` for a `Promise`
	* @param {Object} options The options for the interceptor, synchronous and runWhen
	*
	* @return {Number} An ID used to remove interceptor later
	*/
	use(fulfilled, rejected, options) {
		const handler = {
			fulfilled,
			rejected,
			synchronous: options ? options.synchronous : false,
			runWhen: options ? options.runWhen : null
		};
		const internals = this[$internals];
		if (this.handlers == null) this.handlers = [];
		syncHandlerEntries(this, internals);
		const id = internals.nextId++;
		this.handlers.push(handler);
		internals.handlerEntries.set(id, {
			handler,
			index: this.handlers.length - 1
		});
		internals.handlersLength = this.handlers.length;
		return id;
	}
	/**
	* Remove an interceptor from the stack
	*
	* @param {Number} id The ID that was returned by `use`
	*
	* @returns {void}
	*/
	eject(id) {
		const internals = this[$internals];
		syncHandlerEntries(this, internals);
		const entry = internals.handlerEntries.get(id);
		if (entry) {
			internals.handlerEntries.delete(id);
			if (this.handlers[entry.index] !== entry.handler) return;
			this.handlers[entry.index] = null;
			if (!internals.iterationDepth) {
				trimHandlers(this.handlers);
				internals.handlersLength = this.handlers.length;
			}
		}
	}
	/**
	* Clear all interceptors from the stack
	*
	* @returns {void}
	*/
	clear() {
		if (this.handlers) {
			this.handlers = [];
			syncHandlerEntries(this, this[$internals]);
		}
	}
	/**
	* Iterate over all the registered interceptors
	*
	* This method is particularly useful for skipping over any
	* interceptors that may have become `null` calling `eject`.
	*
	* @param {Function} fn The function to call for each interceptor
	*
	* @returns {void}
	*/
	forEach(fn) {
		const internals = this[$internals];
		syncHandlerEntries(this, internals);
		internals.iterationDepth++;
		try {
			utils_default.forEach(this.handlers, function forEachHandler(h) {
				if (h !== null) fn(h);
			});
		} finally {
			if (!--internals.iterationDepth) {
				syncHandlerEntries(this, internals);
				trimHandlers(this.handlers);
				internals.handlersLength = countHandlers(this.handlers);
			}
		}
	}
};
//#endregion
//#region node_modules/axios/lib/defaults/transitional.js
var transitional_default = {
	silentJSONParsing: true,
	forcedJSONParsing: true,
	clarifyTimeoutError: false,
	legacyInterceptorReqResOrdering: true,
	advertiseZstdAcceptEncoding: false,
	validateStatusUndefinedResolves: true
};
//#endregion
//#region node_modules/axios/lib/platform/browser/index.js
var browser_default = {
	isBrowser: true,
	classes: {
		URLSearchParams: typeof URLSearchParams !== "undefined" ? URLSearchParams : AxiosURLSearchParams,
		FormData: typeof FormData !== "undefined" ? FormData : null,
		Blob: typeof Blob !== "undefined" ? Blob : null
	},
	protocols: [
		"http",
		"https",
		"file",
		"blob",
		"url",
		"data"
	]
};
//#endregion
//#region node_modules/axios/lib/platform/common/utils.js
var utils_exports = /* @__PURE__ */ __exportAll({
	hasBrowserEnv: () => hasBrowserEnv,
	hasStandardBrowserEnv: () => hasStandardBrowserEnv,
	hasStandardBrowserWebWorkerEnv: () => hasStandardBrowserWebWorkerEnv,
	navigator: () => _navigator,
	origin: () => origin
});
var hasBrowserEnv = typeof window !== "undefined" && typeof document !== "undefined";
var _navigator = typeof navigator === "object" && navigator || void 0;
/**
* Determine if we're running in a standard browser environment
*
* This allows axios to run in a web worker, and react-native.
* Both environments support XMLHttpRequest, but not fully standard globals.
*
* web workers:
*  typeof window -> undefined
*  typeof document -> undefined
*
* react-native:
*  navigator.product -> 'ReactNative'
* nativescript
*  navigator.product -> 'NativeScript' or 'NS'
*
* @returns {boolean}
*/
var hasStandardBrowserEnv = hasBrowserEnv && (!_navigator || [
	"ReactNative",
	"NativeScript",
	"NS"
].indexOf(_navigator.product) < 0);
/**
* Determine if we're running in a standard browser webWorker environment
*
* Although the `isStandardBrowserEnv` method indicates that
* `allows axios to run in a web worker`, the WebWorker will still be
* filtered out due to its judgment standard
* `typeof window !== 'undefined' && typeof document !== 'undefined'`.
* This leads to a problem when axios post `FormData` in webWorker
*/
var hasStandardBrowserWebWorkerEnv = (() => {
	return typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope && typeof self.importScripts === "function";
})();
var origin = hasBrowserEnv && window.location.href || "http://localhost";
//#endregion
//#region node_modules/axios/lib/platform/index.js
var platform_default = {
	...utils_exports,
	...browser_default
};
//#endregion
//#region node_modules/axios/lib/helpers/toURLEncodedForm.js
function toURLEncodedForm(data, options) {
	return toFormData$1(data, new platform_default.classes.URLSearchParams(), {
		visitor: function(value, key, path, helpers) {
			if (platform_default.isNode && utils_default.isBuffer(value)) {
				this.append(key, value.toString("base64"));
				return false;
			}
			return helpers.defaultVisitor.apply(this, arguments);
		},
		...options
	});
}
//#endregion
//#region node_modules/axios/lib/helpers/formDataToJSON.js
var MAX_DEPTH = 100;
function throwIfDepthExceeded(index) {
	if (index > MAX_DEPTH) throw new AxiosError$1("FormData field is too deeply nested (" + index + " levels). Max depth: " + MAX_DEPTH, AxiosError$1.ERR_FORM_DATA_DEPTH_EXCEEDED);
}
/**
* It takes a string like `foo[x][y][z]` and returns an array like `['foo', 'x', 'y', 'z']
*
* @param {string} name - The name of the property to get.
*
* @returns An array of strings.
*/
function parsePropPath(name) {
	const path = [];
	const pattern = /[^.[\]]+|\[([^.[\]]*)]/g;
	let match;
	while ((match = pattern.exec(name)) !== null) {
		throwIfDepthExceeded(path.length);
		path.push(match[0] === "[]" ? "" : match[1] || match[0]);
	}
	return path;
}
/**
* Convert an array to an object.
*
* @param {Array<any>} arr - The array to convert to an object.
*
* @returns An object with the same keys and values as the array.
*/
function arrayToObject(arr) {
	const obj = {};
	const keys = Object.keys(arr);
	let i;
	const len = keys.length;
	let key;
	for (i = 0; i < len; i++) {
		key = keys[i];
		obj[key] = arr[key];
	}
	return obj;
}
/**
* It takes a FormData object and returns a JavaScript object
*
* @param {string} formData The FormData object to convert to JSON.
*
* @returns {Object<string, any> | null} The converted object.
*/
function formDataToJSON(formData) {
	function buildPath(path, value, target, index) {
		throwIfDepthExceeded(index);
		let name = path[index++];
		if (name === "__proto__") return true;
		const isNumericKey = Number.isFinite(+name);
		const isLast = index >= path.length;
		name = !name && utils_default.isArray(target) ? target.length : name;
		if (isLast) {
			if (utils_default.hasOwnProp(target, name)) target[name] = utils_default.isArray(target[name]) ? target[name].concat(value) : [target[name], value];
			else target[name] = value;
			return !isNumericKey;
		}
		if (!utils_default.hasOwnProp(target, name) || !utils_default.isObject(target[name])) target[name] = [];
		if (buildPath(path, value, target[name], index) && utils_default.isArray(target[name])) target[name] = arrayToObject(target[name]);
		return !isNumericKey;
	}
	if (utils_default.isFormData(formData) && utils_default.isFunction(formData.entries)) {
		const obj = {};
		utils_default.forEachEntry(formData, (name, value) => {
			buildPath(parsePropPath(name), value, obj, 0);
		});
		return obj;
	}
	return null;
}
//#endregion
//#region node_modules/axios/lib/core/methodList.js
var methodList = Object.freeze([
	"get",
	"delete",
	"head",
	"options",
	"post",
	"put",
	"patch",
	"purge",
	"link",
	"unlink",
	"query"
]);
//#endregion
//#region node_modules/axios/lib/defaults/index.js
var own = (obj, key) => obj != null && utils_default.hasOwnProp(obj, key) ? obj[key] : void 0;
/**
* It takes a string, tries to parse it, and if it fails, it returns the stringified version
* of the input
*
* @param {any} rawValue - The value to be stringified.
* @param {Function} parser - A function that parses a string into a JavaScript object.
* @param {Function} encoder - A function that takes a value and returns a string.
*
* @returns {string} A stringified version of the rawValue.
*/
function stringifySafely(rawValue, parser, encoder) {
	if (utils_default.isString(rawValue)) try {
		(parser || JSON.parse)(rawValue);
		return utils_default.trim(rawValue);
	} catch (e) {
		if (e.name !== "SyntaxError") throw e;
	}
	return (encoder || JSON.stringify)(rawValue);
}
var defaults = {
	transitional: transitional_default,
	adapter: [
		"xhr",
		"http",
		"fetch"
	],
	transformRequest: [function transformRequest(data, headers) {
		const contentType = headers.getContentType() || "";
		const hasJSONContentType = contentType.indexOf("application/json") > -1;
		const isObjectPayload = utils_default.isObject(data);
		if (isObjectPayload && utils_default.isHTMLForm(data)) data = new FormData(data);
		if (utils_default.isFormData(data)) return hasJSONContentType ? JSON.stringify(formDataToJSON(data)) : data;
		if (utils_default.isArrayBuffer(data) || utils_default.isBuffer(data) || utils_default.isStream(data) || utils_default.isFile(data) || utils_default.isBlob(data) || utils_default.isReadableStream(data)) return data;
		if (utils_default.isArrayBufferView(data)) return data.buffer;
		if (utils_default.isURLSearchParams(data)) {
			headers.setContentType("application/x-www-form-urlencoded;charset=utf-8", false);
			return data.toString();
		}
		let isFileList;
		if (isObjectPayload) {
			const formSerializer = own(this, "formSerializer");
			if (contentType.indexOf("application/x-www-form-urlencoded") > -1) return toURLEncodedForm(data, formSerializer).toString();
			if ((isFileList = utils_default.isFileList(data)) || contentType.indexOf("multipart/form-data") > -1) {
				const env = own(this, "env");
				const _FormData = env && env.FormData;
				return toFormData$1(isFileList ? { "files[]": data } : data, _FormData && new _FormData(), formSerializer);
			}
		}
		if (isObjectPayload || hasJSONContentType) {
			headers.setContentType("application/json", false);
			return stringifySafely(data);
		}
		return data;
	}],
	transformResponse: [function transformResponse(data) {
		const transitional = own(this, "transitional") || defaults.transitional;
		const forcedJSONParsing = transitional && transitional.forcedJSONParsing;
		const responseType = own(this, "responseType");
		const JSONRequested = responseType === "json";
		if (utils_default.isResponse(data) || utils_default.isReadableStream(data)) return data;
		if (data && utils_default.isString(data) && (forcedJSONParsing && !responseType || JSONRequested)) {
			const strictJSONParsing = !(transitional && transitional.silentJSONParsing) && JSONRequested;
			try {
				return JSON.parse(data, own(this, "parseReviver"));
			} catch (e) {
				if (strictJSONParsing) {
					if (e.name === "SyntaxError") throw AxiosError$1.from(e, AxiosError$1.ERR_BAD_RESPONSE, this, null, own(this, "response"));
					throw e;
				}
			}
		}
		return data;
	}],
	/**
	* A timeout in milliseconds to abort a request. If set to 0 (default) a
	* timeout is not created.
	*/
	timeout: 0,
	xsrfCookieName: "XSRF-TOKEN",
	xsrfHeaderName: "X-XSRF-TOKEN",
	maxContentLength: -1,
	maxBodyLength: -1,
	env: {
		FormData: platform_default.classes.FormData,
		Blob: platform_default.classes.Blob
	},
	validateStatus: function validateStatus(status) {
		return status >= 200 && status < 300;
	},
	headers: { common: {
		Accept: "application/json, text/plain, */*",
		"Content-Type": void 0
	} }
};
utils_default.forEach(methodList, (method) => {
	defaults.headers[method] = {};
});
//#endregion
//#region node_modules/axios/lib/core/transformData.js
/**
* Transform the data for a request or a response
*
* @param {Array|Function} fns A single function or Array of functions
* @param {?Object} response The response object
*
* @returns {*} The resulting transformed data
*/
function transformData(fns, response) {
	const config = this || defaults;
	const context = response || config;
	const headers = AxiosHeaders$1.from(context.headers);
	let data = context.data;
	utils_default.forEach(fns, function transform(fn) {
		data = fn.call(config, data, headers.normalize(), response ? response.status : void 0);
	});
	headers.normalize();
	return data;
}
//#endregion
//#region node_modules/axios/lib/cancel/isCancel.js
function isCancel$1(value) {
	return !!(value && value.__CANCEL__);
}
//#endregion
//#region node_modules/axios/lib/cancel/CanceledError.js
var CanceledError$1 = class extends AxiosError$1 {
	/**
	* A `CanceledError` is an object that is thrown when an operation is canceled.
	*
	* @param {string=} message The message.
	* @param {Object=} config The config.
	* @param {Object=} request The request.
	*
	* @returns {CanceledError} The created error.
	*/
	constructor(message, config, request) {
		super(message == null ? "canceled" : message, AxiosError$1.ERR_CANCELED, config, request);
		this.name = "CanceledError";
		this.__CANCEL__ = true;
	}
};
//#endregion
//#region node_modules/axios/lib/core/settle.js
/**
* Resolve or reject a Promise based on response status.
*
* @param {Function} resolve A function that resolves the promise.
* @param {Function} reject A function that rejects the promise.
* @param {object} response The response.
*
* @returns {object} The response.
*/
function settle(resolve, reject, response) {
	const validateStatus = response.config.validateStatus;
	if (!response.status || !validateStatus || validateStatus(response.status)) resolve(response);
	else reject(new AxiosError$1("Request failed with status code " + response.status, response.status >= 400 && response.status < 500 ? AxiosError$1.ERR_BAD_REQUEST : AxiosError$1.ERR_BAD_RESPONSE, response.config, response.request, response));
}
//#endregion
//#region node_modules/axios/lib/helpers/normalizeURLForProtocolCheck.js
var urlParserControlCharacters = /[\t\n\r]/g;
/**
* Match WHATWG URL preprocessing before checking a URL's protocol.
*
* @param {string} url
*
* @returns {string}
*/
function normalizeURLForProtocolCheck(url) {
	if (typeof url !== "string") return url;
	let start = 0;
	while (start < url.length && url.charCodeAt(start) <= 32) start++;
	return url.slice(start).replace(urlParserControlCharacters, "");
}
//#endregion
//#region node_modules/axios/lib/helpers/parseProtocol.js
function parseProtocol(url) {
	const match = /^([-+\w]{1,25}):(?:\/\/)?/.exec(url);
	return match && match[1] || "";
}
//#endregion
//#region node_modules/axios/lib/helpers/speedometer.js
/**
* Calculate data maxRate
* @param {Number} [samplesCount= 10]
* @param {Number} [min= 1000]
* @returns {Function}
*/
function speedometer(samplesCount, min) {
	samplesCount = samplesCount || 10;
	const bytes = new Array(samplesCount);
	const timestamps = new Array(samplesCount);
	let head = 0;
	let tail = 0;
	let firstSampleTS;
	min = min !== void 0 ? min : 1e3;
	return function push(chunkLength) {
		const now = Date.now();
		const startedAt = timestamps[tail];
		if (!firstSampleTS) firstSampleTS = now;
		bytes[head] = chunkLength;
		timestamps[head] = now;
		let i = tail;
		let bytesCount = 0;
		while (i !== head) {
			bytesCount += bytes[i++];
			i = i % samplesCount;
		}
		head = (head + 1) % samplesCount;
		if (head === tail) tail = (tail + 1) % samplesCount;
		if (now - firstSampleTS < min) return;
		const passed = startedAt && now - startedAt;
		return passed ? Math.round(bytesCount * 1e3 / passed) : void 0;
	};
}
//#endregion
//#region node_modules/axios/lib/helpers/throttle.js
/**
* Throttle decorator
* @param {Function} fn
* @param {Number} freq
* @return {Array<Function>}
*/
function throttle(fn, freq) {
	let timestamp = 0;
	let threshold = 1e3 / freq;
	let lastArgs;
	let timer;
	const invoke = (args, now = Date.now()) => {
		timestamp = now;
		lastArgs = null;
		if (timer) {
			clearTimeout(timer);
			timer = null;
		}
		fn(...args);
	};
	const throttled = (...args) => {
		const now = Date.now();
		const passed = now - timestamp;
		if (passed >= threshold) invoke(args, now);
		else {
			lastArgs = args;
			if (!timer) timer = setTimeout(() => {
				timer = null;
				invoke(lastArgs);
			}, threshold - passed);
		}
	};
	const flush = () => lastArgs && invoke(lastArgs);
	const flushWith = (...args) => invoke(args);
	return [
		throttled,
		flush,
		flushWith
	];
}
//#endregion
//#region node_modules/axios/lib/helpers/progressEventReducer.js
var progressEventReducer = (listener, isDownloadStream, freq = 3) => {
	let bytesNotified = 0;
	const _speedometer = speedometer(50, 250);
	return throttle((e) => {
		if (!e || !utils_default.isNumber(e.loaded)) return;
		const rawLoaded = e.loaded;
		const total = e.lengthComputable ? e.total : void 0;
		const loaded = Math.max(0, total != null ? Math.min(rawLoaded, total) : rawLoaded);
		const progressBytes = Math.max(0, loaded - bytesNotified);
		const rate = _speedometer(progressBytes);
		bytesNotified = Math.max(bytesNotified, loaded);
		listener({
			loaded,
			total,
			progress: total ? loaded / total : void 0,
			bytes: progressBytes,
			rate: rate ? rate : void 0,
			estimated: rate && total ? (total - loaded) / rate : void 0,
			event: e,
			lengthComputable: total != null,
			[isDownloadStream ? "download" : "upload"]: true
		});
	}, freq);
};
var progressEventDecorator = (total, throttled) => {
	const lengthComputable = total != null;
	return [(loaded) => throttled[0]({
		lengthComputable,
		total,
		loaded
	}), throttled[1]];
};
var asyncDecorator = (fn, scheduler = utils_default.asap) => (...args) => scheduler(() => fn(...args));
//#endregion
//#region node_modules/axios/lib/helpers/isURLSameOrigin.js
var isURLSameOrigin_default = platform_default.hasStandardBrowserEnv ? ((origin, isMSIE) => (url) => {
	url = new URL(url, platform_default.origin);
	return origin.protocol === url.protocol && origin.host === url.host && (isMSIE || origin.port === url.port);
})(new URL(platform_default.origin), platform_default.navigator && /(msie|trident)/i.test(platform_default.navigator.userAgent)) : () => true;
//#endregion
//#region node_modules/axios/lib/helpers/cookies.js
var cookies_default = platform_default.hasStandardBrowserEnv ? {
	write(name, value, expires, path, domain, secure, sameSite) {
		if (typeof document === "undefined") return;
		const cookie = [`${name}=${encodeURIComponent(value)}`];
		if (utils_default.isNumber(expires)) cookie.push(`expires=${new Date(expires).toUTCString()}`);
		if (utils_default.isString(path)) cookie.push(`path=${path}`);
		if (utils_default.isString(domain)) cookie.push(`domain=${domain}`);
		if (secure === true) cookie.push("secure");
		if (utils_default.isString(sameSite)) cookie.push(`SameSite=${sameSite}`);
		document.cookie = cookie.join("; ");
	},
	read(name) {
		if (typeof document === "undefined") return null;
		const cookies = document.cookie.split(";");
		for (let i = 0; i < cookies.length; i++) {
			const cookie = cookies[i].replace(/^\s+/, "");
			const eq = cookie.indexOf("=");
			if (eq !== -1 && cookie.slice(0, eq) === name) try {
				return decodeURIComponent(cookie.slice(eq + 1));
			} catch (e) {
				return cookie.slice(eq + 1);
			}
		}
		return null;
	},
	remove(name) {
		this.write(name, "", Date.now() - 864e5, "/");
	}
} : {
	write() {},
	read() {
		return null;
	},
	remove() {}
};
//#endregion
//#region node_modules/axios/lib/helpers/isAbsoluteURL.js
/**
* Determines whether the specified URL is absolute
*
* @param {string} url The URL to test
*
* @returns {boolean} True if the specified URL is absolute, otherwise false
*/
function isAbsoluteURL(url) {
	if (typeof url !== "string") return false;
	return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(url);
}
//#endregion
//#region node_modules/axios/lib/helpers/combineURLs.js
/**
* Creates a new URL by combining the specified URLs
*
* @param {string} baseURL The base URL
* @param {string} relativeURL The relative URL
*
* @returns {string} The combined URL
*/
function combineURLs(baseURL, relativeURL) {
	if (!relativeURL) return baseURL;
	let end = baseURL.length;
	while (end > 0 && baseURL.charCodeAt(end - 1) === 47) end--;
	return baseURL.slice(0, end) + "/" + relativeURL.replace(/^\/+/, "");
}
//#endregion
//#region node_modules/axios/lib/core/buildFullPath.js
var malformedHttpProtocol = /^https?:(?!\/\/)/i;
function redactFragment(fragment) {
	if (!fragment) return fragment;
	return fragment.replace(/(^|&)([^=&]*=)?[^&]+/g, (match, separator, parameterName = "") => {
		return `${separator}${parameterName}${REDACTED}`;
	});
}
function redactSensitiveURLParts(url) {
	const redactedURL = url.replace(/^(https?:\/{0,2})[^/?#]*@/i, `$1${REDACTED}@`);
	const fragmentIndex = redactedURL.indexOf("#");
	const redactedURLWithoutFragment = (fragmentIndex === -1 ? redactedURL : redactedURL.slice(0, fragmentIndex)).replace(/([?&][^=&#]*=)[^&#]*/g, `$1${REDACTED}`);
	if (fragmentIndex === -1) return redactedURLWithoutFragment;
	return `${redactedURLWithoutFragment}#${redactFragment(redactedURL.slice(fragmentIndex + 1))}`;
}
function assertValidHttpProtocolURL(url, config) {
	if (typeof url === "string") {
		const normalizedURL = normalizeURLForProtocolCheck(url);
		if (malformedHttpProtocol.test(normalizedURL)) throw new AxiosError$1(`Invalid URL ${JSON.stringify(redactSensitiveURLParts(normalizedURL))}: missing "//" after protocol`, AxiosError$1.ERR_INVALID_URL, config);
	}
}
/**
* Creates a new URL by combining the baseURL with the requestedURL,
* only when the requestedURL is not already an absolute URL.
* If the requestURL is absolute, this function returns the requestedURL untouched.
*
* @param {string} baseURL The base URL
* @param {string} requestedURL Absolute or relative URL to combine
*
* @returns {string} The combined full path
*/
function buildFullPath(baseURL, requestedURL, allowAbsoluteUrls, config) {
	assertValidHttpProtocolURL(requestedURL, config);
	let isRelativeUrl = !isAbsoluteURL(requestedURL);
	if (baseURL && (isRelativeUrl || allowAbsoluteUrls === false)) {
		assertValidHttpProtocolURL(baseURL, config);
		return combineURLs(baseURL, requestedURL);
	}
	return requestedURL;
}
//#endregion
//#region node_modules/axios/lib/core/mergeConfig.js
var headersToObject = (thing) => thing instanceof AxiosHeaders$1 ? { ...thing } : thing;
var ownEnumerableKeys = (thing) => {
	if (Object.getOwnPropertySymbols && Object.getOwnPropertyDescriptor) return Object.keys(thing).concat(Object.getOwnPropertySymbols(thing).filter((symbol) => Object.getOwnPropertyDescriptor(thing, symbol).enumerable));
	return Object.keys(thing);
};
/**
* Config-specific merge-function which creates a new config-object
* by merging two configuration objects together.
*
* @param {Object} config1
* @param {Object} config2
*
* @returns {Object} New object resulting from merging config2 to config1
*/
function mergeConfig$1(config1, config2) {
	config1 = config1 || {};
	config2 = config2 || {};
	const config = Object.create(null);
	Object.defineProperty(config, "hasOwnProperty", {
		__proto__: null,
		value: Object.prototype.hasOwnProperty,
		enumerable: false,
		writable: true,
		configurable: true
	});
	function getMergedValue(target, source, prop, caseless) {
		if (utils_default.isPlainObject(target) && utils_default.isPlainObject(source)) return utils_default.merge.call({ caseless }, target, source);
		else if (utils_default.isPlainObject(source)) return utils_default.merge({}, source);
		else if (utils_default.isArray(source)) return source.slice();
		return source;
	}
	function mergeDeepProperties(a, b, prop, caseless) {
		if (!utils_default.isUndefined(b)) return getMergedValue(a, b, prop, caseless);
		else if (!utils_default.isUndefined(a)) return getMergedValue(void 0, a, prop, caseless);
	}
	function valueFromConfig2(a, b) {
		if (!utils_default.isUndefined(b)) return getMergedValue(void 0, b);
	}
	function defaultToConfig2(a, b) {
		if (!utils_default.isUndefined(b)) return getMergedValue(void 0, b);
		else if (!utils_default.isUndefined(a)) return getMergedValue(void 0, a);
	}
	function getMergedTransitionalOption(prop) {
		const transitional2 = utils_default.hasOwnProp(config2, "transitional") ? config2.transitional : void 0;
		if (!utils_default.isUndefined(transitional2)) {
			if (utils_default.isPlainObject(transitional2)) {
				if (utils_default.hasOwnProp(transitional2, prop)) return transitional2[prop];
			} else return;
		}
		const transitional1 = utils_default.hasOwnProp(config1, "transitional") ? config1.transitional : void 0;
		if (utils_default.isPlainObject(transitional1) && utils_default.hasOwnProp(transitional1, prop)) return transitional1[prop];
	}
	function mergeDirectKeys(a, b, prop) {
		if (utils_default.hasOwnProp(config2, prop)) return getMergedValue(a, b);
		else if (utils_default.hasOwnProp(config1, prop)) return getMergedValue(void 0, a);
	}
	const mergeMap = {
		url: valueFromConfig2,
		method: valueFromConfig2,
		data: valueFromConfig2,
		baseURL: defaultToConfig2,
		transformRequest: defaultToConfig2,
		transformResponse: defaultToConfig2,
		paramsSerializer: defaultToConfig2,
		timeout: defaultToConfig2,
		timeoutErrorMessage: defaultToConfig2,
		withCredentials: defaultToConfig2,
		withXSRFToken: defaultToConfig2,
		adapter: defaultToConfig2,
		responseType: defaultToConfig2,
		xsrfCookieName: defaultToConfig2,
		xsrfHeaderName: defaultToConfig2,
		onUploadProgress: defaultToConfig2,
		onDownloadProgress: defaultToConfig2,
		decompress: defaultToConfig2,
		maxContentLength: defaultToConfig2,
		maxBodyLength: defaultToConfig2,
		beforeRedirect: defaultToConfig2,
		transport: defaultToConfig2,
		httpAgent: defaultToConfig2,
		httpsAgent: defaultToConfig2,
		cancelToken: defaultToConfig2,
		socketPath: defaultToConfig2,
		allowedSocketPaths: defaultToConfig2,
		responseEncoding: defaultToConfig2,
		validateStatus: mergeDirectKeys,
		headers: (a, b, prop) => mergeDeepProperties(headersToObject(a), headersToObject(b), prop, true)
	};
	utils_default.forEach(ownEnumerableKeys({
		...config1,
		...config2
	}), function computeConfigValue(prop) {
		if (prop === "__proto__" || prop === "constructor" || prop === "prototype") return;
		const merge = utils_default.hasOwnProp(mergeMap, prop) ? mergeMap[prop] : mergeDeepProperties;
		const configValue = merge(utils_default.hasOwnProp(config1, prop) ? config1[prop] : void 0, utils_default.hasOwnProp(config2, prop) ? config2[prop] : void 0, prop);
		utils_default.isUndefined(configValue) && merge !== mergeDirectKeys || (config[prop] = configValue);
	});
	if (utils_default.hasOwnProp(config2, "validateStatus") && utils_default.isUndefined(config2.validateStatus) && getMergedTransitionalOption("validateStatusUndefinedResolves") === false) {
		if (utils_default.hasOwnProp(config1, "validateStatus")) config.validateStatus = getMergedValue(void 0, config1.validateStatus);
		else delete config.validateStatus;
	}
	return config;
}
//#endregion
//#region node_modules/axios/lib/core/setFormDataHeaders.js
var FORM_DATA_CONTENT_HEADERS = ["content-type", "content-length"];
/**
* Apply the headers generated by a FormData implementation to the request headers,
* honoring the `formDataHeaderPolicy` option: with 'content-only', copy only the
* content-* headers; otherwise merge all of them.
*
* @param {AxiosHeaders} headers - the request headers to mutate
* @param {Object | null | undefined} formHeaders - headers produced by the FormData implementation
* @param {String} [policy] - the resolved `formDataHeaderPolicy` config value
*
* @returns {void}
*/
function setFormDataHeaders(headers, formHeaders, policy) {
	if (policy !== "content-only") {
		headers.set(formHeaders);
		return;
	}
	Object.entries(formHeaders || {}).forEach(([key, val]) => {
		if (FORM_DATA_CONTENT_HEADERS.includes(key.toLowerCase())) headers.set(key, val);
	});
}
//#endregion
//#region node_modules/axios/lib/helpers/resolveConfig.js
/**
* Encode a UTF-8 string to a Latin-1 byte string for use with btoa().
* This is a modern replacement for the deprecated unescape(encodeURIComponent(str)) pattern.
*
* @param {string} str The string to encode
*
* @returns {string} UTF-8 bytes as a Latin-1 string
*/
var encodeUTF8$1 = (str) => encodeURIComponent(str).replace(/%([0-9A-F]{2})/gi, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
function resolveConfig(config) {
	const newConfig = mergeConfig$1({}, config);
	const own = (key) => utils_default.hasOwnProp(newConfig, key) ? newConfig[key] : void 0;
	const data = own("data");
	let withXSRFToken = own("withXSRFToken");
	const xsrfHeaderName = own("xsrfHeaderName");
	const xsrfCookieName = own("xsrfCookieName");
	let headers = own("headers");
	const auth = own("auth");
	const baseURL = own("baseURL");
	const allowAbsoluteUrls = own("allowAbsoluteUrls");
	const url = own("url");
	newConfig.headers = headers = AxiosHeaders$1.from(headers);
	newConfig.url = buildURL(buildFullPath(baseURL, url, allowAbsoluteUrls, newConfig), own("params"), own("paramsSerializer"));
	if (auth) {
		const username = utils_default.getSafeProp(auth, "username") || "";
		const password = utils_default.getSafeProp(auth, "password") || "";
		try {
			headers.set("Authorization", "Basic " + btoa(username + ":" + (password ? encodeUTF8$1(password) : "")));
		} catch (e) {
			throw AxiosError$1.from(e, AxiosError$1.ERR_BAD_OPTION_VALUE, config);
		}
	}
	if (utils_default.isFormData(data)) {
		const getHeaders = utils_default.getSafeProp(data, "getHeaders");
		if (platform_default.hasStandardBrowserEnv || platform_default.hasStandardBrowserWebWorkerEnv || utils_default.isReactNative(data)) headers.setContentType(void 0);
		else if (utils_default.isFunction(getHeaders)) setFormDataHeaders(headers, getHeaders.call(data), own("formDataHeaderPolicy"));
	}
	if (platform_default.hasStandardBrowserEnv) {
		if (utils_default.isFunction(withXSRFToken)) withXSRFToken = withXSRFToken(newConfig);
		if (withXSRFToken === true || withXSRFToken == null && isURLSameOrigin_default(newConfig.url)) {
			const xsrfValue = xsrfHeaderName && xsrfCookieName && cookies_default.read(xsrfCookieName);
			if (xsrfValue) headers.set(xsrfHeaderName, xsrfValue);
		}
	}
	return newConfig;
}
var xhr_default = typeof XMLHttpRequest !== "undefined" && function(config) {
	return new Promise(function dispatchXhrRequest(resolve, reject) {
		const _config = resolveConfig(config);
		let requestData = _config.data;
		const requestHeaders = AxiosHeaders$1.from(_config.headers).normalize();
		let { responseType, onUploadProgress, onDownloadProgress } = _config;
		let onCanceled;
		let uploadThrottled, downloadThrottled;
		let flushUpload, flushDownload, flushDownloadWithEvent;
		function done() {
			flushUpload && flushUpload();
			flushDownload && flushDownload();
			_config.cancelToken && _config.cancelToken.unsubscribe(onCanceled);
			_config.signal && _config.signal.removeEventListener("abort", onCanceled);
		}
		let request = new XMLHttpRequest();
		request.open(_config.method.toUpperCase(), _config.url, true);
		request.timeout = _config.timeout;
		function onloadend(event) {
			if (!request) return;
			if (request.status === 0 && (parseProtocol(normalizeURLForProtocolCheck(_config.url)) || parseProtocol(platform_default.origin)) !== "file" && !(request.responseURL && request.responseURL.startsWith("file:"))) {
				reject(new AxiosError$1("Request aborted", AxiosError$1.ECONNABORTED, config, request));
				done();
				request = null;
				return;
			}
			try {
				if (event) flushDownloadWithEvent && flushDownloadWithEvent(event);
				else flushDownload && flushDownload();
			} catch (err) {
				setTimeout(() => {
					throw err;
				});
			}
			if (!request) return;
			const responseHeaders = AxiosHeaders$1.from("getAllResponseHeaders" in request && request.getAllResponseHeaders());
			settle(function _resolve(value) {
				resolve(value);
				done();
			}, function _reject(err) {
				reject(err);
				done();
			}, {
				data: !responseType || responseType === "text" || responseType === "json" ? request.responseText : request.response,
				status: request.status,
				statusText: request.statusText,
				headers: responseHeaders,
				config,
				request
			});
			request = null;
		}
		if ("onloadend" in request) request.onloadend = onloadend;
		else request.onreadystatechange = function handleLoad() {
			if (!request || request.readyState !== 4) return;
			if (request.status === 0 && !(request.responseURL && request.responseURL.startsWith("file:"))) return;
			setTimeout(onloadend);
		};
		request.onabort = function handleAbort() {
			if (!request) return;
			reject(new AxiosError$1("Request aborted", AxiosError$1.ECONNABORTED, config, request));
			done();
			request = null;
		};
		request.onerror = function handleError(event) {
			const err = new AxiosError$1(event && event.message ? event.message : "Network Error", AxiosError$1.ERR_NETWORK, config, request);
			err.event = event || null;
			reject(err);
			done();
			request = null;
		};
		request.ontimeout = function handleTimeout() {
			let timeoutErrorMessage = _config.timeout ? "timeout of " + _config.timeout + "ms exceeded" : "timeout exceeded";
			const transitional = _config.transitional || transitional_default;
			if (_config.timeoutErrorMessage) timeoutErrorMessage = _config.timeoutErrorMessage;
			reject(new AxiosError$1(timeoutErrorMessage, transitional.clarifyTimeoutError ? AxiosError$1.ETIMEDOUT : AxiosError$1.ECONNABORTED, config, request));
			done();
			request = null;
		};
		requestData === void 0 && requestHeaders.setContentType(null);
		if ("setRequestHeader" in request) utils_default.forEach(toByteStringHeaderObject(requestHeaders), function setRequestHeader(val, key) {
			request.setRequestHeader(key, val);
		});
		if (!utils_default.isUndefined(_config.withCredentials)) request.withCredentials = !!_config.withCredentials;
		if (responseType && responseType !== "json") request.responseType = _config.responseType;
		if (onDownloadProgress) {
			[downloadThrottled, flushDownload, flushDownloadWithEvent] = progressEventReducer(onDownloadProgress, true);
			request.addEventListener("progress", downloadThrottled);
		}
		if (onUploadProgress && request.upload) {
			[uploadThrottled, flushUpload] = progressEventReducer(onUploadProgress);
			request.upload.addEventListener("progress", uploadThrottled);
			request.upload.addEventListener("loadend", flushUpload);
		}
		if (_config.cancelToken || _config.signal) {
			onCanceled = (cancel) => {
				if (!request) return;
				reject(!cancel || cancel.type ? new CanceledError$1(null, config, request) : cancel);
				request.abort();
				done();
				request = null;
			};
			_config.cancelToken && _config.cancelToken.subscribe(onCanceled);
			if (_config.signal) _config.signal.aborted ? onCanceled() : _config.signal.addEventListener("abort", onCanceled);
		}
		const protocol = parseProtocol(_config.url);
		if (protocol && !platform_default.protocols.includes(protocol)) {
			reject(new AxiosError$1("Unsupported protocol " + protocol + ":", AxiosError$1.ERR_BAD_REQUEST, config));
			done();
			return;
		}
		request.send(requestData || null);
	});
};
//#endregion
//#region node_modules/axios/lib/helpers/composeSignals.js
var composeSignals = (signals, timeout) => {
	signals = signals ? signals.filter(Boolean) : [];
	if (!timeout && !signals.length) return;
	const controller = new AbortController();
	let aborted = false;
	const onabort = function(reason) {
		if (!aborted) {
			aborted = true;
			unsubscribe();
			const err = reason instanceof Error ? reason : this.reason;
			controller.abort(err instanceof AxiosError$1 ? err : new CanceledError$1(err instanceof Error ? err.message : err));
		}
	};
	let timer = timeout && setTimeout(() => {
		timer = null;
		onabort(new AxiosError$1(`timeout of ${timeout}ms exceeded`, AxiosError$1.ETIMEDOUT));
	}, timeout);
	const unsubscribe = () => {
		if (!signals) return;
		timer && clearTimeout(timer);
		timer = null;
		signals.forEach((signal) => {
			signal.unsubscribe ? signal.unsubscribe(onabort) : signal.removeEventListener("abort", onabort);
		});
		signals = null;
	};
	signals.forEach((signal) => {
		if (aborted) return;
		if (signal.aborted) {
			onabort.call(signal);
			return;
		}
		signal.addEventListener("abort", onabort, { once: true });
	});
	const { signal } = controller;
	signal.unsubscribe = () => utils_default.asap(unsubscribe);
	return signal;
};
//#endregion
//#region node_modules/axios/lib/helpers/trackStream.js
var streamChunk = function* (chunk, chunkSize) {
	let len = chunk.byteLength;
	if (!chunkSize || len < chunkSize) {
		yield chunk;
		return;
	}
	let pos = 0;
	let end;
	while (pos < len) {
		end = pos + chunkSize;
		yield chunk.slice(pos, end);
		pos = end;
	}
};
var readBytes = async function* (iterable, chunkSize) {
	for await (const chunk of readStream(iterable)) yield* streamChunk(chunk, chunkSize);
};
var readStream = async function* (stream) {
	if (stream[Symbol.asyncIterator]) {
		yield* stream;
		return;
	}
	const reader = stream.getReader();
	try {
		for (;;) {
			const { done, value } = await reader.read();
			if (done) break;
			yield value;
		}
	} finally {
		await reader.cancel();
	}
};
var trackStream = (stream, chunkSize, onProgress, onFinish) => {
	const iterator = readBytes(stream, chunkSize);
	let bytes = 0;
	let done;
	let _onFinish = (e) => {
		if (!done) {
			done = true;
			onFinish && onFinish(e);
		}
	};
	return new ReadableStream({
		async pull(controller) {
			try {
				const { done, value } = await iterator.next();
				if (done) {
					_onFinish();
					controller.close();
					return;
				}
				let len = value.byteLength;
				if (onProgress) onProgress(bytes += len);
				controller.enqueue(new Uint8Array(value));
			} catch (err) {
				_onFinish(err);
				throw err;
			}
		},
		cancel(reason) {
			_onFinish(reason);
			return iterator.return();
		}
	}, { highWaterMark: 2 });
};
//#endregion
//#region node_modules/axios/lib/helpers/estimateDataURLDecodedBytes.js
/**
* Estimate data: URL byte lengths *without* allocating large buffers.
* - Fetch percent-decodes a base64 body before decoding it.
* - Node's Buffer.from(body, 'base64') sizes its backing allocation from the
*   raw body, including ignored characters and content after padding.
* - Non-base64 data is percent-decoded and then encoded as UTF-8.
*/
var isHexDigit = (charCode) => charCode >= 48 && charCode <= 57 || charCode >= 65 && charCode <= 70 || charCode >= 97 && charCode <= 102;
var isPercentEncodedByte = (str, i, len) => i + 2 < len && isHexDigit(str.charCodeAt(i + 1)) && isHexDigit(str.charCodeAt(i + 2));
var hexValue = (charCode) => charCode <= 57 ? charCode - 48 : (charCode & 223) - 55;
var isBase64Char = (charCode) => charCode >= 65 && charCode <= 90 || charCode >= 97 && charCode <= 122 || charCode >= 48 && charCode <= 57 || charCode === 43 || charCode === 47 || charCode === 45 || charCode === 95;
var isBase64Whitespace = (charCode) => charCode === 9 || charCode === 10 || charCode === 12 || charCode === 13 || charCode === 32;
var base64Bytes = (significant) => {
	const groups = Math.floor(significant / 4);
	const remainder = significant % 4;
	return groups * 3 + (remainder === 2 ? 1 : remainder === 3 ? 2 : 0);
};
var estimateBase64BufferAllocation = (body) => {
	const len = body.length;
	let padding = 0;
	if (len > 0 && body.charCodeAt(len - 1) === 61) {
		padding++;
		if (len > 1 && body.charCodeAt(len - 2) === 61) padding++;
	}
	return Math.floor((len - padding) * 3 / 4);
};
var estimatePercentDecodedBase64Bytes = (body) => {
	const len = body.length;
	let significant = 0;
	let padding = 0;
	let invalid = false;
	for (let i = 0; i < len; i++) {
		let code = body.charCodeAt(i);
		if (code === 37 && isPercentEncodedByte(body, i, len)) {
			code = hexValue(body.charCodeAt(i + 1)) * 16 + hexValue(body.charCodeAt(i + 2));
			i += 2;
		}
		if (isBase64Whitespace(code)) continue;
		if (code === 61) {
			padding++;
			continue;
		}
		if (!isBase64Char(code) || padding > 0) {
			invalid = true;
			continue;
		}
		significant++;
	}
	if (invalid || padding > 2 || padding > 0 && (significant + padding) % 4 !== 0 || significant % 4 === 1) return estimateBase64BufferAllocation(body);
	return base64Bytes(significant);
};
var estimateDataURLBytes = (url, estimateBase64) => {
	if (!url || typeof url !== "string") return 0;
	if (!url.startsWith("data:")) return 0;
	const comma = url.indexOf(",");
	if (comma < 0) return 0;
	const meta = url.slice(5, comma);
	const body = url.slice(comma + 1);
	if (/;base64/i.test(meta)) return estimateBase64(body);
	let bytes = 0;
	for (let i = 0, len = body.length; i < len; i++) {
		const c = body.charCodeAt(i);
		if (c === 37 && isPercentEncodedByte(body, i, len)) {
			bytes += 1;
			i += 2;
		} else if (c < 128) bytes += 1;
		else if (c < 2048) bytes += 2;
		else if (c >= 55296 && c <= 56319 && i + 1 < len) {
			const next = body.charCodeAt(i + 1);
			if (next >= 56320 && next <= 57343) {
				bytes += 4;
				i++;
			} else bytes += 3;
		} else bytes += 3;
	}
	return bytes;
};
/**
* Estimate the percent-decoded payload size used by Fetch data: URLs.
*
* @param {string} url
* @returns {number}
*/
function estimateDataURLDecodedBytes(url) {
	const fragmentIndex = typeof url === "string" ? url.indexOf("#") : -1;
	return estimateDataURLBytes(fragmentIndex === -1 ? url : url.slice(0, fragmentIndex), estimatePercentDecodedBase64Bytes);
}
//#endregion
//#region node_modules/axios/lib/env/data.js
var VERSION$1 = "1.20.0";
//#endregion
//#region node_modules/axios/lib/adapters/fetch.js
var DEFAULT_CHUNK_SIZE = 65536;
var DEFAULT_REQUEST_OPTIONS = {
	cache: "default",
	redirect: "follow",
	referrer: "about:client",
	referrerPolicy: "",
	mode: "cors",
	integrity: "",
	keepalive: false,
	priority: "auto",
	window: null
};
var { isFunction } = utils_default;
/**
* Encode a UTF-8 string to a Latin-1 byte string for use with btoa().
* This is a modern replacement for the deprecated unescape(encodeURIComponent(str)) pattern.
*
* @param {string} str The string to encode
*
* @returns {string} UTF-8 bytes as a Latin-1 string
*/
var encodeUTF8 = (str) => encodeURIComponent(str).replace(/%([0-9A-F]{2})/gi, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
var decodeURIComponentSafe = (value) => {
	if (!utils_default.isString(value)) return value;
	try {
		return decodeURIComponent(value);
	} catch (error) {
		return value;
	}
};
var test = (fn, ...args) => {
	try {
		return !!fn(...args);
	} catch (e) {
		return false;
	}
};
var maybeWithAuthCredentials = (url) => {
	const protocolIndex = url.indexOf("://");
	let urlToCheck = url;
	if (protocolIndex !== -1) urlToCheck = urlToCheck.slice(protocolIndex + 3);
	return urlToCheck.includes("@") || urlToCheck.includes(":");
};
var factory = (env) => {
	const globalObject = utils_default.global !== void 0 && utils_default.global !== null ? utils_default.global : globalThis;
	const { ReadableStream, TextEncoder } = globalObject;
	env = utils_default.merge.call({ skipUndefined: true }, {
		Request: globalObject.Request,
		Response: globalObject.Response
	}, env);
	const { fetch: envFetch, Request, Response } = env;
	const isFetchSupported = envFetch ? isFunction(envFetch) : typeof fetch === "function";
	const isRequestSupported = isFunction(Request);
	const isResponseSupported = isFunction(Response);
	if (!isFetchSupported) return false;
	const isReadableStreamSupported = isFetchSupported && isFunction(ReadableStream);
	const encodeText = isFetchSupported && (typeof TextEncoder === "function" ? ((encoder) => (str) => encoder.encode(str))(new TextEncoder()) : async (str) => new Uint8Array(await new Request(str).arrayBuffer()));
	const supportsRequestStream = isRequestSupported && isReadableStreamSupported && test(() => {
		let duplexAccessed = false;
		const request = new Request(platform_default.origin, {
			body: new ReadableStream(),
			method: "POST",
			get duplex() {
				duplexAccessed = true;
				return "half";
			}
		});
		const hasContentType = request.headers.has("Content-Type");
		if (request.body != null) request.body.cancel();
		return duplexAccessed && !hasContentType;
	});
	const supportsResponseStream = isResponseSupported && isReadableStreamSupported && test(() => utils_default.isReadableStream(new Response("").body));
	const resolvers = { stream: supportsResponseStream && ((res) => res.body) };
	isFetchSupported && (() => {
		[
			"text",
			"arrayBuffer",
			"blob",
			"formData",
			"stream"
		].forEach((type) => {
			!resolvers[type] && (resolvers[type] = (res, config) => {
				let method = res && res[type];
				if (method) return method.call(res);
				throw new AxiosError$1(`Response type '${type}' is not supported`, AxiosError$1.ERR_NOT_SUPPORT, config);
			});
		});
	})();
	const getBodyLength = async (body) => {
		if (body == null) return 0;
		if (utils_default.isBlob(body)) return body.size;
		if (utils_default.isSpecCompliantForm(body)) return (await new Request(platform_default.origin, {
			method: "POST",
			body
		}).arrayBuffer()).byteLength;
		if (utils_default.isArrayBufferView(body) || utils_default.isArrayBuffer(body)) return body.byteLength;
		if (utils_default.isURLSearchParams(body)) body = body + "";
		if (utils_default.isString(body)) return (await encodeText(body)).byteLength;
	};
	const resolveBodyLength = async (headers, body) => {
		const length = utils_default.toFiniteNumber(headers.getContentLength());
		return length == null ? getBodyLength(body) : length;
	};
	return async (config) => {
		let { url, method, data, signal, cancelToken, timeout, onDownloadProgress, onUploadProgress, responseType, headers, withCredentials = "same-origin", fetchOptions, maxContentLength, maxBodyLength, maxRedirects } = resolveConfig(config);
		const hasMaxContentLength = utils_default.isNumber(maxContentLength) && maxContentLength > -1;
		const hasMaxBodyLength = utils_default.isNumber(maxBodyLength) && maxBodyLength > -1;
		const own = (key) => utils_default.hasOwnProp(config, key) ? config[key] : void 0;
		let _fetch = envFetch || fetch;
		responseType = responseType ? (responseType + "").toLowerCase() : "text";
		let composedSignal = composeSignals([signal, cancelToken && cancelToken.toAbortSignal()], timeout);
		let request = null;
		const unsubscribe = composedSignal && composedSignal.unsubscribe && (() => {
			composedSignal.unsubscribe();
		});
		let requestContentLength;
		let pendingBodyError = null;
		const maxBodyLengthError = () => new AxiosError$1("Request body larger than maxBodyLength limit", AxiosError$1.ERR_BAD_REQUEST, config, request);
		try {
			let auth = void 0;
			const configAuth = own("auth");
			if (configAuth) auth = {
				username: utils_default.getSafeProp(configAuth, "username") || "",
				password: utils_default.getSafeProp(configAuth, "password") || ""
			};
			if (maybeWithAuthCredentials(url)) {
				const parsedURL = new URL(url, platform_default.origin);
				if (!auth && (parsedURL.username || parsedURL.password)) auth = {
					username: decodeURIComponentSafe(parsedURL.username),
					password: decodeURIComponentSafe(parsedURL.password)
				};
				if (parsedURL.username || parsedURL.password) {
					parsedURL.username = "";
					parsedURL.password = "";
					url = parsedURL.href;
				}
			}
			if (auth) {
				headers.delete("authorization");
				headers.set("Authorization", "Basic " + btoa(encodeUTF8((auth.username || "") + ":" + (auth.password || ""))));
			}
			if (hasMaxContentLength && typeof url === "string" && url.startsWith("data:")) {
				if (estimateDataURLDecodedBytes(url) > maxContentLength) throw new AxiosError$1("maxContentLength size of " + maxContentLength + " exceeded", AxiosError$1.ERR_BAD_RESPONSE, config, request);
			}
			if (hasMaxBodyLength && method !== "get" && method !== "head") {
				const outboundLength = await getBodyLength(data);
				if (typeof outboundLength === "number" && isFinite(outboundLength)) {
					requestContentLength = outboundLength;
					if (outboundLength > maxBodyLength) throw maxBodyLengthError();
				}
			}
			const mustEnforceStreamBody = hasMaxBodyLength && (utils_default.isReadableStream(data) || utils_default.isStream(data));
			const trackRequestStream = (stream, onProgress, flush) => trackStream(stream, DEFAULT_CHUNK_SIZE, (loadedBytes) => {
				if (hasMaxBodyLength && loadedBytes > maxBodyLength) throw pendingBodyError = maxBodyLengthError();
				onProgress && onProgress(loadedBytes);
			}, flush);
			if (supportsRequestStream && method !== "get" && method !== "head" && (onUploadProgress || mustEnforceStreamBody)) {
				requestContentLength = requestContentLength == null ? await resolveBodyLength(headers, data) : requestContentLength;
				if (requestContentLength !== 0 || mustEnforceStreamBody) {
					let _request = new Request(url, {
						method: "POST",
						body: data,
						duplex: "half"
					});
					let contentTypeHeader;
					if (utils_default.isFormData(data) && (contentTypeHeader = _request.headers.get("content-type"))) headers.setContentType(contentTypeHeader);
					if (_request.body) {
						const [onProgress, flush] = onUploadProgress && progressEventDecorator(requestContentLength, progressEventReducer(asyncDecorator(onUploadProgress))) || [];
						data = trackRequestStream(_request.body, onProgress, flush);
					}
				}
			} else if (mustEnforceStreamBody && !isRequestSupported && isReadableStreamSupported && method !== "get" && method !== "head") data = trackRequestStream(data);
			else if (mustEnforceStreamBody && isRequestSupported && !supportsRequestStream && method !== "get" && method !== "head") throw new AxiosError$1("Stream request bodies are not supported by the current fetch implementation", AxiosError$1.ERR_NOT_SUPPORT, config, request);
			if (!utils_default.isString(withCredentials)) withCredentials = withCredentials ? "include" : "omit";
			const isCredentialsSupported = isRequestSupported && "credentials" in Request.prototype;
			if (utils_default.isFormData(data)) {
				const contentType = headers.getContentType();
				if (contentType && /^multipart\/form-data/i.test(contentType) && !/boundary=/i.test(contentType)) headers.delete("content-type");
			}
			headers.set("User-Agent", "axios/" + VERSION$1, false);
			const safeFetchOptions = fetchOptions == null ? fetchOptions : Object.assign(Object.create(null), fetchOptions);
			if (safeFetchOptions) {
				delete safeFetchOptions.body;
				delete safeFetchOptions.headers;
				delete safeFetchOptions.method;
				delete safeFetchOptions.signal;
				delete safeFetchOptions.duplex;
				delete safeFetchOptions.credentials;
			}
			const resolvedOptions = Object.assign(Object.create(null), safeFetchOptions, {
				signal: composedSignal,
				method: method.toUpperCase(),
				headers: toByteStringHeaderObject(headers.normalize()),
				body: data,
				duplex: "half",
				credentials: isCredentialsSupported ? withCredentials : void 0
			});
			if (isRequestSupported) {
				utils_default.forEach(DEFAULT_REQUEST_OPTIONS, (value, key) => {
					if (resolvedOptions[key] === void 0) resolvedOptions[key] = value;
				});
				if (resolvedOptions.signal === void 0) resolvedOptions.signal = null;
				if (resolvedOptions.body === void 0) resolvedOptions.body = null;
			}
			if (maxRedirects === 0) {
				resolvedOptions.redirect = "manual";
				if (safeFetchOptions) safeFetchOptions.redirect = "manual";
			}
			request = isRequestSupported && new Request(url, resolvedOptions);
			let response = await (isRequestSupported ? _fetch(request, safeFetchOptions) : _fetch(url, resolvedOptions));
			const responseHeaders = AxiosHeaders$1.from(response.headers);
			if (hasMaxContentLength) {
				const declaredLength = utils_default.toFiniteNumber(responseHeaders.getContentLength());
				if (declaredLength != null && declaredLength > maxContentLength) throw new AxiosError$1("maxContentLength size of " + maxContentLength + " exceeded", AxiosError$1.ERR_BAD_RESPONSE, config, request);
			}
			const isStreamResponse = supportsResponseStream && (responseType === "stream" || responseType === "response");
			if (supportsResponseStream && response.body && (onDownloadProgress || hasMaxContentLength || isStreamResponse && unsubscribe)) {
				const options = {};
				[
					"status",
					"statusText",
					"headers"
				].forEach((prop) => {
					options[prop] = response[prop];
				});
				const responseContentLength = utils_default.toFiniteNumber(responseHeaders.getContentLength());
				const [onProgress, flush] = onDownloadProgress && progressEventDecorator(responseContentLength, progressEventReducer(asyncDecorator(onDownloadProgress), true)) || [];
				let bytesRead = 0;
				const onChunkProgress = (loadedBytes) => {
					if (hasMaxContentLength) {
						bytesRead = loadedBytes;
						if (bytesRead > maxContentLength) throw new AxiosError$1("maxContentLength size of " + maxContentLength + " exceeded", AxiosError$1.ERR_BAD_RESPONSE, config, request);
					}
					onProgress && onProgress(loadedBytes);
				};
				response = new Response(trackStream(response.body, DEFAULT_CHUNK_SIZE, onChunkProgress, () => {
					flush && flush();
					unsubscribe && unsubscribe();
				}), options);
			}
			responseType = responseType || "text";
			let responseData = await resolvers[utils_default.findKey(resolvers, responseType) || "text"](response, config);
			if (hasMaxContentLength && !supportsResponseStream && !isStreamResponse) {
				let materializedSize;
				if (responseData != null) {
					if (typeof responseData.byteLength === "number") materializedSize = responseData.byteLength;
					else if (typeof responseData.size === "number") materializedSize = responseData.size;
					else if (typeof responseData === "string") materializedSize = typeof TextEncoder === "function" ? new TextEncoder().encode(responseData).byteLength : responseData.length;
				}
				if (typeof materializedSize === "number" && materializedSize > maxContentLength) throw new AxiosError$1("maxContentLength size of " + maxContentLength + " exceeded", AxiosError$1.ERR_BAD_RESPONSE, config, request);
			}
			!isStreamResponse && unsubscribe && unsubscribe();
			return await new Promise((resolve, reject) => {
				settle(resolve, reject, {
					data: responseData,
					headers: AxiosHeaders$1.from(response.headers),
					status: response.status,
					statusText: response.statusText,
					config,
					request
				});
			});
		} catch (err) {
			unsubscribe && unsubscribe();
			if (composedSignal && composedSignal.aborted && composedSignal.reason instanceof AxiosError$1) {
				const canceledError = composedSignal.reason;
				canceledError.config = config;
				request && (canceledError.request = request);
				if (err !== canceledError) Object.defineProperty(canceledError, "cause", {
					__proto__: null,
					value: err,
					writable: true,
					enumerable: false,
					configurable: true
				});
				throw canceledError;
			}
			if (pendingBodyError) {
				request && !pendingBodyError.request && (pendingBodyError.request = request);
				throw pendingBodyError;
			}
			if (err instanceof AxiosError$1) {
				request && !err.request && (err.request = request);
				throw err;
			}
			if (err && err.name === "TypeError" && /Load failed|fetch/i.test(err.message)) {
				const networkError = new AxiosError$1("Network Error", AxiosError$1.ERR_NETWORK, config, request, err && err.response);
				Object.defineProperty(networkError, "cause", {
					__proto__: null,
					value: err.cause || err,
					writable: true,
					enumerable: false,
					configurable: true
				});
				throw networkError;
			}
			throw AxiosError$1.from(err, err && err.code, config, request, err && err.response);
		}
	};
};
var seedCache = /* @__PURE__ */ new Map();
var getFetch = (config) => {
	let env = config && config.env || {};
	const { fetch, Request, Response } = env;
	const seeds = [
		Request,
		Response,
		fetch
	];
	let i = seeds.length, seed, target, map = seedCache;
	while (i--) {
		seed = seeds[i];
		target = map.get(seed);
		target === void 0 && map.set(seed, target = i ? /* @__PURE__ */ new Map() : factory(env));
		map = target;
	}
	return target;
};
getFetch();
//#endregion
//#region node_modules/axios/lib/adapters/adapters.js
/**
* Known adapters mapping.
* Provides environment-specific adapters for Axios:
* - `http` for Node.js
* - `xhr` for browsers
* - `fetch` for fetch API-based requests
*
* @type {Object<string, Function|Object>}
*/
var knownAdapters = {
	http: null,
	xhr: xhr_default,
	fetch: { get: getFetch }
};
utils_default.forEach(knownAdapters, (fn, value) => {
	if (fn) {
		try {
			Object.defineProperty(fn, "name", {
				__proto__: null,
				value
			});
		} catch (e) {}
		Object.defineProperty(fn, "adapterName", {
			__proto__: null,
			value
		});
	}
});
/**
* Render a rejection reason string for unknown or unsupported adapters
*
* @param {string} reason
* @returns {string}
*/
var renderReason = (reason) => `- ${reason}`;
/**
* Check if the adapter is resolved (function, null, or false)
*
* @param {Function|null|false} adapter
* @returns {boolean}
*/
var isResolvedHandle = (adapter) => utils_default.isFunction(adapter) || adapter === null || adapter === false;
/**
* Get the first suitable adapter from the provided list.
* Tries each adapter in order until a supported one is found.
* Throws an AxiosError if no adapter is suitable.
*
* @param {Array<string|Function>|string|Function} adapters - Adapter(s) by name or function.
* @param {Object} config - Axios request configuration
* @throws {AxiosError} If no suitable adapter is available
* @returns {Function} The resolved adapter function
*/
function getAdapter$1(adapters, config) {
	adapters = utils_default.isArray(adapters) ? adapters : [adapters];
	const { length } = adapters;
	let nameOrAdapter;
	let adapter;
	const rejectedReasons = {};
	for (let i = 0; i < length; i++) {
		nameOrAdapter = adapters[i];
		let id;
		adapter = nameOrAdapter;
		if (!isResolvedHandle(nameOrAdapter)) {
			adapter = knownAdapters[(id = String(nameOrAdapter)).toLowerCase()];
			if (adapter === void 0) throw new AxiosError$1(`Unknown adapter '${id}'`);
		}
		if (adapter && (utils_default.isFunction(adapter) || (adapter = adapter.get(config)))) break;
		rejectedReasons[id || "#" + i] = adapter;
	}
	if (!adapter) {
		const reasons = Object.entries(rejectedReasons).map(([id, state]) => `adapter ${id} ` + (state === false ? "is not supported by the environment" : "is not available in the build"));
		throw new AxiosError$1(`There is no suitable adapter to dispatch the request ` + (length ? reasons.length > 1 ? "since :\n" + reasons.map(renderReason).join("\n") : " " + renderReason(reasons[0]) : "as no adapter specified"), AxiosError$1.ERR_NOT_SUPPORT);
	}
	return adapter;
}
/**
* Exports Axios adapters and utility to resolve an adapter
*/
var adapters_default = {
	/**
	* Resolve an adapter from a list of adapter names or functions.
	* @type {Function}
	*/
	getAdapter: getAdapter$1,
	/**
	* Exposes all known adapters
	* @type {Object<string, Function|Object>}
	*/
	adapters: knownAdapters
};
//#endregion
//#region node_modules/axios/lib/core/dispatchRequest.js
/**
* Throws a `CanceledError` if cancellation has been requested.
*
* @param {Object} config The config that is to be used for the request
*
* @returns {void}
*/
function throwIfCancellationRequested(config) {
	if (config.cancelToken) config.cancelToken.throwIfRequested();
	if (config.signal && config.signal.aborted) throw new CanceledError$1(null, config);
}
/**
* Dispatch a request to the server using the configured adapter.
*
* @param {object} config The config that is to be used for the request
*
* @returns {Promise} The Promise to be fulfilled
*/
function dispatchRequest(_config) {
	const config = utils_default.toSafeFlatObject(_config);
	throwIfCancellationRequested(config);
	config.headers = AxiosHeaders$1.from(utils_default.getSafeProp(config, "headers"));
	config.data = transformData.call(config, config.transformRequest);
	if ([
		"post",
		"put",
		"patch"
	].indexOf(config.method) !== -1) config.headers.setContentType("application/x-www-form-urlencoded", false);
	return adapters_default.getAdapter(config.adapter || defaults.adapter, config)(config).then(function onAdapterResolution(response) {
		throwIfCancellationRequested(config);
		config.response = response;
		try {
			response.data = transformData.call(config, config.transformResponse, response);
		} finally {
			delete config.response;
		}
		response.headers = AxiosHeaders$1.from(response.headers);
		return response;
	}, function onAdapterRejection(reason) {
		if (!isCancel$1(reason)) {
			throwIfCancellationRequested(config);
			if (reason && reason.response) {
				config.response = reason.response;
				try {
					reason.response.data = transformData.call(config, config.transformResponse, reason.response);
				} finally {
					delete config.response;
				}
				reason.response.headers = AxiosHeaders$1.from(reason.response.headers);
			}
		}
		return Promise.reject(reason);
	});
}
//#endregion
//#region node_modules/axios/lib/helpers/validator.js
var validators$1 = {};
[
	"object",
	"boolean",
	"number",
	"function",
	"string",
	"symbol"
].forEach((type, i) => {
	validators$1[type] = function validator(thing) {
		return typeof thing === type || "a" + (i < 1 ? "n " : " ") + type;
	};
});
var deprecatedWarnings = {};
/**
* Transitional option validator
*
* @param {function|boolean?} validator - set to false if the transitional option has been removed
* @param {string?} version - deprecated version / removed since version
* @param {string?} message - some message with additional info
*
* @returns {function}
*/
validators$1.transitional = function transitional(validator, version, message) {
	function formatMessage(opt, desc) {
		return "[Axios v" + VERSION$1 + "] Transitional option '" + opt + "'" + desc + (message ? ". " + message : "");
	}
	return (value, opt, opts) => {
		if (validator === false) throw new AxiosError$1(formatMessage(opt, " has been removed" + (version ? " in " + version : "")), AxiosError$1.ERR_DEPRECATED);
		if (version && !deprecatedWarnings[opt]) {
			deprecatedWarnings[opt] = true;
			console.warn(formatMessage(opt, " has been deprecated since v" + version + " and will be removed in the near future"));
		}
		return validator ? validator(value, opt, opts) : true;
	};
};
validators$1.spelling = function spelling(correctSpelling) {
	return (value, opt) => {
		console.warn(`${opt} is likely a misspelling of ${correctSpelling}`);
		return true;
	};
};
/**
* Assert object's properties type
*
* @param {object} options
* @param {object} schema
* @param {boolean?} allowUnknown
*
* @returns {object}
*/
function assertOptions(options, schema, allowUnknown) {
	if (typeof options !== "object" || options === null) throw new AxiosError$1("options must be an object", AxiosError$1.ERR_BAD_OPTION_VALUE);
	const keys = Object.keys(options);
	let i = keys.length;
	while (i-- > 0) {
		const opt = keys[i];
		const validator = Object.prototype.hasOwnProperty.call(schema, opt) ? schema[opt] : void 0;
		if (validator) {
			const value = options[opt];
			const result = value === void 0 || validator(value, opt, options);
			if (result !== true) throw new AxiosError$1("option " + opt + " must be " + result, AxiosError$1.ERR_BAD_OPTION_VALUE);
			continue;
		}
		if (allowUnknown !== true) throw new AxiosError$1("Unknown option " + opt, AxiosError$1.ERR_BAD_OPTION);
	}
}
var validator_default = {
	assertOptions,
	validators: validators$1
};
//#endregion
//#region node_modules/axios/lib/core/Axios.js
var validators = validator_default.validators;
/**
* Create a new instance of Axios
*
* @param {Object} instanceConfig The default config for the instance
*
* @return {Axios} A new instance of Axios
*/
var Axios$1 = class {
	constructor(instanceConfig) {
		this.defaults = instanceConfig || {};
		this.interceptors = {
			request: new InterceptorManager(),
			response: new InterceptorManager()
		};
	}
	/**
	* Dispatch a request
	*
	* @param {String|Object} configOrUrl The config specific for this request (merged with this.defaults)
	* @param {?Object} config
	*
	* @returns {Promise} The Promise to be fulfilled
	*/
	async request(configOrUrl, config) {
		try {
			return await this._request(configOrUrl, config);
		} catch (err) {
			if (err instanceof Error) try {
				let dummy = {};
				Error.captureStackTrace ? Error.captureStackTrace(dummy) : dummy = /* @__PURE__ */ new Error();
				const dummyStack = dummy.stack;
				let stack = "";
				if (typeof dummyStack === "string") {
					const firstNewlineIndex = dummyStack.indexOf("\n");
					stack = firstNewlineIndex === -1 ? "" : dummyStack.slice(firstNewlineIndex + 1);
				}
				if (!err.stack) err.stack = stack;
				else if (stack) {
					const firstNewlineIndex = stack.indexOf("\n");
					const secondNewlineIndex = firstNewlineIndex === -1 ? -1 : stack.indexOf("\n", firstNewlineIndex + 1);
					const stackWithoutTwoTopLines = secondNewlineIndex === -1 ? "" : stack.slice(secondNewlineIndex + 1);
					if (!String(err.stack).endsWith(stackWithoutTwoTopLines)) err.stack += "\n" + stack;
				}
			} catch (e) {}
			throw err;
		}
	}
	_request(configOrUrl, config) {
		if (typeof configOrUrl === "string") {
			config = config || {};
			config.url = configOrUrl;
		} else config = configOrUrl || {};
		config = mergeConfig$1(this.defaults, config);
		const { transitional, paramsSerializer, headers } = config;
		if (transitional !== void 0) validator_default.assertOptions(transitional, {
			silentJSONParsing: validators.transitional(validators.boolean),
			forcedJSONParsing: validators.transitional(validators.boolean),
			clarifyTimeoutError: validators.transitional(validators.boolean),
			legacyInterceptorReqResOrdering: validators.transitional(validators.boolean),
			advertiseZstdAcceptEncoding: validators.transitional(validators.boolean),
			validateStatusUndefinedResolves: validators.transitional(validators.boolean)
		}, false);
		if (paramsSerializer != null) {
			if (utils_default.isFunction(paramsSerializer)) config.paramsSerializer = { serialize: paramsSerializer };
			else validator_default.assertOptions(paramsSerializer, {
				encode: validators.function,
				serialize: validators.function
			}, true);
		}
		if (config.allowAbsoluteUrls !== void 0) {} else if (this.defaults.allowAbsoluteUrls !== void 0) config.allowAbsoluteUrls = this.defaults.allowAbsoluteUrls;
		else config.allowAbsoluteUrls = true;
		validator_default.assertOptions(config, {
			baseUrl: validators.spelling("baseURL"),
			withXsrfToken: validators.spelling("withXSRFToken")
		}, true);
		config.method = (utils_default.getSafeProp(config, "method") || utils_default.getSafeProp(this.defaults, "method") || "get").toLowerCase();
		let contextHeaders = headers && utils_default.merge(headers.common, headers[config.method]);
		headers && utils_default.forEach(methodList.concat("common"), (method) => {
			delete headers[method];
		});
		config.headers = AxiosHeaders$1.concat(contextHeaders, headers);
		const requestInterceptorChain = [];
		let synchronousRequestInterceptors = true;
		this.interceptors.request.forEach(function unshiftRequestInterceptors(interceptor) {
			if (typeof interceptor.runWhen === "function" && interceptor.runWhen(config) === false) return;
			synchronousRequestInterceptors = synchronousRequestInterceptors && interceptor.synchronous;
			const transitional = config.transitional || transitional_default;
			if (transitional && transitional.legacyInterceptorReqResOrdering) requestInterceptorChain.unshift(interceptor.fulfilled, interceptor.rejected);
			else requestInterceptorChain.push(interceptor.fulfilled, interceptor.rejected);
		});
		const responseInterceptorChain = [];
		this.interceptors.response.forEach(function pushResponseInterceptors(interceptor) {
			responseInterceptorChain.push(interceptor.fulfilled, interceptor.rejected);
		});
		let promise;
		let i = 0;
		let len;
		if (!synchronousRequestInterceptors) {
			const chain = [dispatchRequest.bind(this), void 0];
			chain.unshift(...requestInterceptorChain);
			chain.push(...responseInterceptorChain);
			len = chain.length;
			promise = Promise.resolve(config);
			while (i < len) promise = promise.then(chain[i++], chain[i++]);
			return promise;
		}
		len = requestInterceptorChain.length;
		let newConfig = config;
		while (i < len) {
			const onFulfilled = requestInterceptorChain[i++];
			const onRejected = requestInterceptorChain[i++];
			try {
				newConfig = onFulfilled ? onFulfilled(newConfig) : newConfig;
			} catch (error) {
				if (!onRejected) {
					promise = Promise.reject(error);
					break;
				}
				try {
					const rejectedResult = onRejected.call(this, error);
					if (utils_default.isThenable(rejectedResult)) promise = Promise.resolve(rejectedResult).then(() => dispatchRequest.call(this, newConfig));
				} catch (rejectedError) {
					promise = Promise.reject(rejectedError);
				}
				break;
			}
		}
		if (!promise) try {
			promise = dispatchRequest.call(this, newConfig);
		} catch (error) {
			promise = Promise.reject(error);
		}
		i = 0;
		len = responseInterceptorChain.length;
		while (i < len) promise = promise.then(responseInterceptorChain[i++], responseInterceptorChain[i++]);
		return promise;
	}
	getUri(config) {
		config = mergeConfig$1(this.defaults, config);
		return buildURL(buildFullPath(config.baseURL, config.url, config.allowAbsoluteUrls, config), config.params, config.paramsSerializer);
	}
};
utils_default.forEach([
	"delete",
	"get",
	"head",
	"options"
], function forEachMethodNoData(method) {
	Axios$1.prototype[method] = function(url, config) {
		return this.request(mergeConfig$1(config || {}, {
			method,
			url,
			data: config && utils_default.hasOwnProp(config, "data") ? config.data : void 0
		}));
	};
});
utils_default.forEach([
	"post",
	"put",
	"patch",
	"query"
], function forEachMethodWithData(method) {
	function generateHTTPMethod(isForm) {
		return function httpMethod(url, data, config) {
			return this.request(mergeConfig$1(config || {}, {
				method,
				headers: isForm ? { "Content-Type": "multipart/form-data" } : {},
				url,
				data
			}));
		};
	}
	Axios$1.prototype[method] = generateHTTPMethod();
	if (method !== "query") Axios$1.prototype[method + "Form"] = generateHTTPMethod(true);
});
//#endregion
//#region node_modules/axios/lib/cancel/CancelToken.js
/**
* A `CancelToken` is an object that can be used to request cancellation of an operation.
*
* @param {Function} executor The executor function.
*
* @returns {CancelToken}
*/
var CancelToken$1 = class CancelToken$1 {
	constructor(executor) {
		if (typeof executor !== "function") throw new TypeError("executor must be a function.");
		let resolvePromise;
		this.promise = new Promise(function promiseExecutor(resolve) {
			resolvePromise = resolve;
		});
		const token = this;
		this.promise.then((cancel) => {
			if (!token._listeners) return;
			let i = token._listeners.length;
			while (i-- > 0) token._listeners[i](cancel);
			token._listeners = null;
		});
		this.promise.then = (onfulfilled) => {
			let _resolve;
			const promise = new Promise((resolve) => {
				token.subscribe(resolve);
				_resolve = resolve;
			}).then(onfulfilled);
			promise.cancel = function reject() {
				token.unsubscribe(_resolve);
			};
			return promise;
		};
		executor(function cancel(message, config, request) {
			if (token.reason) return;
			token.reason = new CanceledError$1(message, config, request);
			resolvePromise(token.reason);
		});
	}
	/**
	* Throws a `CanceledError` if cancellation has been requested.
	*/
	throwIfRequested() {
		if (this.reason) throw this.reason;
	}
	/**
	* Subscribe to the cancel signal
	*/
	subscribe(listener) {
		if (this.reason) {
			listener(this.reason);
			return;
		}
		if (this._listeners) this._listeners.push(listener);
		else this._listeners = [listener];
	}
	/**
	* Unsubscribe from the cancel signal
	*/
	unsubscribe(listener) {
		if (!this._listeners) return;
		const index = this._listeners.indexOf(listener);
		if (index !== -1) this._listeners.splice(index, 1);
	}
	toAbortSignal() {
		const controller = new AbortController();
		const abort = (err) => {
			controller.abort(err);
		};
		this.subscribe(abort);
		controller.signal.unsubscribe = () => this.unsubscribe(abort);
		return controller.signal;
	}
	/**
	* Returns an object that contains a new `CancelToken` and a function that, when called,
	* cancels the `CancelToken`.
	*/
	static source() {
		let cancel;
		return {
			token: new CancelToken$1(function executor(c) {
				cancel = c;
			}),
			cancel
		};
	}
};
//#endregion
//#region node_modules/axios/lib/helpers/spread.js
/**
* Syntactic sugar for invoking a function and expanding an array for arguments.
*
* Common use case would be to use `Function.prototype.apply`.
*
*  ```js
*  function f(x, y, z) {}
*  const args = [1, 2, 3];
*  f.apply(null, args);
*  ```
*
* With `spread` this example can be re-written.
*
*  ```js
*  spread(function(x, y, z) {})([1, 2, 3]);
*  ```
*
* @param {Function} callback
*
* @returns {Function}
*/
function spread$1(callback) {
	return function wrap(arr) {
		return callback.apply(null, arr);
	};
}
//#endregion
//#region node_modules/axios/lib/helpers/isAxiosError.js
/**
* Determines whether the payload is an error thrown by Axios
*
* @param {*} payload The value to test
*
* @returns {boolean} True if the payload is an error thrown by Axios, otherwise false
*/
function isAxiosError$1(payload) {
	return utils_default.isObject(payload) && payload.isAxiosError === true;
}
//#endregion
//#region node_modules/axios/lib/helpers/HttpStatusCode.js
var HttpStatusCode$1 = {
	Continue: 100,
	SwitchingProtocols: 101,
	Processing: 102,
	EarlyHints: 103,
	Ok: 200,
	Created: 201,
	Accepted: 202,
	NonAuthoritativeInformation: 203,
	NoContent: 204,
	ResetContent: 205,
	PartialContent: 206,
	MultiStatus: 207,
	AlreadyReported: 208,
	ImUsed: 226,
	MultipleChoices: 300,
	MovedPermanently: 301,
	Found: 302,
	SeeOther: 303,
	NotModified: 304,
	UseProxy: 305,
	Unused: 306,
	TemporaryRedirect: 307,
	PermanentRedirect: 308,
	BadRequest: 400,
	Unauthorized: 401,
	PaymentRequired: 402,
	Forbidden: 403,
	NotFound: 404,
	MethodNotAllowed: 405,
	NotAcceptable: 406,
	ProxyAuthenticationRequired: 407,
	RequestTimeout: 408,
	Conflict: 409,
	Gone: 410,
	LengthRequired: 411,
	PreconditionFailed: 412,
	/**
	* @deprecated Use `ContentTooLarge` instead.
	*/
	PayloadTooLarge: 413,
	ContentTooLarge: 413,
	UriTooLong: 414,
	UnsupportedMediaType: 415,
	RangeNotSatisfiable: 416,
	ExpectationFailed: 417,
	ImATeapot: 418,
	MisdirectedRequest: 421,
	/**
	* @deprecated Use `UnprocessableContent` instead.
	*/
	UnprocessableEntity: 422,
	UnprocessableContent: 422,
	Locked: 423,
	FailedDependency: 424,
	TooEarly: 425,
	UpgradeRequired: 426,
	PreconditionRequired: 428,
	TooManyRequests: 429,
	RequestHeaderFieldsTooLarge: 431,
	UnavailableForLegalReasons: 451,
	InternalServerError: 500,
	NotImplemented: 501,
	BadGateway: 502,
	ServiceUnavailable: 503,
	GatewayTimeout: 504,
	HttpVersionNotSupported: 505,
	VariantAlsoNegotiates: 506,
	InsufficientStorage: 507,
	LoopDetected: 508,
	NotExtended: 510,
	NetworkAuthenticationRequired: 511,
	WebServerReturnsAnUnknownError: 520,
	WebServerIsDown: 521,
	ConnectionTimedOut: 522,
	OriginIsUnreachable: 523,
	TimeoutOccurred: 524,
	SslHandshakeFailed: 525,
	InvalidSslCertificate: 526
};
Object.entries(HttpStatusCode$1).forEach(([key, value]) => {
	if (HttpStatusCode$1[value] === void 0) HttpStatusCode$1[value] = key;
});
//#endregion
//#region node_modules/axios/lib/axios.js
/**
* Create an instance of Axios
*
* @param {Object} defaultConfig The default config for the instance
*
* @returns {Axios} A new instance of Axios
*/
function createInstance(defaultConfig) {
	const context = new Axios$1(defaultConfig);
	const instance = bind(Axios$1.prototype.request, context);
	utils_default.extend(instance, Axios$1.prototype, context, { allOwnKeys: true });
	utils_default.extend(instance, context, null, { allOwnKeys: true });
	instance.create = function create(instanceConfig) {
		return createInstance(mergeConfig$1(defaultConfig, instanceConfig));
	};
	return instance;
}
var axios = createInstance(defaults);
axios.Axios = Axios$1;
axios.CanceledError = CanceledError$1;
axios.CancelToken = CancelToken$1;
axios.isCancel = isCancel$1;
axios.VERSION = VERSION$1;
axios.toFormData = toFormData$1;
axios.AxiosError = AxiosError$1;
axios.Cancel = axios.CanceledError;
axios.all = function all(promises) {
	return Promise.all(promises);
};
axios.spread = spread$1;
axios.isAxiosError = isAxiosError$1;
axios.mergeConfig = mergeConfig$1;
axios.AxiosHeaders = AxiosHeaders$1;
axios.formToJSON = (thing) => formDataToJSON(utils_default.isHTMLForm(thing) ? new FormData(thing) : thing);
axios.getAdapter = adapters_default.getAdapter;
axios.HttpStatusCode = HttpStatusCode$1;
axios.default = axios;
//#endregion
//#region node_modules/axios/index.js
var { Axios, AxiosError, CanceledError, isCancel, CancelToken, VERSION, all, Cancel, isAxiosError, spread, toFormData, AxiosHeaders, HttpStatusCode, formToJSON, getAdapter, mergeConfig, create } = axios;
//#endregion
export { Axios, AxiosError, AxiosHeaders, Cancel, CancelToken, CanceledError, HttpStatusCode, VERSION, all, create, axios as default, formToJSON, getAdapter, isAxiosError, isCancel, mergeConfig, spread, toFormData };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXhpb3MuanMiLCJuYW1lcyI6WyJpc0Z1bmN0aW9uIiwidXRpbHMiLCJ1dGlscyIsIiRpbnRlcm5hbHMiLCJ1dGlscyIsIkF4aW9zSGVhZGVycyIsInBhcnNlSGVhZGVycyIsInV0aWxzIiwiQXhpb3NIZWFkZXJzIiwic3RyaW5naWZ5U2FmZWx5IiwiQXhpb3NFcnJvciIsInV0aWxzIiwidG9Gb3JtRGF0YSIsIkF4aW9zRXJyb3IiLCJlbmNvZGUiLCJ0b0Zvcm1EYXRhIiwidXRpbHMiLCJ1dGlscyIsInBsYXRmb3JtIiwidG9Gb3JtRGF0YSIsInBsYXRmb3JtIiwidXRpbHMiLCJBeGlvc0Vycm9yIiwidXRpbHMiLCJ1dGlscyIsInRyYW5zaXRpb25hbERlZmF1bHRzIiwidG9Gb3JtRGF0YSIsIkF4aW9zRXJyb3IiLCJwbGF0Zm9ybSIsIkF4aW9zSGVhZGVycyIsImlzQ2FuY2VsIiwiQ2FuY2VsZWRFcnJvciIsIkF4aW9zRXJyb3IiLCJBeGlvc0Vycm9yIiwidXRpbHMiLCJwbGF0Zm9ybSIsInBsYXRmb3JtIiwidXRpbHMiLCJBeGlvc0Vycm9yIiwiQXhpb3NIZWFkZXJzIiwibWVyZ2VDb25maWciLCJ1dGlscyIsImVuY29kZVVURjgiLCJtZXJnZUNvbmZpZyIsInV0aWxzIiwiQXhpb3NIZWFkZXJzIiwiQXhpb3NFcnJvciIsInBsYXRmb3JtIiwiaXNVUkxTYW1lT3JpZ2luIiwiY29va2llcyIsIkF4aW9zSGVhZGVycyIsInBsYXRmb3JtIiwiQXhpb3NFcnJvciIsInRyYW5zaXRpb25hbERlZmF1bHRzIiwidXRpbHMiLCJDYW5jZWxlZEVycm9yIiwiQXhpb3NFcnJvciIsIkNhbmNlbGVkRXJyb3IiLCJ1dGlscyIsIlZFUlNJT04iLCJ1dGlscyIsInBsYXRmb3JtIiwiQXhpb3NFcnJvciIsIlZFUlNJT04iLCJBeGlvc0hlYWRlcnMiLCJ4aHJBZGFwdGVyIiwiZmV0Y2hBZGFwdGVyLmdldEZldGNoIiwidXRpbHMiLCJnZXRBZGFwdGVyIiwiQXhpb3NFcnJvciIsIkNhbmNlbGVkRXJyb3IiLCJ1dGlscyIsIkF4aW9zSGVhZGVycyIsImFkYXB0ZXJzIiwiaXNDYW5jZWwiLCJ2YWxpZGF0b3JzIiwiVkVSU0lPTiIsIkF4aW9zRXJyb3IiLCJ2YWxpZGF0b3IiLCJBeGlvcyIsIm1lcmdlQ29uZmlnIiwidXRpbHMiLCJBeGlvc0hlYWRlcnMiLCJ0cmFuc2l0aW9uYWxEZWZhdWx0cyIsIkNhbmNlbFRva2VuIiwiQ2FuY2VsZWRFcnJvciIsInNwcmVhZCIsImlzQXhpb3NFcnJvciIsInV0aWxzIiwiSHR0cFN0YXR1c0NvZGUiLCJBeGlvcyIsIm1lcmdlQ29uZmlnIiwiQ2FuY2VsZWRFcnJvciIsIkNhbmNlbFRva2VuIiwiaXNDYW5jZWwiLCJWRVJTSU9OIiwidG9Gb3JtRGF0YSIsIkF4aW9zRXJyb3IiLCJzcHJlYWQiLCJpc0F4aW9zRXJyb3IiLCJBeGlvc0hlYWRlcnMiLCJ1dGlscyIsImFkYXB0ZXJzIiwiSHR0cFN0YXR1c0NvZGUiXSwic291cmNlcyI6WyIuLi8uLi9heGlvcy9saWIvaGVscGVycy9iaW5kLmpzIiwiLi4vLi4vYXhpb3MvbGliL3V0aWxzLmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvcGFyc2VIZWFkZXJzLmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvc2FuaXRpemVIZWFkZXJWYWx1ZS5qcyIsIi4uLy4uL2F4aW9zL2xpYi9jb3JlL0F4aW9zSGVhZGVycy5qcyIsIi4uLy4uL2F4aW9zL2xpYi9jb3JlL0F4aW9zRXJyb3IuanMiLCIuLi8uLi9heGlvcy9saWIvaGVscGVycy90b0Zvcm1EYXRhLmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvQXhpb3NVUkxTZWFyY2hQYXJhbXMuanMiLCIuLi8uLi9heGlvcy9saWIvaGVscGVycy9idWlsZFVSTC5qcyIsIi4uLy4uL2F4aW9zL2xpYi9jb3JlL0ludGVyY2VwdG9yTWFuYWdlci5qcyIsIi4uLy4uL2F4aW9zL2xpYi9kZWZhdWx0cy90cmFuc2l0aW9uYWwuanMiLCIuLi8uLi9heGlvcy9saWIvcGxhdGZvcm0vYnJvd3Nlci9jbGFzc2VzL1VSTFNlYXJjaFBhcmFtcy5qcyIsIi4uLy4uL2F4aW9zL2xpYi9wbGF0Zm9ybS9icm93c2VyL2NsYXNzZXMvRm9ybURhdGEuanMiLCIuLi8uLi9heGlvcy9saWIvcGxhdGZvcm0vYnJvd3Nlci9jbGFzc2VzL0Jsb2IuanMiLCIuLi8uLi9heGlvcy9saWIvcGxhdGZvcm0vYnJvd3Nlci9pbmRleC5qcyIsIi4uLy4uL2F4aW9zL2xpYi9wbGF0Zm9ybS9jb21tb24vdXRpbHMuanMiLCIuLi8uLi9heGlvcy9saWIvcGxhdGZvcm0vaW5kZXguanMiLCIuLi8uLi9heGlvcy9saWIvaGVscGVycy90b1VSTEVuY29kZWRGb3JtLmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvZm9ybURhdGFUb0pTT04uanMiLCIuLi8uLi9heGlvcy9saWIvY29yZS9tZXRob2RMaXN0LmpzIiwiLi4vLi4vYXhpb3MvbGliL2RlZmF1bHRzL2luZGV4LmpzIiwiLi4vLi4vYXhpb3MvbGliL2NvcmUvdHJhbnNmb3JtRGF0YS5qcyIsIi4uLy4uL2F4aW9zL2xpYi9jYW5jZWwvaXNDYW5jZWwuanMiLCIuLi8uLi9heGlvcy9saWIvY2FuY2VsL0NhbmNlbGVkRXJyb3IuanMiLCIuLi8uLi9heGlvcy9saWIvY29yZS9zZXR0bGUuanMiLCIuLi8uLi9heGlvcy9saWIvaGVscGVycy9ub3JtYWxpemVVUkxGb3JQcm90b2NvbENoZWNrLmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvcGFyc2VQcm90b2NvbC5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL3NwZWVkb21ldGVyLmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvdGhyb3R0bGUuanMiLCIuLi8uLi9heGlvcy9saWIvaGVscGVycy9wcm9ncmVzc0V2ZW50UmVkdWNlci5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL2lzVVJMU2FtZU9yaWdpbi5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL2Nvb2tpZXMuanMiLCIuLi8uLi9heGlvcy9saWIvaGVscGVycy9pc0Fic29sdXRlVVJMLmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvY29tYmluZVVSTHMuanMiLCIuLi8uLi9heGlvcy9saWIvY29yZS9idWlsZEZ1bGxQYXRoLmpzIiwiLi4vLi4vYXhpb3MvbGliL2NvcmUvbWVyZ2VDb25maWcuanMiLCIuLi8uLi9heGlvcy9saWIvY29yZS9zZXRGb3JtRGF0YUhlYWRlcnMuanMiLCIuLi8uLi9heGlvcy9saWIvaGVscGVycy9yZXNvbHZlQ29uZmlnLmpzIiwiLi4vLi4vYXhpb3MvbGliL2FkYXB0ZXJzL3hoci5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL2NvbXBvc2VTaWduYWxzLmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvdHJhY2tTdHJlYW0uanMiLCIuLi8uLi9heGlvcy9saWIvaGVscGVycy9lc3RpbWF0ZURhdGFVUkxEZWNvZGVkQnl0ZXMuanMiLCIuLi8uLi9heGlvcy9saWIvZW52L2RhdGEuanMiLCIuLi8uLi9heGlvcy9saWIvYWRhcHRlcnMvZmV0Y2guanMiLCIuLi8uLi9heGlvcy9saWIvYWRhcHRlcnMvYWRhcHRlcnMuanMiLCIuLi8uLi9heGlvcy9saWIvY29yZS9kaXNwYXRjaFJlcXVlc3QuanMiLCIuLi8uLi9heGlvcy9saWIvaGVscGVycy92YWxpZGF0b3IuanMiLCIuLi8uLi9heGlvcy9saWIvY29yZS9BeGlvcy5qcyIsIi4uLy4uL2F4aW9zL2xpYi9jYW5jZWwvQ2FuY2VsVG9rZW4uanMiLCIuLi8uLi9heGlvcy9saWIvaGVscGVycy9zcHJlYWQuanMiLCIuLi8uLi9heGlvcy9saWIvaGVscGVycy9pc0F4aW9zRXJyb3IuanMiLCIuLi8uLi9heGlvcy9saWIvaGVscGVycy9IdHRwU3RhdHVzQ29kZS5qcyIsIi4uLy4uL2F4aW9zL2xpYi9heGlvcy5qcyIsIi4uLy4uL2F4aW9zL2luZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc3RyaWN0JztcblxuLyoqXG4gKiBDcmVhdGUgYSBib3VuZCB2ZXJzaW9uIG9mIGEgZnVuY3Rpb24gd2l0aCBhIHNwZWNpZmllZCBgdGhpc2AgY29udGV4dFxuICpcbiAqIEBwYXJhbSB7RnVuY3Rpb259IGZuIC0gVGhlIGZ1bmN0aW9uIHRvIGJpbmRcbiAqIEBwYXJhbSB7Kn0gdGhpc0FyZyAtIFRoZSB2YWx1ZSB0byBiZSBwYXNzZWQgYXMgdGhlIGB0aGlzYCBwYXJhbWV0ZXJcbiAqIEByZXR1cm5zIHtGdW5jdGlvbn0gQSBuZXcgZnVuY3Rpb24gdGhhdCB3aWxsIGNhbGwgdGhlIG9yaWdpbmFsIGZ1bmN0aW9uIHdpdGggdGhlIHNwZWNpZmllZCBgdGhpc2AgY29udGV4dFxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBiaW5kKGZuLCB0aGlzQXJnKSB7XG4gIHJldHVybiBmdW5jdGlvbiB3cmFwKCkge1xuICAgIHJldHVybiBmbi5hcHBseSh0aGlzQXJnLCBhcmd1bWVudHMpO1xuICB9O1xufVxuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgYmluZCBmcm9tICcuL2hlbHBlcnMvYmluZC5qcyc7XG5cbi8vIHV0aWxzIGlzIGEgbGlicmFyeSBvZiBnZW5lcmljIGhlbHBlciBmdW5jdGlvbnMgbm9uLXNwZWNpZmljIHRvIGF4aW9zXG5cbmNvbnN0IHsgdG9TdHJpbmcgfSA9IE9iamVjdC5wcm90b3R5cGU7XG5jb25zdCB7IGdldFByb3RvdHlwZU9mIH0gPSBPYmplY3Q7XG5jb25zdCB7IGl0ZXJhdG9yLCB0b1N0cmluZ1RhZyB9ID0gU3ltYm9sO1xuXG4vKiBDcmVhdGluZyBhIGZ1bmN0aW9uIHRoYXQgd2lsbCBjaGVjayBpZiBhbiBvYmplY3QgaGFzIGEgcHJvcGVydHkuICovXG5jb25zdCBoYXNPd25Qcm9wZXJ0eSA9IChcbiAgKHsgaGFzT3duUHJvcGVydHkgfSkgPT5cbiAgKG9iaiwgcHJvcCkgPT5cbiAgICBoYXNPd25Qcm9wZXJ0eS5jYWxsKG9iaiwgcHJvcClcbikoT2JqZWN0LnByb3RvdHlwZSk7XG5cbmNvbnN0IGlzVW5zYWZlT2JqZWN0S2V5ID0gKHByb3ApID0+XG4gIHR5cGVvZiBwcm9wID09PSAnc3RyaW5nJyAmJlxuICAocHJvcCA9PT0gJ19fcHJvdG9fXycgfHwgcHJvcCA9PT0gJ2NvbnN0cnVjdG9yJyB8fCBwcm9wID09PSAncHJvdG90eXBlJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIHdoZXRoZXIgYW4gaW5oZXJpdGVkIG9iamVjdCBtdXN0IGJlIHRyZWF0ZWQgYXMgYSBzaGFyZWQtcHJvdG90eXBlXG4gKiBib3VuZGFyeS4gQ3Jvc3MtcmVhbG0gT2JqZWN0LnByb3RvdHlwZSBvYmplY3RzIGNhbm5vdCBiZSBkaXN0aW5ndWlzaGVkXG4gKiByZWxpYWJseSBmcm9tIGFwcGxpY2F0aW9uLWNyZWF0ZWQgbnVsbC1wcm90b3R5cGUgb2JqZWN0cyBiZWNhdXNlIHRoZWlyXG4gKiBwcm9wZXJ0aWVzIGFyZSBtdXRhYmxlLCBzbyBhbGwgaW5oZXJpdGVkIHRlcm1pbmFsIHByb3RvdHlwZXMgYXJlIGV4Y2x1ZGVkXG4gKiBhcyBhIGZhaWwtY2xvc2VkIGJvdW5kYXJ5LiBBIG51bGwtcHJvdG90eXBlIHNvdXJjZSBzdGlsbCBrZWVwcyBpdHMgb3duXG4gKiBwcm9wZXJ0aWVzLCBhcyBwcm9kdWNlZCBieSBtZXJnZUNvbmZpZyBhbmQgb3RoZXIgc2FmZSBtYXRlcmlhbGl6YXRpb24gcGF0aHMuXG4gKlxuICogQHBhcmFtIHsqfSBvYmogVGhlIG9iamVjdCB0byBpbnNwZWN0XG4gKiBAcGFyYW0geyp9IHByb3RvdHlwZSBUaGUgb2JqZWN0J3MgcHJvdG90eXBlXG4gKiBAcGFyYW0ge2Jvb2xlYW59IHNvdXJjZSBXaGV0aGVyIG9iaiBpcyB0aGUgb3JpZ2luYWwgdHJhdmVyc2FsIHNvdXJjZVxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIHdoZW4gb2JqIGlzIGEgc2FmZSBwcm90b3R5cGUgdHJhdmVyc2FsIGJvdW5kYXJ5XG4gKi9cbmNvbnN0IGlzUHJvdG90eXBlQm91bmRhcnkgPSAob2JqLCBwcm90b3R5cGUsIHNvdXJjZSkgPT5cbiAgb2JqID09PSBPYmplY3QucHJvdG90eXBlIHx8ICghc291cmNlICYmIHByb3RvdHlwZSA9PT0gbnVsbCk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIHdoZXRoZXIgYW4gb2JqZWN0IGNhbiByZXRhaW4gaXRzIGlkZW50aXR5IHRocm91Z2ggY29kZSBwYXRocyB0aGF0XG4gKiBhZGQsIHJlcGxhY2UsIGFuZCByZW1vdmUgY29uZmlnIHByb3BlcnRpZXMgd2l0aG91dCBieXBhc3NpbmcgdW5zYWZlLWtleVxuICogZmlsdGVyaW5nLiBJbW11dGFibGUgb2JqZWN0cywgdW5zYWZlLWtleS1iZWFyaW5nIG9iamVjdHMsIGFuZCBvYmplY3RzIHdpdGhcbiAqIGFjY2Vzc29yIG9yIHJlc3RyaWN0ZWQgZGF0YSBwcm9wZXJ0aWVzIG11c3QgYmUgbWF0ZXJpYWxpemVkIGluc3RlYWQuXG4gKlxuICogQHBhcmFtIHsqfSBvYmogVGhlIG9iamVjdCB0byBpbnNwZWN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgd2hlbiBldmVyeSBvd24gcHJvcGVydHkgaXMgc2FmZSBhbmQgZnVsbHkgbXV0YWJsZVxuICovXG5jb25zdCBpc1NhZmVBbmRGdWxseU11dGFibGUgPSAob2JqKSA9PiB7XG4gIGlmICghT2JqZWN0LmlzRXh0ZW5zaWJsZShvYmopKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgY29uc3QgcHJvcHMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyhvYmopO1xuXG4gIGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7XG4gICAgcHJvcHMucHVzaCguLi5PYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKG9iaikpO1xuICB9XG5cbiAgcmV0dXJuIHByb3BzLmV2ZXJ5KChwcm9wKSA9PiB7XG4gICAgaWYgKGlzVW5zYWZlT2JqZWN0S2V5KHByb3ApKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgY29uc3QgZGVzY3JpcHRvciA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3Iob2JqLCBwcm9wKTtcblxuICAgIHJldHVybiAhIWRlc2NyaXB0b3IgJiYgZGVzY3JpcHRvci5jb25maWd1cmFibGUgJiYgZGVzY3JpcHRvci53cml0YWJsZSA9PT0gdHJ1ZTtcbiAgfSk7XG59O1xuXG4vKipcbiAqIFdhbGsgdGhlIHByb3RvdHlwZSBjaGFpbiAoZXhjbHVkaW5nIHRoZSBzb3VyY2UgcmVhbG0ncyBPYmplY3QucHJvdG90eXBlKVxuICogbG9va2luZyBmb3IgYW4gb3duIGBwcm9wYC4gVGhpcyBkaXN0aW5ndWlzaGVzIGdlbnVpbmUgb3duL2luaGVyaXRlZCBtZW1iZXJzXG4gKiDigJQgaW5jbHVkaW5nIGNsYXNzIGFjY2Vzc29ycyBhbmQgdGVtcGxhdGUgcHJvdG90eXBlcyDigJQgZnJvbSBtZW1iZXJzIGluamVjdGVkXG4gKiB2aWEgT2JqZWN0LnByb3RvdHlwZSBwb2xsdXRpb24gKGUuZy4gYE9iamVjdC5wcm90b3R5cGUudXNlcm5hbWUgPSAnLi4uJ2ApLFxuICogd2hpY2ggbGl2ZSBvbiBPYmplY3QucHJvdG90eXBlIGl0c2VsZiBhbmQgYXJlIHRoZXJlZm9yZSBuZXZlciBtYXRjaGVkLlxuICpcbiAqIEBwYXJhbSB7Kn0gdGhpbmcgVGhlIHZhbHVlIHdob3NlIGNoYWluIHRvIGluc3BlY3RcbiAqIEBwYXJhbSB7c3RyaW5nfHN5bWJvbH0gcHJvcCBUaGUgcHJvcGVydHkga2V5IHRvIGxvb2sgZm9yXG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgd2hlbiBgcHJvcGAgaXMgb3duZWQgYmVsb3cgT2JqZWN0LnByb3RvdHlwZVxuICovXG5jb25zdCBoYXNPd25JblByb3RvdHlwZUNoYWluID0gKHRoaW5nLCBwcm9wKSA9PiB7XG4gIGxldCBvYmogPSB0aGluZztcbiAgY29uc3Qgc2VlbiA9IFtdO1xuXG4gIHdoaWxlIChvYmogIT0gbnVsbCkge1xuICAgIGlmIChzZWVuLmluZGV4T2Yob2JqKSAhPT0gLTEpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgc2Vlbi5wdXNoKG9iaik7XG5cbiAgICBjb25zdCBwcm90b3R5cGUgPSBnZXRQcm90b3R5cGVPZihvYmopO1xuXG4gICAgaWYgKGlzUHJvdG90eXBlQm91bmRhcnkob2JqLCBwcm90b3R5cGUsIG9iaiA9PT0gdGhpbmcpKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgaWYgKGhhc093blByb3BlcnR5KG9iaiwgcHJvcCkpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBvYmogPSBwcm90b3R5cGU7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufTtcblxuLyoqXG4gKiBSZWFkIGBvYmpbcHJvcF1gIG9ubHkgd2hlbiBpdCBpcyBzYWZlIGZyb20gT2JqZWN0LnByb3RvdHlwZSBwb2xsdXRpb24uIE93blxuICogcHJvcGVydGllcyBhbmQgbWVtYmVycyBpbmhlcml0ZWQgZnJvbSBhIG5vbi1PYmplY3QucHJvdG90eXBlIHNvdXJjZSAoYSBjbGFzc1xuICogaW5zdGFuY2Ugb3IgdGVtcGxhdGUgb2JqZWN0KSBhcmUgaG9ub3JlZDsgYSB2YWx1ZSByZWFjaGFibGUgb25seSB0aHJvdWdoIGFcbiAqIHBvbGx1dGVkIE9iamVjdC5wcm90b3R5cGUgaXMgaWdub3JlZCBhbmQgYHVuZGVmaW5lZGAgaXMgcmV0dXJuZWQuXG4gKlxuICogQHBhcmFtIHsqfSBvYmogVGhlIHNvdXJjZSBvYmplY3RcbiAqIEBwYXJhbSB7c3RyaW5nfHN5bWJvbH0gcHJvcCBUaGUgcHJvcGVydHkga2V5IHRvIHJlYWRcbiAqXG4gKiBAcmV0dXJucyB7Kn0gVGhlIHJlc29sdmVkIHZhbHVlLCBvciB1bmRlZmluZWQgd2hlbiB1bnNhZmUvYWJzZW50XG4gKi9cbmNvbnN0IGdldFNhZmVQcm9wID0gKG9iaiwgcHJvcCkgPT5cbiAgb2JqICE9IG51bGwgJiYgaGFzT3duSW5Qcm90b3R5cGVDaGFpbihvYmosIHByb3ApID8gb2JqW3Byb3BdIDogdW5kZWZpbmVkO1xuXG4vKipcbiAqIEZsYXR0ZW4gYW4gb2JqZWN0IGFuZCBpdHMgYXBwbGljYXRpb24tZGVmaW5lZCBwcm90b3R5cGUgY2hhaW4gaW50byBhXG4gKiBudWxsLXByb3RvdHlwZSBvYmplY3QuIE1lbWJlcnMgaW5oZXJpdGVkIG9ubHkgZnJvbSB0aGUgc291cmNlIHJlYWxtJ3NcbiAqIE9iamVjdC5wcm90b3R5cGUgYXJlIGRlbGliZXJhdGVseSBleGNsdWRlZCwgd2hpbGUgY2xhc3MvdGVtcGxhdGUgbWVtYmVyc1xuICogYmVsb3cgdGhhdCBib3VuZGFyeSBhcmUgcHJlc2VydmVkLlxuICpcbiAqIEBwYXJhbSB7Kn0gdGhpbmcgVGhlIHZhbHVlIHRvIGZsYXR0ZW5cbiAqXG4gKiBAcmV0dXJucyB7Kn0gQSBudWxsLXByb3RvdHlwZSBjb3B5LCBvciB0aGUgb3JpZ2luYWwgdmFsdWUgd2hlbiBpdCBpcyBhbHJlYWR5XG4gKiBzdHJ1Y3R1cmFsbHkgc2FmZSBvciBpcyBub3QgYW4gb2JqZWN0XG4gKi9cbmNvbnN0IHRvU2FmZUZsYXRPYmplY3QgPSAodGhpbmcpID0+IHtcbiAgaWYgKHRoaW5nID09IG51bGwgfHwgKHR5cGVvZiB0aGluZyAhPT0gJ29iamVjdCcgJiYgdHlwZW9mIHRoaW5nICE9PSAnZnVuY3Rpb24nKSkge1xuICAgIHJldHVybiB0aGluZztcbiAgfVxuXG4gIGNvbnN0IHNvdXJjZVByb3RvdHlwZSA9IGdldFByb3RvdHlwZU9mKHRoaW5nKTtcblxuICBpZiAoc291cmNlUHJvdG90eXBlID09PSBudWxsICYmIGlzU2FmZUFuZEZ1bGx5TXV0YWJsZSh0aGluZykpIHtcbiAgICByZXR1cm4gdGhpbmc7XG4gIH1cblxuICBjb25zdCByZXN1bHQgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBjb25zdCBtZXJnZWQgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBjb25zdCBzZWVuID0gW107XG4gIGxldCBjdXJyZW50ID0gdGhpbmc7XG5cbiAgd2hpbGUgKGN1cnJlbnQgIT0gbnVsbCkge1xuICAgIGlmIChzZWVuLmluZGV4T2YoY3VycmVudCkgIT09IC0xKSB7XG4gICAgICBicmVhaztcbiAgICB9XG5cbiAgICBzZWVuLnB1c2goY3VycmVudCk7XG5cbiAgICBjb25zdCBwcm90b3R5cGUgPSBjdXJyZW50ID09PSB0aGluZyA/IHNvdXJjZVByb3RvdHlwZSA6IGdldFByb3RvdHlwZU9mKGN1cnJlbnQpO1xuXG4gICAgaWYgKGlzUHJvdG90eXBlQm91bmRhcnkoY3VycmVudCwgcHJvdG90eXBlLCBjdXJyZW50ID09PSB0aGluZykpIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIGNvbnN0IHByb3BzID0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMoY3VycmVudCk7XG5cbiAgICBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykge1xuICAgICAgcHJvcHMucHVzaCguLi5PYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKGN1cnJlbnQpKTtcbiAgICB9XG5cbiAgICBmb3IgKGNvbnN0IHByb3Agb2YgcHJvcHMpIHtcbiAgICAgIGlmIChpc1Vuc2FmZU9iamVjdEtleShwcm9wKSkge1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cblxuICAgICAgaWYgKCFoYXNPd25Qcm9wZXJ0eShtZXJnZWQsIHByb3ApKSB7XG4gICAgICAgIHJlc3VsdFtwcm9wXSA9IHRoaW5nW3Byb3BdO1xuICAgICAgICBtZXJnZWRbcHJvcF0gPSB0cnVlO1xuICAgICAgfVxuICAgIH1cblxuICAgIGN1cnJlbnQgPSBwcm90b3R5cGU7XG4gIH1cblxuICByZXR1cm4gcmVzdWx0O1xufTtcblxuY29uc3Qga2luZE9mID0gKChjYWNoZSkgPT4gKHRoaW5nKSA9PiB7XG4gIGNvbnN0IHN0ciA9IHRvU3RyaW5nLmNhbGwodGhpbmcpO1xuICByZXR1cm4gY2FjaGVbc3RyXSB8fCAoY2FjaGVbc3RyXSA9IHN0ci5zbGljZSg4LCAtMSkudG9Mb3dlckNhc2UoKSk7XG59KShPYmplY3QuY3JlYXRlKG51bGwpKTtcblxuY29uc3Qga2luZE9mVGVzdCA9ICh0eXBlKSA9PiB7XG4gIHR5cGUgPSB0eXBlLnRvTG93ZXJDYXNlKCk7XG4gIHJldHVybiAodGhpbmcpID0+IGtpbmRPZih0aGluZykgPT09IHR5cGU7XG59O1xuXG5jb25zdCB0eXBlT2ZUZXN0ID0gKHR5cGUpID0+ICh0aGluZykgPT4gdHlwZW9mIHRoaW5nID09PSB0eXBlO1xuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIGEgbm9uLW51bGwgb2JqZWN0XG4gKlxuICogQHBhcmFtIHtPYmplY3R9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGFuIEFycmF5LCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuY29uc3QgeyBpc0FycmF5IH0gPSBBcnJheTtcblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgYSB2YWx1ZSBpcyB1bmRlZmluZWRcbiAqXG4gKiBAcGFyYW0geyp9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHRoZSB2YWx1ZSBpcyB1bmRlZmluZWQsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc1VuZGVmaW5lZCA9IHR5cGVPZlRlc3QoJ3VuZGVmaW5lZCcpO1xuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIGEgQnVmZmVyXG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIEJ1ZmZlciwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmZ1bmN0aW9uIGlzQnVmZmVyKHZhbCkge1xuICByZXR1cm4gKFxuICAgIHZhbCAhPT0gbnVsbCAmJlxuICAgICFpc1VuZGVmaW5lZCh2YWwpICYmXG4gICAgdmFsLmNvbnN0cnVjdG9yICE9PSBudWxsICYmXG4gICAgIWlzVW5kZWZpbmVkKHZhbC5jb25zdHJ1Y3RvcikgJiZcbiAgICBpc0Z1bmN0aW9uKHZhbC5jb25zdHJ1Y3Rvci5pc0J1ZmZlcikgJiZcbiAgICB2YWwuY29uc3RydWN0b3IuaXNCdWZmZXIodmFsKVxuICApO1xufVxuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIGFuIEFycmF5QnVmZmVyXG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhbiBBcnJheUJ1ZmZlciwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzQXJyYXlCdWZmZXIgPSBraW5kT2ZUZXN0KCdBcnJheUJ1ZmZlcicpO1xuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIGEgdmlldyBvbiBhbiBBcnJheUJ1ZmZlclxuICpcbiAqIEBwYXJhbSB7Kn0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYSB2aWV3IG9uIGFuIEFycmF5QnVmZmVyLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuZnVuY3Rpb24gaXNBcnJheUJ1ZmZlclZpZXcodmFsKSB7XG4gIGxldCByZXN1bHQ7XG4gIGlmICh0eXBlb2YgQXJyYXlCdWZmZXIgIT09ICd1bmRlZmluZWQnICYmIEFycmF5QnVmZmVyLmlzVmlldykge1xuICAgIHJlc3VsdCA9IEFycmF5QnVmZmVyLmlzVmlldyh2YWwpO1xuICB9IGVsc2Uge1xuICAgIHJlc3VsdCA9IHZhbCAmJiB2YWwuYnVmZmVyICYmIGlzQXJyYXlCdWZmZXIodmFsLmJ1ZmZlcik7XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgYSB2YWx1ZSBpcyBhIFN0cmluZ1xuICpcbiAqIEBwYXJhbSB7Kn0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYSBTdHJpbmcsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc1N0cmluZyA9IHR5cGVPZlRlc3QoJ3N0cmluZycpO1xuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIGEgRnVuY3Rpb25cbiAqXG4gKiBAcGFyYW0geyp9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYSBGdW5jdGlvbiwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzRnVuY3Rpb24gPSB0eXBlT2ZUZXN0KCdmdW5jdGlvbicpO1xuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIGEgTnVtYmVyXG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIE51bWJlciwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzTnVtYmVyID0gdHlwZU9mVGVzdCgnbnVtYmVyJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYW4gT2JqZWN0XG4gKlxuICogQHBhcmFtIHsqfSB0aGluZyBUaGUgdmFsdWUgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGFuIE9iamVjdCwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzT2JqZWN0ID0gKHRoaW5nKSA9PiB0aGluZyAhPT0gbnVsbCAmJiB0eXBlb2YgdGhpbmcgPT09ICdvYmplY3QnO1xuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIGEgQm9vbGVhblxuICpcbiAqIEBwYXJhbSB7Kn0gdGhpbmcgVGhlIHZhbHVlIHRvIHRlc3RcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGEgQm9vbGVhbiwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzQm9vbGVhbiA9ICh0aGluZykgPT4gdGhpbmcgPT09IHRydWUgfHwgdGhpbmcgPT09IGZhbHNlO1xuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIGEgcGxhaW4gT2JqZWN0XG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIHBsYWluIE9iamVjdCwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzUGxhaW5PYmplY3QgPSAodmFsKSA9PiB7XG4gIGlmICghaXNPYmplY3QodmFsKSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIGNvbnN0IHByb3RvdHlwZSA9IGdldFByb3RvdHlwZU9mKHZhbCk7XG4gIHJldHVybiAoXG4gICAgKHByb3RvdHlwZSA9PT0gbnVsbCB8fCBwcm90b3R5cGUgPT09IE9iamVjdC5wcm90b3R5cGUgfHwgZ2V0UHJvdG90eXBlT2YocHJvdG90eXBlKSA9PT0gbnVsbCkgJiZcbiAgICAvLyBUcmVhdCBzYWZlIG93bi9pbmhlcml0ZWQgU3ltYm9sLnRvU3RyaW5nVGFnIG9yIFN5bWJvbC5pdGVyYXRvciBtZW1iZXJzIGFzXG4gICAgLy8gZXZpZGVuY2UgdGhlIHZhbHVlIGlzIHRhZ2dlZC9pdGVyYWJsZSwgd2hpbGUgaWdub3JpbmcgbWVtYmVycyByZWFjaGFibGVcbiAgICAvLyBvbmx5IHRocm91Z2ggc2hhcmVkIG9yIHRlcm1pbmFsIHByb3RvdHlwZSBib3VuZGFyaWVzLlxuICAgICFoYXNPd25JblByb3RvdHlwZUNoYWluKHZhbCwgdG9TdHJpbmdUYWcpICYmXG4gICAgIWhhc093bkluUHJvdG90eXBlQ2hhaW4odmFsLCBpdGVyYXRvcilcbiAgKTtcbn07XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYW4gZW1wdHkgb2JqZWN0IChzYWZlbHkgaGFuZGxlcyBCdWZmZXJzKVxuICpcbiAqIEBwYXJhbSB7Kn0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYW4gZW1wdHkgb2JqZWN0LCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuY29uc3QgaXNFbXB0eU9iamVjdCA9ICh2YWwpID0+IHtcbiAgLy8gRWFybHkgcmV0dXJuIGZvciBub24tb2JqZWN0cyBvciBCdWZmZXJzIHRvIHByZXZlbnQgUmFuZ2VFcnJvclxuICBpZiAoIWlzT2JqZWN0KHZhbCkgfHwgaXNCdWZmZXIodmFsKSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKHZhbCkubGVuZ3RoID09PSAwICYmIE9iamVjdC5nZXRQcm90b3R5cGVPZih2YWwpID09PSBPYmplY3QucHJvdG90eXBlO1xuICB9IGNhdGNoIChlKSB7XG4gICAgLy8gRmFsbGJhY2sgZm9yIGFueSBvdGhlciBvYmplY3RzIHRoYXQgbWlnaHQgY2F1c2UgUmFuZ2VFcnJvciB3aXRoIE9iamVjdC5rZXlzKClcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn07XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBEYXRlXG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIERhdGUsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc0RhdGUgPSBraW5kT2ZUZXN0KCdEYXRlJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBGaWxlXG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIEZpbGUsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc0ZpbGUgPSBraW5kT2ZUZXN0KCdGaWxlJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBSZWFjdCBOYXRpdmUgQmxvYlxuICogUmVhY3QgTmF0aXZlIFwiYmxvYlwiOiBhbiBvYmplY3Qgd2l0aCBhIGB1cmlgIGF0dHJpYnV0ZS4gT3B0aW9uYWxseSwgaXQgY2FuXG4gKiBhbHNvIGhhdmUgYSBgbmFtZWAgYW5kIGB0eXBlYCBhdHRyaWJ1dGUgdG8gc3BlY2lmeSBmaWxlbmFtZSBhbmQgY29udGVudCB0eXBlXG4gKlxuICogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vZmFjZWJvb2svcmVhY3QtbmF0aXZlL2Jsb2IvMjY2ODRjZjNhZGY0MDk0ZWI2YzQwNWQzNDVhNzViZjhjN2MwYmY4OC9MaWJyYXJpZXMvTmV0d29yay9Gb3JtRGF0YS5qcyNMNjgtTDcxXG4gKlxuICogQHBhcmFtIHsqfSB2YWx1ZSBUaGUgdmFsdWUgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGEgUmVhY3QgTmF0aXZlIEJsb2IsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc1JlYWN0TmF0aXZlQmxvYiA9ICh2YWx1ZSkgPT4ge1xuICByZXR1cm4gISEodmFsdWUgJiYgdHlwZW9mIHZhbHVlLnVyaSAhPT0gJ3VuZGVmaW5lZCcpO1xufTtcblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgZW52aXJvbm1lbnQgaXMgUmVhY3QgTmF0aXZlXG4gKiBSZWFjdE5hdGl2ZSBgRm9ybURhdGFgIGhhcyBhIG5vbi1zdGFuZGFyZCBgZ2V0UGFydHMoKWAgbWV0aG9kXG4gKlxuICogQHBhcmFtIHsqfSBmb3JtRGF0YSBUaGUgZm9ybURhdGEgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIGVudmlyb25tZW50IGlzIFJlYWN0IE5hdGl2ZSwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzUmVhY3ROYXRpdmUgPSAoZm9ybURhdGEpID0+IGZvcm1EYXRhICYmIHR5cGVvZiBmb3JtRGF0YS5nZXRQYXJ0cyAhPT0gJ3VuZGVmaW5lZCc7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBCbG9iXG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIEJsb2IsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc0Jsb2IgPSBraW5kT2ZUZXN0KCdCbG9iJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBGaWxlTGlzdFxuICpcbiAqIEBwYXJhbSB7Kn0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYSBGaWxlTGlzdCwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzRmlsZUxpc3QgPSBraW5kT2ZUZXN0KCdGaWxlTGlzdCcpO1xuY29uc3QgaXNTZXQgPSBraW5kT2ZUZXN0KCdTZXQnKTtcblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgYSB2YWx1ZSBpcyBhIFN0cmVhbVxuICpcbiAqIEBwYXJhbSB7Kn0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYSBTdHJlYW0sIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc1N0cmVhbSA9ICh2YWwpID0+IGlzT2JqZWN0KHZhbCkgJiYgaXNGdW5jdGlvbih2YWwucGlwZSk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBGb3JtRGF0YVxuICpcbiAqIEBwYXJhbSB7Kn0gdGhpbmcgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhbiBGb3JtRGF0YSwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmZ1bmN0aW9uIGdldEdsb2JhbCgpIHtcbiAgaWYgKHR5cGVvZiBnbG9iYWxUaGlzICE9PSAndW5kZWZpbmVkJykgcmV0dXJuIGdsb2JhbFRoaXM7XG4gIGlmICh0eXBlb2Ygc2VsZiAhPT0gJ3VuZGVmaW5lZCcpIHJldHVybiBzZWxmO1xuICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHJldHVybiB3aW5kb3c7XG4gIGlmICh0eXBlb2YgZ2xvYmFsICE9PSAndW5kZWZpbmVkJykgcmV0dXJuIGdsb2JhbDtcbiAgcmV0dXJuIHt9O1xufVxuXG5jb25zdCBHID0gZ2V0R2xvYmFsKCk7XG5jb25zdCBGb3JtRGF0YUN0b3IgPSB0eXBlb2YgRy5Gb3JtRGF0YSAhPT0gJ3VuZGVmaW5lZCcgPyBHLkZvcm1EYXRhIDogdW5kZWZpbmVkO1xuXG5jb25zdCBpc0Zvcm1EYXRhID0gKHRoaW5nKSA9PiB7XG4gIGlmICghdGhpbmcpIHJldHVybiBmYWxzZTtcbiAgaWYgKEZvcm1EYXRhQ3RvciAmJiB0aGluZyBpbnN0YW5jZW9mIEZvcm1EYXRhQ3RvcikgcmV0dXJuIHRydWU7XG4gIC8vIFJlamVjdCBwbGFpbiBvYmplY3RzIGluaGVyaXRpbmcgZGlyZWN0bHkgZnJvbSBPYmplY3QucHJvdG90eXBlIHNvIHByb3RvdHlwZS1wb2xsdXRpb24gZ2FkZ2V0cyBjYW4ndCBzcG9vZiBGb3JtRGF0YS5cbiAgY29uc3QgcHJvdG8gPSBnZXRQcm90b3R5cGVPZih0aGluZyk7XG4gIGlmICghcHJvdG8gfHwgcHJvdG8gPT09IE9iamVjdC5wcm90b3R5cGUpIHJldHVybiBmYWxzZTtcbiAgaWYgKCFpc0Z1bmN0aW9uKHRoaW5nLmFwcGVuZCkpIHJldHVybiBmYWxzZTtcbiAgY29uc3Qga2luZCA9IGtpbmRPZih0aGluZyk7XG4gIHJldHVybiAoXG4gICAga2luZCA9PT0gJ2Zvcm1kYXRhJyB8fFxuICAgIC8vIGRldGVjdCBmb3JtLWRhdGEgaW5zdGFuY2VcbiAgICAoa2luZCA9PT0gJ29iamVjdCcgJiYgaXNGdW5jdGlvbih0aGluZy50b1N0cmluZykgJiYgdGhpbmcudG9TdHJpbmcoKSA9PT0gJ1tvYmplY3QgRm9ybURhdGFdJylcbiAgKTtcbn07XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBVUkxTZWFyY2hQYXJhbXMgb2JqZWN0XG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIFVSTFNlYXJjaFBhcmFtcyBvYmplY3QsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc1VSTFNlYXJjaFBhcmFtcyA9IGtpbmRPZlRlc3QoJ1VSTFNlYXJjaFBhcmFtcycpO1xuXG5jb25zdCBbaXNSZWFkYWJsZVN0cmVhbSwgaXNSZXF1ZXN0LCBpc1Jlc3BvbnNlLCBpc0hlYWRlcnNdID0gW1xuICAnUmVhZGFibGVTdHJlYW0nLFxuICAnUmVxdWVzdCcsXG4gICdSZXNwb25zZScsXG4gICdIZWFkZXJzJyxcbl0ubWFwKGtpbmRPZlRlc3QpO1xuXG4vKipcbiAqIFRyaW0gZXhjZXNzIHdoaXRlc3BhY2Ugb2ZmIHRoZSBiZWdpbm5pbmcgYW5kIGVuZCBvZiBhIHN0cmluZ1xuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSBzdHIgVGhlIFN0cmluZyB0byB0cmltXG4gKlxuICogQHJldHVybnMge1N0cmluZ30gVGhlIFN0cmluZyBmcmVlZCBvZiBleGNlc3Mgd2hpdGVzcGFjZVxuICovXG5jb25zdCB0cmltID0gKHN0cikgPT4ge1xuICByZXR1cm4gc3RyLnRyaW0gPyBzdHIudHJpbSgpIDogc3RyLnJlcGxhY2UoL15bXFxzXFx1RkVGRlxceEEwXSt8W1xcc1xcdUZFRkZcXHhBMF0rJC9nLCAnJyk7XG59O1xuLyoqXG4gKiBJdGVyYXRlIG92ZXIgYW4gQXJyYXkgb3IgYW4gT2JqZWN0IGludm9raW5nIGEgZnVuY3Rpb24gZm9yIGVhY2ggaXRlbS5cbiAqXG4gKiBJZiBgb2JqYCBpcyBhbiBBcnJheSBjYWxsYmFjayB3aWxsIGJlIGNhbGxlZCBwYXNzaW5nXG4gKiB0aGUgdmFsdWUsIGluZGV4LCBhbmQgY29tcGxldGUgYXJyYXkgZm9yIGVhY2ggaXRlbS5cbiAqXG4gKiBJZiAnb2JqJyBpcyBhbiBPYmplY3QgY2FsbGJhY2sgd2lsbCBiZSBjYWxsZWQgcGFzc2luZ1xuICogdGhlIHZhbHVlLCBrZXksIGFuZCBjb21wbGV0ZSBvYmplY3QgZm9yIGVhY2ggcHJvcGVydHkuXG4gKlxuICogQHBhcmFtIHtPYmplY3R8QXJyYXk8dW5rbm93bj59IG9iaiBUaGUgb2JqZWN0IHRvIGl0ZXJhdGVcbiAqIEBwYXJhbSB7RnVuY3Rpb259IGZuIFRoZSBjYWxsYmFjayB0byBpbnZva2UgZm9yIGVhY2ggaXRlbVxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc11cbiAqIEBwYXJhbSB7Qm9vbGVhbn0gW29wdGlvbnMuYWxsT3duS2V5cyA9IGZhbHNlXVxuICogQHJldHVybnMge2FueX1cbiAqL1xuZnVuY3Rpb24gZm9yRWFjaChvYmosIGZuLCB7IGFsbE93bktleXMgPSBmYWxzZSB9ID0ge30pIHtcbiAgLy8gRG9uJ3QgYm90aGVyIGlmIG5vIHZhbHVlIHByb3ZpZGVkXG4gIGlmIChvYmogPT09IG51bGwgfHwgdHlwZW9mIG9iaiA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICByZXR1cm47XG4gIH1cblxuICBsZXQgaTtcbiAgbGV0IGw7XG5cbiAgLy8gRm9yY2UgYW4gYXJyYXkgaWYgbm90IGFscmVhZHkgc29tZXRoaW5nIGl0ZXJhYmxlXG4gIGlmICh0eXBlb2Ygb2JqICE9PSAnb2JqZWN0Jykge1xuICAgIC8qZXNsaW50IG5vLXBhcmFtLXJlYXNzaWduOjAqL1xuICAgIG9iaiA9IFtvYmpdO1xuICB9XG5cbiAgaWYgKGlzQXJyYXkob2JqKSkge1xuICAgIC8vIEl0ZXJhdGUgb3ZlciBhcnJheSB2YWx1ZXNcbiAgICBmb3IgKGkgPSAwLCBsID0gb2JqLmxlbmd0aDsgaSA8IGw7IGkrKykge1xuICAgICAgZm4uY2FsbChudWxsLCBvYmpbaV0sIGksIG9iaik7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIC8vIEJ1ZmZlciBjaGVja1xuICAgIGlmIChpc0J1ZmZlcihvYmopKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gSXRlcmF0ZSBvdmVyIG9iamVjdCBrZXlzXG4gICAgY29uc3Qga2V5cyA9IGFsbE93bktleXMgPyBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyhvYmopIDogT2JqZWN0LmtleXMob2JqKTtcbiAgICBjb25zdCBsZW4gPSBrZXlzLmxlbmd0aDtcbiAgICBsZXQga2V5O1xuXG4gICAgZm9yIChpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICBrZXkgPSBrZXlzW2ldO1xuICAgICAgZm4uY2FsbChudWxsLCBvYmpba2V5XSwga2V5LCBvYmopO1xuICAgIH1cbiAgfVxufVxuXG4vKipcbiAqIEZpbmRzIGEga2V5IGluIGFuIG9iamVjdCwgY2FzZS1pbnNlbnNpdGl2ZSwgcmV0dXJuaW5nIHRoZSBhY3R1YWwga2V5IG5hbWUuXG4gKiBSZXR1cm5zIG51bGwgaWYgdGhlIG9iamVjdCBpcyBhIEJ1ZmZlciBvciBpZiBubyBtYXRjaCBpcyBmb3VuZC5cbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gb2JqIC0gVGhlIG9iamVjdCB0byBzZWFyY2guXG4gKiBAcGFyYW0ge3N0cmluZ30ga2V5IC0gVGhlIGtleSB0byBmaW5kIChjYXNlLWluc2Vuc2l0aXZlKS5cbiAqIEByZXR1cm5zIHs/c3RyaW5nfSBUaGUgYWN0dWFsIGtleSBuYW1lIGlmIGZvdW5kLCBvdGhlcndpc2UgbnVsbC5cbiAqL1xuZnVuY3Rpb24gZmluZEtleShvYmosIGtleSkge1xuICBpZiAoaXNCdWZmZXIob2JqKSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAga2V5ID0ga2V5LnRvTG93ZXJDYXNlKCk7XG4gIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhvYmopO1xuICBsZXQgaSA9IGtleXMubGVuZ3RoO1xuICBsZXQgX2tleTtcbiAgd2hpbGUgKGktLSA+IDApIHtcbiAgICBfa2V5ID0ga2V5c1tpXTtcbiAgICBpZiAoa2V5ID09PSBfa2V5LnRvTG93ZXJDYXNlKCkpIHtcbiAgICAgIHJldHVybiBfa2V5O1xuICAgIH1cbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuY29uc3QgX2dsb2JhbCA9ICgoKSA9PiB7XG4gIC8qZXNsaW50IG5vLXVuZGVmOjAqL1xuICBpZiAodHlwZW9mIGdsb2JhbFRoaXMgIT09ICd1bmRlZmluZWQnKSByZXR1cm4gZ2xvYmFsVGhpcztcbiAgcmV0dXJuIHR5cGVvZiBzZWxmICE9PSAndW5kZWZpbmVkJyA/IHNlbGYgOiB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyA/IHdpbmRvdyA6IGdsb2JhbDtcbn0pKCk7XG5cbmNvbnN0IGlzQ29udGV4dERlZmluZWQgPSAoY29udGV4dCkgPT4gIWlzVW5kZWZpbmVkKGNvbnRleHQpICYmIGNvbnRleHQgIT09IF9nbG9iYWw7XG5cbi8qKlxuICogQWNjZXB0cyB2YXJhcmdzIGV4cGVjdGluZyBlYWNoIGFyZ3VtZW50IHRvIGJlIGFuIG9iamVjdCwgdGhlblxuICogaW1tdXRhYmx5IG1lcmdlcyB0aGUgcHJvcGVydGllcyBvZiBlYWNoIG9iamVjdCBhbmQgcmV0dXJucyByZXN1bHQuXG4gKlxuICogV2hlbiBtdWx0aXBsZSBvYmplY3RzIGNvbnRhaW4gdGhlIHNhbWUga2V5IHRoZSBsYXRlciBvYmplY3QgaW5cbiAqIHRoZSBhcmd1bWVudHMgbGlzdCB3aWxsIHRha2UgcHJlY2VkZW5jZS5cbiAqXG4gKiBFeGFtcGxlOlxuICpcbiAqIGBgYGpzXG4gKiBjb25zdCByZXN1bHQgPSBtZXJnZSh7Zm9vOiAxMjN9LCB7Zm9vOiA0NTZ9KTtcbiAqIGNvbnNvbGUubG9nKHJlc3VsdC5mb28pOyAvLyBvdXRwdXRzIDQ1NlxuICogYGBgXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IG9iajEgT2JqZWN0IHRvIG1lcmdlXG4gKlxuICogQHJldHVybnMge09iamVjdH0gUmVzdWx0IG9mIGFsbCBtZXJnZSBwcm9wZXJ0aWVzXG4gKi9cbmZ1bmN0aW9uIG1lcmdlKC4uLm9ianMpIHtcbiAgY29uc3QgeyBjYXNlbGVzcywgc2tpcFVuZGVmaW5lZCB9ID0gKGlzQ29udGV4dERlZmluZWQodGhpcykgJiYgdGhpcykgfHwge307XG4gIGNvbnN0IHJlc3VsdCA9IHt9O1xuICBjb25zdCBhc3NpZ25WYWx1ZSA9ICh2YWwsIGtleSkgPT4ge1xuICAgIC8vIFNraXAgZGFuZ2Vyb3VzIHByb3BlcnR5IG5hbWVzIHRvIHByZXZlbnQgcHJvdG90eXBlIHBvbGx1dGlvblxuICAgIGlmIChrZXkgPT09ICdfX3Byb3RvX18nIHx8IGtleSA9PT0gJ2NvbnN0cnVjdG9yJyB8fCBrZXkgPT09ICdwcm90b3R5cGUnKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gZmluZEtleSBsb3dlcmNhc2VzIHRoZSBrZXksIHNvIGNhc2VsZXNzIGxvb2t1cCBvbmx5IGFwcGxpZXMgdG8gc3RyaW5ncyDigJRcbiAgICAvLyBzeW1ib2wga2V5cyBhcmUgaWRlbnRpdHktbWF0Y2hlZC5cbiAgICBjb25zdCB0YXJnZXRLZXkgPSAoY2FzZWxlc3MgJiYgdHlwZW9mIGtleSA9PT0gJ3N0cmluZycgJiYgZmluZEtleShyZXN1bHQsIGtleSkpIHx8IGtleTtcbiAgICAvLyBSZWFkIHZpYSBvd24tcHJvcCBvbmx5IOKAlCBhIGJhcmUgYHJlc3VsdFt0YXJnZXRLZXldYCB3YWxrcyB0aGUgcHJvdG90eXBlXG4gICAgLy8gY2hhaW4sIHNvIGEgcG9sbHV0ZWQgT2JqZWN0LnByb3RvdHlwZSB2YWx1ZSBjb3VsZCBzdXJmYWNlIGhlcmUgYW5kIGdldFxuICAgIC8vIGNvcGllZCBpbnRvIHRoZSBtZXJnZWQgcmVzdWx0LlxuICAgIGNvbnN0IGV4aXN0aW5nID0gaGFzT3duUHJvcGVydHkocmVzdWx0LCB0YXJnZXRLZXkpID8gcmVzdWx0W3RhcmdldEtleV0gOiB1bmRlZmluZWQ7XG4gICAgaWYgKGlzUGxhaW5PYmplY3QoZXhpc3RpbmcpICYmIGlzUGxhaW5PYmplY3QodmFsKSkge1xuICAgICAgcmVzdWx0W3RhcmdldEtleV0gPSBtZXJnZShleGlzdGluZywgdmFsKTtcbiAgICB9IGVsc2UgaWYgKGlzUGxhaW5PYmplY3QodmFsKSkge1xuICAgICAgcmVzdWx0W3RhcmdldEtleV0gPSBtZXJnZSh7fSwgdmFsKTtcbiAgICB9IGVsc2UgaWYgKGlzQXJyYXkodmFsKSkge1xuICAgICAgcmVzdWx0W3RhcmdldEtleV0gPSB2YWwuc2xpY2UoKTtcbiAgICB9IGVsc2UgaWYgKCFza2lwVW5kZWZpbmVkIHx8ICFpc1VuZGVmaW5lZCh2YWwpKSB7XG4gICAgICByZXN1bHRbdGFyZ2V0S2V5XSA9IHZhbDtcbiAgICB9XG4gIH07XG5cbiAgZm9yIChsZXQgaSA9IDAsIGwgPSBvYmpzLmxlbmd0aDsgaSA8IGw7IGkrKykge1xuICAgIGNvbnN0IHNvdXJjZSA9IG9ianNbaV07XG4gICAgaWYgKCFzb3VyY2UgfHwgaXNCdWZmZXIoc291cmNlKSkge1xuICAgICAgY29udGludWU7XG4gICAgfVxuXG4gICAgZm9yRWFjaChzb3VyY2UsIGFzc2lnblZhbHVlKTtcblxuICAgIGlmICh0eXBlb2Ygc291cmNlICE9PSAnb2JqZWN0JyB8fCBpc0FycmF5KHNvdXJjZSkpIHtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGNvbnN0IHN5bWJvbHMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKHNvdXJjZSk7XG4gICAgZm9yIChsZXQgaiA9IDA7IGogPCBzeW1ib2xzLmxlbmd0aDsgaisrKSB7XG4gICAgICBjb25zdCBzeW1ib2wgPSBzeW1ib2xzW2pdO1xuICAgICAgaWYgKHByb3BlcnR5SXNFbnVtZXJhYmxlLmNhbGwoc291cmNlLCBzeW1ib2wpKSB7XG4gICAgICAgIGFzc2lnblZhbHVlKHNvdXJjZVtzeW1ib2xdLCBzeW1ib2wpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gcmVzdWx0O1xufVxuXG4vKipcbiAqIEV4dGVuZHMgb2JqZWN0IGEgYnkgbXV0YWJseSBhZGRpbmcgdG8gaXQgdGhlIHByb3BlcnRpZXMgb2Ygb2JqZWN0IGIuXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IGEgVGhlIG9iamVjdCB0byBiZSBleHRlbmRlZFxuICogQHBhcmFtIHtPYmplY3R9IGIgVGhlIG9iamVjdCB0byBjb3B5IHByb3BlcnRpZXMgZnJvbVxuICogQHBhcmFtIHtPYmplY3R9IHRoaXNBcmcgVGhlIG9iamVjdCB0byBiaW5kIGZ1bmN0aW9uIHRvXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zXVxuICogQHBhcmFtIHtCb29sZWFufSBbb3B0aW9ucy5hbGxPd25LZXlzXVxuICogQHJldHVybnMge09iamVjdH0gVGhlIHJlc3VsdGluZyB2YWx1ZSBvZiBvYmplY3QgYVxuICovXG5jb25zdCBleHRlbmQgPSAoYSwgYiwgdGhpc0FyZywgeyBhbGxPd25LZXlzIH0gPSB7fSkgPT4ge1xuICBmb3JFYWNoKFxuICAgIGIsXG4gICAgKHZhbCwga2V5KSA9PiB7XG4gICAgICBpZiAodGhpc0FyZyAmJiBpc0Z1bmN0aW9uKHZhbCkpIHtcbiAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGEsIGtleSwge1xuICAgICAgICAgIC8vIE51bGwtcHJvdG8gZGVzY3JpcHRvciBzbyBhIHBvbGx1dGVkIE9iamVjdC5wcm90b3R5cGUuZ2V0IGNhbm5vdFxuICAgICAgICAgIC8vIGhpamFjayBkZWZpbmVQcm9wZXJ0eSdzIGFjY2Vzc29yLXZzLWRhdGEgcmVzb2x1dGlvbi5cbiAgICAgICAgICBfX3Byb3RvX186IG51bGwsXG4gICAgICAgICAgdmFsdWU6IGJpbmQodmFsLCB0aGlzQXJnKSxcbiAgICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoYSwga2V5LCB7XG4gICAgICAgICAgX19wcm90b19fOiBudWxsLFxuICAgICAgICAgIHZhbHVlOiB2YWwsXG4gICAgICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0sXG4gICAgeyBhbGxPd25LZXlzIH1cbiAgKTtcbiAgcmV0dXJuIGE7XG59O1xuXG4vKipcbiAqIFJlbW92ZSBieXRlIG9yZGVyIG1hcmtlci4gVGhpcyBjYXRjaGVzIEVGIEJCIEJGICh0aGUgVVRGLTggQk9NKVxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSBjb250ZW50IHdpdGggQk9NXG4gKlxuICogQHJldHVybnMge3N0cmluZ30gY29udGVudCB2YWx1ZSB3aXRob3V0IEJPTVxuICovXG5jb25zdCBzdHJpcEJPTSA9IChjb250ZW50KSA9PiB7XG4gIGlmIChjb250ZW50LmNoYXJDb2RlQXQoMCkgPT09IDB4ZmVmZikge1xuICAgIGNvbnRlbnQgPSBjb250ZW50LnNsaWNlKDEpO1xuICB9XG4gIHJldHVybiBjb250ZW50O1xufTtcblxuLyoqXG4gKiBJbmhlcml0IHRoZSBwcm90b3R5cGUgbWV0aG9kcyBmcm9tIG9uZSBjb25zdHJ1Y3RvciBpbnRvIGFub3RoZXJcbiAqIEBwYXJhbSB7ZnVuY3Rpb259IGNvbnN0cnVjdG9yXG4gKiBAcGFyYW0ge2Z1bmN0aW9ufSBzdXBlckNvbnN0cnVjdG9yXG4gKiBAcGFyYW0ge29iamVjdH0gW3Byb3BzXVxuICogQHBhcmFtIHtvYmplY3R9IFtkZXNjcmlwdG9yc11cbiAqXG4gKiBAcmV0dXJucyB7dm9pZH1cbiAqL1xuY29uc3QgaW5oZXJpdHMgPSAoY29uc3RydWN0b3IsIHN1cGVyQ29uc3RydWN0b3IsIHByb3BzLCBkZXNjcmlwdG9ycykgPT4ge1xuICBjb25zdHJ1Y3Rvci5wcm90b3R5cGUgPSBPYmplY3QuY3JlYXRlKHN1cGVyQ29uc3RydWN0b3IucHJvdG90eXBlLCBkZXNjcmlwdG9ycyk7XG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjb25zdHJ1Y3Rvci5wcm90b3R5cGUsICdjb25zdHJ1Y3RvcicsIHtcbiAgICBfX3Byb3RvX186IG51bGwsXG4gICAgdmFsdWU6IGNvbnN0cnVjdG9yLFxuICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgfSk7XG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjb25zdHJ1Y3RvciwgJ3N1cGVyJywge1xuICAgIF9fcHJvdG9fXzogbnVsbCxcbiAgICB2YWx1ZTogc3VwZXJDb25zdHJ1Y3Rvci5wcm90b3R5cGUsXG4gIH0pO1xuICBwcm9wcyAmJiBPYmplY3QuYXNzaWduKGNvbnN0cnVjdG9yLnByb3RvdHlwZSwgcHJvcHMpO1xufTtcblxuLyoqXG4gKiBSZXNvbHZlIG9iamVjdCB3aXRoIGRlZXAgcHJvdG90eXBlIGNoYWluIHRvIGEgZmxhdCBvYmplY3RcbiAqIEBwYXJhbSB7T2JqZWN0fSBzb3VyY2VPYmogc291cmNlIG9iamVjdFxuICogQHBhcmFtIHtPYmplY3R9IFtkZXN0T2JqXVxuICogQHBhcmFtIHtGdW5jdGlvbnxCb29sZWFufSBbZmlsdGVyXVxuICogQHBhcmFtIHtGdW5jdGlvbn0gW3Byb3BGaWx0ZXJdXG4gKlxuICogQHJldHVybnMge09iamVjdH1cbiAqL1xuY29uc3QgdG9GbGF0T2JqZWN0ID0gKHNvdXJjZU9iaiwgZGVzdE9iaiwgZmlsdGVyLCBwcm9wRmlsdGVyKSA9PiB7XG4gIGxldCBwcm9wcztcbiAgbGV0IGk7XG4gIGxldCBwcm9wO1xuICBjb25zdCBtZXJnZWQgPSB7fTtcblxuICBkZXN0T2JqID0gZGVzdE9iaiB8fCB7fTtcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWVxLW51bGwsZXFlcWVxXG4gIGlmIChzb3VyY2VPYmogPT0gbnVsbCkgcmV0dXJuIGRlc3RPYmo7XG5cbiAgZG8ge1xuICAgIHByb3BzID0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMoc291cmNlT2JqKTtcbiAgICBpID0gcHJvcHMubGVuZ3RoO1xuICAgIHdoaWxlIChpLS0gPiAwKSB7XG4gICAgICBwcm9wID0gcHJvcHNbaV07XG4gICAgICBpZiAoKCFwcm9wRmlsdGVyIHx8IHByb3BGaWx0ZXIocHJvcCwgc291cmNlT2JqLCBkZXN0T2JqKSkgJiYgIW1lcmdlZFtwcm9wXSkge1xuICAgICAgICBkZXN0T2JqW3Byb3BdID0gc291cmNlT2JqW3Byb3BdO1xuICAgICAgICBtZXJnZWRbcHJvcF0gPSB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgICBzb3VyY2VPYmogPSBmaWx0ZXIgIT09IGZhbHNlICYmIGdldFByb3RvdHlwZU9mKHNvdXJjZU9iaik7XG4gIH0gd2hpbGUgKHNvdXJjZU9iaiAmJiAoIWZpbHRlciB8fCBmaWx0ZXIoc291cmNlT2JqLCBkZXN0T2JqKSkgJiYgc291cmNlT2JqICE9PSBPYmplY3QucHJvdG90eXBlKTtcblxuICByZXR1cm4gZGVzdE9iajtcbn07XG5cbi8qKlxuICogRGV0ZXJtaW5lcyB3aGV0aGVyIGEgc3RyaW5nIGVuZHMgd2l0aCB0aGUgY2hhcmFjdGVycyBvZiBhIHNwZWNpZmllZCBzdHJpbmdcbiAqXG4gKiBAcGFyYW0ge1N0cmluZ30gc3RyXG4gKiBAcGFyYW0ge1N0cmluZ30gc2VhcmNoU3RyaW5nXG4gKiBAcGFyYW0ge051bWJlcn0gW3Bvc2l0aW9uPSAwXVxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufVxuICovXG5jb25zdCBlbmRzV2l0aCA9IChzdHIsIHNlYXJjaFN0cmluZywgcG9zaXRpb24pID0+IHtcbiAgc3RyID0gU3RyaW5nKHN0cik7XG4gIGlmIChwb3NpdGlvbiA9PT0gdW5kZWZpbmVkIHx8IHBvc2l0aW9uID4gc3RyLmxlbmd0aCkge1xuICAgIHBvc2l0aW9uID0gc3RyLmxlbmd0aDtcbiAgfVxuICBwb3NpdGlvbiAtPSBzZWFyY2hTdHJpbmcubGVuZ3RoO1xuICBjb25zdCBsYXN0SW5kZXggPSBzdHIuaW5kZXhPZihzZWFyY2hTdHJpbmcsIHBvc2l0aW9uKTtcbiAgcmV0dXJuIGxhc3RJbmRleCAhPT0gLTEgJiYgbGFzdEluZGV4ID09PSBwb3NpdGlvbjtcbn07XG5cbi8qKlxuICogUmV0dXJucyBuZXcgYXJyYXkgZnJvbSBhcnJheSBsaWtlIG9iamVjdCBvciBudWxsIGlmIGZhaWxlZFxuICpcbiAqIEBwYXJhbSB7Kn0gW3RoaW5nXVxuICpcbiAqIEByZXR1cm5zIHs/QXJyYXl9XG4gKi9cbmNvbnN0IHRvQXJyYXkgPSAodGhpbmcpID0+IHtcbiAgaWYgKCF0aGluZykgcmV0dXJuIG51bGw7XG4gIGlmIChpc0FycmF5KHRoaW5nKSkgcmV0dXJuIHRoaW5nO1xuICBsZXQgaSA9IHRoaW5nLmxlbmd0aDtcbiAgaWYgKCFpc051bWJlcihpKSkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IGFyciA9IG5ldyBBcnJheShpKTtcbiAgd2hpbGUgKGktLSA+IDApIHtcbiAgICBhcnJbaV0gPSB0aGluZ1tpXTtcbiAgfVxuICByZXR1cm4gYXJyO1xufTtcblxuLyoqXG4gKiBDaGVja2luZyBpZiB0aGUgVWludDhBcnJheSBleGlzdHMgYW5kIGlmIGl0IGRvZXMsIGl0IHJldHVybnMgYSBmdW5jdGlvbiB0aGF0IGNoZWNrcyBpZiB0aGVcbiAqIHRoaW5nIHBhc3NlZCBpbiBpcyBhbiBpbnN0YW5jZSBvZiBVaW50OEFycmF5XG4gKlxuICogQHBhcmFtIHtUeXBlZEFycmF5fVxuICpcbiAqIEByZXR1cm5zIHtBcnJheX1cbiAqL1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGZ1bmMtbmFtZXNcbmNvbnN0IGlzVHlwZWRBcnJheSA9ICgoVHlwZWRBcnJheSkgPT4ge1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZnVuYy1uYW1lc1xuICByZXR1cm4gKHRoaW5nKSA9PiB7XG4gICAgcmV0dXJuIFR5cGVkQXJyYXkgJiYgdGhpbmcgaW5zdGFuY2VvZiBUeXBlZEFycmF5O1xuICB9O1xufSkodHlwZW9mIFVpbnQ4QXJyYXkgIT09ICd1bmRlZmluZWQnICYmIGdldFByb3RvdHlwZU9mKFVpbnQ4QXJyYXkpKTtcblxuLyoqXG4gKiBGb3IgZWFjaCBlbnRyeSBpbiB0aGUgb2JqZWN0LCBjYWxsIHRoZSBmdW5jdGlvbiB3aXRoIHRoZSBrZXkgYW5kIHZhbHVlLlxuICpcbiAqIEBwYXJhbSB7T2JqZWN0PGFueSwgYW55Pn0gb2JqIC0gVGhlIG9iamVjdCB0byBpdGVyYXRlIG92ZXIuXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBmbiAtIFRoZSBmdW5jdGlvbiB0byBjYWxsIGZvciBlYWNoIGVudHJ5LlxuICpcbiAqIEByZXR1cm5zIHt2b2lkfVxuICovXG5jb25zdCBmb3JFYWNoRW50cnkgPSAob2JqLCBmbikgPT4ge1xuICBjb25zdCBnZW5lcmF0b3IgPSBvYmogJiYgb2JqW2l0ZXJhdG9yXTtcblxuICBjb25zdCBfaXRlcmF0b3IgPSBnZW5lcmF0b3IuY2FsbChvYmopO1xuXG4gIGxldCByZXN1bHQ7XG5cbiAgd2hpbGUgKChyZXN1bHQgPSBfaXRlcmF0b3IubmV4dCgpKSAmJiAhcmVzdWx0LmRvbmUpIHtcbiAgICBjb25zdCBwYWlyID0gcmVzdWx0LnZhbHVlO1xuICAgIGZuLmNhbGwob2JqLCBwYWlyWzBdLCBwYWlyWzFdKTtcbiAgfVxufTtcblxuLyoqXG4gKiBJdCB0YWtlcyBhIHJlZ3VsYXIgZXhwcmVzc2lvbiBhbmQgYSBzdHJpbmcsIGFuZCByZXR1cm5zIGFuIGFycmF5IG9mIGFsbCB0aGUgbWF0Y2hlc1xuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSByZWdFeHAgLSBUaGUgcmVndWxhciBleHByZXNzaW9uIHRvIG1hdGNoIGFnYWluc3QuXG4gKiBAcGFyYW0ge3N0cmluZ30gc3RyIC0gVGhlIHN0cmluZyB0byBzZWFyY2guXG4gKlxuICogQHJldHVybnMge0FycmF5PGJvb2xlYW4+fVxuICovXG5jb25zdCBtYXRjaEFsbCA9IChyZWdFeHAsIHN0cikgPT4ge1xuICBsZXQgbWF0Y2hlcztcbiAgY29uc3QgYXJyID0gW107XG5cbiAgd2hpbGUgKChtYXRjaGVzID0gcmVnRXhwLmV4ZWMoc3RyKSkgIT09IG51bGwpIHtcbiAgICBhcnIucHVzaChtYXRjaGVzKTtcbiAgfVxuXG4gIHJldHVybiBhcnI7XG59O1xuXG4vKiBDaGVja2luZyBpZiB0aGUga2luZE9mVGVzdCBmdW5jdGlvbiByZXR1cm5zIHRydWUgd2hlbiBwYXNzZWQgYW4gSFRNTEZvcm1FbGVtZW50LiAqL1xuY29uc3QgaXNIVE1MRm9ybSA9IGtpbmRPZlRlc3QoJ0hUTUxGb3JtRWxlbWVudCcpO1xuXG5jb25zdCB0b0NhbWVsQ2FzZSA9IChzdHIpID0+IHtcbiAgcmV0dXJuIHN0ci50b0xvd2VyQ2FzZSgpLnJlcGxhY2UoL1stX1xcc10oW2EtelxcZF0pKFxcdyopL2csIGZ1bmN0aW9uIHJlcGxhY2VyKG0sIHAxLCBwMikge1xuICAgIHJldHVybiBwMS50b1VwcGVyQ2FzZSgpICsgcDI7XG4gIH0pO1xufTtcblxuY29uc3QgeyBwcm9wZXJ0eUlzRW51bWVyYWJsZSB9ID0gT2JqZWN0LnByb3RvdHlwZTtcblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgYSB2YWx1ZSBpcyBhIFJlZ0V4cCBvYmplY3RcbiAqXG4gKiBAcGFyYW0geyp9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGEgUmVnRXhwIG9iamVjdCwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzUmVnRXhwID0ga2luZE9mVGVzdCgnUmVnRXhwJyk7XG5cbmNvbnN0IHJlZHVjZURlc2NyaXB0b3JzID0gKG9iaiwgcmVkdWNlcikgPT4ge1xuICBjb25zdCBkZXNjcmlwdG9ycyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKG9iaik7XG4gIGNvbnN0IHJlZHVjZWREZXNjcmlwdG9ycyA9IHt9O1xuXG4gIGZvckVhY2goZGVzY3JpcHRvcnMsIChkZXNjcmlwdG9yLCBuYW1lKSA9PiB7XG4gICAgbGV0IHJldDtcbiAgICBpZiAoKHJldCA9IHJlZHVjZXIoZGVzY3JpcHRvciwgbmFtZSwgb2JqKSkgIT09IGZhbHNlKSB7XG4gICAgICByZWR1Y2VkRGVzY3JpcHRvcnNbbmFtZV0gPSByZXQgfHwgZGVzY3JpcHRvcjtcbiAgICB9XG4gIH0pO1xuXG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKG9iaiwgcmVkdWNlZERlc2NyaXB0b3JzKTtcbn07XG5cbi8qKlxuICogTWFrZXMgYWxsIG1ldGhvZHMgcmVhZC1vbmx5XG4gKiBAcGFyYW0ge09iamVjdH0gb2JqXG4gKi9cblxuY29uc3QgZnJlZXplTWV0aG9kcyA9IChvYmopID0+IHtcbiAgcmVkdWNlRGVzY3JpcHRvcnMob2JqLCAoZGVzY3JpcHRvciwgbmFtZSkgPT4ge1xuICAgIC8vIHNraXAgcmVzdHJpY3RlZCBwcm9wcyBpbiBzdHJpY3QgbW9kZVxuICAgIGlmIChpc0Z1bmN0aW9uKG9iaikgJiYgWydhcmd1bWVudHMnLCAnY2FsbGVyJywgJ2NhbGxlZSddLmluY2x1ZGVzKG5hbWUpKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgY29uc3QgdmFsdWUgPSBvYmpbbmFtZV07XG5cbiAgICBpZiAoIWlzRnVuY3Rpb24odmFsdWUpKSByZXR1cm47XG5cbiAgICBkZXNjcmlwdG9yLmVudW1lcmFibGUgPSBmYWxzZTtcblxuICAgIGlmICgnd3JpdGFibGUnIGluIGRlc2NyaXB0b3IpIHtcbiAgICAgIGRlc2NyaXB0b3Iud3JpdGFibGUgPSBmYWxzZTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoIWRlc2NyaXB0b3Iuc2V0KSB7XG4gICAgICBkZXNjcmlwdG9yLnNldCA9ICgpID0+IHtcbiAgICAgICAgdGhyb3cgRXJyb3IoXCJDYW4gbm90IHJld3JpdGUgcmVhZC1vbmx5IG1ldGhvZCAnXCIgKyBuYW1lICsgXCInXCIpO1xuICAgICAgfTtcbiAgICB9XG4gIH0pO1xufTtcblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBhcnJheSBvciBhIGRlbGltaXRlZCBzdHJpbmcgaW50byBhbiBvYmplY3Qgc2V0IHdpdGggdmFsdWVzIGFzIGtleXMgYW5kIHRydWUgYXMgdmFsdWVzLlxuICogVXNlZnVsIGZvciBmYXN0IG1lbWJlcnNoaXAgY2hlY2tzLlxuICpcbiAqIEBwYXJhbSB7QXJyYXl8c3RyaW5nfSBhcnJheU9yU3RyaW5nIC0gVGhlIGFycmF5IG9yIHN0cmluZyB0byBjb252ZXJ0LlxuICogQHBhcmFtIHtzdHJpbmd9IGRlbGltaXRlciAtIFRoZSBkZWxpbWl0ZXIgdG8gdXNlIGlmIGlucHV0IGlzIGEgc3RyaW5nLlxuICogQHJldHVybnMge09iamVjdH0gQW4gb2JqZWN0IHdpdGgga2V5cyBmcm9tIHRoZSBhcnJheSBvciBzdHJpbmcsIHZhbHVlcyBzZXQgdG8gdHJ1ZS5cbiAqL1xuY29uc3QgdG9PYmplY3RTZXQgPSAoYXJyYXlPclN0cmluZywgZGVsaW1pdGVyKSA9PiB7XG4gIGNvbnN0IG9iaiA9IHt9O1xuXG4gIGNvbnN0IGRlZmluZSA9IChhcnIpID0+IHtcbiAgICBhcnIuZm9yRWFjaCgodmFsdWUpID0+IHtcbiAgICAgIG9ialt2YWx1ZV0gPSB0cnVlO1xuICAgIH0pO1xuICB9O1xuXG4gIGlzQXJyYXkoYXJyYXlPclN0cmluZykgPyBkZWZpbmUoYXJyYXlPclN0cmluZykgOiBkZWZpbmUoU3RyaW5nKGFycmF5T3JTdHJpbmcpLnNwbGl0KGRlbGltaXRlcikpO1xuXG4gIHJldHVybiBvYmo7XG59O1xuXG5jb25zdCBub29wID0gKCkgPT4ge307XG5cbmNvbnN0IHRvRmluaXRlTnVtYmVyID0gKHZhbHVlLCBkZWZhdWx0VmFsdWUpID0+IHtcbiAgcmV0dXJuIHZhbHVlICE9IG51bGwgJiYgTnVtYmVyLmlzRmluaXRlKCh2YWx1ZSA9ICt2YWx1ZSkpID8gdmFsdWUgOiBkZWZhdWx0VmFsdWU7XG59O1xuXG4vKipcbiAqIElmIHRoZSB0aGluZyBpcyBhIEZvcm1EYXRhIG9iamVjdCwgcmV0dXJuIHRydWUsIG90aGVyd2lzZSByZXR1cm4gZmFsc2UuXG4gKlxuICogQHBhcmFtIHt1bmtub3dufSB0aGluZyAtIFRoZSB0aGluZyB0byBjaGVjay5cbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAqL1xuZnVuY3Rpb24gaXNTcGVjQ29tcGxpYW50Rm9ybSh0aGluZykge1xuICByZXR1cm4gISEoXG4gICAgdGhpbmcgJiZcbiAgICBpc0Z1bmN0aW9uKHRoaW5nLmFwcGVuZCkgJiZcbiAgICB0aGluZ1t0b1N0cmluZ1RhZ10gPT09ICdGb3JtRGF0YScgJiZcbiAgICB0aGluZ1tpdGVyYXRvcl1cbiAgKTtcbn1cblxuLyoqXG4gKiBSZWN1cnNpdmVseSBjb252ZXJ0cyBhbiBvYmplY3QgdG8gYSBKU09OLWNvbXBhdGlibGUgb2JqZWN0LCBoYW5kbGluZyBjaXJjdWxhciByZWZlcmVuY2VzIGFuZCBCdWZmZXJzLlxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBvYmogLSBUaGUgb2JqZWN0IHRvIGNvbnZlcnQuXG4gKiBAcmV0dXJucyB7T2JqZWN0fSBUaGUgSlNPTi1jb21wYXRpYmxlIG9iamVjdC5cbiAqL1xuY29uc3QgdG9KU09OT2JqZWN0ID0gKG9iaikgPT4ge1xuICBjb25zdCB2aXNpdGVkID0gbmV3IFdlYWtTZXQoKTtcblxuICBjb25zdCB2aXNpdCA9IChzb3VyY2UpID0+IHtcbiAgICBpZiAoaXNPYmplY3Qoc291cmNlKSkge1xuICAgICAgaWYgKHZpc2l0ZWQuaGFzKHNvdXJjZSkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvL0J1ZmZlciBjaGVja1xuICAgICAgaWYgKGlzQnVmZmVyKHNvdXJjZSkpIHtcbiAgICAgICAgcmV0dXJuIHNvdXJjZTtcbiAgICAgIH1cblxuICAgICAgaWYgKCEoJ3RvSlNPTicgaW4gc291cmNlKSkge1xuICAgICAgICAvLyBhZGQtb24gZGVzY2VudCAvIGRlbGV0ZS1vbi1hc2NlbnQ6IHByZXNlcnZlcyBwYXRoIHNlbWFudGljcywgc28gREFHIG5vZGVzIHNlcmlhbGlzZSBhdCBldmVyeSBvY2N1cnJlbmNlIChzZWUgIzcyMzApLlxuICAgICAgICB2aXNpdGVkLmFkZChzb3VyY2UpO1xuXG4gICAgICAgIGxldCB0YXJnZXQ7XG5cbiAgICAgICAgaWYgKGlzU2V0KHNvdXJjZSkpIHtcbiAgICAgICAgICB0YXJnZXQgPSBbXTtcbiAgICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIHNvdXJjZSkge1xuICAgICAgICAgICAgY29uc3QgcmVkdWNlZFZhbHVlID0gdmlzaXQodmFsdWUpO1xuICAgICAgICAgICAgIWlzVW5kZWZpbmVkKHJlZHVjZWRWYWx1ZSkgJiYgdGFyZ2V0LnB1c2gocmVkdWNlZFZhbHVlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGFyZ2V0ID0gaXNBcnJheShzb3VyY2UpID8gW10gOiB7fTtcblxuICAgICAgICAgIGZvckVhY2goc291cmNlLCAodmFsdWUsIGtleSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgcmVkdWNlZFZhbHVlID0gdmlzaXQodmFsdWUpO1xuICAgICAgICAgICAgIWlzVW5kZWZpbmVkKHJlZHVjZWRWYWx1ZSkgJiYgKHRhcmdldFtrZXldID0gcmVkdWNlZFZhbHVlKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIHZpc2l0ZWQuZGVsZXRlKHNvdXJjZSk7XG5cbiAgICAgICAgcmV0dXJuIHRhcmdldDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gc291cmNlO1xuICB9O1xuXG4gIHJldHVybiB2aXNpdChvYmopO1xufTtcblxuLyoqXG4gKiBEZXRlcm1pbmVzIGlmIGEgdmFsdWUgaXMgYW4gYXN5bmMgZnVuY3Rpb24uXG4gKlxuICogQHBhcmFtIHsqfSB0aGluZyAtIFRoZSB2YWx1ZSB0byB0ZXN0LlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYW4gYXN5bmMgZnVuY3Rpb24sIG90aGVyd2lzZSBmYWxzZS5cbiAqL1xuY29uc3QgaXNBc3luY0ZuID0ga2luZE9mVGVzdCgnQXN5bmNGdW5jdGlvbicpO1xuXG4vKipcbiAqIERldGVybWluZXMgaWYgYSB2YWx1ZSBpcyB0aGVuYWJsZSAoaGFzIHRoZW4gYW5kIGNhdGNoIG1ldGhvZHMpLlxuICpcbiAqIEBwYXJhbSB7Kn0gdGhpbmcgLSBUaGUgdmFsdWUgdG8gdGVzdC5cbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIHRoZW5hYmxlLCBvdGhlcndpc2UgZmFsc2UuXG4gKi9cbmNvbnN0IGlzVGhlbmFibGUgPSAodGhpbmcpID0+XG4gIHRoaW5nICYmXG4gIChpc09iamVjdCh0aGluZykgfHwgaXNGdW5jdGlvbih0aGluZykpICYmXG4gIGlzRnVuY3Rpb24odGhpbmcudGhlbikgJiZcbiAgaXNGdW5jdGlvbih0aGluZy5jYXRjaCk7XG5cbi8vIG9yaWdpbmFsIGNvZGVcbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS9EaWdpdGFsQnJhaW5KUy9BeGlvc1Byb21pc2UvYmxvYi8xNmRlYWIxMzcxMGVjMDk3Nzk5MjIxMzFmM2ZhNTk1NDMyMGY4M2FiL2xpYi91dGlscy5qcyNMMTEtTDM0XG5cbi8qKlxuICogUHJvdmlkZXMgYSBjcm9zcy1wbGF0Zm9ybSBzZXRJbW1lZGlhdGUgaW1wbGVtZW50YXRpb24uXG4gKiBVc2VzIG5hdGl2ZSBzZXRJbW1lZGlhdGUgaWYgYXZhaWxhYmxlLCBvdGhlcndpc2UgZmFsbHMgYmFjayB0byBwb3N0TWVzc2FnZSBvciBzZXRUaW1lb3V0LlxuICpcbiAqIEBwYXJhbSB7Ym9vbGVhbn0gc2V0SW1tZWRpYXRlU3VwcG9ydGVkIC0gV2hldGhlciBzZXRJbW1lZGlhdGUgaXMgc3VwcG9ydGVkLlxuICogQHBhcmFtIHtib29sZWFufSBwb3N0TWVzc2FnZVN1cHBvcnRlZCAtIFdoZXRoZXIgcG9zdE1lc3NhZ2UgaXMgc3VwcG9ydGVkLlxuICogQHJldHVybnMge0Z1bmN0aW9ufSBBIGZ1bmN0aW9uIHRvIHNjaGVkdWxlIGEgY2FsbGJhY2sgYXN5bmNocm9ub3VzbHkuXG4gKi9cbmNvbnN0IF9zZXRJbW1lZGlhdGUgPSAoKHNldEltbWVkaWF0ZVN1cHBvcnRlZCwgcG9zdE1lc3NhZ2VTdXBwb3J0ZWQpID0+IHtcbiAgaWYgKHNldEltbWVkaWF0ZVN1cHBvcnRlZCkge1xuICAgIHJldHVybiBzZXRJbW1lZGlhdGU7XG4gIH1cblxuICByZXR1cm4gcG9zdE1lc3NhZ2VTdXBwb3J0ZWRcbiAgICA/ICgodG9rZW4sIGNhbGxiYWNrcykgPT4ge1xuICAgICAgICBfZ2xvYmFsLmFkZEV2ZW50TGlzdGVuZXIoXG4gICAgICAgICAgJ21lc3NhZ2UnLFxuICAgICAgICAgICh7IHNvdXJjZSwgZGF0YSB9KSA9PiB7XG4gICAgICAgICAgICBpZiAoc291cmNlID09PSBfZ2xvYmFsICYmIGRhdGEgPT09IHRva2VuKSB7XG4gICAgICAgICAgICAgIGNhbGxiYWNrcy5sZW5ndGggJiYgY2FsbGJhY2tzLnNoaWZ0KCkoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIGZhbHNlXG4gICAgICAgICk7XG5cbiAgICAgICAgcmV0dXJuIChjYikgPT4ge1xuICAgICAgICAgIGNhbGxiYWNrcy5wdXNoKGNiKTtcbiAgICAgICAgICBfZ2xvYmFsLnBvc3RNZXNzYWdlKHRva2VuLCAnKicpO1xuICAgICAgICB9O1xuICAgICAgfSkoYGF4aW9zQCR7TWF0aC5yYW5kb20oKX1gLCBbXSlcbiAgICA6IChjYikgPT4gc2V0VGltZW91dChjYik7XG59KSh0eXBlb2Ygc2V0SW1tZWRpYXRlID09PSAnZnVuY3Rpb24nLCBpc0Z1bmN0aW9uKF9nbG9iYWwucG9zdE1lc3NhZ2UpKTtcblxuLyoqXG4gKiBTY2hlZHVsZXMgYSBtaWNyb3Rhc2sgb3IgYXN5bmNocm9ub3VzIGNhbGxiYWNrIGFzIHNvb24gYXMgcG9zc2libGUuXG4gKiBVc2VzIHF1ZXVlTWljcm90YXNrIGlmIGF2YWlsYWJsZSwgb3RoZXJ3aXNlIGZhbGxzIGJhY2sgdG8gcHJvY2Vzcy5uZXh0VGljayBvciBfc2V0SW1tZWRpYXRlLlxuICpcbiAqIEB0eXBlIHtGdW5jdGlvbn1cbiAqL1xuY29uc3QgYXNhcCA9XG4gIHR5cGVvZiBxdWV1ZU1pY3JvdGFzayAhPT0gJ3VuZGVmaW5lZCdcbiAgICA/IHF1ZXVlTWljcm90YXNrLmJpbmQoX2dsb2JhbClcbiAgICA6ICh0eXBlb2YgcHJvY2VzcyAhPT0gJ3VuZGVmaW5lZCcgJiYgcHJvY2Vzcy5uZXh0VGljaykgfHwgX3NldEltbWVkaWF0ZTtcblxuLy8gKioqKioqKioqKioqKioqKioqKioqXG5cbmNvbnN0IGlzSXRlcmFibGUgPSAodGhpbmcpID0+IHRoaW5nICE9IG51bGwgJiYgaXNGdW5jdGlvbih0aGluZ1tpdGVyYXRvcl0pO1xuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIGl0ZXJhYmxlIHZpYSBhbiBpdGVyYXRvciB0aGF0IGlzIE5PVCBzb3VyY2VkIHNvbGVseVxuICogZnJvbSBhIHBvbGx1dGVkIE9iamVjdC5wcm90b3R5cGUuIFVzZSB0aGlzIGluc3RlYWQgb2YgYGlzSXRlcmFibGVgIHdoZW5ldmVyXG4gKiB0aGUgaXRlcmFibGUgY29tZXMgZnJvbSB1bnRydXN0ZWQgaW5wdXQgKGUuZy4gdXNlci1zdXBwbGllZCBoZWFkZXIgc291cmNlcyksXG4gKiBzbyBgT2JqZWN0LnByb3RvdHlwZVtTeW1ib2wuaXRlcmF0b3JdID0gLi4uYCBjYW5ub3QgdHVybiBhbiBvcmRpbmFyeSBvYmplY3RcbiAqIGludG8gYW4gYXR0YWNrZXItY29udHJvbGxlZCBlbnRyaWVzIGl0ZXJhdG9yLlxuICpcbiAqIEBwYXJhbSB7Kn0gdGhpbmcgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBoYXMgYSBub24tcG9sbHV0ZWQgaXRlcmF0b3JcbiAqL1xuY29uc3QgaXNTYWZlSXRlcmFibGUgPSAodGhpbmcpID0+XG4gIHRoaW5nICE9IG51bGwgJiYgaGFzT3duSW5Qcm90b3R5cGVDaGFpbih0aGluZywgaXRlcmF0b3IpICYmIGlzSXRlcmFibGUodGhpbmcpO1xuXG5leHBvcnQgZGVmYXVsdCB7XG4gIGlzQXJyYXksXG4gIGlzQXJyYXlCdWZmZXIsXG4gIGlzQnVmZmVyLFxuICBpc0Zvcm1EYXRhLFxuICBpc0FycmF5QnVmZmVyVmlldyxcbiAgaXNTdHJpbmcsXG4gIGlzTnVtYmVyLFxuICBpc0Jvb2xlYW4sXG4gIGlzT2JqZWN0LFxuICBpc1BsYWluT2JqZWN0LFxuICBpc0VtcHR5T2JqZWN0LFxuICBpc1JlYWRhYmxlU3RyZWFtLFxuICBpc1JlcXVlc3QsXG4gIGlzUmVzcG9uc2UsXG4gIGlzSGVhZGVycyxcbiAgaXNVbmRlZmluZWQsXG4gIGlzRGF0ZSxcbiAgaXNGaWxlLFxuICBpc1JlYWN0TmF0aXZlQmxvYixcbiAgaXNSZWFjdE5hdGl2ZSxcbiAgaXNCbG9iLFxuICBpc1JlZ0V4cCxcbiAgaXNGdW5jdGlvbixcbiAgaXNTdHJlYW0sXG4gIGlzVVJMU2VhcmNoUGFyYW1zLFxuICBpc1R5cGVkQXJyYXksXG4gIGlzRmlsZUxpc3QsXG4gIGZvckVhY2gsXG4gIG1lcmdlLFxuICBleHRlbmQsXG4gIHRyaW0sXG4gIHN0cmlwQk9NLFxuICBpbmhlcml0cyxcbiAgdG9GbGF0T2JqZWN0LFxuICBraW5kT2YsXG4gIGtpbmRPZlRlc3QsXG4gIGVuZHNXaXRoLFxuICB0b0FycmF5LFxuICBmb3JFYWNoRW50cnksXG4gIG1hdGNoQWxsLFxuICBpc0hUTUxGb3JtLFxuICBoYXNPd25Qcm9wZXJ0eSxcbiAgaGFzT3duUHJvcDogaGFzT3duUHJvcGVydHksIC8vIGFuIGFsaWFzIHRvIGF2b2lkIEVTTGludCBuby1wcm90b3R5cGUtYnVpbHRpbnMgZGV0ZWN0aW9uXG4gIGhhc093bkluUHJvdG90eXBlQ2hhaW4sXG4gIGdldFNhZmVQcm9wLFxuICB0b1NhZmVGbGF0T2JqZWN0LFxuICByZWR1Y2VEZXNjcmlwdG9ycyxcbiAgZnJlZXplTWV0aG9kcyxcbiAgdG9PYmplY3RTZXQsXG4gIHRvQ2FtZWxDYXNlLFxuICBub29wLFxuICB0b0Zpbml0ZU51bWJlcixcbiAgZmluZEtleSxcbiAgZ2xvYmFsOiBfZ2xvYmFsLFxuICBpc0NvbnRleHREZWZpbmVkLFxuICBpc1NwZWNDb21wbGlhbnRGb3JtLFxuICB0b0pTT05PYmplY3QsXG4gIGlzQXN5bmNGbixcbiAgaXNUaGVuYWJsZSxcbiAgc2V0SW1tZWRpYXRlOiBfc2V0SW1tZWRpYXRlLFxuICBhc2FwLFxuICBpc0l0ZXJhYmxlLFxuICBpc1NhZmVJdGVyYWJsZSxcbn07XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5cbi8vIFJhd0F4aW9zSGVhZGVycyB3aG9zZSBkdXBsaWNhdGVzIGFyZSBpZ25vcmVkIGJ5IG5vZGVcbi8vIGMuZi4gaHR0cHM6Ly9ub2RlanMub3JnL2FwaS9odHRwLmh0bWwjaHR0cF9tZXNzYWdlX2hlYWRlcnNcbmNvbnN0IGlnbm9yZUR1cGxpY2F0ZU9mID0gdXRpbHMudG9PYmplY3RTZXQoW1xuICAnYWdlJyxcbiAgJ2F1dGhvcml6YXRpb24nLFxuICAnY29udGVudC1sZW5ndGgnLFxuICAnY29udGVudC10eXBlJyxcbiAgJ2V0YWcnLFxuICAnZXhwaXJlcycsXG4gICdmcm9tJyxcbiAgJ2hvc3QnLFxuICAnaWYtbW9kaWZpZWQtc2luY2UnLFxuICAnaWYtdW5tb2RpZmllZC1zaW5jZScsXG4gICdsYXN0LW1vZGlmaWVkJyxcbiAgJ2xvY2F0aW9uJyxcbiAgJ21heC1mb3J3YXJkcycsXG4gICdwcm94eS1hdXRob3JpemF0aW9uJyxcbiAgJ3JlZmVyZXInLFxuICAncmV0cnktYWZ0ZXInLFxuICAndXNlci1hZ2VudCcsXG5dKTtcblxuLyoqXG4gKiBQYXJzZSBoZWFkZXJzIGludG8gYW4gb2JqZWN0XG4gKlxuICogYGBgXG4gKiBEYXRlOiBXZWQsIDI3IEF1ZyAyMDE0IDA4OjU4OjQ5IEdNVFxuICogQ29udGVudC1UeXBlOiBhcHBsaWNhdGlvbi9qc29uXG4gKiBDb25uZWN0aW9uOiBrZWVwLWFsaXZlXG4gKiBUcmFuc2Zlci1FbmNvZGluZzogY2h1bmtlZFxuICogYGBgXG4gKlxuICogQHBhcmFtIHtTdHJpbmd9IHJhd0hlYWRlcnMgSGVhZGVycyBuZWVkaW5nIHRvIGJlIHBhcnNlZFxuICpcbiAqIEByZXR1cm5zIHtPYmplY3R9IEhlYWRlcnMgcGFyc2VkIGludG8gYW4gb2JqZWN0XG4gKi9cbmV4cG9ydCBkZWZhdWx0IChyYXdIZWFkZXJzKSA9PiB7XG4gIGNvbnN0IHBhcnNlZCA9IHt9O1xuICBsZXQga2V5O1xuICBsZXQgdmFsO1xuICBsZXQgaTtcblxuICByYXdIZWFkZXJzICYmXG4gICAgcmF3SGVhZGVycy5zcGxpdCgnXFxuJykuZm9yRWFjaChmdW5jdGlvbiBwYXJzZXIobGluZSkge1xuICAgICAgaSA9IGxpbmUuaW5kZXhPZignOicpO1xuICAgICAga2V5ID0gbGluZS5zdWJzdHJpbmcoMCwgaSkudHJpbSgpLnRvTG93ZXJDYXNlKCk7XG4gICAgICB2YWwgPSBsaW5lLnN1YnN0cmluZyhpICsgMSkudHJpbSgpO1xuXG4gICAgICBjb25zdCBoYXNLZXkgPSB1dGlscy5oYXNPd25Qcm9wKHBhcnNlZCwga2V5KTtcblxuICAgICAgaWYgKCFrZXkgfHwgKGhhc0tleSAmJiB1dGlscy5oYXNPd25Qcm9wKGlnbm9yZUR1cGxpY2F0ZU9mLCBrZXkpKSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIGlmIChrZXkgPT09ICdzZXQtY29va2llJykge1xuICAgICAgICBpZiAoaGFzS2V5KSB7XG4gICAgICAgICAgcGFyc2VkW2tleV0ucHVzaCh2YWwpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHBhcnNlZFtrZXldID0gW3ZhbF07XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHBhcnNlZFtrZXldID0gaGFzS2V5ID8gcGFyc2VkW2tleV0gKyAnLCAnICsgdmFsIDogdmFsO1xuICAgICAgfVxuICAgIH0pO1xuXG4gIHJldHVybiBwYXJzZWQ7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgdXRpbHMgZnJvbSAnLi4vdXRpbHMuanMnO1xuXG5mdW5jdGlvbiB0cmltU1BvckhUQUIoc3RyKSB7XG4gIGxldCBzdGFydCA9IDA7XG4gIGxldCBlbmQgPSBzdHIubGVuZ3RoO1xuXG4gIHdoaWxlIChzdGFydCA8IGVuZCkge1xuICAgIGNvbnN0IGNvZGUgPSBzdHIuY2hhckNvZGVBdChzdGFydCk7XG5cbiAgICBpZiAoY29kZSAhPT0gMHgwOSAmJiBjb2RlICE9PSAweDIwKSB7XG4gICAgICBicmVhaztcbiAgICB9XG5cbiAgICBzdGFydCArPSAxO1xuICB9XG5cbiAgd2hpbGUgKGVuZCA+IHN0YXJ0KSB7XG4gICAgY29uc3QgY29kZSA9IHN0ci5jaGFyQ29kZUF0KGVuZCAtIDEpO1xuXG4gICAgaWYgKGNvZGUgIT09IDB4MDkgJiYgY29kZSAhPT0gMHgyMCkge1xuICAgICAgYnJlYWs7XG4gICAgfVxuXG4gICAgZW5kIC09IDE7XG4gIH1cblxuICByZXR1cm4gc3RhcnQgPT09IDAgJiYgZW5kID09PSBzdHIubGVuZ3RoID8gc3RyIDogc3RyLnNsaWNlKHN0YXJ0LCBlbmQpO1xufVxuXG4vLyBUaGUgY29udHJvbC1jb2RlIHJhbmdlcyBhcmUgaW50ZW50aW9uYWw6IGhlYWRlciBzYW5pdGl6YXRpb24gc3RyaXBzIEMwL0RFTCBieXRlcy5cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1jb250cm9sLXJlZ2V4XG5jb25zdCBJTlZBTElEX1VOSUNPREVfSEVBREVSX1ZBTFVFX0NIQVJTID0gbmV3IFJlZ0V4cCgnW1xcXFx1MDAwMC1cXFxcdTAwMDhcXFxcdTAwMGEtXFxcXHUwMDFmXFxcXHUwMDdmXSsnLCAnZycpO1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNvbnRyb2wtcmVnZXhcbmNvbnN0IElOVkFMSURfQllURV9TVFJJTkdfSEVBREVSX1ZBTFVFX0NIQVJTID0gbmV3IFJlZ0V4cCgnW15cXFxcdTAwMDlcXFxcdTAwMjAtXFxcXHUwMDdlXFxcXHUwMDgwLVxcXFx1MDBmZl0rJywgJ2cnKTtcblxuZnVuY3Rpb24gc2FuaXRpemVWYWx1ZSh2YWx1ZSwgaW52YWxpZENoYXJzKSB7XG4gIGlmICh1dGlscy5pc0FycmF5KHZhbHVlKSkge1xuICAgIHJldHVybiB2YWx1ZS5tYXAoKGl0ZW0pID0+IHNhbml0aXplVmFsdWUoaXRlbSwgaW52YWxpZENoYXJzKSk7XG4gIH1cblxuICByZXR1cm4gdHJpbVNQb3JIVEFCKFN0cmluZyh2YWx1ZSkucmVwbGFjZShpbnZhbGlkQ2hhcnMsICcnKSk7XG59XG5cbmV4cG9ydCBjb25zdCBzYW5pdGl6ZUhlYWRlclZhbHVlID0gKHZhbHVlKSA9PlxuICBzYW5pdGl6ZVZhbHVlKHZhbHVlLCBJTlZBTElEX1VOSUNPREVfSEVBREVSX1ZBTFVFX0NIQVJTKTtcblxuZXhwb3J0IGNvbnN0IHNhbml0aXplQnl0ZVN0cmluZ0hlYWRlclZhbHVlID0gKHZhbHVlKSA9PlxuICBzYW5pdGl6ZVZhbHVlKHZhbHVlLCBJTlZBTElEX0JZVEVfU1RSSU5HX0hFQURFUl9WQUxVRV9DSEFSUyk7XG5cbmV4cG9ydCBmdW5jdGlvbiB0b0J5dGVTdHJpbmdIZWFkZXJPYmplY3QoaGVhZGVycykge1xuICBjb25zdCBieXRlU3RyaW5nSGVhZGVycyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG5cbiAgdXRpbHMuZm9yRWFjaChoZWFkZXJzLnRvSlNPTigpLCAodmFsdWUsIGhlYWRlcikgPT4ge1xuICAgIGJ5dGVTdHJpbmdIZWFkZXJzW2hlYWRlcl0gPSBzYW5pdGl6ZUJ5dGVTdHJpbmdIZWFkZXJWYWx1ZSh2YWx1ZSk7XG4gIH0pO1xuXG4gIHJldHVybiBieXRlU3RyaW5nSGVhZGVycztcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCBwYXJzZUhlYWRlcnMgZnJvbSAnLi4vaGVscGVycy9wYXJzZUhlYWRlcnMuanMnO1xuaW1wb3J0IHsgc2FuaXRpemVIZWFkZXJWYWx1ZSB9IGZyb20gJy4uL2hlbHBlcnMvc2FuaXRpemVIZWFkZXJWYWx1ZS5qcyc7XG5cbmNvbnN0ICRpbnRlcm5hbHMgPSBTeW1ib2woJ2ludGVybmFscycpO1xuXG5mdW5jdGlvbiBub3JtYWxpemVIZWFkZXIoaGVhZGVyKSB7XG4gIHJldHVybiBoZWFkZXIgJiYgU3RyaW5nKGhlYWRlcikudHJpbSgpLnRvTG93ZXJDYXNlKCk7XG59XG5cbmZ1bmN0aW9uIG5vcm1hbGl6ZVZhbHVlKHZhbHVlKSB7XG4gIGlmICh2YWx1ZSA9PT0gZmFsc2UgfHwgdmFsdWUgPT0gbnVsbCkge1xuICAgIHJldHVybiB2YWx1ZTtcbiAgfVxuXG4gIHJldHVybiB1dGlscy5pc0FycmF5KHZhbHVlKSA/IHZhbHVlLm1hcChub3JtYWxpemVWYWx1ZSkgOiBzYW5pdGl6ZUhlYWRlclZhbHVlKFN0cmluZyh2YWx1ZSkpO1xufVxuXG5mdW5jdGlvbiBwYXJzZVRva2VucyhzdHIpIHtcbiAgY29uc3QgdG9rZW5zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgY29uc3QgdG9rZW5zUkUgPSAvKFteXFxzLDs9XSspXFxzKig/Oj1cXHMqKFteLDtdKykpPy9nO1xuICBsZXQgbWF0Y2g7XG5cbiAgd2hpbGUgKChtYXRjaCA9IHRva2Vuc1JFLmV4ZWMoc3RyKSkpIHtcbiAgICB0b2tlbnNbbWF0Y2hbMV1dID0gbWF0Y2hbMl07XG4gIH1cblxuICByZXR1cm4gdG9rZW5zO1xufVxuXG5jb25zdCBwYXJhbWV0ZXJOYW1lUkUgPSAvXlshIyQlJicqK1xcLS5eX2B8fjAtOUEtWmEtel0rJC87XG5cbmZ1bmN0aW9uIHRyaW1PV1ModmFsdWUpIHtcbiAgbGV0IHN0YXJ0ID0gMDtcbiAgbGV0IGVuZCA9IHZhbHVlLmxlbmd0aDtcblxuICB3aGlsZSAoc3RhcnQgPCBlbmQpIHtcbiAgICBjb25zdCBjb2RlID0gdmFsdWUuY2hhckNvZGVBdChzdGFydCk7XG5cbiAgICBpZiAoY29kZSAhPT0gMHgwOSAmJiBjb2RlICE9PSAweDIwKSB7XG4gICAgICBicmVhaztcbiAgICB9XG5cbiAgICBzdGFydCArPSAxO1xuICB9XG5cbiAgd2hpbGUgKGVuZCA+IHN0YXJ0KSB7XG4gICAgY29uc3QgY29kZSA9IHZhbHVlLmNoYXJDb2RlQXQoZW5kIC0gMSk7XG5cbiAgICBpZiAoY29kZSAhPT0gMHgwOSAmJiBjb2RlICE9PSAweDIwKSB7XG4gICAgICBicmVhaztcbiAgICB9XG5cbiAgICBlbmQgLT0gMTtcbiAgfVxuXG4gIHJldHVybiBzdGFydCA9PT0gMCAmJiBlbmQgPT09IHZhbHVlLmxlbmd0aCA/IHZhbHVlIDogdmFsdWUuc2xpY2Uoc3RhcnQsIGVuZCk7XG59XG5cbmZ1bmN0aW9uIGRlY29kZVF1b3RlZFN0cmluZyh2YWx1ZSkge1xuICBjb25zdCBsYXN0ID0gdmFsdWUubGVuZ3RoIC0gMTtcblxuICBpZiAobGFzdCA8IDEgfHwgdmFsdWUuY2hhckNvZGVBdCgwKSAhPT0gMHgyMiB8fCB2YWx1ZS5jaGFyQ29kZUF0KGxhc3QpICE9PSAweDIyKSB7XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG5cbiAgbGV0IGRlY29kZWQgPSAnJztcblxuICBmb3IgKGxldCBpID0gMTsgaSA8IGxhc3Q7IGkrKykge1xuICAgIGNvbnN0IGNvZGUgPSB2YWx1ZS5jaGFyQ29kZUF0KGkpO1xuXG4gICAgaWYgKGNvZGUgPT09IDB4MjIpIHtcbiAgICAgIHJldHVybiB2YWx1ZTtcbiAgICB9XG5cbiAgICBpZiAoY29kZSA9PT0gMHg1Yykge1xuICAgICAgaSArPSAxO1xuXG4gICAgICBpZiAoaSA+PSBsYXN0KSB7XG4gICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBkZWNvZGVkICs9IHZhbHVlW2ldO1xuICB9XG5cbiAgcmV0dXJuIGRlY29kZWQ7XG59XG5cbmZ1bmN0aW9uIHBhcnNlUGFyYW1ldGVycyh2YWx1ZSkge1xuICBjb25zdCBwYXJhbWV0ZXJzID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgY29uc3Qgc3RyID0gU3RyaW5nKHZhbHVlKTtcbiAgbGV0IHN0YXJ0ID0gMDtcbiAgbGV0IHF1b3RlZCA9IGZhbHNlO1xuICBsZXQgZXNjYXBlZCA9IGZhbHNlO1xuXG4gIGZ1bmN0aW9uIHBhcnNlUGFyYW1ldGVyKGVuZCkge1xuICAgIGNvbnN0IHBhcnQgPSB0cmltT1dTKHN0ci5zbGljZShzdGFydCwgZW5kKSk7XG4gICAgY29uc3QgZXF1YWxzID0gcGFydC5pbmRleE9mKCc9Jyk7XG5cbiAgICBpZiAoZXF1YWxzIDwgMSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IG5hbWUgPSB0cmltT1dTKHBhcnQuc2xpY2UoMCwgZXF1YWxzKSk7XG5cbiAgICBpZiAoIXBhcmFtZXRlck5hbWVSRS50ZXN0KG5hbWUpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3Qgbm9ybWFsaXplZE5hbWUgPSBuYW1lLnRvTG93ZXJDYXNlKCk7XG5cbiAgICBpZiAoXG4gICAgICBub3JtYWxpemVkTmFtZSA9PT0gJ19fcHJvdG9fXycgfHxcbiAgICAgIG5vcm1hbGl6ZWROYW1lID09PSAnY29uc3RydWN0b3InIHx8XG4gICAgICBub3JtYWxpemVkTmFtZSA9PT0gJ3Byb3RvdHlwZSdcbiAgICApIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBwYXJhbWV0ZXJWYWx1ZSA9IHRyaW1PV1MocGFydC5zbGljZShlcXVhbHMgKyAxKSk7XG4gICAgcGFyYW1ldGVyc1tub3JtYWxpemVkTmFtZV0gPSBkZWNvZGVRdW90ZWRTdHJpbmcocGFyYW1ldGVyVmFsdWUpO1xuICB9XG5cbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBzdHIubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBjb2RlID0gc3RyLmNoYXJDb2RlQXQoaSk7XG5cbiAgICBpZiAocXVvdGVkKSB7XG4gICAgICBpZiAoZXNjYXBlZCkge1xuICAgICAgICBlc2NhcGVkID0gZmFsc2U7XG4gICAgICB9IGVsc2UgaWYgKGNvZGUgPT09IDB4NWMpIHtcbiAgICAgICAgZXNjYXBlZCA9IHRydWU7XG4gICAgICB9IGVsc2UgaWYgKGNvZGUgPT09IDB4MjIpIHtcbiAgICAgICAgcXVvdGVkID0gZmFsc2U7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChjb2RlID09PSAweDIyKSB7XG4gICAgICBxdW90ZWQgPSB0cnVlO1xuICAgIH0gZWxzZSBpZiAoY29kZSA9PT0gMHgyYyB8fCBjb2RlID09PSAweDNiKSB7XG4gICAgICBwYXJzZVBhcmFtZXRlcihpKTtcbiAgICAgIHN0YXJ0ID0gaSArIDE7XG4gICAgfVxuICB9XG5cbiAgcGFyc2VQYXJhbWV0ZXIoc3RyLmxlbmd0aCk7XG5cbiAgcmV0dXJuIHBhcmFtZXRlcnM7XG59XG5cbmNvbnN0IGlzVmFsaWRIZWFkZXJOYW1lID0gKHN0cikgPT4gL15bLV9hLXpBLVowLTleYHx+LCEjJCUmJyorLl0rJC8udGVzdChzdHIudHJpbSgpKTtcblxuZnVuY3Rpb24gbWF0Y2hIZWFkZXJWYWx1ZShjb250ZXh0LCB2YWx1ZSwgaGVhZGVyLCBmaWx0ZXIsIGlzSGVhZGVyTmFtZUZpbHRlcikge1xuICBpZiAodXRpbHMuaXNGdW5jdGlvbihmaWx0ZXIpKSB7XG4gICAgcmV0dXJuIGZpbHRlci5jYWxsKHRoaXMsIHZhbHVlLCBoZWFkZXIpO1xuICB9XG5cbiAgaWYgKGlzSGVhZGVyTmFtZUZpbHRlcikge1xuICAgIHZhbHVlID0gaGVhZGVyO1xuICB9XG5cbiAgaWYgKCF1dGlscy5pc1N0cmluZyh2YWx1ZSkpIHJldHVybjtcblxuICBpZiAodXRpbHMuaXNTdHJpbmcoZmlsdGVyKSkge1xuICAgIHJldHVybiB2YWx1ZS5pbmRleE9mKGZpbHRlcikgIT09IC0xO1xuICB9XG5cbiAgaWYgKHV0aWxzLmlzUmVnRXhwKGZpbHRlcikpIHtcbiAgICByZXR1cm4gZmlsdGVyLnRlc3QodmFsdWUpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGZvcm1hdEhlYWRlcihoZWFkZXIpIHtcbiAgcmV0dXJuIGhlYWRlclxuICAgIC50cmltKClcbiAgICAudG9Mb3dlckNhc2UoKVxuICAgIC5yZXBsYWNlKC8oW2EtelxcZF0pKFxcdyopL2csICh3LCBjaGFyLCBzdHIpID0+IHtcbiAgICAgIHJldHVybiBjaGFyLnRvVXBwZXJDYXNlKCkgKyBzdHI7XG4gICAgfSk7XG59XG5cbmZ1bmN0aW9uIGJ1aWxkQWNjZXNzb3JzKG9iaiwgaGVhZGVyKSB7XG4gIGNvbnN0IGFjY2Vzc29yTmFtZSA9IHV0aWxzLnRvQ2FtZWxDYXNlKCcgJyArIGhlYWRlcik7XG5cbiAgWydnZXQnLCAnc2V0JywgJ2hhcyddLmZvckVhY2goKG1ldGhvZE5hbWUpID0+IHtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkob2JqLCBtZXRob2ROYW1lICsgYWNjZXNzb3JOYW1lLCB7XG4gICAgICAvLyBOdWxsLXByb3RvIGRlc2NyaXB0b3Igc28gYSBwb2xsdXRlZCBPYmplY3QucHJvdG90eXBlLmdldCBjYW5ub3QgdHVyblxuICAgICAgLy8gdGhpcyBkYXRhIGRlc2NyaXB0b3IgaW50byBhbiBhY2Nlc3NvciBkZXNjcmlwdG9yIG9uIHRoZSB3YXkgaW4uXG4gICAgICBfX3Byb3RvX186IG51bGwsXG4gICAgICB2YWx1ZTogZnVuY3Rpb24gKGFyZzEsIGFyZzIsIGFyZzMpIHtcbiAgICAgICAgcmV0dXJuIHRoaXNbbWV0aG9kTmFtZV0uY2FsbCh0aGlzLCBoZWFkZXIsIGFyZzEsIGFyZzIsIGFyZzMpO1xuICAgICAgfSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICB9KTtcbiAgfSk7XG59XG5cbmNsYXNzIEF4aW9zSGVhZGVycyB7XG4gIGNvbnN0cnVjdG9yKGhlYWRlcnMpIHtcbiAgICBoZWFkZXJzICYmIHRoaXMuc2V0KGhlYWRlcnMpO1xuICB9XG5cbiAgc2V0KGhlYWRlciwgdmFsdWVPclJld3JpdGUsIHJld3JpdGUpIHtcbiAgICBjb25zdCBzZWxmID0gdGhpcztcblxuICAgIGZ1bmN0aW9uIHNldEhlYWRlcihfdmFsdWUsIF9oZWFkZXIsIF9yZXdyaXRlKSB7XG4gICAgICBjb25zdCBsSGVhZGVyID0gbm9ybWFsaXplSGVhZGVyKF9oZWFkZXIpO1xuXG4gICAgICBpZiAoIWxIZWFkZXIpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBrZXkgPSB1dGlscy5maW5kS2V5KHNlbGYsIGxIZWFkZXIpO1xuXG4gICAgICBpZiAoXG4gICAgICAgICFrZXkgfHxcbiAgICAgICAgc2VsZltrZXldID09PSB1bmRlZmluZWQgfHxcbiAgICAgICAgX3Jld3JpdGUgPT09IHRydWUgfHxcbiAgICAgICAgKF9yZXdyaXRlID09PSB1bmRlZmluZWQgJiYgc2VsZltrZXldICE9PSBmYWxzZSlcbiAgICAgICkge1xuICAgICAgICBzZWxmW2tleSB8fCBfaGVhZGVyXSA9IG5vcm1hbGl6ZVZhbHVlKF92YWx1ZSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc3Qgc2V0SGVhZGVycyA9IChoZWFkZXJzLCBfcmV3cml0ZSkgPT5cbiAgICAgIHV0aWxzLmZvckVhY2goaGVhZGVycywgKF92YWx1ZSwgX2hlYWRlcikgPT4gc2V0SGVhZGVyKF92YWx1ZSwgX2hlYWRlciwgX3Jld3JpdGUpKTtcblxuICAgIGlmICh1dGlscy5pc1BsYWluT2JqZWN0KGhlYWRlcikgfHwgaGVhZGVyIGluc3RhbmNlb2YgdGhpcy5jb25zdHJ1Y3Rvcikge1xuICAgICAgc2V0SGVhZGVycyhoZWFkZXIsIHZhbHVlT3JSZXdyaXRlKTtcbiAgICB9IGVsc2UgaWYgKHV0aWxzLmlzU3RyaW5nKGhlYWRlcikgJiYgKGhlYWRlciA9IGhlYWRlci50cmltKCkpICYmICFpc1ZhbGlkSGVhZGVyTmFtZShoZWFkZXIpKSB7XG4gICAgICBzZXRIZWFkZXJzKHBhcnNlSGVhZGVycyhoZWFkZXIpLCB2YWx1ZU9yUmV3cml0ZSk7XG4gICAgfSBlbHNlIGlmICh1dGlscy5pc09iamVjdChoZWFkZXIpICYmIHV0aWxzLmlzU2FmZUl0ZXJhYmxlKGhlYWRlcikpIHtcbiAgICAgIGxldCBvYmogPSBPYmplY3QuY3JlYXRlKG51bGwpLFxuICAgICAgICBkZXN0LFxuICAgICAgICBrZXk7XG4gICAgICBmb3IgKGNvbnN0IGVudHJ5IG9mIGhlYWRlcikge1xuICAgICAgICBpZiAoIXV0aWxzLmlzQXJyYXkoZW50cnkpKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignT2JqZWN0IGl0ZXJhdG9yIG11c3QgcmV0dXJuIGEga2V5LXZhbHVlIHBhaXInKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGtleSA9IGVudHJ5WzBdO1xuXG4gICAgICAgIGlmICh1dGlscy5oYXNPd25Qcm9wKG9iaiwga2V5KSkge1xuICAgICAgICAgIGRlc3QgPSBvYmpba2V5XTtcbiAgICAgICAgICBvYmpba2V5XSA9IHV0aWxzLmlzQXJyYXkoZGVzdCkgPyBbLi4uZGVzdCwgZW50cnlbMV1dIDogW2Rlc3QsIGVudHJ5WzFdXTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBvYmpba2V5XSA9IGVudHJ5WzFdO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHNldEhlYWRlcnMob2JqLCB2YWx1ZU9yUmV3cml0ZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGhlYWRlciAhPSBudWxsICYmIHNldEhlYWRlcih2YWx1ZU9yUmV3cml0ZSwgaGVhZGVyLCByZXdyaXRlKTtcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG4gIGdldChoZWFkZXIsIHBhcnNlcikge1xuICAgIGhlYWRlciA9IG5vcm1hbGl6ZUhlYWRlcihoZWFkZXIpO1xuXG4gICAgaWYgKGhlYWRlcikge1xuICAgICAgY29uc3Qga2V5ID0gdXRpbHMuZmluZEtleSh0aGlzLCBoZWFkZXIpO1xuXG4gICAgICBpZiAoa2V5KSB7XG4gICAgICAgIGNvbnN0IHZhbHVlID0gdGhpc1trZXldO1xuXG4gICAgICAgIGlmICghcGFyc2VyKSB7XG4gICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHBhcnNlciA9PT0gdHJ1ZSkge1xuICAgICAgICAgIHJldHVybiBwYXJzZVRva2Vucyh2YWx1ZSk7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAodXRpbHMuaXNGdW5jdGlvbihwYXJzZXIpKSB7XG4gICAgICAgICAgcmV0dXJuIHBhcnNlci5jYWxsKHRoaXMsIHZhbHVlLCBrZXkpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHV0aWxzLmlzUmVnRXhwKHBhcnNlcikpIHtcbiAgICAgICAgICByZXR1cm4gcGFyc2VyLmV4ZWModmFsdWUpO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcigncGFyc2VyIG11c3QgYmUgYm9vbGVhbnxyZWdleHB8ZnVuY3Rpb24nKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBoYXMoaGVhZGVyLCBtYXRjaGVyKSB7XG4gICAgaGVhZGVyID0gbm9ybWFsaXplSGVhZGVyKGhlYWRlcik7XG5cbiAgICBpZiAoaGVhZGVyKSB7XG4gICAgICBjb25zdCBrZXkgPSB1dGlscy5maW5kS2V5KHRoaXMsIGhlYWRlcik7XG5cbiAgICAgIHJldHVybiAhIShcbiAgICAgICAga2V5ICYmXG4gICAgICAgIHRoaXNba2V5XSAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICghbWF0Y2hlciB8fCBtYXRjaEhlYWRlclZhbHVlKHRoaXMsIHRoaXNba2V5XSwga2V5LCBtYXRjaGVyKSlcbiAgICAgICk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgZGVsZXRlKGhlYWRlciwgbWF0Y2hlcikge1xuICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuICAgIGxldCBkZWxldGVkID0gZmFsc2U7XG5cbiAgICBmdW5jdGlvbiBkZWxldGVIZWFkZXIoX2hlYWRlcikge1xuICAgICAgX2hlYWRlciA9IG5vcm1hbGl6ZUhlYWRlcihfaGVhZGVyKTtcblxuICAgICAgaWYgKF9oZWFkZXIpIHtcbiAgICAgICAgY29uc3Qga2V5ID0gdXRpbHMuZmluZEtleShzZWxmLCBfaGVhZGVyKTtcblxuICAgICAgICBpZiAoa2V5ICYmICghbWF0Y2hlciB8fCBtYXRjaEhlYWRlclZhbHVlKHNlbGYsIHNlbGZba2V5XSwga2V5LCBtYXRjaGVyKSkpIHtcbiAgICAgICAgICBkZWxldGUgc2VsZltrZXldO1xuXG4gICAgICAgICAgZGVsZXRlZCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAodXRpbHMuaXNBcnJheShoZWFkZXIpKSB7XG4gICAgICBoZWFkZXIuZm9yRWFjaChkZWxldGVIZWFkZXIpO1xuICAgIH0gZWxzZSB7XG4gICAgICBkZWxldGVIZWFkZXIoaGVhZGVyKTtcbiAgICB9XG5cbiAgICByZXR1cm4gZGVsZXRlZDtcbiAgfVxuXG4gIGNsZWFyKG1hdGNoZXIpIHtcbiAgICBjb25zdCBrZXlzID0gT2JqZWN0LmtleXModGhpcyk7XG4gICAgbGV0IGkgPSBrZXlzLmxlbmd0aDtcbiAgICBsZXQgZGVsZXRlZCA9IGZhbHNlO1xuXG4gICAgd2hpbGUgKGktLSkge1xuICAgICAgY29uc3Qga2V5ID0ga2V5c1tpXTtcbiAgICAgIGlmICghbWF0Y2hlciB8fCBtYXRjaEhlYWRlclZhbHVlKHRoaXMsIHRoaXNba2V5XSwga2V5LCBtYXRjaGVyLCB0cnVlKSkge1xuICAgICAgICBkZWxldGUgdGhpc1trZXldO1xuICAgICAgICBkZWxldGVkID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gZGVsZXRlZDtcbiAgfVxuXG4gIG5vcm1hbGl6ZShmb3JtYXQpIHtcbiAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICBjb25zdCBoZWFkZXJzID0ge307XG5cbiAgICB1dGlscy5mb3JFYWNoKHRoaXMsICh2YWx1ZSwgaGVhZGVyKSA9PiB7XG4gICAgICBjb25zdCBrZXkgPSB1dGlscy5maW5kS2V5KGhlYWRlcnMsIGhlYWRlcik7XG5cbiAgICAgIGlmIChrZXkpIHtcbiAgICAgICAgc2VsZltrZXldID0gbm9ybWFsaXplVmFsdWUodmFsdWUpO1xuICAgICAgICBkZWxldGUgc2VsZltoZWFkZXJdO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IG5vcm1hbGl6ZWQgPSBmb3JtYXQgPyBmb3JtYXRIZWFkZXIoaGVhZGVyKSA6IFN0cmluZyhoZWFkZXIpLnRyaW0oKTtcblxuICAgICAgaWYgKG5vcm1hbGl6ZWQgIT09IGhlYWRlcikge1xuICAgICAgICBkZWxldGUgc2VsZltoZWFkZXJdO1xuICAgICAgfVxuXG4gICAgICBzZWxmW25vcm1hbGl6ZWRdID0gbm9ybWFsaXplVmFsdWUodmFsdWUpO1xuXG4gICAgICBoZWFkZXJzW25vcm1hbGl6ZWRdID0gdHJ1ZTtcbiAgICB9KTtcblxuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgY29uY2F0KC4uLnRhcmdldHMpIHtcbiAgICByZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5jb25jYXQodGhpcywgLi4udGFyZ2V0cyk7XG4gIH1cblxuICB0b0pTT04oYXNTdHJpbmdzKSB7XG4gICAgY29uc3Qgb2JqID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcblxuICAgIHV0aWxzLmZvckVhY2godGhpcywgKHZhbHVlLCBoZWFkZXIpID0+IHtcbiAgICAgIHZhbHVlICE9IG51bGwgJiZcbiAgICAgICAgdmFsdWUgIT09IGZhbHNlICYmXG4gICAgICAgIChvYmpbaGVhZGVyXSA9IGFzU3RyaW5ncyAmJiB1dGlscy5pc0FycmF5KHZhbHVlKSA/IHZhbHVlLmpvaW4oJywgJykgOiB2YWx1ZSk7XG4gICAgfSk7XG5cbiAgICByZXR1cm4gb2JqO1xuICB9XG5cbiAgW1N5bWJvbC5pdGVyYXRvcl0oKSB7XG4gICAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHRoaXMudG9KU09OKCkpW1N5bWJvbC5pdGVyYXRvcl0oKTtcbiAgfVxuXG4gIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiBPYmplY3QuZW50cmllcyh0aGlzLnRvSlNPTigpKVxuICAgICAgLm1hcCgoW2hlYWRlciwgdmFsdWVdKSA9PiBoZWFkZXIgKyAnOiAnICsgdmFsdWUpXG4gICAgICAuam9pbignXFxuJyk7XG4gIH1cblxuICBnZXRTZXRDb29raWUoKSB7XG4gICAgY29uc3QgdmFsdWUgPSB0aGlzLmdldCgnc2V0LWNvb2tpZScpO1xuICAgIHJldHVybiB1dGlscy5pc0FycmF5KHZhbHVlKSA/IHZhbHVlIDogdmFsdWUgPT0gbnVsbCB8fCB2YWx1ZSA9PT0gZmFsc2UgPyBbXSA6IFt2YWx1ZV07XG4gIH1cblxuICBnZXQgW1N5bWJvbC50b1N0cmluZ1RhZ10oKSB7XG4gICAgcmV0dXJuICdBeGlvc0hlYWRlcnMnO1xuICB9XG5cbiAgc3RhdGljIGZyb20odGhpbmcpIHtcbiAgICByZXR1cm4gdGhpbmcgaW5zdGFuY2VvZiB0aGlzID8gdGhpbmcgOiBuZXcgdGhpcyh0aGluZyk7XG4gIH1cblxuICBzdGF0aWMgcGFyc2VQYXJhbWV0ZXJzKHZhbHVlKSB7XG4gICAgcmV0dXJuIHBhcnNlUGFyYW1ldGVycyh2YWx1ZSk7XG4gIH1cblxuICBzdGF0aWMgY29uY2F0KGZpcnN0LCAuLi50YXJnZXRzKSB7XG4gICAgY29uc3QgY29tcHV0ZWQgPSBuZXcgdGhpcyhmaXJzdCk7XG5cbiAgICB0YXJnZXRzLmZvckVhY2goKHRhcmdldCkgPT4gY29tcHV0ZWQuc2V0KHRhcmdldCkpO1xuXG4gICAgcmV0dXJuIGNvbXB1dGVkO1xuICB9XG5cbiAgc3RhdGljIGFjY2Vzc29yKGhlYWRlcikge1xuICAgIGNvbnN0IGludGVybmFscyA9XG4gICAgICAodGhpc1skaW50ZXJuYWxzXSA9XG4gICAgICB0aGlzWyRpbnRlcm5hbHNdID1cbiAgICAgICAge1xuICAgICAgICAgIGFjY2Vzc29yczoge30sXG4gICAgICAgIH0pO1xuXG4gICAgY29uc3QgYWNjZXNzb3JzID0gaW50ZXJuYWxzLmFjY2Vzc29ycztcbiAgICBjb25zdCBwcm90b3R5cGUgPSB0aGlzLnByb3RvdHlwZTtcblxuICAgIGZ1bmN0aW9uIGRlZmluZUFjY2Vzc29yKF9oZWFkZXIpIHtcbiAgICAgIGNvbnN0IGxIZWFkZXIgPSBub3JtYWxpemVIZWFkZXIoX2hlYWRlcik7XG5cbiAgICAgIGlmICghYWNjZXNzb3JzW2xIZWFkZXJdKSB7XG4gICAgICAgIGJ1aWxkQWNjZXNzb3JzKHByb3RvdHlwZSwgX2hlYWRlcik7XG4gICAgICAgIGFjY2Vzc29yc1tsSGVhZGVyXSA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuXG4gICAgdXRpbHMuaXNBcnJheShoZWFkZXIpID8gaGVhZGVyLmZvckVhY2goZGVmaW5lQWNjZXNzb3IpIDogZGVmaW5lQWNjZXNzb3IoaGVhZGVyKTtcblxuICAgIHJldHVybiB0aGlzO1xuICB9XG59XG5cbkF4aW9zSGVhZGVycy5hY2Nlc3NvcihbXG4gICdDb250ZW50LVR5cGUnLFxuICAnQ29udGVudC1MZW5ndGgnLFxuICAnQWNjZXB0JyxcbiAgJ0FjY2VwdC1FbmNvZGluZycsXG4gICdVc2VyLUFnZW50JyxcbiAgJ0F1dGhvcml6YXRpb24nLFxuXSk7XG5cbi8vIHJlc2VydmVkIG5hbWVzIGhvdGZpeFxudXRpbHMucmVkdWNlRGVzY3JpcHRvcnMoQXhpb3NIZWFkZXJzLnByb3RvdHlwZSwgKHsgdmFsdWUgfSwga2V5KSA9PiB7XG4gIGxldCBtYXBwZWQgPSBrZXlbMF0udG9VcHBlckNhc2UoKSArIGtleS5zbGljZSgxKTsgLy8gbWFwIGBzZXRgID0+IGBTZXRgXG4gIHJldHVybiB7XG4gICAgZ2V0OiAoKSA9PiB2YWx1ZSxcbiAgICBzZXQoaGVhZGVyVmFsdWUpIHtcbiAgICAgIHRoaXNbbWFwcGVkXSA9IGhlYWRlclZhbHVlO1xuICAgIH0sXG4gIH07XG59KTtcblxudXRpbHMuZnJlZXplTWV0aG9kcyhBeGlvc0hlYWRlcnMpO1xuXG5leHBvcnQgZGVmYXVsdCBBeGlvc0hlYWRlcnM7XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5pbXBvcnQgQXhpb3NIZWFkZXJzIGZyb20gJy4vQXhpb3NIZWFkZXJzLmpzJztcblxuZXhwb3J0IGNvbnN0IFJFREFDVEVEID0gJ1tSRURBQ1RFRCAqKioqXSc7XG5cbmZ1bmN0aW9uIGhhc093bk9yUHJvdG90eXBlVG9KU09OKHNvdXJjZSkge1xuICBpZiAodXRpbHMuaGFzT3duUHJvcChzb3VyY2UsICd0b0pTT04nKSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG5cbiAgbGV0IHByb3RvdHlwZSA9IE9iamVjdC5nZXRQcm90b3R5cGVPZihzb3VyY2UpO1xuXG4gIHdoaWxlIChwcm90b3R5cGUgJiYgcHJvdG90eXBlICE9PSBPYmplY3QucHJvdG90eXBlKSB7XG4gICAgaWYgKHV0aWxzLmhhc093blByb3AocHJvdG90eXBlLCAndG9KU09OJykpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cblxuICAgIHByb3RvdHlwZSA9IE9iamVjdC5nZXRQcm90b3R5cGVPZihwcm90b3R5cGUpO1xuICB9XG5cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG4vLyBCdWlsZCBhIHBsYWluLW9iamVjdCBzbmFwc2hvdCBvZiBgY29uZmlnYCBhbmQgcmVwbGFjZSB0aGUgdmFsdWUgb2YgYW55IGtleVxuLy8gKGNhc2UtaW5zZW5zaXRpdmUpIGxpc3RlZCBpbiBgcmVkYWN0S2V5c2Agd2l0aCBSRURBQ1RFRC4gV2Fsa3MgdGhyb3VnaCBhcnJheXNcbi8vIGFuZCBBeGlvc0hlYWRlcnMsIGFuZCBzaG9ydC1jaXJjdWl0cyBvbiBjaXJjdWxhciByZWZlcmVuY2VzLlxuZnVuY3Rpb24gcmVkYWN0Q29uZmlnKGNvbmZpZywgcmVkYWN0S2V5cykge1xuICBjb25zdCBsb3dlcktleXMgPSBuZXcgU2V0KHJlZGFjdEtleXMubWFwKChrKSA9PiBTdHJpbmcoaykudG9Mb3dlckNhc2UoKSkpO1xuICBjb25zdCBzZWVuID0gW107XG5cbiAgY29uc3QgdmlzaXQgPSAoc291cmNlKSA9PiB7XG4gICAgaWYgKHNvdXJjZSA9PT0gbnVsbCB8fCB0eXBlb2Ygc291cmNlICE9PSAnb2JqZWN0JykgcmV0dXJuIHNvdXJjZTtcbiAgICBpZiAodXRpbHMuaXNCdWZmZXIoc291cmNlKSkgcmV0dXJuIHNvdXJjZTtcbiAgICBpZiAoc2Vlbi5pbmRleE9mKHNvdXJjZSkgIT09IC0xKSByZXR1cm4gdW5kZWZpbmVkO1xuXG4gICAgaWYgKHNvdXJjZSBpbnN0YW5jZW9mIEF4aW9zSGVhZGVycykge1xuICAgICAgc291cmNlID0gc291cmNlLnRvSlNPTigpO1xuICAgIH1cblxuICAgIHNlZW4ucHVzaChzb3VyY2UpO1xuXG4gICAgbGV0IHJlc3VsdDtcbiAgICBpZiAodXRpbHMuaXNBcnJheShzb3VyY2UpKSB7XG4gICAgICByZXN1bHQgPSBbXTtcbiAgICAgIHNvdXJjZS5mb3JFYWNoKCh2LCBpKSA9PiB7XG4gICAgICAgIGNvbnN0IHJlZHVjZWRWYWx1ZSA9IHZpc2l0KHYpO1xuICAgICAgICBpZiAoIXV0aWxzLmlzVW5kZWZpbmVkKHJlZHVjZWRWYWx1ZSkpIHtcbiAgICAgICAgICByZXN1bHRbaV0gPSByZWR1Y2VkVmFsdWU7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoIXV0aWxzLmlzUGxhaW5PYmplY3Qoc291cmNlKSAmJiBoYXNPd25PclByb3RvdHlwZVRvSlNPTihzb3VyY2UpKSB7XG4gICAgICAgIHNlZW4ucG9wKCk7XG4gICAgICAgIHJldHVybiBzb3VyY2U7XG4gICAgICB9XG5cbiAgICAgIHJlc3VsdCA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgICBmb3IgKGNvbnN0IFtrZXksIHZhbHVlXSBvZiBPYmplY3QuZW50cmllcyhzb3VyY2UpKSB7XG4gICAgICAgIGNvbnN0IHJlZHVjZWRWYWx1ZSA9IGxvd2VyS2V5cy5oYXMoa2V5LnRvTG93ZXJDYXNlKCkpID8gUkVEQUNURUQgOiB2aXNpdCh2YWx1ZSk7XG4gICAgICAgIGlmICghdXRpbHMuaXNVbmRlZmluZWQocmVkdWNlZFZhbHVlKSkge1xuICAgICAgICAgIHJlc3VsdFtrZXldID0gcmVkdWNlZFZhbHVlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgc2Vlbi5wb3AoKTtcbiAgICByZXR1cm4gcmVzdWx0O1xuICB9O1xuXG4gIHJldHVybiB2aXNpdChjb25maWcpO1xufVxuXG5mdW5jdGlvbiBzdHJpbmdpZnlTYWZlbHkodmFsdWUpIHtcbiAgdHJ5IHtcbiAgICByZXR1cm4gU3RyaW5nKHZhbHVlKTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgcmV0dXJuICcnO1xuICB9XG59XG5cbmZ1bmN0aW9uIGFnZ3JlZ2F0ZUVycm9yTWVzc2FnZShlcnJvcikge1xuICBjb25zdCBtZXNzYWdlID0gZXJyb3IuZXJyb3JzXG4gICAgLm1hcCgoZW50cnkpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBlbnRyeSAmJiBlbnRyeS5tZXNzYWdlID8gc3RyaW5naWZ5U2FmZWx5KGVudHJ5Lm1lc3NhZ2UpIDogc3RyaW5naWZ5U2FmZWx5KGVudHJ5KTtcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICByZXR1cm4gJyc7XG4gICAgICB9XG4gICAgfSlcbiAgICAuZmlsdGVyKEJvb2xlYW4pXG4gICAgLmpvaW4oJzsgJyk7XG5cbiAgcmV0dXJuIG1lc3NhZ2UgfHwgZXJyb3IubmFtZSB8fCAnQWdncmVnYXRlRXJyb3InO1xufVxuXG5jbGFzcyBBeGlvc0Vycm9yIGV4dGVuZHMgRXJyb3Ige1xuICBzdGF0aWMgZnJvbShlcnJvciwgY29kZSwgY29uZmlnLCByZXF1ZXN0LCByZXNwb25zZSwgY3VzdG9tUHJvcHMpIHtcbiAgICAvLyBgQWdncmVnYXRlRXJyb3JgICh0aHJvd24gYnkgTm9kZSBvbiBkdWFsLXN0YWNrL0hhcHB5LUV5ZWJhbGxzIGNvbm5lY3Rpb25cbiAgICAvLyBmYWlsdXJlcykgaGFzIGFuIGVtcHR5IGBtZXNzYWdlYDsgaXRzIGRldGFpbCBsaXZlcyBpbiBgZXJyb3JzW11gLiBXaXRob3V0XG4gICAgLy8gdGhpcywgdGhlIHdyYXBwZWQgZXJyb3Igc3VyZmFjZXMgd2l0aCBhIGJsYW5rIG1lc3NhZ2UgKHNlZSAjNjcyMSkuXG4gICAgbGV0IG1lc3NhZ2UgPSBlcnJvci5tZXNzYWdlO1xuICAgIGlmICghbWVzc2FnZSAmJiB1dGlscy5pc0FycmF5KGVycm9yLmVycm9ycykgJiYgZXJyb3IuZXJyb3JzLmxlbmd0aCkge1xuICAgICAgbWVzc2FnZSA9IGFnZ3JlZ2F0ZUVycm9yTWVzc2FnZShlcnJvcik7XG4gICAgfVxuXG4gICAgY29uc3QgYXhpb3NFcnJvciA9IG5ldyBBeGlvc0Vycm9yKG1lc3NhZ2UsIGNvZGUgfHwgZXJyb3IuY29kZSwgY29uZmlnLCByZXF1ZXN0LCByZXNwb25zZSk7XG4gICAgLy8gTWF0Y2ggbmF0aXZlIGBFcnJvcmAgYGNhdXNlYCBzZW1hbnRpY3M6IG5vbi1lbnVtZXJhYmxlLiBUaGUgd3JhcHBlZFxuICAgIC8vIGVycm9yIG9mdGVuIGNhcnJpZXMgY2lyY3VsYXIgaW50ZXJuYWxzIChzb2NrZXRzLCByZXF1ZXN0cywgYWdlbnRzKSwgc29cbiAgICAvLyBhbiBlbnVtZXJhYmxlIGBjYXVzZWAgbWFrZXMgc3RydWN0dXJlZCBsb2dnZXJzIChwaW5vL3dpbnN0b24pIGFuZCBhbnlcbiAgICAvLyBvd24tcHJvcGVydHkgd2FsayB0aHJvdyBcIkNvbnZlcnRpbmcgY2lyY3VsYXIgc3RydWN0dXJlIHRvIEpTT05cIi5cbiAgICAvLyBSZWdyZXNzaW9uIGZyb20gIzY5ODI7IHNlZSAjNzIwNS4gYF9fcHJvdG9fXzogbnVsbGAgbWlycm9ycyB0aGVcbiAgICAvLyBgbWVzc2FnZWAgZGVzY3JpcHRvciBiZWxvdyAocHJvdG90eXBlLXBvbGx1dGlvbi1zYWZlIGRlc2NyaXB0b3IpLlxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShheGlvc0Vycm9yLCAnY2F1c2UnLCB7XG4gICAgICBfX3Byb3RvX186IG51bGwsXG4gICAgICB2YWx1ZTogZXJyb3IsXG4gICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgIH0pO1xuICAgIGF4aW9zRXJyb3IubmFtZSA9IGVycm9yLm5hbWU7XG5cbiAgICAvLyBQcmVzZXJ2ZSBzdGF0dXMgZnJvbSB0aGUgb3JpZ2luYWwgZXJyb3IgaWYgbm90IGFscmVhZHkgc2V0IGZyb20gcmVzcG9uc2VcbiAgICBpZiAoZXJyb3Iuc3RhdHVzICE9IG51bGwgJiYgYXhpb3NFcnJvci5zdGF0dXMgPT0gbnVsbCkge1xuICAgICAgYXhpb3NFcnJvci5zdGF0dXMgPSBlcnJvci5zdGF0dXM7XG4gICAgfVxuXG4gICAgY3VzdG9tUHJvcHMgJiYgT2JqZWN0LmFzc2lnbihheGlvc0Vycm9yLCBjdXN0b21Qcm9wcyk7XG4gICAgcmV0dXJuIGF4aW9zRXJyb3I7XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlIGFuIEVycm9yIHdpdGggdGhlIHNwZWNpZmllZCBtZXNzYWdlLCBjb25maWcsIGVycm9yIGNvZGUsIHJlcXVlc3QgYW5kIHJlc3BvbnNlLlxuICAgKlxuICAgKiBAcGFyYW0ge3N0cmluZ30gbWVzc2FnZSBUaGUgZXJyb3IgbWVzc2FnZS5cbiAgICogQHBhcmFtIHtzdHJpbmd9IFtjb2RlXSBUaGUgZXJyb3IgY29kZSAoZm9yIGV4YW1wbGUsICdFQ09OTkFCT1JURUQnKS5cbiAgICogQHBhcmFtIHtPYmplY3R9IFtjb25maWddIFRoZSBjb25maWcuXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBbcmVxdWVzdF0gVGhlIHJlcXVlc3QuXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBbcmVzcG9uc2VdIFRoZSByZXNwb25zZS5cbiAgICpcbiAgICogQHJldHVybnMge0Vycm9yfSBUaGUgY3JlYXRlZCBlcnJvci5cbiAgICovXG4gIGNvbnN0cnVjdG9yKG1lc3NhZ2UsIGNvZGUsIGNvbmZpZywgcmVxdWVzdCwgcmVzcG9uc2UpIHtcbiAgICBzdXBlcihtZXNzYWdlKTtcblxuICAgIC8vIE1ha2UgbWVzc2FnZSBlbnVtZXJhYmxlIHRvIG1haW50YWluIGJhY2t3YXJkIGNvbXBhdGliaWxpdHlcbiAgICAvLyBUaGUgbmF0aXZlIEVycm9yIGNvbnN0cnVjdG9yIHNldHMgbWVzc2FnZSBhcyBub24tZW51bWVyYWJsZSxcbiAgICAvLyBidXQgYXhpb3MgPCB2MS4xMy4zIGhhZCBpdCBhcyBlbnVtZXJhYmxlXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsICdtZXNzYWdlJywge1xuICAgICAgLy8gTnVsbC1wcm90byBkZXNjcmlwdG9yIHNvIGEgcG9sbHV0ZWQgT2JqZWN0LnByb3RvdHlwZS5nZXQgY2Fubm90IHR1cm5cbiAgICAgIC8vIHRoaXMgZGF0YSBkZXNjcmlwdG9yIGludG8gYW4gYWNjZXNzb3IgZGVzY3JpcHRvciBvbiB0aGUgd2F5IGluLlxuICAgICAgX19wcm90b19fOiBudWxsLFxuICAgICAgdmFsdWU6IG1lc3NhZ2UsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgfSk7XG5cbiAgICB0aGlzLm5hbWUgPSAnQXhpb3NFcnJvcic7XG4gICAgdGhpcy5pc0F4aW9zRXJyb3IgPSB0cnVlO1xuICAgIGNvZGUgJiYgKHRoaXMuY29kZSA9IGNvZGUpO1xuICAgIGNvbmZpZyAmJiAodGhpcy5jb25maWcgPSBjb25maWcpO1xuICAgIHJlcXVlc3QgJiYgKHRoaXMucmVxdWVzdCA9IHJlcXVlc3QpO1xuICAgIGlmIChyZXNwb25zZSkge1xuICAgICAgdGhpcy5yZXNwb25zZSA9IHJlc3BvbnNlO1xuICAgICAgdGhpcy5zdGF0dXMgPSByZXNwb25zZS5zdGF0dXM7XG4gICAgfVxuICB9XG5cbiAgdG9KU09OKCkge1xuICAgIC8vIE9wdC1pbiByZWRhY3Rpb246IHdoZW4gdGhlIHJlcXVlc3QgY29uZmlnIGNhcnJpZXMgYSBgcmVkYWN0YCBhcnJheSwgdGhlXG4gICAgLy8gdmFsdWUgb2YgYW55IG1hdGNoaW5nIGtleSAoY2FzZS1pbnNlbnNpdGl2ZSwgYXQgYW55IGRlcHRoKSBpcyByZXBsYWNlZFxuICAgIC8vIHdpdGggUkVEQUNURUQgaW4gdGhlIHNlcmlhbGl6ZWQgc25hcHNob3QuIFVuZGVmaW5lZCBvciBlbXB0eSBsZWF2ZXMgdGhlXG4gICAgLy8gZXhpc3Rpbmcgc2VyaWFsaXphdGlvbiBiZWhhdmlvciB1bmNoYW5nZWQuXG4gICAgY29uc3QgY29uZmlnID0gdGhpcy5jb25maWc7XG4gICAgY29uc3QgcmVkYWN0S2V5cyA9IGNvbmZpZyAmJiB1dGlscy5oYXNPd25Qcm9wKGNvbmZpZywgJ3JlZGFjdCcpID8gY29uZmlnLnJlZGFjdCA6IHVuZGVmaW5lZDtcbiAgICBjb25zdCBzZXJpYWxpemVkQ29uZmlnID1cbiAgICAgIHV0aWxzLmlzQXJyYXkocmVkYWN0S2V5cykgJiYgcmVkYWN0S2V5cy5sZW5ndGggPiAwXG4gICAgICAgID8gcmVkYWN0Q29uZmlnKGNvbmZpZywgcmVkYWN0S2V5cylcbiAgICAgICAgOiB1dGlscy50b0pTT05PYmplY3QoY29uZmlnKTtcblxuICAgIHJldHVybiB7XG4gICAgICAvLyBTdGFuZGFyZFxuICAgICAgbWVzc2FnZTogdGhpcy5tZXNzYWdlLFxuICAgICAgbmFtZTogdGhpcy5uYW1lLFxuICAgICAgLy8gTWljcm9zb2Z0XG4gICAgICBkZXNjcmlwdGlvbjogdGhpcy5kZXNjcmlwdGlvbixcbiAgICAgIG51bWJlcjogdGhpcy5udW1iZXIsXG4gICAgICAvLyBNb3ppbGxhXG4gICAgICBmaWxlTmFtZTogdGhpcy5maWxlTmFtZSxcbiAgICAgIGxpbmVOdW1iZXI6IHRoaXMubGluZU51bWJlcixcbiAgICAgIGNvbHVtbk51bWJlcjogdGhpcy5jb2x1bW5OdW1iZXIsXG4gICAgICBzdGFjazogdGhpcy5zdGFjayxcbiAgICAgIC8vIEF4aW9zXG4gICAgICBjb25maWc6IHNlcmlhbGl6ZWRDb25maWcsXG4gICAgICBjb2RlOiB0aGlzLmNvZGUsXG4gICAgICBzdGF0dXM6IHRoaXMuc3RhdHVzLFxuICAgIH07XG4gIH1cbn1cblxuLy8gVGhpcyBjYW4gYmUgY2hhbmdlZCB0byBzdGF0aWMgcHJvcGVydGllcyBhcyBzb29uIGFzIHRoZSBwYXJzZXIgb3B0aW9ucyBpbiAuZXNsaW50LmNqcyBhcmUgdXBkYXRlZC5cbkF4aW9zRXJyb3IuRVJSX0JBRF9PUFRJT05fVkFMVUUgPSAnRVJSX0JBRF9PUFRJT05fVkFMVUUnO1xuQXhpb3NFcnJvci5FUlJfQkFEX09QVElPTiA9ICdFUlJfQkFEX09QVElPTic7XG5BeGlvc0Vycm9yLkVDT05OQUJPUlRFRCA9ICdFQ09OTkFCT1JURUQnO1xuQXhpb3NFcnJvci5FVElNRURPVVQgPSAnRVRJTUVET1VUJztcbkF4aW9zRXJyb3IuRUNPTk5SRUZVU0VEID0gJ0VDT05OUkVGVVNFRCc7XG5BeGlvc0Vycm9yLkVSUl9ORVRXT1JLID0gJ0VSUl9ORVRXT1JLJztcbkF4aW9zRXJyb3IuRVJSX0ZSX1RPT19NQU5ZX1JFRElSRUNUUyA9ICdFUlJfRlJfVE9PX01BTllfUkVESVJFQ1RTJztcbkF4aW9zRXJyb3IuRVJSX0RFUFJFQ0FURUQgPSAnRVJSX0RFUFJFQ0FURUQnO1xuQXhpb3NFcnJvci5FUlJfQkFEX1JFU1BPTlNFID0gJ0VSUl9CQURfUkVTUE9OU0UnO1xuQXhpb3NFcnJvci5FUlJfQkFEX1JFUVVFU1QgPSAnRVJSX0JBRF9SRVFVRVNUJztcbkF4aW9zRXJyb3IuRVJSX0NBTkNFTEVEID0gJ0VSUl9DQU5DRUxFRCc7XG5BeGlvc0Vycm9yLkVSUl9OT1RfU1VQUE9SVCA9ICdFUlJfTk9UX1NVUFBPUlQnO1xuQXhpb3NFcnJvci5FUlJfSU5WQUxJRF9VUkwgPSAnRVJSX0lOVkFMSURfVVJMJztcbkF4aW9zRXJyb3IuRVJSX0ZPUk1fREFUQV9ERVBUSF9FWENFRURFRCA9ICdFUlJfRk9STV9EQVRBX0RFUFRIX0VYQ0VFREVEJztcblxuZXhwb3J0IGRlZmF1bHQgQXhpb3NFcnJvcjtcbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCBBeGlvc0Vycm9yIGZyb20gJy4uL2NvcmUvQXhpb3NFcnJvci5qcyc7XG4vLyB0ZW1wb3JhcnkgaG90Zml4IHRvIGF2b2lkIGNpcmN1bGFyIHJlZmVyZW5jZXMgdW50aWwgQXhpb3NVUkxTZWFyY2hQYXJhbXMgaXMgcmVmYWN0b3JlZFxuaW1wb3J0IFBsYXRmb3JtRm9ybURhdGEgZnJvbSAnLi4vcGxhdGZvcm0vbm9kZS9jbGFzc2VzL0Zvcm1EYXRhLmpzJztcbmltcG9ydCBQbGF0Zm9ybUJ1ZmZlciBmcm9tICcuLi9wbGF0Zm9ybS9ub2RlL2NsYXNzZXMvQnVmZmVyLmpzJztcblxuLy8gRGVmYXVsdCBuZXN0aW5nIGxpbWl0IHNoYXJlZCB3aXRoIHRoZSBpbnZlcnNlIHRyYW5zZm9ybSAoZm9ybURhdGFUb0pTT04pIHNvXG4vLyB0aGUgRm9ybURhdGEgPC0+IEpTT04gcm91bmQtdHJpcCBzdGF5cyBzeW1tZXRyaWMuXG5leHBvcnQgY29uc3QgREVGQVVMVF9GT1JNX0RBVEFfTUFYX0RFUFRIID0gMTAwO1xuXG4vKipcbiAqIERldGVybWluZXMgaWYgdGhlIGdpdmVuIHRoaW5nIGlzIGEgYXJyYXkgb3IganMgb2JqZWN0LlxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSB0aGluZyAtIFRoZSBvYmplY3Qgb3IgYXJyYXkgdG8gYmUgdmlzaXRlZC5cbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAqL1xuZnVuY3Rpb24gaXNWaXNpdGFibGUodGhpbmcpIHtcbiAgcmV0dXJuIHV0aWxzLmlzUGxhaW5PYmplY3QodGhpbmcpIHx8IHV0aWxzLmlzQXJyYXkodGhpbmcpO1xufVxuXG4vKipcbiAqIEl0IHJlbW92ZXMgdGhlIGJyYWNrZXRzIGZyb20gdGhlIGVuZCBvZiBhIHN0cmluZ1xuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSBrZXkgLSBUaGUga2V5IG9mIHRoZSBwYXJhbWV0ZXIuXG4gKlxuICogQHJldHVybnMge3N0cmluZ30gdGhlIGtleSB3aXRob3V0IHRoZSBicmFja2V0cy5cbiAqL1xuZnVuY3Rpb24gcmVtb3ZlQnJhY2tldHMoa2V5KSB7XG4gIHJldHVybiB1dGlscy5lbmRzV2l0aChrZXksICdbXScpID8ga2V5LnNsaWNlKDAsIC0yKSA6IGtleTtcbn1cblxuLyoqXG4gKiBJdCB0YWtlcyBhIHBhdGgsIGEga2V5LCBhbmQgYSBib29sZWFuLCBhbmQgcmV0dXJucyBhIHN0cmluZ1xuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSBwYXRoIC0gVGhlIHBhdGggdG8gdGhlIGN1cnJlbnQga2V5LlxuICogQHBhcmFtIHtzdHJpbmd9IGtleSAtIFRoZSBrZXkgb2YgdGhlIGN1cnJlbnQgb2JqZWN0IGJlaW5nIGl0ZXJhdGVkIG92ZXIuXG4gKiBAcGFyYW0ge3N0cmluZ30gZG90cyAtIElmIHRydWUsIHRoZSBrZXkgd2lsbCBiZSByZW5kZXJlZCB3aXRoIGRvdHMgaW5zdGVhZCBvZiBicmFja2V0cy5cbiAqXG4gKiBAcmV0dXJucyB7c3RyaW5nfSBUaGUgcGF0aCB0byB0aGUgY3VycmVudCBrZXkuXG4gKi9cbmZ1bmN0aW9uIHJlbmRlcktleShwYXRoLCBrZXksIGRvdHMpIHtcbiAgaWYgKCFwYXRoKSByZXR1cm4ga2V5O1xuICByZXR1cm4gcGF0aFxuICAgIC5jb25jYXQoa2V5KVxuICAgIC5tYXAoZnVuY3Rpb24gZWFjaCh0b2tlbiwgaSkge1xuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXBhcmFtLXJlYXNzaWduXG4gICAgICB0b2tlbiA9IHJlbW92ZUJyYWNrZXRzKHRva2VuKTtcbiAgICAgIHJldHVybiAhZG90cyAmJiBpID8gJ1snICsgdG9rZW4gKyAnXScgOiB0b2tlbjtcbiAgICB9KVxuICAgIC5qb2luKGRvdHMgPyAnLicgOiAnJyk7XG59XG5cbi8qKlxuICogSWYgdGhlIGFycmF5IGlzIGFuIGFycmF5IGFuZCBub25lIG9mIGl0cyBlbGVtZW50cyBhcmUgdmlzaXRhYmxlLCB0aGVuIGl0J3MgYSBmbGF0IGFycmF5LlxuICpcbiAqIEBwYXJhbSB7QXJyYXk8YW55Pn0gYXJyIC0gVGhlIGFycmF5IHRvIGNoZWNrXG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59XG4gKi9cbmZ1bmN0aW9uIGlzRmxhdEFycmF5KGFycikge1xuICByZXR1cm4gdXRpbHMuaXNBcnJheShhcnIpICYmICFhcnIuc29tZShpc1Zpc2l0YWJsZSk7XG59XG5cbmNvbnN0IHByZWRpY2F0ZXMgPSB1dGlscy50b0ZsYXRPYmplY3QodXRpbHMsIHt9LCBudWxsLCBmdW5jdGlvbiBmaWx0ZXIocHJvcCkge1xuICByZXR1cm4gL15pc1tBLVpdLy50ZXN0KHByb3ApO1xufSk7XG5cbi8qKlxuICogQ29udmVydCBhIGRhdGEgb2JqZWN0IHRvIEZvcm1EYXRhXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IG9ialxuICogQHBhcmFtIHs/T2JqZWN0fSBbZm9ybURhdGFdXG4gKiBAcGFyYW0gez9PYmplY3R9IFtvcHRpb25zXVxuICogQHBhcmFtIHtGdW5jdGlvbn0gW29wdGlvbnMudmlzaXRvcl1cbiAqIEBwYXJhbSB7Qm9vbGVhbn0gW29wdGlvbnMubWV0YVRva2VucyA9IHRydWVdXG4gKiBAcGFyYW0ge0Jvb2xlYW59IFtvcHRpb25zLmRvdHMgPSBmYWxzZV1cbiAqIEBwYXJhbSB7P0Jvb2xlYW59IFtvcHRpb25zLmluZGV4ZXMgPSBmYWxzZV1cbiAqXG4gKiBAcmV0dXJucyB7T2JqZWN0fVxuICoqL1xuXG4vKipcbiAqIEl0IGNvbnZlcnRzIGFuIG9iamVjdCBpbnRvIGEgRm9ybURhdGEgb2JqZWN0XG4gKlxuICogQHBhcmFtIHtPYmplY3Q8YW55LCBhbnk+fSBvYmogLSBUaGUgb2JqZWN0IHRvIGNvbnZlcnQgdG8gZm9ybSBkYXRhLlxuICogQHBhcmFtIHtzdHJpbmd9IGZvcm1EYXRhIC0gVGhlIEZvcm1EYXRhIG9iamVjdCB0byBhcHBlbmQgdG8uXG4gKiBAcGFyYW0ge09iamVjdDxzdHJpbmcsIGFueT59IG9wdGlvbnNcbiAqXG4gKiBAcmV0dXJuc1xuICovXG5mdW5jdGlvbiB0b0Zvcm1EYXRhKG9iaiwgZm9ybURhdGEsIG9wdGlvbnMpIHtcbiAgaWYgKCF1dGlscy5pc09iamVjdChvYmopKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcigndGFyZ2V0IG11c3QgYmUgYW4gb2JqZWN0Jyk7XG4gIH1cblxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tcGFyYW0tcmVhc3NpZ25cbiAgZm9ybURhdGEgPSBmb3JtRGF0YSB8fCBuZXcgKFBsYXRmb3JtRm9ybURhdGEgfHwgRm9ybURhdGEpKCk7XG5cbiAgY29uc3Qgb3B0aW9uID0gKG5hbWUsIGZhbGxiYWNrKSA9PiB7XG4gICAgY29uc3QgdmFsdWUgPSB1dGlscy5nZXRTYWZlUHJvcChvcHRpb25zLCBuYW1lKTtcbiAgICByZXR1cm4gdXRpbHMuaXNVbmRlZmluZWQodmFsdWUpID8gZmFsbGJhY2sgOiB2YWx1ZTtcbiAgfTtcblxuICBjb25zdCBtZXRhVG9rZW5zID0gb3B0aW9uKCdtZXRhVG9rZW5zJywgdHJ1ZSk7XG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby11c2UtYmVmb3JlLWRlZmluZVxuICBjb25zdCB2aXNpdG9yID0gb3B0aW9uKCd2aXNpdG9yJykgfHwgZGVmYXVsdFZpc2l0b3I7XG4gIGNvbnN0IGRvdHMgPSBvcHRpb24oJ2RvdHMnLCBmYWxzZSk7XG4gIGNvbnN0IGluZGV4ZXMgPSBvcHRpb24oJ2luZGV4ZXMnLCBmYWxzZSk7XG4gIGNvbnN0IF9CbG9iID0gb3B0aW9uKCdCbG9iJykgfHwgKHR5cGVvZiBCbG9iICE9PSAndW5kZWZpbmVkJyAmJiBCbG9iKTtcbiAgY29uc3QgbWF4RGVwdGggPSBvcHRpb24oJ21heERlcHRoJywgREVGQVVMVF9GT1JNX0RBVEFfTUFYX0RFUFRIKTtcbiAgY29uc3QgdXNlQmxvYiA9IF9CbG9iICYmIHV0aWxzLmlzU3BlY0NvbXBsaWFudEZvcm0oZm9ybURhdGEpO1xuICBjb25zdCBzdGFjayA9IFtdO1xuXG4gIGlmICghdXRpbHMuaXNGdW5jdGlvbih2aXNpdG9yKSkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ3Zpc2l0b3IgbXVzdCBiZSBhIGZ1bmN0aW9uJyk7XG4gIH1cblxuICBmdW5jdGlvbiBjb252ZXJ0VmFsdWUodmFsdWUpIHtcbiAgICBpZiAodmFsdWUgPT09IG51bGwpIHJldHVybiAnJztcblxuICAgIGlmICh1dGlscy5pc0RhdGUodmFsdWUpKSB7XG4gICAgICByZXR1cm4gdmFsdWUudG9JU09TdHJpbmcoKTtcbiAgICB9XG5cbiAgICBpZiAodXRpbHMuaXNCb29sZWFuKHZhbHVlKSkge1xuICAgICAgcmV0dXJuIHZhbHVlLnRvU3RyaW5nKCk7XG4gICAgfVxuXG4gICAgaWYgKCF1c2VCbG9iICYmIHV0aWxzLmlzQmxvYih2YWx1ZSkpIHtcbiAgICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKCdCbG9iIGlzIG5vdCBzdXBwb3J0ZWQuIFVzZSBhIEJ1ZmZlciBpbnN0ZWFkLicpO1xuICAgIH1cblxuICAgIGlmICh1dGlscy5pc0FycmF5QnVmZmVyKHZhbHVlKSB8fCB1dGlscy5pc1R5cGVkQXJyYXkodmFsdWUpKSB7XG4gICAgICBpZiAodXNlQmxvYiAmJiB0eXBlb2YgX0Jsb2IgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBfQmxvYihbdmFsdWVdKTtcbiAgICAgIH1cbiAgICAgIGlmIChQbGF0Zm9ybUJ1ZmZlciAmJiBQbGF0Zm9ybUJ1ZmZlci5pc0J1ZmZlckF2YWlsYWJsZSgpKSB7XG4gICAgICAgIHJldHVybiBQbGF0Zm9ybUJ1ZmZlci5mcm9tKHZhbHVlKTtcbiAgICAgIH1cbiAgICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKFxuICAgICAgICAnQmxvYiBpcyBub3Qgc3VwcG9ydGVkLiBVc2UgYSBCdWZmZXIgaW5zdGVhZC4nLFxuICAgICAgICBBeGlvc0Vycm9yLkVSUl9OT1RfU1VQUE9SVFxuICAgICAgKTtcbiAgICB9XG5cbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cblxuICBmdW5jdGlvbiB0aHJvd0lmTWF4RGVwdGhFeGNlZWRlZChkZXB0aCkge1xuICAgIGlmIChkZXB0aCA+IG1heERlcHRoKSB7XG4gICAgICB0aHJvdyBuZXcgQXhpb3NFcnJvcihcbiAgICAgICAgJ09iamVjdCBpcyB0b28gZGVlcGx5IG5lc3RlZCAoJyArIGRlcHRoICsgJyBsZXZlbHMpLiBNYXggZGVwdGg6ICcgKyBtYXhEZXB0aCxcbiAgICAgICAgQXhpb3NFcnJvci5FUlJfRk9STV9EQVRBX0RFUFRIX0VYQ0VFREVEXG4gICAgICApO1xuICAgIH1cbiAgfVxuXG4gIGZ1bmN0aW9uIHN0cmluZ2lmeVdpdGhEZXB0aExpbWl0KHZhbHVlLCBkZXB0aCkge1xuICAgIGlmIChtYXhEZXB0aCA9PT0gSW5maW5pdHkpIHtcbiAgICAgIHJldHVybiBKU09OLnN0cmluZ2lmeSh2YWx1ZSk7XG4gICAgfVxuXG4gICAgY29uc3QgYW5jZXN0b3JzID0gW107XG5cbiAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkodmFsdWUsIGZ1bmN0aW9uIGxpbWl0RGVwdGgoX2tleSwgY3VycmVudFZhbHVlKSB7XG4gICAgICBpZiAoIXV0aWxzLmlzT2JqZWN0KGN1cnJlbnRWYWx1ZSkpIHtcbiAgICAgICAgcmV0dXJuIGN1cnJlbnRWYWx1ZTtcbiAgICAgIH1cblxuICAgICAgd2hpbGUgKGFuY2VzdG9ycy5sZW5ndGggJiYgYW5jZXN0b3JzW2FuY2VzdG9ycy5sZW5ndGggLSAxXSAhPT0gdGhpcykge1xuICAgICAgICBhbmNlc3RvcnMucG9wKCk7XG4gICAgICB9XG5cbiAgICAgIGFuY2VzdG9ycy5wdXNoKGN1cnJlbnRWYWx1ZSk7XG4gICAgICB0aHJvd0lmTWF4RGVwdGhFeGNlZWRlZChkZXB0aCArIGFuY2VzdG9ycy5sZW5ndGggLSAxKTtcblxuICAgICAgcmV0dXJuIGN1cnJlbnRWYWx1ZTtcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWZhdWx0IHZpc2l0b3IuXG4gICAqXG4gICAqIEBwYXJhbSB7Kn0gdmFsdWVcbiAgICogQHBhcmFtIHtTdHJpbmd8TnVtYmVyfSBrZXlcbiAgICogQHBhcmFtIHtBcnJheTxTdHJpbmd8TnVtYmVyPn0gcGF0aFxuICAgKiBAdGhpcyB7Rm9ybURhdGF9XG4gICAqXG4gICAqIEByZXR1cm5zIHtib29sZWFufSByZXR1cm4gdHJ1ZSB0byB2aXNpdCB0aGUgZWFjaCBwcm9wIG9mIHRoZSB2YWx1ZSByZWN1cnNpdmVseVxuICAgKi9cbiAgZnVuY3Rpb24gZGVmYXVsdFZpc2l0b3IodmFsdWUsIGtleSwgcGF0aCkge1xuICAgIGxldCBhcnIgPSB2YWx1ZTtcblxuICAgIGlmICh1dGlscy5pc1JlYWN0TmF0aXZlKGZvcm1EYXRhKSAmJiB1dGlscy5pc1JlYWN0TmF0aXZlQmxvYih2YWx1ZSkpIHtcbiAgICAgIGZvcm1EYXRhLmFwcGVuZChyZW5kZXJLZXkocGF0aCwga2V5LCBkb3RzKSwgY29udmVydFZhbHVlKHZhbHVlKSk7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgaWYgKHZhbHVlICYmICFwYXRoICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcpIHtcbiAgICAgIGlmICh1dGlscy5lbmRzV2l0aChrZXksICd7fScpKSB7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1wYXJhbS1yZWFzc2lnblxuICAgICAgICBrZXkgPSBtZXRhVG9rZW5zID8ga2V5IDoga2V5LnNsaWNlKDAsIC0yKTtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXBhcmFtLXJlYXNzaWduXG4gICAgICAgIHZhbHVlID0gc3RyaW5naWZ5V2l0aERlcHRoTGltaXQodmFsdWUsIDEpO1xuICAgICAgfSBlbHNlIGlmIChcbiAgICAgICAgKHV0aWxzLmlzQXJyYXkodmFsdWUpICYmIGlzRmxhdEFycmF5KHZhbHVlKSkgfHxcbiAgICAgICAgKCh1dGlscy5pc0ZpbGVMaXN0KHZhbHVlKSB8fCB1dGlscy5lbmRzV2l0aChrZXksICdbXScpKSAmJiAoYXJyID0gdXRpbHMudG9BcnJheSh2YWx1ZSkpKVxuICAgICAgKSB7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1wYXJhbS1yZWFzc2lnblxuICAgICAgICBrZXkgPSByZW1vdmVCcmFja2V0cyhrZXkpO1xuXG4gICAgICAgIGFyci5mb3JFYWNoKGZ1bmN0aW9uIGVhY2goZWwsIGluZGV4KSB7XG4gICAgICAgICAgISh1dGlscy5pc1VuZGVmaW5lZChlbCkgfHwgZWwgPT09IG51bGwpICYmXG4gICAgICAgICAgICBmb3JtRGF0YS5hcHBlbmQoXG4gICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1uZXN0ZWQtdGVybmFyeVxuICAgICAgICAgICAgICBpbmRleGVzID09PSB0cnVlXG4gICAgICAgICAgICAgICAgPyByZW5kZXJLZXkoW2tleV0sIGluZGV4LCBkb3RzKVxuICAgICAgICAgICAgICAgIDogaW5kZXhlcyA9PT0gbnVsbFxuICAgICAgICAgICAgICAgICAgPyBrZXlcbiAgICAgICAgICAgICAgICAgIDoga2V5ICsgJ1tdJyxcbiAgICAgICAgICAgICAgY29udmVydFZhbHVlKGVsKVxuICAgICAgICAgICAgKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoaXNWaXNpdGFibGUodmFsdWUpKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG5cbiAgICBmb3JtRGF0YS5hcHBlbmQocmVuZGVyS2V5KHBhdGgsIGtleSwgZG90cyksIGNvbnZlcnRWYWx1ZSh2YWx1ZSkpO1xuXG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgY29uc3QgZXhwb3NlZEhlbHBlcnMgPSBPYmplY3QuYXNzaWduKHByZWRpY2F0ZXMsIHtcbiAgICBkZWZhdWx0VmlzaXRvcixcbiAgICBjb252ZXJ0VmFsdWUsXG4gICAgaXNWaXNpdGFibGUsXG4gIH0pO1xuXG4gIGZ1bmN0aW9uIGJ1aWxkKHZhbHVlLCBwYXRoLCBkZXB0aCA9IDApIHtcbiAgICBpZiAodXRpbHMuaXNVbmRlZmluZWQodmFsdWUpKSByZXR1cm47XG5cbiAgICB0aHJvd0lmTWF4RGVwdGhFeGNlZWRlZChkZXB0aCk7XG5cbiAgICBpZiAoc3RhY2suaW5kZXhPZih2YWx1ZSkgIT09IC0xKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0NpcmN1bGFyIHJlZmVyZW5jZSBkZXRlY3RlZCBpbiAnICsgcGF0aC5qb2luKCcuJykpO1xuICAgIH1cblxuICAgIHN0YWNrLnB1c2godmFsdWUpO1xuXG4gICAgdXRpbHMuZm9yRWFjaCh2YWx1ZSwgZnVuY3Rpb24gZWFjaChlbCwga2V5KSB7XG4gICAgICBjb25zdCByZXN1bHQgPVxuICAgICAgICAhKHV0aWxzLmlzVW5kZWZpbmVkKGVsKSB8fCBlbCA9PT0gbnVsbCkgJiZcbiAgICAgICAgdmlzaXRvci5jYWxsKGZvcm1EYXRhLCBlbCwgdXRpbHMuaXNTdHJpbmcoa2V5KSA/IGtleS50cmltKCkgOiBrZXksIHBhdGgsIGV4cG9zZWRIZWxwZXJzKTtcblxuICAgICAgaWYgKHJlc3VsdCA9PT0gdHJ1ZSkge1xuICAgICAgICBidWlsZChlbCwgcGF0aCA/IHBhdGguY29uY2F0KGtleSkgOiBba2V5XSwgZGVwdGggKyAxKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIHN0YWNrLnBvcCgpO1xuICB9XG5cbiAgaWYgKCF1dGlscy5pc09iamVjdChvYmopKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignZGF0YSBtdXN0IGJlIGFuIG9iamVjdCcpO1xuICB9XG5cbiAgYnVpbGQob2JqKTtcblxuICByZXR1cm4gZm9ybURhdGE7XG59XG5cbmV4cG9ydCBkZWZhdWx0IHRvRm9ybURhdGE7XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB0b0Zvcm1EYXRhIGZyb20gJy4vdG9Gb3JtRGF0YS5qcyc7XG5cbi8qKlxuICogSXQgZW5jb2RlcyBhIHN0cmluZyBieSByZXBsYWNpbmcgYWxsIGNoYXJhY3RlcnMgdGhhdCBhcmUgbm90IGluIHRoZSB1bnJlc2VydmVkIHNldCB3aXRoXG4gKiB0aGVpciBwZXJjZW50LWVuY29kZWQgZXF1aXZhbGVudHNcbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gc3RyIC0gVGhlIHN0cmluZyB0byBlbmNvZGUuXG4gKlxuICogQHJldHVybnMge3N0cmluZ30gVGhlIGVuY29kZWQgc3RyaW5nLlxuICovXG5mdW5jdGlvbiBlbmNvZGUoc3RyKSB7XG4gIGNvbnN0IGNoYXJNYXAgPSB7XG4gICAgJyEnOiAnJTIxJyxcbiAgICBcIidcIjogJyUyNycsXG4gICAgJygnOiAnJTI4JyxcbiAgICAnKSc6ICclMjknLFxuICAgICd+JzogJyU3RScsXG4gICAgJyUyMCc6ICcrJyxcbiAgfTtcbiAgcmV0dXJuIGVuY29kZVVSSUNvbXBvbmVudChzdHIpLnJlcGxhY2UoL1shJygpfl18JTIwL2csIGZ1bmN0aW9uIHJlcGxhY2VyKG1hdGNoKSB7XG4gICAgcmV0dXJuIGNoYXJNYXBbbWF0Y2hdO1xuICB9KTtcbn1cblxuLyoqXG4gKiBJdCB0YWtlcyBhIHBhcmFtcyBvYmplY3QgYW5kIGNvbnZlcnRzIGl0IHRvIGEgRm9ybURhdGEgb2JqZWN0XG4gKlxuICogQHBhcmFtIHtPYmplY3Q8c3RyaW5nLCBhbnk+fSBwYXJhbXMgLSBUaGUgcGFyYW1ldGVycyB0byBiZSBjb252ZXJ0ZWQgdG8gYSBGb3JtRGF0YSBvYmplY3QuXG4gKiBAcGFyYW0ge09iamVjdDxzdHJpbmcsIGFueT59IG9wdGlvbnMgLSBUaGUgb3B0aW9ucyBvYmplY3QgcGFzc2VkIHRvIHRoZSBBeGlvcyBjb25zdHJ1Y3Rvci5cbiAqXG4gKiBAcmV0dXJucyB7dm9pZH1cbiAqL1xuZnVuY3Rpb24gQXhpb3NVUkxTZWFyY2hQYXJhbXMocGFyYW1zLCBvcHRpb25zKSB7XG4gIHRoaXMuX3BhaXJzID0gW107XG5cbiAgcGFyYW1zICYmIHRvRm9ybURhdGEocGFyYW1zLCB0aGlzLCBvcHRpb25zKTtcbn1cblxuY29uc3QgcHJvdG90eXBlID0gQXhpb3NVUkxTZWFyY2hQYXJhbXMucHJvdG90eXBlO1xuXG5wcm90b3R5cGUuYXBwZW5kID0gZnVuY3Rpb24gYXBwZW5kKG5hbWUsIHZhbHVlKSB7XG4gIHRoaXMuX3BhaXJzLnB1c2goW25hbWUsIHZhbHVlXSk7XG59O1xuXG5wcm90b3R5cGUudG9TdHJpbmcgPSBmdW5jdGlvbiB0b1N0cmluZyhlbmNvZGVyKSB7XG4gIGNvbnN0IF9lbmNvZGUgPSBlbmNvZGVyXG4gICAgPyAodmFsdWUpID0+IGVuY29kZXIuY2FsbCh0aGlzLCB2YWx1ZSwgZW5jb2RlKVxuICAgIDogZW5jb2RlO1xuXG4gIHJldHVybiB0aGlzLl9wYWlyc1xuICAgIC5tYXAoZnVuY3Rpb24gZWFjaChwYWlyKSB7XG4gICAgICByZXR1cm4gX2VuY29kZShwYWlyWzBdKSArICc9JyArIF9lbmNvZGUocGFpclsxXSk7XG4gICAgfSwgJycpXG4gICAgLmpvaW4oJyYnKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IEF4aW9zVVJMU2VhcmNoUGFyYW1zO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgdXRpbHMgZnJvbSAnLi4vdXRpbHMuanMnO1xuaW1wb3J0IEF4aW9zVVJMU2VhcmNoUGFyYW1zIGZyb20gJy4vQXhpb3NVUkxTZWFyY2hQYXJhbXMuanMnO1xuXG4vKipcbiAqIEl0IHJlcGxhY2VzIFVSTC1lbmNvZGVkIGZvcm1zIG9mIGA6YCwgYCRgLCBgLGAsIGFuZCBzcGFjZXMgd2l0aFxuICogdGhlaXIgcGxhaW4gY291bnRlcnBhcnRzIChgOmAsIGAkYCwgYCxgLCBgK2ApLlxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSB2YWwgVGhlIHZhbHVlIHRvIGJlIGVuY29kZWQuXG4gKlxuICogQHJldHVybnMge3N0cmluZ30gVGhlIGVuY29kZWQgdmFsdWUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBlbmNvZGUodmFsKSB7XG4gIHJldHVybiBlbmNvZGVVUklDb21wb25lbnQodmFsKVxuICAgIC5yZXBsYWNlKC8lM0EvZ2ksICc6JylcbiAgICAucmVwbGFjZSgvJTI0L2csICckJylcbiAgICAucmVwbGFjZSgvJTJDL2dpLCAnLCcpXG4gICAgLnJlcGxhY2UoLyUyMC9nLCAnKycpO1xufVxuXG4vKipcbiAqIEJ1aWxkIGEgVVJMIGJ5IGFwcGVuZGluZyBwYXJhbXMgdG8gdGhlIGVuZFxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSB1cmwgVGhlIGJhc2Ugb2YgdGhlIHVybCAoZS5nLiwgaHR0cDovL3d3dy5nb29nbGUuY29tKVxuICogQHBhcmFtIHtvYmplY3R9IFtwYXJhbXNdIFRoZSBwYXJhbXMgdG8gYmUgYXBwZW5kZWRcbiAqIEBwYXJhbSB7PyhvYmplY3R8RnVuY3Rpb24pfSBvcHRpb25zXG4gKlxuICogQHJldHVybnMge3N0cmluZ30gVGhlIGZvcm1hdHRlZCB1cmxcbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gYnVpbGRVUkwodXJsLCBwYXJhbXMsIG9wdGlvbnMpIHtcbiAgaWYgKCFwYXJhbXMpIHtcbiAgICByZXR1cm4gdXJsO1xuICB9XG4gIHVybCA9IHVybCB8fCAnJztcblxuICBjb25zdCBfb3B0aW9ucyA9IHV0aWxzLmlzRnVuY3Rpb24ob3B0aW9ucylcbiAgICA/IHtcbiAgICAgICAgc2VyaWFsaXplOiBvcHRpb25zLFxuICAgICAgfVxuICAgIDogb3B0aW9ucztcblxuICAvLyBSZWFkIHNlcmlhbGl6ZXIgb3B0aW9ucyBwb2xsdXRpb24tc2FmZWx5OiBvd24gcHJvcGVydGllcyBhbmQgbWV0aG9kcyBvbiBhXG4gIC8vIGNsYXNzL3RlbXBsYXRlIHByb3RvdHlwZSBhcmUgaG9ub3JlZCwgYnV0IHZhbHVlcyBpbmplY3RlZCBvbnRvIGEgcG9sbHV0ZWRcbiAgLy8gT2JqZWN0LnByb3RvdHlwZSBhcmUgaWdub3JlZC5cbiAgY29uc3QgX2VuY29kZSA9IHV0aWxzLmdldFNhZmVQcm9wKF9vcHRpb25zLCAnZW5jb2RlJykgfHwgZW5jb2RlO1xuICBjb25zdCBzZXJpYWxpemVGbiA9IHV0aWxzLmdldFNhZmVQcm9wKF9vcHRpb25zLCAnc2VyaWFsaXplJyk7XG5cbiAgbGV0IHNlcmlhbGl6ZWRQYXJhbXM7XG5cbiAgaWYgKHNlcmlhbGl6ZUZuKSB7XG4gICAgc2VyaWFsaXplZFBhcmFtcyA9IHNlcmlhbGl6ZUZuKHBhcmFtcywgX29wdGlvbnMpO1xuICB9IGVsc2Uge1xuICAgIHNlcmlhbGl6ZWRQYXJhbXMgPSB1dGlscy5pc1VSTFNlYXJjaFBhcmFtcyhwYXJhbXMpXG4gICAgICA/IHBhcmFtcy50b1N0cmluZygpXG4gICAgICA6IG5ldyBBeGlvc1VSTFNlYXJjaFBhcmFtcyhwYXJhbXMsIF9vcHRpb25zKS50b1N0cmluZyhfZW5jb2RlKTtcbiAgfVxuXG4gIGlmIChzZXJpYWxpemVkUGFyYW1zKSB7XG4gICAgY29uc3QgaGFzaG1hcmtJbmRleCA9IHVybC5pbmRleE9mKCcjJyk7XG5cbiAgICBpZiAoaGFzaG1hcmtJbmRleCAhPT0gLTEpIHtcbiAgICAgIHVybCA9IHVybC5zbGljZSgwLCBoYXNobWFya0luZGV4KTtcbiAgICB9XG4gICAgdXJsICs9ICh1cmwuaW5kZXhPZignPycpID09PSAtMSA/ICc/JyA6ICcmJykgKyBzZXJpYWxpemVkUGFyYW1zO1xuICB9XG5cbiAgcmV0dXJuIHVybDtcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcblxuY29uc3QgJGludGVybmFscyA9IFN5bWJvbCgnaW50ZXJuYWxzJyk7XG5cbi8vIGBoYW5kbGVyc2AgaXMgcHVibGljIGFuZCBtYXkgYmUgcmVwbGFjZWQgd2l0aCBhIG51bGxpc2ggdmFsdWUgYnkgdXNlciBjb2RlO1xuLy8gYGNsZWFyKClgIGhhcyBhbHdheXMgdG9sZXJhdGVkIHRoYXQuIFRyZWF0IGl0IGFzIGFuIGVtcHR5IHN0YWNrIHJhdGhlciB0aGFuXG4vLyBkZXJlZmVyZW5jaW5nIGl0LlxuZnVuY3Rpb24gY291bnRIYW5kbGVycyhoYW5kbGVycykge1xuICByZXR1cm4gaGFuZGxlcnMgPyBoYW5kbGVycy5sZW5ndGggOiAwO1xufVxuXG5mdW5jdGlvbiB0cmltSGFuZGxlcnMoaGFuZGxlcnMpIHtcbiAgaWYgKCFoYW5kbGVycykge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIHdoaWxlIChoYW5kbGVycy5sZW5ndGggJiYgaGFuZGxlcnNbaGFuZGxlcnMubGVuZ3RoIC0gMV0gPT09IG51bGwpIHtcbiAgICBoYW5kbGVycy5wb3AoKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBzeW5jSGFuZGxlckVudHJpZXMobWFuYWdlciwgaW50ZXJuYWxzKSB7XG4gIGNvbnN0IGhhbmRsZXJzID0gbWFuYWdlci5oYW5kbGVycztcbiAgY29uc3QgbGVuZ3RoID0gY291bnRIYW5kbGVycyhoYW5kbGVycyk7XG5cbiAgaWYgKGhhbmRsZXJzICE9PSBpbnRlcm5hbHMuaGFuZGxlcnNSZWYpIHtcbiAgICBpbnRlcm5hbHMuaGFuZGxlcnNSZWYgPSBoYW5kbGVycztcbiAgICBpbnRlcm5hbHMuaGFuZGxlckVudHJpZXMuY2xlYXIoKTtcbiAgfSBlbHNlIGlmIChsZW5ndGggIT09IGludGVybmFscy5oYW5kbGVyc0xlbmd0aCkge1xuICAgIGlmICghbGVuZ3RoKSB7XG4gICAgICBpbnRlcm5hbHMuaGFuZGxlckVudHJpZXMuY2xlYXIoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaW50ZXJuYWxzLmhhbmRsZXJFbnRyaWVzLmZvckVhY2goZnVuY3Rpb24gcmVtb3ZlU3RhbGVFbnRyeShlbnRyeSwgaWQpIHtcbiAgICAgICAgaWYgKGhhbmRsZXJzW2VudHJ5LmluZGV4XSAhPT0gZW50cnkuaGFuZGxlcikge1xuICAgICAgICAgIGludGVybmFscy5oYW5kbGVyRW50cmllcy5kZWxldGUoaWQpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gIH1cblxuICBpbnRlcm5hbHMuaGFuZGxlcnNMZW5ndGggPSBsZW5ndGg7XG59XG5cbmNsYXNzIEludGVyY2VwdG9yTWFuYWdlciB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMuaGFuZGxlcnMgPSBbXTtcbiAgICB0aGlzWyRpbnRlcm5hbHNdID0ge1xuICAgICAgaGFuZGxlcnNSZWY6IHRoaXMuaGFuZGxlcnMsXG4gICAgICBoYW5kbGVyc0xlbmd0aDogdGhpcy5oYW5kbGVycy5sZW5ndGgsXG4gICAgICBoYW5kbGVyRW50cmllczogbmV3IE1hcCgpLFxuICAgICAgaXRlcmF0aW9uRGVwdGg6IDAsXG4gICAgICBuZXh0SWQ6IDAsXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGQgYSBuZXcgaW50ZXJjZXB0b3IgdG8gdGhlIHN0YWNrXG4gICAqXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IGZ1bGZpbGxlZCBUaGUgZnVuY3Rpb24gdG8gaGFuZGxlIGB0aGVuYCBmb3IgYSBgUHJvbWlzZWBcbiAgICogQHBhcmFtIHtGdW5jdGlvbn0gcmVqZWN0ZWQgVGhlIGZ1bmN0aW9uIHRvIGhhbmRsZSBgcmVqZWN0YCBmb3IgYSBgUHJvbWlzZWBcbiAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnMgVGhlIG9wdGlvbnMgZm9yIHRoZSBpbnRlcmNlcHRvciwgc3luY2hyb25vdXMgYW5kIHJ1bldoZW5cbiAgICpcbiAgICogQHJldHVybiB7TnVtYmVyfSBBbiBJRCB1c2VkIHRvIHJlbW92ZSBpbnRlcmNlcHRvciBsYXRlclxuICAgKi9cbiAgdXNlKGZ1bGZpbGxlZCwgcmVqZWN0ZWQsIG9wdGlvbnMpIHtcbiAgICBjb25zdCBoYW5kbGVyID0ge1xuICAgICAgZnVsZmlsbGVkLFxuICAgICAgcmVqZWN0ZWQsXG4gICAgICBzeW5jaHJvbm91czogb3B0aW9ucyA/IG9wdGlvbnMuc3luY2hyb25vdXMgOiBmYWxzZSxcbiAgICAgIHJ1bldoZW46IG9wdGlvbnMgPyBvcHRpb25zLnJ1bldoZW4gOiBudWxsLFxuICAgIH07XG4gICAgY29uc3QgaW50ZXJuYWxzID0gdGhpc1skaW50ZXJuYWxzXTtcblxuICAgIGlmICh0aGlzLmhhbmRsZXJzID09IG51bGwpIHtcbiAgICAgIHRoaXMuaGFuZGxlcnMgPSBbXTtcbiAgICB9XG5cbiAgICBzeW5jSGFuZGxlckVudHJpZXModGhpcywgaW50ZXJuYWxzKTtcblxuICAgIGNvbnN0IGlkID0gaW50ZXJuYWxzLm5leHRJZCsrO1xuXG4gICAgdGhpcy5oYW5kbGVycy5wdXNoKGhhbmRsZXIpO1xuICAgIGludGVybmFscy5oYW5kbGVyRW50cmllcy5zZXQoaWQsIHtcbiAgICAgIGhhbmRsZXIsXG4gICAgICBpbmRleDogdGhpcy5oYW5kbGVycy5sZW5ndGggLSAxLFxuICAgIH0pO1xuICAgIGludGVybmFscy5oYW5kbGVyc0xlbmd0aCA9IHRoaXMuaGFuZGxlcnMubGVuZ3RoO1xuXG4gICAgcmV0dXJuIGlkO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbW92ZSBhbiBpbnRlcmNlcHRvciBmcm9tIHRoZSBzdGFja1xuICAgKlxuICAgKiBAcGFyYW0ge051bWJlcn0gaWQgVGhlIElEIHRoYXQgd2FzIHJldHVybmVkIGJ5IGB1c2VgXG4gICAqXG4gICAqIEByZXR1cm5zIHt2b2lkfVxuICAgKi9cbiAgZWplY3QoaWQpIHtcbiAgICBjb25zdCBpbnRlcm5hbHMgPSB0aGlzWyRpbnRlcm5hbHNdO1xuXG4gICAgc3luY0hhbmRsZXJFbnRyaWVzKHRoaXMsIGludGVybmFscyk7XG5cbiAgICBjb25zdCBlbnRyeSA9IGludGVybmFscy5oYW5kbGVyRW50cmllcy5nZXQoaWQpO1xuXG4gICAgaWYgKGVudHJ5KSB7XG4gICAgICBpbnRlcm5hbHMuaGFuZGxlckVudHJpZXMuZGVsZXRlKGlkKTtcblxuICAgICAgLy8gSWdub3JlIElEcyBpbnZhbGlkYXRlZCBieSBjbGVhciBvciBkaXJlY3QgcmVwbGFjZW1lbnQgb2YgaGFuZGxlcnMuXG4gICAgICBpZiAodGhpcy5oYW5kbGVyc1tlbnRyeS5pbmRleF0gIT09IGVudHJ5LmhhbmRsZXIpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICB0aGlzLmhhbmRsZXJzW2VudHJ5LmluZGV4XSA9IG51bGw7XG5cbiAgICAgIC8vIERvIG5vdCByZXVzZSBhbiBpbmRleCB3aGlsZSBmb3JFYWNoIGlzIHdhbGtpbmcgaXRzIGxlbmd0aCBzbmFwc2hvdC5cbiAgICAgIGlmICghaW50ZXJuYWxzLml0ZXJhdGlvbkRlcHRoKSB7XG4gICAgICAgIHRyaW1IYW5kbGVycyh0aGlzLmhhbmRsZXJzKTtcbiAgICAgICAgaW50ZXJuYWxzLmhhbmRsZXJzTGVuZ3RoID0gdGhpcy5oYW5kbGVycy5sZW5ndGg7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIENsZWFyIGFsbCBpbnRlcmNlcHRvcnMgZnJvbSB0aGUgc3RhY2tcbiAgICpcbiAgICogQHJldHVybnMge3ZvaWR9XG4gICAqL1xuICBjbGVhcigpIHtcbiAgICBpZiAodGhpcy5oYW5kbGVycykge1xuICAgICAgdGhpcy5oYW5kbGVycyA9IFtdO1xuICAgICAgc3luY0hhbmRsZXJFbnRyaWVzKHRoaXMsIHRoaXNbJGludGVybmFsc10pO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBJdGVyYXRlIG92ZXIgYWxsIHRoZSByZWdpc3RlcmVkIGludGVyY2VwdG9yc1xuICAgKlxuICAgKiBUaGlzIG1ldGhvZCBpcyBwYXJ0aWN1bGFybHkgdXNlZnVsIGZvciBza2lwcGluZyBvdmVyIGFueVxuICAgKiBpbnRlcmNlcHRvcnMgdGhhdCBtYXkgaGF2ZSBiZWNvbWUgYG51bGxgIGNhbGxpbmcgYGVqZWN0YC5cbiAgICpcbiAgICogQHBhcmFtIHtGdW5jdGlvbn0gZm4gVGhlIGZ1bmN0aW9uIHRvIGNhbGwgZm9yIGVhY2ggaW50ZXJjZXB0b3JcbiAgICpcbiAgICogQHJldHVybnMge3ZvaWR9XG4gICAqL1xuICBmb3JFYWNoKGZuKSB7XG4gICAgY29uc3QgaW50ZXJuYWxzID0gdGhpc1skaW50ZXJuYWxzXTtcblxuICAgIHN5bmNIYW5kbGVyRW50cmllcyh0aGlzLCBpbnRlcm5hbHMpO1xuXG4gICAgaW50ZXJuYWxzLml0ZXJhdGlvbkRlcHRoKys7XG5cbiAgICB0cnkge1xuICAgICAgdXRpbHMuZm9yRWFjaCh0aGlzLmhhbmRsZXJzLCBmdW5jdGlvbiBmb3JFYWNoSGFuZGxlcihoKSB7XG4gICAgICAgIGlmIChoICE9PSBudWxsKSB7XG4gICAgICAgICAgZm4oaCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBpZiAoIS0taW50ZXJuYWxzLml0ZXJhdGlvbkRlcHRoKSB7XG4gICAgICAgIHN5bmNIYW5kbGVyRW50cmllcyh0aGlzLCBpbnRlcm5hbHMpO1xuICAgICAgICB0cmltSGFuZGxlcnModGhpcy5oYW5kbGVycyk7XG4gICAgICAgIGludGVybmFscy5oYW5kbGVyc0xlbmd0aCA9IGNvdW50SGFuZGxlcnModGhpcy5oYW5kbGVycyk7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IEludGVyY2VwdG9yTWFuYWdlcjtcbiIsIid1c2Ugc3RyaWN0JztcblxuZXhwb3J0IGRlZmF1bHQge1xuICBzaWxlbnRKU09OUGFyc2luZzogdHJ1ZSxcbiAgZm9yY2VkSlNPTlBhcnNpbmc6IHRydWUsXG4gIGNsYXJpZnlUaW1lb3V0RXJyb3I6IGZhbHNlLFxuICBsZWdhY3lJbnRlcmNlcHRvclJlcVJlc09yZGVyaW5nOiB0cnVlLFxuICBhZHZlcnRpc2Vac3RkQWNjZXB0RW5jb2Rpbmc6IGZhbHNlLFxuICB2YWxpZGF0ZVN0YXR1c1VuZGVmaW5lZFJlc29sdmVzOiB0cnVlLFxufTtcbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IEF4aW9zVVJMU2VhcmNoUGFyYW1zIGZyb20gJy4uLy4uLy4uL2hlbHBlcnMvQXhpb3NVUkxTZWFyY2hQYXJhbXMuanMnO1xuZXhwb3J0IGRlZmF1bHQgdHlwZW9mIFVSTFNlYXJjaFBhcmFtcyAhPT0gJ3VuZGVmaW5lZCcgPyBVUkxTZWFyY2hQYXJhbXMgOiBBeGlvc1VSTFNlYXJjaFBhcmFtcztcbiIsIid1c2Ugc3RyaWN0JztcblxuZXhwb3J0IGRlZmF1bHQgdHlwZW9mIEZvcm1EYXRhICE9PSAndW5kZWZpbmVkJyA/IEZvcm1EYXRhIDogbnVsbDtcbiIsIid1c2Ugc3RyaWN0JztcblxuZXhwb3J0IGRlZmF1bHQgdHlwZW9mIEJsb2IgIT09ICd1bmRlZmluZWQnID8gQmxvYiA6IG51bGw7XG4iLCJpbXBvcnQgVVJMU2VhcmNoUGFyYW1zIGZyb20gJy4vY2xhc3Nlcy9VUkxTZWFyY2hQYXJhbXMuanMnO1xuaW1wb3J0IEZvcm1EYXRhIGZyb20gJy4vY2xhc3Nlcy9Gb3JtRGF0YS5qcyc7XG5pbXBvcnQgQmxvYiBmcm9tICcuL2NsYXNzZXMvQmxvYi5qcyc7XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgaXNCcm93c2VyOiB0cnVlLFxuICBjbGFzc2VzOiB7XG4gICAgVVJMU2VhcmNoUGFyYW1zLFxuICAgIEZvcm1EYXRhLFxuICAgIEJsb2IsXG4gIH0sXG4gIHByb3RvY29sczogWydodHRwJywgJ2h0dHBzJywgJ2ZpbGUnLCAnYmxvYicsICd1cmwnLCAnZGF0YSddLFxufTtcbiIsImNvbnN0IGhhc0Jyb3dzZXJFbnYgPSB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgZG9jdW1lbnQgIT09ICd1bmRlZmluZWQnO1xuXG5jb25zdCBfbmF2aWdhdG9yID0gKHR5cGVvZiBuYXZpZ2F0b3IgPT09ICdvYmplY3QnICYmIG5hdmlnYXRvcikgfHwgdW5kZWZpbmVkO1xuXG4vKipcbiAqIERldGVybWluZSBpZiB3ZSdyZSBydW5uaW5nIGluIGEgc3RhbmRhcmQgYnJvd3NlciBlbnZpcm9ubWVudFxuICpcbiAqIFRoaXMgYWxsb3dzIGF4aW9zIHRvIHJ1biBpbiBhIHdlYiB3b3JrZXIsIGFuZCByZWFjdC1uYXRpdmUuXG4gKiBCb3RoIGVudmlyb25tZW50cyBzdXBwb3J0IFhNTEh0dHBSZXF1ZXN0LCBidXQgbm90IGZ1bGx5IHN0YW5kYXJkIGdsb2JhbHMuXG4gKlxuICogd2ViIHdvcmtlcnM6XG4gKiAgdHlwZW9mIHdpbmRvdyAtPiB1bmRlZmluZWRcbiAqICB0eXBlb2YgZG9jdW1lbnQgLT4gdW5kZWZpbmVkXG4gKlxuICogcmVhY3QtbmF0aXZlOlxuICogIG5hdmlnYXRvci5wcm9kdWN0IC0+ICdSZWFjdE5hdGl2ZSdcbiAqIG5hdGl2ZXNjcmlwdFxuICogIG5hdmlnYXRvci5wcm9kdWN0IC0+ICdOYXRpdmVTY3JpcHQnIG9yICdOUydcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAqL1xuY29uc3QgaGFzU3RhbmRhcmRCcm93c2VyRW52ID1cbiAgaGFzQnJvd3NlckVudiAmJlxuICAoIV9uYXZpZ2F0b3IgfHwgWydSZWFjdE5hdGl2ZScsICdOYXRpdmVTY3JpcHQnLCAnTlMnXS5pbmRleE9mKF9uYXZpZ2F0b3IucHJvZHVjdCkgPCAwKTtcblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgd2UncmUgcnVubmluZyBpbiBhIHN0YW5kYXJkIGJyb3dzZXIgd2ViV29ya2VyIGVudmlyb25tZW50XG4gKlxuICogQWx0aG91Z2ggdGhlIGBpc1N0YW5kYXJkQnJvd3NlckVudmAgbWV0aG9kIGluZGljYXRlcyB0aGF0XG4gKiBgYWxsb3dzIGF4aW9zIHRvIHJ1biBpbiBhIHdlYiB3b3JrZXJgLCB0aGUgV2ViV29ya2VyIHdpbGwgc3RpbGwgYmVcbiAqIGZpbHRlcmVkIG91dCBkdWUgdG8gaXRzIGp1ZGdtZW50IHN0YW5kYXJkXG4gKiBgdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIGRvY3VtZW50ICE9PSAndW5kZWZpbmVkJ2AuXG4gKiBUaGlzIGxlYWRzIHRvIGEgcHJvYmxlbSB3aGVuIGF4aW9zIHBvc3QgYEZvcm1EYXRhYCBpbiB3ZWJXb3JrZXJcbiAqL1xuY29uc3QgaGFzU3RhbmRhcmRCcm93c2VyV2ViV29ya2VyRW52ID0gKCgpID0+IHtcbiAgcmV0dXJuIChcbiAgICB0eXBlb2YgV29ya2VyR2xvYmFsU2NvcGUgIT09ICd1bmRlZmluZWQnICYmXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVuZGVmXG4gICAgc2VsZiBpbnN0YW5jZW9mIFdvcmtlckdsb2JhbFNjb3BlICYmXG4gICAgdHlwZW9mIHNlbGYuaW1wb3J0U2NyaXB0cyA9PT0gJ2Z1bmN0aW9uJ1xuICApO1xufSkoKTtcblxuY29uc3Qgb3JpZ2luID0gKGhhc0Jyb3dzZXJFbnYgJiYgd2luZG93LmxvY2F0aW9uLmhyZWYpIHx8ICdodHRwOi8vbG9jYWxob3N0JztcblxuZXhwb3J0IHtcbiAgaGFzQnJvd3NlckVudixcbiAgaGFzU3RhbmRhcmRCcm93c2VyV2ViV29ya2VyRW52LFxuICBoYXNTdGFuZGFyZEJyb3dzZXJFbnYsXG4gIF9uYXZpZ2F0b3IgYXMgbmF2aWdhdG9yLFxuICBvcmlnaW4sXG59O1xuIiwiaW1wb3J0IHBsYXRmb3JtIGZyb20gJy4vbm9kZS9pbmRleC5qcyc7XG5pbXBvcnQgKiBhcyB1dGlscyBmcm9tICcuL2NvbW1vbi91dGlscy5qcyc7XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgLi4udXRpbHMsXG4gIC4uLnBsYXRmb3JtLFxufTtcbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCB0b0Zvcm1EYXRhIGZyb20gJy4vdG9Gb3JtRGF0YS5qcyc7XG5pbXBvcnQgcGxhdGZvcm0gZnJvbSAnLi4vcGxhdGZvcm0vaW5kZXguanMnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiB0b1VSTEVuY29kZWRGb3JtKGRhdGEsIG9wdGlvbnMpIHtcbiAgcmV0dXJuIHRvRm9ybURhdGEoZGF0YSwgbmV3IHBsYXRmb3JtLmNsYXNzZXMuVVJMU2VhcmNoUGFyYW1zKCksIHtcbiAgICB2aXNpdG9yOiBmdW5jdGlvbiAodmFsdWUsIGtleSwgcGF0aCwgaGVscGVycykge1xuICAgICAgaWYgKHBsYXRmb3JtLmlzTm9kZSAmJiB1dGlscy5pc0J1ZmZlcih2YWx1ZSkpIHtcbiAgICAgICAgdGhpcy5hcHBlbmQoa2V5LCB2YWx1ZS50b1N0cmluZygnYmFzZTY0JykpO1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBoZWxwZXJzLmRlZmF1bHRWaXNpdG9yLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgfSxcbiAgICAuLi5vcHRpb25zLFxuICB9KTtcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCBBeGlvc0Vycm9yIGZyb20gJy4uL2NvcmUvQXhpb3NFcnJvci5qcyc7XG5pbXBvcnQgeyBERUZBVUxUX0ZPUk1fREFUQV9NQVhfREVQVEggfSBmcm9tICcuL3RvRm9ybURhdGEuanMnO1xuXG5jb25zdCBNQVhfREVQVEggPSBERUZBVUxUX0ZPUk1fREFUQV9NQVhfREVQVEg7XG5cbmZ1bmN0aW9uIHRocm93SWZEZXB0aEV4Y2VlZGVkKGluZGV4KSB7XG4gIGlmIChpbmRleCA+IE1BWF9ERVBUSCkge1xuICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKFxuICAgICAgJ0Zvcm1EYXRhIGZpZWxkIGlzIHRvbyBkZWVwbHkgbmVzdGVkICgnICsgaW5kZXggKyAnIGxldmVscykuIE1heCBkZXB0aDogJyArIE1BWF9ERVBUSCxcbiAgICAgIEF4aW9zRXJyb3IuRVJSX0ZPUk1fREFUQV9ERVBUSF9FWENFRURFRFxuICAgICk7XG4gIH1cbn1cblxuLyoqXG4gKiBJdCB0YWtlcyBhIHN0cmluZyBsaWtlIGBmb29beF1beV1bel1gIGFuZCByZXR1cm5zIGFuIGFycmF5IGxpa2UgYFsnZm9vJywgJ3gnLCAneScsICd6J11cbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gbmFtZSAtIFRoZSBuYW1lIG9mIHRoZSBwcm9wZXJ0eSB0byBnZXQuXG4gKlxuICogQHJldHVybnMgQW4gYXJyYXkgb2Ygc3RyaW5ncy5cbiAqL1xuZnVuY3Rpb24gcGFyc2VQcm9wUGF0aChuYW1lKSB7XG4gIC8vIGZvb1t4XVt5XVt6XSAtPiBbJ2ZvbycsICd4JywgJ3knLCAneiddXG4gIC8vIGZvby54LnkueiAgICAtPiBbJ2ZvbycsICd4JywgJ3knLCAneiddXG4gIC8vIEEgcGF0aCBpcyBzcGxpdCBvbiBgLmAgYW5kIG9uIGBbLi4uXWAgZ3JvdXBzLiBBIHNlZ21lbnQg4oCUIHdoZXRoZXIgd3JpdHRlblxuICAvLyBpbiBkb3Qgbm90YXRpb24gb3IgY2FwdHVyZWQgaW5zaWRlIGJyYWNrZXRzIOKAlCBtYXkgY29udGFpbiBhbnkgY2hhcmFjdGVyXG4gIC8vIGV4Y2VwdCBgLmAsIGBbYCBhbmQgYF1gLCBzbyBhIGtleSBsaWtlIGB1c2VyLW5hbWVgIG9yIGB1c2VyIG5hbWVgIGlzIGtlcHRcbiAgLy8gbGl0ZXJhbCBpbnN0ZWFkIG9mIGJlaW5nIHNwbGl0ICgjNTQwMikuIGAuYCwgYFtgIGFuZCBgXWAga2VlcCB0aGVpciBleGlzdGluZ1xuICAvLyBtZWFuaW5nLCBlLmcuIGBmb29bYmFyLmJhel1gIC0+IFsnZm9vJywgJ2JhcicsICdiYXonXSBhbmQgYFtdYCBpcyBhbiBhcnJheSBwdXNoLlxuICAvLyBFeGNsdWRpbmcgYFtgIGZyb20gdGhlIGJyYWNrZXQgZ3JvdXAgYWxzbyBtYWtlcyB0aGUgbWF0Y2ggZmFpbCBmYXN0IGF0IHRoZVxuICAvLyBuZXh0IGBbYCwgc28gYSBtYWxmb3JtZWQgbmFtZSBjYW5ub3QgcmVzY2FuIHRvIHRoZSBlbmQgb2YgdGhlIHN0cmluZyBmcm9tXG4gIC8vIGV2ZXJ5IHVubWF0Y2hlZCBgW2Ag4oCUIHBhcnNpbmcgc3RheXMgbGluZWFyIGluIHRoZSBsZW5ndGggb2YgdGhlIG5hbWUuXG4gIGNvbnN0IHBhdGggPSBbXTtcbiAgY29uc3QgcGF0dGVybiA9IC9bXi5bXFxdXSt8XFxbKFteLltcXF1dKildL2c7XG4gIGxldCBtYXRjaDtcblxuICB3aGlsZSAoKG1hdGNoID0gcGF0dGVybi5leGVjKG5hbWUpKSAhPT0gbnVsbCkge1xuICAgIHRocm93SWZEZXB0aEV4Y2VlZGVkKHBhdGgubGVuZ3RoKTtcbiAgICBwYXRoLnB1c2gobWF0Y2hbMF0gPT09ICdbXScgPyAnJyA6IG1hdGNoWzFdIHx8IG1hdGNoWzBdKTtcbiAgfVxuXG4gIHJldHVybiBwYXRoO1xufVxuXG4vKipcbiAqIENvbnZlcnQgYW4gYXJyYXkgdG8gYW4gb2JqZWN0LlxuICpcbiAqIEBwYXJhbSB7QXJyYXk8YW55Pn0gYXJyIC0gVGhlIGFycmF5IHRvIGNvbnZlcnQgdG8gYW4gb2JqZWN0LlxuICpcbiAqIEByZXR1cm5zIEFuIG9iamVjdCB3aXRoIHRoZSBzYW1lIGtleXMgYW5kIHZhbHVlcyBhcyB0aGUgYXJyYXkuXG4gKi9cbmZ1bmN0aW9uIGFycmF5VG9PYmplY3QoYXJyKSB7XG4gIGNvbnN0IG9iaiA9IHt9O1xuICBjb25zdCBrZXlzID0gT2JqZWN0LmtleXMoYXJyKTtcbiAgbGV0IGk7XG4gIGNvbnN0IGxlbiA9IGtleXMubGVuZ3RoO1xuICBsZXQga2V5O1xuICBmb3IgKGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICBrZXkgPSBrZXlzW2ldO1xuICAgIG9ialtrZXldID0gYXJyW2tleV07XG4gIH1cbiAgcmV0dXJuIG9iajtcbn1cblxuLyoqXG4gKiBJdCB0YWtlcyBhIEZvcm1EYXRhIG9iamVjdCBhbmQgcmV0dXJucyBhIEphdmFTY3JpcHQgb2JqZWN0XG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IGZvcm1EYXRhIFRoZSBGb3JtRGF0YSBvYmplY3QgdG8gY29udmVydCB0byBKU09OLlxuICpcbiAqIEByZXR1cm5zIHtPYmplY3Q8c3RyaW5nLCBhbnk+IHwgbnVsbH0gVGhlIGNvbnZlcnRlZCBvYmplY3QuXG4gKi9cbmZ1bmN0aW9uIGZvcm1EYXRhVG9KU09OKGZvcm1EYXRhKSB7XG4gIGZ1bmN0aW9uIGJ1aWxkUGF0aChwYXRoLCB2YWx1ZSwgdGFyZ2V0LCBpbmRleCkge1xuICAgIHRocm93SWZEZXB0aEV4Y2VlZGVkKGluZGV4KTtcblxuICAgIGxldCBuYW1lID0gcGF0aFtpbmRleCsrXTtcblxuICAgIGlmIChuYW1lID09PSAnX19wcm90b19fJykgcmV0dXJuIHRydWU7XG5cbiAgICBjb25zdCBpc051bWVyaWNLZXkgPSBOdW1iZXIuaXNGaW5pdGUoK25hbWUpO1xuICAgIGNvbnN0IGlzTGFzdCA9IGluZGV4ID49IHBhdGgubGVuZ3RoO1xuICAgIG5hbWUgPSAhbmFtZSAmJiB1dGlscy5pc0FycmF5KHRhcmdldCkgPyB0YXJnZXQubGVuZ3RoIDogbmFtZTtcblxuICAgIGlmIChpc0xhc3QpIHtcbiAgICAgIGlmICh1dGlscy5oYXNPd25Qcm9wKHRhcmdldCwgbmFtZSkpIHtcbiAgICAgICAgdGFyZ2V0W25hbWVdID0gdXRpbHMuaXNBcnJheSh0YXJnZXRbbmFtZV0pXG4gICAgICAgICAgPyB0YXJnZXRbbmFtZV0uY29uY2F0KHZhbHVlKVxuICAgICAgICAgIDogW3RhcmdldFtuYW1lXSwgdmFsdWVdO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGFyZ2V0W25hbWVdID0gdmFsdWU7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiAhaXNOdW1lcmljS2V5O1xuICAgIH1cblxuICAgIGlmICghdXRpbHMuaGFzT3duUHJvcCh0YXJnZXQsIG5hbWUpIHx8ICF1dGlscy5pc09iamVjdCh0YXJnZXRbbmFtZV0pKSB7XG4gICAgICB0YXJnZXRbbmFtZV0gPSBbXTtcbiAgICB9XG5cbiAgICBjb25zdCByZXN1bHQgPSBidWlsZFBhdGgocGF0aCwgdmFsdWUsIHRhcmdldFtuYW1lXSwgaW5kZXgpO1xuXG4gICAgaWYgKHJlc3VsdCAmJiB1dGlscy5pc0FycmF5KHRhcmdldFtuYW1lXSkpIHtcbiAgICAgIHRhcmdldFtuYW1lXSA9IGFycmF5VG9PYmplY3QodGFyZ2V0W25hbWVdKTtcbiAgICB9XG5cbiAgICByZXR1cm4gIWlzTnVtZXJpY0tleTtcbiAgfVxuXG4gIGlmICh1dGlscy5pc0Zvcm1EYXRhKGZvcm1EYXRhKSAmJiB1dGlscy5pc0Z1bmN0aW9uKGZvcm1EYXRhLmVudHJpZXMpKSB7XG4gICAgY29uc3Qgb2JqID0ge307XG5cbiAgICB1dGlscy5mb3JFYWNoRW50cnkoZm9ybURhdGEsIChuYW1lLCB2YWx1ZSkgPT4ge1xuICAgICAgYnVpbGRQYXRoKHBhcnNlUHJvcFBhdGgobmFtZSksIHZhbHVlLCBvYmosIDApO1xuICAgIH0pO1xuXG4gICAgcmV0dXJuIG9iajtcbiAgfVxuXG4gIHJldHVybiBudWxsO1xufVxuXG5leHBvcnQgZGVmYXVsdCBmb3JtRGF0YVRvSlNPTjtcbiIsIid1c2Ugc3RyaWN0JztcblxuY29uc3QgbWV0aG9kTGlzdCA9IE9iamVjdC5mcmVlemUoW1xuICAnZ2V0JyxcbiAgJ2RlbGV0ZScsXG4gICdoZWFkJyxcbiAgJ29wdGlvbnMnLFxuICAncG9zdCcsXG4gICdwdXQnLFxuICAncGF0Y2gnLFxuICAncHVyZ2UnLFxuICAnbGluaycsXG4gICd1bmxpbmsnLFxuICAncXVlcnknLFxuXSk7XG5cbmV4cG9ydCBkZWZhdWx0IG1ldGhvZExpc3Q7XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5pbXBvcnQgQXhpb3NFcnJvciBmcm9tICcuLi9jb3JlL0F4aW9zRXJyb3IuanMnO1xuaW1wb3J0IHRyYW5zaXRpb25hbERlZmF1bHRzIGZyb20gJy4vdHJhbnNpdGlvbmFsLmpzJztcbmltcG9ydCB0b0Zvcm1EYXRhIGZyb20gJy4uL2hlbHBlcnMvdG9Gb3JtRGF0YS5qcyc7XG5pbXBvcnQgdG9VUkxFbmNvZGVkRm9ybSBmcm9tICcuLi9oZWxwZXJzL3RvVVJMRW5jb2RlZEZvcm0uanMnO1xuaW1wb3J0IHBsYXRmb3JtIGZyb20gJy4uL3BsYXRmb3JtL2luZGV4LmpzJztcbmltcG9ydCBmb3JtRGF0YVRvSlNPTiBmcm9tICcuLi9oZWxwZXJzL2Zvcm1EYXRhVG9KU09OLmpzJztcbmltcG9ydCBtZXRob2RMaXN0IGZyb20gJy4uL2NvcmUvbWV0aG9kTGlzdC5qcyc7XG5cbmNvbnN0IG93biA9IChvYmosIGtleSkgPT4gKG9iaiAhPSBudWxsICYmIHV0aWxzLmhhc093blByb3Aob2JqLCBrZXkpID8gb2JqW2tleV0gOiB1bmRlZmluZWQpO1xuXG4vKipcbiAqIEl0IHRha2VzIGEgc3RyaW5nLCB0cmllcyB0byBwYXJzZSBpdCwgYW5kIGlmIGl0IGZhaWxzLCBpdCByZXR1cm5zIHRoZSBzdHJpbmdpZmllZCB2ZXJzaW9uXG4gKiBvZiB0aGUgaW5wdXRcbiAqXG4gKiBAcGFyYW0ge2FueX0gcmF3VmFsdWUgLSBUaGUgdmFsdWUgdG8gYmUgc3RyaW5naWZpZWQuXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBwYXJzZXIgLSBBIGZ1bmN0aW9uIHRoYXQgcGFyc2VzIGEgc3RyaW5nIGludG8gYSBKYXZhU2NyaXB0IG9iamVjdC5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IGVuY29kZXIgLSBBIGZ1bmN0aW9uIHRoYXQgdGFrZXMgYSB2YWx1ZSBhbmQgcmV0dXJucyBhIHN0cmluZy5cbiAqXG4gKiBAcmV0dXJucyB7c3RyaW5nfSBBIHN0cmluZ2lmaWVkIHZlcnNpb24gb2YgdGhlIHJhd1ZhbHVlLlxuICovXG5mdW5jdGlvbiBzdHJpbmdpZnlTYWZlbHkocmF3VmFsdWUsIHBhcnNlciwgZW5jb2Rlcikge1xuICBpZiAodXRpbHMuaXNTdHJpbmcocmF3VmFsdWUpKSB7XG4gICAgdHJ5IHtcbiAgICAgIChwYXJzZXIgfHwgSlNPTi5wYXJzZSkocmF3VmFsdWUpO1xuICAgICAgcmV0dXJuIHV0aWxzLnRyaW0ocmF3VmFsdWUpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGlmIChlLm5hbWUgIT09ICdTeW50YXhFcnJvcicpIHtcbiAgICAgICAgdGhyb3cgZTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICByZXR1cm4gKGVuY29kZXIgfHwgSlNPTi5zdHJpbmdpZnkpKHJhd1ZhbHVlKTtcbn1cblxuY29uc3QgZGVmYXVsdHMgPSB7XG4gIHRyYW5zaXRpb25hbDogdHJhbnNpdGlvbmFsRGVmYXVsdHMsXG5cbiAgYWRhcHRlcjogWyd4aHInLCAnaHR0cCcsICdmZXRjaCddLFxuXG4gIHRyYW5zZm9ybVJlcXVlc3Q6IFtcbiAgICBmdW5jdGlvbiB0cmFuc2Zvcm1SZXF1ZXN0KGRhdGEsIGhlYWRlcnMpIHtcbiAgICAgIGNvbnN0IGNvbnRlbnRUeXBlID0gaGVhZGVycy5nZXRDb250ZW50VHlwZSgpIHx8ICcnO1xuICAgICAgY29uc3QgaGFzSlNPTkNvbnRlbnRUeXBlID0gY29udGVudFR5cGUuaW5kZXhPZignYXBwbGljYXRpb24vanNvbicpID4gLTE7XG4gICAgICBjb25zdCBpc09iamVjdFBheWxvYWQgPSB1dGlscy5pc09iamVjdChkYXRhKTtcblxuICAgICAgaWYgKGlzT2JqZWN0UGF5bG9hZCAmJiB1dGlscy5pc0hUTUxGb3JtKGRhdGEpKSB7XG4gICAgICAgIGRhdGEgPSBuZXcgRm9ybURhdGEoZGF0YSk7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGlzRm9ybURhdGEgPSB1dGlscy5pc0Zvcm1EYXRhKGRhdGEpO1xuXG4gICAgICBpZiAoaXNGb3JtRGF0YSkge1xuICAgICAgICByZXR1cm4gaGFzSlNPTkNvbnRlbnRUeXBlID8gSlNPTi5zdHJpbmdpZnkoZm9ybURhdGFUb0pTT04oZGF0YSkpIDogZGF0YTtcbiAgICAgIH1cblxuICAgICAgaWYgKFxuICAgICAgICB1dGlscy5pc0FycmF5QnVmZmVyKGRhdGEpIHx8XG4gICAgICAgIHV0aWxzLmlzQnVmZmVyKGRhdGEpIHx8XG4gICAgICAgIHV0aWxzLmlzU3RyZWFtKGRhdGEpIHx8XG4gICAgICAgIHV0aWxzLmlzRmlsZShkYXRhKSB8fFxuICAgICAgICB1dGlscy5pc0Jsb2IoZGF0YSkgfHxcbiAgICAgICAgdXRpbHMuaXNSZWFkYWJsZVN0cmVhbShkYXRhKVxuICAgICAgKSB7XG4gICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgfVxuICAgICAgaWYgKHV0aWxzLmlzQXJyYXlCdWZmZXJWaWV3KGRhdGEpKSB7XG4gICAgICAgIHJldHVybiBkYXRhLmJ1ZmZlcjtcbiAgICAgIH1cbiAgICAgIGlmICh1dGlscy5pc1VSTFNlYXJjaFBhcmFtcyhkYXRhKSkge1xuICAgICAgICBoZWFkZXJzLnNldENvbnRlbnRUeXBlKCdhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWQ7Y2hhcnNldD11dGYtOCcsIGZhbHNlKTtcbiAgICAgICAgcmV0dXJuIGRhdGEudG9TdHJpbmcoKTtcbiAgICAgIH1cblxuICAgICAgbGV0IGlzRmlsZUxpc3Q7XG5cbiAgICAgIGlmIChpc09iamVjdFBheWxvYWQpIHtcbiAgICAgICAgY29uc3QgZm9ybVNlcmlhbGl6ZXIgPSBvd24odGhpcywgJ2Zvcm1TZXJpYWxpemVyJyk7XG4gICAgICAgIGlmIChjb250ZW50VHlwZS5pbmRleE9mKCdhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWQnKSA+IC0xKSB7XG4gICAgICAgICAgcmV0dXJuIHRvVVJMRW5jb2RlZEZvcm0oZGF0YSwgZm9ybVNlcmlhbGl6ZXIpLnRvU3RyaW5nKCk7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoXG4gICAgICAgICAgKGlzRmlsZUxpc3QgPSB1dGlscy5pc0ZpbGVMaXN0KGRhdGEpKSB8fFxuICAgICAgICAgIGNvbnRlbnRUeXBlLmluZGV4T2YoJ211bHRpcGFydC9mb3JtLWRhdGEnKSA+IC0xXG4gICAgICAgICkge1xuICAgICAgICAgIGNvbnN0IGVudiA9IG93bih0aGlzLCAnZW52Jyk7XG4gICAgICAgICAgY29uc3QgX0Zvcm1EYXRhID0gZW52ICYmIGVudi5Gb3JtRGF0YTtcblxuICAgICAgICAgIHJldHVybiB0b0Zvcm1EYXRhKFxuICAgICAgICAgICAgaXNGaWxlTGlzdCA/IHsgJ2ZpbGVzW10nOiBkYXRhIH0gOiBkYXRhLFxuICAgICAgICAgICAgX0Zvcm1EYXRhICYmIG5ldyBfRm9ybURhdGEoKSxcbiAgICAgICAgICAgIGZvcm1TZXJpYWxpemVyXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAoaXNPYmplY3RQYXlsb2FkIHx8IGhhc0pTT05Db250ZW50VHlwZSkge1xuICAgICAgICBoZWFkZXJzLnNldENvbnRlbnRUeXBlKCdhcHBsaWNhdGlvbi9qc29uJywgZmFsc2UpO1xuICAgICAgICByZXR1cm4gc3RyaW5naWZ5U2FmZWx5KGRhdGEpO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gZGF0YTtcbiAgICB9LFxuICBdLFxuXG4gIHRyYW5zZm9ybVJlc3BvbnNlOiBbXG4gICAgZnVuY3Rpb24gdHJhbnNmb3JtUmVzcG9uc2UoZGF0YSkge1xuICAgICAgY29uc3QgdHJhbnNpdGlvbmFsID0gb3duKHRoaXMsICd0cmFuc2l0aW9uYWwnKSB8fCBkZWZhdWx0cy50cmFuc2l0aW9uYWw7XG4gICAgICBjb25zdCBmb3JjZWRKU09OUGFyc2luZyA9IHRyYW5zaXRpb25hbCAmJiB0cmFuc2l0aW9uYWwuZm9yY2VkSlNPTlBhcnNpbmc7XG4gICAgICBjb25zdCByZXNwb25zZVR5cGUgPSBvd24odGhpcywgJ3Jlc3BvbnNlVHlwZScpO1xuICAgICAgY29uc3QgSlNPTlJlcXVlc3RlZCA9IHJlc3BvbnNlVHlwZSA9PT0gJ2pzb24nO1xuXG4gICAgICBpZiAodXRpbHMuaXNSZXNwb25zZShkYXRhKSB8fCB1dGlscy5pc1JlYWRhYmxlU3RyZWFtKGRhdGEpKSB7XG4gICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgfVxuXG4gICAgICBpZiAoXG4gICAgICAgIGRhdGEgJiZcbiAgICAgICAgdXRpbHMuaXNTdHJpbmcoZGF0YSkgJiZcbiAgICAgICAgKChmb3JjZWRKU09OUGFyc2luZyAmJiAhcmVzcG9uc2VUeXBlKSB8fCBKU09OUmVxdWVzdGVkKVxuICAgICAgKSB7XG4gICAgICAgIGNvbnN0IHNpbGVudEpTT05QYXJzaW5nID0gdHJhbnNpdGlvbmFsICYmIHRyYW5zaXRpb25hbC5zaWxlbnRKU09OUGFyc2luZztcbiAgICAgICAgY29uc3Qgc3RyaWN0SlNPTlBhcnNpbmcgPSAhc2lsZW50SlNPTlBhcnNpbmcgJiYgSlNPTlJlcXVlc3RlZDtcblxuICAgICAgICB0cnkge1xuICAgICAgICAgIHJldHVybiBKU09OLnBhcnNlKGRhdGEsIG93bih0aGlzLCAncGFyc2VSZXZpdmVyJykpO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgaWYgKHN0cmljdEpTT05QYXJzaW5nKSB7XG4gICAgICAgICAgICBpZiAoZS5uYW1lID09PSAnU3ludGF4RXJyb3InKSB7XG4gICAgICAgICAgICAgIHRocm93IEF4aW9zRXJyb3IuZnJvbShlLCBBeGlvc0Vycm9yLkVSUl9CQURfUkVTUE9OU0UsIHRoaXMsIG51bGwsIG93bih0aGlzLCAncmVzcG9uc2UnKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aHJvdyBlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gZGF0YTtcbiAgICB9LFxuICBdLFxuXG4gIC8qKlxuICAgKiBBIHRpbWVvdXQgaW4gbWlsbGlzZWNvbmRzIHRvIGFib3J0IGEgcmVxdWVzdC4gSWYgc2V0IHRvIDAgKGRlZmF1bHQpIGFcbiAgICogdGltZW91dCBpcyBub3QgY3JlYXRlZC5cbiAgICovXG4gIHRpbWVvdXQ6IDAsXG5cbiAgeHNyZkNvb2tpZU5hbWU6ICdYU1JGLVRPS0VOJyxcbiAgeHNyZkhlYWRlck5hbWU6ICdYLVhTUkYtVE9LRU4nLFxuXG4gIG1heENvbnRlbnRMZW5ndGg6IC0xLFxuICBtYXhCb2R5TGVuZ3RoOiAtMSxcblxuICBlbnY6IHtcbiAgICBGb3JtRGF0YTogcGxhdGZvcm0uY2xhc3Nlcy5Gb3JtRGF0YSxcbiAgICBCbG9iOiBwbGF0Zm9ybS5jbGFzc2VzLkJsb2IsXG4gIH0sXG5cbiAgdmFsaWRhdGVTdGF0dXM6IGZ1bmN0aW9uIHZhbGlkYXRlU3RhdHVzKHN0YXR1cykge1xuICAgIHJldHVybiBzdGF0dXMgPj0gMjAwICYmIHN0YXR1cyA8IDMwMDtcbiAgfSxcblxuICBoZWFkZXJzOiB7XG4gICAgY29tbW9uOiB7XG4gICAgICBBY2NlcHQ6ICdhcHBsaWNhdGlvbi9qc29uLCB0ZXh0L3BsYWluLCAqLyonLFxuICAgICAgJ0NvbnRlbnQtVHlwZSc6IHVuZGVmaW5lZCxcbiAgICB9LFxuICB9LFxufTtcblxudXRpbHMuZm9yRWFjaChtZXRob2RMaXN0LCAobWV0aG9kKSA9PiB7XG4gIGRlZmF1bHRzLmhlYWRlcnNbbWV0aG9kXSA9IHt9O1xufSk7XG5cbmV4cG9ydCBkZWZhdWx0IGRlZmF1bHRzO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgdXRpbHMgZnJvbSAnLi4vdXRpbHMuanMnO1xuaW1wb3J0IGRlZmF1bHRzIGZyb20gJy4uL2RlZmF1bHRzL2luZGV4LmpzJztcbmltcG9ydCBBeGlvc0hlYWRlcnMgZnJvbSAnLi4vY29yZS9BeGlvc0hlYWRlcnMuanMnO1xuXG4vKipcbiAqIFRyYW5zZm9ybSB0aGUgZGF0YSBmb3IgYSByZXF1ZXN0IG9yIGEgcmVzcG9uc2VcbiAqXG4gKiBAcGFyYW0ge0FycmF5fEZ1bmN0aW9ufSBmbnMgQSBzaW5nbGUgZnVuY3Rpb24gb3IgQXJyYXkgb2YgZnVuY3Rpb25zXG4gKiBAcGFyYW0gez9PYmplY3R9IHJlc3BvbnNlIFRoZSByZXNwb25zZSBvYmplY3RcbiAqXG4gKiBAcmV0dXJucyB7Kn0gVGhlIHJlc3VsdGluZyB0cmFuc2Zvcm1lZCBkYXRhXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHRyYW5zZm9ybURhdGEoZm5zLCByZXNwb25zZSkge1xuICBjb25zdCBjb25maWcgPSB0aGlzIHx8IGRlZmF1bHRzO1xuICBjb25zdCBjb250ZXh0ID0gcmVzcG9uc2UgfHwgY29uZmlnO1xuICBjb25zdCBoZWFkZXJzID0gQXhpb3NIZWFkZXJzLmZyb20oY29udGV4dC5oZWFkZXJzKTtcbiAgbGV0IGRhdGEgPSBjb250ZXh0LmRhdGE7XG5cbiAgdXRpbHMuZm9yRWFjaChmbnMsIGZ1bmN0aW9uIHRyYW5zZm9ybShmbikge1xuICAgIGRhdGEgPSBmbi5jYWxsKGNvbmZpZywgZGF0YSwgaGVhZGVycy5ub3JtYWxpemUoKSwgcmVzcG9uc2UgPyByZXNwb25zZS5zdGF0dXMgOiB1bmRlZmluZWQpO1xuICB9KTtcblxuICBoZWFkZXJzLm5vcm1hbGl6ZSgpO1xuXG4gIHJldHVybiBkYXRhO1xufVxuIiwiJ3VzZSBzdHJpY3QnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBpc0NhbmNlbCh2YWx1ZSkge1xuICByZXR1cm4gISEodmFsdWUgJiYgdmFsdWUuX19DQU5DRUxfXyk7XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCBBeGlvc0Vycm9yIGZyb20gJy4uL2NvcmUvQXhpb3NFcnJvci5qcyc7XG5cbmNsYXNzIENhbmNlbGVkRXJyb3IgZXh0ZW5kcyBBeGlvc0Vycm9yIHtcbiAgLyoqXG4gICAqIEEgYENhbmNlbGVkRXJyb3JgIGlzIGFuIG9iamVjdCB0aGF0IGlzIHRocm93biB3aGVuIGFuIG9wZXJhdGlvbiBpcyBjYW5jZWxlZC5cbiAgICpcbiAgICogQHBhcmFtIHtzdHJpbmc9fSBtZXNzYWdlIFRoZSBtZXNzYWdlLlxuICAgKiBAcGFyYW0ge09iamVjdD19IGNvbmZpZyBUaGUgY29uZmlnLlxuICAgKiBAcGFyYW0ge09iamVjdD19IHJlcXVlc3QgVGhlIHJlcXVlc3QuXG4gICAqXG4gICAqIEByZXR1cm5zIHtDYW5jZWxlZEVycm9yfSBUaGUgY3JlYXRlZCBlcnJvci5cbiAgICovXG4gIGNvbnN0cnVjdG9yKG1lc3NhZ2UsIGNvbmZpZywgcmVxdWVzdCkge1xuICAgIHN1cGVyKG1lc3NhZ2UgPT0gbnVsbCA/ICdjYW5jZWxlZCcgOiBtZXNzYWdlLCBBeGlvc0Vycm9yLkVSUl9DQU5DRUxFRCwgY29uZmlnLCByZXF1ZXN0KTtcbiAgICB0aGlzLm5hbWUgPSAnQ2FuY2VsZWRFcnJvcic7XG4gICAgdGhpcy5fX0NBTkNFTF9fID0gdHJ1ZTtcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBDYW5jZWxlZEVycm9yO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgQXhpb3NFcnJvciBmcm9tICcuL0F4aW9zRXJyb3IuanMnO1xuXG4vKipcbiAqIFJlc29sdmUgb3IgcmVqZWN0IGEgUHJvbWlzZSBiYXNlZCBvbiByZXNwb25zZSBzdGF0dXMuXG4gKlxuICogQHBhcmFtIHtGdW5jdGlvbn0gcmVzb2x2ZSBBIGZ1bmN0aW9uIHRoYXQgcmVzb2x2ZXMgdGhlIHByb21pc2UuXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSByZWplY3QgQSBmdW5jdGlvbiB0aGF0IHJlamVjdHMgdGhlIHByb21pc2UuXG4gKiBAcGFyYW0ge29iamVjdH0gcmVzcG9uc2UgVGhlIHJlc3BvbnNlLlxuICpcbiAqIEByZXR1cm5zIHtvYmplY3R9IFRoZSByZXNwb25zZS5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gc2V0dGxlKHJlc29sdmUsIHJlamVjdCwgcmVzcG9uc2UpIHtcbiAgY29uc3QgdmFsaWRhdGVTdGF0dXMgPSByZXNwb25zZS5jb25maWcudmFsaWRhdGVTdGF0dXM7XG4gIGlmICghcmVzcG9uc2Uuc3RhdHVzIHx8ICF2YWxpZGF0ZVN0YXR1cyB8fCB2YWxpZGF0ZVN0YXR1cyhyZXNwb25zZS5zdGF0dXMpKSB7XG4gICAgcmVzb2x2ZShyZXNwb25zZSk7XG4gIH0gZWxzZSB7XG4gICAgcmVqZWN0KG5ldyBBeGlvc0Vycm9yKFxuICAgICAgJ1JlcXVlc3QgZmFpbGVkIHdpdGggc3RhdHVzIGNvZGUgJyArIHJlc3BvbnNlLnN0YXR1cyxcbiAgICAgIHJlc3BvbnNlLnN0YXR1cyA+PSA0MDAgJiYgcmVzcG9uc2Uuc3RhdHVzIDwgNTAwID8gQXhpb3NFcnJvci5FUlJfQkFEX1JFUVVFU1QgOiBBeGlvc0Vycm9yLkVSUl9CQURfUkVTUE9OU0UsXG4gICAgICByZXNwb25zZS5jb25maWcsXG4gICAgICByZXNwb25zZS5yZXF1ZXN0LFxuICAgICAgcmVzcG9uc2VcbiAgICApKTtcbiAgfVxufVxuIiwiJ3VzZSBzdHJpY3QnO1xuXG5jb25zdCB1cmxQYXJzZXJDb250cm9sQ2hhcmFjdGVycyA9IC9bXFx0XFxuXFxyXS9nO1xuXG4vKipcbiAqIE1hdGNoIFdIQVRXRyBVUkwgcHJlcHJvY2Vzc2luZyBiZWZvcmUgY2hlY2tpbmcgYSBVUkwncyBwcm90b2NvbC5cbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gdXJsXG4gKlxuICogQHJldHVybnMge3N0cmluZ31cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gbm9ybWFsaXplVVJMRm9yUHJvdG9jb2xDaGVjayh1cmwpIHtcbiAgaWYgKHR5cGVvZiB1cmwgIT09ICdzdHJpbmcnKSB7XG4gICAgcmV0dXJuIHVybDtcbiAgfVxuXG4gIGxldCBzdGFydCA9IDA7XG5cbiAgd2hpbGUgKHN0YXJ0IDwgdXJsLmxlbmd0aCAmJiB1cmwuY2hhckNvZGVBdChzdGFydCkgPD0gMHgyMCkge1xuICAgIHN0YXJ0Kys7XG4gIH1cblxuICByZXR1cm4gdXJsLnNsaWNlKHN0YXJ0KS5yZXBsYWNlKHVybFBhcnNlckNvbnRyb2xDaGFyYWN0ZXJzLCAnJyk7XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHBhcnNlUHJvdG9jb2wodXJsKSB7XG4gIGNvbnN0IG1hdGNoID0gL14oWy0rXFx3XXsxLDI1fSk6KD86XFwvXFwvKT8vLmV4ZWModXJsKTtcbiAgcmV0dXJuIChtYXRjaCAmJiBtYXRjaFsxXSkgfHwgJyc7XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbi8qKlxuICogQ2FsY3VsYXRlIGRhdGEgbWF4UmF0ZVxuICogQHBhcmFtIHtOdW1iZXJ9IFtzYW1wbGVzQ291bnQ9IDEwXVxuICogQHBhcmFtIHtOdW1iZXJ9IFttaW49IDEwMDBdXG4gKiBAcmV0dXJucyB7RnVuY3Rpb259XG4gKi9cbmZ1bmN0aW9uIHNwZWVkb21ldGVyKHNhbXBsZXNDb3VudCwgbWluKSB7XG4gIHNhbXBsZXNDb3VudCA9IHNhbXBsZXNDb3VudCB8fCAxMDtcbiAgY29uc3QgYnl0ZXMgPSBuZXcgQXJyYXkoc2FtcGxlc0NvdW50KTtcbiAgY29uc3QgdGltZXN0YW1wcyA9IG5ldyBBcnJheShzYW1wbGVzQ291bnQpO1xuICBsZXQgaGVhZCA9IDA7XG4gIGxldCB0YWlsID0gMDtcbiAgbGV0IGZpcnN0U2FtcGxlVFM7XG5cbiAgbWluID0gbWluICE9PSB1bmRlZmluZWQgPyBtaW4gOiAxMDAwO1xuXG4gIHJldHVybiBmdW5jdGlvbiBwdXNoKGNodW5rTGVuZ3RoKSB7XG4gICAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcblxuICAgIGNvbnN0IHN0YXJ0ZWRBdCA9IHRpbWVzdGFtcHNbdGFpbF07XG5cbiAgICBpZiAoIWZpcnN0U2FtcGxlVFMpIHtcbiAgICAgIGZpcnN0U2FtcGxlVFMgPSBub3c7XG4gICAgfVxuXG4gICAgYnl0ZXNbaGVhZF0gPSBjaHVua0xlbmd0aDtcbiAgICB0aW1lc3RhbXBzW2hlYWRdID0gbm93O1xuXG4gICAgbGV0IGkgPSB0YWlsO1xuICAgIGxldCBieXRlc0NvdW50ID0gMDtcblxuICAgIHdoaWxlIChpICE9PSBoZWFkKSB7XG4gICAgICBieXRlc0NvdW50ICs9IGJ5dGVzW2krK107XG4gICAgICBpID0gaSAlIHNhbXBsZXNDb3VudDtcbiAgICB9XG5cbiAgICBoZWFkID0gKGhlYWQgKyAxKSAlIHNhbXBsZXNDb3VudDtcblxuICAgIGlmIChoZWFkID09PSB0YWlsKSB7XG4gICAgICB0YWlsID0gKHRhaWwgKyAxKSAlIHNhbXBsZXNDb3VudDtcbiAgICB9XG5cbiAgICBpZiAobm93IC0gZmlyc3RTYW1wbGVUUyA8IG1pbikge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IHBhc3NlZCA9IHN0YXJ0ZWRBdCAmJiBub3cgLSBzdGFydGVkQXQ7XG5cbiAgICByZXR1cm4gcGFzc2VkID8gTWF0aC5yb3VuZCgoYnl0ZXNDb3VudCAqIDEwMDApIC8gcGFzc2VkKSA6IHVuZGVmaW5lZDtcbiAgfTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgc3BlZWRvbWV0ZXI7XG4iLCIvKipcbiAqIFRocm90dGxlIGRlY29yYXRvclxuICogQHBhcmFtIHtGdW5jdGlvbn0gZm5cbiAqIEBwYXJhbSB7TnVtYmVyfSBmcmVxXG4gKiBAcmV0dXJuIHtBcnJheTxGdW5jdGlvbj59XG4gKi9cbmZ1bmN0aW9uIHRocm90dGxlKGZuLCBmcmVxKSB7XG4gIGxldCB0aW1lc3RhbXAgPSAwO1xuICBsZXQgdGhyZXNob2xkID0gMTAwMCAvIGZyZXE7XG4gIGxldCBsYXN0QXJncztcbiAgbGV0IHRpbWVyO1xuXG4gIGNvbnN0IGludm9rZSA9IChhcmdzLCBub3cgPSBEYXRlLm5vdygpKSA9PiB7XG4gICAgdGltZXN0YW1wID0gbm93O1xuICAgIGxhc3RBcmdzID0gbnVsbDtcbiAgICBpZiAodGltZXIpIHtcbiAgICAgIGNsZWFyVGltZW91dCh0aW1lcik7XG4gICAgICB0aW1lciA9IG51bGw7XG4gICAgfVxuICAgIGZuKC4uLmFyZ3MpO1xuICB9O1xuXG4gIGNvbnN0IHRocm90dGxlZCA9ICguLi5hcmdzKSA9PiB7XG4gICAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgICBjb25zdCBwYXNzZWQgPSBub3cgLSB0aW1lc3RhbXA7XG4gICAgaWYgKHBhc3NlZCA+PSB0aHJlc2hvbGQpIHtcbiAgICAgIGludm9rZShhcmdzLCBub3cpO1xuICAgIH0gZWxzZSB7XG4gICAgICBsYXN0QXJncyA9IGFyZ3M7XG4gICAgICBpZiAoIXRpbWVyKSB7XG4gICAgICAgIHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgdGltZXIgPSBudWxsO1xuICAgICAgICAgIGludm9rZShsYXN0QXJncyk7XG4gICAgICAgIH0sIHRocmVzaG9sZCAtIHBhc3NlZCk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGZsdXNoID0gKCkgPT4gbGFzdEFyZ3MgJiYgaW52b2tlKGxhc3RBcmdzKTtcbiAgY29uc3QgZmx1c2hXaXRoID0gKC4uLmFyZ3MpID0+IGludm9rZShhcmdzKTtcblxuICByZXR1cm4gW3Rocm90dGxlZCwgZmx1c2gsIGZsdXNoV2l0aF07XG59XG5cbmV4cG9ydCBkZWZhdWx0IHRocm90dGxlO1xuIiwiaW1wb3J0IHNwZWVkb21ldGVyIGZyb20gJy4vc3BlZWRvbWV0ZXIuanMnO1xuaW1wb3J0IHRocm90dGxlIGZyb20gJy4vdGhyb3R0bGUuanMnO1xuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcblxuZXhwb3J0IGNvbnN0IHByb2dyZXNzRXZlbnRSZWR1Y2VyID0gKGxpc3RlbmVyLCBpc0Rvd25sb2FkU3RyZWFtLCBmcmVxID0gMykgPT4ge1xuICBsZXQgYnl0ZXNOb3RpZmllZCA9IDA7XG4gIGNvbnN0IF9zcGVlZG9tZXRlciA9IHNwZWVkb21ldGVyKDUwLCAyNTApO1xuXG4gIHJldHVybiB0aHJvdHRsZSgoZSkgPT4ge1xuICAgIGlmICghZSB8fCAhdXRpbHMuaXNOdW1iZXIoZS5sb2FkZWQpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHJhd0xvYWRlZCA9IGUubG9hZGVkO1xuICAgIGNvbnN0IHRvdGFsID0gZS5sZW5ndGhDb21wdXRhYmxlID8gZS50b3RhbCA6IHVuZGVmaW5lZDtcbiAgICBjb25zdCBsb2FkZWQgPSBNYXRoLm1heCgwLCB0b3RhbCAhPSBudWxsID8gTWF0aC5taW4ocmF3TG9hZGVkLCB0b3RhbCkgOiByYXdMb2FkZWQpO1xuICAgIGNvbnN0IHByb2dyZXNzQnl0ZXMgPSBNYXRoLm1heCgwLCBsb2FkZWQgLSBieXRlc05vdGlmaWVkKTtcbiAgICBjb25zdCByYXRlID0gX3NwZWVkb21ldGVyKHByb2dyZXNzQnl0ZXMpO1xuXG4gICAgYnl0ZXNOb3RpZmllZCA9IE1hdGgubWF4KGJ5dGVzTm90aWZpZWQsIGxvYWRlZCk7XG5cbiAgICBjb25zdCBkYXRhID0ge1xuICAgICAgbG9hZGVkLFxuICAgICAgdG90YWwsXG4gICAgICBwcm9ncmVzczogdG90YWwgPyBsb2FkZWQgLyB0b3RhbCA6IHVuZGVmaW5lZCxcbiAgICAgIGJ5dGVzOiBwcm9ncmVzc0J5dGVzLFxuICAgICAgcmF0ZTogcmF0ZSA/IHJhdGUgOiB1bmRlZmluZWQsXG4gICAgICBlc3RpbWF0ZWQ6IHJhdGUgJiYgdG90YWwgPyAodG90YWwgLSBsb2FkZWQpIC8gcmF0ZSA6IHVuZGVmaW5lZCxcbiAgICAgIGV2ZW50OiBlLFxuICAgICAgbGVuZ3RoQ29tcHV0YWJsZTogdG90YWwgIT0gbnVsbCxcbiAgICAgIFtpc0Rvd25sb2FkU3RyZWFtID8gJ2Rvd25sb2FkJyA6ICd1cGxvYWQnXTogdHJ1ZSxcbiAgICB9O1xuXG4gICAgbGlzdGVuZXIoZGF0YSk7XG4gIH0sIGZyZXEpO1xufTtcblxuZXhwb3J0IGNvbnN0IHByb2dyZXNzRXZlbnREZWNvcmF0b3IgPSAodG90YWwsIHRocm90dGxlZCkgPT4ge1xuICBjb25zdCBsZW5ndGhDb21wdXRhYmxlID0gdG90YWwgIT0gbnVsbDtcblxuICByZXR1cm4gW1xuICAgIChsb2FkZWQpID0+XG4gICAgICB0aHJvdHRsZWRbMF0oe1xuICAgICAgICBsZW5ndGhDb21wdXRhYmxlLFxuICAgICAgICB0b3RhbCxcbiAgICAgICAgbG9hZGVkLFxuICAgICAgfSksXG4gICAgdGhyb3R0bGVkWzFdLFxuICBdO1xufTtcblxuZXhwb3J0IGNvbnN0IGFzeW5jRGVjb3JhdG9yID1cbiAgKGZuLCBzY2hlZHVsZXIgPSB1dGlscy5hc2FwKSA9PlxuICAoLi4uYXJncykgPT5cbiAgICBzY2hlZHVsZXIoKCkgPT4gZm4oLi4uYXJncykpO1xuIiwiaW1wb3J0IHBsYXRmb3JtIGZyb20gJy4uL3BsYXRmb3JtL2luZGV4LmpzJztcblxuZXhwb3J0IGRlZmF1bHQgcGxhdGZvcm0uaGFzU3RhbmRhcmRCcm93c2VyRW52XG4gID8gKChvcmlnaW4sIGlzTVNJRSkgPT4gKHVybCkgPT4ge1xuICAgICAgdXJsID0gbmV3IFVSTCh1cmwsIHBsYXRmb3JtLm9yaWdpbik7XG5cbiAgICAgIHJldHVybiAoXG4gICAgICAgIG9yaWdpbi5wcm90b2NvbCA9PT0gdXJsLnByb3RvY29sICYmXG4gICAgICAgIG9yaWdpbi5ob3N0ID09PSB1cmwuaG9zdCAmJlxuICAgICAgICAoaXNNU0lFIHx8IG9yaWdpbi5wb3J0ID09PSB1cmwucG9ydClcbiAgICAgICk7XG4gICAgfSkoXG4gICAgICBuZXcgVVJMKHBsYXRmb3JtLm9yaWdpbiksXG4gICAgICBwbGF0Zm9ybS5uYXZpZ2F0b3IgJiYgLyhtc2llfHRyaWRlbnQpL2kudGVzdChwbGF0Zm9ybS5uYXZpZ2F0b3IudXNlckFnZW50KVxuICAgIClcbiAgOiAoKSA9PiB0cnVlO1xuIiwiaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCBwbGF0Zm9ybSBmcm9tICcuLi9wbGF0Zm9ybS9pbmRleC5qcyc7XG5cbmV4cG9ydCBkZWZhdWx0IHBsYXRmb3JtLmhhc1N0YW5kYXJkQnJvd3NlckVudlxuICA/IC8vIFN0YW5kYXJkIGJyb3dzZXIgZW52cyBzdXBwb3J0IGRvY3VtZW50LmNvb2tpZVxuICAgIHtcbiAgICAgIHdyaXRlKG5hbWUsIHZhbHVlLCBleHBpcmVzLCBwYXRoLCBkb21haW4sIHNlY3VyZSwgc2FtZVNpdGUpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBkb2N1bWVudCA9PT0gJ3VuZGVmaW5lZCcpIHJldHVybjtcblxuICAgICAgICBjb25zdCBjb29raWUgPSBbYCR7bmFtZX09JHtlbmNvZGVVUklDb21wb25lbnQodmFsdWUpfWBdO1xuXG4gICAgICAgIGlmICh1dGlscy5pc051bWJlcihleHBpcmVzKSkge1xuICAgICAgICAgIGNvb2tpZS5wdXNoKGBleHBpcmVzPSR7bmV3IERhdGUoZXhwaXJlcykudG9VVENTdHJpbmcoKX1gKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodXRpbHMuaXNTdHJpbmcocGF0aCkpIHtcbiAgICAgICAgICBjb29raWUucHVzaChgcGF0aD0ke3BhdGh9YCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHV0aWxzLmlzU3RyaW5nKGRvbWFpbikpIHtcbiAgICAgICAgICBjb29raWUucHVzaChgZG9tYWluPSR7ZG9tYWlufWApO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzZWN1cmUgPT09IHRydWUpIHtcbiAgICAgICAgICBjb29raWUucHVzaCgnc2VjdXJlJyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHV0aWxzLmlzU3RyaW5nKHNhbWVTaXRlKSkge1xuICAgICAgICAgIGNvb2tpZS5wdXNoKGBTYW1lU2l0ZT0ke3NhbWVTaXRlfWApO1xuICAgICAgICB9XG5cbiAgICAgICAgZG9jdW1lbnQuY29va2llID0gY29va2llLmpvaW4oJzsgJyk7XG4gICAgICB9LFxuXG4gICAgICByZWFkKG5hbWUpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBkb2N1bWVudCA9PT0gJ3VuZGVmaW5lZCcpIHJldHVybiBudWxsO1xuICAgICAgICAvLyBNYXRjaCBuYW1lPXZhbHVlIGJ5IHNwbGl0dGluZyBvbiB0aGUgc2VtaWNvbG9uIHNlcGFyYXRvciBpbnN0ZWFkIG9mIGJ1aWxkaW5nIGFcbiAgICAgICAgLy8gUmVnRXhwIGZyb20gYG5hbWVgIOKAlCBpbnRlcnBvbGF0aW5nIGFuIHVuZXNjYXBlZCBzdHJpbmcgaW50byBhIFJlZ0V4cCB3b3VsZCBsZXRcbiAgICAgICAgLy8gbWV0YWNoYXJhY3RlcnMgKGUuZy4gYC4rP2AgaW4gYW4gYXR0YWNrZXItaW5mbHVlbmNlZCBjb29raWUgbmFtZSkgY2F1c2UgUmVEb1Mgb3JcbiAgICAgICAgLy8gbWF0Y2ggdGhlIHdyb25nIGNvb2tpZS4gQnJvd3NlcnMgbWF5IHNlcmlhbGl6ZSBjb29raWUgcGFpcnMgYXMgZWl0aGVyIFwiO1wiIG9yXG4gICAgICAgIC8vIFwiOyBcIiwgc28gaWdub3JlIG9wdGlvbmFsIHdoaXRlc3BhY2UgYmVmb3JlIGVhY2ggY29va2llIG5hbWUuXG4gICAgICAgIGNvbnN0IGNvb2tpZXMgPSBkb2N1bWVudC5jb29raWUuc3BsaXQoJzsnKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb29raWVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgY29uc3QgY29va2llID0gY29va2llc1tpXS5yZXBsYWNlKC9eXFxzKy8sICcnKTtcbiAgICAgICAgICBjb25zdCBlcSA9IGNvb2tpZS5pbmRleE9mKCc9Jyk7XG4gICAgICAgICAgaWYgKGVxICE9PSAtMSAmJiBjb29raWUuc2xpY2UoMCwgZXEpID09PSBuYW1lKSB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICByZXR1cm4gZGVjb2RlVVJJQ29tcG9uZW50KGNvb2tpZS5zbGljZShlcSArIDEpKTtcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGNvb2tpZS5zbGljZShlcSArIDEpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH0sXG5cbiAgICAgIHJlbW92ZShuYW1lKSB7XG4gICAgICAgIHRoaXMud3JpdGUobmFtZSwgJycsIERhdGUubm93KCkgLSA4NjQwMDAwMCwgJy8nKTtcbiAgICAgIH0sXG4gICAgfVxuICA6IC8vIE5vbi1zdGFuZGFyZCBicm93c2VyIGVudiAod2ViIHdvcmtlcnMsIHJlYWN0LW5hdGl2ZSkgbGFjayBuZWVkZWQgc3VwcG9ydC5cbiAgICB7XG4gICAgICB3cml0ZSgpIHt9LFxuICAgICAgcmVhZCgpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9LFxuICAgICAgcmVtb3ZlKCkge30sXG4gICAgfTtcbiIsIid1c2Ugc3RyaWN0JztcblxuLyoqXG4gKiBEZXRlcm1pbmVzIHdoZXRoZXIgdGhlIHNwZWNpZmllZCBVUkwgaXMgYWJzb2x1dGVcbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gdXJsIFRoZSBVUkwgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHRoZSBzcGVjaWZpZWQgVVJMIGlzIGFic29sdXRlLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gaXNBYnNvbHV0ZVVSTCh1cmwpIHtcbiAgLy8gQSBVUkwgaXMgY29uc2lkZXJlZCBhYnNvbHV0ZSBpZiBpdCBiZWdpbnMgd2l0aCBcIjxzY2hlbWU+Oi8vXCIgb3IgXCIvL1wiIChwcm90b2NvbC1yZWxhdGl2ZSBVUkwpLlxuICAvLyBSRkMgMzk4NiBkZWZpbmVzIHNjaGVtZSBuYW1lIGFzIGEgc2VxdWVuY2Ugb2YgY2hhcmFjdGVycyBiZWdpbm5pbmcgd2l0aCBhIGxldHRlciBhbmQgZm9sbG93ZWRcbiAgLy8gYnkgYW55IGNvbWJpbmF0aW9uIG9mIGxldHRlcnMsIGRpZ2l0cywgcGx1cywgcGVyaW9kLCBvciBoeXBoZW4uXG4gIGlmICh0eXBlb2YgdXJsICE9PSAnc3RyaW5nJykge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIHJldHVybiAvXihbYS16XVthLXpcXGQrXFwtLl0qOik/XFwvXFwvL2kudGVzdCh1cmwpO1xufVxuIiwiJ3VzZSBzdHJpY3QnO1xuXG4vKipcbiAqIENyZWF0ZXMgYSBuZXcgVVJMIGJ5IGNvbWJpbmluZyB0aGUgc3BlY2lmaWVkIFVSTHNcbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gYmFzZVVSTCBUaGUgYmFzZSBVUkxcbiAqIEBwYXJhbSB7c3RyaW5nfSByZWxhdGl2ZVVSTCBUaGUgcmVsYXRpdmUgVVJMXG4gKlxuICogQHJldHVybnMge3N0cmluZ30gVGhlIGNvbWJpbmVkIFVSTFxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBjb21iaW5lVVJMcyhiYXNlVVJMLCByZWxhdGl2ZVVSTCkge1xuICBpZiAoIXJlbGF0aXZlVVJMKSB7XG4gICAgcmV0dXJuIGJhc2VVUkw7XG4gIH1cblxuICBsZXQgZW5kID0gYmFzZVVSTC5sZW5ndGg7XG5cbiAgd2hpbGUgKGVuZCA+IDAgJiYgYmFzZVVSTC5jaGFyQ29kZUF0KGVuZCAtIDEpID09PSA0Nykge1xuICAgIGVuZC0tO1xuICB9XG5cbiAgcmV0dXJuIGJhc2VVUkwuc2xpY2UoMCwgZW5kKSArICcvJyArIHJlbGF0aXZlVVJMLnJlcGxhY2UoL15cXC8rLywgJycpO1xufVxuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgQXhpb3NFcnJvciwgeyBSRURBQ1RFRCB9IGZyb20gJy4vQXhpb3NFcnJvci5qcyc7XG5pbXBvcnQgaXNBYnNvbHV0ZVVSTCBmcm9tICcuLi9oZWxwZXJzL2lzQWJzb2x1dGVVUkwuanMnO1xuaW1wb3J0IGNvbWJpbmVVUkxzIGZyb20gJy4uL2hlbHBlcnMvY29tYmluZVVSTHMuanMnO1xuaW1wb3J0IG5vcm1hbGl6ZVVSTEZvclByb3RvY29sQ2hlY2sgZnJvbSAnLi4vaGVscGVycy9ub3JtYWxpemVVUkxGb3JQcm90b2NvbENoZWNrLmpzJztcblxuY29uc3QgbWFsZm9ybWVkSHR0cFByb3RvY29sID0gL15odHRwcz86KD8hXFwvXFwvKS9pO1xuXG4vLyBSZWRhY3QgdGhlIHBhcnRzIG9mIGEgVVJMIHRoYXQgY2FuIGNhcnJ5IHNlY3JldHMgYmVmb3JlIGl0IGlzIGVtYmVkZGVkIGluIGFuXG4vLyBlcnJvciBtZXNzYWdlLiBBeGlvc0Vycm9yLnRvSlNPTigpIHNlcmlhbGl6ZXMgYG1lc3NhZ2VgIHZlcmJhdGltIGFuZCBlcnJvcnNcbi8vIGFyZSBjb21tb25seSBsb2dnZWQsIHdoaWxlIHRoZSBvcHQtaW4gYGNvbmZpZy5yZWRhY3RgIG1vZGVsIG9ubHkgY2xlYW5zXG4vLyBjb25maWcga2V5cyDigJQgaXQgY2Fubm90IHJlYWNoIHRoZSBtZXNzYWdlLiBSZWRhY3Qgb25seSB0aGUgZ2VudWluZWx5XG4vLyBzZW5zaXRpdmUgc3Vic3RyaW5ncyDigJQgdXNlcmluZm8gKGNyZWRlbnRpYWxzKSwgcXVlcnkgcGFyYW1ldGVyIHZhbHVlcyBhbmRcbi8vIGZyYWdtZW50IGNvbnRlbnRzIOKAlCB3aXRoIHRoZSBzYW1lIFJFREFDVEVEIG1hcmtlciB0aGUgY29uZmlnIHJlZGFjdGlvbiB1c2VzLFxuLy8gd2hpbGUga2VlcGluZyB0aGUgc2NoZW1lLCBob3N0LCBwYXRoIGFuZCBwYXJhbWV0ZXIgbmFtZXMgc28gdGhlIG9mZmVuZGluZ1xuLy8gcmVxdWVzdCBzdGF5cyBhY2N1cmF0ZWx5IGlkZW50aWZpYWJsZS5cbmZ1bmN0aW9uIHJlZGFjdEZyYWdtZW50KGZyYWdtZW50KSB7XG4gIGlmICghZnJhZ21lbnQpIHtcbiAgICByZXR1cm4gZnJhZ21lbnQ7XG4gIH1cblxuICByZXR1cm4gZnJhZ21lbnQucmVwbGFjZSgvKF58JikoW149Jl0qPSk/W14mXSsvZywgKG1hdGNoLCBzZXBhcmF0b3IsIHBhcmFtZXRlck5hbWUgPSAnJykgPT4ge1xuICAgIHJldHVybiBgJHtzZXBhcmF0b3J9JHtwYXJhbWV0ZXJOYW1lfSR7UkVEQUNURUR9YDtcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIHJlZGFjdFNlbnNpdGl2ZVVSTFBhcnRzKHVybCkge1xuICBjb25zdCByZWRhY3RlZFVSTCA9IHVybC5yZXBsYWNlKC9eKGh0dHBzPzpcXC97MCwyfSlbXi8/I10qQC9pLCBgJDEke1JFREFDVEVEfUBgKTtcbiAgY29uc3QgZnJhZ21lbnRJbmRleCA9IHJlZGFjdGVkVVJMLmluZGV4T2YoJyMnKTtcbiAgY29uc3QgdXJsV2l0aG91dEZyYWdtZW50ID1cbiAgICBmcmFnbWVudEluZGV4ID09PSAtMSA/IHJlZGFjdGVkVVJMIDogcmVkYWN0ZWRVUkwuc2xpY2UoMCwgZnJhZ21lbnRJbmRleCk7XG4gIGNvbnN0IHJlZGFjdGVkVVJMV2l0aG91dEZyYWdtZW50ID0gdXJsV2l0aG91dEZyYWdtZW50LnJlcGxhY2UoXG4gICAgLyhbPyZdW149JiNdKj0pW14mI10qL2csXG4gICAgYCQxJHtSRURBQ1RFRH1gXG4gICk7XG5cbiAgaWYgKGZyYWdtZW50SW5kZXggPT09IC0xKSB7XG4gICAgcmV0dXJuIHJlZGFjdGVkVVJMV2l0aG91dEZyYWdtZW50O1xuICB9XG5cbiAgcmV0dXJuIGAke3JlZGFjdGVkVVJMV2l0aG91dEZyYWdtZW50fSMke3JlZGFjdEZyYWdtZW50KHJlZGFjdGVkVVJMLnNsaWNlKGZyYWdtZW50SW5kZXggKyAxKSl9YDtcbn1cblxuZnVuY3Rpb24gYXNzZXJ0VmFsaWRIdHRwUHJvdG9jb2xVUkwodXJsLCBjb25maWcpIHtcbiAgaWYgKHR5cGVvZiB1cmwgPT09ICdzdHJpbmcnKSB7XG4gICAgY29uc3Qgbm9ybWFsaXplZFVSTCA9IG5vcm1hbGl6ZVVSTEZvclByb3RvY29sQ2hlY2sodXJsKTtcbiAgICBpZiAobWFsZm9ybWVkSHR0cFByb3RvY29sLnRlc3Qobm9ybWFsaXplZFVSTCkpIHtcbiAgICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKFxuICAgICAgICBgSW52YWxpZCBVUkwgJHtKU09OLnN0cmluZ2lmeShyZWRhY3RTZW5zaXRpdmVVUkxQYXJ0cyhub3JtYWxpemVkVVJMKSl9OiBtaXNzaW5nIFwiLy9cIiBhZnRlciBwcm90b2NvbGAsXG4gICAgICAgIEF4aW9zRXJyb3IuRVJSX0lOVkFMSURfVVJMLFxuICAgICAgICBjb25maWdcbiAgICAgICk7XG4gICAgfVxuICB9XG59XG5cbi8qKlxuICogQ3JlYXRlcyBhIG5ldyBVUkwgYnkgY29tYmluaW5nIHRoZSBiYXNlVVJMIHdpdGggdGhlIHJlcXVlc3RlZFVSTCxcbiAqIG9ubHkgd2hlbiB0aGUgcmVxdWVzdGVkVVJMIGlzIG5vdCBhbHJlYWR5IGFuIGFic29sdXRlIFVSTC5cbiAqIElmIHRoZSByZXF1ZXN0VVJMIGlzIGFic29sdXRlLCB0aGlzIGZ1bmN0aW9uIHJldHVybnMgdGhlIHJlcXVlc3RlZFVSTCB1bnRvdWNoZWQuXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IGJhc2VVUkwgVGhlIGJhc2UgVVJMXG4gKiBAcGFyYW0ge3N0cmluZ30gcmVxdWVzdGVkVVJMIEFic29sdXRlIG9yIHJlbGF0aXZlIFVSTCB0byBjb21iaW5lXG4gKlxuICogQHJldHVybnMge3N0cmluZ30gVGhlIGNvbWJpbmVkIGZ1bGwgcGF0aFxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBidWlsZEZ1bGxQYXRoKGJhc2VVUkwsIHJlcXVlc3RlZFVSTCwgYWxsb3dBYnNvbHV0ZVVybHMsIGNvbmZpZykge1xuICBhc3NlcnRWYWxpZEh0dHBQcm90b2NvbFVSTChyZXF1ZXN0ZWRVUkwsIGNvbmZpZyk7XG4gIGxldCBpc1JlbGF0aXZlVXJsID0gIWlzQWJzb2x1dGVVUkwocmVxdWVzdGVkVVJMKTtcbiAgaWYgKGJhc2VVUkwgJiYgKGlzUmVsYXRpdmVVcmwgfHwgYWxsb3dBYnNvbHV0ZVVybHMgPT09IGZhbHNlKSkge1xuICAgIGFzc2VydFZhbGlkSHR0cFByb3RvY29sVVJMKGJhc2VVUkwsIGNvbmZpZyk7XG4gICAgcmV0dXJuIGNvbWJpbmVVUkxzKGJhc2VVUkwsIHJlcXVlc3RlZFVSTCk7XG4gIH1cbiAgcmV0dXJuIHJlcXVlc3RlZFVSTDtcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCBBeGlvc0hlYWRlcnMgZnJvbSAnLi9BeGlvc0hlYWRlcnMuanMnO1xuXG5jb25zdCBoZWFkZXJzVG9PYmplY3QgPSAodGhpbmcpID0+ICh0aGluZyBpbnN0YW5jZW9mIEF4aW9zSGVhZGVycyA/IHsgLi4udGhpbmcgfSA6IHRoaW5nKTtcblxuY29uc3Qgb3duRW51bWVyYWJsZUtleXMgPSAodGhpbmcpID0+IHtcbiAgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMgJiYgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcikge1xuICAgIHJldHVybiBPYmplY3Qua2V5cyh0aGluZykuY29uY2F0KFxuICAgICAgT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyh0aGluZykuZmlsdGVyKFxuICAgICAgICAoc3ltYm9sKSA9PiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHRoaW5nLCBzeW1ib2wpLmVudW1lcmFibGVcbiAgICAgIClcbiAgICApO1xuICB9XG4gIHJldHVybiBPYmplY3Qua2V5cyh0aGluZyk7XG59O1xuXG4vKipcbiAqIENvbmZpZy1zcGVjaWZpYyBtZXJnZS1mdW5jdGlvbiB3aGljaCBjcmVhdGVzIGEgbmV3IGNvbmZpZy1vYmplY3RcbiAqIGJ5IG1lcmdpbmcgdHdvIGNvbmZpZ3VyYXRpb24gb2JqZWN0cyB0b2dldGhlci5cbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gY29uZmlnMVxuICogQHBhcmFtIHtPYmplY3R9IGNvbmZpZzJcbiAqXG4gKiBAcmV0dXJucyB7T2JqZWN0fSBOZXcgb2JqZWN0IHJlc3VsdGluZyBmcm9tIG1lcmdpbmcgY29uZmlnMiB0byBjb25maWcxXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIG1lcmdlQ29uZmlnKGNvbmZpZzEsIGNvbmZpZzIpIHtcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXBhcmFtLXJlYXNzaWduXG4gIGNvbmZpZzEgPSBjb25maWcxIHx8IHt9O1xuICBjb25maWcyID0gY29uZmlnMiB8fCB7fTtcblxuICAvLyBVc2UgYSBudWxsLXByb3RvdHlwZSBvYmplY3Qgc28gdGhhdCBkb3duc3RyZWFtIHJlYWRzIHN1Y2ggYXMgYGNvbmZpZy5hdXRoYFxuICAvLyBvciBgY29uZmlnLmJhc2VVUkxgIGNhbm5vdCBpbmhlcml0IHBvbGx1dGVkIHZhbHVlcyBmcm9tIE9iamVjdC5wcm90b3R5cGUuXG4gIC8vIGBoYXNPd25Qcm9wZXJ0eWAgaXMgcmVzdG9yZWQgYXMgYSBub24tZW51bWVyYWJsZSBvd24gc2xvdCB0byBwcmVzZXJ2ZVxuICAvLyBlcmdvbm9taWNzIGZvciB1c2VyIGNvZGUgdGhhdCByZWxpZXMgb24gaXQuXG4gIGNvbnN0IGNvbmZpZyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjb25maWcsICdoYXNPd25Qcm9wZXJ0eScsIHtcbiAgICAvLyBOdWxsLXByb3RvIGRlc2NyaXB0b3Igc28gYSBwb2xsdXRlZCBPYmplY3QucHJvdG90eXBlLmdldCBjYW5ub3QgdHVyblxuICAgIC8vIHRoaXMgZGF0YSBkZXNjcmlwdG9yIGludG8gYW4gYWNjZXNzb3IgZGVzY3JpcHRvciBvbiB0aGUgd2F5IGluLlxuICAgIF9fcHJvdG9fXzogbnVsbCxcbiAgICB2YWx1ZTogT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eSxcbiAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICBjb25maWd1cmFibGU6IHRydWUsXG4gIH0pO1xuXG4gIGZ1bmN0aW9uIGdldE1lcmdlZFZhbHVlKHRhcmdldCwgc291cmNlLCBwcm9wLCBjYXNlbGVzcykge1xuICAgIGlmICh1dGlscy5pc1BsYWluT2JqZWN0KHRhcmdldCkgJiYgdXRpbHMuaXNQbGFpbk9iamVjdChzb3VyY2UpKSB7XG4gICAgICByZXR1cm4gdXRpbHMubWVyZ2UuY2FsbCh7IGNhc2VsZXNzIH0sIHRhcmdldCwgc291cmNlKTtcbiAgICB9IGVsc2UgaWYgKHV0aWxzLmlzUGxhaW5PYmplY3Qoc291cmNlKSkge1xuICAgICAgcmV0dXJuIHV0aWxzLm1lcmdlKHt9LCBzb3VyY2UpO1xuICAgIH0gZWxzZSBpZiAodXRpbHMuaXNBcnJheShzb3VyY2UpKSB7XG4gICAgICByZXR1cm4gc291cmNlLnNsaWNlKCk7XG4gICAgfVxuICAgIHJldHVybiBzb3VyY2U7XG4gIH1cblxuICBmdW5jdGlvbiBtZXJnZURlZXBQcm9wZXJ0aWVzKGEsIGIsIHByb3AsIGNhc2VsZXNzKSB7XG4gICAgaWYgKCF1dGlscy5pc1VuZGVmaW5lZChiKSkge1xuICAgICAgcmV0dXJuIGdldE1lcmdlZFZhbHVlKGEsIGIsIHByb3AsIGNhc2VsZXNzKTtcbiAgICB9IGVsc2UgaWYgKCF1dGlscy5pc1VuZGVmaW5lZChhKSkge1xuICAgICAgcmV0dXJuIGdldE1lcmdlZFZhbHVlKHVuZGVmaW5lZCwgYSwgcHJvcCwgY2FzZWxlc3MpO1xuICAgIH1cbiAgfVxuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjb25zaXN0ZW50LXJldHVyblxuICBmdW5jdGlvbiB2YWx1ZUZyb21Db25maWcyKGEsIGIpIHtcbiAgICBpZiAoIXV0aWxzLmlzVW5kZWZpbmVkKGIpKSB7XG4gICAgICByZXR1cm4gZ2V0TWVyZ2VkVmFsdWUodW5kZWZpbmVkLCBiKTtcbiAgICB9XG4gIH1cblxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgY29uc2lzdGVudC1yZXR1cm5cbiAgZnVuY3Rpb24gZGVmYXVsdFRvQ29uZmlnMihhLCBiKSB7XG4gICAgaWYgKCF1dGlscy5pc1VuZGVmaW5lZChiKSkge1xuICAgICAgcmV0dXJuIGdldE1lcmdlZFZhbHVlKHVuZGVmaW5lZCwgYik7XG4gICAgfSBlbHNlIGlmICghdXRpbHMuaXNVbmRlZmluZWQoYSkpIHtcbiAgICAgIHJldHVybiBnZXRNZXJnZWRWYWx1ZSh1bmRlZmluZWQsIGEpO1xuICAgIH1cbiAgfVxuXG4gIGZ1bmN0aW9uIGdldE1lcmdlZFRyYW5zaXRpb25hbE9wdGlvbihwcm9wKSB7XG4gICAgY29uc3QgdHJhbnNpdGlvbmFsMiA9IHV0aWxzLmhhc093blByb3AoY29uZmlnMiwgJ3RyYW5zaXRpb25hbCcpXG4gICAgICA/IGNvbmZpZzIudHJhbnNpdGlvbmFsXG4gICAgICA6IHVuZGVmaW5lZDtcblxuICAgIGlmICghdXRpbHMuaXNVbmRlZmluZWQodHJhbnNpdGlvbmFsMikpIHtcbiAgICAgIGlmICh1dGlscy5pc1BsYWluT2JqZWN0KHRyYW5zaXRpb25hbDIpKSB7XG4gICAgICAgIGlmICh1dGlscy5oYXNPd25Qcm9wKHRyYW5zaXRpb25hbDIsIHByb3ApKSB7XG4gICAgICAgICAgcmV0dXJuIHRyYW5zaXRpb25hbDJbcHJvcF07XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgdHJhbnNpdGlvbmFsMSA9IHV0aWxzLmhhc093blByb3AoY29uZmlnMSwgJ3RyYW5zaXRpb25hbCcpXG4gICAgICA/IGNvbmZpZzEudHJhbnNpdGlvbmFsXG4gICAgICA6IHVuZGVmaW5lZDtcblxuICAgIGlmICh1dGlscy5pc1BsYWluT2JqZWN0KHRyYW5zaXRpb25hbDEpICYmIHV0aWxzLmhhc093blByb3AodHJhbnNpdGlvbmFsMSwgcHJvcCkpIHtcbiAgICAgIHJldHVybiB0cmFuc2l0aW9uYWwxW3Byb3BdO1xuICAgIH1cblxuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cblxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgY29uc2lzdGVudC1yZXR1cm5cbiAgZnVuY3Rpb24gbWVyZ2VEaXJlY3RLZXlzKGEsIGIsIHByb3ApIHtcbiAgICBpZiAodXRpbHMuaGFzT3duUHJvcChjb25maWcyLCBwcm9wKSkge1xuICAgICAgcmV0dXJuIGdldE1lcmdlZFZhbHVlKGEsIGIpO1xuICAgIH0gZWxzZSBpZiAodXRpbHMuaGFzT3duUHJvcChjb25maWcxLCBwcm9wKSkge1xuICAgICAgcmV0dXJuIGdldE1lcmdlZFZhbHVlKHVuZGVmaW5lZCwgYSk7XG4gICAgfVxuICB9XG5cbiAgY29uc3QgbWVyZ2VNYXAgPSB7XG4gICAgdXJsOiB2YWx1ZUZyb21Db25maWcyLFxuICAgIG1ldGhvZDogdmFsdWVGcm9tQ29uZmlnMixcbiAgICBkYXRhOiB2YWx1ZUZyb21Db25maWcyLFxuICAgIGJhc2VVUkw6IGRlZmF1bHRUb0NvbmZpZzIsXG4gICAgdHJhbnNmb3JtUmVxdWVzdDogZGVmYXVsdFRvQ29uZmlnMixcbiAgICB0cmFuc2Zvcm1SZXNwb25zZTogZGVmYXVsdFRvQ29uZmlnMixcbiAgICBwYXJhbXNTZXJpYWxpemVyOiBkZWZhdWx0VG9Db25maWcyLFxuICAgIHRpbWVvdXQ6IGRlZmF1bHRUb0NvbmZpZzIsXG4gICAgdGltZW91dEVycm9yTWVzc2FnZTogZGVmYXVsdFRvQ29uZmlnMixcbiAgICB3aXRoQ3JlZGVudGlhbHM6IGRlZmF1bHRUb0NvbmZpZzIsXG4gICAgd2l0aFhTUkZUb2tlbjogZGVmYXVsdFRvQ29uZmlnMixcbiAgICBhZGFwdGVyOiBkZWZhdWx0VG9Db25maWcyLFxuICAgIHJlc3BvbnNlVHlwZTogZGVmYXVsdFRvQ29uZmlnMixcbiAgICB4c3JmQ29va2llTmFtZTogZGVmYXVsdFRvQ29uZmlnMixcbiAgICB4c3JmSGVhZGVyTmFtZTogZGVmYXVsdFRvQ29uZmlnMixcbiAgICBvblVwbG9hZFByb2dyZXNzOiBkZWZhdWx0VG9Db25maWcyLFxuICAgIG9uRG93bmxvYWRQcm9ncmVzczogZGVmYXVsdFRvQ29uZmlnMixcbiAgICBkZWNvbXByZXNzOiBkZWZhdWx0VG9Db25maWcyLFxuICAgIG1heENvbnRlbnRMZW5ndGg6IGRlZmF1bHRUb0NvbmZpZzIsXG4gICAgbWF4Qm9keUxlbmd0aDogZGVmYXVsdFRvQ29uZmlnMixcbiAgICBiZWZvcmVSZWRpcmVjdDogZGVmYXVsdFRvQ29uZmlnMixcbiAgICB0cmFuc3BvcnQ6IGRlZmF1bHRUb0NvbmZpZzIsXG4gICAgaHR0cEFnZW50OiBkZWZhdWx0VG9Db25maWcyLFxuICAgIGh0dHBzQWdlbnQ6IGRlZmF1bHRUb0NvbmZpZzIsXG4gICAgY2FuY2VsVG9rZW46IGRlZmF1bHRUb0NvbmZpZzIsXG4gICAgc29ja2V0UGF0aDogZGVmYXVsdFRvQ29uZmlnMixcbiAgICBhbGxvd2VkU29ja2V0UGF0aHM6IGRlZmF1bHRUb0NvbmZpZzIsXG4gICAgcmVzcG9uc2VFbmNvZGluZzogZGVmYXVsdFRvQ29uZmlnMixcbiAgICB2YWxpZGF0ZVN0YXR1czogbWVyZ2VEaXJlY3RLZXlzLFxuICAgIGhlYWRlcnM6IChhLCBiLCBwcm9wKSA9PlxuICAgICAgbWVyZ2VEZWVwUHJvcGVydGllcyhoZWFkZXJzVG9PYmplY3QoYSksIGhlYWRlcnNUb09iamVjdChiKSwgcHJvcCwgdHJ1ZSksXG4gIH07XG5cbiAgdXRpbHMuZm9yRWFjaChvd25FbnVtZXJhYmxlS2V5cyh7IC4uLmNvbmZpZzEsIC4uLmNvbmZpZzIgfSksIGZ1bmN0aW9uIGNvbXB1dGVDb25maWdWYWx1ZShwcm9wKSB7XG4gICAgaWYgKHByb3AgPT09ICdfX3Byb3RvX18nIHx8IHByb3AgPT09ICdjb25zdHJ1Y3RvcicgfHwgcHJvcCA9PT0gJ3Byb3RvdHlwZScpIHJldHVybjtcbiAgICBjb25zdCBtZXJnZSA9IHV0aWxzLmhhc093blByb3AobWVyZ2VNYXAsIHByb3ApID8gbWVyZ2VNYXBbcHJvcF0gOiBtZXJnZURlZXBQcm9wZXJ0aWVzO1xuICAgIGNvbnN0IGEgPSB1dGlscy5oYXNPd25Qcm9wKGNvbmZpZzEsIHByb3ApID8gY29uZmlnMVtwcm9wXSA6IHVuZGVmaW5lZDtcbiAgICBjb25zdCBiID0gdXRpbHMuaGFzT3duUHJvcChjb25maWcyLCBwcm9wKSA/IGNvbmZpZzJbcHJvcF0gOiB1bmRlZmluZWQ7XG4gICAgY29uc3QgY29uZmlnVmFsdWUgPSBtZXJnZShhLCBiLCBwcm9wKTtcbiAgICAodXRpbHMuaXNVbmRlZmluZWQoY29uZmlnVmFsdWUpICYmIG1lcmdlICE9PSBtZXJnZURpcmVjdEtleXMpIHx8IChjb25maWdbcHJvcF0gPSBjb25maWdWYWx1ZSk7XG4gIH0pO1xuXG4gIGlmIChcbiAgICB1dGlscy5oYXNPd25Qcm9wKGNvbmZpZzIsICd2YWxpZGF0ZVN0YXR1cycpICYmXG4gICAgdXRpbHMuaXNVbmRlZmluZWQoY29uZmlnMi52YWxpZGF0ZVN0YXR1cykgJiZcbiAgICBnZXRNZXJnZWRUcmFuc2l0aW9uYWxPcHRpb24oJ3ZhbGlkYXRlU3RhdHVzVW5kZWZpbmVkUmVzb2x2ZXMnKSA9PT0gZmFsc2VcbiAgKSB7XG4gICAgaWYgKHV0aWxzLmhhc093blByb3AoY29uZmlnMSwgJ3ZhbGlkYXRlU3RhdHVzJykpIHtcbiAgICAgIGNvbmZpZy52YWxpZGF0ZVN0YXR1cyA9IGdldE1lcmdlZFZhbHVlKHVuZGVmaW5lZCwgY29uZmlnMS52YWxpZGF0ZVN0YXR1cyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGRlbGV0ZSBjb25maWcudmFsaWRhdGVTdGF0dXM7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGNvbmZpZztcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuY29uc3QgRk9STV9EQVRBX0NPTlRFTlRfSEVBREVSUyA9IFsnY29udGVudC10eXBlJywgJ2NvbnRlbnQtbGVuZ3RoJ107XG5cbi8qKlxuICogQXBwbHkgdGhlIGhlYWRlcnMgZ2VuZXJhdGVkIGJ5IGEgRm9ybURhdGEgaW1wbGVtZW50YXRpb24gdG8gdGhlIHJlcXVlc3QgaGVhZGVycyxcbiAqIGhvbm9yaW5nIHRoZSBgZm9ybURhdGFIZWFkZXJQb2xpY3lgIG9wdGlvbjogd2l0aCAnY29udGVudC1vbmx5JywgY29weSBvbmx5IHRoZVxuICogY29udGVudC0qIGhlYWRlcnM7IG90aGVyd2lzZSBtZXJnZSBhbGwgb2YgdGhlbS5cbiAqXG4gKiBAcGFyYW0ge0F4aW9zSGVhZGVyc30gaGVhZGVycyAtIHRoZSByZXF1ZXN0IGhlYWRlcnMgdG8gbXV0YXRlXG4gKiBAcGFyYW0ge09iamVjdCB8IG51bGwgfCB1bmRlZmluZWR9IGZvcm1IZWFkZXJzIC0gaGVhZGVycyBwcm9kdWNlZCBieSB0aGUgRm9ybURhdGEgaW1wbGVtZW50YXRpb25cbiAqIEBwYXJhbSB7U3RyaW5nfSBbcG9saWN5XSAtIHRoZSByZXNvbHZlZCBgZm9ybURhdGFIZWFkZXJQb2xpY3lgIGNvbmZpZyB2YWx1ZVxuICpcbiAqIEByZXR1cm5zIHt2b2lkfVxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBzZXRGb3JtRGF0YUhlYWRlcnMoaGVhZGVycywgZm9ybUhlYWRlcnMsIHBvbGljeSkge1xuICBpZiAocG9saWN5ICE9PSAnY29udGVudC1vbmx5Jykge1xuICAgIGhlYWRlcnMuc2V0KGZvcm1IZWFkZXJzKTtcbiAgICByZXR1cm47XG4gIH1cblxuICBPYmplY3QuZW50cmllcyhmb3JtSGVhZGVycyB8fCB7fSkuZm9yRWFjaCgoW2tleSwgdmFsXSkgPT4ge1xuICAgIGlmIChGT1JNX0RBVEFfQ09OVEVOVF9IRUFERVJTLmluY2x1ZGVzKGtleS50b0xvd2VyQ2FzZSgpKSkge1xuICAgICAgaGVhZGVycy5zZXQoa2V5LCB2YWwpO1xuICAgIH1cbiAgfSk7XG59XG4iLCJpbXBvcnQgcGxhdGZvcm0gZnJvbSAnLi4vcGxhdGZvcm0vaW5kZXguanMnO1xuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCBBeGlvc0Vycm9yIGZyb20gJy4uL2NvcmUvQXhpb3NFcnJvci5qcyc7XG5pbXBvcnQgaXNVUkxTYW1lT3JpZ2luIGZyb20gJy4vaXNVUkxTYW1lT3JpZ2luLmpzJztcbmltcG9ydCBjb29raWVzIGZyb20gJy4vY29va2llcy5qcyc7XG5pbXBvcnQgYnVpbGRGdWxsUGF0aCBmcm9tICcuLi9jb3JlL2J1aWxkRnVsbFBhdGguanMnO1xuaW1wb3J0IG1lcmdlQ29uZmlnIGZyb20gJy4uL2NvcmUvbWVyZ2VDb25maWcuanMnO1xuaW1wb3J0IEF4aW9zSGVhZGVycyBmcm9tICcuLi9jb3JlL0F4aW9zSGVhZGVycy5qcyc7XG5pbXBvcnQgc2V0Rm9ybURhdGFIZWFkZXJzIGZyb20gJy4uL2NvcmUvc2V0Rm9ybURhdGFIZWFkZXJzLmpzJztcbmltcG9ydCBidWlsZFVSTCBmcm9tICcuL2J1aWxkVVJMLmpzJztcblxuLyoqXG4gKiBFbmNvZGUgYSBVVEYtOCBzdHJpbmcgdG8gYSBMYXRpbi0xIGJ5dGUgc3RyaW5nIGZvciB1c2Ugd2l0aCBidG9hKCkuXG4gKiBUaGlzIGlzIGEgbW9kZXJuIHJlcGxhY2VtZW50IGZvciB0aGUgZGVwcmVjYXRlZCB1bmVzY2FwZShlbmNvZGVVUklDb21wb25lbnQoc3RyKSkgcGF0dGVybi5cbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gc3RyIFRoZSBzdHJpbmcgdG8gZW5jb2RlXG4gKlxuICogQHJldHVybnMge3N0cmluZ30gVVRGLTggYnl0ZXMgYXMgYSBMYXRpbi0xIHN0cmluZ1xuICovXG5jb25zdCBlbmNvZGVVVEY4ID0gKHN0cikgPT5cbiAgZW5jb2RlVVJJQ29tcG9uZW50KHN0cikucmVwbGFjZSgvJShbMC05QS1GXXsyfSkvZ2ksIChfLCBoZXgpID0+XG4gICAgU3RyaW5nLmZyb21DaGFyQ29kZShwYXJzZUludChoZXgsIDE2KSlcbiAgKTtcblxuZnVuY3Rpb24gcmVzb2x2ZUNvbmZpZyhjb25maWcpIHtcbiAgY29uc3QgbmV3Q29uZmlnID0gbWVyZ2VDb25maWcoe30sIGNvbmZpZyk7XG5cbiAgLy8gUmVhZCBvbmx5IG93biBwcm9wZXJ0aWVzIHRvIHByZXZlbnQgcHJvdG90eXBlIHBvbGx1dGlvbiBnYWRnZXRzXG4gIC8vIChlLmcuIE9iamVjdC5wcm90b3R5cGUuYmFzZVVSTCA9ICdodHRwczovL2V2aWwuY29tJykuXG4gIGNvbnN0IG93biA9IChrZXkpID0+ICh1dGlscy5oYXNPd25Qcm9wKG5ld0NvbmZpZywga2V5KSA/IG5ld0NvbmZpZ1trZXldIDogdW5kZWZpbmVkKTtcblxuICBjb25zdCBkYXRhID0gb3duKCdkYXRhJyk7XG4gIGxldCB3aXRoWFNSRlRva2VuID0gb3duKCd3aXRoWFNSRlRva2VuJyk7XG4gIGNvbnN0IHhzcmZIZWFkZXJOYW1lID0gb3duKCd4c3JmSGVhZGVyTmFtZScpO1xuICBjb25zdCB4c3JmQ29va2llTmFtZSA9IG93bigneHNyZkNvb2tpZU5hbWUnKTtcbiAgbGV0IGhlYWRlcnMgPSBvd24oJ2hlYWRlcnMnKTtcbiAgY29uc3QgYXV0aCA9IG93bignYXV0aCcpO1xuICBjb25zdCBiYXNlVVJMID0gb3duKCdiYXNlVVJMJyk7XG4gIGNvbnN0IGFsbG93QWJzb2x1dGVVcmxzID0gb3duKCdhbGxvd0Fic29sdXRlVXJscycpO1xuICBjb25zdCB1cmwgPSBvd24oJ3VybCcpO1xuXG4gIG5ld0NvbmZpZy5oZWFkZXJzID0gaGVhZGVycyA9IEF4aW9zSGVhZGVycy5mcm9tKGhlYWRlcnMpO1xuXG4gIG5ld0NvbmZpZy51cmwgPSBidWlsZFVSTChcbiAgICBidWlsZEZ1bGxQYXRoKGJhc2VVUkwsIHVybCwgYWxsb3dBYnNvbHV0ZVVybHMsIG5ld0NvbmZpZyksXG4gICAgb3duKCdwYXJhbXMnKSxcbiAgICBvd24oJ3BhcmFtc1NlcmlhbGl6ZXInKVxuICApO1xuXG4gIC8vIEhUVFAgYmFzaWMgYXV0aGVudGljYXRpb25cbiAgaWYgKGF1dGgpIHtcbiAgICBjb25zdCB1c2VybmFtZSA9IHV0aWxzLmdldFNhZmVQcm9wKGF1dGgsICd1c2VybmFtZScpIHx8ICcnO1xuICAgIGNvbnN0IHBhc3N3b3JkID0gdXRpbHMuZ2V0U2FmZVByb3AoYXV0aCwgJ3Bhc3N3b3JkJykgfHwgJyc7XG5cbiAgICB0cnkge1xuICAgICAgaGVhZGVycy5zZXQoXG4gICAgICAgICdBdXRob3JpemF0aW9uJyxcbiAgICAgICAgJ0Jhc2ljICcgKyBidG9hKHVzZXJuYW1lICsgJzonICsgKHBhc3N3b3JkID8gZW5jb2RlVVRGOChwYXNzd29yZCkgOiAnJykpXG4gICAgICApO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHRocm93IEF4aW9zRXJyb3IuZnJvbShlLCBBeGlvc0Vycm9yLkVSUl9CQURfT1BUSU9OX1ZBTFVFLCBjb25maWcpO1xuICAgIH1cbiAgfVxuXG4gIGlmICh1dGlscy5pc0Zvcm1EYXRhKGRhdGEpKSB7XG4gICAgY29uc3QgZ2V0SGVhZGVycyA9IHV0aWxzLmdldFNhZmVQcm9wKGRhdGEsICdnZXRIZWFkZXJzJyk7XG5cbiAgICBpZiAoXG4gICAgICBwbGF0Zm9ybS5oYXNTdGFuZGFyZEJyb3dzZXJFbnYgfHxcbiAgICAgIHBsYXRmb3JtLmhhc1N0YW5kYXJkQnJvd3NlcldlYldvcmtlckVudiB8fFxuICAgICAgdXRpbHMuaXNSZWFjdE5hdGl2ZShkYXRhKVxuICAgICkge1xuICAgICAgaGVhZGVycy5zZXRDb250ZW50VHlwZSh1bmRlZmluZWQpOyAvLyBicm93c2VyL3dlYiB3b3JrZXIvUk4gaGFuZGxlcyBpdFxuICAgIH0gZWxzZSBpZiAodXRpbHMuaXNGdW5jdGlvbihnZXRIZWFkZXJzKSkge1xuICAgICAgLy8gTm9kZS5qcyBGb3JtRGF0YSAobGlrZSBmb3JtLWRhdGEgcGFja2FnZSlcbiAgICAgIHNldEZvcm1EYXRhSGVhZGVycyhoZWFkZXJzLCBnZXRIZWFkZXJzLmNhbGwoZGF0YSksIG93bignZm9ybURhdGFIZWFkZXJQb2xpY3knKSk7XG4gICAgfVxuICB9XG5cbiAgLy8gQWRkIHhzcmYgaGVhZGVyXG4gIC8vIFRoaXMgaXMgb25seSBkb25lIGlmIHJ1bm5pbmcgaW4gYSBzdGFuZGFyZCBicm93c2VyIGVudmlyb25tZW50LlxuICAvLyBTcGVjaWZpY2FsbHkgbm90IGlmIHdlJ3JlIGluIGEgd2ViIHdvcmtlciwgb3IgcmVhY3QtbmF0aXZlLlxuXG4gIGlmIChwbGF0Zm9ybS5oYXNTdGFuZGFyZEJyb3dzZXJFbnYpIHtcbiAgICBpZiAodXRpbHMuaXNGdW5jdGlvbih3aXRoWFNSRlRva2VuKSkge1xuICAgICAgd2l0aFhTUkZUb2tlbiA9IHdpdGhYU1JGVG9rZW4obmV3Q29uZmlnKTtcbiAgICB9XG5cbiAgICAvLyBTdHJpY3QgYm9vbGVhbiBjaGVjayDigJQgcHJldmVudHMgcHJvdG8tcG9sbHV0aW9uIGdhZGdldHMgKGUuZy4gT2JqZWN0LnByb3RvdHlwZS53aXRoWFNSRlRva2VuID0gMSlcbiAgICAvLyBhbmQgbWlzY29uZmlndXJhdGlvbnMgKGUuZy4gXCJmYWxzZVwiKSBmcm9tIHNob3J0LWNpcmN1aXRpbmcgdGhlIHNhbWUtb3JpZ2luIGNoZWNrIGFuZCBsZWFraW5nXG4gICAgLy8gdGhlIFhTUkYgdG9rZW4gY3Jvc3Mtb3JpZ2luLlxuICAgIGNvbnN0IHNob3VsZFNlbmRYU1JGID1cbiAgICAgIHdpdGhYU1JGVG9rZW4gPT09IHRydWUgfHwgKHdpdGhYU1JGVG9rZW4gPT0gbnVsbCAmJiBpc1VSTFNhbWVPcmlnaW4obmV3Q29uZmlnLnVybCkpO1xuXG4gICAgaWYgKHNob3VsZFNlbmRYU1JGKSB7XG4gICAgICBjb25zdCB4c3JmVmFsdWUgPSB4c3JmSGVhZGVyTmFtZSAmJiB4c3JmQ29va2llTmFtZSAmJiBjb29raWVzLnJlYWQoeHNyZkNvb2tpZU5hbWUpO1xuXG4gICAgICBpZiAoeHNyZlZhbHVlKSB7XG4gICAgICAgIGhlYWRlcnMuc2V0KHhzcmZIZWFkZXJOYW1lLCB4c3JmVmFsdWUpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiBuZXdDb25maWc7XG59XG5cbmV4cG9ydCBkZWZhdWx0IHJlc29sdmVDb25maWc7XG4iLCJpbXBvcnQgdXRpbHMgZnJvbSAnLi4vdXRpbHMuanMnO1xuaW1wb3J0IHNldHRsZSBmcm9tICcuLi9jb3JlL3NldHRsZS5qcyc7XG5pbXBvcnQgdHJhbnNpdGlvbmFsRGVmYXVsdHMgZnJvbSAnLi4vZGVmYXVsdHMvdHJhbnNpdGlvbmFsLmpzJztcbmltcG9ydCBBeGlvc0Vycm9yIGZyb20gJy4uL2NvcmUvQXhpb3NFcnJvci5qcyc7XG5pbXBvcnQgQ2FuY2VsZWRFcnJvciBmcm9tICcuLi9jYW5jZWwvQ2FuY2VsZWRFcnJvci5qcyc7XG5pbXBvcnQgbm9ybWFsaXplVVJMRm9yUHJvdG9jb2xDaGVjayBmcm9tICcuLi9oZWxwZXJzL25vcm1hbGl6ZVVSTEZvclByb3RvY29sQ2hlY2suanMnO1xuaW1wb3J0IHBhcnNlUHJvdG9jb2wgZnJvbSAnLi4vaGVscGVycy9wYXJzZVByb3RvY29sLmpzJztcbmltcG9ydCBwbGF0Zm9ybSBmcm9tICcuLi9wbGF0Zm9ybS9pbmRleC5qcyc7XG5pbXBvcnQgQXhpb3NIZWFkZXJzIGZyb20gJy4uL2NvcmUvQXhpb3NIZWFkZXJzLmpzJztcbmltcG9ydCB7IHByb2dyZXNzRXZlbnRSZWR1Y2VyIH0gZnJvbSAnLi4vaGVscGVycy9wcm9ncmVzc0V2ZW50UmVkdWNlci5qcyc7XG5pbXBvcnQgcmVzb2x2ZUNvbmZpZyBmcm9tICcuLi9oZWxwZXJzL3Jlc29sdmVDb25maWcuanMnO1xuaW1wb3J0IHsgdG9CeXRlU3RyaW5nSGVhZGVyT2JqZWN0IH0gZnJvbSAnLi4vaGVscGVycy9zYW5pdGl6ZUhlYWRlclZhbHVlLmpzJztcblxuY29uc3QgaXNYSFJBZGFwdGVyU3VwcG9ydGVkID0gdHlwZW9mIFhNTEh0dHBSZXF1ZXN0ICE9PSAndW5kZWZpbmVkJztcblxuZXhwb3J0IGRlZmF1bHQgaXNYSFJBZGFwdGVyU3VwcG9ydGVkICYmXG4gIGZ1bmN0aW9uIChjb25maWcpIHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gZGlzcGF0Y2hYaHJSZXF1ZXN0KHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgY29uc3QgX2NvbmZpZyA9IHJlc29sdmVDb25maWcoY29uZmlnKTtcbiAgICAgIGxldCByZXF1ZXN0RGF0YSA9IF9jb25maWcuZGF0YTtcbiAgICAgIGNvbnN0IHJlcXVlc3RIZWFkZXJzID0gQXhpb3NIZWFkZXJzLmZyb20oX2NvbmZpZy5oZWFkZXJzKS5ub3JtYWxpemUoKTtcbiAgICAgIGxldCB7IHJlc3BvbnNlVHlwZSwgb25VcGxvYWRQcm9ncmVzcywgb25Eb3dubG9hZFByb2dyZXNzIH0gPSBfY29uZmlnO1xuICAgICAgbGV0IG9uQ2FuY2VsZWQ7XG4gICAgICBsZXQgdXBsb2FkVGhyb3R0bGVkLCBkb3dubG9hZFRocm90dGxlZDtcbiAgICAgIGxldCBmbHVzaFVwbG9hZCwgZmx1c2hEb3dubG9hZCwgZmx1c2hEb3dubG9hZFdpdGhFdmVudDtcblxuICAgICAgZnVuY3Rpb24gZG9uZSgpIHtcbiAgICAgICAgZmx1c2hVcGxvYWQgJiYgZmx1c2hVcGxvYWQoKTsgLy8gZmx1c2ggZXZlbnRzXG4gICAgICAgIGZsdXNoRG93bmxvYWQgJiYgZmx1c2hEb3dubG9hZCgpOyAvLyBmbHVzaCBldmVudHNcblxuICAgICAgICBfY29uZmlnLmNhbmNlbFRva2VuICYmIF9jb25maWcuY2FuY2VsVG9rZW4udW5zdWJzY3JpYmUob25DYW5jZWxlZCk7XG5cbiAgICAgICAgX2NvbmZpZy5zaWduYWwgJiYgX2NvbmZpZy5zaWduYWwucmVtb3ZlRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBvbkNhbmNlbGVkKTtcbiAgICAgIH1cblxuICAgICAgbGV0IHJlcXVlc3QgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcblxuICAgICAgcmVxdWVzdC5vcGVuKF9jb25maWcubWV0aG9kLnRvVXBwZXJDYXNlKCksIF9jb25maWcudXJsLCB0cnVlKTtcblxuICAgICAgLy8gU2V0IHRoZSByZXF1ZXN0IHRpbWVvdXQgaW4gTVNcbiAgICAgIHJlcXVlc3QudGltZW91dCA9IF9jb25maWcudGltZW91dDtcblxuICAgICAgZnVuY3Rpb24gb25sb2FkZW5kKGV2ZW50KSB7XG4gICAgICAgIGlmICghcmVxdWVzdCkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFN0YXR1cyAwIG1lYW5zIG5vIHJlc3BvbnNlIHdhcyByZWNlaXZlZCwgd2hpY2ggb25lcnJvciBhbmQgb25hYm9ydCBub3JtYWxseVxuICAgICAgICAvLyByZWplY3QgYmVmb3JlIHRoaXMgcnVucy4gRmlyZWZveCAxNTIgZmlyZXMgb25seSByZWFkeXN0YXRlY2hhbmdlIGFuZCBsb2FkZW5kIGZvclxuICAgICAgICAvLyBuYXZpZ2F0aW9uLWNhbmNlbGVkIHJlcXVlc3RzIChodHRwczovL2J1Z3ppbGxhLm1vemlsbGEub3JnL3Nob3dfYnVnLmNnaT9pZD0xNTA1Mzg5KSxcbiAgICAgICAgLy8gbGVhdmluZyBzZXR0bGUoKSB0byByZXNvbHZlIHRoZW0gYXMgYW4gZW1wdHkgc3VjY2Vzcy4gRUNPTk5BQk9SVEVEIGlzIHRoZSBlcnJvclxuICAgICAgICAvLyBvbmFib3J0IHJhaXNlZCBvbiBGaXJlZm94IDE1MS4gUmVhZHMgb3ZlciBmaWxlOiwgd2hpY2ggc29tZSBlbnZpcm9ubWVudHMgcmVwb3J0IGFzXG4gICAgICAgIC8vIHN0YXR1cyAwIG9uIHN1Y2Nlc3MsIGFyZSBleGNsdWRlZCBieSB0aGUgcmVxdWVzdCBVUkwncyBzY2hlbWUgYWZ0ZXIgYnJvd3Nlci1zdHlsZVxuICAgICAgICAvLyBwcmVwcm9jZXNzaW5nLCBieSB0aGUgcGFnZSBvcmlnaW4ncyBzY2hlbWUgZm9yIHJlbGF0aXZlIFVSTHMgKHdoaWNoIGluaGVyaXQgaXQpLCBvclxuICAgICAgICAvLyBieSByZXNwb25zZVVSTCB3aGVyZSBpbXBsZW1lbnRlZC5cbiAgICAgICAgaWYgKFxuICAgICAgICAgIHJlcXVlc3Quc3RhdHVzID09PSAwICYmXG4gICAgICAgICAgKHBhcnNlUHJvdG9jb2wobm9ybWFsaXplVVJMRm9yUHJvdG9jb2xDaGVjayhfY29uZmlnLnVybCkpIHx8XG4gICAgICAgICAgICBwYXJzZVByb3RvY29sKHBsYXRmb3JtLm9yaWdpbikpICE9PSAnZmlsZScgJiZcbiAgICAgICAgICAhKHJlcXVlc3QucmVzcG9uc2VVUkwgJiYgcmVxdWVzdC5yZXNwb25zZVVSTC5zdGFydHNXaXRoKCdmaWxlOicpKVxuICAgICAgICApIHtcbiAgICAgICAgICByZWplY3QobmV3IEF4aW9zRXJyb3IoJ1JlcXVlc3QgYWJvcnRlZCcsIEF4aW9zRXJyb3IuRUNPTk5BQk9SVEVELCBjb25maWcsIHJlcXVlc3QpKTtcbiAgICAgICAgICBkb25lKCk7XG5cbiAgICAgICAgICAvLyBDbGVhbiB1cCByZXF1ZXN0XG4gICAgICAgICAgcmVxdWVzdCA9IG51bGw7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gV2hlbiBsb2FkZW5kIGlzIHN0aWxsIGRpc3BhdGNoaW5nLCBmbHVzaGluZyB3aXRoIGl0IGdpdmVzIHByb2dyZXNzXG4gICAgICAgIC8vIGxpc3RlbmVycyBhIGZpbmFsIGRlbGl2ZXJ5IHdob3NlIGV2ZW50IGhhcyBhIGxpdmUgdGFyZ2V0LiBUaGUgbGVnYWN5XG4gICAgICAgIC8vIHJlYWR5LXN0YXRlIGZhbGxiYWNrIGhhcyBubyBldmVudCwgc28gcmVwbGF5IGl0cyBwZW5kaW5nIHByb2dyZXNzLlxuICAgICAgICAvLyBBIHRocm93aW5nIGxpc3RlbmVyIG11c3Qgbm90IGJsb2NrIHNldHRsZW1lbnQ7IHJldGhyb3cgYXN5bmNocm9ub3VzbHksXG4gICAgICAgIC8vIG1hdGNoaW5nIGhvdyBsaXN0ZW5lciBlcnJvcnMgc3VyZmFjZSBvbiB0aGUgdGhyb3R0bGUgdGltZXIgcGF0aC5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBpZiAoZXZlbnQpIHtcbiAgICAgICAgICAgIGZsdXNoRG93bmxvYWRXaXRoRXZlbnQgJiYgZmx1c2hEb3dubG9hZFdpdGhFdmVudChldmVudCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGZsdXNoRG93bmxvYWQgJiYgZmx1c2hEb3dubG9hZCgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBBIGZpbmFsIHByb2dyZXNzIGNhbGxiYWNrIGNhbiBjYW5jZWwgdGhlIHJlcXVlc3Qgc3luY2hyb25vdXNseS5cbiAgICAgICAgaWYgKCFyZXF1ZXN0KSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gUHJlcGFyZSB0aGUgcmVzcG9uc2VcbiAgICAgICAgY29uc3QgcmVzcG9uc2VIZWFkZXJzID0gQXhpb3NIZWFkZXJzLmZyb20oXG4gICAgICAgICAgJ2dldEFsbFJlc3BvbnNlSGVhZGVycycgaW4gcmVxdWVzdCAmJiByZXF1ZXN0LmdldEFsbFJlc3BvbnNlSGVhZGVycygpXG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9XG4gICAgICAgICAgIXJlc3BvbnNlVHlwZSB8fCByZXNwb25zZVR5cGUgPT09ICd0ZXh0JyB8fCByZXNwb25zZVR5cGUgPT09ICdqc29uJ1xuICAgICAgICAgICAgPyByZXF1ZXN0LnJlc3BvbnNlVGV4dFxuICAgICAgICAgICAgOiByZXF1ZXN0LnJlc3BvbnNlO1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IHtcbiAgICAgICAgICBkYXRhOiByZXNwb25zZURhdGEsXG4gICAgICAgICAgc3RhdHVzOiByZXF1ZXN0LnN0YXR1cyxcbiAgICAgICAgICBzdGF0dXNUZXh0OiByZXF1ZXN0LnN0YXR1c1RleHQsXG4gICAgICAgICAgaGVhZGVyczogcmVzcG9uc2VIZWFkZXJzLFxuICAgICAgICAgIGNvbmZpZyxcbiAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICB9O1xuXG4gICAgICAgIHNldHRsZShcbiAgICAgICAgICBmdW5jdGlvbiBfcmVzb2x2ZSh2YWx1ZSkge1xuICAgICAgICAgICAgcmVzb2x2ZSh2YWx1ZSk7XG4gICAgICAgICAgICBkb25lKCk7XG4gICAgICAgICAgfSxcbiAgICAgICAgICBmdW5jdGlvbiBfcmVqZWN0KGVycikge1xuICAgICAgICAgICAgcmVqZWN0KGVycik7XG4gICAgICAgICAgICBkb25lKCk7XG4gICAgICAgICAgfSxcbiAgICAgICAgICByZXNwb25zZVxuICAgICAgICApO1xuXG4gICAgICAgIC8vIENsZWFuIHVwIHJlcXVlc3RcbiAgICAgICAgcmVxdWVzdCA9IG51bGw7XG4gICAgICB9XG5cbiAgICAgIGlmICgnb25sb2FkZW5kJyBpbiByZXF1ZXN0KSB7XG4gICAgICAgIC8vIFVzZSBvbmxvYWRlbmQgaWYgYXZhaWxhYmxlXG4gICAgICAgIHJlcXVlc3Qub25sb2FkZW5kID0gb25sb2FkZW5kO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gTGlzdGVuIGZvciByZWFkeSBzdGF0ZSB0byBlbXVsYXRlIG9ubG9hZGVuZFxuICAgICAgICByZXF1ZXN0Lm9ucmVhZHlzdGF0ZWNoYW5nZSA9IGZ1bmN0aW9uIGhhbmRsZUxvYWQoKSB7XG4gICAgICAgICAgaWYgKCFyZXF1ZXN0IHx8IHJlcXVlc3QucmVhZHlTdGF0ZSAhPT0gNCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC8vIFRoZSByZXF1ZXN0IGVycm9yZWQgb3V0IGFuZCB3ZSBkaWRuJ3QgZ2V0IGEgcmVzcG9uc2UsIHRoaXMgd2lsbCBiZVxuICAgICAgICAgIC8vIGhhbmRsZWQgYnkgb25lcnJvciBpbnN0ZWFkXG4gICAgICAgICAgLy8gV2l0aCBvbmUgZXhjZXB0aW9uOiByZXF1ZXN0IHRoYXQgdXNpbmcgZmlsZTogcHJvdG9jb2wsIG1vc3QgYnJvd3NlcnNcbiAgICAgICAgICAvLyB3aWxsIHJldHVybiBzdGF0dXMgYXMgMCBldmVuIHRob3VnaCBpdCdzIGEgc3VjY2Vzc2Z1bCByZXF1ZXN0XG4gICAgICAgICAgaWYgKFxuICAgICAgICAgICAgcmVxdWVzdC5zdGF0dXMgPT09IDAgJiZcbiAgICAgICAgICAgICEocmVxdWVzdC5yZXNwb25zZVVSTCAmJiByZXF1ZXN0LnJlc3BvbnNlVVJMLnN0YXJ0c1dpdGgoJ2ZpbGU6JykpXG4gICAgICAgICAgKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIC8vIHJlYWR5c3RhdGUgaGFuZGxlciBpcyBjYWxsaW5nIGJlZm9yZSBvbmVycm9yIG9yIG9udGltZW91dCBoYW5kbGVycyxcbiAgICAgICAgICAvLyBzbyB3ZSBzaG91bGQgY2FsbCBvbmxvYWRlbmQgb24gdGhlIG5leHQgJ3RpY2snXG4gICAgICAgICAgc2V0VGltZW91dChvbmxvYWRlbmQpO1xuICAgICAgICB9O1xuICAgICAgfVxuXG4gICAgICAvLyBIYW5kbGUgYnJvd3NlciByZXF1ZXN0IGNhbmNlbGxhdGlvbiAoYXMgb3Bwb3NlZCB0byBhIG1hbnVhbCBjYW5jZWxsYXRpb24pXG4gICAgICByZXF1ZXN0Lm9uYWJvcnQgPSBmdW5jdGlvbiBoYW5kbGVBYm9ydCgpIHtcbiAgICAgICAgaWYgKCFyZXF1ZXN0KSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgcmVqZWN0KG5ldyBBeGlvc0Vycm9yKCdSZXF1ZXN0IGFib3J0ZWQnLCBBeGlvc0Vycm9yLkVDT05OQUJPUlRFRCwgY29uZmlnLCByZXF1ZXN0KSk7XG4gICAgICAgIGRvbmUoKTtcblxuICAgICAgICAvLyBDbGVhbiB1cCByZXF1ZXN0XG4gICAgICAgIHJlcXVlc3QgPSBudWxsO1xuICAgICAgfTtcblxuICAgICAgLy8gSGFuZGxlIGxvdyBsZXZlbCBuZXR3b3JrIGVycm9yc1xuICAgICAgcmVxdWVzdC5vbmVycm9yID0gZnVuY3Rpb24gaGFuZGxlRXJyb3IoZXZlbnQpIHtcbiAgICAgICAgLy8gQnJvd3NlcnMgZGVsaXZlciBhIFByb2dyZXNzRXZlbnQgaW4gWEhSIG9uZXJyb3JcbiAgICAgICAgLy8gKG1lc3NhZ2UgbWF5IGJlIGVtcHR5OyB3aGVuIHByZXNlbnQsIHN1cmZhY2UgaXQpXG4gICAgICAgIC8vIFNlZSBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9kb2NzL1dlYi9BUEkvWE1MSHR0cFJlcXVlc3QvZXJyb3JfZXZlbnRcbiAgICAgICAgY29uc3QgbXNnID0gZXZlbnQgJiYgZXZlbnQubWVzc2FnZSA/IGV2ZW50Lm1lc3NhZ2UgOiAnTmV0d29yayBFcnJvcic7XG4gICAgICAgIGNvbnN0IGVyciA9IG5ldyBBeGlvc0Vycm9yKG1zZywgQXhpb3NFcnJvci5FUlJfTkVUV09SSywgY29uZmlnLCByZXF1ZXN0KTtcbiAgICAgICAgLy8gYXR0YWNoIHRoZSB1bmRlcmx5aW5nIGV2ZW50IGZvciBjb25zdW1lcnMgd2hvIHdhbnQgZGV0YWlsc1xuICAgICAgICBlcnIuZXZlbnQgPSBldmVudCB8fCBudWxsO1xuICAgICAgICByZWplY3QoZXJyKTtcbiAgICAgICAgZG9uZSgpO1xuICAgICAgICByZXF1ZXN0ID0gbnVsbDtcbiAgICAgIH07XG5cbiAgICAgIC8vIEhhbmRsZSB0aW1lb3V0XG4gICAgICByZXF1ZXN0Lm9udGltZW91dCA9IGZ1bmN0aW9uIGhhbmRsZVRpbWVvdXQoKSB7XG4gICAgICAgIGxldCB0aW1lb3V0RXJyb3JNZXNzYWdlID0gX2NvbmZpZy50aW1lb3V0XG4gICAgICAgICAgPyAndGltZW91dCBvZiAnICsgX2NvbmZpZy50aW1lb3V0ICsgJ21zIGV4Y2VlZGVkJ1xuICAgICAgICAgIDogJ3RpbWVvdXQgZXhjZWVkZWQnO1xuICAgICAgICBjb25zdCB0cmFuc2l0aW9uYWwgPSBfY29uZmlnLnRyYW5zaXRpb25hbCB8fCB0cmFuc2l0aW9uYWxEZWZhdWx0cztcbiAgICAgICAgaWYgKF9jb25maWcudGltZW91dEVycm9yTWVzc2FnZSkge1xuICAgICAgICAgIHRpbWVvdXRFcnJvck1lc3NhZ2UgPSBfY29uZmlnLnRpbWVvdXRFcnJvck1lc3NhZ2U7XG4gICAgICAgIH1cbiAgICAgICAgcmVqZWN0KFxuICAgICAgICAgIG5ldyBBeGlvc0Vycm9yKFxuICAgICAgICAgICAgdGltZW91dEVycm9yTWVzc2FnZSxcbiAgICAgICAgICAgIHRyYW5zaXRpb25hbC5jbGFyaWZ5VGltZW91dEVycm9yID8gQXhpb3NFcnJvci5FVElNRURPVVQgOiBBeGlvc0Vycm9yLkVDT05OQUJPUlRFRCxcbiAgICAgICAgICAgIGNvbmZpZyxcbiAgICAgICAgICAgIHJlcXVlc3RcbiAgICAgICAgICApXG4gICAgICAgICk7XG4gICAgICAgIGRvbmUoKTtcblxuICAgICAgICAvLyBDbGVhbiB1cCByZXF1ZXN0XG4gICAgICAgIHJlcXVlc3QgPSBudWxsO1xuICAgICAgfTtcblxuICAgICAgLy8gUmVtb3ZlIENvbnRlbnQtVHlwZSBpZiBkYXRhIGlzIHVuZGVmaW5lZFxuICAgICAgcmVxdWVzdERhdGEgPT09IHVuZGVmaW5lZCAmJiByZXF1ZXN0SGVhZGVycy5zZXRDb250ZW50VHlwZShudWxsKTtcblxuICAgICAgLy8gQWRkIGhlYWRlcnMgdG8gdGhlIHJlcXVlc3RcbiAgICAgIGlmICgnc2V0UmVxdWVzdEhlYWRlcicgaW4gcmVxdWVzdCkge1xuICAgICAgICB1dGlscy5mb3JFYWNoKHRvQnl0ZVN0cmluZ0hlYWRlck9iamVjdChyZXF1ZXN0SGVhZGVycyksIGZ1bmN0aW9uIHNldFJlcXVlc3RIZWFkZXIodmFsLCBrZXkpIHtcbiAgICAgICAgICByZXF1ZXN0LnNldFJlcXVlc3RIZWFkZXIoa2V5LCB2YWwpO1xuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgLy8gQWRkIHdpdGhDcmVkZW50aWFscyB0byByZXF1ZXN0IGlmIG5lZWRlZFxuICAgICAgaWYgKCF1dGlscy5pc1VuZGVmaW5lZChfY29uZmlnLndpdGhDcmVkZW50aWFscykpIHtcbiAgICAgICAgcmVxdWVzdC53aXRoQ3JlZGVudGlhbHMgPSAhIV9jb25maWcud2l0aENyZWRlbnRpYWxzO1xuICAgICAgfVxuXG4gICAgICAvLyBBZGQgcmVzcG9uc2VUeXBlIHRvIHJlcXVlc3QgaWYgbmVlZGVkXG4gICAgICBpZiAocmVzcG9uc2VUeXBlICYmIHJlc3BvbnNlVHlwZSAhPT0gJ2pzb24nKSB7XG4gICAgICAgIHJlcXVlc3QucmVzcG9uc2VUeXBlID0gX2NvbmZpZy5yZXNwb25zZVR5cGU7XG4gICAgICB9XG5cbiAgICAgIC8vIEhhbmRsZSBwcm9ncmVzcyBpZiBuZWVkZWRcbiAgICAgIGlmIChvbkRvd25sb2FkUHJvZ3Jlc3MpIHtcbiAgICAgICAgW2Rvd25sb2FkVGhyb3R0bGVkLCBmbHVzaERvd25sb2FkLCBmbHVzaERvd25sb2FkV2l0aEV2ZW50XSA9IHByb2dyZXNzRXZlbnRSZWR1Y2VyKFxuICAgICAgICAgIG9uRG93bmxvYWRQcm9ncmVzcyxcbiAgICAgICAgICB0cnVlXG4gICAgICAgICk7XG4gICAgICAgIHJlcXVlc3QuYWRkRXZlbnRMaXN0ZW5lcigncHJvZ3Jlc3MnLCBkb3dubG9hZFRocm90dGxlZCk7XG4gICAgICB9XG5cbiAgICAgIC8vIE5vdCBhbGwgYnJvd3NlcnMgc3VwcG9ydCB1cGxvYWQgZXZlbnRzXG4gICAgICBpZiAob25VcGxvYWRQcm9ncmVzcyAmJiByZXF1ZXN0LnVwbG9hZCkge1xuICAgICAgICBbdXBsb2FkVGhyb3R0bGVkLCBmbHVzaFVwbG9hZF0gPSBwcm9ncmVzc0V2ZW50UmVkdWNlcihvblVwbG9hZFByb2dyZXNzKTtcblxuICAgICAgICByZXF1ZXN0LnVwbG9hZC5hZGRFdmVudExpc3RlbmVyKCdwcm9ncmVzcycsIHVwbG9hZFRocm90dGxlZCk7XG5cbiAgICAgICAgcmVxdWVzdC51cGxvYWQuYWRkRXZlbnRMaXN0ZW5lcignbG9hZGVuZCcsIGZsdXNoVXBsb2FkKTtcbiAgICAgIH1cblxuICAgICAgaWYgKF9jb25maWcuY2FuY2VsVG9rZW4gfHwgX2NvbmZpZy5zaWduYWwpIHtcbiAgICAgICAgLy8gSGFuZGxlIGNhbmNlbGxhdGlvblxuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZnVuYy1uYW1lc1xuICAgICAgICBvbkNhbmNlbGVkID0gKGNhbmNlbCkgPT4ge1xuICAgICAgICAgIGlmICghcmVxdWVzdCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZWplY3QoIWNhbmNlbCB8fCBjYW5jZWwudHlwZSA/IG5ldyBDYW5jZWxlZEVycm9yKG51bGwsIGNvbmZpZywgcmVxdWVzdCkgOiBjYW5jZWwpO1xuICAgICAgICAgIHJlcXVlc3QuYWJvcnQoKTtcbiAgICAgICAgICBkb25lKCk7XG4gICAgICAgICAgcmVxdWVzdCA9IG51bGw7XG4gICAgICAgIH07XG5cbiAgICAgICAgX2NvbmZpZy5jYW5jZWxUb2tlbiAmJiBfY29uZmlnLmNhbmNlbFRva2VuLnN1YnNjcmliZShvbkNhbmNlbGVkKTtcbiAgICAgICAgaWYgKF9jb25maWcuc2lnbmFsKSB7XG4gICAgICAgICAgX2NvbmZpZy5zaWduYWwuYWJvcnRlZFxuICAgICAgICAgICAgPyBvbkNhbmNlbGVkKClcbiAgICAgICAgICAgIDogX2NvbmZpZy5zaWduYWwuYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBvbkNhbmNlbGVkKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBjb25zdCBwcm90b2NvbCA9IHBhcnNlUHJvdG9jb2woX2NvbmZpZy51cmwpO1xuXG4gICAgICBpZiAocHJvdG9jb2wgJiYgIXBsYXRmb3JtLnByb3RvY29scy5pbmNsdWRlcyhwcm90b2NvbCkpIHtcbiAgICAgICAgcmVqZWN0KFxuICAgICAgICAgIG5ldyBBeGlvc0Vycm9yKFxuICAgICAgICAgICAgJ1Vuc3VwcG9ydGVkIHByb3RvY29sICcgKyBwcm90b2NvbCArICc6JyxcbiAgICAgICAgICAgIEF4aW9zRXJyb3IuRVJSX0JBRF9SRVFVRVNULFxuICAgICAgICAgICAgY29uZmlnXG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgICBkb25lKCk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgLy8gU2VuZCB0aGUgcmVxdWVzdFxuICAgICAgcmVxdWVzdC5zZW5kKHJlcXVlc3REYXRhIHx8IG51bGwpO1xuICAgIH0pO1xuICB9O1xuIiwiaW1wb3J0IENhbmNlbGVkRXJyb3IgZnJvbSAnLi4vY2FuY2VsL0NhbmNlbGVkRXJyb3IuanMnO1xuaW1wb3J0IEF4aW9zRXJyb3IgZnJvbSAnLi4vY29yZS9BeGlvc0Vycm9yLmpzJztcbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5cbmNvbnN0IGNvbXBvc2VTaWduYWxzID0gKHNpZ25hbHMsIHRpbWVvdXQpID0+IHtcbiAgc2lnbmFscyA9IHNpZ25hbHMgPyBzaWduYWxzLmZpbHRlcihCb29sZWFuKSA6IFtdO1xuXG4gIGlmICghdGltZW91dCAmJiAhc2lnbmFscy5sZW5ndGgpIHtcbiAgICByZXR1cm47XG4gIH1cblxuICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuXG4gIGxldCBhYm9ydGVkID0gZmFsc2U7XG5cbiAgY29uc3Qgb25hYm9ydCA9IGZ1bmN0aW9uIChyZWFzb24pIHtcbiAgICBpZiAoIWFib3J0ZWQpIHtcbiAgICAgIGFib3J0ZWQgPSB0cnVlO1xuICAgICAgdW5zdWJzY3JpYmUoKTtcbiAgICAgIGNvbnN0IGVyciA9IHJlYXNvbiBpbnN0YW5jZW9mIEVycm9yID8gcmVhc29uIDogdGhpcy5yZWFzb247XG4gICAgICBjb250cm9sbGVyLmFib3J0KFxuICAgICAgICBlcnIgaW5zdGFuY2VvZiBBeGlvc0Vycm9yXG4gICAgICAgICAgPyBlcnJcbiAgICAgICAgICA6IG5ldyBDYW5jZWxlZEVycm9yKGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiBlcnIpXG4gICAgICApO1xuICAgIH1cbiAgfTtcblxuICBsZXQgdGltZXIgPVxuICAgIHRpbWVvdXQgJiZcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHRpbWVyID0gbnVsbDtcbiAgICAgIG9uYWJvcnQobmV3IEF4aW9zRXJyb3IoYHRpbWVvdXQgb2YgJHt0aW1lb3V0fW1zIGV4Y2VlZGVkYCwgQXhpb3NFcnJvci5FVElNRURPVVQpKTtcbiAgICB9LCB0aW1lb3V0KTtcblxuICBjb25zdCB1bnN1YnNjcmliZSA9ICgpID0+IHtcbiAgICBpZiAoIXNpZ25hbHMpIHsgcmV0dXJuOyB9XG4gICAgdGltZXIgJiYgY2xlYXJUaW1lb3V0KHRpbWVyKTtcbiAgICB0aW1lciA9IG51bGw7XG4gICAgc2lnbmFscy5mb3JFYWNoKChzaWduYWwpID0+IHtcbiAgICAgIHNpZ25hbC51bnN1YnNjcmliZVxuICAgICAgICA/IHNpZ25hbC51bnN1YnNjcmliZShvbmFib3J0KVxuICAgICAgICA6IHNpZ25hbC5yZW1vdmVFdmVudExpc3RlbmVyKCdhYm9ydCcsIG9uYWJvcnQpO1xuICAgIH0pO1xuICAgIHNpZ25hbHMgPSBudWxsO1xuICB9O1xuXG4gIHNpZ25hbHMuZm9yRWFjaCgoc2lnbmFsKSA9PiB7XG4gICAgaWYgKGFib3J0ZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoc2lnbmFsLmFib3J0ZWQpIHtcbiAgICAgIG9uYWJvcnQuY2FsbChzaWduYWwpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKCdhYm9ydCcsIG9uYWJvcnQsIHsgb25jZTogdHJ1ZSB9KTtcbiAgfSk7XG5cbiAgY29uc3QgeyBzaWduYWwgfSA9IGNvbnRyb2xsZXI7XG5cbiAgc2lnbmFsLnVuc3Vic2NyaWJlID0gKCkgPT4gdXRpbHMuYXNhcCh1bnN1YnNjcmliZSk7XG5cbiAgcmV0dXJuIHNpZ25hbDtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IGNvbXBvc2VTaWduYWxzO1xuIiwiZXhwb3J0IGNvbnN0IHN0cmVhbUNodW5rID0gZnVuY3Rpb24qIChjaHVuaywgY2h1bmtTaXplKSB7XG4gIGxldCBsZW4gPSBjaHVuay5ieXRlTGVuZ3RoO1xuXG4gIGlmICghY2h1bmtTaXplIHx8IGxlbiA8IGNodW5rU2l6ZSkge1xuICAgIHlpZWxkIGNodW5rO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGxldCBwb3MgPSAwO1xuICBsZXQgZW5kO1xuXG4gIHdoaWxlIChwb3MgPCBsZW4pIHtcbiAgICBlbmQgPSBwb3MgKyBjaHVua1NpemU7XG4gICAgeWllbGQgY2h1bmsuc2xpY2UocG9zLCBlbmQpO1xuICAgIHBvcyA9IGVuZDtcbiAgfVxufTtcblxuZXhwb3J0IGNvbnN0IHJlYWRCeXRlcyA9IGFzeW5jIGZ1bmN0aW9uKiAoaXRlcmFibGUsIGNodW5rU2l6ZSkge1xuICBmb3IgYXdhaXQgKGNvbnN0IGNodW5rIG9mIHJlYWRTdHJlYW0oaXRlcmFibGUpKSB7XG4gICAgeWllbGQqIHN0cmVhbUNodW5rKGNodW5rLCBjaHVua1NpemUpO1xuICB9XG59O1xuXG5jb25zdCByZWFkU3RyZWFtID0gYXN5bmMgZnVuY3Rpb24qIChzdHJlYW0pIHtcbiAgaWYgKHN0cmVhbVtTeW1ib2wuYXN5bmNJdGVyYXRvcl0pIHtcbiAgICB5aWVsZCogc3RyZWFtO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGNvbnN0IHJlYWRlciA9IHN0cmVhbS5nZXRSZWFkZXIoKTtcbiAgdHJ5IHtcbiAgICBmb3IgKDs7KSB7XG4gICAgICBjb25zdCB7IGRvbmUsIHZhbHVlIH0gPSBhd2FpdCByZWFkZXIucmVhZCgpO1xuICAgICAgaWYgKGRvbmUpIHtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICB5aWVsZCB2YWx1ZTtcbiAgICB9XG4gIH0gZmluYWxseSB7XG4gICAgYXdhaXQgcmVhZGVyLmNhbmNlbCgpO1xuICB9XG59O1xuXG5leHBvcnQgY29uc3QgdHJhY2tTdHJlYW0gPSAoc3RyZWFtLCBjaHVua1NpemUsIG9uUHJvZ3Jlc3MsIG9uRmluaXNoKSA9PiB7XG4gIGNvbnN0IGl0ZXJhdG9yID0gcmVhZEJ5dGVzKHN0cmVhbSwgY2h1bmtTaXplKTtcblxuICBsZXQgYnl0ZXMgPSAwO1xuICBsZXQgZG9uZTtcbiAgbGV0IF9vbkZpbmlzaCA9IChlKSA9PiB7XG4gICAgaWYgKCFkb25lKSB7XG4gICAgICBkb25lID0gdHJ1ZTtcbiAgICAgIG9uRmluaXNoICYmIG9uRmluaXNoKGUpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gbmV3IFJlYWRhYmxlU3RyZWFtKFxuICAgIHtcbiAgICAgIGFzeW5jIHB1bGwoY29udHJvbGxlcikge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IHsgZG9uZSwgdmFsdWUgfSA9IGF3YWl0IGl0ZXJhdG9yLm5leHQoKTtcblxuICAgICAgICAgIGlmIChkb25lKSB7XG4gICAgICAgICAgICBfb25GaW5pc2goKTtcbiAgICAgICAgICAgIGNvbnRyb2xsZXIuY2xvc2UoKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBsZXQgbGVuID0gdmFsdWUuYnl0ZUxlbmd0aDtcbiAgICAgICAgICBpZiAob25Qcm9ncmVzcykge1xuICAgICAgICAgICAgbGV0IGxvYWRlZEJ5dGVzID0gKGJ5dGVzICs9IGxlbik7XG4gICAgICAgICAgICBvblByb2dyZXNzKGxvYWRlZEJ5dGVzKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgY29udHJvbGxlci5lbnF1ZXVlKG5ldyBVaW50OEFycmF5KHZhbHVlKSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIF9vbkZpbmlzaChlcnIpO1xuICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIGNhbmNlbChyZWFzb24pIHtcbiAgICAgICAgX29uRmluaXNoKHJlYXNvbik7XG4gICAgICAgIHJldHVybiBpdGVyYXRvci5yZXR1cm4oKTtcbiAgICAgIH0sXG4gICAgfSxcbiAgICB7XG4gICAgICBoaWdoV2F0ZXJNYXJrOiAyLFxuICAgIH1cbiAgKTtcbn07XG4iLCIvKipcbiAqIEVzdGltYXRlIGRhdGE6IFVSTCBieXRlIGxlbmd0aHMgKndpdGhvdXQqIGFsbG9jYXRpbmcgbGFyZ2UgYnVmZmVycy5cbiAqIC0gRmV0Y2ggcGVyY2VudC1kZWNvZGVzIGEgYmFzZTY0IGJvZHkgYmVmb3JlIGRlY29kaW5nIGl0LlxuICogLSBOb2RlJ3MgQnVmZmVyLmZyb20oYm9keSwgJ2Jhc2U2NCcpIHNpemVzIGl0cyBiYWNraW5nIGFsbG9jYXRpb24gZnJvbSB0aGVcbiAqICAgcmF3IGJvZHksIGluY2x1ZGluZyBpZ25vcmVkIGNoYXJhY3RlcnMgYW5kIGNvbnRlbnQgYWZ0ZXIgcGFkZGluZy5cbiAqIC0gTm9uLWJhc2U2NCBkYXRhIGlzIHBlcmNlbnQtZGVjb2RlZCBhbmQgdGhlbiBlbmNvZGVkIGFzIFVURi04LlxuICovXG5jb25zdCBpc0hleERpZ2l0ID0gKGNoYXJDb2RlKSA9PlxuICAoY2hhckNvZGUgPj0gNDggJiYgY2hhckNvZGUgPD0gNTcpIHx8XG4gIChjaGFyQ29kZSA+PSA2NSAmJiBjaGFyQ29kZSA8PSA3MCkgfHxcbiAgKGNoYXJDb2RlID49IDk3ICYmIGNoYXJDb2RlIDw9IDEwMik7XG5cbmNvbnN0IGlzUGVyY2VudEVuY29kZWRCeXRlID0gKHN0ciwgaSwgbGVuKSA9PlxuICBpICsgMiA8IGxlbiAmJiBpc0hleERpZ2l0KHN0ci5jaGFyQ29kZUF0KGkgKyAxKSkgJiYgaXNIZXhEaWdpdChzdHIuY2hhckNvZGVBdChpICsgMikpO1xuXG5jb25zdCBoZXhWYWx1ZSA9IChjaGFyQ29kZSkgPT4gKGNoYXJDb2RlIDw9IDU3ID8gY2hhckNvZGUgLSA0OCA6IChjaGFyQ29kZSAmIDB4ZGYpIC0gNTUpO1xuXG5jb25zdCBpc0Jhc2U2NENoYXIgPSAoY2hhckNvZGUpID0+XG4gIChjaGFyQ29kZSA+PSA2NSAmJiBjaGFyQ29kZSA8PSA5MCkgfHwgLy8gQS1aXG4gIChjaGFyQ29kZSA+PSA5NyAmJiBjaGFyQ29kZSA8PSAxMjIpIHx8IC8vIGEtelxuICAoY2hhckNvZGUgPj0gNDggJiYgY2hhckNvZGUgPD0gNTcpIHx8IC8vIDAtOVxuICBjaGFyQ29kZSA9PT0gNDMgfHwgLy8gK1xuICBjaGFyQ29kZSA9PT0gNDcgfHwgLy8gL1xuICBjaGFyQ29kZSA9PT0gNDUgfHwgLy8gLSAoYmFzZTY0dXJsKVxuICBjaGFyQ29kZSA9PT0gOTU7IC8vIF8gKGJhc2U2NHVybClcblxuY29uc3QgaXNCYXNlNjRXaGl0ZXNwYWNlID0gKGNoYXJDb2RlKSA9PlxuICBjaGFyQ29kZSA9PT0gOSB8fCBjaGFyQ29kZSA9PT0gMTAgfHwgY2hhckNvZGUgPT09IDEyIHx8IGNoYXJDb2RlID09PSAxMyB8fCBjaGFyQ29kZSA9PT0gMzI7XG5cbmNvbnN0IGJhc2U2NEJ5dGVzID0gKHNpZ25pZmljYW50KSA9PiB7XG4gIGNvbnN0IGdyb3VwcyA9IE1hdGguZmxvb3Ioc2lnbmlmaWNhbnQgLyA0KTtcbiAgY29uc3QgcmVtYWluZGVyID0gc2lnbmlmaWNhbnQgJSA0O1xuICByZXR1cm4gZ3JvdXBzICogMyArIChyZW1haW5kZXIgPT09IDIgPyAxIDogcmVtYWluZGVyID09PSAzID8gMiA6IDApO1xufTtcblxuLy8gQnVmZmVyLmJ5dGVMZW5ndGgoYm9keSwgJ2Jhc2U2NCcpIHVzZXMgdGhlIHJhdyBzdHJpbmcgbGVuZ3RoIGFzIGFuIGFsbG9jYXRpb25cbi8vIHVwcGVyIGJvdW5kIGV2ZW4gd2hlbiBCdWZmZXIuZnJvbSBsYXRlciBpZ25vcmVzIGNoYXJhY3RlcnMgb3Igc3RvcHMgYXQgJz0nLlxuY29uc3QgZXN0aW1hdGVCYXNlNjRCdWZmZXJBbGxvY2F0aW9uID0gKGJvZHkpID0+IHtcbiAgY29uc3QgbGVuID0gYm9keS5sZW5ndGg7XG4gIGxldCBwYWRkaW5nID0gMDtcblxuICBpZiAobGVuID4gMCAmJiBib2R5LmNoYXJDb2RlQXQobGVuIC0gMSkgPT09IDYxIC8qICc9JyAqLykge1xuICAgIHBhZGRpbmcrKztcblxuICAgIGlmIChsZW4gPiAxICYmIGJvZHkuY2hhckNvZGVBdChsZW4gLSAyKSA9PT0gNjEgLyogJz0nICovKSB7XG4gICAgICBwYWRkaW5nKys7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIE1hdGguZmxvb3IoKChsZW4gLSBwYWRkaW5nKSAqIDMpIC8gNCk7XG59O1xuXG5jb25zdCBlc3RpbWF0ZVBlcmNlbnREZWNvZGVkQmFzZTY0Qnl0ZXMgPSAoYm9keSkgPT4ge1xuICBjb25zdCBsZW4gPSBib2R5Lmxlbmd0aDtcbiAgbGV0IHNpZ25pZmljYW50ID0gMDtcbiAgbGV0IHBhZGRpbmcgPSAwO1xuICBsZXQgaW52YWxpZCA9IGZhbHNlO1xuXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICBsZXQgY29kZSA9IGJvZHkuY2hhckNvZGVBdChpKTtcblxuICAgIGlmIChjb2RlID09PSAzNyAvKiAnJScgKi8gJiYgaXNQZXJjZW50RW5jb2RlZEJ5dGUoYm9keSwgaSwgbGVuKSkge1xuICAgICAgY29kZSA9IGhleFZhbHVlKGJvZHkuY2hhckNvZGVBdChpICsgMSkpICogMTYgKyBoZXhWYWx1ZShib2R5LmNoYXJDb2RlQXQoaSArIDIpKTtcbiAgICAgIGkgKz0gMjtcbiAgICB9XG5cbiAgICBpZiAoaXNCYXNlNjRXaGl0ZXNwYWNlKGNvZGUpKSB7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG5cbiAgICBpZiAoY29kZSA9PT0gNjEgLyogJz0nICovKSB7XG4gICAgICBwYWRkaW5nKys7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG5cbiAgICBpZiAoIWlzQmFzZTY0Q2hhcihjb2RlKSB8fCBwYWRkaW5nID4gMCkge1xuICAgICAgaW52YWxpZCA9IHRydWU7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG5cbiAgICBzaWduaWZpY2FudCsrO1xuICB9XG5cbiAgLy8gRmV0Y2ggcmVqZWN0cyBtYWxmb3JtZWQgZm9yZ2l2aW5nLWJhc2U2NCBpbnB1dC4gUmV0dXJuaW5nIHRoZSByYXctc2l6ZVxuICAvLyBhbGxvY2F0aW9uIGJvdW5kIGtlZXBzIHRoYXQgaW52YWxpZCBpbnB1dCBmcm9tIGJlY29taW5nIGEgcHJlLWNoZWNrIGJ5cGFzcy5cbiAgaWYgKFxuICAgIGludmFsaWQgfHxcbiAgICBwYWRkaW5nID4gMiB8fFxuICAgIChwYWRkaW5nID4gMCAmJiAoc2lnbmlmaWNhbnQgKyBwYWRkaW5nKSAlIDQgIT09IDApIHx8XG4gICAgc2lnbmlmaWNhbnQgJSA0ID09PSAxXG4gICkge1xuICAgIHJldHVybiBlc3RpbWF0ZUJhc2U2NEJ1ZmZlckFsbG9jYXRpb24oYm9keSk7XG4gIH1cblxuICByZXR1cm4gYmFzZTY0Qnl0ZXMoc2lnbmlmaWNhbnQpO1xufTtcblxuY29uc3QgZXN0aW1hdGVEYXRhVVJMQnl0ZXMgPSAodXJsLCBlc3RpbWF0ZUJhc2U2NCkgPT4ge1xuICBpZiAoIXVybCB8fCB0eXBlb2YgdXJsICE9PSAnc3RyaW5nJykgcmV0dXJuIDA7XG4gIGlmICghdXJsLnN0YXJ0c1dpdGgoJ2RhdGE6JykpIHJldHVybiAwO1xuXG4gIGNvbnN0IGNvbW1hID0gdXJsLmluZGV4T2YoJywnKTtcbiAgaWYgKGNvbW1hIDwgMCkgcmV0dXJuIDA7XG5cbiAgY29uc3QgbWV0YSA9IHVybC5zbGljZSg1LCBjb21tYSk7XG4gIGNvbnN0IGJvZHkgPSB1cmwuc2xpY2UoY29tbWEgKyAxKTtcbiAgY29uc3QgaXNCYXNlNjQgPSAvO2Jhc2U2NC9pLnRlc3QobWV0YSk7XG5cbiAgaWYgKGlzQmFzZTY0KSB7XG4gICAgcmV0dXJuIGVzdGltYXRlQmFzZTY0KGJvZHkpO1xuICB9XG5cbiAgLy8gQ29tcHV0ZSBVVEYtOCBieXRlIGxlbmd0aCBkaXJlY3RseSBmcm9tIFVURi0xNiBjb2RlIHVuaXRzIHdpdGhvdXQgYWxsb2NhdGluZ1xuICAvLyBhIGJ5dGUgYnVmZmVyIChUZXh0RW5jb2Rlci5lbmNvZGUgd291bGQgZGVmZWF0IHRoZSBEb1MgZ3VhcmQgb24gbGFyZ2UgYm9kaWVzKS5cbiAgLy8gVmFsaWQgJVhYIHRyaXBsZXRzIGNvdW50IGFzIG9uZSBkZWNvZGVkIGJ5dGU7IHRoaXMgbWF0Y2hlcyB0aGUgYnl0ZXMgdGhhdFxuICAvLyBkZWNvZGVVUklDb21wb25lbnQoYm9keSkgd291bGQgcHJvZHVjZSBiZWZvcmUgQnVmZmVyIHJlLWVuY29kZXMgdGhlIHN0cmluZy5cbiAgbGV0IGJ5dGVzID0gMDtcbiAgZm9yIChsZXQgaSA9IDAsIGxlbiA9IGJvZHkubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICBjb25zdCBjID0gYm9keS5jaGFyQ29kZUF0KGkpO1xuICAgIGlmIChjID09PSAzNyAvKiAnJScgKi8gJiYgaXNQZXJjZW50RW5jb2RlZEJ5dGUoYm9keSwgaSwgbGVuKSkge1xuICAgICAgYnl0ZXMgKz0gMTtcbiAgICAgIGkgKz0gMjtcbiAgICB9IGVsc2UgaWYgKGMgPCAweDgwKSB7XG4gICAgICBieXRlcyArPSAxO1xuICAgIH0gZWxzZSBpZiAoYyA8IDB4ODAwKSB7XG4gICAgICBieXRlcyArPSAyO1xuICAgIH0gZWxzZSBpZiAoYyA+PSAweGQ4MDAgJiYgYyA8PSAweGRiZmYgJiYgaSArIDEgPCBsZW4pIHtcbiAgICAgIGNvbnN0IG5leHQgPSBib2R5LmNoYXJDb2RlQXQoaSArIDEpO1xuICAgICAgaWYgKG5leHQgPj0gMHhkYzAwICYmIG5leHQgPD0gMHhkZmZmKSB7XG4gICAgICAgIGJ5dGVzICs9IDQ7XG4gICAgICAgIGkrKztcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGJ5dGVzICs9IDM7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGJ5dGVzICs9IDM7XG4gICAgfVxuICB9XG4gIHJldHVybiBieXRlcztcbn07XG5cbi8qKlxuICogRXN0aW1hdGUgdGhlIHBlcmNlbnQtZGVjb2RlZCBwYXlsb2FkIHNpemUgdXNlZCBieSBGZXRjaCBkYXRhOiBVUkxzLlxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSB1cmxcbiAqIEByZXR1cm5zIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGVzdGltYXRlRGF0YVVSTERlY29kZWRCeXRlcyh1cmwpIHtcbiAgLy8gRmV0Y2ggcmVtb3ZlcyBVUkwgZnJhZ21lbnRzIGJlZm9yZSBwcm9jZXNzaW5nIGEgZGF0YTogVVJMLlxuICBjb25zdCBmcmFnbWVudEluZGV4ID0gdHlwZW9mIHVybCA9PT0gJ3N0cmluZycgPyB1cmwuaW5kZXhPZignIycpIDogLTE7XG5cbiAgcmV0dXJuIGVzdGltYXRlRGF0YVVSTEJ5dGVzKFxuICAgIGZyYWdtZW50SW5kZXggPT09IC0xID8gdXJsIDogdXJsLnNsaWNlKDAsIGZyYWdtZW50SW5kZXgpLFxuICAgIGVzdGltYXRlUGVyY2VudERlY29kZWRCYXNlNjRCeXRlc1xuICApO1xufVxuXG4vKipcbiAqIEVzdGltYXRlIHRoZSBCdWZmZXIgYmFja2luZyBhbGxvY2F0aW9uIHVzZWQgYnkgTm9kZSdzIHJhdyBiYXNlNjQgZGVjb2Rlci5cbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gdXJsXG4gKiBAcmV0dXJucyB7bnVtYmVyfVxuICovXG5leHBvcnQgZnVuY3Rpb24gZXN0aW1hdGVEYXRhVVJMQnVmZmVyQWxsb2NhdGlvbih1cmwpIHtcbiAgcmV0dXJuIGVzdGltYXRlRGF0YVVSTEJ5dGVzKHVybCwgZXN0aW1hdGVCYXNlNjRCdWZmZXJBbGxvY2F0aW9uKTtcbn1cbiIsImV4cG9ydCBjb25zdCBWRVJTSU9OID0gXCIxLjIwLjBcIjsiLCJpbXBvcnQgcGxhdGZvcm0gZnJvbSAnLi4vcGxhdGZvcm0vaW5kZXguanMnO1xuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCBBeGlvc0Vycm9yIGZyb20gJy4uL2NvcmUvQXhpb3NFcnJvci5qcyc7XG5pbXBvcnQgY29tcG9zZVNpZ25hbHMgZnJvbSAnLi4vaGVscGVycy9jb21wb3NlU2lnbmFscy5qcyc7XG5pbXBvcnQgeyB0cmFja1N0cmVhbSB9IGZyb20gJy4uL2hlbHBlcnMvdHJhY2tTdHJlYW0uanMnO1xuaW1wb3J0IEF4aW9zSGVhZGVycyBmcm9tICcuLi9jb3JlL0F4aW9zSGVhZGVycy5qcyc7XG5pbXBvcnQge1xuICBwcm9ncmVzc0V2ZW50UmVkdWNlcixcbiAgcHJvZ3Jlc3NFdmVudERlY29yYXRvcixcbiAgYXN5bmNEZWNvcmF0b3IsXG59IGZyb20gJy4uL2hlbHBlcnMvcHJvZ3Jlc3NFdmVudFJlZHVjZXIuanMnO1xuaW1wb3J0IHJlc29sdmVDb25maWcgZnJvbSAnLi4vaGVscGVycy9yZXNvbHZlQ29uZmlnLmpzJztcbmltcG9ydCBzZXR0bGUgZnJvbSAnLi4vY29yZS9zZXR0bGUuanMnO1xuaW1wb3J0IGVzdGltYXRlRGF0YVVSTERlY29kZWRCeXRlcyBmcm9tICcuLi9oZWxwZXJzL2VzdGltYXRlRGF0YVVSTERlY29kZWRCeXRlcy5qcyc7XG5pbXBvcnQgeyBWRVJTSU9OIH0gZnJvbSAnLi4vZW52L2RhdGEuanMnO1xuaW1wb3J0IHsgdG9CeXRlU3RyaW5nSGVhZGVyT2JqZWN0IH0gZnJvbSAnLi4vaGVscGVycy9zYW5pdGl6ZUhlYWRlclZhbHVlLmpzJztcblxuY29uc3QgREVGQVVMVF9DSFVOS19TSVpFID0gNjQgKiAxMDI0O1xuXG5jb25zdCBERUZBVUxUX1JFUVVFU1RfT1BUSU9OUyA9IHtcbiAgY2FjaGU6ICdkZWZhdWx0JyxcbiAgcmVkaXJlY3Q6ICdmb2xsb3cnLFxuICByZWZlcnJlcjogJ2Fib3V0OmNsaWVudCcsXG4gIHJlZmVycmVyUG9saWN5OiAnJyxcbiAgbW9kZTogJ2NvcnMnLFxuICBpbnRlZ3JpdHk6ICcnLFxuICBrZWVwYWxpdmU6IGZhbHNlLFxuICBwcmlvcml0eTogJ2F1dG8nLFxuICB3aW5kb3c6IG51bGwsXG59O1xuXG5jb25zdCB7IGlzRnVuY3Rpb24gfSA9IHV0aWxzO1xuXG4vKipcbiAqIEVuY29kZSBhIFVURi04IHN0cmluZyB0byBhIExhdGluLTEgYnl0ZSBzdHJpbmcgZm9yIHVzZSB3aXRoIGJ0b2EoKS5cbiAqIFRoaXMgaXMgYSBtb2Rlcm4gcmVwbGFjZW1lbnQgZm9yIHRoZSBkZXByZWNhdGVkIHVuZXNjYXBlKGVuY29kZVVSSUNvbXBvbmVudChzdHIpKSBwYXR0ZXJuLlxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSBzdHIgVGhlIHN0cmluZyB0byBlbmNvZGVcbiAqXG4gKiBAcmV0dXJucyB7c3RyaW5nfSBVVEYtOCBieXRlcyBhcyBhIExhdGluLTEgc3RyaW5nXG4gKi9cbmNvbnN0IGVuY29kZVVURjggPSAoc3RyKSA9PlxuICBlbmNvZGVVUklDb21wb25lbnQoc3RyKS5yZXBsYWNlKC8lKFswLTlBLUZdezJ9KS9naSwgKF8sIGhleCkgPT5cbiAgICBTdHJpbmcuZnJvbUNoYXJDb2RlKHBhcnNlSW50KGhleCwgMTYpKVxuICApO1xuXG4vLyBOb2RlJ3MgV0hBVFdHIFVSTCBwYXJzZXIgcmV0dXJucyBgdXNlcm5hbWVgIGFuZCBgcGFzc3dvcmRgIHBlcmNlbnQtZW5jb2RlZC5cbi8vIERlY29kZSBiZWZvcmUgY29tcG9zaW5nIHRoZSBgYXV0aGAgb3B0aW9uIHNvIGNyZWRlbnRpYWxzIHN1Y2ggYXNcbi8vIGBteSU0MGVtYWlsLmNvbTpwYXNzYCBhcmUgc2VudCBhcyBgbXlAZW1haWwuY29tOnBhc3NgLiBGYWxscyBiYWNrIHRvIHRoZVxuLy8gb3JpZ2luYWwgdmFsdWUgZm9yIG1hbGZvcm1lZCBpbnB1dCBzbyBhIGJhZCBlbmNvZGluZyBuZXZlciB0aHJvd3MuXG5jb25zdCBkZWNvZGVVUklDb21wb25lbnRTYWZlID0gKHZhbHVlKSA9PiB7XG4gIGlmICghdXRpbHMuaXNTdHJpbmcodmFsdWUpKSB7XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG5cbiAgdHJ5IHtcbiAgICByZXR1cm4gZGVjb2RlVVJJQ29tcG9uZW50KHZhbHVlKTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cbn07XG5cbmNvbnN0IHRlc3QgPSAoZm4sIC4uLmFyZ3MpID0+IHtcbiAgdHJ5IHtcbiAgICByZXR1cm4gISFmbiguLi5hcmdzKTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufTtcblxuY29uc3QgbWF5YmVXaXRoQXV0aENyZWRlbnRpYWxzID0gKHVybCkgPT4ge1xuICBjb25zdCBwcm90b2NvbEluZGV4ID0gdXJsLmluZGV4T2YoJzovLycpO1xuICBsZXQgdXJsVG9DaGVjayA9IHVybDtcbiAgaWYgKHByb3RvY29sSW5kZXggIT09IC0xKSB7XG4gICAgdXJsVG9DaGVjayA9IHVybFRvQ2hlY2suc2xpY2UocHJvdG9jb2xJbmRleCArIDMpO1xuICB9XG4gIHJldHVybiB1cmxUb0NoZWNrLmluY2x1ZGVzKCdAJykgfHwgdXJsVG9DaGVjay5pbmNsdWRlcygnOicpO1xufTtcblxuY29uc3QgZmFjdG9yeSA9IChlbnYpID0+IHtcbiAgY29uc3QgZ2xvYmFsT2JqZWN0ID1cbiAgICB1dGlscy5nbG9iYWwgIT09IHVuZGVmaW5lZCAmJiB1dGlscy5nbG9iYWwgIT09IG51bGwgPyB1dGlscy5nbG9iYWwgOiBnbG9iYWxUaGlzO1xuICBjb25zdCB7IFJlYWRhYmxlU3RyZWFtLCBUZXh0RW5jb2RlciB9ID0gZ2xvYmFsT2JqZWN0O1xuXG4gIGVudiA9IHV0aWxzLm1lcmdlLmNhbGwoXG4gICAge1xuICAgICAgc2tpcFVuZGVmaW5lZDogdHJ1ZSxcbiAgICB9LFxuICAgIHtcbiAgICAgIFJlcXVlc3Q6IGdsb2JhbE9iamVjdC5SZXF1ZXN0LFxuICAgICAgUmVzcG9uc2U6IGdsb2JhbE9iamVjdC5SZXNwb25zZSxcbiAgICB9LFxuICAgIGVudlxuICApO1xuXG4gIGNvbnN0IHsgZmV0Y2g6IGVudkZldGNoLCBSZXF1ZXN0LCBSZXNwb25zZSB9ID0gZW52O1xuICBjb25zdCBpc0ZldGNoU3VwcG9ydGVkID0gZW52RmV0Y2ggPyBpc0Z1bmN0aW9uKGVudkZldGNoKSA6IHR5cGVvZiBmZXRjaCA9PT0gJ2Z1bmN0aW9uJztcbiAgY29uc3QgaXNSZXF1ZXN0U3VwcG9ydGVkID0gaXNGdW5jdGlvbihSZXF1ZXN0KTtcbiAgY29uc3QgaXNSZXNwb25zZVN1cHBvcnRlZCA9IGlzRnVuY3Rpb24oUmVzcG9uc2UpO1xuXG4gIGlmICghaXNGZXRjaFN1cHBvcnRlZCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIGNvbnN0IGlzUmVhZGFibGVTdHJlYW1TdXBwb3J0ZWQgPSBpc0ZldGNoU3VwcG9ydGVkICYmIGlzRnVuY3Rpb24oUmVhZGFibGVTdHJlYW0pO1xuXG4gIGNvbnN0IGVuY29kZVRleHQgPVxuICAgIGlzRmV0Y2hTdXBwb3J0ZWQgJiZcbiAgICAodHlwZW9mIFRleHRFbmNvZGVyID09PSAnZnVuY3Rpb24nXG4gICAgICA/IChcbiAgICAgICAgICAoZW5jb2RlcikgPT4gKHN0cikgPT5cbiAgICAgICAgICAgIGVuY29kZXIuZW5jb2RlKHN0cilcbiAgICAgICAgKShuZXcgVGV4dEVuY29kZXIoKSlcbiAgICAgIDogYXN5bmMgKHN0cikgPT4gbmV3IFVpbnQ4QXJyYXkoYXdhaXQgbmV3IFJlcXVlc3Qoc3RyKS5hcnJheUJ1ZmZlcigpKSk7XG5cbiAgY29uc3Qgc3VwcG9ydHNSZXF1ZXN0U3RyZWFtID1cbiAgICBpc1JlcXVlc3RTdXBwb3J0ZWQgJiZcbiAgICBpc1JlYWRhYmxlU3RyZWFtU3VwcG9ydGVkICYmXG4gICAgdGVzdCgoKSA9PiB7XG4gICAgICBsZXQgZHVwbGV4QWNjZXNzZWQgPSBmYWxzZTtcblxuICAgICAgY29uc3QgcmVxdWVzdCA9IG5ldyBSZXF1ZXN0KHBsYXRmb3JtLm9yaWdpbiwge1xuICAgICAgICBib2R5OiBuZXcgUmVhZGFibGVTdHJlYW0oKSxcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgIGdldCBkdXBsZXgoKSB7XG4gICAgICAgICAgZHVwbGV4QWNjZXNzZWQgPSB0cnVlO1xuICAgICAgICAgIHJldHVybiAnaGFsZic7XG4gICAgICAgIH0sXG4gICAgICB9KTtcblxuICAgICAgY29uc3QgaGFzQ29udGVudFR5cGUgPSByZXF1ZXN0LmhlYWRlcnMuaGFzKCdDb250ZW50LVR5cGUnKTtcblxuICAgICAgaWYgKHJlcXVlc3QuYm9keSAhPSBudWxsKSB7XG4gICAgICAgIHJlcXVlc3QuYm9keS5jYW5jZWwoKTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIGR1cGxleEFjY2Vzc2VkICYmICFoYXNDb250ZW50VHlwZTtcbiAgICB9KTtcblxuICBjb25zdCBzdXBwb3J0c1Jlc3BvbnNlU3RyZWFtID1cbiAgICBpc1Jlc3BvbnNlU3VwcG9ydGVkICYmXG4gICAgaXNSZWFkYWJsZVN0cmVhbVN1cHBvcnRlZCAmJlxuICAgIHRlc3QoKCkgPT4gdXRpbHMuaXNSZWFkYWJsZVN0cmVhbShuZXcgUmVzcG9uc2UoJycpLmJvZHkpKTtcblxuICBjb25zdCByZXNvbHZlcnMgPSB7XG4gICAgc3RyZWFtOiBzdXBwb3J0c1Jlc3BvbnNlU3RyZWFtICYmICgocmVzKSA9PiByZXMuYm9keSksXG4gIH07XG5cbiAgaXNGZXRjaFN1cHBvcnRlZCAmJlxuICAgICgoKSA9PiB7XG4gICAgICBbJ3RleHQnLCAnYXJyYXlCdWZmZXInLCAnYmxvYicsICdmb3JtRGF0YScsICdzdHJlYW0nXS5mb3JFYWNoKCh0eXBlKSA9PiB7XG4gICAgICAgICFyZXNvbHZlcnNbdHlwZV0gJiZcbiAgICAgICAgICAocmVzb2x2ZXJzW3R5cGVdID0gKHJlcywgY29uZmlnKSA9PiB7XG4gICAgICAgICAgICBsZXQgbWV0aG9kID0gcmVzICYmIHJlc1t0eXBlXTtcblxuICAgICAgICAgICAgaWYgKG1ldGhvZCkge1xuICAgICAgICAgICAgICByZXR1cm4gbWV0aG9kLmNhbGwocmVzKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdGhyb3cgbmV3IEF4aW9zRXJyb3IoXG4gICAgICAgICAgICAgIGBSZXNwb25zZSB0eXBlICcke3R5cGV9JyBpcyBub3Qgc3VwcG9ydGVkYCxcbiAgICAgICAgICAgICAgQXhpb3NFcnJvci5FUlJfTk9UX1NVUFBPUlQsXG4gICAgICAgICAgICAgIGNvbmZpZ1xuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgIH0pKCk7XG5cbiAgY29uc3QgZ2V0Qm9keUxlbmd0aCA9IGFzeW5jIChib2R5KSA9PiB7XG4gICAgaWYgKGJvZHkgPT0gbnVsbCkge1xuICAgICAgcmV0dXJuIDA7XG4gICAgfVxuXG4gICAgaWYgKHV0aWxzLmlzQmxvYihib2R5KSkge1xuICAgICAgcmV0dXJuIGJvZHkuc2l6ZTtcbiAgICB9XG5cbiAgICBpZiAodXRpbHMuaXNTcGVjQ29tcGxpYW50Rm9ybShib2R5KSkge1xuICAgICAgY29uc3QgX3JlcXVlc3QgPSBuZXcgUmVxdWVzdChwbGF0Zm9ybS5vcmlnaW4sIHtcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgIGJvZHksXG4gICAgICB9KTtcbiAgICAgIHJldHVybiAoYXdhaXQgX3JlcXVlc3QuYXJyYXlCdWZmZXIoKSkuYnl0ZUxlbmd0aDtcbiAgICB9XG5cbiAgICBpZiAodXRpbHMuaXNBcnJheUJ1ZmZlclZpZXcoYm9keSkgfHwgdXRpbHMuaXNBcnJheUJ1ZmZlcihib2R5KSkge1xuICAgICAgcmV0dXJuIGJvZHkuYnl0ZUxlbmd0aDtcbiAgICB9XG5cbiAgICBpZiAodXRpbHMuaXNVUkxTZWFyY2hQYXJhbXMoYm9keSkpIHtcbiAgICAgIGJvZHkgPSBib2R5ICsgJyc7XG4gICAgfVxuXG4gICAgaWYgKHV0aWxzLmlzU3RyaW5nKGJvZHkpKSB7XG4gICAgICByZXR1cm4gKGF3YWl0IGVuY29kZVRleHQoYm9keSkpLmJ5dGVMZW5ndGg7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IHJlc29sdmVCb2R5TGVuZ3RoID0gYXN5bmMgKGhlYWRlcnMsIGJvZHkpID0+IHtcbiAgICBjb25zdCBsZW5ndGggPSB1dGlscy50b0Zpbml0ZU51bWJlcihoZWFkZXJzLmdldENvbnRlbnRMZW5ndGgoKSk7XG5cbiAgICByZXR1cm4gbGVuZ3RoID09IG51bGwgPyBnZXRCb2R5TGVuZ3RoKGJvZHkpIDogbGVuZ3RoO1xuICB9O1xuXG4gIHJldHVybiBhc3luYyAoY29uZmlnKSA9PiB7XG4gICAgbGV0IHtcbiAgICAgIHVybCxcbiAgICAgIG1ldGhvZCxcbiAgICAgIGRhdGEsXG4gICAgICBzaWduYWwsXG4gICAgICBjYW5jZWxUb2tlbixcbiAgICAgIHRpbWVvdXQsXG4gICAgICBvbkRvd25sb2FkUHJvZ3Jlc3MsXG4gICAgICBvblVwbG9hZFByb2dyZXNzLFxuICAgICAgcmVzcG9uc2VUeXBlLFxuICAgICAgaGVhZGVycyxcbiAgICAgIHdpdGhDcmVkZW50aWFscyA9ICdzYW1lLW9yaWdpbicsXG4gICAgICBmZXRjaE9wdGlvbnMsXG4gICAgICBtYXhDb250ZW50TGVuZ3RoLFxuICAgICAgbWF4Qm9keUxlbmd0aCxcbiAgICAgIG1heFJlZGlyZWN0cyxcbiAgICB9ID0gcmVzb2x2ZUNvbmZpZyhjb25maWcpO1xuXG4gICAgY29uc3QgaGFzTWF4Q29udGVudExlbmd0aCA9IHV0aWxzLmlzTnVtYmVyKG1heENvbnRlbnRMZW5ndGgpICYmIG1heENvbnRlbnRMZW5ndGggPiAtMTtcbiAgICBjb25zdCBoYXNNYXhCb2R5TGVuZ3RoID0gdXRpbHMuaXNOdW1iZXIobWF4Qm9keUxlbmd0aCkgJiYgbWF4Qm9keUxlbmd0aCA+IC0xO1xuICAgIGNvbnN0IG93biA9IChrZXkpID0+ICh1dGlscy5oYXNPd25Qcm9wKGNvbmZpZywga2V5KSA/IGNvbmZpZ1trZXldIDogdW5kZWZpbmVkKTtcblxuICAgIGxldCBfZmV0Y2ggPSBlbnZGZXRjaCB8fCBmZXRjaDtcblxuICAgIHJlc3BvbnNlVHlwZSA9IHJlc3BvbnNlVHlwZSA/IChyZXNwb25zZVR5cGUgKyAnJykudG9Mb3dlckNhc2UoKSA6ICd0ZXh0JztcblxuICAgIGxldCBjb21wb3NlZFNpZ25hbCA9IGNvbXBvc2VTaWduYWxzKFxuICAgICAgW3NpZ25hbCwgY2FuY2VsVG9rZW4gJiYgY2FuY2VsVG9rZW4udG9BYm9ydFNpZ25hbCgpXSxcbiAgICAgIHRpbWVvdXRcbiAgICApO1xuXG4gICAgbGV0IHJlcXVlc3QgPSBudWxsO1xuXG4gICAgY29uc3QgdW5zdWJzY3JpYmUgPVxuICAgICAgY29tcG9zZWRTaWduYWwgJiZcbiAgICAgIGNvbXBvc2VkU2lnbmFsLnVuc3Vic2NyaWJlICYmXG4gICAgICAoKCkgPT4ge1xuICAgICAgICBjb21wb3NlZFNpZ25hbC51bnN1YnNjcmliZSgpO1xuICAgICAgfSk7XG5cbiAgICBsZXQgcmVxdWVzdENvbnRlbnRMZW5ndGg7XG5cbiAgICAvLyBBeGlvc0Vycm9yIHdlIHJhaXNlIHdoaWxlIHRoZSByZXF1ZXN0IGJvZHkgaXMgYmVpbmcgc3RyZWFtZWQuIENhcHR1cmVkXG4gICAgLy8gYnkgaWRlbnRpdHkgc28gdGhlIGNhdGNoIGJsb2NrIGNhbiBzdXJmYWNlIGl0IGRpcmVjdGx5LCByZWdhcmRsZXNzIG9mXG4gICAgLy8gaG93IHRoZSBydW50aW1lIHdyYXBzIHRoZSByZXN1bHRpbmcgZmV0Y2ggcmVqZWN0aW9uICh1bmRpY2kgZXhwb3NlcyBpdFxuICAgIC8vIGFzIGBlcnIuY2F1c2VgOyBzb21lIGJyb3dzZXJzIGRyb3AgdGhlIG9yaWdpbmFsIGVycm9yIGVudGlyZWx5KS5cbiAgICBsZXQgcGVuZGluZ0JvZHlFcnJvciA9IG51bGw7XG5cbiAgICBjb25zdCBtYXhCb2R5TGVuZ3RoRXJyb3IgPSAoKSA9PlxuICAgICAgbmV3IEF4aW9zRXJyb3IoXG4gICAgICAgICdSZXF1ZXN0IGJvZHkgbGFyZ2VyIHRoYW4gbWF4Qm9keUxlbmd0aCBsaW1pdCcsXG4gICAgICAgIEF4aW9zRXJyb3IuRVJSX0JBRF9SRVFVRVNULFxuICAgICAgICBjb25maWcsXG4gICAgICAgIHJlcXVlc3RcbiAgICAgICk7XG5cbiAgICB0cnkge1xuICAgICAgLy8gSFRUUCBiYXNpYyBhdXRoZW50aWNhdGlvblxuICAgICAgbGV0IGF1dGggPSB1bmRlZmluZWQ7XG4gICAgICBjb25zdCBjb25maWdBdXRoID0gb3duKCdhdXRoJyk7XG5cbiAgICAgIGlmIChjb25maWdBdXRoKSB7XG4gICAgICAgIGNvbnN0IHVzZXJuYW1lID0gdXRpbHMuZ2V0U2FmZVByb3AoY29uZmlnQXV0aCwgJ3VzZXJuYW1lJykgfHwgJyc7XG4gICAgICAgIGNvbnN0IHBhc3N3b3JkID0gdXRpbHMuZ2V0U2FmZVByb3AoY29uZmlnQXV0aCwgJ3Bhc3N3b3JkJykgfHwgJyc7XG4gICAgICAgIGF1dGggPSB7XG4gICAgICAgICAgdXNlcm5hbWUsXG4gICAgICAgICAgcGFzc3dvcmQsXG4gICAgICAgIH07XG4gICAgICB9XG5cbiAgICAgIGlmIChtYXliZVdpdGhBdXRoQ3JlZGVudGlhbHModXJsKSkge1xuICAgICAgICBjb25zdCBwYXJzZWRVUkwgPSBuZXcgVVJMKHVybCwgcGxhdGZvcm0ub3JpZ2luKTtcblxuICAgICAgICBpZiAoIWF1dGggJiYgKHBhcnNlZFVSTC51c2VybmFtZSB8fCBwYXJzZWRVUkwucGFzc3dvcmQpKSB7XG4gICAgICAgICAgY29uc3QgdXJsVXNlcm5hbWUgPSBkZWNvZGVVUklDb21wb25lbnRTYWZlKHBhcnNlZFVSTC51c2VybmFtZSk7XG4gICAgICAgICAgY29uc3QgdXJsUGFzc3dvcmQgPSBkZWNvZGVVUklDb21wb25lbnRTYWZlKHBhcnNlZFVSTC5wYXNzd29yZCk7XG4gICAgICAgICAgYXV0aCA9IHtcbiAgICAgICAgICAgIHVzZXJuYW1lOiB1cmxVc2VybmFtZSxcbiAgICAgICAgICAgIHBhc3N3b3JkOiB1cmxQYXNzd29yZCxcbiAgICAgICAgICB9O1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHBhcnNlZFVSTC51c2VybmFtZSB8fCBwYXJzZWRVUkwucGFzc3dvcmQpIHtcbiAgICAgICAgICBwYXJzZWRVUkwudXNlcm5hbWUgPSAnJztcbiAgICAgICAgICBwYXJzZWRVUkwucGFzc3dvcmQgPSAnJztcbiAgICAgICAgICB1cmwgPSBwYXJzZWRVUkwuaHJlZjtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAoYXV0aCkge1xuICAgICAgICBoZWFkZXJzLmRlbGV0ZSgnYXV0aG9yaXphdGlvbicpO1xuICAgICAgICBoZWFkZXJzLnNldChcbiAgICAgICAgICAnQXV0aG9yaXphdGlvbicsXG4gICAgICAgICAgJ0Jhc2ljICcgKyBidG9hKGVuY29kZVVURjgoKGF1dGgudXNlcm5hbWUgfHwgJycpICsgJzonICsgKGF1dGgucGFzc3dvcmQgfHwgJycpKSlcbiAgICAgICAgKTtcbiAgICAgIH1cblxuICAgICAgLy8gRW5mb3JjZSBtYXhDb250ZW50TGVuZ3RoIGZvciBkYXRhOiBVUkxzIHVwLWZyb250IHNvIHdlIG5ldmVyIG1hdGVyaWFsaXplXG4gICAgICAvLyBhbiBvdmVyc2l6ZWQgcGF5bG9hZC4gVGhlIEhUVFAgYWRhcHRlciBhcHBsaWVzIHRoZSBzYW1lIGNoZWNrIChzZWUgaHR0cC5qc1xuICAgICAgLy8gXCJpZiAocHJvdG9jb2wgPT09ICdkYXRhOicpXCIgYnJhbmNoKS5cbiAgICAgIGlmIChoYXNNYXhDb250ZW50TGVuZ3RoICYmIHR5cGVvZiB1cmwgPT09ICdzdHJpbmcnICYmIHVybC5zdGFydHNXaXRoKCdkYXRhOicpKSB7XG4gICAgICAgIGNvbnN0IGVzdGltYXRlZCA9IGVzdGltYXRlRGF0YVVSTERlY29kZWRCeXRlcyh1cmwpO1xuICAgICAgICBpZiAoZXN0aW1hdGVkID4gbWF4Q29udGVudExlbmd0aCkge1xuICAgICAgICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKFxuICAgICAgICAgICAgJ21heENvbnRlbnRMZW5ndGggc2l6ZSBvZiAnICsgbWF4Q29udGVudExlbmd0aCArICcgZXhjZWVkZWQnLFxuICAgICAgICAgICAgQXhpb3NFcnJvci5FUlJfQkFEX1JFU1BPTlNFLFxuICAgICAgICAgICAgY29uZmlnLFxuICAgICAgICAgICAgcmVxdWVzdFxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gRW5mb3JjZSBtYXhCb2R5TGVuZ3RoIGFnYWluc3Qga25vd24tc2l6ZSBib2RpZXMgYmVmb3JlIGRpc3BhdGNoIHVzaW5nXG4gICAgICAvLyB0aGUgYm9keSdzICphY3R1YWwqIHNpemUg4oCUIG5ldmVyIGEgY2FsbGVyLWRlY2xhcmVkIENvbnRlbnQtTGVuZ3RoLFxuICAgICAgLy8gd2hpY2ggY291bGQgdW5kZXItcmVwb3J0IHRvIHNsaXAgYW4gb3ZlcnNpemVkIGJvZHkgcGFzdCB0aGUgY2hlY2suXG4gICAgICAvLyBVbmtub3duLXNpemUgc3RyZWFtcyByZXR1cm4gdW5kZWZpbmVkIGhlcmUgYW5kIGFyZSBjb3VudGVkIHBlci1jaHVua1xuICAgICAgLy8gYmVsb3cgYXMgZmV0Y2ggY29uc3VtZXMgdGhlbS5cbiAgICAgIGlmIChoYXNNYXhCb2R5TGVuZ3RoICYmIG1ldGhvZCAhPT0gJ2dldCcgJiYgbWV0aG9kICE9PSAnaGVhZCcpIHtcbiAgICAgICAgY29uc3Qgb3V0Ym91bmRMZW5ndGggPSBhd2FpdCBnZXRCb2R5TGVuZ3RoKGRhdGEpO1xuICAgICAgICBpZiAodHlwZW9mIG91dGJvdW5kTGVuZ3RoID09PSAnbnVtYmVyJyAmJiBpc0Zpbml0ZShvdXRib3VuZExlbmd0aCkpIHtcbiAgICAgICAgICByZXF1ZXN0Q29udGVudExlbmd0aCA9IG91dGJvdW5kTGVuZ3RoO1xuICAgICAgICAgIGlmIChvdXRib3VuZExlbmd0aCA+IG1heEJvZHlMZW5ndGgpIHtcbiAgICAgICAgICAgIHRocm93IG1heEJvZHlMZW5ndGhFcnJvcigpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBBIHN0cmVhbWVkIGJvZHkgdW5kZXIgbWF4Qm9keUxlbmd0aCBtdXN0IGJlIGNvdW50ZWQgYXMgZmV0Y2ggY29uc3VtZXNcbiAgICAgIC8vIGl0OyBpdHMgc2l6ZSBpcyBuZXZlciB0cnVzdGVkIGZyb20gYSBjYWxsZXItZGVjbGFyZWQgQ29udGVudC1MZW5ndGguXG4gICAgICBjb25zdCBtdXN0RW5mb3JjZVN0cmVhbUJvZHkgPVxuICAgICAgICBoYXNNYXhCb2R5TGVuZ3RoICYmICh1dGlscy5pc1JlYWRhYmxlU3RyZWFtKGRhdGEpIHx8IHV0aWxzLmlzU3RyZWFtKGRhdGEpKTtcblxuICAgICAgY29uc3QgdHJhY2tSZXF1ZXN0U3RyZWFtID0gKHN0cmVhbSwgb25Qcm9ncmVzcywgZmx1c2gpID0+XG4gICAgICAgIHRyYWNrU3RyZWFtKFxuICAgICAgICAgIHN0cmVhbSxcbiAgICAgICAgICBERUZBVUxUX0NIVU5LX1NJWkUsXG4gICAgICAgICAgKGxvYWRlZEJ5dGVzKSA9PiB7XG4gICAgICAgICAgICBpZiAoaGFzTWF4Qm9keUxlbmd0aCAmJiBsb2FkZWRCeXRlcyA+IG1heEJvZHlMZW5ndGgpIHtcbiAgICAgICAgICAgICAgdGhyb3cgKHBlbmRpbmdCb2R5RXJyb3IgPSBtYXhCb2R5TGVuZ3RoRXJyb3IoKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvblByb2dyZXNzICYmIG9uUHJvZ3Jlc3MobG9hZGVkQnl0ZXMpO1xuICAgICAgICAgIH0sXG4gICAgICAgICAgZmx1c2hcbiAgICAgICAgKTtcblxuICAgICAgaWYgKFxuICAgICAgICBzdXBwb3J0c1JlcXVlc3RTdHJlYW0gJiZcbiAgICAgICAgbWV0aG9kICE9PSAnZ2V0JyAmJlxuICAgICAgICBtZXRob2QgIT09ICdoZWFkJyAmJlxuICAgICAgICAob25VcGxvYWRQcm9ncmVzcyB8fCBtdXN0RW5mb3JjZVN0cmVhbUJvZHkpXG4gICAgICApIHtcbiAgICAgICAgcmVxdWVzdENvbnRlbnRMZW5ndGggPVxuICAgICAgICAgIHJlcXVlc3RDb250ZW50TGVuZ3RoID09IG51bGxcbiAgICAgICAgICAgID8gYXdhaXQgcmVzb2x2ZUJvZHlMZW5ndGgoaGVhZGVycywgZGF0YSlcbiAgICAgICAgICAgIDogcmVxdWVzdENvbnRlbnRMZW5ndGg7XG5cbiAgICAgICAgLy8gQSBkZWNsYXJlZCBsZW5ndGggb2YgMCBpcyBvbmx5IHRydXN0ZWQgdG8gc2tpcCB0aGUgd3JhcCB3aGVuIHdlIGFyZVxuICAgICAgICAvLyBub3QgZW5mb3JjaW5nIGEgc3RyZWFtIGxpbWl0ICh3aGljaCBtdXN0IG5vdCByZWx5IG9uIHRoYXQgaGVhZGVyKS5cbiAgICAgICAgaWYgKHJlcXVlc3RDb250ZW50TGVuZ3RoICE9PSAwIHx8IG11c3RFbmZvcmNlU3RyZWFtQm9keSkge1xuICAgICAgICAgIGxldCBfcmVxdWVzdCA9IG5ldyBSZXF1ZXN0KHVybCwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICBib2R5OiBkYXRhLFxuICAgICAgICAgICAgZHVwbGV4OiAnaGFsZicsXG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICBsZXQgY29udGVudFR5cGVIZWFkZXI7XG5cbiAgICAgICAgICBpZiAoXG4gICAgICAgICAgICB1dGlscy5pc0Zvcm1EYXRhKGRhdGEpICYmXG4gICAgICAgICAgICAoY29udGVudFR5cGVIZWFkZXIgPSBfcmVxdWVzdC5oZWFkZXJzLmdldCgnY29udGVudC10eXBlJykpXG4gICAgICAgICAgKSB7XG4gICAgICAgICAgICBoZWFkZXJzLnNldENvbnRlbnRUeXBlKGNvbnRlbnRUeXBlSGVhZGVyKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAoX3JlcXVlc3QuYm9keSkge1xuICAgICAgICAgICAgY29uc3QgW29uUHJvZ3Jlc3MsIGZsdXNoXSA9XG4gICAgICAgICAgICAgIChvblVwbG9hZFByb2dyZXNzICYmXG4gICAgICAgICAgICAgICAgcHJvZ3Jlc3NFdmVudERlY29yYXRvcihcbiAgICAgICAgICAgICAgICAgIHJlcXVlc3RDb250ZW50TGVuZ3RoLFxuICAgICAgICAgICAgICAgICAgcHJvZ3Jlc3NFdmVudFJlZHVjZXIoYXN5bmNEZWNvcmF0b3Iob25VcGxvYWRQcm9ncmVzcykpXG4gICAgICAgICAgICAgICAgKSkgfHxcbiAgICAgICAgICAgICAgW107XG5cbiAgICAgICAgICAgIGRhdGEgPSB0cmFja1JlcXVlc3RTdHJlYW0oX3JlcXVlc3QuYm9keSwgb25Qcm9ncmVzcywgZmx1c2gpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChcbiAgICAgICAgbXVzdEVuZm9yY2VTdHJlYW1Cb2R5ICYmXG4gICAgICAgICFpc1JlcXVlc3RTdXBwb3J0ZWQgJiZcbiAgICAgICAgaXNSZWFkYWJsZVN0cmVhbVN1cHBvcnRlZCAmJlxuICAgICAgICBtZXRob2QgIT09ICdnZXQnICYmXG4gICAgICAgIG1ldGhvZCAhPT0gJ2hlYWQnXG4gICAgICApIHtcbiAgICAgICAgZGF0YSA9IHRyYWNrUmVxdWVzdFN0cmVhbShkYXRhKTtcbiAgICAgIH0gZWxzZSBpZiAoXG4gICAgICAgIG11c3RFbmZvcmNlU3RyZWFtQm9keSAmJlxuICAgICAgICBpc1JlcXVlc3RTdXBwb3J0ZWQgJiZcbiAgICAgICAgIXN1cHBvcnRzUmVxdWVzdFN0cmVhbSAmJlxuICAgICAgICBtZXRob2QgIT09ICdnZXQnICYmXG4gICAgICAgIG1ldGhvZCAhPT0gJ2hlYWQnXG4gICAgICApIHtcbiAgICAgICAgdGhyb3cgbmV3IEF4aW9zRXJyb3IoXG4gICAgICAgICAgJ1N0cmVhbSByZXF1ZXN0IGJvZGllcyBhcmUgbm90IHN1cHBvcnRlZCBieSB0aGUgY3VycmVudCBmZXRjaCBpbXBsZW1lbnRhdGlvbicsXG4gICAgICAgICAgQXhpb3NFcnJvci5FUlJfTk9UX1NVUFBPUlQsXG4gICAgICAgICAgY29uZmlnLFxuICAgICAgICAgIHJlcXVlc3RcbiAgICAgICAgKTtcbiAgICAgIH1cblxuICAgICAgaWYgKCF1dGlscy5pc1N0cmluZyh3aXRoQ3JlZGVudGlhbHMpKSB7XG4gICAgICAgIHdpdGhDcmVkZW50aWFscyA9IHdpdGhDcmVkZW50aWFscyA/ICdpbmNsdWRlJyA6ICdvbWl0JztcbiAgICAgIH1cblxuICAgICAgLy8gQ2xvdWRmbGFyZSBXb3JrZXJzIHRocm93cyB3aGVuIGNyZWRlbnRpYWxzIGFyZSBkZWZpbmVkXG4gICAgICAvLyBzZWUgaHR0cHM6Ly9naXRodWIuY29tL2Nsb3VkZmxhcmUvd29ya2VyZC9pc3N1ZXMvOTAyXG4gICAgICBjb25zdCBpc0NyZWRlbnRpYWxzU3VwcG9ydGVkID0gaXNSZXF1ZXN0U3VwcG9ydGVkICYmICdjcmVkZW50aWFscycgaW4gUmVxdWVzdC5wcm90b3R5cGU7XG5cbiAgICAgIC8vIElmIGRhdGEgaXMgRm9ybURhdGEgYW5kIENvbnRlbnQtVHlwZSBpcyBtdWx0aXBhcnQvZm9ybS1kYXRhIHdpdGhvdXQgYm91bmRhcnksXG4gICAgICAvLyBkZWxldGUgaXQgc28gZmV0Y2ggY2FuIHNldCBpdCBjb3JyZWN0bHkgd2l0aCB0aGUgYm91bmRhcnlcbiAgICAgIGlmICh1dGlscy5pc0Zvcm1EYXRhKGRhdGEpKSB7XG4gICAgICAgIGNvbnN0IGNvbnRlbnRUeXBlID0gaGVhZGVycy5nZXRDb250ZW50VHlwZSgpO1xuICAgICAgICBpZiAoXG4gICAgICAgICAgY29udGVudFR5cGUgJiZcbiAgICAgICAgICAvXm11bHRpcGFydFxcL2Zvcm0tZGF0YS9pLnRlc3QoY29udGVudFR5cGUpICYmXG4gICAgICAgICAgIS9ib3VuZGFyeT0vaS50ZXN0KGNvbnRlbnRUeXBlKVxuICAgICAgICApIHtcbiAgICAgICAgICBoZWFkZXJzLmRlbGV0ZSgnY29udGVudC10eXBlJyk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gU2V0IFVzZXItQWdlbnQgaGVhZGVyIGlmIG5vdCBhbHJlYWR5IHNldCAoZmV0Y2ggZGVmYXVsdHMgdG8gJ25vZGUnIGluIE5vZGUuanMpXG4gICAgICBoZWFkZXJzLnNldCgnVXNlci1BZ2VudCcsICdheGlvcy8nICsgVkVSU0lPTiwgZmFsc2UpO1xuXG4gICAgICBjb25zdCBzYWZlRmV0Y2hPcHRpb25zID1cbiAgICAgICAgZmV0Y2hPcHRpb25zID09IG51bGwgPyBmZXRjaE9wdGlvbnMgOiBPYmplY3QuYXNzaWduKE9iamVjdC5jcmVhdGUobnVsbCksIGZldGNoT3B0aW9ucyk7XG5cbiAgICAgIGlmIChzYWZlRmV0Y2hPcHRpb25zKSB7XG4gICAgICAgIC8vIFRoZXNlIG9wdGlvbnMgYXJlIG93bmVkIGJ5IEF4aW9zIGFuZCBhcmUgYWxyZWFkeSByZWZsZWN0ZWQgaW4gdGhlXG4gICAgICAgIC8vIHJlc29sdmVkIFJlcXVlc3QgcGFzc2VkIHRvIGZldGNoLlxuICAgICAgICBkZWxldGUgc2FmZUZldGNoT3B0aW9ucy5ib2R5O1xuICAgICAgICBkZWxldGUgc2FmZUZldGNoT3B0aW9ucy5oZWFkZXJzO1xuICAgICAgICBkZWxldGUgc2FmZUZldGNoT3B0aW9ucy5tZXRob2Q7XG4gICAgICAgIGRlbGV0ZSBzYWZlRmV0Y2hPcHRpb25zLnNpZ25hbDtcbiAgICAgICAgZGVsZXRlIHNhZmVGZXRjaE9wdGlvbnMuZHVwbGV4O1xuICAgICAgICBkZWxldGUgc2FmZUZldGNoT3B0aW9ucy5jcmVkZW50aWFscztcbiAgICAgIH1cblxuICAgICAgY29uc3QgcmVzb2x2ZWRPcHRpb25zID0gT2JqZWN0LmFzc2lnbihPYmplY3QuY3JlYXRlKG51bGwpLCBzYWZlRmV0Y2hPcHRpb25zLCB7XG4gICAgICAgIHNpZ25hbDogY29tcG9zZWRTaWduYWwsXG4gICAgICAgIG1ldGhvZDogbWV0aG9kLnRvVXBwZXJDYXNlKCksXG4gICAgICAgIGhlYWRlcnM6IHRvQnl0ZVN0cmluZ0hlYWRlck9iamVjdChoZWFkZXJzLm5vcm1hbGl6ZSgpKSxcbiAgICAgICAgYm9keTogZGF0YSxcbiAgICAgICAgZHVwbGV4OiAnaGFsZicsXG4gICAgICAgIGNyZWRlbnRpYWxzOiBpc0NyZWRlbnRpYWxzU3VwcG9ydGVkID8gd2l0aENyZWRlbnRpYWxzIDogdW5kZWZpbmVkLFxuICAgICAgfSk7XG5cbiAgICAgIGlmIChpc1JlcXVlc3RTdXBwb3J0ZWQpIHtcbiAgICAgICAgdXRpbHMuZm9yRWFjaChERUZBVUxUX1JFUVVFU1RfT1BUSU9OUywgKHZhbHVlLCBrZXkpID0+IHtcbiAgICAgICAgICBpZiAocmVzb2x2ZWRPcHRpb25zW2tleV0gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgcmVzb2x2ZWRPcHRpb25zW2tleV0gPSB2YWx1ZTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGlmIChyZXNvbHZlZE9wdGlvbnMuc2lnbmFsID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICByZXNvbHZlZE9wdGlvbnMuc2lnbmFsID0gbnVsbDtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChyZXNvbHZlZE9wdGlvbnMuYm9keSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgcmVzb2x2ZWRPcHRpb25zLmJvZHkgPSBudWxsO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGlmIChtYXhSZWRpcmVjdHMgPT09IDApIHtcbiAgICAgICAgcmVzb2x2ZWRPcHRpb25zLnJlZGlyZWN0ID0gJ21hbnVhbCc7XG5cbiAgICAgICAgaWYgKHNhZmVGZXRjaE9wdGlvbnMpIHtcbiAgICAgICAgICBzYWZlRmV0Y2hPcHRpb25zLnJlZGlyZWN0ID0gJ21hbnVhbCc7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgcmVxdWVzdCA9IGlzUmVxdWVzdFN1cHBvcnRlZCAmJiBuZXcgUmVxdWVzdCh1cmwsIHJlc29sdmVkT3B0aW9ucyk7XG5cbiAgICAgIGxldCByZXNwb25zZSA9IGF3YWl0IChpc1JlcXVlc3RTdXBwb3J0ZWRcbiAgICAgICAgPyBfZmV0Y2gocmVxdWVzdCwgc2FmZUZldGNoT3B0aW9ucylcbiAgICAgICAgOiBfZmV0Y2godXJsLCByZXNvbHZlZE9wdGlvbnMpKTtcblxuICAgICAgY29uc3QgcmVzcG9uc2VIZWFkZXJzID0gQXhpb3NIZWFkZXJzLmZyb20ocmVzcG9uc2UuaGVhZGVycyk7XG5cbiAgICAgIC8vIENoZWFwIHByZS1jaGVjazogaWYgdGhlIHNlcnZlciBob25lc3RseSBkZWNsYXJlcyBhIGNvbnRlbnQtbGVuZ3RoIHRoYXRcbiAgICAgIC8vIGFscmVhZHkgZXhjZWVkcyB0aGUgY2FwLCByZWplY3QgYmVmb3JlIHdlIHN0YXJ0IHN0cmVhbWluZy5cbiAgICAgIGlmIChoYXNNYXhDb250ZW50TGVuZ3RoKSB7XG4gICAgICAgIGNvbnN0IGRlY2xhcmVkTGVuZ3RoID0gdXRpbHMudG9GaW5pdGVOdW1iZXIocmVzcG9uc2VIZWFkZXJzLmdldENvbnRlbnRMZW5ndGgoKSk7XG4gICAgICAgIGlmIChkZWNsYXJlZExlbmd0aCAhPSBudWxsICYmIGRlY2xhcmVkTGVuZ3RoID4gbWF4Q29udGVudExlbmd0aCkge1xuICAgICAgICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKFxuICAgICAgICAgICAgJ21heENvbnRlbnRMZW5ndGggc2l6ZSBvZiAnICsgbWF4Q29udGVudExlbmd0aCArICcgZXhjZWVkZWQnLFxuICAgICAgICAgICAgQXhpb3NFcnJvci5FUlJfQkFEX1JFU1BPTlNFLFxuICAgICAgICAgICAgY29uZmlnLFxuICAgICAgICAgICAgcmVxdWVzdFxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgY29uc3QgaXNTdHJlYW1SZXNwb25zZSA9XG4gICAgICAgIHN1cHBvcnRzUmVzcG9uc2VTdHJlYW0gJiYgKHJlc3BvbnNlVHlwZSA9PT0gJ3N0cmVhbScgfHwgcmVzcG9uc2VUeXBlID09PSAncmVzcG9uc2UnKTtcblxuICAgICAgaWYgKFxuICAgICAgICBzdXBwb3J0c1Jlc3BvbnNlU3RyZWFtICYmXG4gICAgICAgIHJlc3BvbnNlLmJvZHkgJiZcbiAgICAgICAgKG9uRG93bmxvYWRQcm9ncmVzcyB8fCBoYXNNYXhDb250ZW50TGVuZ3RoIHx8IChpc1N0cmVhbVJlc3BvbnNlICYmIHVuc3Vic2NyaWJlKSlcbiAgICAgICkge1xuICAgICAgICBjb25zdCBvcHRpb25zID0ge307XG5cbiAgICAgICAgWydzdGF0dXMnLCAnc3RhdHVzVGV4dCcsICdoZWFkZXJzJ10uZm9yRWFjaCgocHJvcCkgPT4ge1xuICAgICAgICAgIG9wdGlvbnNbcHJvcF0gPSByZXNwb25zZVtwcm9wXTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY29uc3QgcmVzcG9uc2VDb250ZW50TGVuZ3RoID0gdXRpbHMudG9GaW5pdGVOdW1iZXIocmVzcG9uc2VIZWFkZXJzLmdldENvbnRlbnRMZW5ndGgoKSk7XG5cbiAgICAgICAgY29uc3QgW29uUHJvZ3Jlc3MsIGZsdXNoXSA9XG4gICAgICAgICAgKG9uRG93bmxvYWRQcm9ncmVzcyAmJlxuICAgICAgICAgICAgcHJvZ3Jlc3NFdmVudERlY29yYXRvcihcbiAgICAgICAgICAgICAgcmVzcG9uc2VDb250ZW50TGVuZ3RoLFxuICAgICAgICAgICAgICBwcm9ncmVzc0V2ZW50UmVkdWNlcihhc3luY0RlY29yYXRvcihvbkRvd25sb2FkUHJvZ3Jlc3MpLCB0cnVlKVxuICAgICAgICAgICAgKSkgfHxcbiAgICAgICAgICBbXTtcblxuICAgICAgICBsZXQgYnl0ZXNSZWFkID0gMDtcbiAgICAgICAgY29uc3Qgb25DaHVua1Byb2dyZXNzID0gKGxvYWRlZEJ5dGVzKSA9PiB7XG4gICAgICAgICAgaWYgKGhhc01heENvbnRlbnRMZW5ndGgpIHtcbiAgICAgICAgICAgIGJ5dGVzUmVhZCA9IGxvYWRlZEJ5dGVzO1xuICAgICAgICAgICAgaWYgKGJ5dGVzUmVhZCA+IG1heENvbnRlbnRMZW5ndGgpIHtcbiAgICAgICAgICAgICAgdGhyb3cgbmV3IEF4aW9zRXJyb3IoXG4gICAgICAgICAgICAgICAgJ21heENvbnRlbnRMZW5ndGggc2l6ZSBvZiAnICsgbWF4Q29udGVudExlbmd0aCArICcgZXhjZWVkZWQnLFxuICAgICAgICAgICAgICAgIEF4aW9zRXJyb3IuRVJSX0JBRF9SRVNQT05TRSxcbiAgICAgICAgICAgICAgICBjb25maWcsXG4gICAgICAgICAgICAgICAgcmVxdWVzdFxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBvblByb2dyZXNzICYmIG9uUHJvZ3Jlc3MobG9hZGVkQnl0ZXMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIHJlc3BvbnNlID0gbmV3IFJlc3BvbnNlKFxuICAgICAgICAgIHRyYWNrU3RyZWFtKHJlc3BvbnNlLmJvZHksIERFRkFVTFRfQ0hVTktfU0laRSwgb25DaHVua1Byb2dyZXNzLCAoKSA9PiB7XG4gICAgICAgICAgICBmbHVzaCAmJiBmbHVzaCgpO1xuICAgICAgICAgICAgdW5zdWJzY3JpYmUgJiYgdW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICB9KSxcbiAgICAgICAgICBvcHRpb25zXG4gICAgICAgICk7XG4gICAgICB9XG5cbiAgICAgIHJlc3BvbnNlVHlwZSA9IHJlc3BvbnNlVHlwZSB8fCAndGV4dCc7XG5cbiAgICAgIGxldCByZXNwb25zZURhdGEgPSBhd2FpdCByZXNvbHZlcnNbdXRpbHMuZmluZEtleShyZXNvbHZlcnMsIHJlc3BvbnNlVHlwZSkgfHwgJ3RleHQnXShcbiAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgIGNvbmZpZ1xuICAgICAgKTtcblxuICAgICAgLy8gRmFsbGJhY2sgZW5mb3JjZW1lbnQgZm9yIGVudmlyb25tZW50cyB3aXRob3V0IFJlYWRhYmxlU3RyZWFtIHN1cHBvcnRcbiAgICAgIC8vIChsZWdhY3kgcnVudGltZXMpLiBEZXRlY3QgbWF0ZXJpYWxpemVkIHNpemUgZnJvbSB0eXBlZCBvdXRwdXQ7IHNraXBcbiAgICAgIC8vIHN0cmVhbXMvUmVzcG9uc2UgcGFzc3Rocm91Z2ggc2luY2UgdGhlIHVzZXIgd2lsbCByZWFkIHRob3NlIHRoZW1zZWx2ZXMuXG4gICAgICBpZiAoaGFzTWF4Q29udGVudExlbmd0aCAmJiAhc3VwcG9ydHNSZXNwb25zZVN0cmVhbSAmJiAhaXNTdHJlYW1SZXNwb25zZSkge1xuICAgICAgICBsZXQgbWF0ZXJpYWxpemVkU2l6ZTtcbiAgICAgICAgaWYgKHJlc3BvbnNlRGF0YSAhPSBudWxsKSB7XG4gICAgICAgICAgaWYgKHR5cGVvZiByZXNwb25zZURhdGEuYnl0ZUxlbmd0aCA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgIG1hdGVyaWFsaXplZFNpemUgPSByZXNwb25zZURhdGEuYnl0ZUxlbmd0aDtcbiAgICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiByZXNwb25zZURhdGEuc2l6ZSA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgIG1hdGVyaWFsaXplZFNpemUgPSByZXNwb25zZURhdGEuc2l6ZTtcbiAgICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiByZXNwb25zZURhdGEgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgICBtYXRlcmlhbGl6ZWRTaXplID1cbiAgICAgICAgICAgICAgdHlwZW9mIFRleHRFbmNvZGVyID09PSAnZnVuY3Rpb24nXG4gICAgICAgICAgICAgICAgPyBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUocmVzcG9uc2VEYXRhKS5ieXRlTGVuZ3RoXG4gICAgICAgICAgICAgICAgOiByZXNwb25zZURhdGEubGVuZ3RoO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAodHlwZW9mIG1hdGVyaWFsaXplZFNpemUgPT09ICdudW1iZXInICYmIG1hdGVyaWFsaXplZFNpemUgPiBtYXhDb250ZW50TGVuZ3RoKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEF4aW9zRXJyb3IoXG4gICAgICAgICAgICAnbWF4Q29udGVudExlbmd0aCBzaXplIG9mICcgKyBtYXhDb250ZW50TGVuZ3RoICsgJyBleGNlZWRlZCcsXG4gICAgICAgICAgICBBeGlvc0Vycm9yLkVSUl9CQURfUkVTUE9OU0UsXG4gICAgICAgICAgICBjb25maWcsXG4gICAgICAgICAgICByZXF1ZXN0XG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAhaXNTdHJlYW1SZXNwb25zZSAmJiB1bnN1YnNjcmliZSAmJiB1bnN1YnNjcmliZSgpO1xuXG4gICAgICByZXR1cm4gYXdhaXQgbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICBzZXR0bGUocmVzb2x2ZSwgcmVqZWN0LCB7XG4gICAgICAgICAgZGF0YTogcmVzcG9uc2VEYXRhLFxuICAgICAgICAgIGhlYWRlcnM6IEF4aW9zSGVhZGVycy5mcm9tKHJlc3BvbnNlLmhlYWRlcnMpLFxuICAgICAgICAgIHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzLFxuICAgICAgICAgIHN0YXR1c1RleHQ6IHJlc3BvbnNlLnN0YXR1c1RleHQsXG4gICAgICAgICAgY29uZmlnLFxuICAgICAgICAgIHJlcXVlc3QsXG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB1bnN1YnNjcmliZSAmJiB1bnN1YnNjcmliZSgpO1xuXG4gICAgICAvLyBTYWZhcmkgY2FuIHN1cmZhY2UgZmV0Y2ggYWJvcnRzIGFzIGEgRE9NRXhjZXB0aW9uLWxpa2Ugb2JqZWN0IHdob3NlXG4gICAgICAvLyBicmFuZGVkIGdldHRlcnMgdGhyb3cuIFByZWZlciBvdXIgY29tcG9zZWQgc2lnbmFsIHJlYXNvbiBiZWZvcmUgcmVhZGluZ1xuICAgICAgLy8gdGhlIGNhdWdodCBlcnJvciwgcHJlc2VydmluZyB0aW1lb3V0IHZzIGNhbmNlbGxhdGlvbiBzZW1hbnRpY3MuXG4gICAgICBpZiAoY29tcG9zZWRTaWduYWwgJiYgY29tcG9zZWRTaWduYWwuYWJvcnRlZCAmJiBjb21wb3NlZFNpZ25hbC5yZWFzb24gaW5zdGFuY2VvZiBBeGlvc0Vycm9yKSB7XG4gICAgICAgIGNvbnN0IGNhbmNlbGVkRXJyb3IgPSBjb21wb3NlZFNpZ25hbC5yZWFzb247XG4gICAgICAgIGNhbmNlbGVkRXJyb3IuY29uZmlnID0gY29uZmlnO1xuICAgICAgICByZXF1ZXN0ICYmIChjYW5jZWxlZEVycm9yLnJlcXVlc3QgPSByZXF1ZXN0KTtcbiAgICAgICAgaWYgKGVyciAhPT0gY2FuY2VsZWRFcnJvcikge1xuICAgICAgICAgIC8vIE5vbi1lbnVtZXJhYmxlIHRvIG1hdGNoIG5hdGl2ZSBFcnJvciBgY2F1c2VgIHNlbWFudGljcyBzbyBsb2dnZXJzXG4gICAgICAgICAgLy8gZG9uJ3QgcmVjdXJzZSBpbnRvIGNpcmN1bGFyIGZldGNoIGludGVybmFscyAoc2VlICM3MjA1KS5cbiAgICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoY2FuY2VsZWRFcnJvciwgJ2NhdXNlJywge1xuICAgICAgICAgICAgX19wcm90b19fOiBudWxsLFxuICAgICAgICAgICAgdmFsdWU6IGVycixcbiAgICAgICAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgdGhyb3cgY2FuY2VsZWRFcnJvcjtcbiAgICAgIH1cblxuICAgICAgLy8gU3VyZmFjZSBhIG1heEJvZHlMZW5ndGggdmlvbGF0aW9uIHdlIHJhaXNlZCB3aGlsZSB0aGUgcmVxdWVzdCBib2R5IHdhc1xuICAgICAgLy8gYmVpbmcgc3RyZWFtZWQuIE1hdGNoaW5nIGJ5IGlkZW50aXR5IChyYXRoZXIgdGhhbiByZWFkaW5nXG4gICAgICAvLyBgZXJyLmNhdXNlLmlzQXhpb3NFcnJvcmApIGtlZXBzIHRoZSBlcnJvciBkZXRlcm1pbmlzdGljIGFjcm9zcyBydW50aW1lc1xuICAgICAgLy8gYW5kIGF2b2lkcyBib3RoIHByb3RvdHlwZS1wb2xsdXRpb24gcmVhZHMgYW5kIG1pcy1hdHRyaWJ1dGluZyBhIGZvcmVpZ25cbiAgICAgIC8vIEF4aW9zRXJyb3IgdGhhdCBtZXJlbHkgaGFwcGVuZWQgdG8gbGFuZCBpbiBgZXJyLmNhdXNlYC5cbiAgICAgIGlmIChwZW5kaW5nQm9keUVycm9yKSB7XG4gICAgICAgIHJlcXVlc3QgJiYgIXBlbmRpbmdCb2R5RXJyb3IucmVxdWVzdCAmJiAocGVuZGluZ0JvZHlFcnJvci5yZXF1ZXN0ID0gcmVxdWVzdCk7XG4gICAgICAgIHRocm93IHBlbmRpbmdCb2R5RXJyb3I7XG4gICAgICB9XG5cbiAgICAgIC8vIFJlLXRocm93IEF4aW9zRXJyb3JzIHdlIHJhaXNlZCBzeW5jaHJvbm91c2x5IChkYXRhOiBVUkwgLyBjb250ZW50LWxlbmd0aFxuICAgICAgLy8gcHJlLWNoZWNrcywgcmVzcG9uc2Ugc2l6ZSBlbmZvcmNlbWVudCkgd2l0aG91dCByZS13cmFwcGluZyB0aGVtLlxuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEF4aW9zRXJyb3IpIHtcbiAgICAgICAgcmVxdWVzdCAmJiAhZXJyLnJlcXVlc3QgJiYgKGVyci5yZXF1ZXN0ID0gcmVxdWVzdCk7XG4gICAgICAgIHRocm93IGVycjtcbiAgICAgIH1cblxuICAgICAgaWYgKGVyciAmJiBlcnIubmFtZSA9PT0gJ1R5cGVFcnJvcicgJiYgL0xvYWQgZmFpbGVkfGZldGNoL2kudGVzdChlcnIubWVzc2FnZSkpIHtcbiAgICAgICAgY29uc3QgbmV0d29ya0Vycm9yID0gbmV3IEF4aW9zRXJyb3IoXG4gICAgICAgICAgJ05ldHdvcmsgRXJyb3InLFxuICAgICAgICAgIEF4aW9zRXJyb3IuRVJSX05FVFdPUkssXG4gICAgICAgICAgY29uZmlnLFxuICAgICAgICAgIHJlcXVlc3QsXG4gICAgICAgICAgZXJyICYmIGVyci5yZXNwb25zZVxuICAgICAgICApO1xuICAgICAgICAvLyBOb24tZW51bWVyYWJsZSB0byBtYXRjaCBuYXRpdmUgRXJyb3IgYGNhdXNlYCBzZW1hbnRpY3Mgc28gbG9nZ2Vyc1xuICAgICAgICAvLyBkb24ndCByZWN1cnNlIGludG8gY2lyY3VsYXIgZmV0Y2ggaW50ZXJuYWxzIChzZWUgIzcyMDUpLlxuICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkobmV0d29ya0Vycm9yLCAnY2F1c2UnLCB7XG4gICAgICAgICAgX19wcm90b19fOiBudWxsLFxuICAgICAgICAgIHZhbHVlOiBlcnIuY2F1c2UgfHwgZXJyLFxuICAgICAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICAgIHRocm93IG5ldHdvcmtFcnJvcjtcbiAgICAgIH1cblxuICAgICAgdGhyb3cgQXhpb3NFcnJvci5mcm9tKGVyciwgZXJyICYmIGVyci5jb2RlLCBjb25maWcsIHJlcXVlc3QsIGVyciAmJiBlcnIucmVzcG9uc2UpO1xuICAgIH1cbiAgfTtcbn07XG5cbmNvbnN0IHNlZWRDYWNoZSA9IG5ldyBNYXAoKTtcblxuZXhwb3J0IGNvbnN0IGdldEZldGNoID0gKGNvbmZpZykgPT4ge1xuICBsZXQgZW52ID0gKGNvbmZpZyAmJiBjb25maWcuZW52KSB8fCB7fTtcbiAgY29uc3QgeyBmZXRjaCwgUmVxdWVzdCwgUmVzcG9uc2UgfSA9IGVudjtcbiAgY29uc3Qgc2VlZHMgPSBbUmVxdWVzdCwgUmVzcG9uc2UsIGZldGNoXTtcblxuICBsZXQgbGVuID0gc2VlZHMubGVuZ3RoLFxuICAgIGkgPSBsZW4sXG4gICAgc2VlZCxcbiAgICB0YXJnZXQsXG4gICAgbWFwID0gc2VlZENhY2hlO1xuXG4gIHdoaWxlIChpLS0pIHtcbiAgICBzZWVkID0gc2VlZHNbaV07XG4gICAgdGFyZ2V0ID0gbWFwLmdldChzZWVkKTtcblxuICAgIHRhcmdldCA9PT0gdW5kZWZpbmVkICYmIG1hcC5zZXQoc2VlZCwgKHRhcmdldCA9IGkgPyBuZXcgTWFwKCkgOiBmYWN0b3J5KGVudikpKTtcblxuICAgIG1hcCA9IHRhcmdldDtcbiAgfVxuXG4gIHJldHVybiB0YXJnZXQ7XG59O1xuXG5jb25zdCBhZGFwdGVyID0gZ2V0RmV0Y2goKTtcblxuZXhwb3J0IGRlZmF1bHQgYWRhcHRlcjtcbiIsImltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5pbXBvcnQgaHR0cEFkYXB0ZXIgZnJvbSAnLi9odHRwLmpzJztcbmltcG9ydCB4aHJBZGFwdGVyIGZyb20gJy4veGhyLmpzJztcbmltcG9ydCAqIGFzIGZldGNoQWRhcHRlciBmcm9tICcuL2ZldGNoLmpzJztcbmltcG9ydCBBeGlvc0Vycm9yIGZyb20gJy4uL2NvcmUvQXhpb3NFcnJvci5qcyc7XG5cbi8qKlxuICogS25vd24gYWRhcHRlcnMgbWFwcGluZy5cbiAqIFByb3ZpZGVzIGVudmlyb25tZW50LXNwZWNpZmljIGFkYXB0ZXJzIGZvciBBeGlvczpcbiAqIC0gYGh0dHBgIGZvciBOb2RlLmpzXG4gKiAtIGB4aHJgIGZvciBicm93c2Vyc1xuICogLSBgZmV0Y2hgIGZvciBmZXRjaCBBUEktYmFzZWQgcmVxdWVzdHNcbiAqXG4gKiBAdHlwZSB7T2JqZWN0PHN0cmluZywgRnVuY3Rpb258T2JqZWN0Pn1cbiAqL1xuY29uc3Qga25vd25BZGFwdGVycyA9IHtcbiAgaHR0cDogaHR0cEFkYXB0ZXIsXG4gIHhocjogeGhyQWRhcHRlcixcbiAgZmV0Y2g6IHtcbiAgICBnZXQ6IGZldGNoQWRhcHRlci5nZXRGZXRjaCxcbiAgfSxcbn07XG5cbi8vIEFzc2lnbiBhZGFwdGVyIG5hbWVzIGZvciBlYXNpZXIgZGVidWdnaW5nIGFuZCBpZGVudGlmaWNhdGlvblxudXRpbHMuZm9yRWFjaChrbm93bkFkYXB0ZXJzLCAoZm4sIHZhbHVlKSA9PiB7XG4gIGlmIChmbikge1xuICAgIHRyeSB7XG4gICAgICAvLyBOdWxsLXByb3RvIGRlc2NyaXB0b3JzIHNvIGEgcG9sbHV0ZWQgT2JqZWN0LnByb3RvdHlwZS5nZXQgY2Fubm90IHR1cm5cbiAgICAgIC8vIHRoZXNlIGRhdGEgZGVzY3JpcHRvcnMgaW50byBhY2Nlc3NvciBkZXNjcmlwdG9ycyBvbiB0aGUgd2F5IGluLlxuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGZuLCAnbmFtZScsIHsgX19wcm90b19fOiBudWxsLCB2YWx1ZSB9KTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tZW1wdHlcbiAgICB9XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGZuLCAnYWRhcHRlck5hbWUnLCB7IF9fcHJvdG9fXzogbnVsbCwgdmFsdWUgfSk7XG4gIH1cbn0pO1xuXG4vKipcbiAqIFJlbmRlciBhIHJlamVjdGlvbiByZWFzb24gc3RyaW5nIGZvciB1bmtub3duIG9yIHVuc3VwcG9ydGVkIGFkYXB0ZXJzXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IHJlYXNvblxuICogQHJldHVybnMge3N0cmluZ31cbiAqL1xuY29uc3QgcmVuZGVyUmVhc29uID0gKHJlYXNvbikgPT4gYC0gJHtyZWFzb259YDtcblxuLyoqXG4gKiBDaGVjayBpZiB0aGUgYWRhcHRlciBpcyByZXNvbHZlZCAoZnVuY3Rpb24sIG51bGwsIG9yIGZhbHNlKVxuICpcbiAqIEBwYXJhbSB7RnVuY3Rpb258bnVsbHxmYWxzZX0gYWRhcHRlclxuICogQHJldHVybnMge2Jvb2xlYW59XG4gKi9cbmNvbnN0IGlzUmVzb2x2ZWRIYW5kbGUgPSAoYWRhcHRlcikgPT5cbiAgdXRpbHMuaXNGdW5jdGlvbihhZGFwdGVyKSB8fCBhZGFwdGVyID09PSBudWxsIHx8IGFkYXB0ZXIgPT09IGZhbHNlO1xuXG4vKipcbiAqIEdldCB0aGUgZmlyc3Qgc3VpdGFibGUgYWRhcHRlciBmcm9tIHRoZSBwcm92aWRlZCBsaXN0LlxuICogVHJpZXMgZWFjaCBhZGFwdGVyIGluIG9yZGVyIHVudGlsIGEgc3VwcG9ydGVkIG9uZSBpcyBmb3VuZC5cbiAqIFRocm93cyBhbiBBeGlvc0Vycm9yIGlmIG5vIGFkYXB0ZXIgaXMgc3VpdGFibGUuXG4gKlxuICogQHBhcmFtIHtBcnJheTxzdHJpbmd8RnVuY3Rpb24+fHN0cmluZ3xGdW5jdGlvbn0gYWRhcHRlcnMgLSBBZGFwdGVyKHMpIGJ5IG5hbWUgb3IgZnVuY3Rpb24uXG4gKiBAcGFyYW0ge09iamVjdH0gY29uZmlnIC0gQXhpb3MgcmVxdWVzdCBjb25maWd1cmF0aW9uXG4gKiBAdGhyb3dzIHtBeGlvc0Vycm9yfSBJZiBubyBzdWl0YWJsZSBhZGFwdGVyIGlzIGF2YWlsYWJsZVxuICogQHJldHVybnMge0Z1bmN0aW9ufSBUaGUgcmVzb2x2ZWQgYWRhcHRlciBmdW5jdGlvblxuICovXG5mdW5jdGlvbiBnZXRBZGFwdGVyKGFkYXB0ZXJzLCBjb25maWcpIHtcbiAgYWRhcHRlcnMgPSB1dGlscy5pc0FycmF5KGFkYXB0ZXJzKSA/IGFkYXB0ZXJzIDogW2FkYXB0ZXJzXTtcblxuICBjb25zdCB7IGxlbmd0aCB9ID0gYWRhcHRlcnM7XG4gIGxldCBuYW1lT3JBZGFwdGVyO1xuICBsZXQgYWRhcHRlcjtcblxuICBjb25zdCByZWplY3RlZFJlYXNvbnMgPSB7fTtcblxuICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbmd0aDsgaSsrKSB7XG4gICAgbmFtZU9yQWRhcHRlciA9IGFkYXB0ZXJzW2ldO1xuICAgIGxldCBpZDtcblxuICAgIGFkYXB0ZXIgPSBuYW1lT3JBZGFwdGVyO1xuXG4gICAgaWYgKCFpc1Jlc29sdmVkSGFuZGxlKG5hbWVPckFkYXB0ZXIpKSB7XG4gICAgICBhZGFwdGVyID0ga25vd25BZGFwdGVyc1soaWQgPSBTdHJpbmcobmFtZU9yQWRhcHRlcikpLnRvTG93ZXJDYXNlKCldO1xuXG4gICAgICBpZiAoYWRhcHRlciA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKGBVbmtub3duIGFkYXB0ZXIgJyR7aWR9J2ApO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmIChhZGFwdGVyICYmICh1dGlscy5pc0Z1bmN0aW9uKGFkYXB0ZXIpIHx8IChhZGFwdGVyID0gYWRhcHRlci5nZXQoY29uZmlnKSkpKSB7XG4gICAgICBicmVhaztcbiAgICB9XG5cbiAgICByZWplY3RlZFJlYXNvbnNbaWQgfHwgJyMnICsgaV0gPSBhZGFwdGVyO1xuICB9XG5cbiAgaWYgKCFhZGFwdGVyKSB7XG4gICAgY29uc3QgcmVhc29ucyA9IE9iamVjdC5lbnRyaWVzKHJlamVjdGVkUmVhc29ucykubWFwKFxuICAgICAgKFtpZCwgc3RhdGVdKSA9PlxuICAgICAgICBgYWRhcHRlciAke2lkfSBgICtcbiAgICAgICAgKHN0YXRlID09PSBmYWxzZSA/ICdpcyBub3Qgc3VwcG9ydGVkIGJ5IHRoZSBlbnZpcm9ubWVudCcgOiAnaXMgbm90IGF2YWlsYWJsZSBpbiB0aGUgYnVpbGQnKVxuICAgICk7XG5cbiAgICBsZXQgcyA9IGxlbmd0aFxuICAgICAgPyByZWFzb25zLmxlbmd0aCA+IDFcbiAgICAgICAgPyAnc2luY2UgOlxcbicgKyByZWFzb25zLm1hcChyZW5kZXJSZWFzb24pLmpvaW4oJ1xcbicpXG4gICAgICAgIDogJyAnICsgcmVuZGVyUmVhc29uKHJlYXNvbnNbMF0pXG4gICAgICA6ICdhcyBubyBhZGFwdGVyIHNwZWNpZmllZCc7XG5cbiAgICB0aHJvdyBuZXcgQXhpb3NFcnJvcihcbiAgICAgIGBUaGVyZSBpcyBubyBzdWl0YWJsZSBhZGFwdGVyIHRvIGRpc3BhdGNoIHRoZSByZXF1ZXN0IGAgKyBzLFxuICAgICAgQXhpb3NFcnJvci5FUlJfTk9UX1NVUFBPUlRcbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIGFkYXB0ZXI7XG59XG5cbi8qKlxuICogRXhwb3J0cyBBeGlvcyBhZGFwdGVycyBhbmQgdXRpbGl0eSB0byByZXNvbHZlIGFuIGFkYXB0ZXJcbiAqL1xuZXhwb3J0IGRlZmF1bHQge1xuICAvKipcbiAgICogUmVzb2x2ZSBhbiBhZGFwdGVyIGZyb20gYSBsaXN0IG9mIGFkYXB0ZXIgbmFtZXMgb3IgZnVuY3Rpb25zLlxuICAgKiBAdHlwZSB7RnVuY3Rpb259XG4gICAqL1xuICBnZXRBZGFwdGVyLFxuXG4gIC8qKlxuICAgKiBFeHBvc2VzIGFsbCBrbm93biBhZGFwdGVyc1xuICAgKiBAdHlwZSB7T2JqZWN0PHN0cmluZywgRnVuY3Rpb258T2JqZWN0Pn1cbiAgICovXG4gIGFkYXB0ZXJzOiBrbm93bkFkYXB0ZXJzLFxufTtcbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHRyYW5zZm9ybURhdGEgZnJvbSAnLi90cmFuc2Zvcm1EYXRhLmpzJztcbmltcG9ydCBpc0NhbmNlbCBmcm9tICcuLi9jYW5jZWwvaXNDYW5jZWwuanMnO1xuaW1wb3J0IGRlZmF1bHRzIGZyb20gJy4uL2RlZmF1bHRzL2luZGV4LmpzJztcbmltcG9ydCBDYW5jZWxlZEVycm9yIGZyb20gJy4uL2NhbmNlbC9DYW5jZWxlZEVycm9yLmpzJztcbmltcG9ydCBBeGlvc0hlYWRlcnMgZnJvbSAnLi4vY29yZS9BeGlvc0hlYWRlcnMuanMnO1xuaW1wb3J0IGFkYXB0ZXJzIGZyb20gJy4uL2FkYXB0ZXJzL2FkYXB0ZXJzLmpzJztcbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5cbi8qKlxuICogVGhyb3dzIGEgYENhbmNlbGVkRXJyb3JgIGlmIGNhbmNlbGxhdGlvbiBoYXMgYmVlbiByZXF1ZXN0ZWQuXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IGNvbmZpZyBUaGUgY29uZmlnIHRoYXQgaXMgdG8gYmUgdXNlZCBmb3IgdGhlIHJlcXVlc3RcbiAqXG4gKiBAcmV0dXJucyB7dm9pZH1cbiAqL1xuZnVuY3Rpb24gdGhyb3dJZkNhbmNlbGxhdGlvblJlcXVlc3RlZChjb25maWcpIHtcbiAgaWYgKGNvbmZpZy5jYW5jZWxUb2tlbikge1xuICAgIGNvbmZpZy5jYW5jZWxUb2tlbi50aHJvd0lmUmVxdWVzdGVkKCk7XG4gIH1cblxuICBpZiAoY29uZmlnLnNpZ25hbCAmJiBjb25maWcuc2lnbmFsLmFib3J0ZWQpIHtcbiAgICB0aHJvdyBuZXcgQ2FuY2VsZWRFcnJvcihudWxsLCBjb25maWcpO1xuICB9XG59XG5cbi8qKlxuICogRGlzcGF0Y2ggYSByZXF1ZXN0IHRvIHRoZSBzZXJ2ZXIgdXNpbmcgdGhlIGNvbmZpZ3VyZWQgYWRhcHRlci5cbiAqXG4gKiBAcGFyYW0ge29iamVjdH0gY29uZmlnIFRoZSBjb25maWcgdGhhdCBpcyB0byBiZSB1c2VkIGZvciB0aGUgcmVxdWVzdFxuICpcbiAqIEByZXR1cm5zIHtQcm9taXNlfSBUaGUgUHJvbWlzZSB0byBiZSBmdWxmaWxsZWRcbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gZGlzcGF0Y2hSZXF1ZXN0KF9jb25maWcpIHtcbiAgLy8gSW50ZXJjZXB0b3JzIG1heSByZXBsYWNlIHRoZSBtZXJnZWQgY29uZmlnIHdpdGggYW4gb3JkaW5hcnkgb2JqZWN0LiBGbGF0dGVuXG4gIC8vIGl0IGF0IHRoZSBkaXNwYXRjaCBib3VuZGFyeSBzbyBzaGFyZWQgcHJvdG90eXBlIG1lbWJlcnMgY2Fubm90IGJlY29tZVxuICAvLyByZXF1ZXN0IGJlaGF2aW9yLCB3aGlsZSBwcmVzZXJ2aW5nIGludGVudGlvbmFsIHRlbXBsYXRlL2NsYXNzIG1lbWJlcnMuXG4gIGNvbnN0IGNvbmZpZyA9IHV0aWxzLnRvU2FmZUZsYXRPYmplY3QoX2NvbmZpZyk7XG5cbiAgdGhyb3dJZkNhbmNlbGxhdGlvblJlcXVlc3RlZChjb25maWcpO1xuXG4gIGNvbmZpZy5oZWFkZXJzID0gQXhpb3NIZWFkZXJzLmZyb20odXRpbHMuZ2V0U2FmZVByb3AoY29uZmlnLCAnaGVhZGVycycpKTtcblxuICAvLyBUcmFuc2Zvcm0gcmVxdWVzdCBkYXRhXG4gIGNvbmZpZy5kYXRhID0gdHJhbnNmb3JtRGF0YS5jYWxsKGNvbmZpZywgY29uZmlnLnRyYW5zZm9ybVJlcXVlc3QpO1xuXG4gIGlmIChbJ3Bvc3QnLCAncHV0JywgJ3BhdGNoJ10uaW5kZXhPZihjb25maWcubWV0aG9kKSAhPT0gLTEpIHtcbiAgICBjb25maWcuaGVhZGVycy5zZXRDb250ZW50VHlwZSgnYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkJywgZmFsc2UpO1xuICB9XG5cbiAgY29uc3QgYWRhcHRlciA9IGFkYXB0ZXJzLmdldEFkYXB0ZXIoY29uZmlnLmFkYXB0ZXIgfHwgZGVmYXVsdHMuYWRhcHRlciwgY29uZmlnKTtcblxuICByZXR1cm4gYWRhcHRlcihjb25maWcpLnRoZW4oXG4gICAgZnVuY3Rpb24gb25BZGFwdGVyUmVzb2x1dGlvbihyZXNwb25zZSkge1xuICAgICAgdGhyb3dJZkNhbmNlbGxhdGlvblJlcXVlc3RlZChjb25maWcpO1xuXG4gICAgICAvLyBFeHBvc2UgdGhlIGN1cnJlbnQgcmVzcG9uc2Ugb24gY29uZmlnIHNvIHRoYXQgdHJhbnNmb3JtUmVzcG9uc2UgY2FuXG4gICAgICAvLyBhdHRhY2ggaXQgdG8gYW55IEF4aW9zRXJyb3IgaXQgdGhyb3dzIChlLmcuIG9uIEpTT04gcGFyc2UgZmFpbHVyZSkuXG4gICAgICAvLyBXZSBjbGVhbiBpdCB1cCBhZnRlcndhcmRzIHRvIGF2b2lkIHBvbGx1dGluZyB0aGUgY29uZmlnIG9iamVjdC5cbiAgICAgIGNvbmZpZy5yZXNwb25zZSA9IHJlc3BvbnNlO1xuICAgICAgdHJ5IHtcbiAgICAgICAgcmVzcG9uc2UuZGF0YSA9IHRyYW5zZm9ybURhdGEuY2FsbChjb25maWcsIGNvbmZpZy50cmFuc2Zvcm1SZXNwb25zZSwgcmVzcG9uc2UpO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgZGVsZXRlIGNvbmZpZy5yZXNwb25zZTtcbiAgICAgIH1cblxuICAgICAgcmVzcG9uc2UuaGVhZGVycyA9IEF4aW9zSGVhZGVycy5mcm9tKHJlc3BvbnNlLmhlYWRlcnMpO1xuXG4gICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgfSxcbiAgICBmdW5jdGlvbiBvbkFkYXB0ZXJSZWplY3Rpb24ocmVhc29uKSB7XG4gICAgICBpZiAoIWlzQ2FuY2VsKHJlYXNvbikpIHtcbiAgICAgICAgdGhyb3dJZkNhbmNlbGxhdGlvblJlcXVlc3RlZChjb25maWcpO1xuXG4gICAgICAgIC8vIFRyYW5zZm9ybSByZXNwb25zZSBkYXRhXG4gICAgICAgIGlmIChyZWFzb24gJiYgcmVhc29uLnJlc3BvbnNlKSB7XG4gICAgICAgICAgY29uZmlnLnJlc3BvbnNlID0gcmVhc29uLnJlc3BvbnNlO1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZWFzb24ucmVzcG9uc2UuZGF0YSA9IHRyYW5zZm9ybURhdGEuY2FsbChcbiAgICAgICAgICAgICAgY29uZmlnLFxuICAgICAgICAgICAgICBjb25maWcudHJhbnNmb3JtUmVzcG9uc2UsXG4gICAgICAgICAgICAgIHJlYXNvbi5yZXNwb25zZVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgZGVsZXRlIGNvbmZpZy5yZXNwb25zZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmVhc29uLnJlc3BvbnNlLmhlYWRlcnMgPSBBeGlvc0hlYWRlcnMuZnJvbShyZWFzb24ucmVzcG9uc2UuaGVhZGVycyk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KHJlYXNvbik7XG4gICAgfVxuICApO1xufVxuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgeyBWRVJTSU9OIH0gZnJvbSAnLi4vZW52L2RhdGEuanMnO1xuaW1wb3J0IEF4aW9zRXJyb3IgZnJvbSAnLi4vY29yZS9BeGlvc0Vycm9yLmpzJztcblxuY29uc3QgdmFsaWRhdG9ycyA9IHt9O1xuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZnVuYy1uYW1lc1xuWydvYmplY3QnLCAnYm9vbGVhbicsICdudW1iZXInLCAnZnVuY3Rpb24nLCAnc3RyaW5nJywgJ3N5bWJvbCddLmZvckVhY2goKHR5cGUsIGkpID0+IHtcbiAgdmFsaWRhdG9yc1t0eXBlXSA9IGZ1bmN0aW9uIHZhbGlkYXRvcih0aGluZykge1xuICAgIHJldHVybiB0eXBlb2YgdGhpbmcgPT09IHR5cGUgfHwgJ2EnICsgKGkgPCAxID8gJ24gJyA6ICcgJykgKyB0eXBlO1xuICB9O1xufSk7XG5cbmNvbnN0IGRlcHJlY2F0ZWRXYXJuaW5ncyA9IHt9O1xuXG4vKipcbiAqIFRyYW5zaXRpb25hbCBvcHRpb24gdmFsaWRhdG9yXG4gKlxuICogQHBhcmFtIHtmdW5jdGlvbnxib29sZWFuP30gdmFsaWRhdG9yIC0gc2V0IHRvIGZhbHNlIGlmIHRoZSB0cmFuc2l0aW9uYWwgb3B0aW9uIGhhcyBiZWVuIHJlbW92ZWRcbiAqIEBwYXJhbSB7c3RyaW5nP30gdmVyc2lvbiAtIGRlcHJlY2F0ZWQgdmVyc2lvbiAvIHJlbW92ZWQgc2luY2UgdmVyc2lvblxuICogQHBhcmFtIHtzdHJpbmc/fSBtZXNzYWdlIC0gc29tZSBtZXNzYWdlIHdpdGggYWRkaXRpb25hbCBpbmZvXG4gKlxuICogQHJldHVybnMge2Z1bmN0aW9ufVxuICovXG52YWxpZGF0b3JzLnRyYW5zaXRpb25hbCA9IGZ1bmN0aW9uIHRyYW5zaXRpb25hbCh2YWxpZGF0b3IsIHZlcnNpb24sIG1lc3NhZ2UpIHtcbiAgZnVuY3Rpb24gZm9ybWF0TWVzc2FnZShvcHQsIGRlc2MpIHtcbiAgICByZXR1cm4gKFxuICAgICAgJ1tBeGlvcyB2JyArXG4gICAgICBWRVJTSU9OICtcbiAgICAgIFwiXSBUcmFuc2l0aW9uYWwgb3B0aW9uICdcIiArXG4gICAgICBvcHQgK1xuICAgICAgXCInXCIgK1xuICAgICAgZGVzYyArXG4gICAgICAobWVzc2FnZSA/ICcuICcgKyBtZXNzYWdlIDogJycpXG4gICAgKTtcbiAgfVxuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBmdW5jLW5hbWVzXG4gIHJldHVybiAodmFsdWUsIG9wdCwgb3B0cykgPT4ge1xuICAgIGlmICh2YWxpZGF0b3IgPT09IGZhbHNlKSB7XG4gICAgICB0aHJvdyBuZXcgQXhpb3NFcnJvcihcbiAgICAgICAgZm9ybWF0TWVzc2FnZShvcHQsICcgaGFzIGJlZW4gcmVtb3ZlZCcgKyAodmVyc2lvbiA/ICcgaW4gJyArIHZlcnNpb24gOiAnJykpLFxuICAgICAgICBBeGlvc0Vycm9yLkVSUl9ERVBSRUNBVEVEXG4gICAgICApO1xuICAgIH1cblxuICAgIGlmICh2ZXJzaW9uICYmICFkZXByZWNhdGVkV2FybmluZ3Nbb3B0XSkge1xuICAgICAgZGVwcmVjYXRlZFdhcm5pbmdzW29wdF0gPSB0cnVlO1xuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNvbnNvbGVcbiAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgZm9ybWF0TWVzc2FnZShcbiAgICAgICAgICBvcHQsXG4gICAgICAgICAgJyBoYXMgYmVlbiBkZXByZWNhdGVkIHNpbmNlIHYnICsgdmVyc2lvbiArICcgYW5kIHdpbGwgYmUgcmVtb3ZlZCBpbiB0aGUgbmVhciBmdXR1cmUnXG4gICAgICAgIClcbiAgICAgICk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHZhbGlkYXRvciA/IHZhbGlkYXRvcih2YWx1ZSwgb3B0LCBvcHRzKSA6IHRydWU7XG4gIH07XG59O1xuXG52YWxpZGF0b3JzLnNwZWxsaW5nID0gZnVuY3Rpb24gc3BlbGxpbmcoY29ycmVjdFNwZWxsaW5nKSB7XG4gIHJldHVybiAodmFsdWUsIG9wdCkgPT4ge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1jb25zb2xlXG4gICAgY29uc29sZS53YXJuKGAke29wdH0gaXMgbGlrZWx5IGEgbWlzc3BlbGxpbmcgb2YgJHtjb3JyZWN0U3BlbGxpbmd9YCk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH07XG59O1xuXG4vKipcbiAqIEFzc2VydCBvYmplY3QncyBwcm9wZXJ0aWVzIHR5cGVcbiAqXG4gKiBAcGFyYW0ge29iamVjdH0gb3B0aW9uc1xuICogQHBhcmFtIHtvYmplY3R9IHNjaGVtYVxuICogQHBhcmFtIHtib29sZWFuP30gYWxsb3dVbmtub3duXG4gKlxuICogQHJldHVybnMge29iamVjdH1cbiAqL1xuXG5mdW5jdGlvbiBhc3NlcnRPcHRpb25zKG9wdGlvbnMsIHNjaGVtYSwgYWxsb3dVbmtub3duKSB7XG4gIGlmICh0eXBlb2Ygb3B0aW9ucyAhPT0gJ29iamVjdCcgfHwgb3B0aW9ucyA9PT0gbnVsbCkge1xuICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKCdvcHRpb25zIG11c3QgYmUgYW4gb2JqZWN0JywgQXhpb3NFcnJvci5FUlJfQkFEX09QVElPTl9WQUxVRSk7XG4gIH1cbiAgY29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKG9wdGlvbnMpO1xuICBsZXQgaSA9IGtleXMubGVuZ3RoO1xuICB3aGlsZSAoaS0tID4gMCkge1xuICAgIGNvbnN0IG9wdCA9IGtleXNbaV07XG4gICAgLy8gVXNlIGhhc093blByb3BlcnR5IHNvIGEgcG9sbHV0ZWQgT2JqZWN0LnByb3RvdHlwZS48b3B0PiBjYW5ub3Qgc3VwcGx5XG4gICAgLy8gYSBub24tZnVuY3Rpb24gdmFsaWRhdG9yIGFuZCBjYXVzZSBhIFR5cGVFcnJvci5cbiAgICBjb25zdCB2YWxpZGF0b3IgPSBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoc2NoZW1hLCBvcHQpID8gc2NoZW1hW29wdF0gOiB1bmRlZmluZWQ7XG4gICAgaWYgKHZhbGlkYXRvcikge1xuICAgICAgY29uc3QgdmFsdWUgPSBvcHRpb25zW29wdF07XG4gICAgICBjb25zdCByZXN1bHQgPSB2YWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHZhbGlkYXRvcih2YWx1ZSwgb3B0LCBvcHRpb25zKTtcbiAgICAgIGlmIChyZXN1bHQgIT09IHRydWUpIHtcbiAgICAgICAgdGhyb3cgbmV3IEF4aW9zRXJyb3IoXG4gICAgICAgICAgJ29wdGlvbiAnICsgb3B0ICsgJyBtdXN0IGJlICcgKyByZXN1bHQsXG4gICAgICAgICAgQXhpb3NFcnJvci5FUlJfQkFEX09QVElPTl9WQUxVRVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChhbGxvd1Vua25vd24gIT09IHRydWUpIHtcbiAgICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKCdVbmtub3duIG9wdGlvbiAnICsgb3B0LCBBeGlvc0Vycm9yLkVSUl9CQURfT1BUSU9OKTtcbiAgICB9XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQge1xuICBhc3NlcnRPcHRpb25zLFxuICB2YWxpZGF0b3JzLFxufTtcbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCBidWlsZFVSTCBmcm9tICcuLi9oZWxwZXJzL2J1aWxkVVJMLmpzJztcbmltcG9ydCBJbnRlcmNlcHRvck1hbmFnZXIgZnJvbSAnLi9JbnRlcmNlcHRvck1hbmFnZXIuanMnO1xuaW1wb3J0IGRpc3BhdGNoUmVxdWVzdCBmcm9tICcuL2Rpc3BhdGNoUmVxdWVzdC5qcyc7XG5pbXBvcnQgbWVyZ2VDb25maWcgZnJvbSAnLi9tZXJnZUNvbmZpZy5qcyc7XG5pbXBvcnQgYnVpbGRGdWxsUGF0aCBmcm9tICcuL2J1aWxkRnVsbFBhdGguanMnO1xuaW1wb3J0IG1ldGhvZExpc3QgZnJvbSAnLi9tZXRob2RMaXN0LmpzJztcbmltcG9ydCB2YWxpZGF0b3IgZnJvbSAnLi4vaGVscGVycy92YWxpZGF0b3IuanMnO1xuaW1wb3J0IEF4aW9zSGVhZGVycyBmcm9tICcuL0F4aW9zSGVhZGVycy5qcyc7XG5pbXBvcnQgdHJhbnNpdGlvbmFsRGVmYXVsdHMgZnJvbSAnLi4vZGVmYXVsdHMvdHJhbnNpdGlvbmFsLmpzJztcblxuY29uc3QgdmFsaWRhdG9ycyA9IHZhbGlkYXRvci52YWxpZGF0b3JzO1xuXG4vKipcbiAqIENyZWF0ZSBhIG5ldyBpbnN0YW5jZSBvZiBBeGlvc1xuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBpbnN0YW5jZUNvbmZpZyBUaGUgZGVmYXVsdCBjb25maWcgZm9yIHRoZSBpbnN0YW5jZVxuICpcbiAqIEByZXR1cm4ge0F4aW9zfSBBIG5ldyBpbnN0YW5jZSBvZiBBeGlvc1xuICovXG5jbGFzcyBBeGlvcyB7XG4gIGNvbnN0cnVjdG9yKGluc3RhbmNlQ29uZmlnKSB7XG4gICAgdGhpcy5kZWZhdWx0cyA9IGluc3RhbmNlQ29uZmlnIHx8IHt9O1xuICAgIHRoaXMuaW50ZXJjZXB0b3JzID0ge1xuICAgICAgcmVxdWVzdDogbmV3IEludGVyY2VwdG9yTWFuYWdlcigpLFxuICAgICAgcmVzcG9uc2U6IG5ldyBJbnRlcmNlcHRvck1hbmFnZXIoKSxcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIERpc3BhdGNoIGEgcmVxdWVzdFxuICAgKlxuICAgKiBAcGFyYW0ge1N0cmluZ3xPYmplY3R9IGNvbmZpZ09yVXJsIFRoZSBjb25maWcgc3BlY2lmaWMgZm9yIHRoaXMgcmVxdWVzdCAobWVyZ2VkIHdpdGggdGhpcy5kZWZhdWx0cylcbiAgICogQHBhcmFtIHs/T2JqZWN0fSBjb25maWdcbiAgICpcbiAgICogQHJldHVybnMge1Byb21pc2V9IFRoZSBQcm9taXNlIHRvIGJlIGZ1bGZpbGxlZFxuICAgKi9cbiAgYXN5bmMgcmVxdWVzdChjb25maWdPclVybCwgY29uZmlnKSB7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLl9yZXF1ZXN0KGNvbmZpZ09yVXJsLCBjb25maWcpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgbGV0IGR1bW15ID0ge307XG5cbiAgICAgICAgICBFcnJvci5jYXB0dXJlU3RhY2tUcmFjZSA/IEVycm9yLmNhcHR1cmVTdGFja1RyYWNlKGR1bW15KSA6IChkdW1teSA9IG5ldyBFcnJvcigpKTtcblxuICAgICAgICAgIGNvbnN0IGR1bW15U3RhY2sgPSBkdW1teS5zdGFjaztcbiAgICAgICAgICBsZXQgc3RhY2sgPSAnJztcblxuICAgICAgICAgIC8vIHNsaWNlIG9mZiB0aGUgRXJyb3I6IC4uLiBsaW5lXG4gICAgICAgICAgaWYgKHR5cGVvZiBkdW1teVN0YWNrID09PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgY29uc3QgZmlyc3ROZXdsaW5lSW5kZXggPSBkdW1teVN0YWNrLmluZGV4T2YoJ1xcbicpO1xuXG4gICAgICAgICAgICBzdGFjayA9IGZpcnN0TmV3bGluZUluZGV4ID09PSAtMSA/ICcnIDogZHVtbXlTdGFjay5zbGljZShmaXJzdE5ld2xpbmVJbmRleCArIDEpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGlmICghZXJyLnN0YWNrKSB7XG4gICAgICAgICAgICBlcnIuc3RhY2sgPSBzdGFjaztcbiAgICAgICAgICAgIC8vIG1hdGNoIHdpdGhvdXQgdGhlIDIgdG9wIHN0YWNrIGxpbmVzXG4gICAgICAgICAgfSBlbHNlIGlmIChzdGFjaykge1xuICAgICAgICAgICAgY29uc3QgZmlyc3ROZXdsaW5lSW5kZXggPSBzdGFjay5pbmRleE9mKCdcXG4nKTtcbiAgICAgICAgICAgIGNvbnN0IHNlY29uZE5ld2xpbmVJbmRleCA9XG4gICAgICAgICAgICAgIGZpcnN0TmV3bGluZUluZGV4ID09PSAtMSA/IC0xIDogc3RhY2suaW5kZXhPZignXFxuJywgZmlyc3ROZXdsaW5lSW5kZXggKyAxKTtcbiAgICAgICAgICAgIGNvbnN0IHN0YWNrV2l0aG91dFR3b1RvcExpbmVzID1cbiAgICAgICAgICAgICAgc2Vjb25kTmV3bGluZUluZGV4ID09PSAtMSA/ICcnIDogc3RhY2suc2xpY2Uoc2Vjb25kTmV3bGluZUluZGV4ICsgMSk7XG5cbiAgICAgICAgICAgIGlmICghU3RyaW5nKGVyci5zdGFjaykuZW5kc1dpdGgoc3RhY2tXaXRob3V0VHdvVG9wTGluZXMpKSB7XG4gICAgICAgICAgICAgIGVyci5zdGFjayArPSAnXFxuJyArIHN0YWNrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIC8vIElnbm9yZSBmYWlsdXJlcyBmcm9tIGN1c3RvbSBzdGFjayBob29rcyBvciB1bi13cml0YWJsZSBzdGFjayBwcm9wZXJ0aWVzLlxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICBfcmVxdWVzdChjb25maWdPclVybCwgY29uZmlnKSB7XG4gICAgLyplc2xpbnQgbm8tcGFyYW0tcmVhc3NpZ246MCovXG4gICAgLy8gQWxsb3cgZm9yIGF4aW9zKCdleGFtcGxlL3VybCdbLCBjb25maWddKSBhIGxhIGZldGNoIEFQSVxuICAgIGlmICh0eXBlb2YgY29uZmlnT3JVcmwgPT09ICdzdHJpbmcnKSB7XG4gICAgICBjb25maWcgPSBjb25maWcgfHwge307XG4gICAgICBjb25maWcudXJsID0gY29uZmlnT3JVcmw7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbmZpZyA9IGNvbmZpZ09yVXJsIHx8IHt9O1xuICAgIH1cblxuICAgIGNvbmZpZyA9IG1lcmdlQ29uZmlnKHRoaXMuZGVmYXVsdHMsIGNvbmZpZyk7XG5cbiAgICBjb25zdCB7IHRyYW5zaXRpb25hbCwgcGFyYW1zU2VyaWFsaXplciwgaGVhZGVycyB9ID0gY29uZmlnO1xuXG4gICAgaWYgKHRyYW5zaXRpb25hbCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICB2YWxpZGF0b3IuYXNzZXJ0T3B0aW9ucyhcbiAgICAgICAgdHJhbnNpdGlvbmFsLFxuICAgICAgICB7XG4gICAgICAgICAgc2lsZW50SlNPTlBhcnNpbmc6IHZhbGlkYXRvcnMudHJhbnNpdGlvbmFsKHZhbGlkYXRvcnMuYm9vbGVhbiksXG4gICAgICAgICAgZm9yY2VkSlNPTlBhcnNpbmc6IHZhbGlkYXRvcnMudHJhbnNpdGlvbmFsKHZhbGlkYXRvcnMuYm9vbGVhbiksXG4gICAgICAgICAgY2xhcmlmeVRpbWVvdXRFcnJvcjogdmFsaWRhdG9ycy50cmFuc2l0aW9uYWwodmFsaWRhdG9ycy5ib29sZWFuKSxcbiAgICAgICAgICBsZWdhY3lJbnRlcmNlcHRvclJlcVJlc09yZGVyaW5nOiB2YWxpZGF0b3JzLnRyYW5zaXRpb25hbCh2YWxpZGF0b3JzLmJvb2xlYW4pLFxuICAgICAgICAgIGFkdmVydGlzZVpzdGRBY2NlcHRFbmNvZGluZzogdmFsaWRhdG9ycy50cmFuc2l0aW9uYWwodmFsaWRhdG9ycy5ib29sZWFuKSxcbiAgICAgICAgICB2YWxpZGF0ZVN0YXR1c1VuZGVmaW5lZFJlc29sdmVzOiB2YWxpZGF0b3JzLnRyYW5zaXRpb25hbCh2YWxpZGF0b3JzLmJvb2xlYW4pLFxuICAgICAgICB9LFxuICAgICAgICBmYWxzZVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBpZiAocGFyYW1zU2VyaWFsaXplciAhPSBudWxsKSB7XG4gICAgICBpZiAodXRpbHMuaXNGdW5jdGlvbihwYXJhbXNTZXJpYWxpemVyKSkge1xuICAgICAgICBjb25maWcucGFyYW1zU2VyaWFsaXplciA9IHtcbiAgICAgICAgICBzZXJpYWxpemU6IHBhcmFtc1NlcmlhbGl6ZXIsXG4gICAgICAgIH07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB2YWxpZGF0b3IuYXNzZXJ0T3B0aW9ucyhcbiAgICAgICAgICBwYXJhbXNTZXJpYWxpemVyLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGVuY29kZTogdmFsaWRhdG9ycy5mdW5jdGlvbixcbiAgICAgICAgICAgIHNlcmlhbGl6ZTogdmFsaWRhdG9ycy5mdW5jdGlvbixcbiAgICAgICAgICB9LFxuICAgICAgICAgIHRydWVcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBTZXQgY29uZmlnLmFsbG93QWJzb2x1dGVVcmxzXG4gICAgaWYgKGNvbmZpZy5hbGxvd0Fic29sdXRlVXJscyAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAvLyBkbyBub3RoaW5nXG4gICAgfSBlbHNlIGlmICh0aGlzLmRlZmF1bHRzLmFsbG93QWJzb2x1dGVVcmxzICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIGNvbmZpZy5hbGxvd0Fic29sdXRlVXJscyA9IHRoaXMuZGVmYXVsdHMuYWxsb3dBYnNvbHV0ZVVybHM7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbmZpZy5hbGxvd0Fic29sdXRlVXJscyA9IHRydWU7XG4gICAgfVxuXG4gICAgdmFsaWRhdG9yLmFzc2VydE9wdGlvbnMoXG4gICAgICBjb25maWcsXG4gICAgICB7XG4gICAgICAgIGJhc2VVcmw6IHZhbGlkYXRvcnMuc3BlbGxpbmcoJ2Jhc2VVUkwnKSxcbiAgICAgICAgd2l0aFhzcmZUb2tlbjogdmFsaWRhdG9ycy5zcGVsbGluZygnd2l0aFhTUkZUb2tlbicpLFxuICAgICAgfSxcbiAgICAgIHRydWVcbiAgICApO1xuXG4gICAgLy8gU2V0IGNvbmZpZy5tZXRob2RcbiAgICBjb25maWcubWV0aG9kID0gKFxuICAgICAgdXRpbHMuZ2V0U2FmZVByb3AoY29uZmlnLCAnbWV0aG9kJykgfHxcbiAgICAgIHV0aWxzLmdldFNhZmVQcm9wKHRoaXMuZGVmYXVsdHMsICdtZXRob2QnKSB8fFxuICAgICAgJ2dldCdcbiAgICApLnRvTG93ZXJDYXNlKCk7XG5cbiAgICAvLyBGbGF0dGVuIGhlYWRlcnNcbiAgICBsZXQgY29udGV4dEhlYWRlcnMgPSBoZWFkZXJzICYmIHV0aWxzLm1lcmdlKGhlYWRlcnMuY29tbW9uLCBoZWFkZXJzW2NvbmZpZy5tZXRob2RdKTtcblxuICAgIGhlYWRlcnMgJiZcbiAgICAgIHV0aWxzLmZvckVhY2gobWV0aG9kTGlzdC5jb25jYXQoJ2NvbW1vbicpLCAobWV0aG9kKSA9PiB7XG4gICAgICAgIGRlbGV0ZSBoZWFkZXJzW21ldGhvZF07XG4gICAgICB9KTtcblxuICAgIGNvbmZpZy5oZWFkZXJzID0gQXhpb3NIZWFkZXJzLmNvbmNhdChjb250ZXh0SGVhZGVycywgaGVhZGVycyk7XG5cbiAgICAvLyBmaWx0ZXIgb3V0IHNraXBwZWQgaW50ZXJjZXB0b3JzXG4gICAgY29uc3QgcmVxdWVzdEludGVyY2VwdG9yQ2hhaW4gPSBbXTtcbiAgICBsZXQgc3luY2hyb25vdXNSZXF1ZXN0SW50ZXJjZXB0b3JzID0gdHJ1ZTtcbiAgICB0aGlzLmludGVyY2VwdG9ycy5yZXF1ZXN0LmZvckVhY2goZnVuY3Rpb24gdW5zaGlmdFJlcXVlc3RJbnRlcmNlcHRvcnMoaW50ZXJjZXB0b3IpIHtcbiAgICAgIGlmICh0eXBlb2YgaW50ZXJjZXB0b3IucnVuV2hlbiA9PT0gJ2Z1bmN0aW9uJyAmJiBpbnRlcmNlcHRvci5ydW5XaGVuKGNvbmZpZykgPT09IGZhbHNlKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgc3luY2hyb25vdXNSZXF1ZXN0SW50ZXJjZXB0b3JzID0gc3luY2hyb25vdXNSZXF1ZXN0SW50ZXJjZXB0b3JzICYmIGludGVyY2VwdG9yLnN5bmNocm9ub3VzO1xuXG4gICAgICBjb25zdCB0cmFuc2l0aW9uYWwgPSBjb25maWcudHJhbnNpdGlvbmFsIHx8IHRyYW5zaXRpb25hbERlZmF1bHRzO1xuICAgICAgY29uc3QgbGVnYWN5SW50ZXJjZXB0b3JSZXFSZXNPcmRlcmluZyA9XG4gICAgICAgIHRyYW5zaXRpb25hbCAmJiB0cmFuc2l0aW9uYWwubGVnYWN5SW50ZXJjZXB0b3JSZXFSZXNPcmRlcmluZztcblxuICAgICAgaWYgKGxlZ2FjeUludGVyY2VwdG9yUmVxUmVzT3JkZXJpbmcpIHtcbiAgICAgICAgcmVxdWVzdEludGVyY2VwdG9yQ2hhaW4udW5zaGlmdChpbnRlcmNlcHRvci5mdWxmaWxsZWQsIGludGVyY2VwdG9yLnJlamVjdGVkKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlcXVlc3RJbnRlcmNlcHRvckNoYWluLnB1c2goaW50ZXJjZXB0b3IuZnVsZmlsbGVkLCBpbnRlcmNlcHRvci5yZWplY3RlZCk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBjb25zdCByZXNwb25zZUludGVyY2VwdG9yQ2hhaW4gPSBbXTtcbiAgICB0aGlzLmludGVyY2VwdG9ycy5yZXNwb25zZS5mb3JFYWNoKGZ1bmN0aW9uIHB1c2hSZXNwb25zZUludGVyY2VwdG9ycyhpbnRlcmNlcHRvcikge1xuICAgICAgcmVzcG9uc2VJbnRlcmNlcHRvckNoYWluLnB1c2goaW50ZXJjZXB0b3IuZnVsZmlsbGVkLCBpbnRlcmNlcHRvci5yZWplY3RlZCk7XG4gICAgfSk7XG5cbiAgICBsZXQgcHJvbWlzZTtcbiAgICBsZXQgaSA9IDA7XG4gICAgbGV0IGxlbjtcblxuICAgIGlmICghc3luY2hyb25vdXNSZXF1ZXN0SW50ZXJjZXB0b3JzKSB7XG4gICAgICBjb25zdCBjaGFpbiA9IFtkaXNwYXRjaFJlcXVlc3QuYmluZCh0aGlzKSwgdW5kZWZpbmVkXTtcbiAgICAgIGNoYWluLnVuc2hpZnQoLi4ucmVxdWVzdEludGVyY2VwdG9yQ2hhaW4pO1xuICAgICAgY2hhaW4ucHVzaCguLi5yZXNwb25zZUludGVyY2VwdG9yQ2hhaW4pO1xuICAgICAgbGVuID0gY2hhaW4ubGVuZ3RoO1xuXG4gICAgICBwcm9taXNlID0gUHJvbWlzZS5yZXNvbHZlKGNvbmZpZyk7XG5cbiAgICAgIHdoaWxlIChpIDwgbGVuKSB7XG4gICAgICAgIHByb21pc2UgPSBwcm9taXNlLnRoZW4oY2hhaW5baSsrXSwgY2hhaW5baSsrXSk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBwcm9taXNlO1xuICAgIH1cblxuICAgIGxlbiA9IHJlcXVlc3RJbnRlcmNlcHRvckNoYWluLmxlbmd0aDtcblxuICAgIGxldCBuZXdDb25maWcgPSBjb25maWc7XG5cbiAgICB3aGlsZSAoaSA8IGxlbikge1xuICAgICAgY29uc3Qgb25GdWxmaWxsZWQgPSByZXF1ZXN0SW50ZXJjZXB0b3JDaGFpbltpKytdO1xuICAgICAgY29uc3Qgb25SZWplY3RlZCA9IHJlcXVlc3RJbnRlcmNlcHRvckNoYWluW2krK107XG4gICAgICB0cnkge1xuICAgICAgICBuZXdDb25maWcgPSBvbkZ1bGZpbGxlZCA/IG9uRnVsZmlsbGVkKG5ld0NvbmZpZykgOiBuZXdDb25maWc7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBpZiAoIW9uUmVqZWN0ZWQpIHtcbiAgICAgICAgICBwcm9taXNlID0gUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCByZWplY3RlZFJlc3VsdCA9IG9uUmVqZWN0ZWQuY2FsbCh0aGlzLCBlcnJvcik7XG5cbiAgICAgICAgICBpZiAodXRpbHMuaXNUaGVuYWJsZShyZWplY3RlZFJlc3VsdCkpIHtcbiAgICAgICAgICAgIHByb21pc2UgPSBQcm9taXNlLnJlc29sdmUocmVqZWN0ZWRSZXN1bHQpLnRoZW4oKCkgPT5cbiAgICAgICAgICAgICAgZGlzcGF0Y2hSZXF1ZXN0LmNhbGwodGhpcywgbmV3Q29uZmlnKVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKHJlamVjdGVkRXJyb3IpIHtcbiAgICAgICAgICBwcm9taXNlID0gUHJvbWlzZS5yZWplY3QocmVqZWN0ZWRFcnJvcik7XG4gICAgICAgIH1cblxuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoIXByb21pc2UpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHByb21pc2UgPSBkaXNwYXRjaFJlcXVlc3QuY2FsbCh0aGlzLCBuZXdDb25maWcpO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgcHJvbWlzZSA9IFByb21pc2UucmVqZWN0KGVycm9yKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpID0gMDtcbiAgICBsZW4gPSByZXNwb25zZUludGVyY2VwdG9yQ2hhaW4ubGVuZ3RoO1xuXG4gICAgd2hpbGUgKGkgPCBsZW4pIHtcbiAgICAgIHByb21pc2UgPSBwcm9taXNlLnRoZW4ocmVzcG9uc2VJbnRlcmNlcHRvckNoYWluW2krK10sIHJlc3BvbnNlSW50ZXJjZXB0b3JDaGFpbltpKytdKTtcbiAgICB9XG5cbiAgICByZXR1cm4gcHJvbWlzZTtcbiAgfVxuXG4gIGdldFVyaShjb25maWcpIHtcbiAgICBjb25maWcgPSBtZXJnZUNvbmZpZyh0aGlzLmRlZmF1bHRzLCBjb25maWcpO1xuICAgIGNvbnN0IGZ1bGxQYXRoID0gYnVpbGRGdWxsUGF0aChjb25maWcuYmFzZVVSTCwgY29uZmlnLnVybCwgY29uZmlnLmFsbG93QWJzb2x1dGVVcmxzLCBjb25maWcpO1xuICAgIHJldHVybiBidWlsZFVSTChmdWxsUGF0aCwgY29uZmlnLnBhcmFtcywgY29uZmlnLnBhcmFtc1NlcmlhbGl6ZXIpO1xuICB9XG59XG5cbi8vIFByb3ZpZGUgYWxpYXNlcyBmb3Igc3VwcG9ydGVkIHJlcXVlc3QgbWV0aG9kc1xudXRpbHMuZm9yRWFjaChbJ2RlbGV0ZScsICdnZXQnLCAnaGVhZCcsICdvcHRpb25zJ10sIGZ1bmN0aW9uIGZvckVhY2hNZXRob2ROb0RhdGEobWV0aG9kKSB7XG4gIC8qZXNsaW50IGZ1bmMtbmFtZXM6MCovXG4gIEF4aW9zLnByb3RvdHlwZVttZXRob2RdID0gZnVuY3Rpb24gKHVybCwgY29uZmlnKSB7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdChcbiAgICAgIG1lcmdlQ29uZmlnKGNvbmZpZyB8fCB7fSwge1xuICAgICAgICBtZXRob2QsXG4gICAgICAgIHVybCxcbiAgICAgICAgZGF0YTogY29uZmlnICYmIHV0aWxzLmhhc093blByb3AoY29uZmlnLCAnZGF0YScpID8gY29uZmlnLmRhdGEgOiB1bmRlZmluZWQsXG4gICAgICB9KVxuICAgICk7XG4gIH07XG59KTtcblxudXRpbHMuZm9yRWFjaChbJ3Bvc3QnLCAncHV0JywgJ3BhdGNoJywgJ3F1ZXJ5J10sIGZ1bmN0aW9uIGZvckVhY2hNZXRob2RXaXRoRGF0YShtZXRob2QpIHtcbiAgZnVuY3Rpb24gZ2VuZXJhdGVIVFRQTWV0aG9kKGlzRm9ybSkge1xuICAgIHJldHVybiBmdW5jdGlvbiBodHRwTWV0aG9kKHVybCwgZGF0YSwgY29uZmlnKSB7XG4gICAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KFxuICAgICAgICBtZXJnZUNvbmZpZyhjb25maWcgfHwge30sIHtcbiAgICAgICAgICBtZXRob2QsXG4gICAgICAgICAgaGVhZGVyczogaXNGb3JtXG4gICAgICAgICAgICA/IHtcbiAgICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ211bHRpcGFydC9mb3JtLWRhdGEnLFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA6IHt9LFxuICAgICAgICAgIHVybCxcbiAgICAgICAgICBkYXRhLFxuICAgICAgICB9KVxuICAgICAgKTtcbiAgICB9O1xuICB9XG5cbiAgQXhpb3MucHJvdG90eXBlW21ldGhvZF0gPSBnZW5lcmF0ZUhUVFBNZXRob2QoKTtcblxuICAvLyBRVUVSWSBpcyBhIHNhZmUvaWRlbXBvdGVudCByZWFkIG1ldGhvZDsgbXVsdGlwYXJ0IGZvcm0gYm9kaWVzIGRvbid0IGZpdFxuICAvLyBpdHMgc2VtYW50aWNzLCBzbyBubyBxdWVyeUZvcm0gc2hvcnRoYW5kIGlzIGdlbmVyYXRlZC5cbiAgaWYgKG1ldGhvZCAhPT0gJ3F1ZXJ5Jykge1xuICAgIEF4aW9zLnByb3RvdHlwZVttZXRob2QgKyAnRm9ybSddID0gZ2VuZXJhdGVIVFRQTWV0aG9kKHRydWUpO1xuICB9XG59KTtcblxuZXhwb3J0IGRlZmF1bHQgQXhpb3M7XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCBDYW5jZWxlZEVycm9yIGZyb20gJy4vQ2FuY2VsZWRFcnJvci5qcyc7XG5cbi8qKlxuICogQSBgQ2FuY2VsVG9rZW5gIGlzIGFuIG9iamVjdCB0aGF0IGNhbiBiZSB1c2VkIHRvIHJlcXVlc3QgY2FuY2VsbGF0aW9uIG9mIGFuIG9wZXJhdGlvbi5cbiAqXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBleGVjdXRvciBUaGUgZXhlY3V0b3IgZnVuY3Rpb24uXG4gKlxuICogQHJldHVybnMge0NhbmNlbFRva2VufVxuICovXG5jbGFzcyBDYW5jZWxUb2tlbiB7XG4gIGNvbnN0cnVjdG9yKGV4ZWN1dG9yKSB7XG4gICAgaWYgKHR5cGVvZiBleGVjdXRvciAhPT0gJ2Z1bmN0aW9uJykge1xuICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignZXhlY3V0b3IgbXVzdCBiZSBhIGZ1bmN0aW9uLicpO1xuICAgIH1cblxuICAgIGxldCByZXNvbHZlUHJvbWlzZTtcblxuICAgIHRoaXMucHJvbWlzZSA9IG5ldyBQcm9taXNlKGZ1bmN0aW9uIHByb21pc2VFeGVjdXRvcihyZXNvbHZlKSB7XG4gICAgICByZXNvbHZlUHJvbWlzZSA9IHJlc29sdmU7XG4gICAgfSk7XG5cbiAgICBjb25zdCB0b2tlbiA9IHRoaXM7XG5cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZnVuYy1uYW1lc1xuICAgIHRoaXMucHJvbWlzZS50aGVuKChjYW5jZWwpID0+IHtcbiAgICAgIGlmICghdG9rZW4uX2xpc3RlbmVycykgcmV0dXJuO1xuXG4gICAgICBsZXQgaSA9IHRva2VuLl9saXN0ZW5lcnMubGVuZ3RoO1xuXG4gICAgICB3aGlsZSAoaS0tID4gMCkge1xuICAgICAgICB0b2tlbi5fbGlzdGVuZXJzW2ldKGNhbmNlbCk7XG4gICAgICB9XG4gICAgICB0b2tlbi5fbGlzdGVuZXJzID0gbnVsbDtcbiAgICB9KTtcblxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBmdW5jLW5hbWVzXG4gICAgdGhpcy5wcm9taXNlLnRoZW4gPSAob25mdWxmaWxsZWQpID0+IHtcbiAgICAgIGxldCBfcmVzb2x2ZTtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBmdW5jLW5hbWVzXG4gICAgICBjb25zdCBwcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgICAgdG9rZW4uc3Vic2NyaWJlKHJlc29sdmUpO1xuICAgICAgICBfcmVzb2x2ZSA9IHJlc29sdmU7XG4gICAgICB9KS50aGVuKG9uZnVsZmlsbGVkKTtcblxuICAgICAgcHJvbWlzZS5jYW5jZWwgPSBmdW5jdGlvbiByZWplY3QoKSB7XG4gICAgICAgIHRva2VuLnVuc3Vic2NyaWJlKF9yZXNvbHZlKTtcbiAgICAgIH07XG5cbiAgICAgIHJldHVybiBwcm9taXNlO1xuICAgIH07XG5cbiAgICBleGVjdXRvcihmdW5jdGlvbiBjYW5jZWwobWVzc2FnZSwgY29uZmlnLCByZXF1ZXN0KSB7XG4gICAgICBpZiAodG9rZW4ucmVhc29uKSB7XG4gICAgICAgIC8vIENhbmNlbGxhdGlvbiBoYXMgYWxyZWFkeSBiZWVuIHJlcXVlc3RlZFxuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIHRva2VuLnJlYXNvbiA9IG5ldyBDYW5jZWxlZEVycm9yKG1lc3NhZ2UsIGNvbmZpZywgcmVxdWVzdCk7XG4gICAgICByZXNvbHZlUHJvbWlzZSh0b2tlbi5yZWFzb24pO1xuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFRocm93cyBhIGBDYW5jZWxlZEVycm9yYCBpZiBjYW5jZWxsYXRpb24gaGFzIGJlZW4gcmVxdWVzdGVkLlxuICAgKi9cbiAgdGhyb3dJZlJlcXVlc3RlZCgpIHtcbiAgICBpZiAodGhpcy5yZWFzb24pIHtcbiAgICAgIHRocm93IHRoaXMucmVhc29uO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBTdWJzY3JpYmUgdG8gdGhlIGNhbmNlbCBzaWduYWxcbiAgICovXG5cbiAgc3Vic2NyaWJlKGxpc3RlbmVyKSB7XG4gICAgaWYgKHRoaXMucmVhc29uKSB7XG4gICAgICBsaXN0ZW5lcih0aGlzLnJlYXNvbik7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuX2xpc3RlbmVycykge1xuICAgICAgdGhpcy5fbGlzdGVuZXJzLnB1c2gobGlzdGVuZXIpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLl9saXN0ZW5lcnMgPSBbbGlzdGVuZXJdO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBVbnN1YnNjcmliZSBmcm9tIHRoZSBjYW5jZWwgc2lnbmFsXG4gICAqL1xuXG4gIHVuc3Vic2NyaWJlKGxpc3RlbmVyKSB7XG4gICAgaWYgKCF0aGlzLl9saXN0ZW5lcnMpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgaW5kZXggPSB0aGlzLl9saXN0ZW5lcnMuaW5kZXhPZihsaXN0ZW5lcik7XG4gICAgaWYgKGluZGV4ICE9PSAtMSkge1xuICAgICAgdGhpcy5fbGlzdGVuZXJzLnNwbGljZShpbmRleCwgMSk7XG4gICAgfVxuICB9XG5cbiAgdG9BYm9ydFNpZ25hbCgpIHtcbiAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuXG4gICAgY29uc3QgYWJvcnQgPSAoZXJyKSA9PiB7XG4gICAgICBjb250cm9sbGVyLmFib3J0KGVycik7XG4gICAgfTtcblxuICAgIHRoaXMuc3Vic2NyaWJlKGFib3J0KTtcblxuICAgIGNvbnRyb2xsZXIuc2lnbmFsLnVuc3Vic2NyaWJlID0gKCkgPT4gdGhpcy51bnN1YnNjcmliZShhYm9ydCk7XG5cbiAgICByZXR1cm4gY29udHJvbGxlci5zaWduYWw7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBhbiBvYmplY3QgdGhhdCBjb250YWlucyBhIG5ldyBgQ2FuY2VsVG9rZW5gIGFuZCBhIGZ1bmN0aW9uIHRoYXQsIHdoZW4gY2FsbGVkLFxuICAgKiBjYW5jZWxzIHRoZSBgQ2FuY2VsVG9rZW5gLlxuICAgKi9cbiAgc3RhdGljIHNvdXJjZSgpIHtcbiAgICBsZXQgY2FuY2VsO1xuICAgIGNvbnN0IHRva2VuID0gbmV3IENhbmNlbFRva2VuKGZ1bmN0aW9uIGV4ZWN1dG9yKGMpIHtcbiAgICAgIGNhbmNlbCA9IGM7XG4gICAgfSk7XG4gICAgcmV0dXJuIHtcbiAgICAgIHRva2VuLFxuICAgICAgY2FuY2VsLFxuICAgIH07XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgQ2FuY2VsVG9rZW47XG4iLCIndXNlIHN0cmljdCc7XG5cbi8qKlxuICogU3ludGFjdGljIHN1Z2FyIGZvciBpbnZva2luZyBhIGZ1bmN0aW9uIGFuZCBleHBhbmRpbmcgYW4gYXJyYXkgZm9yIGFyZ3VtZW50cy5cbiAqXG4gKiBDb21tb24gdXNlIGNhc2Ugd291bGQgYmUgdG8gdXNlIGBGdW5jdGlvbi5wcm90b3R5cGUuYXBwbHlgLlxuICpcbiAqICBgYGBqc1xuICogIGZ1bmN0aW9uIGYoeCwgeSwgeikge31cbiAqICBjb25zdCBhcmdzID0gWzEsIDIsIDNdO1xuICogIGYuYXBwbHkobnVsbCwgYXJncyk7XG4gKiAgYGBgXG4gKlxuICogV2l0aCBgc3ByZWFkYCB0aGlzIGV4YW1wbGUgY2FuIGJlIHJlLXdyaXR0ZW4uXG4gKlxuICogIGBgYGpzXG4gKiAgc3ByZWFkKGZ1bmN0aW9uKHgsIHksIHopIHt9KShbMSwgMiwgM10pO1xuICogIGBgYFxuICpcbiAqIEBwYXJhbSB7RnVuY3Rpb259IGNhbGxiYWNrXG4gKlxuICogQHJldHVybnMge0Z1bmN0aW9ufVxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBzcHJlYWQoY2FsbGJhY2spIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIHdyYXAoYXJyKSB7XG4gICAgcmV0dXJuIGNhbGxiYWNrLmFwcGx5KG51bGwsIGFycik7XG4gIH07XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5cbi8qKlxuICogRGV0ZXJtaW5lcyB3aGV0aGVyIHRoZSBwYXlsb2FkIGlzIGFuIGVycm9yIHRocm93biBieSBBeGlvc1xuICpcbiAqIEBwYXJhbSB7Kn0gcGF5bG9hZCBUaGUgdmFsdWUgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHRoZSBwYXlsb2FkIGlzIGFuIGVycm9yIHRocm93biBieSBBeGlvcywgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGlzQXhpb3NFcnJvcihwYXlsb2FkKSB7XG4gIHJldHVybiB1dGlscy5pc09iamVjdChwYXlsb2FkKSAmJiBwYXlsb2FkLmlzQXhpb3NFcnJvciA9PT0gdHJ1ZTtcbn1cbiIsImNvbnN0IEh0dHBTdGF0dXNDb2RlID0ge1xuICBDb250aW51ZTogMTAwLFxuICBTd2l0Y2hpbmdQcm90b2NvbHM6IDEwMSxcbiAgUHJvY2Vzc2luZzogMTAyLFxuICBFYXJseUhpbnRzOiAxMDMsXG4gIE9rOiAyMDAsXG4gIENyZWF0ZWQ6IDIwMSxcbiAgQWNjZXB0ZWQ6IDIwMixcbiAgTm9uQXV0aG9yaXRhdGl2ZUluZm9ybWF0aW9uOiAyMDMsXG4gIE5vQ29udGVudDogMjA0LFxuICBSZXNldENvbnRlbnQ6IDIwNSxcbiAgUGFydGlhbENvbnRlbnQ6IDIwNixcbiAgTXVsdGlTdGF0dXM6IDIwNyxcbiAgQWxyZWFkeVJlcG9ydGVkOiAyMDgsXG4gIEltVXNlZDogMjI2LFxuICBNdWx0aXBsZUNob2ljZXM6IDMwMCxcbiAgTW92ZWRQZXJtYW5lbnRseTogMzAxLFxuICBGb3VuZDogMzAyLFxuICBTZWVPdGhlcjogMzAzLFxuICBOb3RNb2RpZmllZDogMzA0LFxuICBVc2VQcm94eTogMzA1LFxuICBVbnVzZWQ6IDMwNixcbiAgVGVtcG9yYXJ5UmVkaXJlY3Q6IDMwNyxcbiAgUGVybWFuZW50UmVkaXJlY3Q6IDMwOCxcbiAgQmFkUmVxdWVzdDogNDAwLFxuICBVbmF1dGhvcml6ZWQ6IDQwMSxcbiAgUGF5bWVudFJlcXVpcmVkOiA0MDIsXG4gIEZvcmJpZGRlbjogNDAzLFxuICBOb3RGb3VuZDogNDA0LFxuICBNZXRob2ROb3RBbGxvd2VkOiA0MDUsXG4gIE5vdEFjY2VwdGFibGU6IDQwNixcbiAgUHJveHlBdXRoZW50aWNhdGlvblJlcXVpcmVkOiA0MDcsXG4gIFJlcXVlc3RUaW1lb3V0OiA0MDgsXG4gIENvbmZsaWN0OiA0MDksXG4gIEdvbmU6IDQxMCxcbiAgTGVuZ3RoUmVxdWlyZWQ6IDQxMSxcbiAgUHJlY29uZGl0aW9uRmFpbGVkOiA0MTIsXG4gIC8qKlxuICAgKiBAZGVwcmVjYXRlZCBVc2UgYENvbnRlbnRUb29MYXJnZWAgaW5zdGVhZC5cbiAgICovXG4gIFBheWxvYWRUb29MYXJnZTogNDEzLFxuICBDb250ZW50VG9vTGFyZ2U6IDQxMyxcbiAgVXJpVG9vTG9uZzogNDE0LFxuICBVbnN1cHBvcnRlZE1lZGlhVHlwZTogNDE1LFxuICBSYW5nZU5vdFNhdGlzZmlhYmxlOiA0MTYsXG4gIEV4cGVjdGF0aW9uRmFpbGVkOiA0MTcsXG4gIEltQVRlYXBvdDogNDE4LFxuICBNaXNkaXJlY3RlZFJlcXVlc3Q6IDQyMSxcbiAgLyoqXG4gICAqIEBkZXByZWNhdGVkIFVzZSBgVW5wcm9jZXNzYWJsZUNvbnRlbnRgIGluc3RlYWQuXG4gICAqL1xuICBVbnByb2Nlc3NhYmxlRW50aXR5OiA0MjIsXG4gIFVucHJvY2Vzc2FibGVDb250ZW50OiA0MjIsXG4gIExvY2tlZDogNDIzLFxuICBGYWlsZWREZXBlbmRlbmN5OiA0MjQsXG4gIFRvb0Vhcmx5OiA0MjUsXG4gIFVwZ3JhZGVSZXF1aXJlZDogNDI2LFxuICBQcmVjb25kaXRpb25SZXF1aXJlZDogNDI4LFxuICBUb29NYW55UmVxdWVzdHM6IDQyOSxcbiAgUmVxdWVzdEhlYWRlckZpZWxkc1Rvb0xhcmdlOiA0MzEsXG4gIFVuYXZhaWxhYmxlRm9yTGVnYWxSZWFzb25zOiA0NTEsXG4gIEludGVybmFsU2VydmVyRXJyb3I6IDUwMCxcbiAgTm90SW1wbGVtZW50ZWQ6IDUwMSxcbiAgQmFkR2F0ZXdheTogNTAyLFxuICBTZXJ2aWNlVW5hdmFpbGFibGU6IDUwMyxcbiAgR2F0ZXdheVRpbWVvdXQ6IDUwNCxcbiAgSHR0cFZlcnNpb25Ob3RTdXBwb3J0ZWQ6IDUwNSxcbiAgVmFyaWFudEFsc29OZWdvdGlhdGVzOiA1MDYsXG4gIEluc3VmZmljaWVudFN0b3JhZ2U6IDUwNyxcbiAgTG9vcERldGVjdGVkOiA1MDgsXG4gIE5vdEV4dGVuZGVkOiA1MTAsXG4gIE5ldHdvcmtBdXRoZW50aWNhdGlvblJlcXVpcmVkOiA1MTEsXG4gIFdlYlNlcnZlclJldHVybnNBblVua25vd25FcnJvcjogNTIwLFxuICBXZWJTZXJ2ZXJJc0Rvd246IDUyMSxcbiAgQ29ubmVjdGlvblRpbWVkT3V0OiA1MjIsXG4gIE9yaWdpbklzVW5yZWFjaGFibGU6IDUyMyxcbiAgVGltZW91dE9jY3VycmVkOiA1MjQsXG4gIFNzbEhhbmRzaGFrZUZhaWxlZDogNTI1LFxuICBJbnZhbGlkU3NsQ2VydGlmaWNhdGU6IDUyNixcbn07XG5cbk9iamVjdC5lbnRyaWVzKEh0dHBTdGF0dXNDb2RlKS5mb3JFYWNoKChba2V5LCB2YWx1ZV0pID0+IHtcbiAgaWYgKEh0dHBTdGF0dXNDb2RlW3ZhbHVlXSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgSHR0cFN0YXR1c0NvZGVbdmFsdWVdID0ga2V5O1xuICB9XG59KTtcblxuZXhwb3J0IGRlZmF1bHQgSHR0cFN0YXR1c0NvZGU7XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuL3V0aWxzLmpzJztcbmltcG9ydCBiaW5kIGZyb20gJy4vaGVscGVycy9iaW5kLmpzJztcbmltcG9ydCBBeGlvcyBmcm9tICcuL2NvcmUvQXhpb3MuanMnO1xuaW1wb3J0IG1lcmdlQ29uZmlnIGZyb20gJy4vY29yZS9tZXJnZUNvbmZpZy5qcyc7XG5pbXBvcnQgZGVmYXVsdHMgZnJvbSAnLi9kZWZhdWx0cy9pbmRleC5qcyc7XG5pbXBvcnQgZm9ybURhdGFUb0pTT04gZnJvbSAnLi9oZWxwZXJzL2Zvcm1EYXRhVG9KU09OLmpzJztcbmltcG9ydCBDYW5jZWxlZEVycm9yIGZyb20gJy4vY2FuY2VsL0NhbmNlbGVkRXJyb3IuanMnO1xuaW1wb3J0IENhbmNlbFRva2VuIGZyb20gJy4vY2FuY2VsL0NhbmNlbFRva2VuLmpzJztcbmltcG9ydCBpc0NhbmNlbCBmcm9tICcuL2NhbmNlbC9pc0NhbmNlbC5qcyc7XG5pbXBvcnQgeyBWRVJTSU9OIH0gZnJvbSAnLi9lbnYvZGF0YS5qcyc7XG5pbXBvcnQgdG9Gb3JtRGF0YSBmcm9tICcuL2hlbHBlcnMvdG9Gb3JtRGF0YS5qcyc7XG5pbXBvcnQgQXhpb3NFcnJvciBmcm9tICcuL2NvcmUvQXhpb3NFcnJvci5qcyc7XG5pbXBvcnQgc3ByZWFkIGZyb20gJy4vaGVscGVycy9zcHJlYWQuanMnO1xuaW1wb3J0IGlzQXhpb3NFcnJvciBmcm9tICcuL2hlbHBlcnMvaXNBeGlvc0Vycm9yLmpzJztcbmltcG9ydCBBeGlvc0hlYWRlcnMgZnJvbSAnLi9jb3JlL0F4aW9zSGVhZGVycy5qcyc7XG5pbXBvcnQgYWRhcHRlcnMgZnJvbSAnLi9hZGFwdGVycy9hZGFwdGVycy5qcyc7XG5pbXBvcnQgSHR0cFN0YXR1c0NvZGUgZnJvbSAnLi9oZWxwZXJzL0h0dHBTdGF0dXNDb2RlLmpzJztcblxuLyoqXG4gKiBDcmVhdGUgYW4gaW5zdGFuY2Ugb2YgQXhpb3NcbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gZGVmYXVsdENvbmZpZyBUaGUgZGVmYXVsdCBjb25maWcgZm9yIHRoZSBpbnN0YW5jZVxuICpcbiAqIEByZXR1cm5zIHtBeGlvc30gQSBuZXcgaW5zdGFuY2Ugb2YgQXhpb3NcbiAqL1xuZnVuY3Rpb24gY3JlYXRlSW5zdGFuY2UoZGVmYXVsdENvbmZpZykge1xuICBjb25zdCBjb250ZXh0ID0gbmV3IEF4aW9zKGRlZmF1bHRDb25maWcpO1xuICBjb25zdCBpbnN0YW5jZSA9IGJpbmQoQXhpb3MucHJvdG90eXBlLnJlcXVlc3QsIGNvbnRleHQpO1xuXG4gIC8vIENvcHkgYXhpb3MucHJvdG90eXBlIHRvIGluc3RhbmNlXG4gIHV0aWxzLmV4dGVuZChpbnN0YW5jZSwgQXhpb3MucHJvdG90eXBlLCBjb250ZXh0LCB7IGFsbE93bktleXM6IHRydWUgfSk7XG5cbiAgLy8gQ29weSBjb250ZXh0IHRvIGluc3RhbmNlXG4gIHV0aWxzLmV4dGVuZChpbnN0YW5jZSwgY29udGV4dCwgbnVsbCwgeyBhbGxPd25LZXlzOiB0cnVlIH0pO1xuXG4gIC8vIEZhY3RvcnkgZm9yIGNyZWF0aW5nIG5ldyBpbnN0YW5jZXNcbiAgaW5zdGFuY2UuY3JlYXRlID0gZnVuY3Rpb24gY3JlYXRlKGluc3RhbmNlQ29uZmlnKSB7XG4gICAgcmV0dXJuIGNyZWF0ZUluc3RhbmNlKG1lcmdlQ29uZmlnKGRlZmF1bHRDb25maWcsIGluc3RhbmNlQ29uZmlnKSk7XG4gIH07XG5cbiAgcmV0dXJuIGluc3RhbmNlO1xufVxuXG4vLyBDcmVhdGUgdGhlIGRlZmF1bHQgaW5zdGFuY2UgdG8gYmUgZXhwb3J0ZWRcbmNvbnN0IGF4aW9zID0gY3JlYXRlSW5zdGFuY2UoZGVmYXVsdHMpO1xuXG4vLyBFeHBvc2UgQXhpb3MgY2xhc3MgdG8gYWxsb3cgY2xhc3MgaW5oZXJpdGFuY2VcbmF4aW9zLkF4aW9zID0gQXhpb3M7XG5cbi8vIEV4cG9zZSBDYW5jZWwgJiBDYW5jZWxUb2tlblxuYXhpb3MuQ2FuY2VsZWRFcnJvciA9IENhbmNlbGVkRXJyb3I7XG5heGlvcy5DYW5jZWxUb2tlbiA9IENhbmNlbFRva2VuO1xuYXhpb3MuaXNDYW5jZWwgPSBpc0NhbmNlbDtcbmF4aW9zLlZFUlNJT04gPSBWRVJTSU9OO1xuYXhpb3MudG9Gb3JtRGF0YSA9IHRvRm9ybURhdGE7XG5cbi8vIEV4cG9zZSBBeGlvc0Vycm9yIGNsYXNzXG5heGlvcy5BeGlvc0Vycm9yID0gQXhpb3NFcnJvcjtcblxuLy8gYWxpYXMgZm9yIENhbmNlbGVkRXJyb3IgZm9yIGJhY2t3YXJkIGNvbXBhdGliaWxpdHlcbmF4aW9zLkNhbmNlbCA9IGF4aW9zLkNhbmNlbGVkRXJyb3I7XG5cbi8vIEV4cG9zZSBhbGwvc3ByZWFkXG5heGlvcy5hbGwgPSBmdW5jdGlvbiBhbGwocHJvbWlzZXMpIHtcbiAgcmV0dXJuIFByb21pc2UuYWxsKHByb21pc2VzKTtcbn07XG5cbmF4aW9zLnNwcmVhZCA9IHNwcmVhZDtcblxuLy8gRXhwb3NlIGlzQXhpb3NFcnJvclxuYXhpb3MuaXNBeGlvc0Vycm9yID0gaXNBeGlvc0Vycm9yO1xuXG4vLyBFeHBvc2UgbWVyZ2VDb25maWdcbmF4aW9zLm1lcmdlQ29uZmlnID0gbWVyZ2VDb25maWc7XG5cbmF4aW9zLkF4aW9zSGVhZGVycyA9IEF4aW9zSGVhZGVycztcblxuYXhpb3MuZm9ybVRvSlNPTiA9ICh0aGluZykgPT4gZm9ybURhdGFUb0pTT04odXRpbHMuaXNIVE1MRm9ybSh0aGluZykgPyBuZXcgRm9ybURhdGEodGhpbmcpIDogdGhpbmcpO1xuXG5heGlvcy5nZXRBZGFwdGVyID0gYWRhcHRlcnMuZ2V0QWRhcHRlcjtcblxuYXhpb3MuSHR0cFN0YXR1c0NvZGUgPSBIdHRwU3RhdHVzQ29kZTtcblxuYXhpb3MuZGVmYXVsdCA9IGF4aW9zO1xuXG4vLyB0aGlzIG1vZHVsZSBzaG91bGQgb25seSBoYXZlIGEgZGVmYXVsdCBleHBvcnRcbmV4cG9ydCBkZWZhdWx0IGF4aW9zO1xuIiwiaW1wb3J0IGF4aW9zIGZyb20gJy4vbGliL2F4aW9zLmpzJztcblxuLy8gVGhpcyBtb2R1bGUgaXMgaW50ZW5kZWQgdG8gdW53cmFwIEF4aW9zIGRlZmF1bHQgZXhwb3J0IGFzIG5hbWVkLlxuLy8gS2VlcCB0b3AtbGV2ZWwgZXhwb3J0IHNhbWUgd2l0aCBzdGF0aWMgcHJvcGVydGllc1xuLy8gc28gdGhhdCBpdCBjYW4ga2VlcCBzYW1lIHdpdGggZXMgbW9kdWxlIG9yIGNqc1xuY29uc3Qge1xuICBBeGlvcyxcbiAgQXhpb3NFcnJvcixcbiAgQ2FuY2VsZWRFcnJvcixcbiAgaXNDYW5jZWwsXG4gIENhbmNlbFRva2VuLFxuICBWRVJTSU9OLFxuICBhbGwsXG4gIENhbmNlbCxcbiAgaXNBeGlvc0Vycm9yLFxuICBzcHJlYWQsXG4gIHRvRm9ybURhdGEsXG4gIEF4aW9zSGVhZGVycyxcbiAgSHR0cFN0YXR1c0NvZGUsXG4gIGZvcm1Ub0pTT04sXG4gIGdldEFkYXB0ZXIsXG4gIG1lcmdlQ29uZmlnLFxuICBjcmVhdGUsXG59ID0gYXhpb3M7XG5cbmV4cG9ydCB7XG4gIGF4aW9zIGFzIGRlZmF1bHQsXG4gIGNyZWF0ZSxcbiAgQXhpb3MsXG4gIEF4aW9zRXJyb3IsXG4gIENhbmNlbGVkRXJyb3IsXG4gIGlzQ2FuY2VsLFxuICBDYW5jZWxUb2tlbixcbiAgVkVSU0lPTixcbiAgYWxsLFxuICBDYW5jZWwsXG4gIGlzQXhpb3NFcnJvcixcbiAgc3ByZWFkLFxuICB0b0Zvcm1EYXRhLFxuICBBeGlvc0hlYWRlcnMsXG4gIEh0dHBTdGF0dXNDb2RlLFxuICBmb3JtVG9KU09OLFxuICBnZXRBZGFwdGVyLFxuICBtZXJnZUNvbmZpZyxcbn07XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQVNBLFNBQXdCLEtBQUssSUFBSSxTQUFTO0NBQ3hDLE9BQU8sU0FBUyxPQUFPO0VBQ3JCLE9BQU8sR0FBRyxNQUFNLFNBQVMsU0FBUztDQUNwQztBQUNGOzs7QUNQQSxJQUFNLEVBQUUsYUFBYSxPQUFPO0FBQzVCLElBQU0sRUFBRSxtQkFBbUI7QUFDM0IsSUFBTSxFQUFFLFVBQVUsZ0JBQWdCO0FBR2xDLElBQU0sbUJBQ0gsRUFBRSxzQkFDRixLQUFLLFNBQ0osZUFBZSxLQUFLLEtBQUssSUFBSSxFQUFBLENBQy9CLE9BQU8sU0FBUztBQUVsQixJQUFNLHFCQUFxQixTQUN6QixPQUFPLFNBQVMsYUFDZixTQUFTLGVBQWUsU0FBUyxpQkFBaUIsU0FBUzs7Ozs7Ozs7Ozs7Ozs7O0FBZ0I5RCxJQUFNLHVCQUF1QixLQUFLLFdBQVcsV0FDM0MsUUFBUSxPQUFPLGFBQWMsQ0FBQyxVQUFVLGNBQWM7Ozs7Ozs7Ozs7O0FBWXhELElBQU0seUJBQXlCLFFBQVE7Q0FDckMsSUFBSSxDQUFDLE9BQU8sYUFBYSxHQUFHLEdBQzFCLE9BQU87Q0FHVCxNQUFNLFFBQVEsT0FBTyxvQkFBb0IsR0FBRztDQUU1QyxJQUFJLE9BQU8sdUJBQ1QsTUFBTSxLQUFLLEdBQUcsT0FBTyxzQkFBc0IsR0FBRyxDQUFDO0NBR2pELE9BQU8sTUFBTSxPQUFPLFNBQVM7RUFDM0IsSUFBSSxrQkFBa0IsSUFBSSxHQUN4QixPQUFPO0VBR1QsTUFBTSxhQUFhLE9BQU8seUJBQXlCLEtBQUssSUFBSTtFQUU1RCxPQUFPLENBQUMsQ0FBQyxjQUFjLFdBQVcsZ0JBQWdCLFdBQVcsYUFBYTtDQUM1RSxDQUFDO0FBQ0g7Ozs7Ozs7Ozs7Ozs7QUFjQSxJQUFNLDBCQUEwQixPQUFPLFNBQVM7Q0FDOUMsSUFBSSxNQUFNO0NBQ1YsTUFBTSxPQUFPLENBQUM7Q0FFZCxPQUFPLE9BQU8sTUFBTTtFQUNsQixJQUFJLEtBQUssUUFBUSxHQUFHLE1BQU0sSUFDeEIsT0FBTztFQUVULEtBQUssS0FBSyxHQUFHO0VBRWIsTUFBTSxZQUFZLGVBQWUsR0FBRztFQUVwQyxJQUFJLG9CQUFvQixLQUFLLFdBQVcsUUFBUSxLQUFLLEdBQ25ELE9BQU87RUFHVCxJQUFJLGVBQWUsS0FBSyxJQUFJLEdBQzFCLE9BQU87RUFFVCxNQUFNO0NBQ1I7Q0FDQSxPQUFPO0FBQ1Q7Ozs7Ozs7Ozs7OztBQWFBLElBQU0sZUFBZSxLQUFLLFNBQ3hCLE9BQU8sUUFBUSx1QkFBdUIsS0FBSyxJQUFJLElBQUksSUFBSSxRQUFRLEtBQUE7Ozs7Ozs7Ozs7OztBQWFqRSxJQUFNLG9CQUFvQixVQUFVO0NBQ2xDLElBQUksU0FBUyxRQUFTLE9BQU8sVUFBVSxZQUFZLE9BQU8sVUFBVSxZQUNsRSxPQUFPO0NBR1QsTUFBTSxrQkFBa0IsZUFBZSxLQUFLO0NBRTVDLElBQUksb0JBQW9CLFFBQVEsc0JBQXNCLEtBQUssR0FDekQsT0FBTztDQUdULE1BQU0sU0FBUyxPQUFPLE9BQU8sSUFBSTtDQUNqQyxNQUFNLFNBQVMsT0FBTyxPQUFPLElBQUk7Q0FDakMsTUFBTSxPQUFPLENBQUM7Q0FDZCxJQUFJLFVBQVU7Q0FFZCxPQUFPLFdBQVcsTUFBTTtFQUN0QixJQUFJLEtBQUssUUFBUSxPQUFPLE1BQU0sSUFDNUI7RUFHRixLQUFLLEtBQUssT0FBTztFQUVqQixNQUFNLFlBQVksWUFBWSxRQUFRLGtCQUFrQixlQUFlLE9BQU87RUFFOUUsSUFBSSxvQkFBb0IsU0FBUyxXQUFXLFlBQVksS0FBSyxHQUMzRDtFQUdGLE1BQU0sUUFBUSxPQUFPLG9CQUFvQixPQUFPO0VBRWhELElBQUksT0FBTyx1QkFDVCxNQUFNLEtBQUssR0FBRyxPQUFPLHNCQUFzQixPQUFPLENBQUM7RUFHckQsS0FBSyxNQUFNLFFBQVEsT0FBTztHQUN4QixJQUFJLGtCQUFrQixJQUFJLEdBQ3hCO0dBR0YsSUFBSSxDQUFDLGVBQWUsUUFBUSxJQUFJLEdBQUc7SUFDakMsT0FBTyxRQUFRLE1BQU07SUFDckIsT0FBTyxRQUFRO0dBQ2pCO0VBQ0Y7RUFFQSxVQUFVO0NBQ1o7Q0FFQSxPQUFPO0FBQ1Q7QUFFQSxJQUFNLFdBQVcsV0FBVyxVQUFVO0NBQ3BDLE1BQU0sTUFBTSxTQUFTLEtBQUssS0FBSztDQUMvQixPQUFPLE1BQU0sU0FBUyxNQUFNLE9BQU8sSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUMsWUFBWTtBQUNsRSxFQUFBLENBQUcsT0FBTyxPQUFPLElBQUksQ0FBQztBQUV0QixJQUFNLGNBQWMsU0FBUztDQUMzQixPQUFPLEtBQUssWUFBWTtDQUN4QixRQUFRLFVBQVUsT0FBTyxLQUFLLE1BQU07QUFDdEM7QUFFQSxJQUFNLGNBQWMsVUFBVSxVQUFVLE9BQU8sVUFBVTs7Ozs7Ozs7QUFTekQsSUFBTSxFQUFFLFlBQVk7Ozs7Ozs7O0FBU3BCLElBQU0sY0FBYyxXQUFXLFdBQVc7Ozs7Ozs7O0FBUzFDLFNBQVMsU0FBUyxLQUFLO0NBQ3JCLE9BQ0UsUUFBUSxRQUNSLENBQUMsWUFBWSxHQUFHLEtBQ2hCLElBQUksZ0JBQWdCLFFBQ3BCLENBQUMsWUFBWSxJQUFJLFdBQVcsS0FDNUJBLGFBQVcsSUFBSSxZQUFZLFFBQVEsS0FDbkMsSUFBSSxZQUFZLFNBQVMsR0FBRztBQUVoQzs7Ozs7Ozs7QUFTQSxJQUFNLGdCQUFnQixXQUFXLGFBQWE7Ozs7Ozs7O0FBUzlDLFNBQVMsa0JBQWtCLEtBQUs7Q0FDOUIsSUFBSTtDQUNKLElBQUksT0FBTyxnQkFBZ0IsZUFBZSxZQUFZLFFBQ3BELFNBQVMsWUFBWSxPQUFPLEdBQUc7TUFFL0IsU0FBUyxPQUFPLElBQUksVUFBVSxjQUFjLElBQUksTUFBTTtDQUV4RCxPQUFPO0FBQ1Q7Ozs7Ozs7O0FBU0EsSUFBTSxXQUFXLFdBQVcsUUFBUTs7Ozs7OztBQVFwQyxJQUFNQSxlQUFhLFdBQVcsVUFBVTs7Ozs7Ozs7QUFTeEMsSUFBTSxXQUFXLFdBQVcsUUFBUTs7Ozs7Ozs7QUFTcEMsSUFBTSxZQUFZLFVBQVUsVUFBVSxRQUFRLE9BQU8sVUFBVTs7Ozs7OztBQVEvRCxJQUFNLGFBQWEsVUFBVSxVQUFVLFFBQVEsVUFBVTs7Ozs7Ozs7QUFTekQsSUFBTSxpQkFBaUIsUUFBUTtDQUM3QixJQUFJLENBQUMsU0FBUyxHQUFHLEdBQ2YsT0FBTztDQUdULE1BQU0sWUFBWSxlQUFlLEdBQUc7Q0FDcEMsUUFDRyxjQUFjLFFBQVEsY0FBYyxPQUFPLGFBQWEsZUFBZSxTQUFTLE1BQU0sU0FJdkYsQ0FBQyx1QkFBdUIsS0FBSyxXQUFXLEtBQ3hDLENBQUMsdUJBQXVCLEtBQUssUUFBUTtBQUV6Qzs7Ozs7Ozs7QUFTQSxJQUFNLGlCQUFpQixRQUFRO0NBRTdCLElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxTQUFTLEdBQUcsR0FDaEMsT0FBTztDQUdULElBQUk7RUFDRixPQUFPLE9BQU8sS0FBSyxHQUFHLENBQUMsQ0FBQyxXQUFXLEtBQUssT0FBTyxlQUFlLEdBQUcsTUFBTSxPQUFPO0NBQ2hGLFNBQVMsR0FBRztFQUVWLE9BQU87Q0FDVDtBQUNGOzs7Ozs7OztBQVNBLElBQU0sU0FBUyxXQUFXLE1BQU07Ozs7Ozs7O0FBU2hDLElBQU0sU0FBUyxXQUFXLE1BQU07Ozs7Ozs7Ozs7OztBQWFoQyxJQUFNLHFCQUFxQixVQUFVO0NBQ25DLE9BQU8sQ0FBQyxFQUFFLFNBQVMsT0FBTyxNQUFNLFFBQVE7QUFDMUM7Ozs7Ozs7OztBQVVBLElBQU0saUJBQWlCLGFBQWEsWUFBWSxPQUFPLFNBQVMsYUFBYTs7Ozs7Ozs7QUFTN0UsSUFBTSxTQUFTLFdBQVcsTUFBTTs7Ozs7Ozs7QUFTaEMsSUFBTSxhQUFhLFdBQVcsVUFBVTtBQUN4QyxJQUFNLFFBQVEsV0FBVyxLQUFLOzs7Ozs7OztBQVM5QixJQUFNLFlBQVksUUFBUSxTQUFTLEdBQUcsS0FBS0EsYUFBVyxJQUFJLElBQUk7Ozs7Ozs7O0FBUzlELFNBQVMsWUFBWTtDQUNuQixJQUFJLE9BQU8sZUFBZSxhQUFhLE9BQU87Q0FDOUMsSUFBSSxPQUFPLFNBQVMsYUFBYSxPQUFPO0NBQ3hDLElBQUksT0FBTyxXQUFXLGFBQWEsT0FBTztDQUMxQyxJQUFJLE9BQU8sV0FBVyxhQUFhLE9BQU87Q0FDMUMsT0FBTyxDQUFDO0FBQ1Y7QUFFQSxJQUFNLElBQUksVUFBVTtBQUNwQixJQUFNLGVBQWUsT0FBTyxFQUFFLGFBQWEsY0FBYyxFQUFFLFdBQVcsS0FBQTtBQUV0RSxJQUFNLGNBQWMsVUFBVTtDQUM1QixJQUFJLENBQUMsT0FBTyxPQUFPO0NBQ25CLElBQUksZ0JBQWdCLGlCQUFpQixjQUFjLE9BQU87Q0FFMUQsTUFBTSxRQUFRLGVBQWUsS0FBSztDQUNsQyxJQUFJLENBQUMsU0FBUyxVQUFVLE9BQU8sV0FBVyxPQUFPO0NBQ2pELElBQUksQ0FBQ0EsYUFBVyxNQUFNLE1BQU0sR0FBRyxPQUFPO0NBQ3RDLE1BQU0sT0FBTyxPQUFPLEtBQUs7Q0FDekIsT0FDRSxTQUFTLGNBRVIsU0FBUyxZQUFZQSxhQUFXLE1BQU0sUUFBUSxLQUFLLE1BQU0sU0FBUyxNQUFNO0FBRTdFOzs7Ozs7OztBQVNBLElBQU0sb0JBQW9CLFdBQVcsaUJBQWlCO0FBRXRELElBQU0sQ0FBQyxrQkFBa0IsV0FBVyxZQUFZLGFBQWE7Q0FDM0Q7Q0FDQTtDQUNBO0NBQ0E7QUFDRixDQUFDLENBQUMsSUFBSSxVQUFVOzs7Ozs7OztBQVNoQixJQUFNLFFBQVEsUUFBUTtDQUNwQixPQUFPLElBQUksT0FBTyxJQUFJLEtBQUssSUFBSSxJQUFJLFFBQVEsc0NBQXNDLEVBQUU7QUFDckY7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBaUJBLFNBQVMsUUFBUSxLQUFLLElBQUksRUFBRSxhQUFhLFVBQVUsQ0FBQyxHQUFHO0NBRXJELElBQUksUUFBUSxRQUFRLE9BQU8sUUFBUSxhQUNqQztDQUdGLElBQUk7Q0FDSixJQUFJO0NBR0osSUFBSSxPQUFPLFFBQVEsVUFFakIsTUFBTSxDQUFDLEdBQUc7Q0FHWixJQUFJLFFBQVEsR0FBRyxHQUViLEtBQUssSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLElBQUksR0FBRyxLQUNqQyxHQUFHLEtBQUssTUFBTSxJQUFJLElBQUksR0FBRyxHQUFHO01BRXpCO0VBRUwsSUFBSSxTQUFTLEdBQUcsR0FDZDtFQUlGLE1BQU0sT0FBTyxhQUFhLE9BQU8sb0JBQW9CLEdBQUcsSUFBSSxPQUFPLEtBQUssR0FBRztFQUMzRSxNQUFNLE1BQU0sS0FBSztFQUNqQixJQUFJO0VBRUosS0FBSyxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQUs7R0FDeEIsTUFBTSxLQUFLO0dBQ1gsR0FBRyxLQUFLLE1BQU0sSUFBSSxNQUFNLEtBQUssR0FBRztFQUNsQztDQUNGO0FBQ0Y7Ozs7Ozs7OztBQVVBLFNBQVMsUUFBUSxLQUFLLEtBQUs7Q0FDekIsSUFBSSxTQUFTLEdBQUcsR0FDZCxPQUFPO0NBR1QsTUFBTSxJQUFJLFlBQVk7Q0FDdEIsTUFBTSxPQUFPLE9BQU8sS0FBSyxHQUFHO0NBQzVCLElBQUksSUFBSSxLQUFLO0NBQ2IsSUFBSTtDQUNKLE9BQU8sTUFBTSxHQUFHO0VBQ2QsT0FBTyxLQUFLO0VBQ1osSUFBSSxRQUFRLEtBQUssWUFBWSxHQUMzQixPQUFPO0NBRVg7Q0FDQSxPQUFPO0FBQ1Q7QUFFQSxJQUFNLGlCQUFpQjtDQUVyQixJQUFJLE9BQU8sZUFBZSxhQUFhLE9BQU87Q0FDOUMsT0FBTyxPQUFPLFNBQVMsY0FBYyxPQUFPLE9BQU8sV0FBVyxjQUFjLFNBQVM7QUFDdkYsRUFBQSxDQUFHO0FBRUgsSUFBTSxvQkFBb0IsWUFBWSxDQUFDLFlBQVksT0FBTyxLQUFLLFlBQVk7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFvQjNFLFNBQVMsTUFBTSxHQUFHLE1BQU07Q0FDdEIsTUFBTSxFQUFFLFVBQVUsa0JBQW1CLGlCQUFpQixJQUFJLEtBQUssUUFBUyxDQUFDO0NBQ3pFLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLE1BQU0sZUFBZSxLQUFLLFFBQVE7RUFFaEMsSUFBSSxRQUFRLGVBQWUsUUFBUSxpQkFBaUIsUUFBUSxhQUMxRDtFQUtGLE1BQU0sWUFBYSxZQUFZLE9BQU8sUUFBUSxZQUFZLFFBQVEsUUFBUSxHQUFHLEtBQU07RUFJbkYsTUFBTSxXQUFXLGVBQWUsUUFBUSxTQUFTLElBQUksT0FBTyxhQUFhLEtBQUE7RUFDekUsSUFBSSxjQUFjLFFBQVEsS0FBSyxjQUFjLEdBQUcsR0FDOUMsT0FBTyxhQUFhLE1BQU0sVUFBVSxHQUFHO09BQ2xDLElBQUksY0FBYyxHQUFHLEdBQzFCLE9BQU8sYUFBYSxNQUFNLENBQUMsR0FBRyxHQUFHO09BQzVCLElBQUksUUFBUSxHQUFHLEdBQ3BCLE9BQU8sYUFBYSxJQUFJLE1BQU07T0FDekIsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFlBQVksR0FBRyxHQUMzQyxPQUFPLGFBQWE7Q0FFeEI7Q0FFQSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLElBQUksR0FBRyxLQUFLO0VBQzNDLE1BQU0sU0FBUyxLQUFLO0VBQ3BCLElBQUksQ0FBQyxVQUFVLFNBQVMsTUFBTSxHQUM1QjtFQUdGLFFBQVEsUUFBUSxXQUFXO0VBRTNCLElBQUksT0FBTyxXQUFXLFlBQVksUUFBUSxNQUFNLEdBQzlDO0VBR0YsTUFBTSxVQUFVLE9BQU8sc0JBQXNCLE1BQU07RUFDbkQsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsUUFBUSxLQUFLO0dBQ3ZDLE1BQU0sU0FBUyxRQUFRO0dBQ3ZCLElBQUkscUJBQXFCLEtBQUssUUFBUSxNQUFNLEdBQzFDLFlBQVksT0FBTyxTQUFTLE1BQU07RUFFdEM7Q0FDRjtDQUNBLE9BQU87QUFDVDs7Ozs7Ozs7Ozs7O0FBYUEsSUFBTSxVQUFVLEdBQUcsR0FBRyxTQUFTLEVBQUUsZUFBZSxDQUFDLE1BQU07Q0FDckQsUUFDRSxJQUNDLEtBQUssUUFBUTtFQUNaLElBQUksV0FBV0EsYUFBVyxHQUFHLEdBQzNCLE9BQU8sZUFBZSxHQUFHLEtBQUs7R0FHNUIsV0FBVztHQUNYLE9BQU8sS0FBSyxLQUFLLE9BQU87R0FDeEIsVUFBVTtHQUNWLFlBQVk7R0FDWixjQUFjO0VBQ2hCLENBQUM7T0FFRCxPQUFPLGVBQWUsR0FBRyxLQUFLO0dBQzVCLFdBQVc7R0FDWCxPQUFPO0dBQ1AsVUFBVTtHQUNWLFlBQVk7R0FDWixjQUFjO0VBQ2hCLENBQUM7Q0FFTCxHQUNBLEVBQUUsV0FBVyxDQUNmO0NBQ0EsT0FBTztBQUNUOzs7Ozs7OztBQVNBLElBQU0sWUFBWSxZQUFZO0NBQzVCLElBQUksUUFBUSxXQUFXLENBQUMsTUFBTSxPQUM1QixVQUFVLFFBQVEsTUFBTSxDQUFDO0NBRTNCLE9BQU87QUFDVDs7Ozs7Ozs7OztBQVdBLElBQU0sWUFBWSxhQUFhLGtCQUFrQixPQUFPLGdCQUFnQjtDQUN0RSxZQUFZLFlBQVksT0FBTyxPQUFPLGlCQUFpQixXQUFXLFdBQVc7Q0FDN0UsT0FBTyxlQUFlLFlBQVksV0FBVyxlQUFlO0VBQzFELFdBQVc7RUFDWCxPQUFPO0VBQ1AsVUFBVTtFQUNWLFlBQVk7RUFDWixjQUFjO0NBQ2hCLENBQUM7Q0FDRCxPQUFPLGVBQWUsYUFBYSxTQUFTO0VBQzFDLFdBQVc7RUFDWCxPQUFPLGlCQUFpQjtDQUMxQixDQUFDO0NBQ0QsU0FBUyxPQUFPLE9BQU8sWUFBWSxXQUFXLEtBQUs7QUFDckQ7Ozs7Ozs7Ozs7QUFXQSxJQUFNLGdCQUFnQixXQUFXLFNBQVMsUUFBUSxlQUFlO0NBQy9ELElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLE1BQU0sU0FBUyxDQUFDO0NBRWhCLFVBQVUsV0FBVyxDQUFDO0NBRXRCLElBQUksYUFBYSxNQUFNLE9BQU87Q0FFOUIsR0FBRztFQUNELFFBQVEsT0FBTyxvQkFBb0IsU0FBUztFQUM1QyxJQUFJLE1BQU07RUFDVixPQUFPLE1BQU0sR0FBRztHQUNkLE9BQU8sTUFBTTtHQUNiLEtBQUssQ0FBQyxjQUFjLFdBQVcsTUFBTSxXQUFXLE9BQU8sTUFBTSxDQUFDLE9BQU8sT0FBTztJQUMxRSxRQUFRLFFBQVEsVUFBVTtJQUMxQixPQUFPLFFBQVE7R0FDakI7RUFDRjtFQUNBLFlBQVksV0FBVyxTQUFTLGVBQWUsU0FBUztDQUMxRCxTQUFTLGNBQWMsQ0FBQyxVQUFVLE9BQU8sV0FBVyxPQUFPLE1BQU0sY0FBYyxPQUFPO0NBRXRGLE9BQU87QUFDVDs7Ozs7Ozs7OztBQVdBLElBQU0sWUFBWSxLQUFLLGNBQWMsYUFBYTtDQUNoRCxNQUFNLE9BQU8sR0FBRztDQUNoQixJQUFJLGFBQWEsS0FBQSxLQUFhLFdBQVcsSUFBSSxRQUMzQyxXQUFXLElBQUk7Q0FFakIsWUFBWSxhQUFhO0NBQ3pCLE1BQU0sWUFBWSxJQUFJLFFBQVEsY0FBYyxRQUFRO0NBQ3BELE9BQU8sY0FBYyxNQUFNLGNBQWM7QUFDM0M7Ozs7Ozs7O0FBU0EsSUFBTSxXQUFXLFVBQVU7Q0FDekIsSUFBSSxDQUFDLE9BQU8sT0FBTztDQUNuQixJQUFJLFFBQVEsS0FBSyxHQUFHLE9BQU87Q0FDM0IsSUFBSSxJQUFJLE1BQU07Q0FDZCxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsT0FBTztDQUN6QixNQUFNLE1BQU0sSUFBSSxNQUFNLENBQUM7Q0FDdkIsT0FBTyxNQUFNLEdBQ1gsSUFBSSxLQUFLLE1BQU07Q0FFakIsT0FBTztBQUNUOzs7Ozs7Ozs7QUFXQSxJQUFNLGlCQUFpQixlQUFlO0NBRXBDLFFBQVEsVUFBVTtFQUNoQixPQUFPLGNBQWMsaUJBQWlCO0NBQ3hDO0FBQ0YsRUFBQSxDQUFHLE9BQU8sZUFBZSxlQUFlLGVBQWUsVUFBVSxDQUFDOzs7Ozs7Ozs7QUFVbEUsSUFBTSxnQkFBZ0IsS0FBSyxPQUFPO0NBR2hDLE1BQU0sYUFGWSxPQUFPLElBQUksVUFBQSxDQUVELEtBQUssR0FBRztDQUVwQyxJQUFJO0NBRUosUUFBUSxTQUFTLFVBQVUsS0FBSyxNQUFNLENBQUMsT0FBTyxNQUFNO0VBQ2xELE1BQU0sT0FBTyxPQUFPO0VBQ3BCLEdBQUcsS0FBSyxLQUFLLEtBQUssSUFBSSxLQUFLLEVBQUU7Q0FDL0I7QUFDRjs7Ozs7Ozs7O0FBVUEsSUFBTSxZQUFZLFFBQVEsUUFBUTtDQUNoQyxJQUFJO0NBQ0osTUFBTSxNQUFNLENBQUM7Q0FFYixRQUFRLFVBQVUsT0FBTyxLQUFLLEdBQUcsT0FBTyxNQUN0QyxJQUFJLEtBQUssT0FBTztDQUdsQixPQUFPO0FBQ1Q7QUFHQSxJQUFNLGFBQWEsV0FBVyxpQkFBaUI7QUFFL0MsSUFBTSxlQUFlLFFBQVE7Q0FDM0IsT0FBTyxJQUFJLFlBQVksQ0FBQyxDQUFDLFFBQVEseUJBQXlCLFNBQVMsU0FBUyxHQUFHLElBQUksSUFBSTtFQUNyRixPQUFPLEdBQUcsWUFBWSxJQUFJO0NBQzVCLENBQUM7QUFDSDtBQUVBLElBQU0sRUFBRSx5QkFBeUIsT0FBTzs7Ozs7Ozs7QUFTeEMsSUFBTSxXQUFXLFdBQVcsUUFBUTtBQUVwQyxJQUFNLHFCQUFxQixLQUFLLFlBQVk7Q0FDMUMsTUFBTSxjQUFjLE9BQU8sMEJBQTBCLEdBQUc7Q0FDeEQsTUFBTSxxQkFBcUIsQ0FBQztDQUU1QixRQUFRLGNBQWMsWUFBWSxTQUFTO0VBQ3pDLElBQUk7RUFDSixLQUFLLE1BQU0sUUFBUSxZQUFZLE1BQU0sR0FBRyxPQUFPLE9BQzdDLG1CQUFtQixRQUFRLE9BQU87Q0FFdEMsQ0FBQztDQUVELE9BQU8saUJBQWlCLEtBQUssa0JBQWtCO0FBQ2pEOzs7OztBQU9BLElBQU0saUJBQWlCLFFBQVE7Q0FDN0Isa0JBQWtCLE1BQU0sWUFBWSxTQUFTO0VBRTNDLElBQUlBLGFBQVcsR0FBRyxLQUFLO0dBQUM7R0FBYTtHQUFVO0VBQVEsQ0FBQyxDQUFDLFNBQVMsSUFBSSxHQUNwRSxPQUFPO0VBR1QsTUFBTSxRQUFRLElBQUk7RUFFbEIsSUFBSSxDQUFDQSxhQUFXLEtBQUssR0FBRztFQUV4QixXQUFXLGFBQWE7RUFFeEIsSUFBSSxjQUFjLFlBQVk7R0FDNUIsV0FBVyxXQUFXO0dBQ3RCO0VBQ0Y7RUFFQSxJQUFJLENBQUMsV0FBVyxLQUNkLFdBQVcsWUFBWTtHQUNyQixNQUFNLE1BQU0sdUNBQXVDLE9BQU8sR0FBRztFQUMvRDtDQUVKLENBQUM7QUFDSDs7Ozs7Ozs7O0FBVUEsSUFBTSxlQUFlLGVBQWUsY0FBYztDQUNoRCxNQUFNLE1BQU0sQ0FBQztDQUViLE1BQU0sVUFBVSxRQUFRO0VBQ3RCLElBQUksU0FBUyxVQUFVO0dBQ3JCLElBQUksU0FBUztFQUNmLENBQUM7Q0FDSDtDQUVBLFFBQVEsYUFBYSxJQUFJLE9BQU8sYUFBYSxJQUFJLE9BQU8sT0FBTyxhQUFhLENBQUMsQ0FBQyxNQUFNLFNBQVMsQ0FBQztDQUU5RixPQUFPO0FBQ1Q7QUFFQSxJQUFNLGFBQWEsQ0FBQztBQUVwQixJQUFNLGtCQUFrQixPQUFPLGlCQUFpQjtDQUM5QyxPQUFPLFNBQVMsUUFBUSxPQUFPLFNBQVUsUUFBUSxDQUFDLEtBQU0sSUFBSSxRQUFRO0FBQ3RFOzs7Ozs7OztBQVNBLFNBQVMsb0JBQW9CLE9BQU87Q0FDbEMsT0FBTyxDQUFDLEVBQ04sU0FDQUEsYUFBVyxNQUFNLE1BQU0sS0FDdkIsTUFBTSxpQkFBaUIsY0FDdkIsTUFBTTtBQUVWOzs7Ozs7O0FBUUEsSUFBTSxnQkFBZ0IsUUFBUTtDQUM1QixNQUFNLDBCQUFVLElBQUksUUFBUTtDQUU1QixNQUFNLFNBQVMsV0FBVztFQUN4QixJQUFJLFNBQVMsTUFBTSxHQUFHO0dBQ3BCLElBQUksUUFBUSxJQUFJLE1BQU0sR0FDcEI7R0FJRixJQUFJLFNBQVMsTUFBTSxHQUNqQixPQUFPO0dBR1QsSUFBSSxFQUFFLFlBQVksU0FBUztJQUV6QixRQUFRLElBQUksTUFBTTtJQUVsQixJQUFJO0lBRUosSUFBSSxNQUFNLE1BQU0sR0FBRztLQUNqQixTQUFTLENBQUM7S0FDVixLQUFLLE1BQU0sU0FBUyxRQUFRO01BQzFCLE1BQU0sZUFBZSxNQUFNLEtBQUs7TUFDaEMsQ0FBQyxZQUFZLFlBQVksS0FBSyxPQUFPLEtBQUssWUFBWTtLQUN4RDtJQUNGLE9BQU87S0FDTCxTQUFTLFFBQVEsTUFBTSxJQUFJLENBQUMsSUFBSSxDQUFDO0tBRWpDLFFBQVEsU0FBUyxPQUFPLFFBQVE7TUFDOUIsTUFBTSxlQUFlLE1BQU0sS0FBSztNQUNoQyxDQUFDLFlBQVksWUFBWSxNQUFNLE9BQU8sT0FBTztLQUMvQyxDQUFDO0lBQ0g7SUFFQSxRQUFRLE9BQU8sTUFBTTtJQUVyQixPQUFPO0dBQ1Q7RUFDRjtFQUVBLE9BQU87Q0FDVDtDQUVBLE9BQU8sTUFBTSxHQUFHO0FBQ2xCOzs7Ozs7O0FBUUEsSUFBTSxZQUFZLFdBQVcsZUFBZTs7Ozs7OztBQVE1QyxJQUFNLGNBQWMsVUFDbEIsVUFDQyxTQUFTLEtBQUssS0FBS0EsYUFBVyxLQUFLLE1BQ3BDQSxhQUFXLE1BQU0sSUFBSSxLQUNyQkEsYUFBVyxNQUFNLEtBQUs7Ozs7Ozs7OztBQWF4QixJQUFNLGtCQUFrQix1QkFBdUIseUJBQXlCO0NBQ3RFLElBQUksdUJBQ0YsT0FBTztDQUdULE9BQU8seUJBQ0QsT0FBTyxjQUFjO0VBQ3JCLFFBQVEsaUJBQ04sWUFDQyxFQUFFLFFBQVEsV0FBVztHQUNwQixJQUFJLFdBQVcsV0FBVyxTQUFTLE9BQ2pDLFVBQVUsVUFBVSxVQUFVLE1BQU0sQ0FBQyxDQUFDO0VBRTFDLEdBQ0EsS0FDRjtFQUVBLFFBQVEsT0FBTztHQUNiLFVBQVUsS0FBSyxFQUFFO0dBQ2pCLFFBQVEsWUFBWSxPQUFPLEdBQUc7RUFDaEM7Q0FDRixFQUFBLENBQUcsU0FBUyxLQUFLLE9BQU8sS0FBSyxDQUFDLENBQUMsS0FDOUIsT0FBTyxXQUFXLEVBQUU7QUFDM0IsRUFBQSxDQUFHLE9BQU8saUJBQWlCLFlBQVlBLGFBQVcsUUFBUSxXQUFXLENBQUM7Ozs7Ozs7QUFRdEUsSUFBTSxPQUNKLE9BQU8sbUJBQW1CLGNBQ3RCLGVBQWUsS0FBSyxPQUFPLElBQzFCLE9BQU8sWUFBWSxlQUFlLFFBQVEsWUFBYTtBQUk5RCxJQUFNLGNBQWMsVUFBVSxTQUFTLFFBQVFBLGFBQVcsTUFBTSxTQUFTOzs7Ozs7Ozs7Ozs7QUFhekUsSUFBTSxrQkFBa0IsVUFDdEIsU0FBUyxRQUFRLHVCQUF1QixPQUFPLFFBQVEsS0FBSyxXQUFXLEtBQUs7QUFFOUUsSUFBQSxnQkFBZTtDQUNiO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsWUFBQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsWUFBWTtDQUNaO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsUUFBUTtDQUNSO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxjQUFjO0NBQ2Q7Q0FDQTtDQUNBO0FBQ0Y7OztBQ3ZuQ0EsSUFBTSxvQkFBb0JDLGNBQU0sWUFBWTtDQUMxQztDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0FBQ0YsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7O0FBZ0JELElBQUEsd0JBQWdCLGVBQWU7Q0FDN0IsTUFBTSxTQUFTLENBQUM7Q0FDaEIsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBRUosY0FDRSxXQUFXLE1BQU0sSUFBSSxDQUFDLENBQUMsUUFBUSxTQUFTLE9BQU8sTUFBTTtFQUNuRCxJQUFJLEtBQUssUUFBUSxHQUFHO0VBQ3BCLE1BQU0sS0FBSyxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsWUFBWTtFQUM5QyxNQUFNLEtBQUssVUFBVSxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUs7RUFFakMsTUFBTSxTQUFTQSxjQUFNLFdBQVcsUUFBUSxHQUFHO0VBRTNDLElBQUksQ0FBQyxPQUFRLFVBQVVBLGNBQU0sV0FBVyxtQkFBbUIsR0FBRyxHQUM1RDtFQUdGLElBQUksUUFBUSxjQUFjO0dBQ3hCLElBQUksUUFDRixPQUFPLElBQUksQ0FBQyxLQUFLLEdBQUc7UUFFcEIsT0FBTyxPQUFPLENBQUMsR0FBRztFQUV0QixPQUNFLE9BQU8sT0FBTyxTQUFTLE9BQU8sT0FBTyxPQUFPLE1BQU07Q0FFdEQsQ0FBQztDQUVILE9BQU87QUFDVDs7O0FDbEVBLFNBQVMsYUFBYSxLQUFLO0NBQ3pCLElBQUksUUFBUTtDQUNaLElBQUksTUFBTSxJQUFJO0NBRWQsT0FBTyxRQUFRLEtBQUs7RUFDbEIsTUFBTSxPQUFPLElBQUksV0FBVyxLQUFLO0VBRWpDLElBQUksU0FBUyxLQUFRLFNBQVMsSUFDNUI7RUFHRixTQUFTO0NBQ1g7Q0FFQSxPQUFPLE1BQU0sT0FBTztFQUNsQixNQUFNLE9BQU8sSUFBSSxXQUFXLE1BQU0sQ0FBQztFQUVuQyxJQUFJLFNBQVMsS0FBUSxTQUFTLElBQzVCO0VBR0YsT0FBTztDQUNUO0NBRUEsT0FBTyxVQUFVLEtBQUssUUFBUSxJQUFJLFNBQVMsTUFBTSxJQUFJLE1BQU0sT0FBTyxHQUFHO0FBQ3ZFO0FBSUEsSUFBTSxxREFBcUMsSUFBSSxPQUFPLDRDQUE0QyxHQUFHO0FBRXJHLElBQU0seURBQXlDLElBQUksT0FBTyw2Q0FBNkMsR0FBRztBQUUxRyxTQUFTLGNBQWMsT0FBTyxjQUFjO0NBQzFDLElBQUlDLGNBQU0sUUFBUSxLQUFLLEdBQ3JCLE9BQU8sTUFBTSxLQUFLLFNBQVMsY0FBYyxNQUFNLFlBQVksQ0FBQztDQUc5RCxPQUFPLGFBQWEsT0FBTyxLQUFLLENBQUMsQ0FBQyxRQUFRLGNBQWMsRUFBRSxDQUFDO0FBQzdEO0FBRUEsSUFBYSx1QkFBdUIsVUFDbEMsY0FBYyxPQUFPLGtDQUFrQztBQUV6RCxJQUFhLGlDQUFpQyxVQUM1QyxjQUFjLE9BQU8sc0NBQXNDO0FBRTdELFNBQWdCLHlCQUF5QixTQUFTO0NBQ2hELE1BQU0sb0JBQW9CLE9BQU8sT0FBTyxJQUFJO0NBRTVDLGNBQU0sUUFBUSxRQUFRLE9BQU8sSUFBSSxPQUFPLFdBQVc7RUFDakQsa0JBQWtCLFVBQVUsOEJBQThCLEtBQUs7Q0FDakUsQ0FBQztDQUVELE9BQU87QUFDVDs7O0FDckRBLElBQU1DLGVBQWEsT0FBTyxXQUFXO0FBRXJDLFNBQVMsZ0JBQWdCLFFBQVE7Q0FDL0IsT0FBTyxVQUFVLE9BQU8sTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsWUFBWTtBQUNyRDtBQUVBLFNBQVMsZUFBZSxPQUFPO0NBQzdCLElBQUksVUFBVSxTQUFTLFNBQVMsTUFDOUIsT0FBTztDQUdULE9BQU9DLGNBQU0sUUFBUSxLQUFLLElBQUksTUFBTSxJQUFJLGNBQWMsSUFBSSxvQkFBb0IsT0FBTyxLQUFLLENBQUM7QUFDN0Y7QUFFQSxTQUFTLFlBQVksS0FBSztDQUN4QixNQUFNLFNBQVMsT0FBTyxPQUFPLElBQUk7Q0FDakMsTUFBTSxXQUFXO0NBQ2pCLElBQUk7Q0FFSixPQUFRLFFBQVEsU0FBUyxLQUFLLEdBQUcsR0FDL0IsT0FBTyxNQUFNLE1BQU0sTUFBTTtDQUczQixPQUFPO0FBQ1Q7QUFFQSxJQUFNLGtCQUFrQjtBQUV4QixTQUFTLFFBQVEsT0FBTztDQUN0QixJQUFJLFFBQVE7Q0FDWixJQUFJLE1BQU0sTUFBTTtDQUVoQixPQUFPLFFBQVEsS0FBSztFQUNsQixNQUFNLE9BQU8sTUFBTSxXQUFXLEtBQUs7RUFFbkMsSUFBSSxTQUFTLEtBQVEsU0FBUyxJQUM1QjtFQUdGLFNBQVM7Q0FDWDtDQUVBLE9BQU8sTUFBTSxPQUFPO0VBQ2xCLE1BQU0sT0FBTyxNQUFNLFdBQVcsTUFBTSxDQUFDO0VBRXJDLElBQUksU0FBUyxLQUFRLFNBQVMsSUFDNUI7RUFHRixPQUFPO0NBQ1Q7Q0FFQSxPQUFPLFVBQVUsS0FBSyxRQUFRLE1BQU0sU0FBUyxRQUFRLE1BQU0sTUFBTSxPQUFPLEdBQUc7QUFDN0U7QUFFQSxTQUFTLG1CQUFtQixPQUFPO0NBQ2pDLE1BQU0sT0FBTyxNQUFNLFNBQVM7Q0FFNUIsSUFBSSxPQUFPLEtBQUssTUFBTSxXQUFXLENBQUMsTUFBTSxNQUFRLE1BQU0sV0FBVyxJQUFJLE1BQU0sSUFDekUsT0FBTztDQUdULElBQUksVUFBVTtDQUVkLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLEtBQUs7RUFDN0IsTUFBTSxPQUFPLE1BQU0sV0FBVyxDQUFDO0VBRS9CLElBQUksU0FBUyxJQUNYLE9BQU87RUFHVCxJQUFJLFNBQVMsSUFBTTtHQUNqQixLQUFLO0dBRUwsSUFBSSxLQUFLLE1BQ1AsT0FBTztFQUVYO0VBRUEsV0FBVyxNQUFNO0NBQ25CO0NBRUEsT0FBTztBQUNUO0FBRUEsU0FBUyxnQkFBZ0IsT0FBTztDQUM5QixNQUFNLGFBQWEsT0FBTyxPQUFPLElBQUk7Q0FDckMsTUFBTSxNQUFNLE9BQU8sS0FBSztDQUN4QixJQUFJLFFBQVE7Q0FDWixJQUFJLFNBQVM7Q0FDYixJQUFJLFVBQVU7Q0FFZCxTQUFTLGVBQWUsS0FBSztFQUMzQixNQUFNLE9BQU8sUUFBUSxJQUFJLE1BQU0sT0FBTyxHQUFHLENBQUM7RUFDMUMsTUFBTSxTQUFTLEtBQUssUUFBUSxHQUFHO0VBRS9CLElBQUksU0FBUyxHQUNYO0VBR0YsTUFBTSxPQUFPLFFBQVEsS0FBSyxNQUFNLEdBQUcsTUFBTSxDQUFDO0VBRTFDLElBQUksQ0FBQyxnQkFBZ0IsS0FBSyxJQUFJLEdBQzVCO0VBR0YsTUFBTSxpQkFBaUIsS0FBSyxZQUFZO0VBRXhDLElBQ0UsbUJBQW1CLGVBQ25CLG1CQUFtQixpQkFDbkIsbUJBQW1CLGFBRW5CO0VBR0YsTUFBTSxpQkFBaUIsUUFBUSxLQUFLLE1BQU0sU0FBUyxDQUFDLENBQUM7RUFDckQsV0FBVyxrQkFBa0IsbUJBQW1CLGNBQWM7Q0FDaEU7Q0FFQSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLEtBQUs7RUFDbkMsTUFBTSxPQUFPLElBQUksV0FBVyxDQUFDO0VBRTdCLElBQUksUUFBUTtHQUNWLElBQUksU0FDRixVQUFVO1FBQ0wsSUFBSSxTQUFTLElBQ2xCLFVBQVU7UUFDTCxJQUFJLFNBQVMsSUFDbEIsU0FBUztFQUViLE9BQU8sSUFBSSxTQUFTLElBQ2xCLFNBQVM7T0FDSixJQUFJLFNBQVMsTUFBUSxTQUFTLElBQU07R0FDekMsZUFBZSxDQUFDO0dBQ2hCLFFBQVEsSUFBSTtFQUNkO0NBQ0Y7Q0FFQSxlQUFlLElBQUksTUFBTTtDQUV6QixPQUFPO0FBQ1Q7QUFFQSxJQUFNLHFCQUFxQixRQUFRLGlDQUFpQyxLQUFLLElBQUksS0FBSyxDQUFDO0FBRW5GLFNBQVMsaUJBQWlCLFNBQVMsT0FBTyxRQUFRLFFBQVEsb0JBQW9CO0NBQzVFLElBQUlBLGNBQU0sV0FBVyxNQUFNLEdBQ3pCLE9BQU8sT0FBTyxLQUFLLE1BQU0sT0FBTyxNQUFNO0NBR3hDLElBQUksb0JBQ0YsUUFBUTtDQUdWLElBQUksQ0FBQ0EsY0FBTSxTQUFTLEtBQUssR0FBRztDQUU1QixJQUFJQSxjQUFNLFNBQVMsTUFBTSxHQUN2QixPQUFPLE1BQU0sUUFBUSxNQUFNLE1BQU07Q0FHbkMsSUFBSUEsY0FBTSxTQUFTLE1BQU0sR0FDdkIsT0FBTyxPQUFPLEtBQUssS0FBSztBQUU1QjtBQUVBLFNBQVMsYUFBYSxRQUFRO0NBQzVCLE9BQU8sT0FDSixLQUFLLENBQUMsQ0FDTixZQUFZLENBQUMsQ0FDYixRQUFRLG9CQUFvQixHQUFHLE1BQU0sUUFBUTtFQUM1QyxPQUFPLEtBQUssWUFBWSxJQUFJO0NBQzlCLENBQUM7QUFDTDtBQUVBLFNBQVMsZUFBZSxLQUFLLFFBQVE7Q0FDbkMsTUFBTSxlQUFlQSxjQUFNLFlBQVksTUFBTSxNQUFNO0NBRW5EO0VBQUM7RUFBTztFQUFPO0NBQUssQ0FBQyxDQUFDLFNBQVMsZUFBZTtFQUM1QyxPQUFPLGVBQWUsS0FBSyxhQUFhLGNBQWM7R0FHcEQsV0FBVztHQUNYLE9BQU8sU0FBVSxNQUFNLE1BQU0sTUFBTTtJQUNqQyxPQUFPLEtBQUssV0FBVyxDQUFDLEtBQUssTUFBTSxRQUFRLE1BQU0sTUFBTSxJQUFJO0dBQzdEO0dBQ0EsY0FBYztFQUNoQixDQUFDO0NBQ0gsQ0FBQztBQUNIO0FBRUEsSUFBTUMsaUJBQU4sTUFBbUI7Q0FDakIsWUFBWSxTQUFTO0VBQ25CLFdBQVcsS0FBSyxJQUFJLE9BQU87Q0FDN0I7Q0FFQSxJQUFJLFFBQVEsZ0JBQWdCLFNBQVM7RUFDbkMsTUFBTSxPQUFPO0VBRWIsU0FBUyxVQUFVLFFBQVEsU0FBUyxVQUFVO0dBQzVDLE1BQU0sVUFBVSxnQkFBZ0IsT0FBTztHQUV2QyxJQUFJLENBQUMsU0FDSDtHQUdGLE1BQU0sTUFBTUQsY0FBTSxRQUFRLE1BQU0sT0FBTztHQUV2QyxJQUNFLENBQUMsT0FDRCxLQUFLLFNBQVMsS0FBQSxLQUNkLGFBQWEsUUFDWixhQUFhLEtBQUEsS0FBYSxLQUFLLFNBQVMsT0FFekMsS0FBSyxPQUFPLFdBQVcsZUFBZSxNQUFNO0VBRWhEO0VBRUEsTUFBTSxjQUFjLFNBQVMsYUFDM0JBLGNBQU0sUUFBUSxVQUFVLFFBQVEsWUFBWSxVQUFVLFFBQVEsU0FBUyxRQUFRLENBQUM7RUFFbEYsSUFBSUEsY0FBTSxjQUFjLE1BQU0sS0FBSyxrQkFBa0IsS0FBSyxhQUN4RCxXQUFXLFFBQVEsY0FBYztPQUM1QixJQUFJQSxjQUFNLFNBQVMsTUFBTSxNQUFNLFNBQVMsT0FBTyxLQUFLLE1BQU0sQ0FBQyxrQkFBa0IsTUFBTSxHQUN4RixXQUFXRSxxQkFBYSxNQUFNLEdBQUcsY0FBYztPQUMxQyxJQUFJRixjQUFNLFNBQVMsTUFBTSxLQUFLQSxjQUFNLGVBQWUsTUFBTSxHQUFHO0dBQ2pFLElBQUksTUFBTSxPQUFPLE9BQU8sSUFBSSxHQUMxQixNQUNBO0dBQ0YsS0FBSyxNQUFNLFNBQVMsUUFBUTtJQUMxQixJQUFJLENBQUNBLGNBQU0sUUFBUSxLQUFLLEdBQ3RCLE1BQU0sSUFBSSxVQUFVLDhDQUE4QztJQUdwRSxNQUFNLE1BQU07SUFFWixJQUFJQSxjQUFNLFdBQVcsS0FBSyxHQUFHLEdBQUc7S0FDOUIsT0FBTyxJQUFJO0tBQ1gsSUFBSSxPQUFPQSxjQUFNLFFBQVEsSUFBSSxJQUFJLENBQUMsR0FBRyxNQUFNLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxNQUFNLEVBQUU7SUFDeEUsT0FDRSxJQUFJLE9BQU8sTUFBTTtHQUVyQjtHQUVBLFdBQVcsS0FBSyxjQUFjO0VBQ2hDLE9BQ0UsVUFBVSxRQUFRLFVBQVUsZ0JBQWdCLFFBQVEsT0FBTztFQUc3RCxPQUFPO0NBQ1Q7Q0FFQSxJQUFJLFFBQVEsUUFBUTtFQUNsQixTQUFTLGdCQUFnQixNQUFNO0VBRS9CLElBQUksUUFBUTtHQUNWLE1BQU0sTUFBTUEsY0FBTSxRQUFRLE1BQU0sTUFBTTtHQUV0QyxJQUFJLEtBQUs7SUFDUCxNQUFNLFFBQVEsS0FBSztJQUVuQixJQUFJLENBQUMsUUFDSCxPQUFPO0lBR1QsSUFBSSxXQUFXLE1BQ2IsT0FBTyxZQUFZLEtBQUs7SUFHMUIsSUFBSUEsY0FBTSxXQUFXLE1BQU0sR0FDekIsT0FBTyxPQUFPLEtBQUssTUFBTSxPQUFPLEdBQUc7SUFHckMsSUFBSUEsY0FBTSxTQUFTLE1BQU0sR0FDdkIsT0FBTyxPQUFPLEtBQUssS0FBSztJQUcxQixNQUFNLElBQUksVUFBVSx3Q0FBd0M7R0FDOUQ7RUFDRjtDQUNGO0NBRUEsSUFBSSxRQUFRLFNBQVM7RUFDbkIsU0FBUyxnQkFBZ0IsTUFBTTtFQUUvQixJQUFJLFFBQVE7R0FDVixNQUFNLE1BQU1BLGNBQU0sUUFBUSxNQUFNLE1BQU07R0FFdEMsT0FBTyxDQUFDLEVBQ04sT0FDQSxLQUFLLFNBQVMsS0FBQSxNQUNiLENBQUMsV0FBVyxpQkFBaUIsTUFBTSxLQUFLLE1BQU0sS0FBSyxPQUFPO0VBRS9EO0VBRUEsT0FBTztDQUNUO0NBRUEsT0FBTyxRQUFRLFNBQVM7RUFDdEIsTUFBTSxPQUFPO0VBQ2IsSUFBSSxVQUFVO0VBRWQsU0FBUyxhQUFhLFNBQVM7R0FDN0IsVUFBVSxnQkFBZ0IsT0FBTztHQUVqQyxJQUFJLFNBQVM7SUFDWCxNQUFNLE1BQU1BLGNBQU0sUUFBUSxNQUFNLE9BQU87SUFFdkMsSUFBSSxRQUFRLENBQUMsV0FBVyxpQkFBaUIsTUFBTSxLQUFLLE1BQU0sS0FBSyxPQUFPLElBQUk7S0FDeEUsT0FBTyxLQUFLO0tBRVosVUFBVTtJQUNaO0dBQ0Y7RUFDRjtFQUVBLElBQUlBLGNBQU0sUUFBUSxNQUFNLEdBQ3RCLE9BQU8sUUFBUSxZQUFZO09BRTNCLGFBQWEsTUFBTTtFQUdyQixPQUFPO0NBQ1Q7Q0FFQSxNQUFNLFNBQVM7RUFDYixNQUFNLE9BQU8sT0FBTyxLQUFLLElBQUk7RUFDN0IsSUFBSSxJQUFJLEtBQUs7RUFDYixJQUFJLFVBQVU7RUFFZCxPQUFPLEtBQUs7R0FDVixNQUFNLE1BQU0sS0FBSztHQUNqQixJQUFJLENBQUMsV0FBVyxpQkFBaUIsTUFBTSxLQUFLLE1BQU0sS0FBSyxTQUFTLElBQUksR0FBRztJQUNyRSxPQUFPLEtBQUs7SUFDWixVQUFVO0dBQ1o7RUFDRjtFQUVBLE9BQU87Q0FDVDtDQUVBLFVBQVUsUUFBUTtFQUNoQixNQUFNLE9BQU87RUFDYixNQUFNLFVBQVUsQ0FBQztFQUVqQixjQUFNLFFBQVEsT0FBTyxPQUFPLFdBQVc7R0FDckMsTUFBTSxNQUFNQSxjQUFNLFFBQVEsU0FBUyxNQUFNO0dBRXpDLElBQUksS0FBSztJQUNQLEtBQUssT0FBTyxlQUFlLEtBQUs7SUFDaEMsT0FBTyxLQUFLO0lBQ1o7R0FDRjtHQUVBLE1BQU0sYUFBYSxTQUFTLGFBQWEsTUFBTSxJQUFJLE9BQU8sTUFBTSxDQUFDLENBQUMsS0FBSztHQUV2RSxJQUFJLGVBQWUsUUFDakIsT0FBTyxLQUFLO0dBR2QsS0FBSyxjQUFjLGVBQWUsS0FBSztHQUV2QyxRQUFRLGNBQWM7RUFDeEIsQ0FBQztFQUVELE9BQU87Q0FDVDtDQUVBLE9BQU8sR0FBRyxTQUFTO0VBQ2pCLE9BQU8sS0FBSyxZQUFZLE9BQU8sTUFBTSxHQUFHLE9BQU87Q0FDakQ7Q0FFQSxPQUFPLFdBQVc7RUFDaEIsTUFBTSxNQUFNLE9BQU8sT0FBTyxJQUFJO0VBRTlCLGNBQU0sUUFBUSxPQUFPLE9BQU8sV0FBVztHQUNyQyxTQUFTLFFBQ1AsVUFBVSxVQUNULElBQUksVUFBVSxhQUFhQSxjQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0sS0FBSyxJQUFJLElBQUk7RUFDMUUsQ0FBQztFQUVELE9BQU87Q0FDVDtDQUVBLENBQUMsT0FBTyxZQUFZO0VBQ2xCLE9BQU8sT0FBTyxRQUFRLEtBQUssT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLFNBQVMsQ0FBQztDQUN4RDtDQUVBLFdBQVc7RUFDVCxPQUFPLE9BQU8sUUFBUSxLQUFLLE9BQU8sQ0FBQyxDQUFDLENBQ2pDLEtBQUssQ0FBQyxRQUFRLFdBQVcsU0FBUyxPQUFPLEtBQUssQ0FBQyxDQUMvQyxLQUFLLElBQUk7Q0FDZDtDQUVBLGVBQWU7RUFDYixNQUFNLFFBQVEsS0FBSyxJQUFJLFlBQVk7RUFDbkMsT0FBT0EsY0FBTSxRQUFRLEtBQUssSUFBSSxRQUFRLFNBQVMsUUFBUSxVQUFVLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSztDQUN0RjtDQUVBLEtBQUssT0FBTyxlQUFlO0VBQ3pCLE9BQU87Q0FDVDtDQUVBLE9BQU8sS0FBSyxPQUFPO0VBQ2pCLE9BQU8saUJBQWlCLE9BQU8sUUFBUSxJQUFJLEtBQUssS0FBSztDQUN2RDtDQUVBLE9BQU8sZ0JBQWdCLE9BQU87RUFDNUIsT0FBTyxnQkFBZ0IsS0FBSztDQUM5QjtDQUVBLE9BQU8sT0FBTyxPQUFPLEdBQUcsU0FBUztFQUMvQixNQUFNLFdBQVcsSUFBSSxLQUFLLEtBQUs7RUFFL0IsUUFBUSxTQUFTLFdBQVcsU0FBUyxJQUFJLE1BQU0sQ0FBQztFQUVoRCxPQUFPO0NBQ1Q7Q0FFQSxPQUFPLFNBQVMsUUFBUTtFQVF0QixNQUFNLGFBQVksS0FOVkQsZ0JBQ04sS0FBS0EsZ0JBQ0gsRUFDRSxXQUFXLENBQUMsRUFDZCxFQUFBLENBRXdCO0VBQzVCLE1BQU0sWUFBWSxLQUFLO0VBRXZCLFNBQVMsZUFBZSxTQUFTO0dBQy9CLE1BQU0sVUFBVSxnQkFBZ0IsT0FBTztHQUV2QyxJQUFJLENBQUMsVUFBVSxVQUFVO0lBQ3ZCLGVBQWUsV0FBVyxPQUFPO0lBQ2pDLFVBQVUsV0FBVztHQUN2QjtFQUNGO0VBRUEsY0FBTSxRQUFRLE1BQU0sSUFBSSxPQUFPLFFBQVEsY0FBYyxJQUFJLGVBQWUsTUFBTTtFQUU5RSxPQUFPO0NBQ1Q7QUFDRjtBQUVBRSxlQUFhLFNBQVM7Q0FDcEI7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0FBQ0YsQ0FBQztBQUdERCxjQUFNLGtCQUFrQkMsZUFBYSxZQUFZLEVBQUUsU0FBUyxRQUFRO0NBQ2xFLElBQUksU0FBUyxJQUFJLEVBQUUsQ0FBQyxZQUFZLElBQUksSUFBSSxNQUFNLENBQUM7Q0FDL0MsT0FBTztFQUNMLFdBQVc7RUFDWCxJQUFJLGFBQWE7R0FDZixLQUFLLFVBQVU7RUFDakI7Q0FDRjtBQUNGLENBQUM7QUFFREQsY0FBTSxjQUFjQyxjQUFZOzs7QUNsZGhDLElBQWEsV0FBVztBQUV4QixTQUFTLHdCQUF3QixRQUFRO0NBQ3ZDLElBQUlFLGNBQU0sV0FBVyxRQUFRLFFBQVEsR0FDbkMsT0FBTztDQUdULElBQUksWUFBWSxPQUFPLGVBQWUsTUFBTTtDQUU1QyxPQUFPLGFBQWEsY0FBYyxPQUFPLFdBQVc7RUFDbEQsSUFBSUEsY0FBTSxXQUFXLFdBQVcsUUFBUSxHQUN0QyxPQUFPO0VBR1QsWUFBWSxPQUFPLGVBQWUsU0FBUztDQUM3QztDQUVBLE9BQU87QUFDVDtBQUtBLFNBQVMsYUFBYSxRQUFRLFlBQVk7Q0FDeEMsTUFBTSxZQUFZLElBQUksSUFBSSxXQUFXLEtBQUssTUFBTSxPQUFPLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0NBQ3hFLE1BQU0sT0FBTyxDQUFDO0NBRWQsTUFBTSxTQUFTLFdBQVc7RUFDeEIsSUFBSSxXQUFXLFFBQVEsT0FBTyxXQUFXLFVBQVUsT0FBTztFQUMxRCxJQUFJQSxjQUFNLFNBQVMsTUFBTSxHQUFHLE9BQU87RUFDbkMsSUFBSSxLQUFLLFFBQVEsTUFBTSxNQUFNLElBQUksT0FBTyxLQUFBO0VBRXhDLElBQUksa0JBQWtCQyxnQkFDcEIsU0FBUyxPQUFPLE9BQU87RUFHekIsS0FBSyxLQUFLLE1BQU07RUFFaEIsSUFBSTtFQUNKLElBQUlELGNBQU0sUUFBUSxNQUFNLEdBQUc7R0FDekIsU0FBUyxDQUFDO0dBQ1YsT0FBTyxTQUFTLEdBQUcsTUFBTTtJQUN2QixNQUFNLGVBQWUsTUFBTSxDQUFDO0lBQzVCLElBQUksQ0FBQ0EsY0FBTSxZQUFZLFlBQVksR0FDakMsT0FBTyxLQUFLO0dBRWhCLENBQUM7RUFDSCxPQUFPO0dBQ0wsSUFBSSxDQUFDQSxjQUFNLGNBQWMsTUFBTSxLQUFLLHdCQUF3QixNQUFNLEdBQUc7SUFDbkUsS0FBSyxJQUFJO0lBQ1QsT0FBTztHQUNUO0dBRUEsU0FBUyxPQUFPLE9BQU8sSUFBSTtHQUMzQixLQUFLLE1BQU0sQ0FBQyxLQUFLLFVBQVUsT0FBTyxRQUFRLE1BQU0sR0FBRztJQUNqRCxNQUFNLGVBQWUsVUFBVSxJQUFJLElBQUksWUFBWSxDQUFDLElBQUksV0FBVyxNQUFNLEtBQUs7SUFDOUUsSUFBSSxDQUFDQSxjQUFNLFlBQVksWUFBWSxHQUNqQyxPQUFPLE9BQU87R0FFbEI7RUFDRjtFQUVBLEtBQUssSUFBSTtFQUNULE9BQU87Q0FDVDtDQUVBLE9BQU8sTUFBTSxNQUFNO0FBQ3JCO0FBRUEsU0FBU0Usa0JBQWdCLE9BQU87Q0FDOUIsSUFBSTtFQUNGLE9BQU8sT0FBTyxLQUFLO0NBQ3JCLFNBQVMsS0FBSztFQUNaLE9BQU87Q0FDVDtBQUNGO0FBRUEsU0FBUyxzQkFBc0IsT0FBTztDQVlwQyxPQVhnQixNQUFNLE9BQ25CLEtBQUssVUFBVTtFQUNkLElBQUk7R0FDRixPQUFPLFNBQVMsTUFBTSxVQUFVQSxrQkFBZ0IsTUFBTSxPQUFPLElBQUlBLGtCQUFnQixLQUFLO0VBQ3hGLFNBQVMsS0FBSztHQUNaLE9BQU87RUFDVDtDQUNGLENBQUMsQ0FBQyxDQUNELE9BQU8sT0FBTyxDQUFDLENBQ2YsS0FBSyxJQUVLLEtBQUssTUFBTSxRQUFRO0FBQ2xDO0FBRUEsSUFBTUMsZUFBTixNQUFNQSxxQkFBbUIsTUFBTTtDQUM3QixPQUFPLEtBQUssT0FBTyxNQUFNLFFBQVEsU0FBUyxVQUFVLGFBQWE7RUFJL0QsSUFBSSxVQUFVLE1BQU07RUFDcEIsSUFBSSxDQUFDLFdBQVdILGNBQU0sUUFBUSxNQUFNLE1BQU0sS0FBSyxNQUFNLE9BQU8sUUFDMUQsVUFBVSxzQkFBc0IsS0FBSztFQUd2QyxNQUFNLGFBQWEsSUFBSUcsYUFBVyxTQUFTLFFBQVEsTUFBTSxNQUFNLFFBQVEsU0FBUyxRQUFRO0VBT3hGLE9BQU8sZUFBZSxZQUFZLFNBQVM7R0FDekMsV0FBVztHQUNYLE9BQU87R0FDUCxVQUFVO0dBQ1YsWUFBWTtHQUNaLGNBQWM7RUFDaEIsQ0FBQztFQUNELFdBQVcsT0FBTyxNQUFNO0VBR3hCLElBQUksTUFBTSxVQUFVLFFBQVEsV0FBVyxVQUFVLE1BQy9DLFdBQVcsU0FBUyxNQUFNO0VBRzVCLGVBQWUsT0FBTyxPQUFPLFlBQVksV0FBVztFQUNwRCxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7OztDQWFBLFlBQVksU0FBUyxNQUFNLFFBQVEsU0FBUyxVQUFVO0VBQ3BELE1BQU0sT0FBTztFQUtiLE9BQU8sZUFBZSxNQUFNLFdBQVc7R0FHckMsV0FBVztHQUNYLE9BQU87R0FDUCxZQUFZO0dBQ1osVUFBVTtHQUNWLGNBQWM7RUFDaEIsQ0FBQztFQUVELEtBQUssT0FBTztFQUNaLEtBQUssZUFBZTtFQUNwQixTQUFTLEtBQUssT0FBTztFQUNyQixXQUFXLEtBQUssU0FBUztFQUN6QixZQUFZLEtBQUssVUFBVTtFQUMzQixJQUFJLFVBQVU7R0FDWixLQUFLLFdBQVc7R0FDaEIsS0FBSyxTQUFTLFNBQVM7RUFDekI7Q0FDRjtDQUVBLFNBQVM7RUFLUCxNQUFNLFNBQVMsS0FBSztFQUNwQixNQUFNLGFBQWEsVUFBVUgsY0FBTSxXQUFXLFFBQVEsUUFBUSxJQUFJLE9BQU8sU0FBUyxLQUFBO0VBQ2xGLE1BQU0sbUJBQ0pBLGNBQU0sUUFBUSxVQUFVLEtBQUssV0FBVyxTQUFTLElBQzdDLGFBQWEsUUFBUSxVQUFVLElBQy9CQSxjQUFNLGFBQWEsTUFBTTtFQUUvQixPQUFPO0dBRUwsU0FBUyxLQUFLO0dBQ2QsTUFBTSxLQUFLO0dBRVgsYUFBYSxLQUFLO0dBQ2xCLFFBQVEsS0FBSztHQUViLFVBQVUsS0FBSztHQUNmLFlBQVksS0FBSztHQUNqQixjQUFjLEtBQUs7R0FDbkIsT0FBTyxLQUFLO0dBRVosUUFBUTtHQUNSLE1BQU0sS0FBSztHQUNYLFFBQVEsS0FBSztFQUNmO0NBQ0Y7QUFDRjtBQUdBLGFBQVcsdUJBQXVCO0FBQ2xDLGFBQVcsaUJBQWlCO0FBQzVCLGFBQVcsZUFBZTtBQUMxQixhQUFXLFlBQVk7QUFDdkIsYUFBVyxlQUFlO0FBQzFCLGFBQVcsY0FBYztBQUN6QixhQUFXLDRCQUE0QjtBQUN2QyxhQUFXLGlCQUFpQjtBQUM1QixhQUFXLG1CQUFtQjtBQUM5QixhQUFXLGtCQUFrQjtBQUM3QixhQUFXLGVBQWU7QUFDMUIsYUFBVyxrQkFBa0I7QUFDN0IsYUFBVyxrQkFBa0I7QUFDN0IsYUFBVywrQkFBK0I7Ozs7Ozs7O0FDck0xQyxTQUFTLFlBQVksT0FBTztDQUMxQixPQUFPSSxjQUFNLGNBQWMsS0FBSyxLQUFLQSxjQUFNLFFBQVEsS0FBSztBQUMxRDs7Ozs7Ozs7QUFTQSxTQUFTLGVBQWUsS0FBSztDQUMzQixPQUFPQSxjQUFNLFNBQVMsS0FBSyxJQUFJLElBQUksSUFBSSxNQUFNLEdBQUcsRUFBRSxJQUFJO0FBQ3hEOzs7Ozs7Ozs7O0FBV0EsU0FBUyxVQUFVLE1BQU0sS0FBSyxNQUFNO0NBQ2xDLElBQUksQ0FBQyxNQUFNLE9BQU87Q0FDbEIsT0FBTyxLQUNKLE9BQU8sR0FBRyxDQUFDLENBQ1gsSUFBSSxTQUFTLEtBQUssT0FBTyxHQUFHO0VBRTNCLFFBQVEsZUFBZSxLQUFLO0VBQzVCLE9BQU8sQ0FBQyxRQUFRLElBQUksTUFBTSxRQUFRLE1BQU07Q0FDMUMsQ0FBQyxDQUFDLENBQ0QsS0FBSyxPQUFPLE1BQU0sRUFBRTtBQUN6Qjs7Ozs7Ozs7QUFTQSxTQUFTLFlBQVksS0FBSztDQUN4QixPQUFPQSxjQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsSUFBSSxLQUFLLFdBQVc7QUFDcEQ7QUFFQSxJQUFNLGFBQWFBLGNBQU0sYUFBYUEsZUFBTyxDQUFDLEdBQUcsTUFBTSxTQUFTLE9BQU8sTUFBTTtDQUMzRSxPQUFPLFdBQVcsS0FBSyxJQUFJO0FBQzdCLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBeUJELFNBQVNDLGFBQVcsS0FBSyxVQUFVLFNBQVM7Q0FDMUMsSUFBSSxDQUFDRCxjQUFNLFNBQVMsR0FBRyxHQUNyQixNQUFNLElBQUksVUFBVSwwQkFBMEI7Q0FJaEQsV0FBVyxZQUFZLElBQXlCLFNBQVU7Q0FFMUQsTUFBTSxVQUFVLE1BQU0sYUFBYTtFQUNqQyxNQUFNLFFBQVFBLGNBQU0sWUFBWSxTQUFTLElBQUk7RUFDN0MsT0FBT0EsY0FBTSxZQUFZLEtBQUssSUFBSSxXQUFXO0NBQy9DO0NBRUEsTUFBTSxhQUFhLE9BQU8sY0FBYyxJQUFJO0NBRTVDLE1BQU0sVUFBVSxPQUFPLFNBQVMsS0FBSztDQUNyQyxNQUFNLE9BQU8sT0FBTyxRQUFRLEtBQUs7Q0FDakMsTUFBTSxVQUFVLE9BQU8sV0FBVyxLQUFLO0NBQ3ZDLE1BQU0sUUFBUSxPQUFPLE1BQU0sS0FBTSxPQUFPLFNBQVMsZUFBZTtDQUNoRSxNQUFNLFdBQVcsT0FBTyxZQUFBLEdBQXVDO0NBQy9ELE1BQU0sVUFBVSxTQUFTQSxjQUFNLG9CQUFvQixRQUFRO0NBQzNELE1BQU0sUUFBUSxDQUFDO0NBRWYsSUFBSSxDQUFDQSxjQUFNLFdBQVcsT0FBTyxHQUMzQixNQUFNLElBQUksVUFBVSw0QkFBNEI7Q0FHbEQsU0FBUyxhQUFhLE9BQU87RUFDM0IsSUFBSSxVQUFVLE1BQU0sT0FBTztFQUUzQixJQUFJQSxjQUFNLE9BQU8sS0FBSyxHQUNwQixPQUFPLE1BQU0sWUFBWTtFQUczQixJQUFJQSxjQUFNLFVBQVUsS0FBSyxHQUN2QixPQUFPLE1BQU0sU0FBUztFQUd4QixJQUFJLENBQUMsV0FBV0EsY0FBTSxPQUFPLEtBQUssR0FDaEMsTUFBTSxJQUFJRSxhQUFXLDhDQUE4QztFQUdyRSxJQUFJRixjQUFNLGNBQWMsS0FBSyxLQUFLQSxjQUFNLGFBQWEsS0FBSyxHQUFHO0dBQzNELElBQUksV0FBVyxPQUFPLFVBQVUsWUFDOUIsT0FBTyxJQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUM7R0FLMUIsTUFBTSxJQUFJRSxhQUNSLGdEQUNBQSxhQUFXLGVBQ2I7RUFDRjtFQUVBLE9BQU87Q0FDVDtDQUVBLFNBQVMsd0JBQXdCLE9BQU87RUFDdEMsSUFBSSxRQUFRLFVBQ1YsTUFBTSxJQUFJQSxhQUNSLGtDQUFrQyxRQUFRLDBCQUEwQixVQUNwRUEsYUFBVyw0QkFDYjtDQUVKO0NBRUEsU0FBUyx3QkFBd0IsT0FBTyxPQUFPO0VBQzdDLElBQUksYUFBYSxVQUNmLE9BQU8sS0FBSyxVQUFVLEtBQUs7RUFHN0IsTUFBTSxZQUFZLENBQUM7RUFFbkIsT0FBTyxLQUFLLFVBQVUsT0FBTyxTQUFTLFdBQVcsTUFBTSxjQUFjO0dBQ25FLElBQUksQ0FBQ0YsY0FBTSxTQUFTLFlBQVksR0FDOUIsT0FBTztHQUdULE9BQU8sVUFBVSxVQUFVLFVBQVUsVUFBVSxTQUFTLE9BQU8sTUFDN0QsVUFBVSxJQUFJO0dBR2hCLFVBQVUsS0FBSyxZQUFZO0dBQzNCLHdCQUF3QixRQUFRLFVBQVUsU0FBUyxDQUFDO0dBRXBELE9BQU87RUFDVCxDQUFDO0NBQ0g7Ozs7Ozs7Ozs7O0NBWUEsU0FBUyxlQUFlLE9BQU8sS0FBSyxNQUFNO0VBQ3hDLElBQUksTUFBTTtFQUVWLElBQUlBLGNBQU0sY0FBYyxRQUFRLEtBQUtBLGNBQU0sa0JBQWtCLEtBQUssR0FBRztHQUNuRSxTQUFTLE9BQU8sVUFBVSxNQUFNLEtBQUssSUFBSSxHQUFHLGFBQWEsS0FBSyxDQUFDO0dBQy9ELE9BQU87RUFDVDtFQUVBLElBQUksU0FBUyxDQUFDLFFBQVEsT0FBTyxVQUFVLFVBQVU7R0FDL0MsSUFBSUEsY0FBTSxTQUFTLEtBQUssSUFBSSxHQUFHO0lBRTdCLE1BQU0sYUFBYSxNQUFNLElBQUksTUFBTSxHQUFHLEVBQUU7SUFFeEMsUUFBUSx3QkFBd0IsT0FBTyxDQUFDO0dBQzFDLE9BQU8sSUFDSkEsY0FBTSxRQUFRLEtBQUssS0FBSyxZQUFZLEtBQUssTUFDeENBLGNBQU0sV0FBVyxLQUFLLEtBQUtBLGNBQU0sU0FBUyxLQUFLLElBQUksT0FBTyxNQUFNQSxjQUFNLFFBQVEsS0FBSyxJQUNyRjtJQUVBLE1BQU0sZUFBZSxHQUFHO0lBRXhCLElBQUksUUFBUSxTQUFTLEtBQUssSUFBSSxPQUFPO0tBQ25DLEVBQUVBLGNBQU0sWUFBWSxFQUFFLEtBQUssT0FBTyxTQUNoQyxTQUFTLE9BRVAsWUFBWSxPQUNSLFVBQVUsQ0FBQyxHQUFHLEdBQUcsT0FBTyxJQUFJLElBQzVCLFlBQVksT0FDVixNQUNBLE1BQU0sTUFDWixhQUFhLEVBQUUsQ0FDakI7SUFDSixDQUFDO0lBQ0QsT0FBTztHQUNUO0VBQ0Y7RUFFQSxJQUFJLFlBQVksS0FBSyxHQUNuQixPQUFPO0VBR1QsU0FBUyxPQUFPLFVBQVUsTUFBTSxLQUFLLElBQUksR0FBRyxhQUFhLEtBQUssQ0FBQztFQUUvRCxPQUFPO0NBQ1Q7Q0FFQSxNQUFNLGlCQUFpQixPQUFPLE9BQU8sWUFBWTtFQUMvQztFQUNBO0VBQ0E7Q0FDRixDQUFDO0NBRUQsU0FBUyxNQUFNLE9BQU8sTUFBTSxRQUFRLEdBQUc7RUFDckMsSUFBSUEsY0FBTSxZQUFZLEtBQUssR0FBRztFQUU5Qix3QkFBd0IsS0FBSztFQUU3QixJQUFJLE1BQU0sUUFBUSxLQUFLLE1BQU0sSUFDM0IsTUFBTSxJQUFJLE1BQU0sb0NBQW9DLEtBQUssS0FBSyxHQUFHLENBQUM7RUFHcEUsTUFBTSxLQUFLLEtBQUs7RUFFaEIsY0FBTSxRQUFRLE9BQU8sU0FBUyxLQUFLLElBQUksS0FBSztHQUsxQyxLQUhFLEVBQUVBLGNBQU0sWUFBWSxFQUFFLEtBQUssT0FBTyxTQUNsQyxRQUFRLEtBQUssVUFBVSxJQUFJQSxjQUFNLFNBQVMsR0FBRyxJQUFJLElBQUksS0FBSyxJQUFJLEtBQUssTUFBTSxjQUFjLE9BRTFFLE1BQ2IsTUFBTSxJQUFJLE9BQU8sS0FBSyxPQUFPLEdBQUcsSUFBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUM7RUFFeEQsQ0FBQztFQUVELE1BQU0sSUFBSTtDQUNaO0NBRUEsSUFBSSxDQUFDQSxjQUFNLFNBQVMsR0FBRyxHQUNyQixNQUFNLElBQUksVUFBVSx3QkFBd0I7Q0FHOUMsTUFBTSxHQUFHO0NBRVQsT0FBTztBQUNUOzs7Ozs7Ozs7OztBQ3hRQSxTQUFTRyxTQUFPLEtBQUs7Q0FDbkIsTUFBTSxVQUFVO0VBQ2QsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxPQUFPO0NBQ1Q7Q0FDQSxPQUFPLG1CQUFtQixHQUFHLENBQUMsQ0FBQyxRQUFRLGdCQUFnQixTQUFTLFNBQVMsT0FBTztFQUM5RSxPQUFPLFFBQVE7Q0FDakIsQ0FBQztBQUNIOzs7Ozs7Ozs7QUFVQSxTQUFTLHFCQUFxQixRQUFRLFNBQVM7Q0FDN0MsS0FBSyxTQUFTLENBQUM7Q0FFZixVQUFVQyxhQUFXLFFBQVEsTUFBTSxPQUFPO0FBQzVDO0FBRUEsSUFBTSxZQUFZLHFCQUFxQjtBQUV2QyxVQUFVLFNBQVMsU0FBUyxPQUFPLE1BQU0sT0FBTztDQUM5QyxLQUFLLE9BQU8sS0FBSyxDQUFDLE1BQU0sS0FBSyxDQUFDO0FBQ2hDO0FBRUEsVUFBVSxXQUFXLFNBQVMsU0FBUyxTQUFTO0NBQzlDLE1BQU0sVUFBVSxXQUNYLFVBQVUsUUFBUSxLQUFLLE1BQU0sT0FBT0QsUUFBTSxJQUMzQ0E7Q0FFSixPQUFPLEtBQUssT0FDVCxJQUFJLFNBQVMsS0FBSyxNQUFNO0VBQ3ZCLE9BQU8sUUFBUSxLQUFLLEVBQUUsSUFBSSxNQUFNLFFBQVEsS0FBSyxFQUFFO0NBQ2pELEdBQUcsRUFBRSxDQUFDLENBQ0wsS0FBSyxHQUFHO0FBQ2I7Ozs7Ozs7Ozs7O0FDM0NBLFNBQWdCLE9BQU8sS0FBSztDQUMxQixPQUFPLG1CQUFtQixHQUFHLENBQUMsQ0FDM0IsUUFBUSxTQUFTLEdBQUcsQ0FBQyxDQUNyQixRQUFRLFFBQVEsR0FBRyxDQUFDLENBQ3BCLFFBQVEsU0FBUyxHQUFHLENBQUMsQ0FDckIsUUFBUSxRQUFRLEdBQUc7QUFDeEI7Ozs7Ozs7Ozs7QUFXQSxTQUF3QixTQUFTLEtBQUssUUFBUSxTQUFTO0NBQ3JELElBQUksQ0FBQyxRQUNILE9BQU87Q0FFVCxNQUFNLE9BQU87Q0FFYixNQUFNLFdBQVdFLGNBQU0sV0FBVyxPQUFPLElBQ3JDLEVBQ0UsV0FBVyxRQUNiLElBQ0E7Q0FLSixNQUFNLFVBQVVBLGNBQU0sWUFBWSxVQUFVLFFBQVEsS0FBSztDQUN6RCxNQUFNLGNBQWNBLGNBQU0sWUFBWSxVQUFVLFdBQVc7Q0FFM0QsSUFBSTtDQUVKLElBQUksYUFDRixtQkFBbUIsWUFBWSxRQUFRLFFBQVE7TUFFL0MsbUJBQW1CQSxjQUFNLGtCQUFrQixNQUFNLElBQzdDLE9BQU8sU0FBUyxJQUNoQixJQUFJLHFCQUFxQixRQUFRLFFBQVEsQ0FBQyxDQUFDLFNBQVMsT0FBTztDQUdqRSxJQUFJLGtCQUFrQjtFQUNwQixNQUFNLGdCQUFnQixJQUFJLFFBQVEsR0FBRztFQUVyQyxJQUFJLGtCQUFrQixJQUNwQixNQUFNLElBQUksTUFBTSxHQUFHLGFBQWE7RUFFbEMsUUFBUSxJQUFJLFFBQVEsR0FBRyxNQUFNLEtBQUssTUFBTSxPQUFPO0NBQ2pEO0NBRUEsT0FBTztBQUNUOzs7QUNoRUEsSUFBTSxhQUFhLE9BQU8sV0FBVztBQUtyQyxTQUFTLGNBQWMsVUFBVTtDQUMvQixPQUFPLFdBQVcsU0FBUyxTQUFTO0FBQ3RDO0FBRUEsU0FBUyxhQUFhLFVBQVU7Q0FDOUIsSUFBSSxDQUFDLFVBQ0g7Q0FHRixPQUFPLFNBQVMsVUFBVSxTQUFTLFNBQVMsU0FBUyxPQUFPLE1BQzFELFNBQVMsSUFBSTtBQUVqQjtBQUVBLFNBQVMsbUJBQW1CLFNBQVMsV0FBVztDQUM5QyxNQUFNLFdBQVcsUUFBUTtDQUN6QixNQUFNLFNBQVMsY0FBYyxRQUFRO0NBRXJDLElBQUksYUFBYSxVQUFVLGFBQWE7RUFDdEMsVUFBVSxjQUFjO0VBQ3hCLFVBQVUsZUFBZSxNQUFNO0NBQ2pDLE9BQU8sSUFBSSxXQUFXLFVBQVUsZ0JBQWdCO0VBQzlDLElBQUksQ0FBQyxRQUNILFVBQVUsZUFBZSxNQUFNO09BRS9CLFVBQVUsZUFBZSxRQUFRLFNBQVMsaUJBQWlCLE9BQU8sSUFBSTtHQUNwRSxJQUFJLFNBQVMsTUFBTSxXQUFXLE1BQU0sU0FDbEMsVUFBVSxlQUFlLE9BQU8sRUFBRTtFQUV0QyxDQUFDO0NBRUw7Q0FFQSxVQUFVLGlCQUFpQjtBQUM3QjtBQUVBLElBQU0scUJBQU4sTUFBeUI7Q0FDdkIsY0FBYztFQUNaLEtBQUssV0FBVyxDQUFDO0VBQ2pCLEtBQUssY0FBYztHQUNqQixhQUFhLEtBQUs7R0FDbEIsZ0JBQWdCLEtBQUssU0FBUztHQUM5QixnQ0FBZ0IsSUFBSSxJQUFJO0dBQ3hCLGdCQUFnQjtHQUNoQixRQUFRO0VBQ1Y7Q0FDRjs7Ozs7Ozs7OztDQVdBLElBQUksV0FBVyxVQUFVLFNBQVM7RUFDaEMsTUFBTSxVQUFVO0dBQ2Q7R0FDQTtHQUNBLGFBQWEsVUFBVSxRQUFRLGNBQWM7R0FDN0MsU0FBUyxVQUFVLFFBQVEsVUFBVTtFQUN2QztFQUNBLE1BQU0sWUFBWSxLQUFLO0VBRXZCLElBQUksS0FBSyxZQUFZLE1BQ25CLEtBQUssV0FBVyxDQUFDO0VBR25CLG1CQUFtQixNQUFNLFNBQVM7RUFFbEMsTUFBTSxLQUFLLFVBQVU7RUFFckIsS0FBSyxTQUFTLEtBQUssT0FBTztFQUMxQixVQUFVLGVBQWUsSUFBSSxJQUFJO0dBQy9CO0dBQ0EsT0FBTyxLQUFLLFNBQVMsU0FBUztFQUNoQyxDQUFDO0VBQ0QsVUFBVSxpQkFBaUIsS0FBSyxTQUFTO0VBRXpDLE9BQU87Q0FDVDs7Ozs7Ozs7Q0FTQSxNQUFNLElBQUk7RUFDUixNQUFNLFlBQVksS0FBSztFQUV2QixtQkFBbUIsTUFBTSxTQUFTO0VBRWxDLE1BQU0sUUFBUSxVQUFVLGVBQWUsSUFBSSxFQUFFO0VBRTdDLElBQUksT0FBTztHQUNULFVBQVUsZUFBZSxPQUFPLEVBQUU7R0FHbEMsSUFBSSxLQUFLLFNBQVMsTUFBTSxXQUFXLE1BQU0sU0FDdkM7R0FHRixLQUFLLFNBQVMsTUFBTSxTQUFTO0dBRzdCLElBQUksQ0FBQyxVQUFVLGdCQUFnQjtJQUM3QixhQUFhLEtBQUssUUFBUTtJQUMxQixVQUFVLGlCQUFpQixLQUFLLFNBQVM7R0FDM0M7RUFDRjtDQUNGOzs7Ozs7Q0FPQSxRQUFRO0VBQ04sSUFBSSxLQUFLLFVBQVU7R0FDakIsS0FBSyxXQUFXLENBQUM7R0FDakIsbUJBQW1CLE1BQU0sS0FBSyxXQUFXO0VBQzNDO0NBQ0Y7Ozs7Ozs7Ozs7O0NBWUEsUUFBUSxJQUFJO0VBQ1YsTUFBTSxZQUFZLEtBQUs7RUFFdkIsbUJBQW1CLE1BQU0sU0FBUztFQUVsQyxVQUFVO0VBRVYsSUFBSTtHQUNGLGNBQU0sUUFBUSxLQUFLLFVBQVUsU0FBUyxlQUFlLEdBQUc7SUFDdEQsSUFBSSxNQUFNLE1BQ1IsR0FBRyxDQUFDO0dBRVIsQ0FBQztFQUNILFVBQVU7R0FDUixJQUFJLENBQUMsRUFBRSxVQUFVLGdCQUFnQjtJQUMvQixtQkFBbUIsTUFBTSxTQUFTO0lBQ2xDLGFBQWEsS0FBSyxRQUFRO0lBQzFCLFVBQVUsaUJBQWlCLGNBQWMsS0FBSyxRQUFRO0dBQ3hEO0VBQ0Y7Q0FDRjtBQUNGOzs7QUN0S0EsSUFBQSx1QkFBZTtDQUNiLG1CQUFtQjtDQUNuQixtQkFBbUI7Q0FDbkIscUJBQXFCO0NBQ3JCLGlDQUFpQztDQUNqQyw2QkFBNkI7Q0FDN0IsaUNBQWlDO0FBQ25DOzs7QUlMQSxJQUFBLGtCQUFlO0NBQ2IsV0FBVztDQUNYLFNBQVM7RUFDUCxpQkhKVyxPQUFPLG9CQUFvQixjQUFjLGtCQUFrQjtFR0t0RSxVRk5XLE9BQU8sYUFBYSxjQUFjLFdBQVc7RUVPeEQsTURQVyxPQUFPLFNBQVMsY0FBYyxPQUFPO0NDUWxEO0NBQ0EsV0FBVztFQUFDO0VBQVE7RUFBUztFQUFRO0VBQVE7RUFBTztDQUFNO0FBQzVEOzs7Ozs7Ozs7O0FDWkEsSUFBTSxnQkFBZ0IsT0FBTyxXQUFXLGVBQWUsT0FBTyxhQUFhO0FBRTNFLElBQU0sYUFBYyxPQUFPLGNBQWMsWUFBWSxhQUFjLEtBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW1CbkUsSUFBTSx3QkFDSixrQkFDQyxDQUFDLGNBQWM7Q0FBQztDQUFlO0NBQWdCO0FBQUksQ0FBQyxDQUFDLFFBQVEsV0FBVyxPQUFPLElBQUk7Ozs7Ozs7Ozs7QUFXdEYsSUFBTSx3Q0FBd0M7Q0FDNUMsT0FDRSxPQUFPLHNCQUFzQixlQUU3QixnQkFBZ0IscUJBQ2hCLE9BQU8sS0FBSyxrQkFBa0I7QUFFbEMsRUFBQSxDQUFHO0FBRUgsSUFBTSxTQUFVLGlCQUFpQixPQUFPLFNBQVMsUUFBUzs7O0FDeEMxRCxJQUFBLG1CQUFlO0NBQ2IsR0FBR0M7Q0FDSCxHQUFHQztBQUNMOzs7QUNBQSxTQUF3QixpQkFBaUIsTUFBTSxTQUFTO0NBQ3RELE9BQU9DLGFBQVcsTUFBTSxJQUFJQyxpQkFBUyxRQUFRLGdCQUFnQixHQUFHO0VBQzlELFNBQVMsU0FBVSxPQUFPLEtBQUssTUFBTSxTQUFTO0dBQzVDLElBQUlBLGlCQUFTLFVBQVVDLGNBQU0sU0FBUyxLQUFLLEdBQUc7SUFDNUMsS0FBSyxPQUFPLEtBQUssTUFBTSxTQUFTLFFBQVEsQ0FBQztJQUN6QyxPQUFPO0dBQ1Q7R0FFQSxPQUFPLFFBQVEsZUFBZSxNQUFNLE1BQU0sU0FBUztFQUNyRDtFQUNBLEdBQUc7Q0FDTCxDQUFDO0FBQ0g7OztBQ1pBLElBQU0sWUFBQTtBQUVOLFNBQVMscUJBQXFCLE9BQU87Q0FDbkMsSUFBSSxRQUFRLFdBQ1YsTUFBTSxJQUFJQyxhQUNSLDBDQUEwQyxRQUFRLDBCQUEwQixXQUM1RUEsYUFBVyw0QkFDYjtBQUVKOzs7Ozs7OztBQVNBLFNBQVMsY0FBYyxNQUFNO0NBVzNCLE1BQU0sT0FBTyxDQUFDO0NBQ2QsTUFBTSxVQUFVO0NBQ2hCLElBQUk7Q0FFSixRQUFRLFFBQVEsUUFBUSxLQUFLLElBQUksT0FBTyxNQUFNO0VBQzVDLHFCQUFxQixLQUFLLE1BQU07RUFDaEMsS0FBSyxLQUFLLE1BQU0sT0FBTyxPQUFPLEtBQUssTUFBTSxNQUFNLE1BQU0sRUFBRTtDQUN6RDtDQUVBLE9BQU87QUFDVDs7Ozs7Ozs7QUFTQSxTQUFTLGNBQWMsS0FBSztDQUMxQixNQUFNLE1BQU0sQ0FBQztDQUNiLE1BQU0sT0FBTyxPQUFPLEtBQUssR0FBRztDQUM1QixJQUFJO0NBQ0osTUFBTSxNQUFNLEtBQUs7Q0FDakIsSUFBSTtDQUNKLEtBQUssSUFBSSxHQUFHLElBQUksS0FBSyxLQUFLO0VBQ3hCLE1BQU0sS0FBSztFQUNYLElBQUksT0FBTyxJQUFJO0NBQ2pCO0NBQ0EsT0FBTztBQUNUOzs7Ozs7OztBQVNBLFNBQVMsZUFBZSxVQUFVO0NBQ2hDLFNBQVMsVUFBVSxNQUFNLE9BQU8sUUFBUSxPQUFPO0VBQzdDLHFCQUFxQixLQUFLO0VBRTFCLElBQUksT0FBTyxLQUFLO0VBRWhCLElBQUksU0FBUyxhQUFhLE9BQU87RUFFakMsTUFBTSxlQUFlLE9BQU8sU0FBUyxDQUFDLElBQUk7RUFDMUMsTUFBTSxTQUFTLFNBQVMsS0FBSztFQUM3QixPQUFPLENBQUMsUUFBUUMsY0FBTSxRQUFRLE1BQU0sSUFBSSxPQUFPLFNBQVM7RUFFeEQsSUFBSSxRQUFRO0dBQ1YsSUFBSUEsY0FBTSxXQUFXLFFBQVEsSUFBSSxHQUMvQixPQUFPLFFBQVFBLGNBQU0sUUFBUSxPQUFPLEtBQUssSUFDckMsT0FBTyxLQUFLLENBQUMsT0FBTyxLQUFLLElBQ3pCLENBQUMsT0FBTyxPQUFPLEtBQUs7UUFFeEIsT0FBTyxRQUFRO0dBR2pCLE9BQU8sQ0FBQztFQUNWO0VBRUEsSUFBSSxDQUFDQSxjQUFNLFdBQVcsUUFBUSxJQUFJLEtBQUssQ0FBQ0EsY0FBTSxTQUFTLE9BQU8sS0FBSyxHQUNqRSxPQUFPLFFBQVEsQ0FBQztFQUtsQixJQUZlLFVBQVUsTUFBTSxPQUFPLE9BQU8sT0FBTyxLQUUzQyxLQUFLQSxjQUFNLFFBQVEsT0FBTyxLQUFLLEdBQ3RDLE9BQU8sUUFBUSxjQUFjLE9BQU8sS0FBSztFQUczQyxPQUFPLENBQUM7Q0FDVjtDQUVBLElBQUlBLGNBQU0sV0FBVyxRQUFRLEtBQUtBLGNBQU0sV0FBVyxTQUFTLE9BQU8sR0FBRztFQUNwRSxNQUFNLE1BQU0sQ0FBQztFQUViLGNBQU0sYUFBYSxXQUFXLE1BQU0sVUFBVTtHQUM1QyxVQUFVLGNBQWMsSUFBSSxHQUFHLE9BQU8sS0FBSyxDQUFDO0VBQzlDLENBQUM7RUFFRCxPQUFPO0NBQ1Q7Q0FFQSxPQUFPO0FBQ1Q7OztBQ3hIQSxJQUFNLGFBQWEsT0FBTyxPQUFPO0NBQy9CO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7QUFDRixDQUFDOzs7QUNIRCxJQUFNLE9BQU8sS0FBSyxRQUFTLE9BQU8sUUFBUUMsY0FBTSxXQUFXLEtBQUssR0FBRyxJQUFJLElBQUksT0FBTyxLQUFBOzs7Ozs7Ozs7OztBQVlsRixTQUFTLGdCQUFnQixVQUFVLFFBQVEsU0FBUztDQUNsRCxJQUFJQSxjQUFNLFNBQVMsUUFBUSxHQUN6QixJQUFJO0VBQ0YsQ0FBQyxVQUFVLEtBQUssTUFBQSxDQUFPLFFBQVE7RUFDL0IsT0FBT0EsY0FBTSxLQUFLLFFBQVE7Q0FDNUIsU0FBUyxHQUFHO0VBQ1YsSUFBSSxFQUFFLFNBQVMsZUFDYixNQUFNO0NBRVY7Q0FHRixRQUFRLFdBQVcsS0FBSyxVQUFBLENBQVcsUUFBUTtBQUM3QztBQUVBLElBQU0sV0FBVztDQUNmLGNBQWNDO0NBRWQsU0FBUztFQUFDO0VBQU87RUFBUTtDQUFPO0NBRWhDLGtCQUFrQixDQUNoQixTQUFTLGlCQUFpQixNQUFNLFNBQVM7RUFDdkMsTUFBTSxjQUFjLFFBQVEsZUFBZSxLQUFLO0VBQ2hELE1BQU0scUJBQXFCLFlBQVksUUFBUSxrQkFBa0IsSUFBSTtFQUNyRSxNQUFNLGtCQUFrQkQsY0FBTSxTQUFTLElBQUk7RUFFM0MsSUFBSSxtQkFBbUJBLGNBQU0sV0FBVyxJQUFJLEdBQzFDLE9BQU8sSUFBSSxTQUFTLElBQUk7RUFLMUIsSUFGbUJBLGNBQU0sV0FBVyxJQUV2QixHQUNYLE9BQU8scUJBQXFCLEtBQUssVUFBVSxlQUFlLElBQUksQ0FBQyxJQUFJO0VBR3JFLElBQ0VBLGNBQU0sY0FBYyxJQUFJLEtBQ3hCQSxjQUFNLFNBQVMsSUFBSSxLQUNuQkEsY0FBTSxTQUFTLElBQUksS0FDbkJBLGNBQU0sT0FBTyxJQUFJLEtBQ2pCQSxjQUFNLE9BQU8sSUFBSSxLQUNqQkEsY0FBTSxpQkFBaUIsSUFBSSxHQUUzQixPQUFPO0VBRVQsSUFBSUEsY0FBTSxrQkFBa0IsSUFBSSxHQUM5QixPQUFPLEtBQUs7RUFFZCxJQUFJQSxjQUFNLGtCQUFrQixJQUFJLEdBQUc7R0FDakMsUUFBUSxlQUFlLG1EQUFtRCxLQUFLO0dBQy9FLE9BQU8sS0FBSyxTQUFTO0VBQ3ZCO0VBRUEsSUFBSTtFQUVKLElBQUksaUJBQWlCO0dBQ25CLE1BQU0saUJBQWlCLElBQUksTUFBTSxnQkFBZ0I7R0FDakQsSUFBSSxZQUFZLFFBQVEsbUNBQW1DLElBQUksSUFDN0QsT0FBTyxpQkFBaUIsTUFBTSxjQUFjLENBQUMsQ0FBQyxTQUFTO0dBR3pELEtBQ0csYUFBYUEsY0FBTSxXQUFXLElBQUksTUFDbkMsWUFBWSxRQUFRLHFCQUFxQixJQUFJLElBQzdDO0lBQ0EsTUFBTSxNQUFNLElBQUksTUFBTSxLQUFLO0lBQzNCLE1BQU0sWUFBWSxPQUFPLElBQUk7SUFFN0IsT0FBT0UsYUFDTCxhQUFhLEVBQUUsV0FBVyxLQUFLLElBQUksTUFDbkMsYUFBYSxJQUFJLFVBQVUsR0FDM0IsY0FDRjtHQUNGO0VBQ0Y7RUFFQSxJQUFJLG1CQUFtQixvQkFBb0I7R0FDekMsUUFBUSxlQUFlLG9CQUFvQixLQUFLO0dBQ2hELE9BQU8sZ0JBQWdCLElBQUk7RUFDN0I7RUFFQSxPQUFPO0NBQ1QsQ0FDRjtDQUVBLG1CQUFtQixDQUNqQixTQUFTLGtCQUFrQixNQUFNO0VBQy9CLE1BQU0sZUFBZSxJQUFJLE1BQU0sY0FBYyxLQUFLLFNBQVM7RUFDM0QsTUFBTSxvQkFBb0IsZ0JBQWdCLGFBQWE7RUFDdkQsTUFBTSxlQUFlLElBQUksTUFBTSxjQUFjO0VBQzdDLE1BQU0sZ0JBQWdCLGlCQUFpQjtFQUV2QyxJQUFJRixjQUFNLFdBQVcsSUFBSSxLQUFLQSxjQUFNLGlCQUFpQixJQUFJLEdBQ3ZELE9BQU87RUFHVCxJQUNFLFFBQ0FBLGNBQU0sU0FBUyxJQUFJLE1BQ2pCLHFCQUFxQixDQUFDLGdCQUFpQixnQkFDekM7R0FFQSxNQUFNLG9CQUFvQixFQURBLGdCQUFnQixhQUFhLHNCQUNQO0dBRWhELElBQUk7SUFDRixPQUFPLEtBQUssTUFBTSxNQUFNLElBQUksTUFBTSxjQUFjLENBQUM7R0FDbkQsU0FBUyxHQUFHO0lBQ1YsSUFBSSxtQkFBbUI7S0FDckIsSUFBSSxFQUFFLFNBQVMsZUFDYixNQUFNRyxhQUFXLEtBQUssR0FBR0EsYUFBVyxrQkFBa0IsTUFBTSxNQUFNLElBQUksTUFBTSxVQUFVLENBQUM7S0FFekYsTUFBTTtJQUNSO0dBQ0Y7RUFDRjtFQUVBLE9BQU87Q0FDVCxDQUNGOzs7OztDQU1BLFNBQVM7Q0FFVCxnQkFBZ0I7Q0FDaEIsZ0JBQWdCO0NBRWhCLGtCQUFrQjtDQUNsQixlQUFlO0NBRWYsS0FBSztFQUNILFVBQVVDLGlCQUFTLFFBQVE7RUFDM0IsTUFBTUEsaUJBQVMsUUFBUTtDQUN6QjtDQUVBLGdCQUFnQixTQUFTLGVBQWUsUUFBUTtFQUM5QyxPQUFPLFVBQVUsT0FBTyxTQUFTO0NBQ25DO0NBRUEsU0FBUyxFQUNQLFFBQVE7RUFDTixRQUFRO0VBQ1IsZ0JBQWdCLEtBQUE7Q0FDbEIsRUFDRjtBQUNGO0FBRUFKLGNBQU0sUUFBUSxhQUFhLFdBQVc7Q0FDcEMsU0FBUyxRQUFRLFVBQVUsQ0FBQztBQUM5QixDQUFDOzs7Ozs7Ozs7OztBQ2pLRCxTQUF3QixjQUFjLEtBQUssVUFBVTtDQUNuRCxNQUFNLFNBQVMsUUFBUTtDQUN2QixNQUFNLFVBQVUsWUFBWTtDQUM1QixNQUFNLFVBQVVLLGVBQWEsS0FBSyxRQUFRLE9BQU87Q0FDakQsSUFBSSxPQUFPLFFBQVE7Q0FFbkIsY0FBTSxRQUFRLEtBQUssU0FBUyxVQUFVLElBQUk7RUFDeEMsT0FBTyxHQUFHLEtBQUssUUFBUSxNQUFNLFFBQVEsVUFBVSxHQUFHLFdBQVcsU0FBUyxTQUFTLEtBQUEsQ0FBUztDQUMxRixDQUFDO0NBRUQsUUFBUSxVQUFVO0NBRWxCLE9BQU87QUFDVDs7O0FDekJBLFNBQXdCQyxXQUFTLE9BQU87Q0FDdEMsT0FBTyxDQUFDLEVBQUUsU0FBUyxNQUFNO0FBQzNCOzs7QUNBQSxJQUFNQyxrQkFBTixjQUE0QkMsYUFBVzs7Ozs7Ozs7OztDQVVyQyxZQUFZLFNBQVMsUUFBUSxTQUFTO0VBQ3BDLE1BQU0sV0FBVyxPQUFPLGFBQWEsU0FBU0EsYUFBVyxjQUFjLFFBQVEsT0FBTztFQUN0RixLQUFLLE9BQU87RUFDWixLQUFLLGFBQWE7Q0FDcEI7QUFDRjs7Ozs7Ozs7Ozs7O0FDTkEsU0FBd0IsT0FBTyxTQUFTLFFBQVEsVUFBVTtDQUN4RCxNQUFNLGlCQUFpQixTQUFTLE9BQU87Q0FDdkMsSUFBSSxDQUFDLFNBQVMsVUFBVSxDQUFDLGtCQUFrQixlQUFlLFNBQVMsTUFBTSxHQUN2RSxRQUFRLFFBQVE7TUFFaEIsT0FBTyxJQUFJQyxhQUNULHFDQUFxQyxTQUFTLFFBQzlDLFNBQVMsVUFBVSxPQUFPLFNBQVMsU0FBUyxNQUFNQSxhQUFXLGtCQUFrQkEsYUFBVyxrQkFDMUYsU0FBUyxRQUNULFNBQVMsU0FDVCxRQUNGLENBQUM7QUFFTDs7O0FDeEJBLElBQU0sNkJBQTZCOzs7Ozs7OztBQVNuQyxTQUF3Qiw2QkFBNkIsS0FBSztDQUN4RCxJQUFJLE9BQU8sUUFBUSxVQUNqQixPQUFPO0NBR1QsSUFBSSxRQUFRO0NBRVosT0FBTyxRQUFRLElBQUksVUFBVSxJQUFJLFdBQVcsS0FBSyxLQUFLLElBQ3BEO0NBR0YsT0FBTyxJQUFJLE1BQU0sS0FBSyxDQUFDLENBQUMsUUFBUSw0QkFBNEIsRUFBRTtBQUNoRTs7O0FDckJBLFNBQXdCLGNBQWMsS0FBSztDQUN6QyxNQUFNLFFBQVEsNEJBQTRCLEtBQUssR0FBRztDQUNsRCxPQUFRLFNBQVMsTUFBTSxNQUFPO0FBQ2hDOzs7Ozs7Ozs7QUNHQSxTQUFTLFlBQVksY0FBYyxLQUFLO0NBQ3RDLGVBQWUsZ0JBQWdCO0NBQy9CLE1BQU0sUUFBUSxJQUFJLE1BQU0sWUFBWTtDQUNwQyxNQUFNLGFBQWEsSUFBSSxNQUFNLFlBQVk7Q0FDekMsSUFBSSxPQUFPO0NBQ1gsSUFBSSxPQUFPO0NBQ1gsSUFBSTtDQUVKLE1BQU0sUUFBUSxLQUFBLElBQVksTUFBTTtDQUVoQyxPQUFPLFNBQVMsS0FBSyxhQUFhO0VBQ2hDLE1BQU0sTUFBTSxLQUFLLElBQUk7RUFFckIsTUFBTSxZQUFZLFdBQVc7RUFFN0IsSUFBSSxDQUFDLGVBQ0gsZ0JBQWdCO0VBR2xCLE1BQU0sUUFBUTtFQUNkLFdBQVcsUUFBUTtFQUVuQixJQUFJLElBQUk7RUFDUixJQUFJLGFBQWE7RUFFakIsT0FBTyxNQUFNLE1BQU07R0FDakIsY0FBYyxNQUFNO0dBQ3BCLElBQUksSUFBSTtFQUNWO0VBRUEsUUFBUSxPQUFPLEtBQUs7RUFFcEIsSUFBSSxTQUFTLE1BQ1gsUUFBUSxPQUFPLEtBQUs7RUFHdEIsSUFBSSxNQUFNLGdCQUFnQixLQUN4QjtFQUdGLE1BQU0sU0FBUyxhQUFhLE1BQU07RUFFbEMsT0FBTyxTQUFTLEtBQUssTUFBTyxhQUFhLE1BQVEsTUFBTSxJQUFJLEtBQUE7Q0FDN0Q7QUFDRjs7Ozs7Ozs7O0FDOUNBLFNBQVMsU0FBUyxJQUFJLE1BQU07Q0FDMUIsSUFBSSxZQUFZO0NBQ2hCLElBQUksWUFBWSxNQUFPO0NBQ3ZCLElBQUk7Q0FDSixJQUFJO0NBRUosTUFBTSxVQUFVLE1BQU0sTUFBTSxLQUFLLElBQUksTUFBTTtFQUN6QyxZQUFZO0VBQ1osV0FBVztFQUNYLElBQUksT0FBTztHQUNULGFBQWEsS0FBSztHQUNsQixRQUFRO0VBQ1Y7RUFDQSxHQUFHLEdBQUcsSUFBSTtDQUNaO0NBRUEsTUFBTSxhQUFhLEdBQUcsU0FBUztFQUM3QixNQUFNLE1BQU0sS0FBSyxJQUFJO0VBQ3JCLE1BQU0sU0FBUyxNQUFNO0VBQ3JCLElBQUksVUFBVSxXQUNaLE9BQU8sTUFBTSxHQUFHO09BQ1g7R0FDTCxXQUFXO0dBQ1gsSUFBSSxDQUFDLE9BQ0gsUUFBUSxpQkFBaUI7SUFDdkIsUUFBUTtJQUNSLE9BQU8sUUFBUTtHQUNqQixHQUFHLFlBQVksTUFBTTtFQUV6QjtDQUNGO0NBRUEsTUFBTSxjQUFjLFlBQVksT0FBTyxRQUFRO0NBQy9DLE1BQU0sYUFBYSxHQUFHLFNBQVMsT0FBTyxJQUFJO0NBRTFDLE9BQU87RUFBQztFQUFXO0VBQU87Q0FBUztBQUNyQzs7O0FDdENBLElBQWEsd0JBQXdCLFVBQVUsa0JBQWtCLE9BQU8sTUFBTTtDQUM1RSxJQUFJLGdCQUFnQjtDQUNwQixNQUFNLGVBQWUsWUFBWSxJQUFJLEdBQUc7Q0FFeEMsT0FBTyxVQUFVLE1BQU07RUFDckIsSUFBSSxDQUFDLEtBQUssQ0FBQ0MsY0FBTSxTQUFTLEVBQUUsTUFBTSxHQUNoQztFQUVGLE1BQU0sWUFBWSxFQUFFO0VBQ3BCLE1BQU0sUUFBUSxFQUFFLG1CQUFtQixFQUFFLFFBQVEsS0FBQTtFQUM3QyxNQUFNLFNBQVMsS0FBSyxJQUFJLEdBQUcsU0FBUyxPQUFPLEtBQUssSUFBSSxXQUFXLEtBQUssSUFBSSxTQUFTO0VBQ2pGLE1BQU0sZ0JBQWdCLEtBQUssSUFBSSxHQUFHLFNBQVMsYUFBYTtFQUN4RCxNQUFNLE9BQU8sYUFBYSxhQUFhO0VBRXZDLGdCQUFnQixLQUFLLElBQUksZUFBZSxNQUFNO0VBYzlDLFNBQVM7R0FYUDtHQUNBO0dBQ0EsVUFBVSxRQUFRLFNBQVMsUUFBUSxLQUFBO0dBQ25DLE9BQU87R0FDUCxNQUFNLE9BQU8sT0FBTyxLQUFBO0dBQ3BCLFdBQVcsUUFBUSxTQUFTLFFBQVEsVUFBVSxPQUFPLEtBQUE7R0FDckQsT0FBTztHQUNQLGtCQUFrQixTQUFTO0lBQzFCLG1CQUFtQixhQUFhLFdBQVc7RUFHbEMsQ0FBQztDQUNmLEdBQUcsSUFBSTtBQUNUO0FBRUEsSUFBYSwwQkFBMEIsT0FBTyxjQUFjO0NBQzFELE1BQU0sbUJBQW1CLFNBQVM7Q0FFbEMsT0FBTyxFQUNKLFdBQ0MsVUFBVSxFQUFFLENBQUM7RUFDWDtFQUNBO0VBQ0E7Q0FDRixDQUFDLEdBQ0gsVUFBVSxFQUNaO0FBQ0Y7QUFFQSxJQUFhLGtCQUNWLElBQUksWUFBWUEsY0FBTSxVQUN0QixHQUFHLFNBQ0YsZ0JBQWdCLEdBQUcsR0FBRyxJQUFJLENBQUM7OztBQ25EL0IsSUFBQSwwQkFBZUMsaUJBQVMsMEJBQ2xCLFFBQVEsWUFBWSxRQUFRO0NBQzVCLE1BQU0sSUFBSSxJQUFJLEtBQUtBLGlCQUFTLE1BQU07Q0FFbEMsT0FDRSxPQUFPLGFBQWEsSUFBSSxZQUN4QixPQUFPLFNBQVMsSUFBSSxTQUNuQixVQUFVLE9BQU8sU0FBUyxJQUFJO0FBRW5DLEVBQUEsQ0FDRSxJQUFJLElBQUlBLGlCQUFTLE1BQU0sR0FDdkJBLGlCQUFTLGFBQWEsa0JBQWtCLEtBQUtBLGlCQUFTLFVBQVUsU0FBUyxDQUMzRSxVQUNNOzs7QUNaVixJQUFBLGtCQUFlQyxpQkFBUyx3QkFFcEI7Q0FDRSxNQUFNLE1BQU0sT0FBTyxTQUFTLE1BQU0sUUFBUSxRQUFRLFVBQVU7RUFDMUQsSUFBSSxPQUFPLGFBQWEsYUFBYTtFQUVyQyxNQUFNLFNBQVMsQ0FBQyxHQUFHLEtBQUssR0FBRyxtQkFBbUIsS0FBSyxHQUFHO0VBRXRELElBQUlDLGNBQU0sU0FBUyxPQUFPLEdBQ3hCLE9BQU8sS0FBSyxXQUFXLElBQUksS0FBSyxPQUFPLENBQUMsQ0FBQyxZQUFZLEdBQUc7RUFFMUQsSUFBSUEsY0FBTSxTQUFTLElBQUksR0FDckIsT0FBTyxLQUFLLFFBQVEsTUFBTTtFQUU1QixJQUFJQSxjQUFNLFNBQVMsTUFBTSxHQUN2QixPQUFPLEtBQUssVUFBVSxRQUFRO0VBRWhDLElBQUksV0FBVyxNQUNiLE9BQU8sS0FBSyxRQUFRO0VBRXRCLElBQUlBLGNBQU0sU0FBUyxRQUFRLEdBQ3pCLE9BQU8sS0FBSyxZQUFZLFVBQVU7RUFHcEMsU0FBUyxTQUFTLE9BQU8sS0FBSyxJQUFJO0NBQ3BDO0NBRUEsS0FBSyxNQUFNO0VBQ1QsSUFBSSxPQUFPLGFBQWEsYUFBYSxPQUFPO0VBTTVDLE1BQU0sVUFBVSxTQUFTLE9BQU8sTUFBTSxHQUFHO0VBQ3pDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLFFBQVEsS0FBSztHQUN2QyxNQUFNLFNBQVMsUUFBUSxFQUFFLENBQUMsUUFBUSxRQUFRLEVBQUU7R0FDNUMsTUFBTSxLQUFLLE9BQU8sUUFBUSxHQUFHO0dBQzdCLElBQUksT0FBTyxNQUFNLE9BQU8sTUFBTSxHQUFHLEVBQUUsTUFBTSxNQUN2QyxJQUFJO0lBQ0YsT0FBTyxtQkFBbUIsT0FBTyxNQUFNLEtBQUssQ0FBQyxDQUFDO0dBQ2hELFNBQVMsR0FBRztJQUNWLE9BQU8sT0FBTyxNQUFNLEtBQUssQ0FBQztHQUM1QjtFQUVKO0VBQ0EsT0FBTztDQUNUO0NBRUEsT0FBTyxNQUFNO0VBQ1gsS0FBSyxNQUFNLE1BQU0sSUFBSSxLQUFLLElBQUksSUFBSSxPQUFVLEdBQUc7Q0FDakQ7QUFDRixJQUVBO0NBQ0UsUUFBUSxDQUFDO0NBQ1QsT0FBTztFQUNMLE9BQU87Q0FDVDtDQUNBLFNBQVMsQ0FBQztBQUNaOzs7Ozs7Ozs7O0FDdERKLFNBQXdCLGNBQWMsS0FBSztDQUl6QyxJQUFJLE9BQU8sUUFBUSxVQUNqQixPQUFPO0NBR1QsT0FBTyw4QkFBOEIsS0FBSyxHQUFHO0FBQy9DOzs7Ozs7Ozs7OztBQ1JBLFNBQXdCLFlBQVksU0FBUyxhQUFhO0NBQ3hELElBQUksQ0FBQyxhQUNILE9BQU87Q0FHVCxJQUFJLE1BQU0sUUFBUTtDQUVsQixPQUFPLE1BQU0sS0FBSyxRQUFRLFdBQVcsTUFBTSxDQUFDLE1BQU0sSUFDaEQ7Q0FHRixPQUFPLFFBQVEsTUFBTSxHQUFHLEdBQUcsSUFBSSxNQUFNLFlBQVksUUFBUSxRQUFRLEVBQUU7QUFDckU7OztBQ2ZBLElBQU0sd0JBQXdCO0FBVTlCLFNBQVMsZUFBZSxVQUFVO0NBQ2hDLElBQUksQ0FBQyxVQUNILE9BQU87Q0FHVCxPQUFPLFNBQVMsUUFBUSwwQkFBMEIsT0FBTyxXQUFXLGdCQUFnQixPQUFPO0VBQ3pGLE9BQU8sR0FBRyxZQUFZLGdCQUFnQjtDQUN4QyxDQUFDO0FBQ0g7QUFFQSxTQUFTLHdCQUF3QixLQUFLO0NBQ3BDLE1BQU0sY0FBYyxJQUFJLFFBQVEsOEJBQThCLEtBQUssU0FBUyxFQUFFO0NBQzlFLE1BQU0sZ0JBQWdCLFlBQVksUUFBUSxHQUFHO0NBRzdDLE1BQU0sOEJBREosa0JBQWtCLEtBQUssY0FBYyxZQUFZLE1BQU0sR0FBRyxhQUFhLEVBQUEsQ0FDbkIsUUFDcEQseUJBQ0EsS0FBSyxVQUNQO0NBRUEsSUFBSSxrQkFBa0IsSUFDcEIsT0FBTztDQUdULE9BQU8sR0FBRywyQkFBMkIsR0FBRyxlQUFlLFlBQVksTUFBTSxnQkFBZ0IsQ0FBQyxDQUFDO0FBQzdGO0FBRUEsU0FBUywyQkFBMkIsS0FBSyxRQUFRO0NBQy9DLElBQUksT0FBTyxRQUFRLFVBQVU7RUFDM0IsTUFBTSxnQkFBZ0IsNkJBQTZCLEdBQUc7RUFDdEQsSUFBSSxzQkFBc0IsS0FBSyxhQUFhLEdBQzFDLE1BQU0sSUFBSUMsYUFDUixlQUFlLEtBQUssVUFBVSx3QkFBd0IsYUFBYSxDQUFDLEVBQUUsZ0NBQ3RFQSxhQUFXLGlCQUNYLE1BQ0Y7Q0FFSjtBQUNGOzs7Ozs7Ozs7OztBQVlBLFNBQXdCLGNBQWMsU0FBUyxjQUFjLG1CQUFtQixRQUFRO0NBQ3RGLDJCQUEyQixjQUFjLE1BQU07Q0FDL0MsSUFBSSxnQkFBZ0IsQ0FBQyxjQUFjLFlBQVk7Q0FDL0MsSUFBSSxZQUFZLGlCQUFpQixzQkFBc0IsUUFBUTtFQUM3RCwyQkFBMkIsU0FBUyxNQUFNO0VBQzFDLE9BQU8sWUFBWSxTQUFTLFlBQVk7Q0FDMUM7Q0FDQSxPQUFPO0FBQ1Q7OztBQ3RFQSxJQUFNLG1CQUFtQixVQUFXLGlCQUFpQkMsaUJBQWUsRUFBRSxHQUFHLE1BQU0sSUFBSTtBQUVuRixJQUFNLHFCQUFxQixVQUFVO0NBQ25DLElBQUksT0FBTyx5QkFBeUIsT0FBTywwQkFDekMsT0FBTyxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsT0FDeEIsT0FBTyxzQkFBc0IsS0FBSyxDQUFDLENBQUMsUUFDakMsV0FBVyxPQUFPLHlCQUF5QixPQUFPLE1BQU0sQ0FBQyxDQUFDLFVBQzdELENBQ0Y7Q0FFRixPQUFPLE9BQU8sS0FBSyxLQUFLO0FBQzFCOzs7Ozs7Ozs7O0FBV0EsU0FBd0JDLGNBQVksU0FBUyxTQUFTO0NBRXBELFVBQVUsV0FBVyxDQUFDO0NBQ3RCLFVBQVUsV0FBVyxDQUFDO0NBTXRCLE1BQU0sU0FBUyxPQUFPLE9BQU8sSUFBSTtDQUNqQyxPQUFPLGVBQWUsUUFBUSxrQkFBa0I7RUFHOUMsV0FBVztFQUNYLE9BQU8sT0FBTyxVQUFVO0VBQ3hCLFlBQVk7RUFDWixVQUFVO0VBQ1YsY0FBYztDQUNoQixDQUFDO0NBRUQsU0FBUyxlQUFlLFFBQVEsUUFBUSxNQUFNLFVBQVU7RUFDdEQsSUFBSUMsY0FBTSxjQUFjLE1BQU0sS0FBS0EsY0FBTSxjQUFjLE1BQU0sR0FDM0QsT0FBT0EsY0FBTSxNQUFNLEtBQUssRUFBRSxTQUFTLEdBQUcsUUFBUSxNQUFNO09BQy9DLElBQUlBLGNBQU0sY0FBYyxNQUFNLEdBQ25DLE9BQU9BLGNBQU0sTUFBTSxDQUFDLEdBQUcsTUFBTTtPQUN4QixJQUFJQSxjQUFNLFFBQVEsTUFBTSxHQUM3QixPQUFPLE9BQU8sTUFBTTtFQUV0QixPQUFPO0NBQ1Q7Q0FFQSxTQUFTLG9CQUFvQixHQUFHLEdBQUcsTUFBTSxVQUFVO0VBQ2pELElBQUksQ0FBQ0EsY0FBTSxZQUFZLENBQUMsR0FDdEIsT0FBTyxlQUFlLEdBQUcsR0FBRyxNQUFNLFFBQVE7T0FDckMsSUFBSSxDQUFDQSxjQUFNLFlBQVksQ0FBQyxHQUM3QixPQUFPLGVBQWUsS0FBQSxHQUFXLEdBQUcsTUFBTSxRQUFRO0NBRXREO0NBR0EsU0FBUyxpQkFBaUIsR0FBRyxHQUFHO0VBQzlCLElBQUksQ0FBQ0EsY0FBTSxZQUFZLENBQUMsR0FDdEIsT0FBTyxlQUFlLEtBQUEsR0FBVyxDQUFDO0NBRXRDO0NBR0EsU0FBUyxpQkFBaUIsR0FBRyxHQUFHO0VBQzlCLElBQUksQ0FBQ0EsY0FBTSxZQUFZLENBQUMsR0FDdEIsT0FBTyxlQUFlLEtBQUEsR0FBVyxDQUFDO09BQzdCLElBQUksQ0FBQ0EsY0FBTSxZQUFZLENBQUMsR0FDN0IsT0FBTyxlQUFlLEtBQUEsR0FBVyxDQUFDO0NBRXRDO0NBRUEsU0FBUyw0QkFBNEIsTUFBTTtFQUN6QyxNQUFNLGdCQUFnQkEsY0FBTSxXQUFXLFNBQVMsY0FBYyxJQUMxRCxRQUFRLGVBQ1IsS0FBQTtFQUVKLElBQUksQ0FBQ0EsY0FBTSxZQUFZLGFBQWEsR0FBRztHQUNyQyxJQUFJQSxjQUFNLGNBQWMsYUFBYSxHQUMvQkE7UUFBQUEsY0FBTSxXQUFXLGVBQWUsSUFBSSxHQUN0QyxPQUFPLGNBQWM7R0FBQSxPQUd2QjtFQUVKO0VBRUEsTUFBTSxnQkFBZ0JBLGNBQU0sV0FBVyxTQUFTLGNBQWMsSUFDMUQsUUFBUSxlQUNSLEtBQUE7RUFFSixJQUFJQSxjQUFNLGNBQWMsYUFBYSxLQUFLQSxjQUFNLFdBQVcsZUFBZSxJQUFJLEdBQzVFLE9BQU8sY0FBYztDQUl6QjtDQUdBLFNBQVMsZ0JBQWdCLEdBQUcsR0FBRyxNQUFNO0VBQ25DLElBQUlBLGNBQU0sV0FBVyxTQUFTLElBQUksR0FDaEMsT0FBTyxlQUFlLEdBQUcsQ0FBQztPQUNyQixJQUFJQSxjQUFNLFdBQVcsU0FBUyxJQUFJLEdBQ3ZDLE9BQU8sZUFBZSxLQUFBLEdBQVcsQ0FBQztDQUV0QztDQUVBLE1BQU0sV0FBVztFQUNmLEtBQUs7RUFDTCxRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7RUFDVCxrQkFBa0I7RUFDbEIsbUJBQW1CO0VBQ25CLGtCQUFrQjtFQUNsQixTQUFTO0VBQ1QscUJBQXFCO0VBQ3JCLGlCQUFpQjtFQUNqQixlQUFlO0VBQ2YsU0FBUztFQUNULGNBQWM7RUFDZCxnQkFBZ0I7RUFDaEIsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixvQkFBb0I7RUFDcEIsWUFBWTtFQUNaLGtCQUFrQjtFQUNsQixlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLFdBQVc7RUFDWCxXQUFXO0VBQ1gsWUFBWTtFQUNaLGFBQWE7RUFDYixZQUFZO0VBQ1osb0JBQW9CO0VBQ3BCLGtCQUFrQjtFQUNsQixnQkFBZ0I7RUFDaEIsVUFBVSxHQUFHLEdBQUcsU0FDZCxvQkFBb0IsZ0JBQWdCLENBQUMsR0FBRyxnQkFBZ0IsQ0FBQyxHQUFHLE1BQU0sSUFBSTtDQUMxRTtDQUVBLGNBQU0sUUFBUSxrQkFBa0I7RUFBRSxHQUFHO0VBQVMsR0FBRztDQUFRLENBQUMsR0FBRyxTQUFTLG1CQUFtQixNQUFNO0VBQzdGLElBQUksU0FBUyxlQUFlLFNBQVMsaUJBQWlCLFNBQVMsYUFBYTtFQUM1RSxNQUFNLFFBQVFBLGNBQU0sV0FBVyxVQUFVLElBQUksSUFBSSxTQUFTLFFBQVE7RUFHbEUsTUFBTSxjQUFjLE1BRlZBLGNBQU0sV0FBVyxTQUFTLElBQUksSUFBSSxRQUFRLFFBQVEsS0FBQSxHQUNsREEsY0FBTSxXQUFXLFNBQVMsSUFBSSxJQUFJLFFBQVEsUUFBUSxLQUFBLEdBQzVCLElBQUk7RUFDcEMsY0FBTyxZQUFZLFdBQVcsS0FBSyxVQUFVLG9CQUFxQixPQUFPLFFBQVE7Q0FDbkYsQ0FBQztDQUVELElBQ0VBLGNBQU0sV0FBVyxTQUFTLGdCQUFnQixLQUMxQ0EsY0FBTSxZQUFZLFFBQVEsY0FBYyxLQUN4Qyw0QkFBNEIsaUNBQWlDLE1BQU0sT0FDbkU7RUFDQSxJQUFJQSxjQUFNLFdBQVcsU0FBUyxnQkFBZ0IsR0FDNUMsT0FBTyxpQkFBaUIsZUFBZSxLQUFBLEdBQVcsUUFBUSxjQUFjO09BRXhFLE9BQU8sT0FBTztDQUVsQjtDQUVBLE9BQU87QUFDVDs7O0FDM0tBLElBQU0sNEJBQTRCLENBQUMsZ0JBQWdCLGdCQUFnQjs7Ozs7Ozs7Ozs7O0FBYW5FLFNBQXdCLG1CQUFtQixTQUFTLGFBQWEsUUFBUTtDQUN2RSxJQUFJLFdBQVcsZ0JBQWdCO0VBQzdCLFFBQVEsSUFBSSxXQUFXO0VBQ3ZCO0NBQ0Y7Q0FFQSxPQUFPLFFBQVEsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLFNBQVM7RUFDeEQsSUFBSSwwQkFBMEIsU0FBUyxJQUFJLFlBQVksQ0FBQyxHQUN0RCxRQUFRLElBQUksS0FBSyxHQUFHO0NBRXhCLENBQUM7QUFDSDs7Ozs7Ozs7Ozs7QUNQQSxJQUFNQyxnQkFBYyxRQUNsQixtQkFBbUIsR0FBRyxDQUFDLENBQUMsUUFBUSxxQkFBcUIsR0FBRyxRQUN0RCxPQUFPLGFBQWEsU0FBUyxLQUFLLEVBQUUsQ0FBQyxDQUN2QztBQUVGLFNBQVMsY0FBYyxRQUFRO0NBQzdCLE1BQU0sWUFBWUMsY0FBWSxDQUFDLEdBQUcsTUFBTTtDQUl4QyxNQUFNLE9BQU8sUUFBU0MsY0FBTSxXQUFXLFdBQVcsR0FBRyxJQUFJLFVBQVUsT0FBTyxLQUFBO0NBRTFFLE1BQU0sT0FBTyxJQUFJLE1BQU07Q0FDdkIsSUFBSSxnQkFBZ0IsSUFBSSxlQUFlO0NBQ3ZDLE1BQU0saUJBQWlCLElBQUksZ0JBQWdCO0NBQzNDLE1BQU0saUJBQWlCLElBQUksZ0JBQWdCO0NBQzNDLElBQUksVUFBVSxJQUFJLFNBQVM7Q0FDM0IsTUFBTSxPQUFPLElBQUksTUFBTTtDQUN2QixNQUFNLFVBQVUsSUFBSSxTQUFTO0NBQzdCLE1BQU0sb0JBQW9CLElBQUksbUJBQW1CO0NBQ2pELE1BQU0sTUFBTSxJQUFJLEtBQUs7Q0FFckIsVUFBVSxVQUFVLFVBQVVDLGVBQWEsS0FBSyxPQUFPO0NBRXZELFVBQVUsTUFBTSxTQUNkLGNBQWMsU0FBUyxLQUFLLG1CQUFtQixTQUFTLEdBQ3hELElBQUksUUFBUSxHQUNaLElBQUksa0JBQWtCLENBQ3hCO0NBR0EsSUFBSSxNQUFNO0VBQ1IsTUFBTSxXQUFXRCxjQUFNLFlBQVksTUFBTSxVQUFVLEtBQUs7RUFDeEQsTUFBTSxXQUFXQSxjQUFNLFlBQVksTUFBTSxVQUFVLEtBQUs7RUFFeEQsSUFBSTtHQUNGLFFBQVEsSUFDTixpQkFDQSxXQUFXLEtBQUssV0FBVyxPQUFPLFdBQVdGLGFBQVcsUUFBUSxJQUFJLEdBQUcsQ0FDekU7RUFDRixTQUFTLEdBQUc7R0FDVixNQUFNSSxhQUFXLEtBQUssR0FBR0EsYUFBVyxzQkFBc0IsTUFBTTtFQUNsRTtDQUNGO0NBRUEsSUFBSUYsY0FBTSxXQUFXLElBQUksR0FBRztFQUMxQixNQUFNLGFBQWFBLGNBQU0sWUFBWSxNQUFNLFlBQVk7RUFFdkQsSUFDRUcsaUJBQVMseUJBQ1RBLGlCQUFTLGtDQUNUSCxjQUFNLGNBQWMsSUFBSSxHQUV4QixRQUFRLGVBQWUsS0FBQSxDQUFTO09BQzNCLElBQUlBLGNBQU0sV0FBVyxVQUFVLEdBRXBDLG1CQUFtQixTQUFTLFdBQVcsS0FBSyxJQUFJLEdBQUcsSUFBSSxzQkFBc0IsQ0FBQztDQUVsRjtDQU1BLElBQUlHLGlCQUFTLHVCQUF1QjtFQUNsQyxJQUFJSCxjQUFNLFdBQVcsYUFBYSxHQUNoQyxnQkFBZ0IsY0FBYyxTQUFTO0VBU3pDLElBRkUsa0JBQWtCLFFBQVMsaUJBQWlCLFFBQVFJLHdCQUFnQixVQUFVLEdBQUcsR0FFL0Q7R0FDbEIsTUFBTSxZQUFZLGtCQUFrQixrQkFBa0JDLGdCQUFRLEtBQUssY0FBYztHQUVqRixJQUFJLFdBQ0YsUUFBUSxJQUFJLGdCQUFnQixTQUFTO0VBRXpDO0NBQ0Y7Q0FFQSxPQUFPO0FBQ1Q7QUN6RkEsSUFBQSxjQUY4QixPQUFPLG1CQUFtQixlQUd0RCxTQUFVLFFBQVE7Q0FDaEIsT0FBTyxJQUFJLFFBQVEsU0FBUyxtQkFBbUIsU0FBUyxRQUFRO0VBQzlELE1BQU0sVUFBVSxjQUFjLE1BQU07RUFDcEMsSUFBSSxjQUFjLFFBQVE7RUFDMUIsTUFBTSxpQkFBaUJDLGVBQWEsS0FBSyxRQUFRLE9BQU8sQ0FBQyxDQUFDLFVBQVU7RUFDcEUsSUFBSSxFQUFFLGNBQWMsa0JBQWtCLHVCQUF1QjtFQUM3RCxJQUFJO0VBQ0osSUFBSSxpQkFBaUI7RUFDckIsSUFBSSxhQUFhLGVBQWU7RUFFaEMsU0FBUyxPQUFPO0dBQ2QsZUFBZSxZQUFZO0dBQzNCLGlCQUFpQixjQUFjO0dBRS9CLFFBQVEsZUFBZSxRQUFRLFlBQVksWUFBWSxVQUFVO0dBRWpFLFFBQVEsVUFBVSxRQUFRLE9BQU8sb0JBQW9CLFNBQVMsVUFBVTtFQUMxRTtFQUVBLElBQUksVUFBVSxJQUFJLGVBQWU7RUFFakMsUUFBUSxLQUFLLFFBQVEsT0FBTyxZQUFZLEdBQUcsUUFBUSxLQUFLLElBQUk7RUFHNUQsUUFBUSxVQUFVLFFBQVE7RUFFMUIsU0FBUyxVQUFVLE9BQU87R0FDeEIsSUFBSSxDQUFDLFNBQ0g7R0FXRixJQUNFLFFBQVEsV0FBVyxNQUNsQixjQUFjLDZCQUE2QixRQUFRLEdBQUcsQ0FBQyxLQUN0RCxjQUFjQyxpQkFBUyxNQUFNLE9BQU8sVUFDdEMsRUFBRSxRQUFRLGVBQWUsUUFBUSxZQUFZLFdBQVcsT0FBTyxJQUMvRDtJQUNBLE9BQU8sSUFBSUMsYUFBVyxtQkFBbUJBLGFBQVcsY0FBYyxRQUFRLE9BQU8sQ0FBQztJQUNsRixLQUFLO0lBR0wsVUFBVTtJQUNWO0dBQ0Y7R0FPQSxJQUFJO0lBQ0YsSUFBSSxPQUNGLDBCQUEwQix1QkFBdUIsS0FBSztTQUV0RCxpQkFBaUIsY0FBYztHQUVuQyxTQUFTLEtBQUs7SUFDWixpQkFBaUI7S0FDZixNQUFNO0lBQ1IsQ0FBQztHQUNIO0dBR0EsSUFBSSxDQUFDLFNBQ0g7R0FJRixNQUFNLGtCQUFrQkYsZUFBYSxLQUNuQywyQkFBMkIsV0FBVyxRQUFRLHNCQUFzQixDQUN0RTtHQWNBLE9BQ0UsU0FBUyxTQUFTLE9BQU87SUFDdkIsUUFBUSxLQUFLO0lBQ2IsS0FBSztHQUNQLEdBQ0EsU0FBUyxRQUFRLEtBQUs7SUFDcEIsT0FBTyxHQUFHO0lBQ1YsS0FBSztHQUNQLEdBQ0E7SUFqQkEsTUFKQSxDQUFDLGdCQUFnQixpQkFBaUIsVUFBVSxpQkFBaUIsU0FDekQsUUFBUSxlQUNSLFFBQVE7SUFHWixRQUFRLFFBQVE7SUFDaEIsWUFBWSxRQUFRO0lBQ3BCLFNBQVM7SUFDVDtJQUNBO0dBWUEsQ0FDRjtHQUdBLFVBQVU7RUFDWjtFQUVBLElBQUksZUFBZSxTQUVqQixRQUFRLFlBQVk7T0FHcEIsUUFBUSxxQkFBcUIsU0FBUyxhQUFhO0dBQ2pELElBQUksQ0FBQyxXQUFXLFFBQVEsZUFBZSxHQUNyQztHQU9GLElBQ0UsUUFBUSxXQUFXLEtBQ25CLEVBQUUsUUFBUSxlQUFlLFFBQVEsWUFBWSxXQUFXLE9BQU8sSUFFL0Q7R0FJRixXQUFXLFNBQVM7RUFDdEI7RUFJRixRQUFRLFVBQVUsU0FBUyxjQUFjO0dBQ3ZDLElBQUksQ0FBQyxTQUNIO0dBR0YsT0FBTyxJQUFJRSxhQUFXLG1CQUFtQkEsYUFBVyxjQUFjLFFBQVEsT0FBTyxDQUFDO0dBQ2xGLEtBQUs7R0FHTCxVQUFVO0VBQ1o7RUFHQSxRQUFRLFVBQVUsU0FBUyxZQUFZLE9BQU87R0FLNUMsTUFBTSxNQUFNLElBQUlBLGFBREosU0FBUyxNQUFNLFVBQVUsTUFBTSxVQUFVLGlCQUNyQkEsYUFBVyxhQUFhLFFBQVEsT0FBTztHQUV2RSxJQUFJLFFBQVEsU0FBUztHQUNyQixPQUFPLEdBQUc7R0FDVixLQUFLO0dBQ0wsVUFBVTtFQUNaO0VBR0EsUUFBUSxZQUFZLFNBQVMsZ0JBQWdCO0dBQzNDLElBQUksc0JBQXNCLFFBQVEsVUFDOUIsZ0JBQWdCLFFBQVEsVUFBVSxnQkFDbEM7R0FDSixNQUFNLGVBQWUsUUFBUSxnQkFBZ0JDO0dBQzdDLElBQUksUUFBUSxxQkFDVixzQkFBc0IsUUFBUTtHQUVoQyxPQUNFLElBQUlELGFBQ0YscUJBQ0EsYUFBYSxzQkFBc0JBLGFBQVcsWUFBWUEsYUFBVyxjQUNyRSxRQUNBLE9BQ0YsQ0FDRjtHQUNBLEtBQUs7R0FHTCxVQUFVO0VBQ1o7RUFHQSxnQkFBZ0IsS0FBQSxLQUFhLGVBQWUsZUFBZSxJQUFJO0VBRy9ELElBQUksc0JBQXNCLFNBQ3hCLGNBQU0sUUFBUSx5QkFBeUIsY0FBYyxHQUFHLFNBQVMsaUJBQWlCLEtBQUssS0FBSztHQUMxRixRQUFRLGlCQUFpQixLQUFLLEdBQUc7RUFDbkMsQ0FBQztFQUlILElBQUksQ0FBQ0UsY0FBTSxZQUFZLFFBQVEsZUFBZSxHQUM1QyxRQUFRLGtCQUFrQixDQUFDLENBQUMsUUFBUTtFQUl0QyxJQUFJLGdCQUFnQixpQkFBaUIsUUFDbkMsUUFBUSxlQUFlLFFBQVE7RUFJakMsSUFBSSxvQkFBb0I7R0FDdEIsQ0FBQyxtQkFBbUIsZUFBZSwwQkFBMEIscUJBQzNELG9CQUNBLElBQ0Y7R0FDQSxRQUFRLGlCQUFpQixZQUFZLGlCQUFpQjtFQUN4RDtFQUdBLElBQUksb0JBQW9CLFFBQVEsUUFBUTtHQUN0QyxDQUFDLGlCQUFpQixlQUFlLHFCQUFxQixnQkFBZ0I7R0FFdEUsUUFBUSxPQUFPLGlCQUFpQixZQUFZLGVBQWU7R0FFM0QsUUFBUSxPQUFPLGlCQUFpQixXQUFXLFdBQVc7RUFDeEQ7RUFFQSxJQUFJLFFBQVEsZUFBZSxRQUFRLFFBQVE7R0FHekMsY0FBYyxXQUFXO0lBQ3ZCLElBQUksQ0FBQyxTQUNIO0lBRUYsT0FBTyxDQUFDLFVBQVUsT0FBTyxPQUFPLElBQUlDLGdCQUFjLE1BQU0sUUFBUSxPQUFPLElBQUksTUFBTTtJQUNqRixRQUFRLE1BQU07SUFDZCxLQUFLO0lBQ0wsVUFBVTtHQUNaO0dBRUEsUUFBUSxlQUFlLFFBQVEsWUFBWSxVQUFVLFVBQVU7R0FDL0QsSUFBSSxRQUFRLFFBQ1YsUUFBUSxPQUFPLFVBQ1gsV0FBVyxJQUNYLFFBQVEsT0FBTyxpQkFBaUIsU0FBUyxVQUFVO0VBRTNEO0VBRUEsTUFBTSxXQUFXLGNBQWMsUUFBUSxHQUFHO0VBRTFDLElBQUksWUFBWSxDQUFDSixpQkFBUyxVQUFVLFNBQVMsUUFBUSxHQUFHO0dBQ3RELE9BQ0UsSUFBSUMsYUFDRiwwQkFBMEIsV0FBVyxLQUNyQ0EsYUFBVyxpQkFDWCxNQUNGLENBQ0Y7R0FDQSxLQUFLO0dBQ0w7RUFDRjtFQUdBLFFBQVEsS0FBSyxlQUFlLElBQUk7Q0FDbEMsQ0FBQztBQUNIOzs7QUNoUkYsSUFBTSxrQkFBa0IsU0FBUyxZQUFZO0NBQzNDLFVBQVUsVUFBVSxRQUFRLE9BQU8sT0FBTyxJQUFJLENBQUM7Q0FFL0MsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLFFBQ3ZCO0NBR0YsTUFBTSxhQUFhLElBQUksZ0JBQWdCO0NBRXZDLElBQUksVUFBVTtDQUVkLE1BQU0sVUFBVSxTQUFVLFFBQVE7RUFDaEMsSUFBSSxDQUFDLFNBQVM7R0FDWixVQUFVO0dBQ1YsWUFBWTtHQUNaLE1BQU0sTUFBTSxrQkFBa0IsUUFBUSxTQUFTLEtBQUs7R0FDcEQsV0FBVyxNQUNULGVBQWVJLGVBQ1gsTUFDQSxJQUFJQyxnQkFBYyxlQUFlLFFBQVEsSUFBSSxVQUFVLEdBQUcsQ0FDaEU7RUFDRjtDQUNGO0NBRUEsSUFBSSxRQUNGLFdBQ0EsaUJBQWlCO0VBQ2YsUUFBUTtFQUNSLFFBQVEsSUFBSUQsYUFBVyxjQUFjLFFBQVEsY0FBY0EsYUFBVyxTQUFTLENBQUM7Q0FDbEYsR0FBRyxPQUFPO0NBRVosTUFBTSxvQkFBb0I7RUFDeEIsSUFBSSxDQUFDLFNBQVc7RUFDaEIsU0FBUyxhQUFhLEtBQUs7RUFDM0IsUUFBUTtFQUNSLFFBQVEsU0FBUyxXQUFXO0dBQzFCLE9BQU8sY0FDSCxPQUFPLFlBQVksT0FBTyxJQUMxQixPQUFPLG9CQUFvQixTQUFTLE9BQU87RUFDakQsQ0FBQztFQUNELFVBQVU7Q0FDWjtDQUVBLFFBQVEsU0FBUyxXQUFXO0VBQzFCLElBQUksU0FDRjtFQUdGLElBQUksT0FBTyxTQUFTO0dBQ2xCLFFBQVEsS0FBSyxNQUFNO0dBQ25CO0VBQ0Y7RUFFQSxPQUFPLGlCQUFpQixTQUFTLFNBQVMsRUFBRSxNQUFNLEtBQUssQ0FBQztDQUMxRCxDQUFDO0NBRUQsTUFBTSxFQUFFLFdBQVc7Q0FFbkIsT0FBTyxvQkFBb0JFLGNBQU0sS0FBSyxXQUFXO0NBRWpELE9BQU87QUFDVDs7O0FDakVBLElBQWEsY0FBYyxXQUFXLE9BQU8sV0FBVztDQUN0RCxJQUFJLE1BQU0sTUFBTTtDQUVoQixJQUFJLENBQUMsYUFBYSxNQUFNLFdBQVc7RUFDakMsTUFBTTtFQUNOO0NBQ0Y7Q0FFQSxJQUFJLE1BQU07Q0FDVixJQUFJO0NBRUosT0FBTyxNQUFNLEtBQUs7RUFDaEIsTUFBTSxNQUFNO0VBQ1osTUFBTSxNQUFNLE1BQU0sS0FBSyxHQUFHO0VBQzFCLE1BQU07Q0FDUjtBQUNGO0FBRUEsSUFBYSxZQUFZLGlCQUFpQixVQUFVLFdBQVc7Q0FDN0QsV0FBVyxNQUFNLFNBQVMsV0FBVyxRQUFRLEdBQzNDLE9BQU8sWUFBWSxPQUFPLFNBQVM7QUFFdkM7QUFFQSxJQUFNLGFBQWEsaUJBQWlCLFFBQVE7Q0FDMUMsSUFBSSxPQUFPLE9BQU8sZ0JBQWdCO0VBQ2hDLE9BQU87RUFDUDtDQUNGO0NBRUEsTUFBTSxTQUFTLE9BQU8sVUFBVTtDQUNoQyxJQUFJO0VBQ0YsU0FBUztHQUNQLE1BQU0sRUFBRSxNQUFNLFVBQVUsTUFBTSxPQUFPLEtBQUs7R0FDMUMsSUFBSSxNQUNGO0dBRUYsTUFBTTtFQUNSO0NBQ0YsVUFBVTtFQUNSLE1BQU0sT0FBTyxPQUFPO0NBQ3RCO0FBQ0Y7QUFFQSxJQUFhLGVBQWUsUUFBUSxXQUFXLFlBQVksYUFBYTtDQUN0RSxNQUFNLFdBQVcsVUFBVSxRQUFRLFNBQVM7Q0FFNUMsSUFBSSxRQUFRO0NBQ1osSUFBSTtDQUNKLElBQUksYUFBYSxNQUFNO0VBQ3JCLElBQUksQ0FBQyxNQUFNO0dBQ1QsT0FBTztHQUNQLFlBQVksU0FBUyxDQUFDO0VBQ3hCO0NBQ0Y7Q0FFQSxPQUFPLElBQUksZUFDVDtFQUNFLE1BQU0sS0FBSyxZQUFZO0dBQ3JCLElBQUk7SUFDRixNQUFNLEVBQUUsTUFBTSxVQUFVLE1BQU0sU0FBUyxLQUFLO0lBRTVDLElBQUksTUFBTTtLQUNSLFVBQVU7S0FDVixXQUFXLE1BQU07S0FDakI7SUFDRjtJQUVBLElBQUksTUFBTSxNQUFNO0lBQ2hCLElBQUksWUFFRixXQUFXLFNBRGlCLEdBQ047SUFFeEIsV0FBVyxRQUFRLElBQUksV0FBVyxLQUFLLENBQUM7R0FDMUMsU0FBUyxLQUFLO0lBQ1osVUFBVSxHQUFHO0lBQ2IsTUFBTTtHQUNSO0VBQ0Y7RUFDQSxPQUFPLFFBQVE7R0FDYixVQUFVLE1BQU07R0FDaEIsT0FBTyxTQUFTLE9BQU87RUFDekI7Q0FDRixHQUNBLEVBQ0UsZUFBZSxFQUNqQixDQUNGO0FBQ0Y7Ozs7Ozs7Ozs7QUNqRkEsSUFBTSxjQUFjLGFBQ2pCLFlBQVksTUFBTSxZQUFZLE1BQzlCLFlBQVksTUFBTSxZQUFZLE1BQzlCLFlBQVksTUFBTSxZQUFZO0FBRWpDLElBQU0sd0JBQXdCLEtBQUssR0FBRyxRQUNwQyxJQUFJLElBQUksT0FBTyxXQUFXLElBQUksV0FBVyxJQUFJLENBQUMsQ0FBQyxLQUFLLFdBQVcsSUFBSSxXQUFXLElBQUksQ0FBQyxDQUFDO0FBRXRGLElBQU0sWUFBWSxhQUFjLFlBQVksS0FBSyxXQUFXLE1BQU0sV0FBVyxPQUFRO0FBRXJGLElBQU0sZ0JBQWdCLGFBQ25CLFlBQVksTUFBTSxZQUFZLE1BQzlCLFlBQVksTUFBTSxZQUFZLE9BQzlCLFlBQVksTUFBTSxZQUFZLE1BQy9CLGFBQWEsTUFDYixhQUFhLE1BQ2IsYUFBYSxNQUNiLGFBQWE7QUFFZixJQUFNLHNCQUFzQixhQUMxQixhQUFhLEtBQUssYUFBYSxNQUFNLGFBQWEsTUFBTSxhQUFhLE1BQU0sYUFBYTtBQUUxRixJQUFNLGVBQWUsZ0JBQWdCO0NBQ25DLE1BQU0sU0FBUyxLQUFLLE1BQU0sY0FBYyxDQUFDO0NBQ3pDLE1BQU0sWUFBWSxjQUFjO0NBQ2hDLE9BQU8sU0FBUyxLQUFLLGNBQWMsSUFBSSxJQUFJLGNBQWMsSUFBSSxJQUFJO0FBQ25FO0FBSUEsSUFBTSxrQ0FBa0MsU0FBUztDQUMvQyxNQUFNLE1BQU0sS0FBSztDQUNqQixJQUFJLFVBQVU7Q0FFZCxJQUFJLE1BQU0sS0FBSyxLQUFLLFdBQVcsTUFBTSxDQUFDLE1BQU0sSUFBYztFQUN4RDtFQUVBLElBQUksTUFBTSxLQUFLLEtBQUssV0FBVyxNQUFNLENBQUMsTUFBTSxJQUMxQztDQUVKO0NBRUEsT0FBTyxLQUFLLE9BQVEsTUFBTSxXQUFXLElBQUssQ0FBQztBQUM3QztBQUVBLElBQU0scUNBQXFDLFNBQVM7Q0FDbEQsTUFBTSxNQUFNLEtBQUs7Q0FDakIsSUFBSSxjQUFjO0NBQ2xCLElBQUksVUFBVTtDQUNkLElBQUksVUFBVTtDQUVkLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQUs7RUFDNUIsSUFBSSxPQUFPLEtBQUssV0FBVyxDQUFDO0VBRTVCLElBQUksU0FBUyxNQUFnQixxQkFBcUIsTUFBTSxHQUFHLEdBQUcsR0FBRztHQUMvRCxPQUFPLFNBQVMsS0FBSyxXQUFXLElBQUksQ0FBQyxDQUFDLElBQUksS0FBSyxTQUFTLEtBQUssV0FBVyxJQUFJLENBQUMsQ0FBQztHQUM5RSxLQUFLO0VBQ1A7RUFFQSxJQUFJLG1CQUFtQixJQUFJLEdBQ3pCO0VBR0YsSUFBSSxTQUFTLElBQWM7R0FDekI7R0FDQTtFQUNGO0VBRUEsSUFBSSxDQUFDLGFBQWEsSUFBSSxLQUFLLFVBQVUsR0FBRztHQUN0QyxVQUFVO0dBQ1Y7RUFDRjtFQUVBO0NBQ0Y7Q0FJQSxJQUNFLFdBQ0EsVUFBVSxLQUNULFVBQVUsTUFBTSxjQUFjLFdBQVcsTUFBTSxLQUNoRCxjQUFjLE1BQU0sR0FFcEIsT0FBTywrQkFBK0IsSUFBSTtDQUc1QyxPQUFPLFlBQVksV0FBVztBQUNoQztBQUVBLElBQU0sd0JBQXdCLEtBQUssbUJBQW1CO0NBQ3BELElBQUksQ0FBQyxPQUFPLE9BQU8sUUFBUSxVQUFVLE9BQU87Q0FDNUMsSUFBSSxDQUFDLElBQUksV0FBVyxPQUFPLEdBQUcsT0FBTztDQUVyQyxNQUFNLFFBQVEsSUFBSSxRQUFRLEdBQUc7Q0FDN0IsSUFBSSxRQUFRLEdBQUcsT0FBTztDQUV0QixNQUFNLE9BQU8sSUFBSSxNQUFNLEdBQUcsS0FBSztDQUMvQixNQUFNLE9BQU8sSUFBSSxNQUFNLFFBQVEsQ0FBQztDQUdoQyxJQUZpQixXQUFXLEtBQUssSUFFdEIsR0FDVCxPQUFPLGVBQWUsSUFBSTtDQU81QixJQUFJLFFBQVE7Q0FDWixLQUFLLElBQUksSUFBSSxHQUFHLE1BQU0sS0FBSyxRQUFRLElBQUksS0FBSyxLQUFLO0VBQy9DLE1BQU0sSUFBSSxLQUFLLFdBQVcsQ0FBQztFQUMzQixJQUFJLE1BQU0sTUFBZ0IscUJBQXFCLE1BQU0sR0FBRyxHQUFHLEdBQUc7R0FDNUQsU0FBUztHQUNULEtBQUs7RUFDUCxPQUFPLElBQUksSUFBSSxLQUNiLFNBQVM7T0FDSixJQUFJLElBQUksTUFDYixTQUFTO09BQ0osSUFBSSxLQUFLLFNBQVUsS0FBSyxTQUFVLElBQUksSUFBSSxLQUFLO0dBQ3BELE1BQU0sT0FBTyxLQUFLLFdBQVcsSUFBSSxDQUFDO0dBQ2xDLElBQUksUUFBUSxTQUFVLFFBQVEsT0FBUTtJQUNwQyxTQUFTO0lBQ1Q7R0FDRixPQUNFLFNBQVM7RUFFYixPQUNFLFNBQVM7Q0FFYjtDQUNBLE9BQU87QUFDVDs7Ozs7OztBQVFBLFNBQXdCLDRCQUE0QixLQUFLO0NBRXZELE1BQU0sZ0JBQWdCLE9BQU8sUUFBUSxXQUFXLElBQUksUUFBUSxHQUFHLElBQUk7Q0FFbkUsT0FBTyxxQkFDTCxrQkFBa0IsS0FBSyxNQUFNLElBQUksTUFBTSxHQUFHLGFBQWEsR0FDdkQsaUNBQ0Y7QUFDRjs7O0FDM0pBLElBQWFDLFlBQVU7OztBQ2lCdkIsSUFBTSxxQkFBcUI7QUFFM0IsSUFBTSwwQkFBMEI7Q0FDOUIsT0FBTztDQUNQLFVBQVU7Q0FDVixVQUFVO0NBQ1YsZ0JBQWdCO0NBQ2hCLE1BQU07Q0FDTixXQUFXO0NBQ1gsV0FBVztDQUNYLFVBQVU7Q0FDVixRQUFRO0FBQ1Y7QUFFQSxJQUFNLEVBQUUsZUFBZUM7Ozs7Ozs7OztBQVV2QixJQUFNLGNBQWMsUUFDbEIsbUJBQW1CLEdBQUcsQ0FBQyxDQUFDLFFBQVEscUJBQXFCLEdBQUcsUUFDdEQsT0FBTyxhQUFhLFNBQVMsS0FBSyxFQUFFLENBQUMsQ0FDdkM7QUFNRixJQUFNLDBCQUEwQixVQUFVO0NBQ3hDLElBQUksQ0FBQ0EsY0FBTSxTQUFTLEtBQUssR0FDdkIsT0FBTztDQUdULElBQUk7RUFDRixPQUFPLG1CQUFtQixLQUFLO0NBQ2pDLFNBQVMsT0FBTztFQUNkLE9BQU87Q0FDVDtBQUNGO0FBRUEsSUFBTSxRQUFRLElBQUksR0FBRyxTQUFTO0NBQzVCLElBQUk7RUFDRixPQUFPLENBQUMsQ0FBQyxHQUFHLEdBQUcsSUFBSTtDQUNyQixTQUFTLEdBQUc7RUFDVixPQUFPO0NBQ1Q7QUFDRjtBQUVBLElBQU0sNEJBQTRCLFFBQVE7Q0FDeEMsTUFBTSxnQkFBZ0IsSUFBSSxRQUFRLEtBQUs7Q0FDdkMsSUFBSSxhQUFhO0NBQ2pCLElBQUksa0JBQWtCLElBQ3BCLGFBQWEsV0FBVyxNQUFNLGdCQUFnQixDQUFDO0NBRWpELE9BQU8sV0FBVyxTQUFTLEdBQUcsS0FBSyxXQUFXLFNBQVMsR0FBRztBQUM1RDtBQUVBLElBQU0sV0FBVyxRQUFRO0NBQ3ZCLE1BQU0sZUFDSkEsY0FBTSxXQUFXLEtBQUEsS0FBYUEsY0FBTSxXQUFXLE9BQU9BLGNBQU0sU0FBUztDQUN2RSxNQUFNLEVBQUUsZ0JBQWdCLGdCQUFnQjtDQUV4QyxNQUFNQSxjQUFNLE1BQU0sS0FDaEIsRUFDRSxlQUFlLEtBQ2pCLEdBQ0E7RUFDRSxTQUFTLGFBQWE7RUFDdEIsVUFBVSxhQUFhO0NBQ3pCLEdBQ0EsR0FDRjtDQUVBLE1BQU0sRUFBRSxPQUFPLFVBQVUsU0FBUyxhQUFhO0NBQy9DLE1BQU0sbUJBQW1CLFdBQVcsV0FBVyxRQUFRLElBQUksT0FBTyxVQUFVO0NBQzVFLE1BQU0scUJBQXFCLFdBQVcsT0FBTztDQUM3QyxNQUFNLHNCQUFzQixXQUFXLFFBQVE7Q0FFL0MsSUFBSSxDQUFDLGtCQUNILE9BQU87Q0FHVCxNQUFNLDRCQUE0QixvQkFBb0IsV0FBVyxjQUFjO0NBRS9FLE1BQU0sYUFDSixxQkFDQyxPQUFPLGdCQUFnQixlQUVqQixhQUFhLFFBQ1osUUFBUSxPQUFPLEdBQUcsRUFBQSxDQUNwQixJQUFJLFlBQVksQ0FBQyxJQUNuQixPQUFPLFFBQVEsSUFBSSxXQUFXLE1BQU0sSUFBSSxRQUFRLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQztDQUV4RSxNQUFNLHdCQUNKLHNCQUNBLDZCQUNBLFdBQVc7RUFDVCxJQUFJLGlCQUFpQjtFQUVyQixNQUFNLFVBQVUsSUFBSSxRQUFRQyxpQkFBUyxRQUFRO0dBQzNDLE1BQU0sSUFBSSxlQUFlO0dBQ3pCLFFBQVE7R0FDUixJQUFJLFNBQVM7SUFDWCxpQkFBaUI7SUFDakIsT0FBTztHQUNUO0VBQ0YsQ0FBQztFQUVELE1BQU0saUJBQWlCLFFBQVEsUUFBUSxJQUFJLGNBQWM7RUFFekQsSUFBSSxRQUFRLFFBQVEsTUFDbEIsUUFBUSxLQUFLLE9BQU87RUFHdEIsT0FBTyxrQkFBa0IsQ0FBQztDQUM1QixDQUFDO0NBRUgsTUFBTSx5QkFDSix1QkFDQSw2QkFDQSxXQUFXRCxjQUFNLGlCQUFpQixJQUFJLFNBQVMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDO0NBRTFELE1BQU0sWUFBWSxFQUNoQixRQUFRLDRCQUE0QixRQUFRLElBQUksTUFDbEQ7Q0FFQSwyQkFDUztFQUNMO0dBQUM7R0FBUTtHQUFlO0dBQVE7R0FBWTtFQUFRLENBQUMsQ0FBQyxTQUFTLFNBQVM7R0FDdEUsQ0FBQyxVQUFVLFVBQ1IsVUFBVSxTQUFTLEtBQUssV0FBVztJQUNsQyxJQUFJLFNBQVMsT0FBTyxJQUFJO0lBRXhCLElBQUksUUFDRixPQUFPLE9BQU8sS0FBSyxHQUFHO0lBR3hCLE1BQU0sSUFBSUUsYUFDUixrQkFBa0IsS0FBSyxxQkFDdkJBLGFBQVcsaUJBQ1gsTUFDRjtHQUNGO0VBQ0osQ0FBQztDQUNILEVBQUEsQ0FBRztDQUVMLE1BQU0sZ0JBQWdCLE9BQU8sU0FBUztFQUNwQyxJQUFJLFFBQVEsTUFDVixPQUFPO0VBR1QsSUFBSUYsY0FBTSxPQUFPLElBQUksR0FDbkIsT0FBTyxLQUFLO0VBR2QsSUFBSUEsY0FBTSxvQkFBb0IsSUFBSSxHQUtoQyxRQUFRLE1BQU0sSUFKTyxRQUFRQyxpQkFBUyxRQUFRO0dBQzVDLFFBQVE7R0FDUjtFQUNGLENBQ3FCLENBQUMsQ0FBQyxZQUFZLEVBQUEsQ0FBRztFQUd4QyxJQUFJRCxjQUFNLGtCQUFrQixJQUFJLEtBQUtBLGNBQU0sY0FBYyxJQUFJLEdBQzNELE9BQU8sS0FBSztFQUdkLElBQUlBLGNBQU0sa0JBQWtCLElBQUksR0FDOUIsT0FBTyxPQUFPO0VBR2hCLElBQUlBLGNBQU0sU0FBUyxJQUFJLEdBQ3JCLFFBQVEsTUFBTSxXQUFXLElBQUksRUFBQSxDQUFHO0NBRXBDO0NBRUEsTUFBTSxvQkFBb0IsT0FBTyxTQUFTLFNBQVM7RUFDakQsTUFBTSxTQUFTQSxjQUFNLGVBQWUsUUFBUSxpQkFBaUIsQ0FBQztFQUU5RCxPQUFPLFVBQVUsT0FBTyxjQUFjLElBQUksSUFBSTtDQUNoRDtDQUVBLE9BQU8sT0FBTyxXQUFXO0VBQ3ZCLElBQUksRUFDRixLQUNBLFFBQ0EsTUFDQSxRQUNBLGFBQ0EsU0FDQSxvQkFDQSxrQkFDQSxjQUNBLFNBQ0Esa0JBQWtCLGVBQ2xCLGNBQ0Esa0JBQ0EsZUFDQSxpQkFDRSxjQUFjLE1BQU07RUFFeEIsTUFBTSxzQkFBc0JBLGNBQU0sU0FBUyxnQkFBZ0IsS0FBSyxtQkFBbUI7RUFDbkYsTUFBTSxtQkFBbUJBLGNBQU0sU0FBUyxhQUFhLEtBQUssZ0JBQWdCO0VBQzFFLE1BQU0sT0FBTyxRQUFTQSxjQUFNLFdBQVcsUUFBUSxHQUFHLElBQUksT0FBTyxPQUFPLEtBQUE7RUFFcEUsSUFBSSxTQUFTLFlBQVk7RUFFekIsZUFBZSxnQkFBZ0IsZUFBZSxHQUFBLENBQUksWUFBWSxJQUFJO0VBRWxFLElBQUksaUJBQWlCLGVBQ25CLENBQUMsUUFBUSxlQUFlLFlBQVksY0FBYyxDQUFDLEdBQ25ELE9BQ0Y7RUFFQSxJQUFJLFVBQVU7RUFFZCxNQUFNLGNBQ0osa0JBQ0EsZUFBZSxzQkFDUjtHQUNMLGVBQWUsWUFBWTtFQUM3QjtFQUVGLElBQUk7RUFNSixJQUFJLG1CQUFtQjtFQUV2QixNQUFNLDJCQUNKLElBQUlFLGFBQ0YsZ0RBQ0FBLGFBQVcsaUJBQ1gsUUFDQSxPQUNGO0VBRUYsSUFBSTtHQUVGLElBQUksT0FBTyxLQUFBO0dBQ1gsTUFBTSxhQUFhLElBQUksTUFBTTtHQUU3QixJQUFJLFlBR0YsT0FBTztJQUNMLFVBSGVGLGNBQU0sWUFBWSxZQUFZLFVBQVUsS0FBSztJQUk1RCxVQUhlQSxjQUFNLFlBQVksWUFBWSxVQUFVLEtBQUs7R0FJOUQ7R0FHRixJQUFJLHlCQUF5QixHQUFHLEdBQUc7SUFDakMsTUFBTSxZQUFZLElBQUksSUFBSSxLQUFLQyxpQkFBUyxNQUFNO0lBRTlDLElBQUksQ0FBQyxTQUFTLFVBQVUsWUFBWSxVQUFVLFdBRzVDLE9BQU87S0FDTCxVQUhrQix1QkFBdUIsVUFBVSxRQUcvQjtLQUNwQixVQUhrQix1QkFBdUIsVUFBVSxRQUcvQjtJQUN0QjtJQUdGLElBQUksVUFBVSxZQUFZLFVBQVUsVUFBVTtLQUM1QyxVQUFVLFdBQVc7S0FDckIsVUFBVSxXQUFXO0tBQ3JCLE1BQU0sVUFBVTtJQUNsQjtHQUNGO0dBRUEsSUFBSSxNQUFNO0lBQ1IsUUFBUSxPQUFPLGVBQWU7SUFDOUIsUUFBUSxJQUNOLGlCQUNBLFdBQVcsS0FBSyxZQUFZLEtBQUssWUFBWSxNQUFNLE9BQU8sS0FBSyxZQUFZLEdBQUcsQ0FBQyxDQUNqRjtHQUNGO0dBS0EsSUFBSSx1QkFBdUIsT0FBTyxRQUFRLFlBQVksSUFBSSxXQUFXLE9BQU8sR0FDeEQ7UUFBQSw0QkFBNEIsR0FDbEMsSUFBSSxrQkFDZCxNQUFNLElBQUlDLGFBQ1IsOEJBQThCLG1CQUFtQixhQUNqREEsYUFBVyxrQkFDWCxRQUNBLE9BQ0Y7R0FBQTtHQVNKLElBQUksb0JBQW9CLFdBQVcsU0FBUyxXQUFXLFFBQVE7SUFDN0QsTUFBTSxpQkFBaUIsTUFBTSxjQUFjLElBQUk7SUFDL0MsSUFBSSxPQUFPLG1CQUFtQixZQUFZLFNBQVMsY0FBYyxHQUFHO0tBQ2xFLHVCQUF1QjtLQUN2QixJQUFJLGlCQUFpQixlQUNuQixNQUFNLG1CQUFtQjtJQUU3QjtHQUNGO0dBSUEsTUFBTSx3QkFDSixxQkFBcUJGLGNBQU0saUJBQWlCLElBQUksS0FBS0EsY0FBTSxTQUFTLElBQUk7R0FFMUUsTUFBTSxzQkFBc0IsUUFBUSxZQUFZLFVBQzlDLFlBQ0UsUUFDQSxxQkFDQyxnQkFBZ0I7SUFDZixJQUFJLG9CQUFvQixjQUFjLGVBQ3BDLE1BQU8sbUJBQW1CLG1CQUFtQjtJQUUvQyxjQUFjLFdBQVcsV0FBVztHQUN0QyxHQUNBLEtBQ0Y7R0FFRixJQUNFLHlCQUNBLFdBQVcsU0FDWCxXQUFXLFdBQ1Ysb0JBQW9CLHdCQUNyQjtJQUNBLHVCQUNFLHdCQUF3QixPQUNwQixNQUFNLGtCQUFrQixTQUFTLElBQUksSUFDckM7SUFJTixJQUFJLHlCQUF5QixLQUFLLHVCQUF1QjtLQUN2RCxJQUFJLFdBQVcsSUFBSSxRQUFRLEtBQUs7TUFDOUIsUUFBUTtNQUNSLE1BQU07TUFDTixRQUFRO0tBQ1YsQ0FBQztLQUVELElBQUk7S0FFSixJQUNFQSxjQUFNLFdBQVcsSUFBSSxNQUNwQixvQkFBb0IsU0FBUyxRQUFRLElBQUksY0FBYyxJQUV4RCxRQUFRLGVBQWUsaUJBQWlCO0tBRzFDLElBQUksU0FBUyxNQUFNO01BQ2pCLE1BQU0sQ0FBQyxZQUFZLFNBQ2hCLG9CQUNDLHVCQUNFLHNCQUNBLHFCQUFxQixlQUFlLGdCQUFnQixDQUFDLENBQ3ZELEtBQ0YsQ0FBQztNQUVILE9BQU8sbUJBQW1CLFNBQVMsTUFBTSxZQUFZLEtBQUs7S0FDNUQ7SUFDRjtHQUNGLE9BQU8sSUFDTCx5QkFDQSxDQUFDLHNCQUNELDZCQUNBLFdBQVcsU0FDWCxXQUFXLFFBRVgsT0FBTyxtQkFBbUIsSUFBSTtRQUN6QixJQUNMLHlCQUNBLHNCQUNBLENBQUMseUJBQ0QsV0FBVyxTQUNYLFdBQVcsUUFFWCxNQUFNLElBQUlFLGFBQ1IsK0VBQ0FBLGFBQVcsaUJBQ1gsUUFDQSxPQUNGO0dBR0YsSUFBSSxDQUFDRixjQUFNLFNBQVMsZUFBZSxHQUNqQyxrQkFBa0Isa0JBQWtCLFlBQVk7R0FLbEQsTUFBTSx5QkFBeUIsc0JBQXNCLGlCQUFpQixRQUFRO0dBSTlFLElBQUlBLGNBQU0sV0FBVyxJQUFJLEdBQUc7SUFDMUIsTUFBTSxjQUFjLFFBQVEsZUFBZTtJQUMzQyxJQUNFLGVBQ0EseUJBQXlCLEtBQUssV0FBVyxLQUN6QyxDQUFDLGFBQWEsS0FBSyxXQUFXLEdBRTlCLFFBQVEsT0FBTyxjQUFjO0dBRWpDO0dBR0EsUUFBUSxJQUFJLGNBQWMsV0FBV0csV0FBUyxLQUFLO0dBRW5ELE1BQU0sbUJBQ0osZ0JBQWdCLE9BQU8sZUFBZSxPQUFPLE9BQU8sT0FBTyxPQUFPLElBQUksR0FBRyxZQUFZO0dBRXZGLElBQUksa0JBQWtCO0lBR3BCLE9BQU8saUJBQWlCO0lBQ3hCLE9BQU8saUJBQWlCO0lBQ3hCLE9BQU8saUJBQWlCO0lBQ3hCLE9BQU8saUJBQWlCO0lBQ3hCLE9BQU8saUJBQWlCO0lBQ3hCLE9BQU8saUJBQWlCO0dBQzFCO0dBRUEsTUFBTSxrQkFBa0IsT0FBTyxPQUFPLE9BQU8sT0FBTyxJQUFJLEdBQUcsa0JBQWtCO0lBQzNFLFFBQVE7SUFDUixRQUFRLE9BQU8sWUFBWTtJQUMzQixTQUFTLHlCQUF5QixRQUFRLFVBQVUsQ0FBQztJQUNyRCxNQUFNO0lBQ04sUUFBUTtJQUNSLGFBQWEseUJBQXlCLGtCQUFrQixLQUFBO0dBQzFELENBQUM7R0FFRCxJQUFJLG9CQUFvQjtJQUN0QixjQUFNLFFBQVEsMEJBQTBCLE9BQU8sUUFBUTtLQUNyRCxJQUFJLGdCQUFnQixTQUFTLEtBQUEsR0FDM0IsZ0JBQWdCLE9BQU87SUFFM0IsQ0FBQztJQUVELElBQUksZ0JBQWdCLFdBQVcsS0FBQSxHQUM3QixnQkFBZ0IsU0FBUztJQUczQixJQUFJLGdCQUFnQixTQUFTLEtBQUEsR0FDM0IsZ0JBQWdCLE9BQU87R0FFM0I7R0FFQSxJQUFJLGlCQUFpQixHQUFHO0lBQ3RCLGdCQUFnQixXQUFXO0lBRTNCLElBQUksa0JBQ0YsaUJBQWlCLFdBQVc7R0FFaEM7R0FFQSxVQUFVLHNCQUFzQixJQUFJLFFBQVEsS0FBSyxlQUFlO0dBRWhFLElBQUksV0FBVyxPQUFPLHFCQUNsQixPQUFPLFNBQVMsZ0JBQWdCLElBQ2hDLE9BQU8sS0FBSyxlQUFlO0dBRS9CLE1BQU0sa0JBQWtCQyxlQUFhLEtBQUssU0FBUyxPQUFPO0dBSTFELElBQUkscUJBQXFCO0lBQ3ZCLE1BQU0saUJBQWlCSixjQUFNLGVBQWUsZ0JBQWdCLGlCQUFpQixDQUFDO0lBQzlFLElBQUksa0JBQWtCLFFBQVEsaUJBQWlCLGtCQUM3QyxNQUFNLElBQUlFLGFBQ1IsOEJBQThCLG1CQUFtQixhQUNqREEsYUFBVyxrQkFDWCxRQUNBLE9BQ0Y7R0FFSjtHQUVBLE1BQU0sbUJBQ0osMkJBQTJCLGlCQUFpQixZQUFZLGlCQUFpQjtHQUUzRSxJQUNFLDBCQUNBLFNBQVMsU0FDUixzQkFBc0IsdUJBQXdCLG9CQUFvQixjQUNuRTtJQUNBLE1BQU0sVUFBVSxDQUFDO0lBRWpCO0tBQUM7S0FBVTtLQUFjO0lBQVMsQ0FBQyxDQUFDLFNBQVMsU0FBUztLQUNwRCxRQUFRLFFBQVEsU0FBUztJQUMzQixDQUFDO0lBRUQsTUFBTSx3QkFBd0JGLGNBQU0sZUFBZSxnQkFBZ0IsaUJBQWlCLENBQUM7SUFFckYsTUFBTSxDQUFDLFlBQVksU0FDaEIsc0JBQ0MsdUJBQ0UsdUJBQ0EscUJBQXFCLGVBQWUsa0JBQWtCLEdBQUcsSUFBSSxDQUMvRCxLQUNGLENBQUM7SUFFSCxJQUFJLFlBQVk7SUFDaEIsTUFBTSxtQkFBbUIsZ0JBQWdCO0tBQ3ZDLElBQUkscUJBQXFCO01BQ3ZCLFlBQVk7TUFDWixJQUFJLFlBQVksa0JBQ2QsTUFBTSxJQUFJRSxhQUNSLDhCQUE4QixtQkFBbUIsYUFDakRBLGFBQVcsa0JBQ1gsUUFDQSxPQUNGO0tBRUo7S0FDQSxjQUFjLFdBQVcsV0FBVztJQUN0QztJQUVBLFdBQVcsSUFBSSxTQUNiLFlBQVksU0FBUyxNQUFNLG9CQUFvQix1QkFBdUI7S0FDcEUsU0FBUyxNQUFNO0tBQ2YsZUFBZSxZQUFZO0lBQzdCLENBQUMsR0FDRCxPQUNGO0dBQ0Y7R0FFQSxlQUFlLGdCQUFnQjtHQUUvQixJQUFJLGVBQWUsTUFBTSxVQUFVRixjQUFNLFFBQVEsV0FBVyxZQUFZLEtBQUssT0FBTyxDQUNsRixVQUNBLE1BQ0Y7R0FLQSxJQUFJLHVCQUF1QixDQUFDLDBCQUEwQixDQUFDLGtCQUFrQjtJQUN2RSxJQUFJO0lBQ0osSUFBSSxnQkFBZ0IsTUFBTTtLQUN4QixJQUFJLE9BQU8sYUFBYSxlQUFlLFVBQ3JDLG1CQUFtQixhQUFhO1VBQzNCLElBQUksT0FBTyxhQUFhLFNBQVMsVUFDdEMsbUJBQW1CLGFBQWE7VUFDM0IsSUFBSSxPQUFPLGlCQUFpQixVQUNqQyxtQkFDRSxPQUFPLGdCQUFnQixhQUNuQixJQUFJLFlBQVksQ0FBQyxDQUFDLE9BQU8sWUFBWSxDQUFDLENBQUMsYUFDdkMsYUFBYTtJQUV2QjtJQUNBLElBQUksT0FBTyxxQkFBcUIsWUFBWSxtQkFBbUIsa0JBQzdELE1BQU0sSUFBSUUsYUFDUiw4QkFBOEIsbUJBQW1CLGFBQ2pEQSxhQUFXLGtCQUNYLFFBQ0EsT0FDRjtHQUVKO0dBRUEsQ0FBQyxvQkFBb0IsZUFBZSxZQUFZO0dBRWhELE9BQU8sTUFBTSxJQUFJLFNBQVMsU0FBUyxXQUFXO0lBQzVDLE9BQU8sU0FBUyxRQUFRO0tBQ3RCLE1BQU07S0FDTixTQUFTRSxlQUFhLEtBQUssU0FBUyxPQUFPO0tBQzNDLFFBQVEsU0FBUztLQUNqQixZQUFZLFNBQVM7S0FDckI7S0FDQTtJQUNGLENBQUM7R0FDSCxDQUFDO0VBQ0gsU0FBUyxLQUFLO0dBQ1osZUFBZSxZQUFZO0dBSzNCLElBQUksa0JBQWtCLGVBQWUsV0FBVyxlQUFlLGtCQUFrQkYsY0FBWTtJQUMzRixNQUFNLGdCQUFnQixlQUFlO0lBQ3JDLGNBQWMsU0FBUztJQUN2QixZQUFZLGNBQWMsVUFBVTtJQUNwQyxJQUFJLFFBQVEsZUFHVixPQUFPLGVBQWUsZUFBZSxTQUFTO0tBQzVDLFdBQVc7S0FDWCxPQUFPO0tBQ1AsVUFBVTtLQUNWLFlBQVk7S0FDWixjQUFjO0lBQ2hCLENBQUM7SUFFSCxNQUFNO0dBQ1I7R0FPQSxJQUFJLGtCQUFrQjtJQUNwQixXQUFXLENBQUMsaUJBQWlCLFlBQVksaUJBQWlCLFVBQVU7SUFDcEUsTUFBTTtHQUNSO0dBSUEsSUFBSSxlQUFlQSxjQUFZO0lBQzdCLFdBQVcsQ0FBQyxJQUFJLFlBQVksSUFBSSxVQUFVO0lBQzFDLE1BQU07R0FDUjtHQUVBLElBQUksT0FBTyxJQUFJLFNBQVMsZUFBZSxxQkFBcUIsS0FBSyxJQUFJLE9BQU8sR0FBRztJQUM3RSxNQUFNLGVBQWUsSUFBSUEsYUFDdkIsaUJBQ0FBLGFBQVcsYUFDWCxRQUNBLFNBQ0EsT0FBTyxJQUFJLFFBQ2I7SUFHQSxPQUFPLGVBQWUsY0FBYyxTQUFTO0tBQzNDLFdBQVc7S0FDWCxPQUFPLElBQUksU0FBUztLQUNwQixVQUFVO0tBQ1YsWUFBWTtLQUNaLGNBQWM7SUFDaEIsQ0FBQztJQUNELE1BQU07R0FDUjtHQUVBLE1BQU1BLGFBQVcsS0FBSyxLQUFLLE9BQU8sSUFBSSxNQUFNLFFBQVEsU0FBUyxPQUFPLElBQUksUUFBUTtFQUNsRjtDQUNGO0FBQ0Y7QUFFQSxJQUFNLDRCQUFZLElBQUksSUFBSTtBQUUxQixJQUFhLFlBQVksV0FBVztDQUNsQyxJQUFJLE1BQU8sVUFBVSxPQUFPLE9BQVEsQ0FBQztDQUNyQyxNQUFNLEVBQUUsT0FBTyxTQUFTLGFBQWE7Q0FDckMsTUFBTSxRQUFRO0VBQUM7RUFBUztFQUFVO0NBQUs7Q0FFdkMsSUFDRSxJQURRLE1BQU0sUUFFZCxNQUNBLFFBQ0EsTUFBTTtDQUVSLE9BQU8sS0FBSztFQUNWLE9BQU8sTUFBTTtFQUNiLFNBQVMsSUFBSSxJQUFJLElBQUk7RUFFckIsV0FBVyxLQUFBLEtBQWEsSUFBSSxJQUFJLE1BQU8sU0FBUyxvQkFBSSxJQUFJLElBQUksSUFBSSxRQUFRLEdBQUcsQ0FBRTtFQUU3RSxNQUFNO0NBQ1I7Q0FFQSxPQUFPO0FBQ1Q7QUFFZ0IsU0FBUzs7Ozs7Ozs7Ozs7O0FDdHFCekIsSUFBTSxnQkFBZ0I7Q0FDcEIsTUFBQTtDQUNBLEtBQUtHO0NBQ0wsT0FBTyxFQUNMLEtBQUtDLFNBQ1A7QUFDRjtBQUdBQyxjQUFNLFFBQVEsZ0JBQWdCLElBQUksVUFBVTtDQUMxQyxJQUFJLElBQUk7RUFDTixJQUFJO0dBR0YsT0FBTyxlQUFlLElBQUksUUFBUTtJQUFFLFdBQVc7SUFBTTtHQUFNLENBQUM7RUFDOUQsU0FBUyxHQUFHLENBRVo7RUFDQSxPQUFPLGVBQWUsSUFBSSxlQUFlO0dBQUUsV0FBVztHQUFNO0VBQU0sQ0FBQztDQUNyRTtBQUNGLENBQUM7Ozs7Ozs7QUFRRCxJQUFNLGdCQUFnQixXQUFXLEtBQUs7Ozs7Ozs7QUFRdEMsSUFBTSxvQkFBb0IsWUFDeEJBLGNBQU0sV0FBVyxPQUFPLEtBQUssWUFBWSxRQUFRLFlBQVk7Ozs7Ozs7Ozs7O0FBWS9ELFNBQVNDLGFBQVcsVUFBVSxRQUFRO0NBQ3BDLFdBQVdELGNBQU0sUUFBUSxRQUFRLElBQUksV0FBVyxDQUFDLFFBQVE7Q0FFekQsTUFBTSxFQUFFLFdBQVc7Q0FDbkIsSUFBSTtDQUNKLElBQUk7Q0FFSixNQUFNLGtCQUFrQixDQUFDO0NBRXpCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLEtBQUs7RUFDL0IsZ0JBQWdCLFNBQVM7RUFDekIsSUFBSTtFQUVKLFVBQVU7RUFFVixJQUFJLENBQUMsaUJBQWlCLGFBQWEsR0FBRztHQUNwQyxVQUFVLGVBQWUsS0FBSyxPQUFPLGFBQWEsRUFBQSxDQUFHLFlBQVk7R0FFakUsSUFBSSxZQUFZLEtBQUEsR0FDZCxNQUFNLElBQUlFLGFBQVcsb0JBQW9CLEdBQUcsRUFBRTtFQUVsRDtFQUVBLElBQUksWUFBWUYsY0FBTSxXQUFXLE9BQU8sTUFBTSxVQUFVLFFBQVEsSUFBSSxNQUFNLEtBQ3hFO0VBR0YsZ0JBQWdCLE1BQU0sTUFBTSxLQUFLO0NBQ25DO0NBRUEsSUFBSSxDQUFDLFNBQVM7RUFDWixNQUFNLFVBQVUsT0FBTyxRQUFRLGVBQWUsQ0FBQyxDQUFDLEtBQzdDLENBQUMsSUFBSSxXQUNKLFdBQVcsR0FBRyxNQUNiLFVBQVUsUUFBUSx3Q0FBd0MsZ0NBQy9EO0VBUUEsTUFBTSxJQUFJRSxhQUNSLDJEQVBNLFNBQ0osUUFBUSxTQUFTLElBQ2YsY0FBYyxRQUFRLElBQUksWUFBWSxDQUFDLENBQUMsS0FBSyxJQUFJLElBQ2pELE1BQU0sYUFBYSxRQUFRLEVBQUUsSUFDL0IsNEJBSUZBLGFBQVcsZUFDYjtDQUNGO0NBRUEsT0FBTztBQUNUOzs7O0FBS0EsSUFBQSxtQkFBZTs7Ozs7Q0FLYixZQUFBOzs7OztDQU1BLFVBQVU7QUFDWjs7Ozs7Ozs7OztBQ2xIQSxTQUFTLDZCQUE2QixRQUFRO0NBQzVDLElBQUksT0FBTyxhQUNULE9BQU8sWUFBWSxpQkFBaUI7Q0FHdEMsSUFBSSxPQUFPLFVBQVUsT0FBTyxPQUFPLFNBQ2pDLE1BQU0sSUFBSUMsZ0JBQWMsTUFBTSxNQUFNO0FBRXhDOzs7Ozs7OztBQVNBLFNBQXdCLGdCQUFnQixTQUFTO0NBSS9DLE1BQU0sU0FBU0MsY0FBTSxpQkFBaUIsT0FBTztDQUU3Qyw2QkFBNkIsTUFBTTtDQUVuQyxPQUFPLFVBQVVDLGVBQWEsS0FBS0QsY0FBTSxZQUFZLFFBQVEsU0FBUyxDQUFDO0NBR3ZFLE9BQU8sT0FBTyxjQUFjLEtBQUssUUFBUSxPQUFPLGdCQUFnQjtDQUVoRSxJQUFJO0VBQUM7RUFBUTtFQUFPO0NBQU8sQ0FBQyxDQUFDLFFBQVEsT0FBTyxNQUFNLE1BQU0sSUFDdEQsT0FBTyxRQUFRLGVBQWUscUNBQXFDLEtBQUs7Q0FLMUUsT0FGZ0JFLGlCQUFTLFdBQVcsT0FBTyxXQUFXLFNBQVMsU0FBUyxNQUUzRCxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FDckIsU0FBUyxvQkFBb0IsVUFBVTtFQUNyQyw2QkFBNkIsTUFBTTtFQUtuQyxPQUFPLFdBQVc7RUFDbEIsSUFBSTtHQUNGLFNBQVMsT0FBTyxjQUFjLEtBQUssUUFBUSxPQUFPLG1CQUFtQixRQUFRO0VBQy9FLFVBQVU7R0FDUixPQUFPLE9BQU87RUFDaEI7RUFFQSxTQUFTLFVBQVVELGVBQWEsS0FBSyxTQUFTLE9BQU87RUFFckQsT0FBTztDQUNULEdBQ0EsU0FBUyxtQkFBbUIsUUFBUTtFQUNsQyxJQUFJLENBQUNFLFdBQVMsTUFBTSxHQUFHO0dBQ3JCLDZCQUE2QixNQUFNO0dBR25DLElBQUksVUFBVSxPQUFPLFVBQVU7SUFDN0IsT0FBTyxXQUFXLE9BQU87SUFDekIsSUFBSTtLQUNGLE9BQU8sU0FBUyxPQUFPLGNBQWMsS0FDbkMsUUFDQSxPQUFPLG1CQUNQLE9BQU8sUUFDVDtJQUNGLFVBQVU7S0FDUixPQUFPLE9BQU87SUFDaEI7SUFDQSxPQUFPLFNBQVMsVUFBVUYsZUFBYSxLQUFLLE9BQU8sU0FBUyxPQUFPO0dBQ3JFO0VBQ0Y7RUFFQSxPQUFPLFFBQVEsT0FBTyxNQUFNO0NBQzlCLENBQ0Y7QUFDRjs7O0FDekZBLElBQU1HLGVBQWEsQ0FBQztBQUdwQjtDQUFDO0NBQVU7Q0FBVztDQUFVO0NBQVk7Q0FBVTtBQUFRLENBQUMsQ0FBQyxTQUFTLE1BQU0sTUFBTTtDQUNuRixhQUFXLFFBQVEsU0FBUyxVQUFVLE9BQU87RUFDM0MsT0FBTyxPQUFPLFVBQVUsUUFBUSxPQUFPLElBQUksSUFBSSxPQUFPLE9BQU87Q0FDL0Q7QUFDRixDQUFDO0FBRUQsSUFBTSxxQkFBcUIsQ0FBQzs7Ozs7Ozs7OztBQVc1QixhQUFXLGVBQWUsU0FBUyxhQUFhLFdBQVcsU0FBUyxTQUFTO0NBQzNFLFNBQVMsY0FBYyxLQUFLLE1BQU07RUFDaEMsT0FDRSxhQUNBQyxZQUNBLDRCQUNBLE1BQ0EsTUFDQSxRQUNDLFVBQVUsT0FBTyxVQUFVO0NBRWhDO0NBR0EsUUFBUSxPQUFPLEtBQUssU0FBUztFQUMzQixJQUFJLGNBQWMsT0FDaEIsTUFBTSxJQUFJQyxhQUNSLGNBQWMsS0FBSyx1QkFBdUIsVUFBVSxTQUFTLFVBQVUsR0FBRyxHQUMxRUEsYUFBVyxjQUNiO0VBR0YsSUFBSSxXQUFXLENBQUMsbUJBQW1CLE1BQU07R0FDdkMsbUJBQW1CLE9BQU87R0FFMUIsUUFBUSxLQUNOLGNBQ0UsS0FDQSxpQ0FBaUMsVUFBVSx5Q0FDN0MsQ0FDRjtFQUNGO0VBRUEsT0FBTyxZQUFZLFVBQVUsT0FBTyxLQUFLLElBQUksSUFBSTtDQUNuRDtBQUNGO0FBRUEsYUFBVyxXQUFXLFNBQVMsU0FBUyxpQkFBaUI7Q0FDdkQsUUFBUSxPQUFPLFFBQVE7RUFFckIsUUFBUSxLQUFLLEdBQUcsSUFBSSw4QkFBOEIsaUJBQWlCO0VBQ25FLE9BQU87Q0FDVDtBQUNGOzs7Ozs7Ozs7O0FBWUEsU0FBUyxjQUFjLFNBQVMsUUFBUSxjQUFjO0NBQ3BELElBQUksT0FBTyxZQUFZLFlBQVksWUFBWSxNQUM3QyxNQUFNLElBQUlBLGFBQVcsNkJBQTZCQSxhQUFXLG9CQUFvQjtDQUVuRixNQUFNLE9BQU8sT0FBTyxLQUFLLE9BQU87Q0FDaEMsSUFBSSxJQUFJLEtBQUs7Q0FDYixPQUFPLE1BQU0sR0FBRztFQUNkLE1BQU0sTUFBTSxLQUFLO0VBR2pCLE1BQU0sWUFBWSxPQUFPLFVBQVUsZUFBZSxLQUFLLFFBQVEsR0FBRyxJQUFJLE9BQU8sT0FBTyxLQUFBO0VBQ3BGLElBQUksV0FBVztHQUNiLE1BQU0sUUFBUSxRQUFRO0dBQ3RCLE1BQU0sU0FBUyxVQUFVLEtBQUEsS0FBYSxVQUFVLE9BQU8sS0FBSyxPQUFPO0dBQ25FLElBQUksV0FBVyxNQUNiLE1BQU0sSUFBSUEsYUFDUixZQUFZLE1BQU0sY0FBYyxRQUNoQ0EsYUFBVyxvQkFDYjtHQUVGO0VBQ0Y7RUFDQSxJQUFJLGlCQUFpQixNQUNuQixNQUFNLElBQUlBLGFBQVcsb0JBQW9CLEtBQUtBLGFBQVcsY0FBYztDQUUzRTtBQUNGO0FBRUEsSUFBQSxvQkFBZTtDQUNiO0NBQ0EsWUFBQTtBQUNGOzs7QUNsR0EsSUFBTSxhQUFhQyxrQkFBVTs7Ozs7Ozs7QUFTN0IsSUFBTUMsVUFBTixNQUFZO0NBQ1YsWUFBWSxnQkFBZ0I7RUFDMUIsS0FBSyxXQUFXLGtCQUFrQixDQUFDO0VBQ25DLEtBQUssZUFBZTtHQUNsQixTQUFTLElBQUksbUJBQW1CO0dBQ2hDLFVBQVUsSUFBSSxtQkFBbUI7RUFDbkM7Q0FDRjs7Ozs7Ozs7O0NBVUEsTUFBTSxRQUFRLGFBQWEsUUFBUTtFQUNqQyxJQUFJO0dBQ0YsT0FBTyxNQUFNLEtBQUssU0FBUyxhQUFhLE1BQU07RUFDaEQsU0FBUyxLQUFLO0dBQ1osSUFBSSxlQUFlLE9BQ2pCLElBQUk7SUFDRixJQUFJLFFBQVEsQ0FBQztJQUViLE1BQU0sb0JBQW9CLE1BQU0sa0JBQWtCLEtBQUssSUFBSyx3QkFBUSxJQUFJLE1BQU07SUFFOUUsTUFBTSxhQUFhLE1BQU07SUFDekIsSUFBSSxRQUFRO0lBR1osSUFBSSxPQUFPLGVBQWUsVUFBVTtLQUNsQyxNQUFNLG9CQUFvQixXQUFXLFFBQVEsSUFBSTtLQUVqRCxRQUFRLHNCQUFzQixLQUFLLEtBQUssV0FBVyxNQUFNLG9CQUFvQixDQUFDO0lBQ2hGO0lBRUEsSUFBSSxDQUFDLElBQUksT0FDUCxJQUFJLFFBQVE7U0FFUCxJQUFJLE9BQU87S0FDaEIsTUFBTSxvQkFBb0IsTUFBTSxRQUFRLElBQUk7S0FDNUMsTUFBTSxxQkFDSixzQkFBc0IsS0FBSyxLQUFLLE1BQU0sUUFBUSxNQUFNLG9CQUFvQixDQUFDO0tBQzNFLE1BQU0sMEJBQ0osdUJBQXVCLEtBQUssS0FBSyxNQUFNLE1BQU0scUJBQXFCLENBQUM7S0FFckUsSUFBSSxDQUFDLE9BQU8sSUFBSSxLQUFLLENBQUMsQ0FBQyxTQUFTLHVCQUF1QixHQUNyRCxJQUFJLFNBQVMsT0FBTztJQUV4QjtHQUNGLFNBQVMsR0FBRyxDQUVaO0dBR0YsTUFBTTtFQUNSO0NBQ0Y7Q0FFQSxTQUFTLGFBQWEsUUFBUTtFQUc1QixJQUFJLE9BQU8sZ0JBQWdCLFVBQVU7R0FDbkMsU0FBUyxVQUFVLENBQUM7R0FDcEIsT0FBTyxNQUFNO0VBQ2YsT0FDRSxTQUFTLGVBQWUsQ0FBQztFQUczQixTQUFTQyxjQUFZLEtBQUssVUFBVSxNQUFNO0VBRTFDLE1BQU0sRUFBRSxjQUFjLGtCQUFrQixZQUFZO0VBRXBELElBQUksaUJBQWlCLEtBQUEsR0FDbkIsa0JBQVUsY0FDUixjQUNBO0dBQ0UsbUJBQW1CLFdBQVcsYUFBYSxXQUFXLE9BQU87R0FDN0QsbUJBQW1CLFdBQVcsYUFBYSxXQUFXLE9BQU87R0FDN0QscUJBQXFCLFdBQVcsYUFBYSxXQUFXLE9BQU87R0FDL0QsaUNBQWlDLFdBQVcsYUFBYSxXQUFXLE9BQU87R0FDM0UsNkJBQTZCLFdBQVcsYUFBYSxXQUFXLE9BQU87R0FDdkUsaUNBQWlDLFdBQVcsYUFBYSxXQUFXLE9BQU87RUFDN0UsR0FDQSxLQUNGO0VBR0YsSUFBSSxvQkFBb0IsTUFBTTtHQUM1QixJQUFJQyxjQUFNLFdBQVcsZ0JBQWdCLEdBQ25DLE9BQU8sbUJBQW1CLEVBQ3hCLFdBQVcsaUJBQ2I7UUFFQSxrQkFBVSxjQUNSLGtCQUNBO0lBQ0UsUUFBUSxXQUFXO0lBQ25CLFdBQVcsV0FBVztHQUN4QixHQUNBLElBQ0Y7RUFFSjtFQUdBLElBQUksT0FBTyxzQkFBc0IsS0FBQSxHQUFXLENBRTVDLE9BQU8sSUFBSSxLQUFLLFNBQVMsc0JBQXNCLEtBQUEsR0FDN0MsT0FBTyxvQkFBb0IsS0FBSyxTQUFTO09BRXpDLE9BQU8sb0JBQW9CO0VBRzdCLGtCQUFVLGNBQ1IsUUFDQTtHQUNFLFNBQVMsV0FBVyxTQUFTLFNBQVM7R0FDdEMsZUFBZSxXQUFXLFNBQVMsZUFBZTtFQUNwRCxHQUNBLElBQ0Y7RUFHQSxPQUFPLFVBQ0xBLGNBQU0sWUFBWSxRQUFRLFFBQVEsS0FDbENBLGNBQU0sWUFBWSxLQUFLLFVBQVUsUUFBUSxLQUN6QyxNQUFBLENBQ0EsWUFBWTtFQUdkLElBQUksaUJBQWlCLFdBQVdBLGNBQU0sTUFBTSxRQUFRLFFBQVEsUUFBUSxPQUFPLE9BQU87RUFFbEYsV0FDRUEsY0FBTSxRQUFRLFdBQVcsT0FBTyxRQUFRLElBQUksV0FBVztHQUNyRCxPQUFPLFFBQVE7RUFDakIsQ0FBQztFQUVILE9BQU8sVUFBVUMsZUFBYSxPQUFPLGdCQUFnQixPQUFPO0VBRzVELE1BQU0sMEJBQTBCLENBQUM7RUFDakMsSUFBSSxpQ0FBaUM7RUFDckMsS0FBSyxhQUFhLFFBQVEsUUFBUSxTQUFTLDJCQUEyQixhQUFhO0dBQ2pGLElBQUksT0FBTyxZQUFZLFlBQVksY0FBYyxZQUFZLFFBQVEsTUFBTSxNQUFNLE9BQy9FO0dBR0YsaUNBQWlDLGtDQUFrQyxZQUFZO0dBRS9FLE1BQU0sZUFBZSxPQUFPLGdCQUFnQkM7R0FJNUMsSUFGRSxnQkFBZ0IsYUFBYSxpQ0FHN0Isd0JBQXdCLFFBQVEsWUFBWSxXQUFXLFlBQVksUUFBUTtRQUUzRSx3QkFBd0IsS0FBSyxZQUFZLFdBQVcsWUFBWSxRQUFRO0VBRTVFLENBQUM7RUFFRCxNQUFNLDJCQUEyQixDQUFDO0VBQ2xDLEtBQUssYUFBYSxTQUFTLFFBQVEsU0FBUyx5QkFBeUIsYUFBYTtHQUNoRix5QkFBeUIsS0FBSyxZQUFZLFdBQVcsWUFBWSxRQUFRO0VBQzNFLENBQUM7RUFFRCxJQUFJO0VBQ0osSUFBSSxJQUFJO0VBQ1IsSUFBSTtFQUVKLElBQUksQ0FBQyxnQ0FBZ0M7R0FDbkMsTUFBTSxRQUFRLENBQUMsZ0JBQWdCLEtBQUssSUFBSSxHQUFHLEtBQUEsQ0FBUztHQUNwRCxNQUFNLFFBQVEsR0FBRyx1QkFBdUI7R0FDeEMsTUFBTSxLQUFLLEdBQUcsd0JBQXdCO0dBQ3RDLE1BQU0sTUFBTTtHQUVaLFVBQVUsUUFBUSxRQUFRLE1BQU07R0FFaEMsT0FBTyxJQUFJLEtBQ1QsVUFBVSxRQUFRLEtBQUssTUFBTSxNQUFNLE1BQU0sSUFBSTtHQUcvQyxPQUFPO0VBQ1Q7RUFFQSxNQUFNLHdCQUF3QjtFQUU5QixJQUFJLFlBQVk7RUFFaEIsT0FBTyxJQUFJLEtBQUs7R0FDZCxNQUFNLGNBQWMsd0JBQXdCO0dBQzVDLE1BQU0sYUFBYSx3QkFBd0I7R0FDM0MsSUFBSTtJQUNGLFlBQVksY0FBYyxZQUFZLFNBQVMsSUFBSTtHQUNyRCxTQUFTLE9BQU87SUFDZCxJQUFJLENBQUMsWUFBWTtLQUNmLFVBQVUsUUFBUSxPQUFPLEtBQUs7S0FDOUI7SUFDRjtJQUVBLElBQUk7S0FDRixNQUFNLGlCQUFpQixXQUFXLEtBQUssTUFBTSxLQUFLO0tBRWxELElBQUlGLGNBQU0sV0FBVyxjQUFjLEdBQ2pDLFVBQVUsUUFBUSxRQUFRLGNBQWMsQ0FBQyxDQUFDLFdBQ3hDLGdCQUFnQixLQUFLLE1BQU0sU0FBUyxDQUN0QztJQUVKLFNBQVMsZUFBZTtLQUN0QixVQUFVLFFBQVEsT0FBTyxhQUFhO0lBQ3hDO0lBRUE7R0FDRjtFQUNGO0VBRUEsSUFBSSxDQUFDLFNBQ0gsSUFBSTtHQUNGLFVBQVUsZ0JBQWdCLEtBQUssTUFBTSxTQUFTO0VBQ2hELFNBQVMsT0FBTztHQUNkLFVBQVUsUUFBUSxPQUFPLEtBQUs7RUFDaEM7RUFHRixJQUFJO0VBQ0osTUFBTSx5QkFBeUI7RUFFL0IsT0FBTyxJQUFJLEtBQ1QsVUFBVSxRQUFRLEtBQUsseUJBQXlCLE1BQU0seUJBQXlCLElBQUk7RUFHckYsT0FBTztDQUNUO0NBRUEsT0FBTyxRQUFRO0VBQ2IsU0FBU0QsY0FBWSxLQUFLLFVBQVUsTUFBTTtFQUUxQyxPQUFPLFNBRFUsY0FBYyxPQUFPLFNBQVMsT0FBTyxLQUFLLE9BQU8sbUJBQW1CLE1BQ3JFLEdBQVUsT0FBTyxRQUFRLE9BQU8sZ0JBQWdCO0NBQ2xFO0FBQ0Y7QUFHQUMsY0FBTSxRQUFRO0NBQUM7Q0FBVTtDQUFPO0NBQVE7QUFBUyxHQUFHLFNBQVMsb0JBQW9CLFFBQVE7Q0FFdkYsUUFBTSxVQUFVLFVBQVUsU0FBVSxLQUFLLFFBQVE7RUFDL0MsT0FBTyxLQUFLLFFBQ1ZELGNBQVksVUFBVSxDQUFDLEdBQUc7R0FDeEI7R0FDQTtHQUNBLE1BQU0sVUFBVUMsY0FBTSxXQUFXLFFBQVEsTUFBTSxJQUFJLE9BQU8sT0FBTyxLQUFBO0VBQ25FLENBQUMsQ0FDSDtDQUNGO0FBQ0YsQ0FBQztBQUVEQSxjQUFNLFFBQVE7Q0FBQztDQUFRO0NBQU87Q0FBUztBQUFPLEdBQUcsU0FBUyxzQkFBc0IsUUFBUTtDQUN0RixTQUFTLG1CQUFtQixRQUFRO0VBQ2xDLE9BQU8sU0FBUyxXQUFXLEtBQUssTUFBTSxRQUFRO0dBQzVDLE9BQU8sS0FBSyxRQUNWRCxjQUFZLFVBQVUsQ0FBQyxHQUFHO0lBQ3hCO0lBQ0EsU0FBUyxTQUNMLEVBQ0UsZ0JBQWdCLHNCQUNsQixJQUNBLENBQUM7SUFDTDtJQUNBO0dBQ0YsQ0FBQyxDQUNIO0VBQ0Y7Q0FDRjtDQUVBLFFBQU0sVUFBVSxVQUFVLG1CQUFtQjtDQUk3QyxJQUFJLFdBQVcsU0FDYixRQUFNLFVBQVUsU0FBUyxVQUFVLG1CQUFtQixJQUFJO0FBRTlELENBQUM7Ozs7Ozs7Ozs7QUNwU0QsSUFBTUksZ0JBQU4sTUFBTUEsY0FBWTtDQUNoQixZQUFZLFVBQVU7RUFDcEIsSUFBSSxPQUFPLGFBQWEsWUFDdEIsTUFBTSxJQUFJLFVBQVUsOEJBQThCO0VBR3BELElBQUk7RUFFSixLQUFLLFVBQVUsSUFBSSxRQUFRLFNBQVMsZ0JBQWdCLFNBQVM7R0FDM0QsaUJBQWlCO0VBQ25CLENBQUM7RUFFRCxNQUFNLFFBQVE7RUFHZCxLQUFLLFFBQVEsTUFBTSxXQUFXO0dBQzVCLElBQUksQ0FBQyxNQUFNLFlBQVk7R0FFdkIsSUFBSSxJQUFJLE1BQU0sV0FBVztHQUV6QixPQUFPLE1BQU0sR0FDWCxNQUFNLFdBQVcsRUFBRSxDQUFDLE1BQU07R0FFNUIsTUFBTSxhQUFhO0VBQ3JCLENBQUM7RUFHRCxLQUFLLFFBQVEsUUFBUSxnQkFBZ0I7R0FDbkMsSUFBSTtHQUVKLE1BQU0sVUFBVSxJQUFJLFNBQVMsWUFBWTtJQUN2QyxNQUFNLFVBQVUsT0FBTztJQUN2QixXQUFXO0dBQ2IsQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFXO0dBRW5CLFFBQVEsU0FBUyxTQUFTLFNBQVM7SUFDakMsTUFBTSxZQUFZLFFBQVE7R0FDNUI7R0FFQSxPQUFPO0VBQ1Q7RUFFQSxTQUFTLFNBQVMsT0FBTyxTQUFTLFFBQVEsU0FBUztHQUNqRCxJQUFJLE1BQU0sUUFFUjtHQUdGLE1BQU0sU0FBUyxJQUFJQyxnQkFBYyxTQUFTLFFBQVEsT0FBTztHQUN6RCxlQUFlLE1BQU0sTUFBTTtFQUM3QixDQUFDO0NBQ0g7Ozs7Q0FLQSxtQkFBbUI7RUFDakIsSUFBSSxLQUFLLFFBQ1AsTUFBTSxLQUFLO0NBRWY7Ozs7Q0FNQSxVQUFVLFVBQVU7RUFDbEIsSUFBSSxLQUFLLFFBQVE7R0FDZixTQUFTLEtBQUssTUFBTTtHQUNwQjtFQUNGO0VBRUEsSUFBSSxLQUFLLFlBQ1AsS0FBSyxXQUFXLEtBQUssUUFBUTtPQUU3QixLQUFLLGFBQWEsQ0FBQyxRQUFRO0NBRS9COzs7O0NBTUEsWUFBWSxVQUFVO0VBQ3BCLElBQUksQ0FBQyxLQUFLLFlBQ1I7RUFFRixNQUFNLFFBQVEsS0FBSyxXQUFXLFFBQVEsUUFBUTtFQUM5QyxJQUFJLFVBQVUsSUFDWixLQUFLLFdBQVcsT0FBTyxPQUFPLENBQUM7Q0FFbkM7Q0FFQSxnQkFBZ0I7RUFDZCxNQUFNLGFBQWEsSUFBSSxnQkFBZ0I7RUFFdkMsTUFBTSxTQUFTLFFBQVE7R0FDckIsV0FBVyxNQUFNLEdBQUc7RUFDdEI7RUFFQSxLQUFLLFVBQVUsS0FBSztFQUVwQixXQUFXLE9BQU8sb0JBQW9CLEtBQUssWUFBWSxLQUFLO0VBRTVELE9BQU8sV0FBVztDQUNwQjs7Ozs7Q0FNQSxPQUFPLFNBQVM7RUFDZCxJQUFJO0VBSUosT0FBTztHQUNMLE9BQUEsSUFKZ0JELGNBQVksU0FBUyxTQUFTLEdBQUc7SUFDakQsU0FBUztHQUNYLENBRU07R0FDSjtFQUNGO0NBQ0Y7QUFDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDN0dBLFNBQXdCRSxTQUFPLFVBQVU7Q0FDdkMsT0FBTyxTQUFTLEtBQUssS0FBSztFQUN4QixPQUFPLFNBQVMsTUFBTSxNQUFNLEdBQUc7Q0FDakM7QUFDRjs7Ozs7Ozs7OztBQ2hCQSxTQUF3QkMsZUFBYSxTQUFTO0NBQzVDLE9BQU9DLGNBQU0sU0FBUyxPQUFPLEtBQUssUUFBUSxpQkFBaUI7QUFDN0Q7OztBQ2JBLElBQU1DLG1CQUFpQjtDQUNyQixVQUFVO0NBQ1Ysb0JBQW9CO0NBQ3BCLFlBQVk7Q0FDWixZQUFZO0NBQ1osSUFBSTtDQUNKLFNBQVM7Q0FDVCxVQUFVO0NBQ1YsNkJBQTZCO0NBQzdCLFdBQVc7Q0FDWCxjQUFjO0NBQ2QsZ0JBQWdCO0NBQ2hCLGFBQWE7Q0FDYixpQkFBaUI7Q0FDakIsUUFBUTtDQUNSLGlCQUFpQjtDQUNqQixrQkFBa0I7Q0FDbEIsT0FBTztDQUNQLFVBQVU7Q0FDVixhQUFhO0NBQ2IsVUFBVTtDQUNWLFFBQVE7Q0FDUixtQkFBbUI7Q0FDbkIsbUJBQW1CO0NBQ25CLFlBQVk7Q0FDWixjQUFjO0NBQ2QsaUJBQWlCO0NBQ2pCLFdBQVc7Q0FDWCxVQUFVO0NBQ1Ysa0JBQWtCO0NBQ2xCLGVBQWU7Q0FDZiw2QkFBNkI7Q0FDN0IsZ0JBQWdCO0NBQ2hCLFVBQVU7Q0FDVixNQUFNO0NBQ04sZ0JBQWdCO0NBQ2hCLG9CQUFvQjs7OztDQUlwQixpQkFBaUI7Q0FDakIsaUJBQWlCO0NBQ2pCLFlBQVk7Q0FDWixzQkFBc0I7Q0FDdEIscUJBQXFCO0NBQ3JCLG1CQUFtQjtDQUNuQixXQUFXO0NBQ1gsb0JBQW9COzs7O0NBSXBCLHFCQUFxQjtDQUNyQixzQkFBc0I7Q0FDdEIsUUFBUTtDQUNSLGtCQUFrQjtDQUNsQixVQUFVO0NBQ1YsaUJBQWlCO0NBQ2pCLHNCQUFzQjtDQUN0QixpQkFBaUI7Q0FDakIsNkJBQTZCO0NBQzdCLDRCQUE0QjtDQUM1QixxQkFBcUI7Q0FDckIsZ0JBQWdCO0NBQ2hCLFlBQVk7Q0FDWixvQkFBb0I7Q0FDcEIsZ0JBQWdCO0NBQ2hCLHlCQUF5QjtDQUN6Qix1QkFBdUI7Q0FDdkIscUJBQXFCO0NBQ3JCLGNBQWM7Q0FDZCxhQUFhO0NBQ2IsK0JBQStCO0NBQy9CLGdDQUFnQztDQUNoQyxpQkFBaUI7Q0FDakIsb0JBQW9CO0NBQ3BCLHFCQUFxQjtDQUNyQixpQkFBaUI7Q0FDakIsb0JBQW9CO0NBQ3BCLHVCQUF1QjtBQUN6QjtBQUVBLE9BQU8sUUFBUUEsZ0JBQWMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLFdBQVc7Q0FDdkQsSUFBSUEsaUJBQWUsV0FBVyxLQUFBLEdBQzVCLGlCQUFlLFNBQVM7QUFFNUIsQ0FBQzs7Ozs7Ozs7OztBQzFERCxTQUFTLGVBQWUsZUFBZTtDQUNyQyxNQUFNLFVBQVUsSUFBSUMsUUFBTSxhQUFhO0NBQ3ZDLE1BQU0sV0FBVyxLQUFLQSxRQUFNLFVBQVUsU0FBUyxPQUFPO0NBR3RELGNBQU0sT0FBTyxVQUFVQSxRQUFNLFdBQVcsU0FBUyxFQUFFLFlBQVksS0FBSyxDQUFDO0NBR3JFLGNBQU0sT0FBTyxVQUFVLFNBQVMsTUFBTSxFQUFFLFlBQVksS0FBSyxDQUFDO0NBRzFELFNBQVMsU0FBUyxTQUFTLE9BQU8sZ0JBQWdCO0VBQ2hELE9BQU8sZUFBZUMsY0FBWSxlQUFlLGNBQWMsQ0FBQztDQUNsRTtDQUVBLE9BQU87QUFDVDtBQUdBLElBQU0sUUFBUSxlQUFlLFFBQVE7QUFHckMsTUFBTSxRQUFRRDtBQUdkLE1BQU0sZ0JBQWdCRTtBQUN0QixNQUFNLGNBQWNDO0FBQ3BCLE1BQU0sV0FBV0M7QUFDakIsTUFBTSxVQUFVQztBQUNoQixNQUFNLGFBQWFDO0FBR25CLE1BQU0sYUFBYUM7QUFHbkIsTUFBTSxTQUFTLE1BQU07QUFHckIsTUFBTSxNQUFNLFNBQVMsSUFBSSxVQUFVO0NBQ2pDLE9BQU8sUUFBUSxJQUFJLFFBQVE7QUFDN0I7QUFFQSxNQUFNLFNBQVNDO0FBR2YsTUFBTSxlQUFlQztBQUdyQixNQUFNLGNBQWNSO0FBRXBCLE1BQU0sZUFBZVM7QUFFckIsTUFBTSxjQUFjLFVBQVUsZUFBZUMsY0FBTSxXQUFXLEtBQUssSUFBSSxJQUFJLFNBQVMsS0FBSyxJQUFJLEtBQUs7QUFFbEcsTUFBTSxhQUFhQyxpQkFBUztBQUU1QixNQUFNLGlCQUFpQkM7QUFFdkIsTUFBTSxVQUFVOzs7QUNoRmhCLElBQU0sRUFDSixPQUNBLFlBQ0EsZUFDQSxVQUNBLGFBQ0EsU0FDQSxLQUNBLFFBQ0EsY0FDQSxRQUNBLFlBQ0EsY0FDQSxnQkFDQSxZQUNBLFlBQ0EsYUFDQSxXQUNFIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDMsNCw1LDYsNyw4LDksMTAsMTEsMTIsMTMsMTQsMTUsMTYsMTcsMTgsMTksMjAsMjEsMjIsMjMsMjQsMjUsMjYsMjcsMjgsMjksMzAsMzEsMzIsMzMsMzQsMzUsMzYsMzcsMzgsMzksNDAsNDEsNDIsNDMsNDQsNDUsNDYsNDcsNDgsNDksNTAsNTEsNTIsNTNdfQ==