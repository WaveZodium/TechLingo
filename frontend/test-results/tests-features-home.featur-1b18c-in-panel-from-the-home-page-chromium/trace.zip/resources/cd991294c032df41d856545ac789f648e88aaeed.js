import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/Navbar.tsx");const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import { Link, NavLink } from "/node_modules/.vite/deps/react-router-dom.js?v=57280423";
import { useAuth } from "/src/context/AuthContext.tsx";
import logo from "/src/assets/TechlingoALTlogo.png?import";
import "/src/styles/Navbar.css";
var _jsxFileName = "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/layout/Navbar.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=57280423";
var _s = $RefreshSig$();
function Navbar({ onLoginClick }) {
	_s();
	const { isAuth, role, logoutUser } = useAuth();
	return /* @__PURE__ */ _jsxDEV("header", {
		className: "navbar",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "navbar__content",
			children: [
				/* @__PURE__ */ _jsxDEV(Link, {
					to: "/",
					className: "navbar__logo-link",
					"aria-label": "TechLingo home",
					children: /* @__PURE__ */ _jsxDEV("img", {
						src: logo,
						alt: "TechLingo",
						className: "navbar__logo"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 20,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 19,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("nav", {
					className: "navbar__links",
					children: [
						/* @__PURE__ */ _jsxDEV(NavLink, {
							to: "/",
							end: true,
							className: ({ isActive }) => `navbar__link ${isActive ? "navbar__link--active" : ""}`,
							children: "Home"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 24,
							columnNumber: 11
						}, this),
						isAuth && /* @__PURE__ */ _jsxDEV(NavLink, {
							to: "/categories",
							className: ({ isActive }) => `navbar__link ${isActive ? "navbar__link--active" : ""}`,
							children: "Categories"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 35,
							columnNumber: 13
						}, this),
						role === "Admin" && /* @__PURE__ */ _jsxDEV(NavLink, {
							to: "/admin",
							className: ({ isActive }) => `navbar__link ${isActive ? "navbar__link--active" : ""}`,
							children: "Admin panel"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 23,
					columnNumber: 9
				}, this),
				isAuth ? /* @__PURE__ */ _jsxDEV("button", {
					onClick: logoutUser,
					className: "navbar__login",
					type: "button",
					children: [/* @__PURE__ */ _jsxDEV("svg", {
						className: "navbar__login-icon",
						viewBox: "0 0 24 24",
						"aria-hidden": "true",
						children: [/* @__PURE__ */ _jsxDEV("circle", {
							cx: "12",
							cy: "8",
							r: "4"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("path", { d: "M5 21v-2a7 7 0 0 1 14 0v2" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 65,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Logout" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 11
				}, this) : /* @__PURE__ */ _jsxDEV("button", {
					onClick: onLoginClick,
					className: "navbar__login",
					type: "button",
					children: [/* @__PURE__ */ _jsxDEV("svg", {
						className: "navbar__login-icon",
						viewBox: "0 0 24 24",
						"aria-hidden": "true",
						children: [/* @__PURE__ */ _jsxDEV("circle", {
							cx: "12",
							cy: "8",
							r: "4"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("path", { d: "M5 21v-2a7 7 0 0 1 14 0v2" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Login" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 85,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 18,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 5
	}, this);
}
_s(Navbar, "kjKbkku70VjQMnLSjHhNef+KKVw=", false, function() {
	return [useAuth];
});
_c = Navbar;
export default Navbar;
var _c;
$RefreshReg$(_c, "Navbar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/Navbar.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/layout/Navbar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/layout/Navbar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/layout/Navbar.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxNQUFNLGVBQWU7QUFFOUIsU0FBUyxlQUFlO0FBRXhCLE9BQU8sVUFBVTtBQUVqQixPQUFPOzs7O0FBTVAsU0FBUyxPQUFPLEVBQUUsZ0JBQTZCOztDQUM3QyxNQUFNLEVBQUUsUUFBUSxNQUFNLGVBQWUsUUFBUTtDQUU3QyxPQUNFLHdCQUFDLFVBQUQ7RUFBUSxXQUFVO1lBQ2hCLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxNQUFEO0tBQU0sSUFBRztLQUFJLFdBQVU7S0FBb0IsY0FBVztlQUNwRCx3QkFBQyxPQUFEO01BQUssS0FBSztNQUFNLEtBQUk7TUFBWSxXQUFVO0tBQWdCOzs7OztJQUN0RDs7Ozs7SUFFTix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsU0FBRDtPQUNFLElBQUc7T0FDSDtPQUNBLFlBQVksRUFBRSxlQUNaLGdCQUFnQixXQUFXLHlCQUF5QjtpQkFFdkQ7TUFFUTs7Ozs7TUFFUixVQUNDLHdCQUFDLFNBQUQ7T0FDRSxJQUFHO09BQ0gsWUFBWSxFQUFFLGVBQ1osZ0JBQWdCLFdBQVcseUJBQXlCO2lCQUV2RDtNQUVROzs7OztNQUdWLFNBQVMsV0FDUix3QkFBQyxTQUFEO09BQ0UsSUFBRztPQUNILFlBQVksRUFBRSxlQUNaLGdCQUFnQixXQUFXLHlCQUF5QjtpQkFFdkQ7TUFFUTs7Ozs7S0FFUjs7Ozs7O0lBRUosU0FDQyx3QkFBQyxVQUFEO0tBQVEsU0FBUztLQUFZLFdBQVU7S0FBZ0IsTUFBSztlQUE1RCxDQUNFLHdCQUFDLE9BQUQ7TUFDRSxXQUFVO01BQ1YsU0FBUTtNQUNSLGVBQVk7Z0JBSGQsQ0FLRSx3QkFBQyxVQUFEO09BQVEsSUFBRztPQUFLLElBQUc7T0FBSSxHQUFFO01BQUs7Ozs7Z0JBQzlCLHdCQUFDLFFBQUQsRUFBTSxHQUFFLDRCQUE2Qjs7OztjQUNsQzs7Ozs7ZUFFTCx3QkFBQyxRQUFELFlBQU0sU0FBWTs7OzthQUNaOzs7OztlQUVSLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsV0FBVTtLQUNWLE1BQUs7ZUFIUCxDQUtFLHdCQUFDLE9BQUQ7TUFDRSxXQUFVO01BQ1YsU0FBUTtNQUNSLGVBQVk7Z0JBSGQsQ0FLRSx3QkFBQyxVQUFEO09BQVEsSUFBRztPQUFLLElBQUc7T0FBSSxHQUFFO01BQUs7Ozs7Z0JBQzlCLHdCQUFDLFFBQUQsRUFBTSxHQUFFLDRCQUE2Qjs7OztjQUNsQzs7Ozs7ZUFFTCx3QkFBQyxRQUFELFlBQU0sUUFBVzs7OzthQUNYOzs7Ozs7R0FFUDs7Ozs7O0NBQ0M7Ozs7O0FBRVo7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJOYXZiYXIudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmssIE5hdkxpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5cclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCIuLi8uLi9jb250ZXh0L0F1dGhDb250ZXh0XCI7XHJcblxyXG5pbXBvcnQgbG9nbyBmcm9tIFwiLi4vLi4vYXNzZXRzL1RlY2hsaW5nb0FMVGxvZ28ucG5nXCI7XHJcblxyXG5pbXBvcnQgXCIuLi8uLi9zdHlsZXMvTmF2YmFyLmNzc1wiO1xyXG5cclxuaW50ZXJmYWNlIE5hdmJhclByb3BzIHtcclxuICBvbkxvZ2luQ2xpY2s6ICgpID0+IHZvaWQ7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIE5hdmJhcih7IG9uTG9naW5DbGljayB9OiBOYXZiYXJQcm9wcykge1xyXG4gIGNvbnN0IHsgaXNBdXRoLCByb2xlLCBsb2dvdXRVc2VyIH0gPSB1c2VBdXRoKCk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8aGVhZGVyIGNsYXNzTmFtZT1cIm5hdmJhclwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5hdmJhcl9fY29udGVudFwiPlxyXG4gICAgICAgIDxMaW5rIHRvPVwiL1wiIGNsYXNzTmFtZT1cIm5hdmJhcl9fbG9nby1saW5rXCIgYXJpYS1sYWJlbD1cIlRlY2hMaW5nbyBob21lXCI+XHJcbiAgICAgICAgICA8aW1nIHNyYz17bG9nb30gYWx0PVwiVGVjaExpbmdvXCIgY2xhc3NOYW1lPVwibmF2YmFyX19sb2dvXCIgLz5cclxuICAgICAgICA8L0xpbms+XHJcblxyXG4gICAgICAgIDxuYXYgY2xhc3NOYW1lPVwibmF2YmFyX19saW5rc1wiPlxyXG4gICAgICAgICAgPE5hdkxpbmtcclxuICAgICAgICAgICAgdG89XCIvXCJcclxuICAgICAgICAgICAgZW5kXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT5cclxuICAgICAgICAgICAgICBgbmF2YmFyX19saW5rICR7aXNBY3RpdmUgPyBcIm5hdmJhcl9fbGluay0tYWN0aXZlXCIgOiBcIlwifWBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBIb21lXHJcbiAgICAgICAgICA8L05hdkxpbms+XHJcblxyXG4gICAgICAgICAge2lzQXV0aCAmJiAoXHJcbiAgICAgICAgICAgIDxOYXZMaW5rXHJcbiAgICAgICAgICAgICAgdG89XCIvY2F0ZWdvcmllc1wiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXsoeyBpc0FjdGl2ZSB9KSA9PlxyXG4gICAgICAgICAgICAgICAgYG5hdmJhcl9fbGluayAke2lzQWN0aXZlID8gXCJuYXZiYXJfX2xpbmstLWFjdGl2ZVwiIDogXCJcIn1gXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgQ2F0ZWdvcmllc1xyXG4gICAgICAgICAgICA8L05hdkxpbms+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHtyb2xlID09PSBcIkFkbWluXCIgJiYgKFxyXG4gICAgICAgICAgICA8TmF2TGlua1xyXG4gICAgICAgICAgICAgIHRvPVwiL2FkbWluXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9eyh7IGlzQWN0aXZlIH0pID0+XHJcbiAgICAgICAgICAgICAgICBgbmF2YmFyX19saW5rICR7aXNBY3RpdmUgPyBcIm5hdmJhcl9fbGluay0tYWN0aXZlXCIgOiBcIlwifWBcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBBZG1pbiBwYW5lbFxyXG4gICAgICAgICAgICA8L05hdkxpbms+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvbmF2PlxyXG5cclxuICAgICAgICB7aXNBdXRoID8gKFxyXG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtsb2dvdXRVc2VyfSBjbGFzc05hbWU9XCJuYXZiYXJfX2xvZ2luXCIgdHlwZT1cImJ1dHRvblwiPlxyXG4gICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibmF2YmFyX19sb2dpbi1pY29uXCJcclxuICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGNpcmNsZSBjeD1cIjEyXCIgY3k9XCI4XCIgcj1cIjRcIiAvPlxyXG4gICAgICAgICAgICAgIDxwYXRoIGQ9XCJNNSAyMXYtMmE3IDcgMCAwIDEgMTQgMHYyXCIgLz5cclxuICAgICAgICAgICAgPC9zdmc+XHJcblxyXG4gICAgICAgICAgICA8c3Bhbj5Mb2dvdXQ8L3NwYW4+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkxvZ2luQ2xpY2t9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cIm5hdmJhcl9fbG9naW5cIlxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm5hdmJhcl9fbG9naW4taWNvblwiXHJcbiAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxjaXJjbGUgY3g9XCIxMlwiIGN5PVwiOFwiIHI9XCI0XCIgLz5cclxuICAgICAgICAgICAgICA8cGF0aCBkPVwiTTUgMjF2LTJhNyA3IDAgMCAxIDE0IDB2MlwiIC8+XHJcbiAgICAgICAgICAgIDwvc3ZnPlxyXG5cclxuICAgICAgICAgICAgPHNwYW4+TG9naW48L3NwYW4+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvaGVhZGVyPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IE5hdmJhcjtcclxuIl19