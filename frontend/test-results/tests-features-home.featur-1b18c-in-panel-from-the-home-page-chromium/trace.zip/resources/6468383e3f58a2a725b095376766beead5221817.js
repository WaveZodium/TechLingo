import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/styles/Layout.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/abbas/Desktop/TechLingo/frontend/src/styles/Layout.css"
const __vite__css = ".layout {\r\n  position: relative;\r\n  width: 100%;\r\n  min-height: 100vh;\r\n  background-color: var(--color-background);\r\n}\r\n\r\n.layout-background {\r\n  position: fixed;\r\n  inset: 0;\r\n  z-index: 0;\r\n  pointer-events: none;\r\n}\r\n\r\n.layout-content {\r\n  position: relative;\r\n  z-index: 1;\r\n  width: 100%;\r\n  min-height: 100vh;\r\n}\r\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))