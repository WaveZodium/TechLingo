import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CategoriesPage.tsx");const useEffect = __vite__cjsImport1_react["useEffect"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=57280423";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=57280423";
import "/src/styles/CategoriesPage.css";
import { getCategories } from "/src/api/categoryApi.ts";
var _jsxFileName = "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/pages/CategoriesPage.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=57280423";
var _s = $RefreshSig$();
function CategoriesPage() {
	_s();
	// Sparar kategorierna som hämtas från backend.
	const [categories, setCategories] = useState([]);
	const [isLoading, setIsLoading] = useState(true);
	const [error, setError] = useState(null);
	// Hämtar kategorier när sidan laddas första gången.
	useEffect(() => {
		async function loadCategories() {
			try {
				setIsLoading(true);
				setError(null);
				const data = await getCategories();
				setCategories(data);
			} catch (error) {
				console.error("Failed to load categories:", error);
				setError("Could not load categories.");
			} finally {
				setIsLoading(false);
			}
		}
		loadCategories();
	}, []);
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "category",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "category__content",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "category__header",
				children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "category__title",
					children: "Choose a category"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "category__description",
					children: "Pick a topic you want to master. Each quiz is fun, fast and packed with useful knowledge!"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "category__categories",
				children: [
					isLoading && /* @__PURE__ */ _jsxDEV("p", { children: "Loading categories..." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 25
					}, this),
					error && /* @__PURE__ */ _jsxDEV("p", { children: error }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 21
					}, this),
					!isLoading && !error && categories.map((category, index) => /* @__PURE__ */ _jsxDEV("article", {
						className: "category__card",
						style: { animationDelay: `${index * -2}s` },
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "category__card-content",
							children: [
								/* @__PURE__ */ _jsxDEV("h2", {
									className: "category__card-title",
									children: category.name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 64,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "category__card-description",
									children: category.description
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 66,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV(Link, {
									to: `/quiz/${category.id}`,
									className: "category__button",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "Start quiz" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 74,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										"aria-hidden": "true",
										children: "→"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 75,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 70,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 63,
							columnNumber: 17
						}, this)
					}, category.id, false, {
						fileName: _jsxFileName,
						lineNumber: 56,
						columnNumber: 15
					}, this))
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 38,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 37,
		columnNumber: 5
	}, this);
}
_s(CategoriesPage, "tokiekIHlmfxI387POURmOZ6R0M=");
_c = CategoriesPage;
export default CategoriesPage;
var _c;
$RefreshReg$(_c, "CategoriesPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/CategoriesPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/pages/CategoriesPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/pages/CategoriesPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/pages/CategoriesPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsV0FBVyxnQkFBZ0I7QUFFcEMsT0FBTztBQUVQLFNBQVMscUJBQXFCOzs7O0FBRzlCLFNBQVMsaUJBQWlCOzs7Q0FFeEIsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQXFCLENBQUMsQ0FBQztDQUMzRCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxJQUFJO0NBQy9DLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBd0IsSUFBSTs7Q0FHdEQsZ0JBQWdCO0VBQ2QsZUFBZSxpQkFBaUI7R0FDOUIsSUFBSTtJQUNGLGFBQWEsSUFBSTtJQUNqQixTQUFTLElBQUk7SUFFYixNQUFNLE9BQU8sTUFBTSxjQUFjO0lBRWpDLGNBQWMsSUFBSTtHQUNwQixTQUFTLE9BQU87SUFDZCxRQUFRLE1BQU0sOEJBQThCLEtBQUs7SUFDakQsU0FBUyw0QkFBNEI7R0FDdkMsVUFBVTtJQUNSLGFBQWEsS0FBSztHQUNwQjtFQUNGO0VBRUEsZUFBZTtDQUNqQixHQUFHLENBQUMsQ0FBQztDQUVMLE9BQ0Usd0JBQUMsV0FBRDtFQUFTLFdBQVU7WUFDakIsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFrQjtJQUFxQjs7OztjQUVyRCx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUF3QjtJQUdsQzs7OztZQUNBOzs7OzthQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRyxhQUFhLHdCQUFDLEtBQUQsWUFBRyx3QkFBd0I7Ozs7O0tBRXhDLFNBQVMsd0JBQUMsS0FBRCxZQUFJLE1BQVM7Ozs7O0tBRXRCLENBQUMsYUFDQSxDQUFDLFNBQ0QsV0FBVyxLQUFLLFVBQVUsVUFDeEIsd0JBQUMsV0FBRDtNQUNFLFdBQVU7TUFFVixPQUFPLEVBQ0wsZ0JBQWdCLEdBQUcsUUFBUSxDQUFDLEVBQUUsR0FDaEM7Z0JBRUEsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBd0IsU0FBUztRQUFTOzs7OztRQUV4RCx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFDVixTQUFTO1FBQ1Q7Ozs7O1FBRUgsd0JBQUMsTUFBRDtTQUNFLElBQUksU0FBUyxTQUFTO1NBQ3RCLFdBQVU7bUJBRlosQ0FJRSx3QkFBQyxRQUFELFlBQU0sYUFBZ0I7Ozs7bUJBQ3RCLHdCQUFDLFFBQUQ7VUFBTSxlQUFZO29CQUFPO1NBQU87Ozs7aUJBQzVCOzs7Ozs7T0FDSDs7Ozs7O0tBQ0UsR0FwQkYsU0FBUzs7OztZQW9CUCxDQUNWO0lBQ0E7Ozs7O1dBQ0Y7Ozs7OztDQUNFOzs7OztBQUViOzs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNhdGVnb3JpZXNQYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuaW1wb3J0IFwiLi4vc3R5bGVzL0NhdGVnb3JpZXNQYWdlLmNzc1wiO1xyXG5cclxuaW1wb3J0IHsgZ2V0Q2F0ZWdvcmllcyB9IGZyb20gXCIuLi9hcGkvY2F0ZWdvcnlBcGlcIjtcclxuaW1wb3J0IHR5cGUgeyBDYXRlZ29yeSB9IGZyb20gXCIuLi90eXBlcy9jYXRlZ29yeVwiO1xyXG5cclxuZnVuY3Rpb24gQ2F0ZWdvcmllc1BhZ2UoKSB7XHJcbiAgLy8gU3BhcmFyIGthdGVnb3JpZXJuYSBzb20gaMOkbXRhcyBmcsOlbiBiYWNrZW5kLlxyXG4gIGNvbnN0IFtjYXRlZ29yaWVzLCBzZXRDYXRlZ29yaWVzXSA9IHVzZVN0YXRlPENhdGVnb3J5W10+KFtdKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuXHJcbiAgLy8gSMOkbXRhciBrYXRlZ29yaWVyIG7DpHIgc2lkYW4gbGFkZGFzIGbDtnJzdGEgZ8Olbmdlbi5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgYXN5bmMgZnVuY3Rpb24gbG9hZENhdGVnb3JpZXMoKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIHNldEVycm9yKG51bGwpO1xyXG5cclxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgZ2V0Q2F0ZWdvcmllcygpO1xyXG5cclxuICAgICAgICBzZXRDYXRlZ29yaWVzKGRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gbG9hZCBjYXRlZ29yaWVzOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0RXJyb3IoXCJDb3VsZCBub3QgbG9hZCBjYXRlZ29yaWVzLlwiKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbG9hZENhdGVnb3JpZXMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJjYXRlZ29yeVwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhdGVnb3J5X19jb250ZW50XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXRlZ29yeV9faGVhZGVyXCI+XHJcbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwiY2F0ZWdvcnlfX3RpdGxlXCI+Q2hvb3NlIGEgY2F0ZWdvcnk8L2gxPlxyXG5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImNhdGVnb3J5X19kZXNjcmlwdGlvblwiPlxyXG4gICAgICAgICAgICBQaWNrIGEgdG9waWMgeW91IHdhbnQgdG8gbWFzdGVyLiBFYWNoIHF1aXogaXMgZnVuLCBmYXN0IGFuZCBwYWNrZWRcclxuICAgICAgICAgICAgd2l0aCB1c2VmdWwga25vd2xlZGdlIVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhdGVnb3J5X19jYXRlZ29yaWVzXCI+XHJcbiAgICAgICAgICB7aXNMb2FkaW5nICYmIDxwPkxvYWRpbmcgY2F0ZWdvcmllcy4uLjwvcD59XHJcblxyXG4gICAgICAgICAge2Vycm9yICYmIDxwPntlcnJvcn08L3A+fVxyXG5cclxuICAgICAgICAgIHshaXNMb2FkaW5nICYmXHJcbiAgICAgICAgICAgICFlcnJvciAmJlxyXG4gICAgICAgICAgICBjYXRlZ29yaWVzLm1hcCgoY2F0ZWdvcnksIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgPGFydGljbGVcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNhdGVnb3J5X19jYXJkXCJcclxuICAgICAgICAgICAgICAgIGtleT17Y2F0ZWdvcnkuaWR9XHJcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICBhbmltYXRpb25EZWxheTogYCR7aW5kZXggKiAtMn1zYCxcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXRlZ29yeV9fY2FyZC1jb250ZW50XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJjYXRlZ29yeV9fY2FyZC10aXRsZVwiPntjYXRlZ29yeS5uYW1lfTwvaDI+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJjYXRlZ29yeV9fY2FyZC1kZXNjcmlwdGlvblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeS5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICB0bz17YC9xdWl6LyR7Y2F0ZWdvcnkuaWR9YH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjYXRlZ29yeV9fYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlN0YXJ0IHF1aXo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gYXJpYS1oaWRkZW49XCJ0cnVlXCI+4oaSPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2FydGljbGU+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDYXRlZ29yaWVzUGFnZTtcclxuIl19