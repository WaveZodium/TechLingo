import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_API_URL": "http://localhost:5121/api"};import axios from "/node_modules/.vite/deps/axios.js?v=99106a80";
const API_URL = import.meta.env.VITE_API_URL;
const api = axios.create({
	baseURL: API_URL,
	headers: { "Content-Type": "application/json" }
});
api.interceptors.request.use((config) => {
	const token = localStorage.getItem("token");
	if (token) {
		config.headers.Authorization = `Bearer ${token}`;
	}
	return config;
});
export default api;

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBRWxCLE1BQU0sVUFBVSxZQUFZLElBQUk7QUFFaEMsTUFBTSxNQUFNLE1BQU0sT0FBTztDQUN2QixTQUFTO0NBQ1QsU0FBUyxFQUNQLGdCQUFnQixtQkFDbEI7QUFDRixDQUFDO0FBRUQsSUFBSSxhQUFhLFFBQVEsS0FBSyxXQUFXO0NBQ3ZDLE1BQU0sUUFBUSxhQUFhLFFBQVEsT0FBTztDQUUxQyxJQUFJLE9BQU87RUFDVCxPQUFPLFFBQVEsZ0JBQWdCLFVBQVU7Q0FDM0M7Q0FFQSxPQUFPO0FBQ1QsQ0FBQztBQUVELGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiYXBpLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuXHJcbmNvbnN0IEFQSV9VUkwgPSBpbXBvcnQubWV0YS5lbnYuVklURV9BUElfVVJMO1xyXG5cclxuY29uc3QgYXBpID0gYXhpb3MuY3JlYXRlKHtcclxuICBiYXNlVVJMOiBBUElfVVJMLFxyXG4gIGhlYWRlcnM6IHtcclxuICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxyXG4gIH0sXHJcbn0pO1xyXG5cclxuYXBpLmludGVyY2VwdG9ycy5yZXF1ZXN0LnVzZSgoY29uZmlnKSA9PiB7XHJcbiAgY29uc3QgdG9rZW4gPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInRva2VuXCIpO1xyXG5cclxuICBpZiAodG9rZW4pIHtcclxuICAgIGNvbmZpZy5oZWFkZXJzLkF1dGhvcml6YXRpb24gPSBgQmVhcmVyICR7dG9rZW59YDtcclxuICB9XHJcblxyXG4gIHJldHVybiBjb25maWc7XHJcbn0pO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgYXBpO1xyXG4iXX0=