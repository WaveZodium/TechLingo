import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/styles/Iridescence.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/styles/Iridescence.css"
const __vite__css = ".iridescence-container {\r\n  width: 100%;\r\n  height: 100%;\r\n}\r\n\r\n.iridescence-container canvas {\r\n  display: block;\r\n  width: 100%;\r\n  height: 100%;\r\n}\r\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))