import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/auth/ProtectedRoute.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { Navigate, Outlet } from "/node_modules/.vite/deps/react-router-dom.js?v=57280423";
import { useAuth } from "/src/context/AuthContext.tsx";
var _jsxFileName = "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/auth/ProtectedRoute.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=57280423";
var _s = $RefreshSig$();
function ProtectedRoute({ requiredRole }) {
	_s();
	const { isAuth, role } = useAuth();
	if (!isAuth) {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/",
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 12
		}, this);
	}
	if (requiredRole && role !== requiredRole) {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/",
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 18,
			columnNumber: 12
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 21,
		columnNumber: 10
	}, this);
}
_s(ProtectedRoute, "sMuHApBgIAKrQHKSiOazxBHB520=", false, function() {
	return [useAuth];
});
_c = ProtectedRoute;
export default ProtectedRoute;
var _c;
$RefreshReg$(_c, "ProtectedRoute");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/auth/ProtectedRoute.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/auth/ProtectedRoute.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/auth/ProtectedRoute.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/auth/ProtectedRoute.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGNBQWM7QUFFakMsU0FBUyxlQUFlOzs7O0FBT3hCLFNBQVMsZUFBZSxFQUFFLGdCQUFxQzs7Q0FDN0QsTUFBTSxFQUFFLFFBQVEsU0FBUyxRQUFRO0NBRWpDLElBQUksQ0FBQyxRQUFRO0VBQ1gsT0FBTyx3QkFBQyxVQUFEO0dBQVUsSUFBRztHQUFJO0VBQVM7Ozs7O0NBQ25DO0NBRUEsSUFBSSxnQkFBZ0IsU0FBUyxjQUFjO0VBQ3pDLE9BQU8sd0JBQUMsVUFBRDtHQUFVLElBQUc7R0FBSTtFQUFTOzs7OztDQUNuQztDQUVBLE9BQU8sd0JBQUMsUUFBRCxDQUFTOzs7OztBQUNsQjs7Ozs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlByb3RlY3RlZFJvdXRlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOYXZpZ2F0ZSwgT3V0bGV0IH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuXHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiLi4vLi4vY29udGV4dC9BdXRoQ29udGV4dFwiO1xyXG5pbXBvcnQgdHlwZSB7IFVzZXJSb2xlIH0gZnJvbSBcIi4uLy4uL2FwaS9hdXRoQXBpXCI7XHJcblxyXG50eXBlIFByb3RlY3RlZFJvdXRlUHJvcHMgPSB7XHJcbiAgcmVxdWlyZWRSb2xlPzogVXNlclJvbGU7XHJcbn07XHJcblxyXG5mdW5jdGlvbiBQcm90ZWN0ZWRSb3V0ZSh7IHJlcXVpcmVkUm9sZSB9OiBQcm90ZWN0ZWRSb3V0ZVByb3BzKSB7XHJcbiAgY29uc3QgeyBpc0F1dGgsIHJvbGUgfSA9IHVzZUF1dGgoKTtcclxuXHJcbiAgaWYgKCFpc0F1dGgpIHtcclxuICAgIHJldHVybiA8TmF2aWdhdGUgdG89XCIvXCIgcmVwbGFjZSAvPjtcclxuICB9XHJcblxyXG4gIGlmIChyZXF1aXJlZFJvbGUgJiYgcm9sZSAhPT0gcmVxdWlyZWRSb2xlKSB7XHJcbiAgICByZXR1cm4gPE5hdmlnYXRlIHRvPVwiL1wiIHJlcGxhY2UgLz47XHJcbiAgfVxyXG5cclxuICByZXR1cm4gPE91dGxldCAvPjtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUHJvdGVjdGVkUm91dGU7XHJcbiJdfQ==