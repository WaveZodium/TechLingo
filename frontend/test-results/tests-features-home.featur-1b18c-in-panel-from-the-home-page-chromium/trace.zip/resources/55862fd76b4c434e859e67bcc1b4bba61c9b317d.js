import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/context/AuthContext.tsx");const createContext = __vite__cjsImport0_react["createContext"]; const useContext = __vite__cjsImport0_react["useContext"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=57280423";
import { isAuthenticated, logout, getTokenExpiration, getToken, getTokenRole } from "/src/api/authApi.ts";
var _jsxFileName = "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/context/AuthContext.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=57280423";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const AuthContext = createContext(undefined);
_c = AuthContext;
export function AuthProvider({ children }) {
	_s();
	const [isAuth, setIsAuth] = useState(isAuthenticated);
	const [role, setRole] = useState(() => {
		const token = getToken();
		if (!token) {
			return null;
		}
		return getTokenRole(token);
	});
	const hasAlertedForExpiredToken = useRef(false);
	function login() {
		const token = getToken();
		setIsAuth(true);
		setRole(token ? getTokenRole(token) : null);
		hasAlertedForExpiredToken.current = false;
	}
	function logoutUser() {
		logout();
		setIsAuth(false);
		setRole(null);
	}
	useEffect(() => {
		function handleTokenExpired() {
			if (!hasAlertedForExpiredToken.current) {
				alert("Your session has expired. Please log in again.");
				hasAlertedForExpiredToken.current = true;
			}
			logout();
			setIsAuth(false);
			setRole(null);
		}
		window.addEventListener("auth-expired", handleTokenExpired);
		if (!isAuth) {
			return () => {
				window.removeEventListener("auth-expired", handleTokenExpired);
			};
		}
		const token = getToken();
		if (!token) {
			setIsAuth(false);
			setRole(null);
			return () => {
				window.removeEventListener("auth-expired", handleTokenExpired);
			};
		}
		const expirationTime = getTokenExpiration(token);
		if (!expirationTime) {
			return () => {
				window.removeEventListener("auth-expired", handleTokenExpired);
			};
		}
		const timeUntilExpiration = expirationTime - Date.now();
		if (timeUntilExpiration <= 0) {
			handleTokenExpired();
			return () => {
				window.removeEventListener("auth-expired", handleTokenExpired);
			};
		}
		const timeout = window.setTimeout(handleTokenExpired, timeUntilExpiration);
		return () => {
			window.clearTimeout(timeout);
			window.removeEventListener("auth-expired", handleTokenExpired);
		};
	}, [isAuth]);
	return /* @__PURE__ */ _jsxDEV(AuthContext.Provider, {
		value: {
			isAuth,
			role,
			login,
			logoutUser
		},
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 122,
		columnNumber: 5
	}, this);
}
_s(AuthProvider, "aEjbvHdaqCJmBkOnvpOCKF4gd10=");
_c2 = AuthProvider;
export function useAuth() {
	_s2();
	const context = useContext(AuthContext);
	if (context === undefined) {
		throw new Error("useAuth must be used within an AuthProvider");
	}
	return context;
}
_s2(useAuth, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c, _c2;
$RefreshReg$(_c, "AuthContext");
$RefreshReg$(_c2, "AuthProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/context/AuthContext.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/context/AuthContext.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/context/AuthContext.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/context/AuthContext.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FDRSxlQUNBLFlBQ0EsV0FDQSxRQUNBLGdCQUVLO0FBRVAsU0FDRSxpQkFDQSxRQUNBLG9CQUNBLFVBQ0Esb0JBRUs7Ozs7QUFhUCxNQUFNLGNBQWMsY0FBMkMsU0FBUzs7QUFFeEUsT0FBTyxTQUFTLGFBQWEsRUFBRSxZQUErQjs7Q0FDNUQsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLGVBQWU7Q0FFcEQsTUFBTSxDQUFDLE1BQU0sV0FBVyxlQUFnQztFQUN0RCxNQUFNLFFBQVEsU0FBUztFQUV2QixJQUFJLENBQUMsT0FBTztHQUNWLE9BQU87RUFDVDtFQUVBLE9BQU8sYUFBYSxLQUFLO0NBQzNCLENBQUM7Q0FFRCxNQUFNLDRCQUE0QixPQUFPLEtBQUs7Q0FFOUMsU0FBUyxRQUFRO0VBQ2YsTUFBTSxRQUFRLFNBQVM7RUFFdkIsVUFBVSxJQUFJO0VBQ2QsUUFBUSxRQUFRLGFBQWEsS0FBSyxJQUFJLElBQUk7RUFFMUMsMEJBQTBCLFVBQVU7Q0FDdEM7Q0FFQSxTQUFTLGFBQWE7RUFDcEIsT0FBTztFQUVQLFVBQVUsS0FBSztFQUNmLFFBQVEsSUFBSTtDQUNkO0NBRUEsZ0JBQWdCO0VBQ2QsU0FBUyxxQkFBcUI7R0FDNUIsSUFBSSxDQUFDLDBCQUEwQixTQUFTO0lBQ3RDLE1BQU0sZ0RBQWdEO0lBQ3RELDBCQUEwQixVQUFVO0dBQ3RDO0dBRUEsT0FBTztHQUVQLFVBQVUsS0FBSztHQUNmLFFBQVEsSUFBSTtFQUNkO0VBRUEsT0FBTyxpQkFBaUIsZ0JBQWdCLGtCQUFrQjtFQUUxRCxJQUFJLENBQUMsUUFBUTtHQUNYLGFBQWE7SUFDWCxPQUFPLG9CQUFvQixnQkFBZ0Isa0JBQWtCO0dBQy9EO0VBQ0Y7RUFFQSxNQUFNLFFBQVEsU0FBUztFQUV2QixJQUFJLENBQUMsT0FBTztHQUNWLFVBQVUsS0FBSztHQUNmLFFBQVEsSUFBSTtHQUVaLGFBQWE7SUFDWCxPQUFPLG9CQUFvQixnQkFBZ0Isa0JBQWtCO0dBQy9EO0VBQ0Y7RUFFQSxNQUFNLGlCQUFpQixtQkFBbUIsS0FBSztFQUUvQyxJQUFJLENBQUMsZ0JBQWdCO0dBQ25CLGFBQWE7SUFDWCxPQUFPLG9CQUFvQixnQkFBZ0Isa0JBQWtCO0dBQy9EO0VBQ0Y7RUFFQSxNQUFNLHNCQUFzQixpQkFBaUIsS0FBSyxJQUFJO0VBRXRELElBQUksdUJBQXVCLEdBQUc7R0FDNUIsbUJBQW1CO0dBRW5CLGFBQWE7SUFDWCxPQUFPLG9CQUFvQixnQkFBZ0Isa0JBQWtCO0dBQy9EO0VBQ0Y7RUFFQSxNQUFNLFVBQVUsT0FBTyxXQUFXLG9CQUFvQixtQkFBbUI7RUFFekUsYUFBYTtHQUNYLE9BQU8sYUFBYSxPQUFPO0dBQzNCLE9BQU8sb0JBQW9CLGdCQUFnQixrQkFBa0I7RUFDL0Q7Q0FDRixHQUFHLENBQUMsTUFBTSxDQUFDO0NBRVgsT0FDRSx3QkFBQyxZQUFZLFVBQWI7RUFBc0IsT0FBTztHQUFFO0dBQVE7R0FBTTtHQUFPO0VBQVc7RUFDNUQ7Q0FDbUI7Ozs7O0FBRTFCOzs7QUFFQSxPQUFPLFNBQVMsVUFBVTs7Q0FDeEIsTUFBTSxVQUFVLFdBQVcsV0FBVztDQUV0QyxJQUFJLFlBQVksV0FBVztFQUN6QixNQUFNLElBQUksTUFBTSw2Q0FBNkM7Q0FDL0Q7Q0FFQSxPQUFPO0FBQ1QiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXV0aENvbnRleHQudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgY3JlYXRlQ29udGV4dCxcclxuICB1c2VDb250ZXh0LFxyXG4gIHVzZUVmZmVjdCxcclxuICB1c2VSZWYsXHJcbiAgdXNlU3RhdGUsXHJcbiAgdHlwZSBSZWFjdE5vZGUsXHJcbn0gZnJvbSBcInJlYWN0XCI7XHJcblxyXG5pbXBvcnQge1xyXG4gIGlzQXV0aGVudGljYXRlZCxcclxuICBsb2dvdXQsXHJcbiAgZ2V0VG9rZW5FeHBpcmF0aW9uLFxyXG4gIGdldFRva2VuLFxyXG4gIGdldFRva2VuUm9sZSxcclxuICB0eXBlIFVzZXJSb2xlLFxyXG59IGZyb20gXCIuLi9hcGkvYXV0aEFwaVwiO1xyXG5cclxudHlwZSBBdXRoQ29udGV4dFR5cGUgPSB7XHJcbiAgaXNBdXRoOiBib29sZWFuO1xyXG4gIHJvbGU6IFVzZXJSb2xlIHwgbnVsbDtcclxuICBsb2dpbjogKCkgPT4gdm9pZDtcclxuICBsb2dvdXRVc2VyOiAoKSA9PiB2b2lkO1xyXG59O1xyXG5cclxudHlwZSBBdXRoUHJvdmlkZXJQcm9wcyA9IHtcclxuICBjaGlsZHJlbjogUmVhY3ROb2RlO1xyXG59O1xyXG5cclxuY29uc3QgQXV0aENvbnRleHQgPSBjcmVhdGVDb250ZXh0PEF1dGhDb250ZXh0VHlwZSB8IHVuZGVmaW5lZD4odW5kZWZpbmVkKTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBBdXRoUHJvdmlkZXIoeyBjaGlsZHJlbiB9OiBBdXRoUHJvdmlkZXJQcm9wcykge1xyXG4gIGNvbnN0IFtpc0F1dGgsIHNldElzQXV0aF0gPSB1c2VTdGF0ZShpc0F1dGhlbnRpY2F0ZWQpO1xyXG5cclxuICBjb25zdCBbcm9sZSwgc2V0Um9sZV0gPSB1c2VTdGF0ZTxVc2VyUm9sZSB8IG51bGw+KCgpID0+IHtcclxuICAgIGNvbnN0IHRva2VuID0gZ2V0VG9rZW4oKTtcclxuXHJcbiAgICBpZiAoIXRva2VuKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBnZXRUb2tlblJvbGUodG9rZW4pO1xyXG4gIH0pO1xyXG5cclxuICBjb25zdCBoYXNBbGVydGVkRm9yRXhwaXJlZFRva2VuID0gdXNlUmVmKGZhbHNlKTtcclxuXHJcbiAgZnVuY3Rpb24gbG9naW4oKSB7XHJcbiAgICBjb25zdCB0b2tlbiA9IGdldFRva2VuKCk7XHJcblxyXG4gICAgc2V0SXNBdXRoKHRydWUpO1xyXG4gICAgc2V0Um9sZSh0b2tlbiA/IGdldFRva2VuUm9sZSh0b2tlbikgOiBudWxsKTtcclxuXHJcbiAgICBoYXNBbGVydGVkRm9yRXhwaXJlZFRva2VuLmN1cnJlbnQgPSBmYWxzZTtcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIGxvZ291dFVzZXIoKSB7XHJcbiAgICBsb2dvdXQoKTtcclxuXHJcbiAgICBzZXRJc0F1dGgoZmFsc2UpO1xyXG4gICAgc2V0Um9sZShudWxsKTtcclxuICB9XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmdW5jdGlvbiBoYW5kbGVUb2tlbkV4cGlyZWQoKSB7XHJcbiAgICAgIGlmICghaGFzQWxlcnRlZEZvckV4cGlyZWRUb2tlbi5jdXJyZW50KSB7XHJcbiAgICAgICAgYWxlcnQoXCJZb3VyIHNlc3Npb24gaGFzIGV4cGlyZWQuIFBsZWFzZSBsb2cgaW4gYWdhaW4uXCIpO1xyXG4gICAgICAgIGhhc0FsZXJ0ZWRGb3JFeHBpcmVkVG9rZW4uY3VycmVudCA9IHRydWU7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGxvZ291dCgpO1xyXG5cclxuICAgICAgc2V0SXNBdXRoKGZhbHNlKTtcclxuICAgICAgc2V0Um9sZShudWxsKTtcclxuICAgIH1cclxuXHJcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImF1dGgtZXhwaXJlZFwiLCBoYW5kbGVUb2tlbkV4cGlyZWQpO1xyXG5cclxuICAgIGlmICghaXNBdXRoKSB7XHJcbiAgICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJhdXRoLWV4cGlyZWRcIiwgaGFuZGxlVG9rZW5FeHBpcmVkKTtcclxuICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCB0b2tlbiA9IGdldFRva2VuKCk7XHJcblxyXG4gICAgaWYgKCF0b2tlbikge1xyXG4gICAgICBzZXRJc0F1dGgoZmFsc2UpO1xyXG4gICAgICBzZXRSb2xlKG51bGwpO1xyXG5cclxuICAgICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImF1dGgtZXhwaXJlZFwiLCBoYW5kbGVUb2tlbkV4cGlyZWQpO1xyXG4gICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGV4cGlyYXRpb25UaW1lID0gZ2V0VG9rZW5FeHBpcmF0aW9uKHRva2VuKTtcclxuXHJcbiAgICBpZiAoIWV4cGlyYXRpb25UaW1lKSB7XHJcbiAgICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJhdXRoLWV4cGlyZWRcIiwgaGFuZGxlVG9rZW5FeHBpcmVkKTtcclxuICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCB0aW1lVW50aWxFeHBpcmF0aW9uID0gZXhwaXJhdGlvblRpbWUgLSBEYXRlLm5vdygpO1xyXG5cclxuICAgIGlmICh0aW1lVW50aWxFeHBpcmF0aW9uIDw9IDApIHtcclxuICAgICAgaGFuZGxlVG9rZW5FeHBpcmVkKCk7XHJcblxyXG4gICAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwiYXV0aC1leHBpcmVkXCIsIGhhbmRsZVRva2VuRXhwaXJlZCk7XHJcbiAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgdGltZW91dCA9IHdpbmRvdy5zZXRUaW1lb3V0KGhhbmRsZVRva2VuRXhwaXJlZCwgdGltZVVudGlsRXhwaXJhdGlvbik7XHJcblxyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgd2luZG93LmNsZWFyVGltZW91dCh0aW1lb3V0KTtcclxuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJhdXRoLWV4cGlyZWRcIiwgaGFuZGxlVG9rZW5FeHBpcmVkKTtcclxuICAgIH07XHJcbiAgfSwgW2lzQXV0aF0pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPEF1dGhDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt7IGlzQXV0aCwgcm9sZSwgbG9naW4sIGxvZ291dFVzZXIgfX0+XHJcbiAgICAgIHtjaGlsZHJlbn1cclxuICAgIDwvQXV0aENvbnRleHQuUHJvdmlkZXI+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHVzZUF1dGgoKSB7XHJcbiAgY29uc3QgY29udGV4dCA9IHVzZUNvbnRleHQoQXV0aENvbnRleHQpO1xyXG5cclxuICBpZiAoY29udGV4dCA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJ1c2VBdXRoIG11c3QgYmUgdXNlZCB3aXRoaW4gYW4gQXV0aFByb3ZpZGVyXCIpO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIGNvbnRleHQ7XHJcbn1cclxuIl19