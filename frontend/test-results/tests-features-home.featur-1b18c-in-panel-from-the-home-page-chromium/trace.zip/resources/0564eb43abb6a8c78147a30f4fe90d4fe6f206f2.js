import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"];import { BrowserRouter as Router, Routes, Route } from "/node_modules/.vite/deps/react-router-dom.js?v=57280423";
import Layout from "/src/components/layout/Layout.tsx";
import ProtectedRoute from "/src/components/auth/ProtectedRoute.tsx";
import HomePage from "/src/pages/HomePage.tsx";
import NotFoundPage from "/src/pages/NotFoundPage.tsx";
import CategoriesPage from "/src/pages/CategoriesPage.tsx";
import QuizPage from "/src/pages/QuizPage.tsx";
import AdminPage from "/src/pages/AdminPage.tsx";
var _jsxFileName = "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/App.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=57280423";
function App() {
	return /* @__PURE__ */ _jsxDEV(Router, { children: /* @__PURE__ */ _jsxDEV(Routes, { children: /* @__PURE__ */ _jsxDEV(Route, {
		element: /* @__PURE__ */ _jsxDEV(Layout, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 18,
			columnNumber: 25
		}, this),
		children: [
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "/",
				element: /* @__PURE__ */ _jsxDEV(HomePage, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 19,
					columnNumber: 36
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 23,
					columnNumber: 27
				}, this),
				children: [/* @__PURE__ */ _jsxDEV(Route, {
					path: "/categories",
					element: /* @__PURE__ */ _jsxDEV(CategoriesPage, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 24,
						columnNumber: 48
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 24,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV(Route, {
					path: "/quiz/:categoryId",
					element: /* @__PURE__ */ _jsxDEV(QuizPage, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 54
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 27,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { requiredRole: "Admin" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 27
				}, this),
				children: /* @__PURE__ */ _jsxDEV(Route, {
					path: "/admin",
					element: /* @__PURE__ */ _jsxDEV(AdminPage, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 31,
						columnNumber: 43
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "*",
				element: /* @__PURE__ */ _jsxDEV(NotFoundPage, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 36
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 11
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 9
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 16,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 5
	}, this);
}
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUIsUUFBUSxRQUFRLGFBQWE7QUFFdkQsT0FBTyxZQUFZO0FBQ25CLE9BQU8sb0JBQW9CO0FBRTNCLE9BQU8sY0FBYztBQUNyQixPQUFPLGtCQUFrQjtBQUN6QixPQUFPLG9CQUFvQjtBQUMzQixPQUFPLGNBQWM7QUFDckIsT0FBTyxlQUFlOzs7QUFFdEIsU0FBUyxNQUFNO0NBQ2IsT0FDRSx3QkFBQyxRQUFELFlBRUUsd0JBQUMsUUFBRCxZQUVFLHdCQUFDLE9BQUQ7RUFBTyxTQUFTLHdCQUFDLFFBQUQsQ0FBUzs7Ozs7WUFBekI7R0FDRSx3QkFBQyxPQUFEO0lBQU8sTUFBSztJQUFJLFNBQVMsd0JBQUMsVUFBRCxDQUFXOzs7OztHQUFJOzs7OztHQUl4Qyx3QkFBQyxPQUFEO0lBQU8sU0FBUyx3QkFBQyxnQkFBRCxDQUFpQjs7Ozs7Y0FBakMsQ0FDRSx3QkFBQyxPQUFEO0tBQU8sTUFBSztLQUFjLFNBQVMsd0JBQUMsZ0JBQUQsQ0FBaUI7Ozs7O0lBQUk7Ozs7Y0FHeEQsd0JBQUMsT0FBRDtLQUFPLE1BQUs7S0FBb0IsU0FBUyx3QkFBQyxVQUFELENBQVc7Ozs7O0lBQUk7Ozs7WUFDbkQ7Ozs7OztHQUVQLHdCQUFDLE9BQUQ7SUFBTyxTQUFTLHdCQUFDLGdCQUFELEVBQWdCLGNBQWEsUUFBUzs7Ozs7Y0FDcEQsd0JBQUMsT0FBRDtLQUFPLE1BQUs7S0FBUyxTQUFTLHdCQUFDLFdBQUQsQ0FBWTs7Ozs7SUFBSTs7Ozs7R0FDekM7Ozs7O0dBR1Asd0JBQUMsT0FBRDtJQUFPLE1BQUs7SUFBSSxTQUFTLHdCQUFDLGNBQUQsQ0FBZTs7Ozs7R0FBSTs7Ozs7RUFDdkM7Ozs7O1VBQ0Q7Ozs7VUFDRjs7Ozs7QUFFWjs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQnJvd3NlclJvdXRlciBhcyBSb3V0ZXIsIFJvdXRlcywgUm91dGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5cclxuaW1wb3J0IExheW91dCBmcm9tIFwiLi9jb21wb25lbnRzL2xheW91dC9MYXlvdXRcIjtcclxuaW1wb3J0IFByb3RlY3RlZFJvdXRlIGZyb20gXCIuL2NvbXBvbmVudHMvYXV0aC9Qcm90ZWN0ZWRSb3V0ZVwiO1xyXG5cclxuaW1wb3J0IEhvbWVQYWdlIGZyb20gXCIuL3BhZ2VzL0hvbWVQYWdlXCI7XHJcbmltcG9ydCBOb3RGb3VuZFBhZ2UgZnJvbSBcIi4vcGFnZXMvTm90Rm91bmRQYWdlXCI7XHJcbmltcG9ydCBDYXRlZ29yaWVzUGFnZSBmcm9tIFwiLi9wYWdlcy9DYXRlZ29yaWVzUGFnZVwiO1xyXG5pbXBvcnQgUXVpelBhZ2UgZnJvbSBcIi4vcGFnZXMvUXVpelBhZ2VcIjtcclxuaW1wb3J0IEFkbWluUGFnZSBmcm9tIFwiLi9wYWdlcy9BZG1pblBhZ2VcIjtcclxuXHJcbmZ1bmN0aW9uIEFwcCgpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPFJvdXRlcj5cclxuICAgICAgey8qIERlZmluaWVyYXIgdmlsa2Ega29tcG9uZW50ZXIgc29tIHNrYSB2aXNhcyBmw7ZyIHJlc3Bla3RpdmUgVVJMLiAqL31cclxuICAgICAgPFJvdXRlcz5cclxuICAgICAgICB7LyogTGF5b3V0IGFudsOkbmRzIHNvbSBnZW1lbnNhbSBzdHJ1a3R1ciBydW50IHNpZG9ybmFzIGlubmVow6VsbC4gKi99XHJcbiAgICAgICAgPFJvdXRlIGVsZW1lbnQ9ezxMYXlvdXQgLz59PlxyXG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCIvXCIgZWxlbWVudD17PEhvbWVQYWdlIC8+fSAvPlxyXG5cclxuICAgICAgICAgIHsvKiBlbmRhc3QgZsO2ciBhbnbDpG5kYXJlICovfVxyXG4gICAgICAgICAgey8qIERlc3NhIHJvdXRlcyBrcsOkdmVyIGF0dCBhbnbDpG5kYXJlbiDDpHIgYXV0ZW50aXNlcmFkLiAqL31cclxuICAgICAgICAgIDxSb3V0ZSBlbGVtZW50PXs8UHJvdGVjdGVkUm91dGUgLz59PlxyXG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9jYXRlZ29yaWVzXCIgZWxlbWVudD17PENhdGVnb3JpZXNQYWdlIC8+fSAvPlxyXG5cclxuICAgICAgICAgICAgey8qIGNhdGVnb3J5SWQgYW52w6RuZHMgZsO2ciBhdHQgaWRlbnRpZmllcmEgdmlsa2VuIGthdGVnb3JpcyBmcsOlZ29yIHNvbSBza2EgaMOkbXRhcy4gKi99XHJcbiAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL3F1aXovOmNhdGVnb3J5SWRcIiBlbGVtZW50PXs8UXVpelBhZ2UgLz59IC8+XHJcbiAgICAgICAgICA8L1JvdXRlPlxyXG4gICAgICAgICAgey8qIEVuZGFzdCBhZG1pbiAqL31cclxuICAgICAgICAgIDxSb3V0ZSBlbGVtZW50PXs8UHJvdGVjdGVkUm91dGUgcmVxdWlyZWRSb2xlPVwiQWRtaW5cIiAvPn0+XHJcbiAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2FkbWluXCIgZWxlbWVudD17PEFkbWluUGFnZSAvPn0gLz5cclxuICAgICAgICAgIDwvUm91dGU+XHJcblxyXG4gICAgICAgICAgey8qIFZpc2FzIG9tIGFudsOkbmRhcmVuIGfDpXIgdGlsbCBlbiByb3V0ZSBzb20gaW50ZSBmaW5ucy4gKi99XHJcbiAgICAgICAgICA8Um91dGUgcGF0aD1cIipcIiBlbGVtZW50PXs8Tm90Rm91bmRQYWdlIC8+fSAvPlxyXG4gICAgICAgIDwvUm91dGU+XHJcbiAgICAgIDwvUm91dGVzPlxyXG4gICAgPC9Sb3V0ZXI+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQXBwO1xyXG4iXX0=