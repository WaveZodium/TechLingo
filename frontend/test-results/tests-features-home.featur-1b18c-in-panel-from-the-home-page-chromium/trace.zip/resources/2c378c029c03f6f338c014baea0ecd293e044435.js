import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/auth/PasswordField.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=57280423";
var _jsxFileName = "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/auth/PasswordField.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=57280423";
var _s = $RefreshSig$();
export default function PasswordField({ id, label, value, onChange, disabled }) {
	_s();
	const [showPassword, setShowPassword] = useState(false);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "auth-form__field",
		children: [/* @__PURE__ */ _jsxDEV("label", {
			htmlFor: id,
			children: label
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "auth-form__password",
			children: [/* @__PURE__ */ _jsxDEV("input", {
				id,
				type: showPassword ? "text" : "password",
				value,
				onChange: (event) => onChange(event.target.value),
				required: true,
				disabled
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				className: "auth-form__password-toggle",
				onClick: () => setShowPassword((prev) => !prev),
				"aria-label": showPassword ? "Hide password" : "Show password",
				children: showPassword ? /* @__PURE__ */ _jsxDEV("svg", {
					viewBox: "0 0 24 24",
					"aria-hidden": "true",
					children: [
						/* @__PURE__ */ _jsxDEV("path", { d: "M3 3l18 18" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 42,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("path", { d: "M10.6 10.7a2 2 0 0 0 2.7 2.7" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 43,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("path", { d: "M9.9 5.1A10.8 10.8 0 0 1 12 5c6.5 0 10 7 10 7a17.6 17.6 0 0 1-3.2 3.8" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 44,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("path", { d: "M6.2 6.3C3.8 8 2 12 2 12s3.5 7 10 7c1.8 0 3.4-.4 4.8-1.1" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 45,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 41,
					columnNumber: 13
				}, this) : /* @__PURE__ */ _jsxDEV("svg", {
					viewBox: "0 0 24 24",
					"aria-hidden": "true",
					children: [/* @__PURE__ */ _jsxDEV("path", { d: "M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6Z" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("circle", {
						cx: "12",
						cy: "12",
						r: "3"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 48,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 21,
		columnNumber: 5
	}, this);
}
_s(PasswordField, "daguiRHWMFkqPgCh/ppD7CF5VuQ=");
_c = PasswordField;
var _c;
$RefreshReg$(_c, "PasswordField");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/auth/PasswordField.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/auth/PasswordField.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/auth/PasswordField.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/auth/PasswordField.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7Ozs7QUFVekIsZUFBZSxTQUFTLGNBQWMsRUFDcEMsSUFDQSxPQUNBLE9BQ0EsVUFDQSxZQUNxQjs7Q0FDckIsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsS0FBSztDQUV0RCxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDRSx3QkFBQyxTQUFEO0dBQU8sU0FBUzthQUFLO0VBQWE7Ozs7WUFFbEMsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLFNBQUQ7SUFDTTtJQUNKLE1BQU0sZUFBZSxTQUFTO0lBQ3ZCO0lBQ1AsV0FBVyxVQUFVLFNBQVMsTUFBTSxPQUFPLEtBQUs7SUFDaEQ7SUFDVTtHQUNYOzs7O2FBRUQsd0JBQUMsVUFBRDtJQUNFLE1BQUs7SUFDTCxXQUFVO0lBQ1YsZUFBZSxpQkFBaUIsU0FBUyxDQUFDLElBQUk7SUFDOUMsY0FBWSxlQUFlLGtCQUFrQjtjQUU1QyxlQUNDLHdCQUFDLE9BQUQ7S0FBSyxTQUFRO0tBQVksZUFBWTtlQUFyQztNQUNFLHdCQUFDLFFBQUQsRUFBTSxHQUFFLGFBQWM7Ozs7O01BQ3RCLHdCQUFDLFFBQUQsRUFBTSxHQUFFLCtCQUFnQzs7Ozs7TUFDeEMsd0JBQUMsUUFBRCxFQUFNLEdBQUUsd0VBQXlFOzs7OztNQUNqRix3QkFBQyxRQUFELEVBQU0sR0FBRSwyREFBNEQ7Ozs7O0tBQ2pFOzs7OztlQUVMLHdCQUFDLE9BQUQ7S0FBSyxTQUFRO0tBQVksZUFBWTtlQUFyQyxDQUNFLHdCQUFDLFFBQUQsRUFBTSxHQUFFLG1EQUFvRDs7OztlQUM1RCx3QkFBQyxVQUFEO01BQVEsSUFBRztNQUFLLElBQUc7TUFBSyxHQUFFO0tBQUs7Ozs7YUFDNUI7Ozs7OztHQUVEOzs7O1dBQ0w7Ozs7O1VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlBhc3N3b3JkRmllbGQudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcblxyXG5pbnRlcmZhY2UgUGFzc3dvcmRGaWVsZFByb3BzIHtcclxuICBpZDogc3RyaW5nO1xyXG4gIGxhYmVsOiBzdHJpbmc7XHJcbiAgdmFsdWU6IHN0cmluZztcclxuICBvbkNoYW5nZTogKHZhbHVlOiBzdHJpbmcpID0+IHZvaWQ7XHJcbiAgZGlzYWJsZWQ/OiBib29sZWFuO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQYXNzd29yZEZpZWxkKHtcclxuICBpZCxcclxuICBsYWJlbCxcclxuICB2YWx1ZSxcclxuICBvbkNoYW5nZSxcclxuICBkaXNhYmxlZCxcclxufTogUGFzc3dvcmRGaWVsZFByb3BzKSB7XHJcbiAgY29uc3QgW3Nob3dQYXNzd29yZCwgc2V0U2hvd1Bhc3N3b3JkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1mb3JtX19maWVsZFwiPlxyXG4gICAgICA8bGFiZWwgaHRtbEZvcj17aWR9PntsYWJlbH08L2xhYmVsPlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWZvcm1fX3Bhc3N3b3JkXCI+XHJcbiAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICBpZD17aWR9XHJcbiAgICAgICAgICB0eXBlPXtzaG93UGFzc3dvcmQgPyBcInRleHRcIiA6IFwicGFzc3dvcmRcIn1cclxuICAgICAgICAgIHZhbHVlPXt2YWx1ZX1cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IG9uQ2hhbmdlKGV2ZW50LnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxyXG4gICAgICAgIC8+XHJcblxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYXV0aC1mb3JtX19wYXNzd29yZC10b2dnbGVcIlxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1Bhc3N3b3JkKChwcmV2KSA9PiAhcHJldil9XHJcbiAgICAgICAgICBhcmlhLWxhYmVsPXtzaG93UGFzc3dvcmQgPyBcIkhpZGUgcGFzc3dvcmRcIiA6IFwiU2hvdyBwYXNzd29yZFwifVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtzaG93UGFzc3dvcmQgPyAoXHJcbiAgICAgICAgICAgIDxzdmcgdmlld0JveD1cIjAgMCAyNCAyNFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxyXG4gICAgICAgICAgICAgIDxwYXRoIGQ9XCJNMyAzbDE4IDE4XCIgLz5cclxuICAgICAgICAgICAgICA8cGF0aCBkPVwiTTEwLjYgMTAuN2EyIDIgMCAwIDAgMi43IDIuN1wiIC8+XHJcbiAgICAgICAgICAgICAgPHBhdGggZD1cIk05LjkgNS4xQTEwLjggMTAuOCAwIDAgMSAxMiA1YzYuNSAwIDEwIDcgMTAgN2ExNy42IDE3LjYgMCAwIDEtMy4yIDMuOFwiIC8+XHJcbiAgICAgICAgICAgICAgPHBhdGggZD1cIk02LjIgNi4zQzMuOCA4IDIgMTIgMiAxMnMzLjUgNyAxMCA3YzEuOCAwIDMuNC0uNCA0LjgtMS4xXCIgLz5cclxuICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8c3ZnIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBhcmlhLWhpZGRlbj1cInRydWVcIj5cclxuICAgICAgICAgICAgICA8cGF0aCBkPVwiTTIgMTJzMy41LTYgMTAtNiAxMCA2IDEwIDYtMy41IDYtMTAgNi0xMC02LTEwLTZaXCIgLz5cclxuICAgICAgICAgICAgICA8Y2lyY2xlIGN4PVwiMTJcIiBjeT1cIjEyXCIgcj1cIjNcIiAvPlxyXG4gICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXX0=