import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/Layout.tsx");const useState = __vite__cjsImport5_react["useState"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import { Outlet } from "/node_modules/.vite/deps/react-router-dom.js?v=57280423";
import Navbar from "/src/components/layout/Navbar.tsx";
import Footer from "/src/components/layout/Footer.tsx";
import "/src/styles/Layout.css";
import Iridescence from "/src/components/iridescence/Iridescence.tsx";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=57280423";
import AuthPanel from "/src/components/auth/AuthPanel.tsx";
var _jsxFileName = "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/layout/Layout.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=57280423";
var _s = $RefreshSig$();
function Layout() {
	_s();
	const [isAuthOpen, setIsAuthOpen] = useState(false);
	function openAuthPanel() {
		setIsAuthOpen(true);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "layout",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "layout-background",
			children: /* @__PURE__ */ _jsxDEV(Iridescence, {
				color: [
					.0039,
					.0863,
					.2157
				],
				mouseReact: false,
				amplitude: .1,
				speed: 1
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 18,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "layout-content",
			children: [
				/* @__PURE__ */ _jsxDEV(Navbar, { onLoginClick: openAuthPanel }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("main", { children: /* @__PURE__ */ _jsxDEV(Outlet, { context: { openAuthPanel } }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 11
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Footer, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(AuthPanel, {
					isOpen: isAuthOpen,
					onClose: () => setIsAuthOpen(false)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 5
	}, this);
}
_s(Layout, "xASa6VDVkMMtxCo5XwieAxfmhBs=");
_c = Layout;
export default Layout;
var _c;
$RefreshReg$(_c, "Layout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/Layout.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/layout/Layout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/layout/Layout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/layout/Layout.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxjQUFjO0FBQ3ZCLE9BQU8sWUFBWTtBQUNuQixPQUFPLFlBQVk7QUFDbkIsT0FBTztBQUNQLE9BQU8saUJBQWlCO0FBQ3hCLFNBQVMsZ0JBQWdCO0FBQ3pCLE9BQU8sZUFBZTs7OztBQUV0QixTQUFTLFNBQVM7O0NBQ2hCLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLEtBQUs7Q0FFbEQsU0FBUyxnQkFBZ0I7RUFDdkIsY0FBYyxJQUFJO0NBQ3BCO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDYix3QkFBQyxhQUFEO0lBQ0UsT0FBTztLQUFDO0tBQVE7S0FBUTtJQUFNO0lBQzlCLFlBQVk7SUFDWixXQUFXO0lBQ1gsT0FBTztHQUNSOzs7OztFQUNFOzs7O1lBRUwsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLFFBQUQsRUFBUSxjQUFjLGNBQWdCOzs7OztJQUV0Qyx3QkFBQyxRQUFELFlBQ0Usd0JBQUMsUUFBRCxFQUFRLFNBQVMsRUFBRSxjQUFjLEVBQUk7Ozs7YUFDakM7Ozs7O0lBRU4sd0JBQUMsUUFBRCxDQUFTOzs7OztJQUNULHdCQUFDLFdBQUQ7S0FBVyxRQUFRO0tBQVksZUFBZSxjQUFjLEtBQUs7SUFBSTs7Ozs7R0FDbEU7Ozs7O1VBQ0Y7Ozs7OztBQUVUOzs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkxheW91dC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgT3V0bGV0IH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi9OYXZiYXJcIjtcclxuaW1wb3J0IEZvb3RlciBmcm9tIFwiLi9Gb290ZXJcIjtcclxuaW1wb3J0IFwiLi4vLi4vc3R5bGVzL0xheW91dC5jc3NcIjtcclxuaW1wb3J0IElyaWRlc2NlbmNlIGZyb20gXCIuLi9pcmlkZXNjZW5jZS9JcmlkZXNjZW5jZVwiO1xyXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgQXV0aFBhbmVsIGZyb20gXCIuLi9hdXRoL0F1dGhQYW5lbFwiO1xyXG5cclxuZnVuY3Rpb24gTGF5b3V0KCkge1xyXG4gIGNvbnN0IFtpc0F1dGhPcGVuLCBzZXRJc0F1dGhPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgZnVuY3Rpb24gb3BlbkF1dGhQYW5lbCgpIHtcclxuICAgIHNldElzQXV0aE9wZW4odHJ1ZSk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJsYXlvdXRcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJsYXlvdXQtYmFja2dyb3VuZFwiPlxyXG4gICAgICAgIDxJcmlkZXNjZW5jZVxyXG4gICAgICAgICAgY29sb3I9e1swLjAwMzksIDAuMDg2MywgMC4yMTU3XX1cclxuICAgICAgICAgIG1vdXNlUmVhY3Q9e2ZhbHNlfVxyXG4gICAgICAgICAgYW1wbGl0dWRlPXswLjF9XHJcbiAgICAgICAgICBzcGVlZD17MX1cclxuICAgICAgICAvPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGF5b3V0LWNvbnRlbnRcIj5cclxuICAgICAgICA8TmF2YmFyIG9uTG9naW5DbGljaz17b3BlbkF1dGhQYW5lbH0gLz5cclxuXHJcbiAgICAgICAgPG1haW4+XHJcbiAgICAgICAgICA8T3V0bGV0IGNvbnRleHQ9e3sgb3BlbkF1dGhQYW5lbCB9fSAvPlxyXG4gICAgICAgIDwvbWFpbj5cclxuXHJcbiAgICAgICAgPEZvb3RlciAvPlxyXG4gICAgICAgIDxBdXRoUGFuZWwgaXNPcGVuPXtpc0F1dGhPcGVufSBvbkNsb3NlPXsoKSA9PiBzZXRJc0F1dGhPcGVuKGZhbHNlKX0gLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBMYXlvdXQ7XHJcbiJdfQ==