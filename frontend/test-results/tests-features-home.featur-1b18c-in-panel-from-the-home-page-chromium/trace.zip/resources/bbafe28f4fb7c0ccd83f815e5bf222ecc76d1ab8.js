import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import { BrowserRouter as Router, Routes, Route } from "/node_modules/.vite/deps/react-router-dom.js?v=99106a80";
import Layout from "/src/components/layout/Layout.tsx";
import ProtectedRoute from "/src/components/auth/ProtectedRoute.tsx";
import HomePage from "/src/pages/HomePage.tsx";
import NotFoundPage from "/src/pages/NotFoundPage.tsx";
import CategoriesPage from "/src/pages/CategoriesPage.tsx";
import QuizPage from "/src/pages/QuizPage.tsx";
var _jsxFileName = "C:/Users/abbas/Desktop/TechLingo/frontend/src/App.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=99106a80";
function App() {
	return /* @__PURE__ */ _jsxDEV(Router, { children: /* @__PURE__ */ _jsxDEV(Routes, { children: /* @__PURE__ */ _jsxDEV(Route, {
		element: /* @__PURE__ */ _jsxDEV(Layout, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 25
		}, this),
		children: [
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "/",
				element: /* @__PURE__ */ _jsxDEV(HomePage, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 18,
					columnNumber: 36
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 22,
					columnNumber: 27
				}, this),
				children: [/* @__PURE__ */ _jsxDEV(Route, {
					path: "/categories",
					element: /* @__PURE__ */ _jsxDEV(CategoriesPage, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 23,
						columnNumber: 48
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 23,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV(Route, {
					path: "/quiz/:categoryId",
					element: /* @__PURE__ */ _jsxDEV(QuizPage, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 26,
						columnNumber: 54
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 22,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "*",
				element: /* @__PURE__ */ _jsxDEV(NotFoundPage, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 36
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 11
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 9
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 5
	}, this);
}
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/abbas/Desktop/TechLingo/frontend/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/abbas/Desktop/TechLingo/frontend/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/abbas/Desktop/TechLingo/frontend/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUIsUUFBUSxRQUFRLGFBQWE7QUFFdkQsT0FBTyxZQUFZO0FBQ25CLE9BQU8sb0JBQW9CO0FBRTNCLE9BQU8sY0FBYztBQUNyQixPQUFPLGtCQUFrQjtBQUN6QixPQUFPLG9CQUFvQjtBQUMzQixPQUFPLGNBQWM7OztBQUVyQixTQUFTLE1BQU07Q0FDYixPQUNFLHdCQUFDLFFBQUQsWUFFRSx3QkFBQyxRQUFELFlBRUUsd0JBQUMsT0FBRDtFQUFPLFNBQVMsd0JBQUMsUUFBRCxDQUFTOzs7OztZQUF6QjtHQUNFLHdCQUFDLE9BQUQ7SUFBTyxNQUFLO0lBQUksU0FBUyx3QkFBQyxVQUFELENBQVc7Ozs7O0dBQUk7Ozs7O0dBSXhDLHdCQUFDLE9BQUQ7SUFBTyxTQUFTLHdCQUFDLGdCQUFELENBQWlCOzs7OztjQUFqQyxDQUNFLHdCQUFDLE9BQUQ7S0FBTyxNQUFLO0tBQWMsU0FBUyx3QkFBQyxnQkFBRCxDQUFpQjs7Ozs7SUFBSTs7OztjQUd4RCx3QkFBQyxPQUFEO0tBQU8sTUFBSztLQUFvQixTQUFTLHdCQUFDLFVBQUQsQ0FBVzs7Ozs7SUFBSTs7OztZQUNuRDs7Ozs7O0dBR1Asd0JBQUMsT0FBRDtJQUFPLE1BQUs7SUFBSSxTQUFTLHdCQUFDLGNBQUQsQ0FBZTs7Ozs7R0FBSTs7Ozs7RUFDdkM7Ozs7O1VBQ0Q7Ozs7VUFDRjs7Ozs7QUFFWjs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQnJvd3NlclJvdXRlciBhcyBSb3V0ZXIsIFJvdXRlcywgUm91dGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5cclxuaW1wb3J0IExheW91dCBmcm9tIFwiLi9jb21wb25lbnRzL2xheW91dC9MYXlvdXRcIjtcclxuaW1wb3J0IFByb3RlY3RlZFJvdXRlIGZyb20gXCIuL2NvbXBvbmVudHMvYXV0aC9Qcm90ZWN0ZWRSb3V0ZVwiO1xyXG5cclxuaW1wb3J0IEhvbWVQYWdlIGZyb20gXCIuL3BhZ2VzL0hvbWVQYWdlXCI7XHJcbmltcG9ydCBOb3RGb3VuZFBhZ2UgZnJvbSBcIi4vcGFnZXMvTm90Rm91bmRQYWdlXCI7XHJcbmltcG9ydCBDYXRlZ29yaWVzUGFnZSBmcm9tIFwiLi9wYWdlcy9DYXRlZ29yaWVzUGFnZVwiO1xyXG5pbXBvcnQgUXVpelBhZ2UgZnJvbSBcIi4vcGFnZXMvUXVpelBhZ2VcIjtcclxuXHJcbmZ1bmN0aW9uIEFwcCgpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPFJvdXRlcj5cclxuICAgICAgey8qIERlZmluaWVyYXIgdmlsa2Ega29tcG9uZW50ZXIgc29tIHNrYSB2aXNhcyBmw7ZyIHJlc3Bla3RpdmUgVVJMLiAqL31cclxuICAgICAgPFJvdXRlcz5cclxuICAgICAgICB7LyogTGF5b3V0IGFudsOkbmRzIHNvbSBnZW1lbnNhbSBzdHJ1a3R1ciBydW50IHNpZG9ybmFzIGlubmVow6VsbC4gKi99XHJcbiAgICAgICAgPFJvdXRlIGVsZW1lbnQ9ezxMYXlvdXQgLz59PlxyXG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCIvXCIgZWxlbWVudD17PEhvbWVQYWdlIC8+fSAvPlxyXG5cclxuICAgICAgICAgIHsvKiBlbmRhc3QgZsO2ciBhbnbDpG5kYXJlICovfVxyXG4gICAgICAgICAgey8qIERlc3NhIHJvdXRlcyBrcsOkdmVyIGF0dCBhbnbDpG5kYXJlbiDDpHIgYXV0ZW50aXNlcmFkLiAqL31cclxuICAgICAgICAgIDxSb3V0ZSBlbGVtZW50PXs8UHJvdGVjdGVkUm91dGUgLz59PlxyXG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9jYXRlZ29yaWVzXCIgZWxlbWVudD17PENhdGVnb3JpZXNQYWdlIC8+fSAvPlxyXG5cclxuICAgICAgICAgICAgey8qIGNhdGVnb3J5SWQgYW52w6RuZHMgZsO2ciBhdHQgaWRlbnRpZmllcmEgdmlsa2VuIGthdGVnb3JpcyBmcsOlZ29yIHNvbSBza2EgaMOkbXRhcy4gKi99XHJcbiAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL3F1aXovOmNhdGVnb3J5SWRcIiBlbGVtZW50PXs8UXVpelBhZ2UgLz59IC8+XHJcbiAgICAgICAgICA8L1JvdXRlPlxyXG5cclxuICAgICAgICAgIHsvKiBWaXNhcyBvbSBhbnbDpG5kYXJlbiBnw6VyIHRpbGwgZW4gcm91dGUgc29tIGludGUgZmlubnMuICovfVxyXG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCIqXCIgZWxlbWVudD17PE5vdEZvdW5kUGFnZSAvPn0gLz5cclxuICAgICAgICA8L1JvdXRlPlxyXG4gICAgICA8L1JvdXRlcz5cclxuICAgIDwvUm91dGVyPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFwcDtcclxuIl19