import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/context/AuthContext.tsx");const createContext = __vite__cjsImport0_react["createContext"]; const useContext = __vite__cjsImport0_react["useContext"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=99106a80";
import { isAuthenticated, logout, getTokenExpiration, getToken } from "/src/api/authApi.ts";
var _jsxFileName = "C:/Users/abbas/Desktop/TechLingo/frontend/src/context/AuthContext.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=99106a80";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const AuthContext = createContext(undefined);
_c = AuthContext;
export function AuthProvider({ children }) {
	_s();
	const [isAuth, setIsAuth] = useState(isAuthenticated);
	const hasAlertedForExpiredToken = useRef(false);
	function login() {
		setIsAuth(true);
		hasAlertedForExpiredToken.current = false;
	}
	function logoutUser() {
		logout();
		setIsAuth(false);
	}
	useEffect(() => {
		function handleTokenExpired() {
			if (!hasAlertedForExpiredToken.current) {
				alert("Your session has expired. Please log in again.");
				hasAlertedForExpiredToken.current = true;
			}
			logout();
			setIsAuth(false);
		}
		window.addEventListener("auth-expired", handleTokenExpired);
		if (!isAuth) {
			return () => {
				window.removeEventListener("auth-expired", handleTokenExpired);
			};
		}
		const token = getToken();
		if (!token) {
			setIsAuth(false);
			return () => {
				window.removeEventListener("auth-expired", handleTokenExpired);
			};
		}
		const expirationTime = getTokenExpiration(token);
		if (!expirationTime) {
			return () => {
				window.removeEventListener("auth-expired", handleTokenExpired);
			};
		}
		const timeUntilExpiration = expirationTime - Date.now();
		if (timeUntilExpiration <= 0) {
			handleTokenExpired();
			return () => {
				window.removeEventListener("auth-expired", handleTokenExpired);
			};
		}
		const timeout = window.setTimeout(handleTokenExpired, timeUntilExpiration);
		return () => {
			window.clearTimeout(timeout);
			window.removeEventListener("auth-expired", handleTokenExpired);
		};
	}, [isAuth]);
	return /* @__PURE__ */ _jsxDEV(AuthContext.Provider, {
		value: {
			isAuth,
			login,
			logoutUser
		},
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 99,
		columnNumber: 5
	}, this);
}
_s(AuthProvider, "5Bm5+xQAbxcibyZim2BTcfzrwhE=");
_c2 = AuthProvider;
export function useAuth() {
	_s2();
	const context = useContext(AuthContext);
	if (context === undefined) {
		throw new Error("useAuth must be used within an AuthProvider");
	}
	return context;
}
_s2(useAuth, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c, _c2;
$RefreshReg$(_c, "AuthContext");
$RefreshReg$(_c2, "AuthProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/context/AuthContext.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/abbas/Desktop/TechLingo/frontend/src/context/AuthContext.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/abbas/Desktop/TechLingo/frontend/src/context/AuthContext.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/abbas/Desktop/TechLingo/frontend/src/context/AuthContext.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FDRSxlQUNBLFlBQ0EsV0FDQSxRQUNBLGdCQUVLO0FBRVAsU0FDRSxpQkFDQSxRQUNBLG9CQUNBLGdCQUNLOzs7O0FBWVAsTUFBTSxjQUFjLGNBQTJDLFNBQVM7O0FBRXhFLE9BQU8sU0FBUyxhQUFhLEVBQUUsWUFBK0I7O0NBQzVELE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxlQUFlO0NBQ3BELE1BQU0sNEJBQTRCLE9BQU8sS0FBSztDQUU5QyxTQUFTLFFBQVE7RUFDZixVQUFVLElBQUk7RUFDZCwwQkFBMEIsVUFBVTtDQUN0QztDQUVBLFNBQVMsYUFBYTtFQUNwQixPQUFPO0VBQ1AsVUFBVSxLQUFLO0NBQ2pCO0NBRUEsZ0JBQWdCO0VBQ2QsU0FBUyxxQkFBcUI7R0FDNUIsSUFBSSxDQUFDLDBCQUEwQixTQUFTO0lBQ3RDLE1BQU0sZ0RBQWdEO0lBQ3RELDBCQUEwQixVQUFVO0dBQ3RDO0dBRUEsT0FBTztHQUNQLFVBQVUsS0FBSztFQUNqQjtFQUVBLE9BQU8saUJBQWlCLGdCQUFnQixrQkFBa0I7RUFFMUQsSUFBSSxDQUFDLFFBQVE7R0FDWCxhQUFhO0lBQ1gsT0FBTyxvQkFBb0IsZ0JBQWdCLGtCQUFrQjtHQUMvRDtFQUNGO0VBRUEsTUFBTSxRQUFRLFNBQVM7RUFFdkIsSUFBSSxDQUFDLE9BQU87R0FDVixVQUFVLEtBQUs7R0FFZixhQUFhO0lBQ1gsT0FBTyxvQkFBb0IsZ0JBQWdCLGtCQUFrQjtHQUMvRDtFQUNGO0VBRUEsTUFBTSxpQkFBaUIsbUJBQW1CLEtBQUs7RUFFL0MsSUFBSSxDQUFDLGdCQUFnQjtHQUNuQixhQUFhO0lBQ1gsT0FBTyxvQkFBb0IsZ0JBQWdCLGtCQUFrQjtHQUMvRDtFQUNGO0VBRUEsTUFBTSxzQkFBc0IsaUJBQWlCLEtBQUssSUFBSTtFQUV0RCxJQUFJLHVCQUF1QixHQUFHO0dBQzVCLG1CQUFtQjtHQUVuQixhQUFhO0lBQ1gsT0FBTyxvQkFBb0IsZ0JBQWdCLGtCQUFrQjtHQUMvRDtFQUNGO0VBRUEsTUFBTSxVQUFVLE9BQU8sV0FBVyxvQkFBb0IsbUJBQW1CO0VBRXpFLGFBQWE7R0FDWCxPQUFPLGFBQWEsT0FBTztHQUMzQixPQUFPLG9CQUFvQixnQkFBZ0Isa0JBQWtCO0VBQy9EO0NBQ0YsR0FBRyxDQUFDLE1BQU0sQ0FBQztDQUVYLE9BQ0Usd0JBQUMsWUFBWSxVQUFiO0VBQXNCLE9BQU87R0FBRTtHQUFRO0dBQU87RUFBVztFQUN0RDtDQUNtQjs7Ozs7QUFFMUI7OztBQUVBLE9BQU8sU0FBUyxVQUFVOztDQUN4QixNQUFNLFVBQVUsV0FBVyxXQUFXO0NBRXRDLElBQUksWUFBWSxXQUFXO0VBQ3pCLE1BQU0sSUFBSSxNQUFNLDZDQUE2QztDQUMvRDtDQUVBLE9BQU87QUFDVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBdXRoQ29udGV4dC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICBjcmVhdGVDb250ZXh0LFxyXG4gIHVzZUNvbnRleHQsXHJcbiAgdXNlRWZmZWN0LFxyXG4gIHVzZVJlZixcclxuICB1c2VTdGF0ZSxcclxuICB0eXBlIFJlYWN0Tm9kZSxcclxufSBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmltcG9ydCB7XHJcbiAgaXNBdXRoZW50aWNhdGVkLFxyXG4gIGxvZ291dCxcclxuICBnZXRUb2tlbkV4cGlyYXRpb24sXHJcbiAgZ2V0VG9rZW4sXHJcbn0gZnJvbSBcIi4uL2FwaS9hdXRoQXBpXCI7XHJcblxyXG50eXBlIEF1dGhDb250ZXh0VHlwZSA9IHtcclxuICBpc0F1dGg6IGJvb2xlYW47XHJcbiAgbG9naW46ICgpID0+IHZvaWQ7XHJcbiAgbG9nb3V0VXNlcjogKCkgPT4gdm9pZDtcclxufTtcclxuXHJcbnR5cGUgQXV0aFByb3ZpZGVyUHJvcHMgPSB7XHJcbiAgY2hpbGRyZW46IFJlYWN0Tm9kZTtcclxufTtcclxuXHJcbmNvbnN0IEF1dGhDb250ZXh0ID0gY3JlYXRlQ29udGV4dDxBdXRoQ29udGV4dFR5cGUgfCB1bmRlZmluZWQ+KHVuZGVmaW5lZCk7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQXV0aFByb3ZpZGVyKHsgY2hpbGRyZW4gfTogQXV0aFByb3ZpZGVyUHJvcHMpIHtcclxuICBjb25zdCBbaXNBdXRoLCBzZXRJc0F1dGhdID0gdXNlU3RhdGUoaXNBdXRoZW50aWNhdGVkKTtcclxuICBjb25zdCBoYXNBbGVydGVkRm9yRXhwaXJlZFRva2VuID0gdXNlUmVmKGZhbHNlKTtcclxuXHJcbiAgZnVuY3Rpb24gbG9naW4oKSB7XHJcbiAgICBzZXRJc0F1dGgodHJ1ZSk7XHJcbiAgICBoYXNBbGVydGVkRm9yRXhwaXJlZFRva2VuLmN1cnJlbnQgPSBmYWxzZTtcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIGxvZ291dFVzZXIoKSB7XHJcbiAgICBsb2dvdXQoKTtcclxuICAgIHNldElzQXV0aChmYWxzZSk7XHJcbiAgfVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZnVuY3Rpb24gaGFuZGxlVG9rZW5FeHBpcmVkKCkge1xyXG4gICAgICBpZiAoIWhhc0FsZXJ0ZWRGb3JFeHBpcmVkVG9rZW4uY3VycmVudCkge1xyXG4gICAgICAgIGFsZXJ0KFwiWW91ciBzZXNzaW9uIGhhcyBleHBpcmVkLiBQbGVhc2UgbG9nIGluIGFnYWluLlwiKTtcclxuICAgICAgICBoYXNBbGVydGVkRm9yRXhwaXJlZFRva2VuLmN1cnJlbnQgPSB0cnVlO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBsb2dvdXQoKTtcclxuICAgICAgc2V0SXNBdXRoKGZhbHNlKTtcclxuICAgIH1cclxuXHJcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImF1dGgtZXhwaXJlZFwiLCBoYW5kbGVUb2tlbkV4cGlyZWQpO1xyXG5cclxuICAgIGlmICghaXNBdXRoKSB7XHJcbiAgICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJhdXRoLWV4cGlyZWRcIiwgaGFuZGxlVG9rZW5FeHBpcmVkKTtcclxuICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCB0b2tlbiA9IGdldFRva2VuKCk7XHJcblxyXG4gICAgaWYgKCF0b2tlbikge1xyXG4gICAgICBzZXRJc0F1dGgoZmFsc2UpO1xyXG5cclxuICAgICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImF1dGgtZXhwaXJlZFwiLCBoYW5kbGVUb2tlbkV4cGlyZWQpO1xyXG4gICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGV4cGlyYXRpb25UaW1lID0gZ2V0VG9rZW5FeHBpcmF0aW9uKHRva2VuKTtcclxuXHJcbiAgICBpZiAoIWV4cGlyYXRpb25UaW1lKSB7XHJcbiAgICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJhdXRoLWV4cGlyZWRcIiwgaGFuZGxlVG9rZW5FeHBpcmVkKTtcclxuICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCB0aW1lVW50aWxFeHBpcmF0aW9uID0gZXhwaXJhdGlvblRpbWUgLSBEYXRlLm5vdygpO1xyXG5cclxuICAgIGlmICh0aW1lVW50aWxFeHBpcmF0aW9uIDw9IDApIHtcclxuICAgICAgaGFuZGxlVG9rZW5FeHBpcmVkKCk7XHJcblxyXG4gICAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwiYXV0aC1leHBpcmVkXCIsIGhhbmRsZVRva2VuRXhwaXJlZCk7XHJcbiAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgdGltZW91dCA9IHdpbmRvdy5zZXRUaW1lb3V0KGhhbmRsZVRva2VuRXhwaXJlZCwgdGltZVVudGlsRXhwaXJhdGlvbik7XHJcblxyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgd2luZG93LmNsZWFyVGltZW91dCh0aW1lb3V0KTtcclxuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJhdXRoLWV4cGlyZWRcIiwgaGFuZGxlVG9rZW5FeHBpcmVkKTtcclxuICAgIH07XHJcbiAgfSwgW2lzQXV0aF0pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPEF1dGhDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt7IGlzQXV0aCwgbG9naW4sIGxvZ291dFVzZXIgfX0+XHJcbiAgICAgIHtjaGlsZHJlbn1cclxuICAgIDwvQXV0aENvbnRleHQuUHJvdmlkZXI+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHVzZUF1dGgoKSB7XHJcbiAgY29uc3QgY29udGV4dCA9IHVzZUNvbnRleHQoQXV0aENvbnRleHQpO1xyXG5cclxuICBpZiAoY29udGV4dCA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJ1c2VBdXRoIG11c3QgYmUgdXNlZCB3aXRoaW4gYW4gQXV0aFByb3ZpZGVyXCIpO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIGNvbnRleHQ7XHJcbn1cclxuIl19