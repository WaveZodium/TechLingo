import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/iridescence/Iridescence.tsx");const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { Renderer, Program, Mesh, Color, Triangle } from "/node_modules/.vite/deps/ogl.js?v=57280423";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=57280423";
import "/src/styles/Iridescence.css";
var _jsxFileName = "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/iridescence/Iridescence.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=57280423";
var _s = $RefreshSig$();
const vertexShader = `
attribute vec2 uv;
attribute vec2 position;

varying vec2 vUv;

void main() {
  vUv = uv;
  gl_Position = vec4(position, 0, 1);
}
`;
const fragmentShader = `
precision highp float;

uniform float uTime;
uniform vec3 uColor;
uniform vec3 uResolution;
uniform vec2 uMouse;
uniform float uAmplitude;
uniform float uSpeed;

varying vec2 vUv;

void main() {
  float mr = min(uResolution.x, uResolution.y);
  vec2 uv = (vUv.xy * 2.0 - 1.0) * uResolution.xy / mr;

  uv += (uMouse - vec2(0.5)) * uAmplitude;

  float d = -uTime * 0.5 * uSpeed;
  float a = 0.0;
  for (float i = 0.0; i < 8.0; ++i) {
    a += cos(i - d - a * uv.x);
    d += sin(uv.y * i + a);
  }
  d += uTime * 0.5 * uSpeed;
  vec3 col = vec3(cos(uv * vec2(d, a)) * 0.6 + 0.4, cos(a + d) * 0.5 + 0.5);
  col = cos(col * cos(vec3(d, a, 2.5)) * 0.5 + 0.5) * uColor;
  gl_FragColor = vec4(col, 1.0);
}
`;
export default function Iridescence({ color = [
	1,
	1,
	1
], speed = 1, amplitude = .1, mouseReact = true, ...rest }) {
	_s();
	const ctnDom = useRef(null);
	const mousePos = useRef({
		x: .5,
		y: .5
	});
	useEffect(() => {
		if (!ctnDom.current) return;
		const ctn = ctnDom.current;
		const renderer = new Renderer();
		const gl = renderer.gl;
		gl.clearColor(1, 1, 1, 1);
		let program;
		function resize() {
			const scale = 1;
			renderer.setSize(ctn.offsetWidth * scale, ctn.offsetHeight * scale);
			if (program) {
				program.uniforms.uResolution.value = new Color(gl.canvas.width, gl.canvas.height, gl.canvas.width / gl.canvas.height);
			}
		}
		window.addEventListener("resize", resize, false);
		resize();
		const geometry = new Triangle(gl);
		program = new Program(gl, {
			vertex: vertexShader,
			fragment: fragmentShader,
			uniforms: {
				uTime: { value: 0 },
				uColor: { value: new Color(...color) },
				uResolution: { value: new Color(gl.canvas.width, gl.canvas.height, gl.canvas.width / gl.canvas.height) },
				uMouse: { value: new Float32Array([mousePos.current.x, mousePos.current.y]) },
				uAmplitude: { value: amplitude },
				uSpeed: { value: speed }
			}
		});
		const mesh = new Mesh(gl, {
			geometry,
			program
		});
		let animateId;
		function update(t) {
			animateId = requestAnimationFrame(update);
			program.uniforms.uTime.value = t * .001;
			renderer.render({ scene: mesh });
		}
		animateId = requestAnimationFrame(update);
		ctn.appendChild(gl.canvas);
		function handleMouseMove(e) {
			const rect = ctn.getBoundingClientRect();
			const x = (e.clientX - rect.left) / rect.width;
			const y = 1 - (e.clientY - rect.top) / rect.height;
			mousePos.current = {
				x,
				y
			};
			program.uniforms.uMouse.value[0] = x;
			program.uniforms.uMouse.value[1] = y;
		}
		if (mouseReact) {
			ctn.addEventListener("mousemove", handleMouseMove);
		}
		return () => {
			cancelAnimationFrame(animateId);
			window.removeEventListener("resize", resize);
			if (mouseReact) {
				ctn.removeEventListener("mousemove", handleMouseMove);
			}
			ctn.removeChild(gl.canvas);
			gl.getExtension("WEBGL_lose_context")?.loseContext();
		};
	}, [
		color,
		speed,
		amplitude,
		mouseReact
	]);
	return /* @__PURE__ */ _jsxDEV("div", {
		ref: ctnDom,
		className: "iridescence-container",
		...rest
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 145,
		columnNumber: 10
	}, this);
}
_s(Iridescence, "UPORvdp6AzHgrOMZicif350ruRQ=");
_c = Iridescence;
var _c;
$RefreshReg$(_c, "Iridescence");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/iridescence/Iridescence.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/iridescence/Iridescence.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/iridescence/Iridescence.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/iridescence/Iridescence.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFNBQVMsTUFBTSxPQUFPLGdCQUFnQjtBQUN6RCxTQUFTLFdBQVcsY0FBYztBQUVsQyxPQUFPOzs7O0FBRVAsTUFBTSxlQUFlOzs7Ozs7Ozs7OztBQVlyQixNQUFNLGlCQUFpQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBc0N2QixlQUFlLFNBQVMsWUFBWSxFQUNsQyxRQUFRO0NBQUM7Q0FBRztDQUFHO0FBQUMsR0FDaEIsUUFBUSxHQUNSLFlBQVksSUFDWixhQUFhLE1BQ2IsR0FBRyxRQUNnQjs7Q0FDbkIsTUFBTSxTQUFTLE9BQXVCLElBQUk7Q0FDMUMsTUFBTSxXQUFXLE9BQU87RUFBRSxHQUFHO0VBQUssR0FBRztDQUFJLENBQUM7Q0FFMUMsZ0JBQWdCO0VBQ2QsSUFBSSxDQUFDLE9BQU8sU0FBUztFQUNyQixNQUFNLE1BQU0sT0FBTztFQUNuQixNQUFNLFdBQVcsSUFBSSxTQUFTO0VBQzlCLE1BQU0sS0FBSyxTQUFTO0VBQ3BCLEdBQUcsV0FBVyxHQUFHLEdBQUcsR0FBRyxDQUFDO0VBRXhCLElBQUk7RUFFSixTQUFTLFNBQVM7R0FDaEIsTUFBTSxRQUFRO0dBQ2QsU0FBUyxRQUFRLElBQUksY0FBYyxPQUFPLElBQUksZUFBZSxLQUFLO0dBQ2xFLElBQUksU0FBUztJQUNYLFFBQVEsU0FBUyxZQUFZLFFBQVEsSUFBSSxNQUN2QyxHQUFHLE9BQU8sT0FDVixHQUFHLE9BQU8sUUFDVixHQUFHLE9BQU8sUUFBUSxHQUFHLE9BQU8sTUFDOUI7R0FDRjtFQUNGO0VBQ0EsT0FBTyxpQkFBaUIsVUFBVSxRQUFRLEtBQUs7RUFDL0MsT0FBTztFQUVQLE1BQU0sV0FBVyxJQUFJLFNBQVMsRUFBRTtFQUNoQyxVQUFVLElBQUksUUFBUSxJQUFJO0dBQ3hCLFFBQVE7R0FDUixVQUFVO0dBQ1YsVUFBVTtJQUNSLE9BQU8sRUFBRSxPQUFPLEVBQUU7SUFDbEIsUUFBUSxFQUFFLE9BQU8sSUFBSSxNQUFNLEdBQUcsS0FBSyxFQUFFO0lBQ3JDLGFBQWEsRUFDWCxPQUFPLElBQUksTUFDVCxHQUFHLE9BQU8sT0FDVixHQUFHLE9BQU8sUUFDVixHQUFHLE9BQU8sUUFBUSxHQUFHLE9BQU8sTUFDOUIsRUFDRjtJQUNBLFFBQVEsRUFDTixPQUFPLElBQUksYUFBYSxDQUFDLFNBQVMsUUFBUSxHQUFHLFNBQVMsUUFBUSxDQUFDLENBQUMsRUFDbEU7SUFDQSxZQUFZLEVBQUUsT0FBTyxVQUFVO0lBQy9CLFFBQVEsRUFBRSxPQUFPLE1BQU07R0FDekI7RUFDRixDQUFDO0VBRUQsTUFBTSxPQUFPLElBQUksS0FBSyxJQUFJO0dBQUU7R0FBVTtFQUFRLENBQUM7RUFDL0MsSUFBSTtFQUVKLFNBQVMsT0FBTyxHQUFXO0dBQ3pCLFlBQVksc0JBQXNCLE1BQU07R0FDeEMsUUFBUSxTQUFTLE1BQU0sUUFBUSxJQUFJO0dBQ25DLFNBQVMsT0FBTyxFQUFFLE9BQU8sS0FBSyxDQUFDO0VBQ2pDO0VBQ0EsWUFBWSxzQkFBc0IsTUFBTTtFQUN4QyxJQUFJLFlBQVksR0FBRyxNQUFNO0VBRXpCLFNBQVMsZ0JBQWdCLEdBQWU7R0FDdEMsTUFBTSxPQUFPLElBQUksc0JBQXNCO0dBQ3ZDLE1BQU0sS0FBSyxFQUFFLFVBQVUsS0FBSyxRQUFRLEtBQUs7R0FDekMsTUFBTSxJQUFJLEtBQU8sRUFBRSxVQUFVLEtBQUssT0FBTyxLQUFLO0dBQzlDLFNBQVMsVUFBVTtJQUFFO0lBQUc7R0FBRTtHQUMxQixRQUFRLFNBQVMsT0FBTyxNQUFNLEtBQUs7R0FDbkMsUUFBUSxTQUFTLE9BQU8sTUFBTSxLQUFLO0VBQ3JDO0VBQ0EsSUFBSSxZQUFZO0dBQ2QsSUFBSSxpQkFBaUIsYUFBYSxlQUFlO0VBQ25EO0VBRUEsYUFBYTtHQUNYLHFCQUFxQixTQUFTO0dBQzlCLE9BQU8sb0JBQW9CLFVBQVUsTUFBTTtHQUMzQyxJQUFJLFlBQVk7SUFDZCxJQUFJLG9CQUFvQixhQUFhLGVBQWU7R0FDdEQ7R0FDQSxJQUFJLFlBQVksR0FBRyxNQUFNO0dBQ3pCLEdBQUcsYUFBYSxvQkFBb0IsQ0FBQyxFQUFFLFlBQVk7RUFDckQ7Q0FDRixHQUFHO0VBQUM7RUFBTztFQUFPO0VBQVc7Q0FBVSxDQUFDO0NBRXhDLE9BQU8sd0JBQUMsT0FBRDtFQUFLLEtBQUs7RUFBUSxXQUFVO0VBQXdCLEdBQUk7Q0FBTzs7Ozs7QUFDeEUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSXJpZGVzY2VuY2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFJlbmRlcmVyLCBQcm9ncmFtLCBNZXNoLCBDb2xvciwgVHJpYW5nbGUgfSBmcm9tIFwib2dsXCI7XHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSBcInJlYWN0XCI7XHJcblxyXG5pbXBvcnQgXCIuLi8uLi9zdHlsZXMvSXJpZGVzY2VuY2UuY3NzXCI7XHJcblxyXG5jb25zdCB2ZXJ0ZXhTaGFkZXIgPSBgXHJcbmF0dHJpYnV0ZSB2ZWMyIHV2O1xyXG5hdHRyaWJ1dGUgdmVjMiBwb3NpdGlvbjtcclxuXHJcbnZhcnlpbmcgdmVjMiB2VXY7XHJcblxyXG52b2lkIG1haW4oKSB7XHJcbiAgdlV2ID0gdXY7XHJcbiAgZ2xfUG9zaXRpb24gPSB2ZWM0KHBvc2l0aW9uLCAwLCAxKTtcclxufVxyXG5gO1xyXG5cclxuY29uc3QgZnJhZ21lbnRTaGFkZXIgPSBgXHJcbnByZWNpc2lvbiBoaWdocCBmbG9hdDtcclxuXHJcbnVuaWZvcm0gZmxvYXQgdVRpbWU7XHJcbnVuaWZvcm0gdmVjMyB1Q29sb3I7XHJcbnVuaWZvcm0gdmVjMyB1UmVzb2x1dGlvbjtcclxudW5pZm9ybSB2ZWMyIHVNb3VzZTtcclxudW5pZm9ybSBmbG9hdCB1QW1wbGl0dWRlO1xyXG51bmlmb3JtIGZsb2F0IHVTcGVlZDtcclxuXHJcbnZhcnlpbmcgdmVjMiB2VXY7XHJcblxyXG52b2lkIG1haW4oKSB7XHJcbiAgZmxvYXQgbXIgPSBtaW4odVJlc29sdXRpb24ueCwgdVJlc29sdXRpb24ueSk7XHJcbiAgdmVjMiB1diA9ICh2VXYueHkgKiAyLjAgLSAxLjApICogdVJlc29sdXRpb24ueHkgLyBtcjtcclxuXHJcbiAgdXYgKz0gKHVNb3VzZSAtIHZlYzIoMC41KSkgKiB1QW1wbGl0dWRlO1xyXG5cclxuICBmbG9hdCBkID0gLXVUaW1lICogMC41ICogdVNwZWVkO1xyXG4gIGZsb2F0IGEgPSAwLjA7XHJcbiAgZm9yIChmbG9hdCBpID0gMC4wOyBpIDwgOC4wOyArK2kpIHtcclxuICAgIGEgKz0gY29zKGkgLSBkIC0gYSAqIHV2LngpO1xyXG4gICAgZCArPSBzaW4odXYueSAqIGkgKyBhKTtcclxuICB9XHJcbiAgZCArPSB1VGltZSAqIDAuNSAqIHVTcGVlZDtcclxuICB2ZWMzIGNvbCA9IHZlYzMoY29zKHV2ICogdmVjMihkLCBhKSkgKiAwLjYgKyAwLjQsIGNvcyhhICsgZCkgKiAwLjUgKyAwLjUpO1xyXG4gIGNvbCA9IGNvcyhjb2wgKiBjb3ModmVjMyhkLCBhLCAyLjUpKSAqIDAuNSArIDAuNSkgKiB1Q29sb3I7XHJcbiAgZ2xfRnJhZ0NvbG9yID0gdmVjNChjb2wsIDEuMCk7XHJcbn1cclxuYDtcclxuXHJcbmludGVyZmFjZSBJcmlkZXNjZW5jZVByb3BzIHtcclxuICBjb2xvcj86IFtudW1iZXIsIG51bWJlciwgbnVtYmVyXTtcclxuICBzcGVlZD86IG51bWJlcjtcclxuICBhbXBsaXR1ZGU/OiBudW1iZXI7XHJcbiAgbW91c2VSZWFjdD86IGJvb2xlYW47XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIElyaWRlc2NlbmNlKHtcclxuICBjb2xvciA9IFsxLCAxLCAxXSxcclxuICBzcGVlZCA9IDEuMCxcclxuICBhbXBsaXR1ZGUgPSAwLjEsXHJcbiAgbW91c2VSZWFjdCA9IHRydWUsXHJcbiAgLi4ucmVzdFxyXG59OiBJcmlkZXNjZW5jZVByb3BzKSB7XHJcbiAgY29uc3QgY3RuRG9tID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcclxuICBjb25zdCBtb3VzZVBvcyA9IHVzZVJlZih7IHg6IDAuNSwgeTogMC41IH0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCFjdG5Eb20uY3VycmVudCkgcmV0dXJuO1xyXG4gICAgY29uc3QgY3RuID0gY3RuRG9tLmN1cnJlbnQ7XHJcbiAgICBjb25zdCByZW5kZXJlciA9IG5ldyBSZW5kZXJlcigpO1xyXG4gICAgY29uc3QgZ2wgPSByZW5kZXJlci5nbDtcclxuICAgIGdsLmNsZWFyQ29sb3IoMSwgMSwgMSwgMSk7XHJcblxyXG4gICAgbGV0IHByb2dyYW06IFByb2dyYW07XHJcblxyXG4gICAgZnVuY3Rpb24gcmVzaXplKCkge1xyXG4gICAgICBjb25zdCBzY2FsZSA9IDE7XHJcbiAgICAgIHJlbmRlcmVyLnNldFNpemUoY3RuLm9mZnNldFdpZHRoICogc2NhbGUsIGN0bi5vZmZzZXRIZWlnaHQgKiBzY2FsZSk7XHJcbiAgICAgIGlmIChwcm9ncmFtKSB7XHJcbiAgICAgICAgcHJvZ3JhbS51bmlmb3Jtcy51UmVzb2x1dGlvbi52YWx1ZSA9IG5ldyBDb2xvcihcclxuICAgICAgICAgIGdsLmNhbnZhcy53aWR0aCxcclxuICAgICAgICAgIGdsLmNhbnZhcy5oZWlnaHQsXHJcbiAgICAgICAgICBnbC5jYW52YXMud2lkdGggLyBnbC5jYW52YXMuaGVpZ2h0LFxyXG4gICAgICAgICk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicmVzaXplXCIsIHJlc2l6ZSwgZmFsc2UpO1xyXG4gICAgcmVzaXplKCk7XHJcblxyXG4gICAgY29uc3QgZ2VvbWV0cnkgPSBuZXcgVHJpYW5nbGUoZ2wpO1xyXG4gICAgcHJvZ3JhbSA9IG5ldyBQcm9ncmFtKGdsLCB7XHJcbiAgICAgIHZlcnRleDogdmVydGV4U2hhZGVyLFxyXG4gICAgICBmcmFnbWVudDogZnJhZ21lbnRTaGFkZXIsXHJcbiAgICAgIHVuaWZvcm1zOiB7XHJcbiAgICAgICAgdVRpbWU6IHsgdmFsdWU6IDAgfSxcclxuICAgICAgICB1Q29sb3I6IHsgdmFsdWU6IG5ldyBDb2xvciguLi5jb2xvcikgfSxcclxuICAgICAgICB1UmVzb2x1dGlvbjoge1xyXG4gICAgICAgICAgdmFsdWU6IG5ldyBDb2xvcihcclxuICAgICAgICAgICAgZ2wuY2FudmFzLndpZHRoLFxyXG4gICAgICAgICAgICBnbC5jYW52YXMuaGVpZ2h0LFxyXG4gICAgICAgICAgICBnbC5jYW52YXMud2lkdGggLyBnbC5jYW52YXMuaGVpZ2h0LFxyXG4gICAgICAgICAgKSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHVNb3VzZToge1xyXG4gICAgICAgICAgdmFsdWU6IG5ldyBGbG9hdDMyQXJyYXkoW21vdXNlUG9zLmN1cnJlbnQueCwgbW91c2VQb3MuY3VycmVudC55XSksXHJcbiAgICAgICAgfSxcclxuICAgICAgICB1QW1wbGl0dWRlOiB7IHZhbHVlOiBhbXBsaXR1ZGUgfSxcclxuICAgICAgICB1U3BlZWQ6IHsgdmFsdWU6IHNwZWVkIH0sXHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCBtZXNoID0gbmV3IE1lc2goZ2wsIHsgZ2VvbWV0cnksIHByb2dyYW0gfSk7XHJcbiAgICBsZXQgYW5pbWF0ZUlkOiBudW1iZXI7XHJcblxyXG4gICAgZnVuY3Rpb24gdXBkYXRlKHQ6IG51bWJlcikge1xyXG4gICAgICBhbmltYXRlSWQgPSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUodXBkYXRlKTtcclxuICAgICAgcHJvZ3JhbS51bmlmb3Jtcy51VGltZS52YWx1ZSA9IHQgKiAwLjAwMTtcclxuICAgICAgcmVuZGVyZXIucmVuZGVyKHsgc2NlbmU6IG1lc2ggfSk7XHJcbiAgICB9XHJcbiAgICBhbmltYXRlSWQgPSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUodXBkYXRlKTtcclxuICAgIGN0bi5hcHBlbmRDaGlsZChnbC5jYW52YXMpO1xyXG5cclxuICAgIGZ1bmN0aW9uIGhhbmRsZU1vdXNlTW92ZShlOiBNb3VzZUV2ZW50KSB7XHJcbiAgICAgIGNvbnN0IHJlY3QgPSBjdG4uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcbiAgICAgIGNvbnN0IHggPSAoZS5jbGllbnRYIC0gcmVjdC5sZWZ0KSAvIHJlY3Qud2lkdGg7XHJcbiAgICAgIGNvbnN0IHkgPSAxLjAgLSAoZS5jbGllbnRZIC0gcmVjdC50b3ApIC8gcmVjdC5oZWlnaHQ7XHJcbiAgICAgIG1vdXNlUG9zLmN1cnJlbnQgPSB7IHgsIHkgfTtcclxuICAgICAgcHJvZ3JhbS51bmlmb3Jtcy51TW91c2UudmFsdWVbMF0gPSB4O1xyXG4gICAgICBwcm9ncmFtLnVuaWZvcm1zLnVNb3VzZS52YWx1ZVsxXSA9IHk7XHJcbiAgICB9XHJcbiAgICBpZiAobW91c2VSZWFjdCkge1xyXG4gICAgICBjdG4uYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlbW92ZVwiLCBoYW5kbGVNb3VzZU1vdmUpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGNhbmNlbEFuaW1hdGlvbkZyYW1lKGFuaW1hdGVJZCk7XHJcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwicmVzaXplXCIsIHJlc2l6ZSk7XHJcbiAgICAgIGlmIChtb3VzZVJlYWN0KSB7XHJcbiAgICAgICAgY3RuLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJtb3VzZW1vdmVcIiwgaGFuZGxlTW91c2VNb3ZlKTtcclxuICAgICAgfVxyXG4gICAgICBjdG4ucmVtb3ZlQ2hpbGQoZ2wuY2FudmFzKTtcclxuICAgICAgZ2wuZ2V0RXh0ZW5zaW9uKFwiV0VCR0xfbG9zZV9jb250ZXh0XCIpPy5sb3NlQ29udGV4dCgpO1xyXG4gICAgfTtcclxuICB9LCBbY29sb3IsIHNwZWVkLCBhbXBsaXR1ZGUsIG1vdXNlUmVhY3RdKTtcclxuXHJcbiAgcmV0dXJuIDxkaXYgcmVmPXtjdG5Eb219IGNsYXNzTmFtZT1cImlyaWRlc2NlbmNlLWNvbnRhaW5lclwiIHsuLi5yZXN0fSAvPjtcclxufVxyXG4iXX0=