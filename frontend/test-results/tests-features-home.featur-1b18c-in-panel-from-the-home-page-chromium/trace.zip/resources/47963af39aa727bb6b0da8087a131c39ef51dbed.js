import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/NotFoundPage.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/pages/NotFoundPage.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=57280423";
function NotFoundPage() {
	return /* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV("h1", { children: "404 - Page Not Found" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 4,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 3,
		columnNumber: 5
	}, this);
}
_c = NotFoundPage;
export default NotFoundPage;
var _c;
$RefreshReg$(_c, "NotFoundPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/NotFoundPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/pages/NotFoundPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/pages/NotFoundPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/pages/NotFoundPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFBQSxTQUFTLGVBQWU7Q0FDdEIsT0FDRSx3QkFBQyxPQUFELFlBQ0Usd0JBQUMsTUFBRCxZQUFJLHVCQUF3Qjs7OztVQUN6Qjs7Ozs7QUFFVDs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk5vdEZvdW5kUGFnZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiZnVuY3Rpb24gTm90Rm91bmRQYWdlKCkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8aDE+NDA0IC0gUGFnZSBOb3QgRm91bmQ8L2gxPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTm90Rm91bmRQYWdlO1xyXG4iXX0=