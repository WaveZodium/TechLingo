//#region node_modules/ogl/src/math/functions/Vec3Func.js
/**
* Calculates the length of a vec3
*
* @param {vec3} a vector to calculate length of
* @returns {Number} length of a
*/
function length$1(a) {
	let x = a[0];
	let y = a[1];
	let z = a[2];
	return Math.sqrt(x * x + y * y + z * z);
}
/**
* Copy the values from one vec3 to another
*
* @param {vec3} out the receiving vector
* @param {vec3} a the source vector
* @returns {vec3} out
*/
function copy$5(out, a) {
	out[0] = a[0];
	out[1] = a[1];
	out[2] = a[2];
	return out;
}
/**
* Set the components of a vec3 to the given values
*
* @param {vec3} out the receiving vector
* @param {Number} x X component
* @param {Number} y Y component
* @param {Number} z Z component
* @returns {vec3} out
*/
function set$5(out, x, y, z) {
	out[0] = x;
	out[1] = y;
	out[2] = z;
	return out;
}
/**
* Adds two vec3's
*
* @param {vec3} out the receiving vector
* @param {vec3} a the first operand
* @param {vec3} b the second operand
* @returns {vec3} out
*/
function add$2(out, a, b) {
	out[0] = a[0] + b[0];
	out[1] = a[1] + b[1];
	out[2] = a[2] + b[2];
	return out;
}
/**
* Subtracts vector b from vector a
*
* @param {vec3} out the receiving vector
* @param {vec3} a the first operand
* @param {vec3} b the second operand
* @returns {vec3} out
*/
function subtract$2(out, a, b) {
	out[0] = a[0] - b[0];
	out[1] = a[1] - b[1];
	out[2] = a[2] - b[2];
	return out;
}
/**
* Multiplies two vec3's
*
* @param {vec3} out the receiving vector
* @param {vec3} a the first operand
* @param {vec3} b the second operand
* @returns {vec3} out
*/
function multiply$4(out, a, b) {
	out[0] = a[0] * b[0];
	out[1] = a[1] * b[1];
	out[2] = a[2] * b[2];
	return out;
}
/**
* Divides two vec3's
*
* @param {vec3} out the receiving vector
* @param {vec3} a the first operand
* @param {vec3} b the second operand
* @returns {vec3} out
*/
function divide$1(out, a, b) {
	out[0] = a[0] / b[0];
	out[1] = a[1] / b[1];
	out[2] = a[2] / b[2];
	return out;
}
/**
* Scales a vec3 by a scalar number
*
* @param {vec3} out the receiving vector
* @param {vec3} a the vector to scale
* @param {Number} b amount to scale the vector by
* @returns {vec3} out
*/
function scale$4(out, a, b) {
	out[0] = a[0] * b;
	out[1] = a[1] * b;
	out[2] = a[2] * b;
	return out;
}
/**
* Calculates the euclidian distance between two vec3's
*
* @param {vec3} a the first operand
* @param {vec3} b the second operand
* @returns {Number} distance between a and b
*/
function distance$1(a, b) {
	let x = b[0] - a[0];
	let y = b[1] - a[1];
	let z = b[2] - a[2];
	return Math.sqrt(x * x + y * y + z * z);
}
/**
* Calculates the squared euclidian distance between two vec3's
*
* @param {vec3} a the first operand
* @param {vec3} b the second operand
* @returns {Number} squared distance between a and b
*/
function squaredDistance$1(a, b) {
	let x = b[0] - a[0];
	let y = b[1] - a[1];
	let z = b[2] - a[2];
	return x * x + y * y + z * z;
}
/**
* Calculates the squared length of a vec3
*
* @param {vec3} a vector to calculate squared length of
* @returns {Number} squared length of a
*/
function squaredLength$1(a) {
	let x = a[0];
	let y = a[1];
	let z = a[2];
	return x * x + y * y + z * z;
}
/**
* Negates the components of a vec3
*
* @param {vec3} out the receiving vector
* @param {vec3} a vector to negate
* @returns {vec3} out
*/
function negate$1(out, a) {
	out[0] = -a[0];
	out[1] = -a[1];
	out[2] = -a[2];
	return out;
}
/**
* Returns the inverse of the components of a vec3
*
* @param {vec3} out the receiving vector
* @param {vec3} a vector to invert
* @returns {vec3} out
*/
function inverse$1(out, a) {
	out[0] = 1 / a[0];
	out[1] = 1 / a[1];
	out[2] = 1 / a[2];
	return out;
}
/**
* Normalize a vec3
*
* @param {vec3} out the receiving vector
* @param {vec3} a vector to normalize
* @returns {vec3} out
*/
function normalize$3(out, a) {
	let x = a[0];
	let y = a[1];
	let z = a[2];
	let len = x * x + y * y + z * z;
	if (len > 0) len = 1 / Math.sqrt(len);
	out[0] = a[0] * len;
	out[1] = a[1] * len;
	out[2] = a[2] * len;
	return out;
}
/**
* Calculates the dot product of two vec3's
*
* @param {vec3} a the first operand
* @param {vec3} b the second operand
* @returns {Number} dot product of a and b
*/
function dot$3(a, b) {
	return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}
/**
* Computes the cross product of two vec3's
*
* @param {vec3} out the receiving vector
* @param {vec3} a the first operand
* @param {vec3} b the second operand
* @returns {vec3} out
*/
function cross$1(out, a, b) {
	let ax = a[0], ay = a[1], az = a[2];
	let bx = b[0], by = b[1], bz = b[2];
	out[0] = ay * bz - az * by;
	out[1] = az * bx - ax * bz;
	out[2] = ax * by - ay * bx;
	return out;
}
/**
* Performs a linear interpolation between two vec3's
*
* @param {vec3} out the receiving vector
* @param {vec3} a the first operand
* @param {vec3} b the second operand
* @param {Number} t interpolation amount between the two inputs
* @returns {vec3} out
*/
function lerp$1(out, a, b, t) {
	let ax = a[0];
	let ay = a[1];
	let az = a[2];
	out[0] = ax + t * (b[0] - ax);
	out[1] = ay + t * (b[1] - ay);
	out[2] = az + t * (b[2] - az);
	return out;
}
/**
* Performs a frame rate independant, linear interpolation between two vec3's
*
* @param {vec3} out the receiving vector
* @param {vec3} a the first operand
* @param {vec3} b the second operand
* @param {Number} decay decay constant for interpolation. useful range between 1 and 25, from slow to fast.
* @param {Number} dt delta time
* @returns {vec3} out
*/
function smoothLerp$1(out, a, b, decay, dt) {
	const exp = Math.exp(-decay * dt);
	let ax = a[0];
	let ay = a[1];
	let az = a[2];
	out[0] = b[0] + (ax - b[0]) * exp;
	out[1] = b[1] + (ay - b[1]) * exp;
	out[2] = b[2] + (az - b[2]) * exp;
	return out;
}
/**
* Transforms the vec3 with a mat4.
* 4th vector component is implicitly '1'
*
* @param {vec3} out the receiving vector
* @param {vec3} a the vector to transform
* @param {mat4} m matrix to transform with
* @returns {vec3} out
*/
function transformMat4$1(out, a, m) {
	let x = a[0], y = a[1], z = a[2];
	let w = m[3] * x + m[7] * y + m[11] * z + m[15];
	w = w || 1;
	out[0] = (m[0] * x + m[4] * y + m[8] * z + m[12]) / w;
	out[1] = (m[1] * x + m[5] * y + m[9] * z + m[13]) / w;
	out[2] = (m[2] * x + m[6] * y + m[10] * z + m[14]) / w;
	return out;
}
/**
* Same as above but doesn't apply translation.
* Useful for rays.
*/
function scaleRotateMat4(out, a, m) {
	let x = a[0], y = a[1], z = a[2];
	let w = m[3] * x + m[7] * y + m[11] * z + m[15];
	w = w || 1;
	out[0] = (m[0] * x + m[4] * y + m[8] * z) / w;
	out[1] = (m[1] * x + m[5] * y + m[9] * z) / w;
	out[2] = (m[2] * x + m[6] * y + m[10] * z) / w;
	return out;
}
/**
* Transforms the vec3 with a mat3.
*
* @param {vec3} out the receiving vector
* @param {vec3} a the vector to transform
* @param {mat3} m the 3x3 matrix to transform with
* @returns {vec3} out
*/
function transformMat3$1(out, a, m) {
	let x = a[0], y = a[1], z = a[2];
	out[0] = x * m[0] + y * m[3] + z * m[6];
	out[1] = x * m[1] + y * m[4] + z * m[7];
	out[2] = x * m[2] + y * m[5] + z * m[8];
	return out;
}
/**
* Transforms the vec3 with a quat
*
* @param {vec3} out the receiving vector
* @param {vec3} a the vector to transform
* @param {quat} q quaternion to transform with
* @returns {vec3} out
*/
function transformQuat(out, a, q) {
	let x = a[0], y = a[1], z = a[2];
	let qx = q[0], qy = q[1], qz = q[2], qw = q[3];
	let uvx = qy * z - qz * y;
	let uvy = qz * x - qx * z;
	let uvz = qx * y - qy * x;
	let uuvx = qy * uvz - qz * uvy;
	let uuvy = qz * uvx - qx * uvz;
	let uuvz = qx * uvy - qy * uvx;
	let w2 = qw * 2;
	uvx *= w2;
	uvy *= w2;
	uvz *= w2;
	uuvx *= 2;
	uuvy *= 2;
	uuvz *= 2;
	out[0] = x + uvx + uuvx;
	out[1] = y + uvy + uuvy;
	out[2] = z + uvz + uuvz;
	return out;
}
/**
* Get the angle between two 3D vectors
* @param {vec3} a The first operand
* @param {vec3} b The second operand
* @returns {Number} The angle in radians
*/
var angle = (function() {
	const tempA = [
		0,
		0,
		0
	];
	const tempB = [
		0,
		0,
		0
	];
	return function(a, b) {
		copy$5(tempA, a);
		copy$5(tempB, b);
		normalize$3(tempA, tempA);
		normalize$3(tempB, tempB);
		let cosine = dot$3(tempA, tempB);
		if (cosine > 1) return 0;
		else if (cosine < -1) return Math.PI;
		else return Math.acos(cosine);
	};
})();
/**
* Returns whether or not the vectors have exactly the same elements in the same position (when compared with ===)
*
* @param {vec3} a The first vector.
* @param {vec3} b The second vector.
* @returns {Boolean} True if the vectors are equal, false otherwise.
*/
function exactEquals$1(a, b) {
	return a[0] === b[0] && a[1] === b[1] && a[2] === b[2];
}
//#endregion
//#region node_modules/ogl/src/math/Vec3.js
var Vec3 = class Vec3 extends Array {
	constructor(x = 0, y = x, z = x) {
		super(x, y, z);
		return this;
	}
	get x() {
		return this[0];
	}
	get y() {
		return this[1];
	}
	get z() {
		return this[2];
	}
	set x(v) {
		this[0] = v;
	}
	set y(v) {
		this[1] = v;
	}
	set z(v) {
		this[2] = v;
	}
	set(x, y = x, z = x) {
		if (x.length) return this.copy(x);
		set$5(this, x, y, z);
		return this;
	}
	copy(v) {
		copy$5(this, v);
		return this;
	}
	add(va, vb) {
		if (vb) add$2(this, va, vb);
		else add$2(this, this, va);
		return this;
	}
	sub(va, vb) {
		if (vb) subtract$2(this, va, vb);
		else subtract$2(this, this, va);
		return this;
	}
	multiply(v) {
		if (v.length) multiply$4(this, this, v);
		else scale$4(this, this, v);
		return this;
	}
	divide(v) {
		if (v.length) divide$1(this, this, v);
		else scale$4(this, this, 1 / v);
		return this;
	}
	inverse(v = this) {
		inverse$1(this, v);
		return this;
	}
	len() {
		return length$1(this);
	}
	distance(v) {
		if (v) return distance$1(this, v);
		else return length$1(this);
	}
	squaredLen() {
		return squaredLength$1(this);
	}
	squaredDistance(v) {
		if (v) return squaredDistance$1(this, v);
		else return squaredLength$1(this);
	}
	negate(v = this) {
		negate$1(this, v);
		return this;
	}
	cross(va, vb) {
		if (vb) cross$1(this, va, vb);
		else cross$1(this, this, va);
		return this;
	}
	scale(v) {
		scale$4(this, this, v);
		return this;
	}
	normalize() {
		normalize$3(this, this);
		return this;
	}
	dot(v) {
		return dot$3(this, v);
	}
	equals(v) {
		return exactEquals$1(this, v);
	}
	applyMatrix3(mat3) {
		transformMat3$1(this, this, mat3);
		return this;
	}
	applyMatrix4(mat4) {
		transformMat4$1(this, this, mat4);
		return this;
	}
	scaleRotateMatrix4(mat4) {
		scaleRotateMat4(this, this, mat4);
		return this;
	}
	applyQuaternion(q) {
		transformQuat(this, this, q);
		return this;
	}
	angle(v) {
		return angle(this, v);
	}
	lerp(v, t) {
		lerp$1(this, this, v, t);
		return this;
	}
	smoothLerp(v, decay, dt) {
		smoothLerp$1(this, this, v, decay, dt);
		return this;
	}
	clone() {
		return new Vec3(this[0], this[1], this[2]);
	}
	fromArray(a, o = 0) {
		this[0] = a[o];
		this[1] = a[o + 1];
		this[2] = a[o + 2];
		return this;
	}
	toArray(a = [], o = 0) {
		a[o] = this[0];
		a[o + 1] = this[1];
		a[o + 2] = this[2];
		return a;
	}
	transformDirection(mat4) {
		const x = this[0];
		const y = this[1];
		const z = this[2];
		this[0] = mat4[0] * x + mat4[4] * y + mat4[8] * z;
		this[1] = mat4[1] * x + mat4[5] * y + mat4[9] * z;
		this[2] = mat4[2] * x + mat4[6] * y + mat4[10] * z;
		return this.normalize();
	}
};
//#endregion
//#region node_modules/ogl/src/core/Geometry.js
var tempVec3$6 = /* @__PURE__ */ new Vec3();
var ID$4 = 1;
var ATTR_ID = 1;
var isBoundsWarned = false;
var Geometry = class {
	constructor(gl, attributes = {}) {
		if (!gl.canvas) console.error("gl not passed as first argument to Geometry");
		this.gl = gl;
		this.attributes = attributes;
		this.id = ID$4++;
		this.VAOs = {};
		this.drawRange = {
			start: 0,
			count: 0
		};
		this.instancedCount = 0;
		this.gl.renderer.bindVertexArray(null);
		this.gl.renderer.currentGeometry = null;
		this.glState = this.gl.renderer.state;
		for (let key in attributes) this.addAttribute(key, attributes[key]);
	}
	addAttribute(key, attr) {
		this.attributes[key] = attr;
		attr.id = ATTR_ID++;
		attr.size = attr.size || 1;
		attr.type = attr.type || (attr.data.constructor === Float32Array ? this.gl.FLOAT : attr.data.constructor === Uint16Array ? this.gl.UNSIGNED_SHORT : this.gl.UNSIGNED_INT);
		attr.target = key === "index" ? this.gl.ELEMENT_ARRAY_BUFFER : this.gl.ARRAY_BUFFER;
		attr.normalized = attr.normalized || false;
		attr.stride = attr.stride || 0;
		attr.offset = attr.offset || 0;
		attr.count = attr.count || (attr.stride ? attr.data.byteLength / attr.stride : attr.data.length / attr.size);
		attr.divisor = attr.instanced || 0;
		attr.needsUpdate = false;
		attr.usage = attr.usage || this.gl.STATIC_DRAW;
		if (!attr.buffer) this.updateAttribute(attr);
		if (attr.divisor) {
			this.isInstanced = true;
			if (this.instancedCount && this.instancedCount !== attr.count * attr.divisor) {
				console.warn("geometry has multiple instanced buffers of different length");
				return this.instancedCount = Math.min(this.instancedCount, attr.count * attr.divisor);
			}
			this.instancedCount = attr.count * attr.divisor;
		} else if (key === "index") this.drawRange.count = attr.count;
		else if (!this.attributes.index) this.drawRange.count = Math.max(this.drawRange.count, attr.count);
	}
	updateAttribute(attr) {
		const isNewBuffer = !attr.buffer;
		if (isNewBuffer) attr.buffer = this.gl.createBuffer();
		if (this.glState.boundBuffer !== attr.buffer) {
			this.gl.bindBuffer(attr.target, attr.buffer);
			this.glState.boundBuffer = attr.buffer;
		}
		if (isNewBuffer) this.gl.bufferData(attr.target, attr.data, attr.usage);
		else this.gl.bufferSubData(attr.target, 0, attr.data);
		attr.needsUpdate = false;
	}
	setIndex(value) {
		this.addAttribute("index", value);
	}
	setDrawRange(start, count) {
		this.drawRange.start = start;
		this.drawRange.count = count;
	}
	setInstancedCount(value) {
		this.instancedCount = value;
	}
	createVAO(program) {
		this.VAOs[program.attributeOrder] = this.gl.renderer.createVertexArray();
		this.gl.renderer.bindVertexArray(this.VAOs[program.attributeOrder]);
		this.bindAttributes(program);
	}
	bindAttributes(program) {
		program.attributeLocations.forEach((location, { name, type }) => {
			if (!this.attributes[name]) {
				console.warn(`active attribute ${name} not being supplied`);
				return;
			}
			const attr = this.attributes[name];
			this.gl.bindBuffer(attr.target, attr.buffer);
			this.glState.boundBuffer = attr.buffer;
			let numLoc = 1;
			if (type === 35674) numLoc = 2;
			if (type === 35675) numLoc = 3;
			if (type === 35676) numLoc = 4;
			const size = attr.size / numLoc;
			const stride = numLoc === 1 ? 0 : numLoc * numLoc * 4;
			const offset = numLoc === 1 ? 0 : numLoc * 4;
			for (let i = 0; i < numLoc; i++) {
				this.gl.vertexAttribPointer(location + i, size, attr.type, attr.normalized, attr.stride + stride, attr.offset + i * offset);
				this.gl.enableVertexAttribArray(location + i);
				this.gl.renderer.vertexAttribDivisor(location + i, attr.divisor);
			}
		});
		if (this.attributes.index) this.gl.bindBuffer(this.gl.ELEMENT_ARRAY_BUFFER, this.attributes.index.buffer);
	}
	draw({ program, mode = this.gl.TRIANGLES }) {
		if (this.gl.renderer.currentGeometry !== `${this.id}_${program.attributeOrder}`) {
			if (!this.VAOs[program.attributeOrder]) this.createVAO(program);
			this.gl.renderer.bindVertexArray(this.VAOs[program.attributeOrder]);
			this.gl.renderer.currentGeometry = `${this.id}_${program.attributeOrder}`;
		}
		program.attributeLocations.forEach((location, { name }) => {
			const attr = this.attributes[name];
			if (attr.needsUpdate) this.updateAttribute(attr);
		});
		let indexBytesPerElement = 2;
		if (this.attributes.index?.type === this.gl.UNSIGNED_INT) indexBytesPerElement = 4;
		if (this.isInstanced) {
			if (this.attributes.index) this.gl.renderer.drawElementsInstanced(mode, this.drawRange.count, this.attributes.index.type, this.attributes.index.offset + this.drawRange.start * indexBytesPerElement, this.instancedCount);
			else this.gl.renderer.drawArraysInstanced(mode, this.drawRange.start, this.drawRange.count, this.instancedCount);
		} else if (this.attributes.index) this.gl.drawElements(mode, this.drawRange.count, this.attributes.index.type, this.attributes.index.offset + this.drawRange.start * indexBytesPerElement);
		else this.gl.drawArrays(mode, this.drawRange.start, this.drawRange.count);
	}
	getPosition() {
		const attr = this.attributes.position;
		if (attr.data) return attr;
		if (isBoundsWarned) return;
		console.warn("No position buffer data found to compute bounds");
		return isBoundsWarned = true;
	}
	computeBoundingBox(attr) {
		if (!attr) attr = this.getPosition();
		const array = attr.data;
		const stride = attr.size;
		if (!this.bounds) this.bounds = {
			min: new Vec3(),
			max: new Vec3(),
			center: new Vec3(),
			scale: new Vec3(),
			radius: Infinity
		};
		const min = this.bounds.min;
		const max = this.bounds.max;
		const center = this.bounds.center;
		const scale = this.bounds.scale;
		min.set(Infinity);
		max.set(-Infinity);
		for (let i = 0, l = array.length; i < l; i += stride) {
			const x = array[i];
			const y = array[i + 1];
			const z = array[i + 2];
			min.x = Math.min(x, min.x);
			min.y = Math.min(y, min.y);
			min.z = Math.min(z, min.z);
			max.x = Math.max(x, max.x);
			max.y = Math.max(y, max.y);
			max.z = Math.max(z, max.z);
		}
		scale.sub(max, min);
		center.add(min, max).divide(2);
	}
	computeBoundingSphere(attr) {
		if (!attr) attr = this.getPosition();
		const array = attr.data;
		const stride = attr.size;
		if (!this.bounds) this.computeBoundingBox(attr);
		let maxRadiusSq = 0;
		for (let i = 0, l = array.length; i < l; i += stride) {
			tempVec3$6.fromArray(array, i);
			maxRadiusSq = Math.max(maxRadiusSq, this.bounds.center.squaredDistance(tempVec3$6));
		}
		this.bounds.radius = Math.sqrt(maxRadiusSq);
	}
	remove() {
		for (let key in this.VAOs) {
			this.gl.renderer.deleteVertexArray(this.VAOs[key]);
			delete this.VAOs[key];
		}
		for (let key in this.attributes) {
			this.gl.deleteBuffer(this.attributes[key].buffer);
			delete this.attributes[key];
		}
	}
};
//#endregion
//#region node_modules/ogl/src/core/Program.js
var ID$3 = 1;
var arrayCacheF32 = {};
var Program = class {
	constructor(gl, { vertex, fragment, uniforms = {}, transparent = false, cullFace = gl.BACK, frontFace = gl.CCW, depthTest = true, depthWrite = true, depthFunc = gl.LEQUAL } = {}) {
		if (!gl.canvas) console.error("gl not passed as first argument to Program");
		this.gl = gl;
		this.uniforms = uniforms;
		this.id = ID$3++;
		if (!vertex) console.warn("vertex shader not supplied");
		if (!fragment) console.warn("fragment shader not supplied");
		this.transparent = transparent;
		this.cullFace = cullFace;
		this.frontFace = frontFace;
		this.depthTest = depthTest;
		this.depthWrite = depthWrite;
		this.depthFunc = depthFunc;
		this.blendFunc = {};
		this.blendEquation = {};
		this.stencilFunc = {};
		this.stencilOp = {};
		if (this.transparent && !this.blendFunc.src) {
			if (this.gl.renderer.premultipliedAlpha) this.setBlendFunc(this.gl.ONE, this.gl.ONE_MINUS_SRC_ALPHA);
			else this.setBlendFunc(this.gl.SRC_ALPHA, this.gl.ONE_MINUS_SRC_ALPHA);
		}
		this.vertexShader = gl.createShader(gl.VERTEX_SHADER);
		this.fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);
		this.program = gl.createProgram();
		gl.attachShader(this.program, this.vertexShader);
		gl.attachShader(this.program, this.fragmentShader);
		this.setShaders({
			vertex,
			fragment
		});
	}
	setShaders({ vertex, fragment }) {
		if (vertex) {
			this.gl.shaderSource(this.vertexShader, vertex);
			this.gl.compileShader(this.vertexShader);
			if (this.gl.getShaderInfoLog(this.vertexShader) !== "") console.warn(`${this.gl.getShaderInfoLog(this.vertexShader)}\nVertex Shader\n${addLineNumbers(vertex)}`);
		}
		if (fragment) {
			this.gl.shaderSource(this.fragmentShader, fragment);
			this.gl.compileShader(this.fragmentShader);
			if (this.gl.getShaderInfoLog(this.fragmentShader) !== "") console.warn(`${this.gl.getShaderInfoLog(this.fragmentShader)}\nFragment Shader\n${addLineNumbers(fragment)}`);
		}
		this.gl.linkProgram(this.program);
		if (!this.gl.getProgramParameter(this.program, this.gl.LINK_STATUS)) return console.warn(this.gl.getProgramInfoLog(this.program));
		this.uniformLocations = /* @__PURE__ */ new Map();
		let numUniforms = this.gl.getProgramParameter(this.program, this.gl.ACTIVE_UNIFORMS);
		for (let uIndex = 0; uIndex < numUniforms; uIndex++) {
			let uniform = this.gl.getActiveUniform(this.program, uIndex);
			this.uniformLocations.set(uniform, this.gl.getUniformLocation(this.program, uniform.name));
			const split = uniform.name.match(/(\w+)/g);
			uniform.uniformName = split[0];
			uniform.nameComponents = split.slice(1);
		}
		this.attributeLocations = /* @__PURE__ */ new Map();
		const locations = [];
		const numAttribs = this.gl.getProgramParameter(this.program, this.gl.ACTIVE_ATTRIBUTES);
		for (let aIndex = 0; aIndex < numAttribs; aIndex++) {
			const attribute = this.gl.getActiveAttrib(this.program, aIndex);
			const location = this.gl.getAttribLocation(this.program, attribute.name);
			if (location === -1) continue;
			locations[location] = attribute.name;
			this.attributeLocations.set(attribute, location);
		}
		this.attributeOrder = locations.join("");
	}
	setBlendFunc(src, dst, srcAlpha, dstAlpha) {
		this.blendFunc.src = src;
		this.blendFunc.dst = dst;
		this.blendFunc.srcAlpha = srcAlpha;
		this.blendFunc.dstAlpha = dstAlpha;
		if (src) this.transparent = true;
	}
	setBlendEquation(modeRGB, modeAlpha) {
		this.blendEquation.modeRGB = modeRGB;
		this.blendEquation.modeAlpha = modeAlpha;
	}
	setStencilFunc(func, ref, mask) {
		this.stencilRef = ref;
		this.stencilFunc.func = func;
		this.stencilFunc.ref = ref;
		this.stencilFunc.mask = mask;
	}
	setStencilOp(stencilFail, depthFail, depthPass) {
		this.stencilOp.stencilFail = stencilFail;
		this.stencilOp.depthFail = depthFail;
		this.stencilOp.depthPass = depthPass;
	}
	applyState() {
		if (this.depthTest) this.gl.renderer.enable(this.gl.DEPTH_TEST);
		else this.gl.renderer.disable(this.gl.DEPTH_TEST);
		if (this.cullFace) this.gl.renderer.enable(this.gl.CULL_FACE);
		else this.gl.renderer.disable(this.gl.CULL_FACE);
		if (this.blendFunc.src) this.gl.renderer.enable(this.gl.BLEND);
		else this.gl.renderer.disable(this.gl.BLEND);
		if (this.cullFace) this.gl.renderer.setCullFace(this.cullFace);
		this.gl.renderer.setFrontFace(this.frontFace);
		this.gl.renderer.setDepthMask(this.depthWrite);
		this.gl.renderer.setDepthFunc(this.depthFunc);
		if (this.blendFunc.src) this.gl.renderer.setBlendFunc(this.blendFunc.src, this.blendFunc.dst, this.blendFunc.srcAlpha, this.blendFunc.dstAlpha);
		this.gl.renderer.setBlendEquation(this.blendEquation.modeRGB, this.blendEquation.modeAlpha);
		if (this.stencilFunc.func || this.stencilOp.stencilFail) this.gl.renderer.enable(this.gl.STENCIL_TEST);
		else this.gl.renderer.disable(this.gl.STENCIL_TEST);
		this.gl.renderer.setStencilFunc(this.stencilFunc.func, this.stencilFunc.ref, this.stencilFunc.mask);
		this.gl.renderer.setStencilOp(this.stencilOp.stencilFail, this.stencilOp.depthFail, this.stencilOp.depthPass);
	}
	use({ flipFaces = false } = {}) {
		let textureUnit = -1;
		if (!(this.gl.renderer.state.currentProgram === this.id)) {
			this.gl.useProgram(this.program);
			this.gl.renderer.state.currentProgram = this.id;
		}
		this.uniformLocations.forEach((location, activeUniform) => {
			let uniform = this.uniforms[activeUniform.uniformName];
			for (const component of activeUniform.nameComponents) {
				if (!uniform) break;
				if (component in uniform) uniform = uniform[component];
				else if (Array.isArray(uniform.value)) break;
				else {
					uniform = void 0;
					break;
				}
			}
			if (!uniform) return warn(`Active uniform ${activeUniform.name} has not been supplied`);
			if (uniform && uniform.value === void 0) return warn(`${activeUniform.name} uniform is missing a value parameter`);
			if (uniform.value.texture) {
				textureUnit = textureUnit + 1;
				uniform.value.update(textureUnit);
				return setUniform(this.gl, activeUniform.type, location, textureUnit);
			}
			if (uniform.value.length && uniform.value[0].texture) {
				const textureUnits = [];
				uniform.value.forEach((value) => {
					textureUnit = textureUnit + 1;
					value.update(textureUnit);
					textureUnits.push(textureUnit);
				});
				return setUniform(this.gl, activeUniform.type, location, textureUnits);
			}
			setUniform(this.gl, activeUniform.type, location, uniform.value);
		});
		this.applyState();
		if (flipFaces) this.gl.renderer.setFrontFace(this.frontFace === this.gl.CCW ? this.gl.CW : this.gl.CCW);
	}
	remove() {
		this.gl.deleteProgram(this.program);
	}
};
function setUniform(gl, type, location, value) {
	value = value.length ? flatten(value) : value;
	const setValue = gl.renderer.state.uniformLocations.get(location);
	if (value.length) {
		if (setValue === void 0 || setValue.length !== value.length) gl.renderer.state.uniformLocations.set(location, value.slice(0));
		else {
			if (arraysEqual(setValue, value)) return;
			setValue.set ? setValue.set(value) : setArray(setValue, value);
			gl.renderer.state.uniformLocations.set(location, setValue);
		}
	} else {
		if (setValue === value) return;
		gl.renderer.state.uniformLocations.set(location, value);
	}
	switch (type) {
		case 5126: return value.length ? gl.uniform1fv(location, value) : gl.uniform1f(location, value);
		case 35664: return gl.uniform2fv(location, value);
		case 35665: return gl.uniform3fv(location, value);
		case 35666: return gl.uniform4fv(location, value);
		case 35670:
		case 5124:
		case 35678:
		case 36306:
		case 35680:
		case 36289: return value.length ? gl.uniform1iv(location, value) : gl.uniform1i(location, value);
		case 35671:
		case 35667: return gl.uniform2iv(location, value);
		case 35672:
		case 35668: return gl.uniform3iv(location, value);
		case 35673:
		case 35669: return gl.uniform4iv(location, value);
		case 35674: return gl.uniformMatrix2fv(location, false, value);
		case 35675: return gl.uniformMatrix3fv(location, false, value);
		case 35676: return gl.uniformMatrix4fv(location, false, value);
	}
}
function addLineNumbers(string) {
	let lines = string.split("\n");
	for (let i = 0; i < lines.length; i++) lines[i] = i + 1 + ": " + lines[i];
	return lines.join("\n");
}
function flatten(a) {
	const arrayLen = a.length;
	const valueLen = a[0].length;
	if (valueLen === void 0) return a;
	const length = arrayLen * valueLen;
	let value = arrayCacheF32[length];
	if (!value) arrayCacheF32[length] = value = new Float32Array(length);
	for (let i = 0; i < arrayLen; i++) value.set(a[i], i * valueLen);
	return value;
}
function arraysEqual(a, b) {
	if (a.length !== b.length) return false;
	for (let i = 0, l = a.length; i < l; i++) if (a[i] !== b[i]) return false;
	return true;
}
function setArray(a, b) {
	for (let i = 0, l = a.length; i < l; i++) a[i] = b[i];
}
var warnCount = 0;
function warn(message) {
	if (warnCount > 100) return;
	console.warn(message);
	warnCount++;
	if (warnCount > 100) console.warn("More than 100 program warnings - stopping logs.");
}
//#endregion
//#region node_modules/ogl/src/core/Renderer.js
var tempVec3$5 = /* @__PURE__ */ new Vec3();
var ID$2 = 1;
var Renderer = class {
	constructor({ canvas = document.createElement("canvas"), width = 300, height = 150, dpr = 1, alpha = false, depth = true, stencil = false, antialias = false, premultipliedAlpha = false, preserveDrawingBuffer = false, powerPreference = "default", autoClear = true, webgl = 2 } = {}) {
		const attributes = {
			alpha,
			depth,
			stencil,
			antialias,
			premultipliedAlpha,
			preserveDrawingBuffer,
			powerPreference
		};
		this.dpr = dpr;
		this.alpha = alpha;
		this.color = true;
		this.depth = depth;
		this.stencil = stencil;
		this.premultipliedAlpha = premultipliedAlpha;
		this.autoClear = autoClear;
		this.id = ID$2++;
		if (webgl === 2) this.gl = canvas.getContext("webgl2", attributes);
		this.isWebgl2 = !!this.gl;
		if (!this.gl) this.gl = canvas.getContext("webgl", attributes);
		if (!this.gl) console.error("unable to create webgl context");
		this.gl.renderer = this;
		this.setSize(width, height);
		this.state = {};
		this.state.blendFunc = {
			src: this.gl.ONE,
			dst: this.gl.ZERO
		};
		this.state.blendEquation = { modeRGB: this.gl.FUNC_ADD };
		this.state.cullFace = false;
		this.state.frontFace = this.gl.CCW;
		this.state.depthMask = true;
		this.state.depthFunc = this.gl.LEQUAL;
		this.state.premultiplyAlpha = false;
		this.state.flipY = false;
		this.state.unpackAlignment = 4;
		this.state.framebuffer = null;
		this.state.viewport = {
			x: 0,
			y: 0,
			width: null,
			height: null
		};
		this.state.textureUnits = [];
		this.state.activeTextureUnit = 0;
		this.state.boundBuffer = null;
		this.state.uniformLocations = /* @__PURE__ */ new Map();
		this.state.currentProgram = null;
		this.extensions = {};
		if (this.isWebgl2) {
			this.getExtension("EXT_color_buffer_float");
			this.getExtension("OES_texture_float_linear");
		} else {
			this.getExtension("OES_texture_float");
			this.getExtension("OES_texture_float_linear");
			this.getExtension("OES_texture_half_float");
			this.getExtension("OES_texture_half_float_linear");
			this.getExtension("OES_element_index_uint");
			this.getExtension("OES_standard_derivatives");
			this.getExtension("EXT_sRGB");
			this.getExtension("WEBGL_depth_texture");
			this.getExtension("WEBGL_draw_buffers");
		}
		this.getExtension("WEBGL_compressed_texture_astc");
		this.getExtension("EXT_texture_compression_bptc");
		this.getExtension("WEBGL_compressed_texture_s3tc");
		this.getExtension("WEBGL_compressed_texture_etc1");
		this.getExtension("WEBGL_compressed_texture_pvrtc");
		this.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");
		this.vertexAttribDivisor = this.getExtension("ANGLE_instanced_arrays", "vertexAttribDivisor", "vertexAttribDivisorANGLE");
		this.drawArraysInstanced = this.getExtension("ANGLE_instanced_arrays", "drawArraysInstanced", "drawArraysInstancedANGLE");
		this.drawElementsInstanced = this.getExtension("ANGLE_instanced_arrays", "drawElementsInstanced", "drawElementsInstancedANGLE");
		this.createVertexArray = this.getExtension("OES_vertex_array_object", "createVertexArray", "createVertexArrayOES");
		this.bindVertexArray = this.getExtension("OES_vertex_array_object", "bindVertexArray", "bindVertexArrayOES");
		this.deleteVertexArray = this.getExtension("OES_vertex_array_object", "deleteVertexArray", "deleteVertexArrayOES");
		this.drawBuffers = this.getExtension("WEBGL_draw_buffers", "drawBuffers", "drawBuffersWEBGL");
		this.parameters = {};
		this.parameters.maxTextureUnits = this.gl.getParameter(this.gl.MAX_COMBINED_TEXTURE_IMAGE_UNITS);
		this.parameters.maxAnisotropy = this.getExtension("EXT_texture_filter_anisotropic") ? this.gl.getParameter(this.getExtension("EXT_texture_filter_anisotropic").MAX_TEXTURE_MAX_ANISOTROPY_EXT) : 0;
	}
	setSize(width, height) {
		this.width = width;
		this.height = height;
		this.gl.canvas.width = width * this.dpr;
		this.gl.canvas.height = height * this.dpr;
		if (!this.gl.canvas.style) return;
		Object.assign(this.gl.canvas.style, {
			width: width + "px",
			height: height + "px"
		});
	}
	setViewport(width, height, x = 0, y = 0) {
		if (this.state.viewport.width === width && this.state.viewport.height === height) return;
		this.state.viewport.width = width;
		this.state.viewport.height = height;
		this.state.viewport.x = x;
		this.state.viewport.y = y;
		this.gl.viewport(x, y, width, height);
	}
	setScissor(width, height, x = 0, y = 0) {
		this.gl.scissor(x, y, width, height);
	}
	enable(id) {
		if (this.state[id] === true) return;
		this.gl.enable(id);
		this.state[id] = true;
	}
	disable(id) {
		if (this.state[id] === false) return;
		this.gl.disable(id);
		this.state[id] = false;
	}
	setBlendFunc(src, dst, srcAlpha, dstAlpha) {
		if (this.state.blendFunc.src === src && this.state.blendFunc.dst === dst && this.state.blendFunc.srcAlpha === srcAlpha && this.state.blendFunc.dstAlpha === dstAlpha) return;
		this.state.blendFunc.src = src;
		this.state.blendFunc.dst = dst;
		this.state.blendFunc.srcAlpha = srcAlpha;
		this.state.blendFunc.dstAlpha = dstAlpha;
		if (srcAlpha !== void 0) this.gl.blendFuncSeparate(src, dst, srcAlpha, dstAlpha);
		else this.gl.blendFunc(src, dst);
	}
	setBlendEquation(modeRGB, modeAlpha) {
		modeRGB = modeRGB || this.gl.FUNC_ADD;
		if (this.state.blendEquation.modeRGB === modeRGB && this.state.blendEquation.modeAlpha === modeAlpha) return;
		this.state.blendEquation.modeRGB = modeRGB;
		this.state.blendEquation.modeAlpha = modeAlpha;
		if (modeAlpha !== void 0) this.gl.blendEquationSeparate(modeRGB, modeAlpha);
		else this.gl.blendEquation(modeRGB);
	}
	setCullFace(value) {
		if (this.state.cullFace === value) return;
		this.state.cullFace = value;
		this.gl.cullFace(value);
	}
	setFrontFace(value) {
		if (this.state.frontFace === value) return;
		this.state.frontFace = value;
		this.gl.frontFace(value);
	}
	setDepthMask(value) {
		if (this.state.depthMask === value) return;
		this.state.depthMask = value;
		this.gl.depthMask(value);
	}
	setDepthFunc(value) {
		if (this.state.depthFunc === value) return;
		this.state.depthFunc = value;
		this.gl.depthFunc(value);
	}
	setStencilMask(value) {
		if (this.state.stencilMask === value) return;
		this.state.stencilMask = value;
		this.gl.stencilMask(value);
	}
	setStencilFunc(func, ref, mask) {
		if (this.state.stencilFunc === func && this.state.stencilRef === ref && this.state.stencilFuncMask === mask) return;
		this.state.stencilFunc = func || this.gl.ALWAYS;
		this.state.stencilRef = ref || 0;
		this.state.stencilFuncMask = mask || 0;
		this.gl.stencilFunc(func || this.gl.ALWAYS, ref || 0, mask || 0);
	}
	setStencilOp(stencilFail, depthFail, depthPass) {
		if (this.state.stencilFail === stencilFail && this.state.stencilDepthFail === depthFail && this.state.stencilDepthPass === depthPass) return;
		this.state.stencilFail = stencilFail;
		this.state.stencilDepthFail = depthFail;
		this.state.stencilDepthPass = depthPass;
		this.gl.stencilOp(stencilFail, depthFail, depthPass);
	}
	activeTexture(value) {
		if (this.state.activeTextureUnit === value) return;
		this.state.activeTextureUnit = value;
		this.gl.activeTexture(this.gl.TEXTURE0 + value);
	}
	bindFramebuffer({ target = this.gl.FRAMEBUFFER, buffer = null } = {}) {
		if (this.state.framebuffer === buffer) return;
		this.state.framebuffer = buffer;
		this.gl.bindFramebuffer(target, buffer);
	}
	getExtension(extension, webgl2Func, extFunc) {
		if (webgl2Func && this.gl[webgl2Func]) return this.gl[webgl2Func].bind(this.gl);
		if (!this.extensions[extension]) this.extensions[extension] = this.gl.getExtension(extension);
		if (!webgl2Func) return this.extensions[extension];
		if (!this.extensions[extension]) return null;
		return this.extensions[extension][extFunc].bind(this.extensions[extension]);
	}
	sortOpaque(a, b) {
		if (a.renderOrder !== b.renderOrder) return a.renderOrder - b.renderOrder;
		else if (a.program.id !== b.program.id) return a.program.id - b.program.id;
		else if (a.zDepth !== b.zDepth) return a.zDepth - b.zDepth;
		else return b.id - a.id;
	}
	sortTransparent(a, b) {
		if (a.renderOrder !== b.renderOrder) return a.renderOrder - b.renderOrder;
		if (a.zDepth !== b.zDepth) return b.zDepth - a.zDepth;
		else return b.id - a.id;
	}
	sortUI(a, b) {
		if (a.renderOrder !== b.renderOrder) return a.renderOrder - b.renderOrder;
		else if (a.program.id !== b.program.id) return a.program.id - b.program.id;
		else return b.id - a.id;
	}
	getRenderList({ scene, camera, frustumCull, sort }) {
		let renderList = [];
		if (camera && frustumCull) camera.updateFrustum();
		scene.traverse((node) => {
			if (!node.visible) return true;
			if (!node.draw) return;
			if (frustumCull && node.frustumCulled && camera) {
				if (!camera.frustumIntersectsMesh(node)) return;
			}
			renderList.push(node);
		});
		if (sort) {
			const opaque = [];
			const transparent = [];
			const ui = [];
			renderList.forEach((node) => {
				if (!node.program.transparent) opaque.push(node);
				else if (node.program.depthTest) transparent.push(node);
				else ui.push(node);
				node.zDepth = 0;
				if (node.renderOrder !== 0 || !node.program.depthTest || !camera) return;
				node.worldMatrix.getTranslation(tempVec3$5);
				tempVec3$5.applyMatrix4(camera.projectionViewMatrix);
				node.zDepth = tempVec3$5.z;
			});
			opaque.sort(this.sortOpaque);
			transparent.sort(this.sortTransparent);
			ui.sort(this.sortUI);
			renderList = opaque.concat(transparent, ui);
		}
		return renderList;
	}
	render({ scene, camera, target = null, update = true, sort = true, frustumCull = true, clear }) {
		if (target === null) {
			this.bindFramebuffer();
			this.setViewport(this.width * this.dpr, this.height * this.dpr);
		} else {
			this.bindFramebuffer(target);
			this.setViewport(target.width, target.height);
		}
		if (clear || this.autoClear && clear !== false) {
			if (this.depth && (!target || target.depth)) {
				this.enable(this.gl.DEPTH_TEST);
				this.setDepthMask(true);
			}
			if (this.stencil || !target || target.stencil) {
				this.enable(this.gl.STENCIL_TEST);
				this.setStencilMask(255);
			}
			this.gl.clear((this.color ? this.gl.COLOR_BUFFER_BIT : 0) | (this.depth ? this.gl.DEPTH_BUFFER_BIT : 0) | (this.stencil ? this.gl.STENCIL_BUFFER_BIT : 0));
		}
		if (update) scene.updateMatrixWorld();
		if (camera) camera.updateMatrixWorld();
		this.getRenderList({
			scene,
			camera,
			frustumCull,
			sort
		}).forEach((node) => {
			node.draw({ camera });
		});
	}
};
//#endregion
//#region node_modules/ogl/src/math/functions/Vec4Func.js
/**
* Copy the values from one vec4 to another
*
* @param {vec4} out the receiving vector
* @param {vec4} a the source vector
* @returns {vec4} out
*/
function copy$4(out, a) {
	out[0] = a[0];
	out[1] = a[1];
	out[2] = a[2];
	out[3] = a[3];
	return out;
}
/**
* Set the components of a vec4 to the given values
*
* @param {vec4} out the receiving vector
* @param {Number} x X component
* @param {Number} y Y component
* @param {Number} z Z component
* @param {Number} w W component
* @returns {vec4} out
*/
function set$4(out, x, y, z, w) {
	out[0] = x;
	out[1] = y;
	out[2] = z;
	out[3] = w;
	return out;
}
/**
* Scales a vec4 by a scalar number
*
* @param {vec4} out the receiving vector
* @param {vec4} a the vector to scale
* @param {Number} b amount to scale the vector by
* @returns {vec4} out
*/
function scale$3(out, a, b) {
	out[0] = a[0] * b;
	out[1] = a[1] * b;
	out[2] = a[2] * b;
	out[3] = a[3] * b;
	return out;
}
/**
* Normalize a vec4
*
* @param {vec4} out the receiving vector
* @param {vec4} a vector to normalize
* @returns {vec4} out
*/
function normalize$2(out, a) {
	let x = a[0];
	let y = a[1];
	let z = a[2];
	let w = a[3];
	let len = x * x + y * y + z * z + w * w;
	if (len > 0) len = 1 / Math.sqrt(len);
	out[0] = x * len;
	out[1] = y * len;
	out[2] = z * len;
	out[3] = w * len;
	return out;
}
/**
* Calculates the dot product of two vec4's
*
* @param {vec4} a the first operand
* @param {vec4} b the second operand
* @returns {Number} dot product of a and b
*/
function dot$2(a, b) {
	return a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3];
}
//#endregion
//#region node_modules/ogl/src/math/functions/QuatFunc.js
/**
* Set a quat to the identity quaternion
*
* @param {quat} out the receiving quaternion
* @returns {quat} out
*/
function identity$3(out) {
	out[0] = 0;
	out[1] = 0;
	out[2] = 0;
	out[3] = 1;
	return out;
}
/**
* Sets a quat from the given angle and rotation axis,
* then returns it.
*
* @param {quat} out the receiving quaternion
* @param {vec3} axis the axis around which to rotate
* @param {Number} rad the angle in radians
* @returns {quat} out
**/
function setAxisAngle(out, axis, rad) {
	rad = rad * .5;
	let s = Math.sin(rad);
	out[0] = s * axis[0];
	out[1] = s * axis[1];
	out[2] = s * axis[2];
	out[3] = Math.cos(rad);
	return out;
}
/**
* Multiplies two quats
*
* @param {quat} out the receiving quaternion
* @param {quat} a the first operand
* @param {quat} b the second operand
* @returns {quat} out
*/
function multiply$3(out, a, b) {
	let ax = a[0], ay = a[1], az = a[2], aw = a[3];
	let bx = b[0], by = b[1], bz = b[2], bw = b[3];
	out[0] = ax * bw + aw * bx + ay * bz - az * by;
	out[1] = ay * bw + aw * by + az * bx - ax * bz;
	out[2] = az * bw + aw * bz + ax * by - ay * bx;
	out[3] = aw * bw - ax * bx - ay * by - az * bz;
	return out;
}
/**
* Rotates a quaternion by the given angle about the X axis
*
* @param {quat} out quat receiving operation result
* @param {quat} a quat to rotate
* @param {number} rad angle (in radians) to rotate
* @returns {quat} out
*/
function rotateX(out, a, rad) {
	rad *= .5;
	let ax = a[0], ay = a[1], az = a[2], aw = a[3];
	let bx = Math.sin(rad), bw = Math.cos(rad);
	out[0] = ax * bw + aw * bx;
	out[1] = ay * bw + az * bx;
	out[2] = az * bw - ay * bx;
	out[3] = aw * bw - ax * bx;
	return out;
}
/**
* Rotates a quaternion by the given angle about the Y axis
*
* @param {quat} out quat receiving operation result
* @param {quat} a quat to rotate
* @param {number} rad angle (in radians) to rotate
* @returns {quat} out
*/
function rotateY(out, a, rad) {
	rad *= .5;
	let ax = a[0], ay = a[1], az = a[2], aw = a[3];
	let by = Math.sin(rad), bw = Math.cos(rad);
	out[0] = ax * bw - az * by;
	out[1] = ay * bw + aw * by;
	out[2] = az * bw + ax * by;
	out[3] = aw * bw - ay * by;
	return out;
}
/**
* Rotates a quaternion by the given angle about the Z axis
*
* @param {quat} out quat receiving operation result
* @param {quat} a quat to rotate
* @param {number} rad angle (in radians) to rotate
* @returns {quat} out
*/
function rotateZ(out, a, rad) {
	rad *= .5;
	let ax = a[0], ay = a[1], az = a[2], aw = a[3];
	let bz = Math.sin(rad), bw = Math.cos(rad);
	out[0] = ax * bw + ay * bz;
	out[1] = ay * bw - ax * bz;
	out[2] = az * bw + aw * bz;
	out[3] = aw * bw - az * bz;
	return out;
}
/**
* Performs a spherical linear interpolation between two quat
*
* @param {quat} out the receiving quaternion
* @param {quat} a the first operand
* @param {quat} b the second operand
* @param {Number} t interpolation amount between the two inputs
* @returns {quat} out
*/
function slerp(out, a, b, t) {
	let ax = a[0], ay = a[1], az = a[2], aw = a[3];
	let bx = b[0], by = b[1], bz = b[2], bw = b[3];
	let omega, cosom, sinom, scale0, scale1;
	cosom = ax * bx + ay * by + az * bz + aw * bw;
	if (cosom < 0) {
		cosom = -cosom;
		bx = -bx;
		by = -by;
		bz = -bz;
		bw = -bw;
	}
	if (1 - cosom > 1e-6) {
		omega = Math.acos(cosom);
		sinom = Math.sin(omega);
		scale0 = Math.sin((1 - t) * omega) / sinom;
		scale1 = Math.sin(t * omega) / sinom;
	} else {
		scale0 = 1 - t;
		scale1 = t;
	}
	out[0] = scale0 * ax + scale1 * bx;
	out[1] = scale0 * ay + scale1 * by;
	out[2] = scale0 * az + scale1 * bz;
	out[3] = scale0 * aw + scale1 * bw;
	return out;
}
/**
* Calculates the inverse of a quat
*
* @param {quat} out the receiving quaternion
* @param {quat} a quat to calculate inverse of
* @returns {quat} out
*/
function invert$2(out, a) {
	let a0 = a[0], a1 = a[1], a2 = a[2], a3 = a[3];
	let dot = a0 * a0 + a1 * a1 + a2 * a2 + a3 * a3;
	let invDot = dot ? 1 / dot : 0;
	out[0] = -a0 * invDot;
	out[1] = -a1 * invDot;
	out[2] = -a2 * invDot;
	out[3] = a3 * invDot;
	return out;
}
/**
* Calculates the conjugate of a quat
* If the quaternion is normalized, this function is faster than quat.inverse and produces the same result.
*
* @param {quat} out the receiving quaternion
* @param {quat} a quat to calculate conjugate of
* @returns {quat} out
*/
function conjugate(out, a) {
	out[0] = -a[0];
	out[1] = -a[1];
	out[2] = -a[2];
	out[3] = a[3];
	return out;
}
/**
* Creates a quaternion from the given 3x3 rotation matrix.
*
* NOTE: The resultant quaternion is not normalized, so you should be sure
* to renormalize the quaternion yourself where necessary.
*
* @param {quat} out the receiving quaternion
* @param {mat3} m rotation matrix
* @returns {quat} out
* @function
*/
function fromMat3(out, m) {
	let fTrace = m[0] + m[4] + m[8];
	let fRoot;
	if (fTrace > 0) {
		fRoot = Math.sqrt(fTrace + 1);
		out[3] = .5 * fRoot;
		fRoot = .5 / fRoot;
		out[0] = (m[5] - m[7]) * fRoot;
		out[1] = (m[6] - m[2]) * fRoot;
		out[2] = (m[1] - m[3]) * fRoot;
	} else {
		let i = 0;
		if (m[4] > m[0]) i = 1;
		if (m[8] > m[i * 3 + i]) i = 2;
		let j = (i + 1) % 3;
		let k = (i + 2) % 3;
		fRoot = Math.sqrt(m[i * 3 + i] - m[j * 3 + j] - m[k * 3 + k] + 1);
		out[i] = .5 * fRoot;
		fRoot = .5 / fRoot;
		out[3] = (m[j * 3 + k] - m[k * 3 + j]) * fRoot;
		out[j] = (m[j * 3 + i] + m[i * 3 + j]) * fRoot;
		out[k] = (m[k * 3 + i] + m[i * 3 + k]) * fRoot;
	}
	return out;
}
/**
* Creates a quaternion from the given euler angle x, y, z.
*
* @param {quat} out the receiving quaternion
* @param {vec3} euler Angles to rotate around each axis in degrees.
* @param {String} order detailing order of operations. Default 'XYZ'.
* @returns {quat} out
* @function
*/
function fromEuler(out, euler, order = "YXZ") {
	let sx = Math.sin(euler[0] * .5);
	let cx = Math.cos(euler[0] * .5);
	let sy = Math.sin(euler[1] * .5);
	let cy = Math.cos(euler[1] * .5);
	let sz = Math.sin(euler[2] * .5);
	let cz = Math.cos(euler[2] * .5);
	if (order === "XYZ") {
		out[0] = sx * cy * cz + cx * sy * sz;
		out[1] = cx * sy * cz - sx * cy * sz;
		out[2] = cx * cy * sz + sx * sy * cz;
		out[3] = cx * cy * cz - sx * sy * sz;
	} else if (order === "YXZ") {
		out[0] = sx * cy * cz + cx * sy * sz;
		out[1] = cx * sy * cz - sx * cy * sz;
		out[2] = cx * cy * sz - sx * sy * cz;
		out[3] = cx * cy * cz + sx * sy * sz;
	} else if (order === "ZXY") {
		out[0] = sx * cy * cz - cx * sy * sz;
		out[1] = cx * sy * cz + sx * cy * sz;
		out[2] = cx * cy * sz + sx * sy * cz;
		out[3] = cx * cy * cz - sx * sy * sz;
	} else if (order === "ZYX") {
		out[0] = sx * cy * cz - cx * sy * sz;
		out[1] = cx * sy * cz + sx * cy * sz;
		out[2] = cx * cy * sz - sx * sy * cz;
		out[3] = cx * cy * cz + sx * sy * sz;
	} else if (order === "YZX") {
		out[0] = sx * cy * cz + cx * sy * sz;
		out[1] = cx * sy * cz + sx * cy * sz;
		out[2] = cx * cy * sz - sx * sy * cz;
		out[3] = cx * cy * cz - sx * sy * sz;
	} else if (order === "XZY") {
		out[0] = sx * cy * cz - cx * sy * sz;
		out[1] = cx * sy * cz - sx * cy * sz;
		out[2] = cx * cy * sz + sx * sy * cz;
		out[3] = cx * cy * cz + sx * sy * sz;
	}
	return out;
}
/**
* Copy the values from one quat to another
*
* @param {quat} out the receiving quaternion
* @param {quat} a the source quaternion
* @returns {quat} out
* @function
*/
var copy$3 = copy$4;
/**
* Set the components of a quat to the given values
*
* @param {quat} out the receiving quaternion
* @param {Number} x X component
* @param {Number} y Y component
* @param {Number} z Z component
* @param {Number} w W component
* @returns {quat} out
* @function
*/
var set$3 = set$4;
/**
* Calculates the dot product of two quat's
*
* @param {quat} a the first operand
* @param {quat} b the second operand
* @returns {Number} dot product of a and b
* @function
*/
var dot$1 = dot$2;
/**
* Normalize a quat
*
* @param {quat} out the receiving quaternion
* @param {quat} a quaternion to normalize
* @returns {quat} out
* @function
*/
var normalize$1 = normalize$2;
//#endregion
//#region node_modules/ogl/src/math/Quat.js
var Quat = class extends Array {
	constructor(x = 0, y = 0, z = 0, w = 1) {
		super(x, y, z, w);
		this.onChange = () => {};
		this._target = this;
		const triggerProps = [
			"0",
			"1",
			"2",
			"3"
		];
		return new Proxy(this, { set(target, property) {
			const success = Reflect.set(...arguments);
			if (success && triggerProps.includes(property)) target.onChange();
			return success;
		} });
	}
	get x() {
		return this[0];
	}
	get y() {
		return this[1];
	}
	get z() {
		return this[2];
	}
	get w() {
		return this[3];
	}
	set x(v) {
		this._target[0] = v;
		this.onChange();
	}
	set y(v) {
		this._target[1] = v;
		this.onChange();
	}
	set z(v) {
		this._target[2] = v;
		this.onChange();
	}
	set w(v) {
		this._target[3] = v;
		this.onChange();
	}
	identity() {
		identity$3(this._target);
		this.onChange();
		return this;
	}
	set(x, y, z, w) {
		if (x.length) return this.copy(x);
		set$3(this._target, x, y, z, w);
		this.onChange();
		return this;
	}
	rotateX(a) {
		rotateX(this._target, this._target, a);
		this.onChange();
		return this;
	}
	rotateY(a) {
		rotateY(this._target, this._target, a);
		this.onChange();
		return this;
	}
	rotateZ(a) {
		rotateZ(this._target, this._target, a);
		this.onChange();
		return this;
	}
	inverse(q = this._target) {
		invert$2(this._target, q);
		this.onChange();
		return this;
	}
	conjugate(q = this._target) {
		conjugate(this._target, q);
		this.onChange();
		return this;
	}
	copy(q) {
		copy$3(this._target, q);
		this.onChange();
		return this;
	}
	normalize(q = this._target) {
		normalize$1(this._target, q);
		this.onChange();
		return this;
	}
	multiply(qA, qB) {
		if (qB) multiply$3(this._target, qA, qB);
		else multiply$3(this._target, this._target, qA);
		this.onChange();
		return this;
	}
	dot(v) {
		return dot$1(this._target, v);
	}
	fromMatrix3(matrix3) {
		fromMat3(this._target, matrix3);
		this.onChange();
		return this;
	}
	fromEuler(euler, isInternal) {
		fromEuler(this._target, euler, euler.order);
		if (!isInternal) this.onChange();
		return this;
	}
	fromAxisAngle(axis, a) {
		setAxisAngle(this._target, axis, a);
		this.onChange();
		return this;
	}
	slerp(q, t) {
		slerp(this._target, this._target, q, t);
		this.onChange();
		return this;
	}
	fromArray(a, o = 0) {
		this._target[0] = a[o];
		this._target[1] = a[o + 1];
		this._target[2] = a[o + 2];
		this._target[3] = a[o + 3];
		this.onChange();
		return this;
	}
	toArray(a = [], o = 0) {
		a[o] = this[0];
		a[o + 1] = this[1];
		a[o + 2] = this[2];
		a[o + 3] = this[3];
		return a;
	}
};
//#endregion
//#region node_modules/ogl/src/math/functions/Mat4Func.js
var EPSILON = 1e-6;
/**
* Copy the values from one mat4 to another
*
* @param {mat4} out the receiving matrix
* @param {mat4} a the source matrix
* @returns {mat4} out
*/
function copy$2(out, a) {
	out[0] = a[0];
	out[1] = a[1];
	out[2] = a[2];
	out[3] = a[3];
	out[4] = a[4];
	out[5] = a[5];
	out[6] = a[6];
	out[7] = a[7];
	out[8] = a[8];
	out[9] = a[9];
	out[10] = a[10];
	out[11] = a[11];
	out[12] = a[12];
	out[13] = a[13];
	out[14] = a[14];
	out[15] = a[15];
	return out;
}
/**
* Set the components of a mat4 to the given values
*
* @param {mat4} out the receiving matrix
* @returns {mat4} out
*/
function set$2(out, m00, m01, m02, m03, m10, m11, m12, m13, m20, m21, m22, m23, m30, m31, m32, m33) {
	out[0] = m00;
	out[1] = m01;
	out[2] = m02;
	out[3] = m03;
	out[4] = m10;
	out[5] = m11;
	out[6] = m12;
	out[7] = m13;
	out[8] = m20;
	out[9] = m21;
	out[10] = m22;
	out[11] = m23;
	out[12] = m30;
	out[13] = m31;
	out[14] = m32;
	out[15] = m33;
	return out;
}
/**
* Set a mat4 to the identity matrix
*
* @param {mat4} out the receiving matrix
* @returns {mat4} out
*/
function identity$2(out) {
	out[0] = 1;
	out[1] = 0;
	out[2] = 0;
	out[3] = 0;
	out[4] = 0;
	out[5] = 1;
	out[6] = 0;
	out[7] = 0;
	out[8] = 0;
	out[9] = 0;
	out[10] = 1;
	out[11] = 0;
	out[12] = 0;
	out[13] = 0;
	out[14] = 0;
	out[15] = 1;
	return out;
}
/**
* Inverts a mat4
*
* @param {mat4} out the receiving matrix
* @param {mat4} a the source matrix
* @returns {mat4} out
*/
function invert$1(out, a) {
	let a00 = a[0], a01 = a[1], a02 = a[2], a03 = a[3];
	let a10 = a[4], a11 = a[5], a12 = a[6], a13 = a[7];
	let a20 = a[8], a21 = a[9], a22 = a[10], a23 = a[11];
	let a30 = a[12], a31 = a[13], a32 = a[14], a33 = a[15];
	let b00 = a00 * a11 - a01 * a10;
	let b01 = a00 * a12 - a02 * a10;
	let b02 = a00 * a13 - a03 * a10;
	let b03 = a01 * a12 - a02 * a11;
	let b04 = a01 * a13 - a03 * a11;
	let b05 = a02 * a13 - a03 * a12;
	let b06 = a20 * a31 - a21 * a30;
	let b07 = a20 * a32 - a22 * a30;
	let b08 = a20 * a33 - a23 * a30;
	let b09 = a21 * a32 - a22 * a31;
	let b10 = a21 * a33 - a23 * a31;
	let b11 = a22 * a33 - a23 * a32;
	let det = b00 * b11 - b01 * b10 + b02 * b09 + b03 * b08 - b04 * b07 + b05 * b06;
	if (!det) return null;
	det = 1 / det;
	out[0] = (a11 * b11 - a12 * b10 + a13 * b09) * det;
	out[1] = (a02 * b10 - a01 * b11 - a03 * b09) * det;
	out[2] = (a31 * b05 - a32 * b04 + a33 * b03) * det;
	out[3] = (a22 * b04 - a21 * b05 - a23 * b03) * det;
	out[4] = (a12 * b08 - a10 * b11 - a13 * b07) * det;
	out[5] = (a00 * b11 - a02 * b08 + a03 * b07) * det;
	out[6] = (a32 * b02 - a30 * b05 - a33 * b01) * det;
	out[7] = (a20 * b05 - a22 * b02 + a23 * b01) * det;
	out[8] = (a10 * b10 - a11 * b08 + a13 * b06) * det;
	out[9] = (a01 * b08 - a00 * b10 - a03 * b06) * det;
	out[10] = (a30 * b04 - a31 * b02 + a33 * b00) * det;
	out[11] = (a21 * b02 - a20 * b04 - a23 * b00) * det;
	out[12] = (a11 * b07 - a10 * b09 - a12 * b06) * det;
	out[13] = (a00 * b09 - a01 * b07 + a02 * b06) * det;
	out[14] = (a31 * b01 - a30 * b03 - a32 * b00) * det;
	out[15] = (a20 * b03 - a21 * b01 + a22 * b00) * det;
	return out;
}
/**
* Calculates the determinant of a mat4
*
* @param {mat4} a the source matrix
* @returns {Number} determinant of a
*/
function determinant(a) {
	let a00 = a[0], a01 = a[1], a02 = a[2], a03 = a[3];
	let a10 = a[4], a11 = a[5], a12 = a[6], a13 = a[7];
	let a20 = a[8], a21 = a[9], a22 = a[10], a23 = a[11];
	let a30 = a[12], a31 = a[13], a32 = a[14], a33 = a[15];
	let b00 = a00 * a11 - a01 * a10;
	let b01 = a00 * a12 - a02 * a10;
	let b02 = a00 * a13 - a03 * a10;
	let b03 = a01 * a12 - a02 * a11;
	let b04 = a01 * a13 - a03 * a11;
	let b05 = a02 * a13 - a03 * a12;
	let b06 = a20 * a31 - a21 * a30;
	let b07 = a20 * a32 - a22 * a30;
	let b08 = a20 * a33 - a23 * a30;
	let b09 = a21 * a32 - a22 * a31;
	let b10 = a21 * a33 - a23 * a31;
	return b00 * (a22 * a33 - a23 * a32) - b01 * b10 + b02 * b09 + b03 * b08 - b04 * b07 + b05 * b06;
}
/**
* Multiplies two mat4s
*
* @param {mat4} out the receiving matrix
* @param {mat4} a the first operand
* @param {mat4} b the second operand
* @returns {mat4} out
*/
function multiply$2(out, a, b) {
	let a00 = a[0], a01 = a[1], a02 = a[2], a03 = a[3];
	let a10 = a[4], a11 = a[5], a12 = a[6], a13 = a[7];
	let a20 = a[8], a21 = a[9], a22 = a[10], a23 = a[11];
	let a30 = a[12], a31 = a[13], a32 = a[14], a33 = a[15];
	let b0 = b[0], b1 = b[1], b2 = b[2], b3 = b[3];
	out[0] = b0 * a00 + b1 * a10 + b2 * a20 + b3 * a30;
	out[1] = b0 * a01 + b1 * a11 + b2 * a21 + b3 * a31;
	out[2] = b0 * a02 + b1 * a12 + b2 * a22 + b3 * a32;
	out[3] = b0 * a03 + b1 * a13 + b2 * a23 + b3 * a33;
	b0 = b[4];
	b1 = b[5];
	b2 = b[6];
	b3 = b[7];
	out[4] = b0 * a00 + b1 * a10 + b2 * a20 + b3 * a30;
	out[5] = b0 * a01 + b1 * a11 + b2 * a21 + b3 * a31;
	out[6] = b0 * a02 + b1 * a12 + b2 * a22 + b3 * a32;
	out[7] = b0 * a03 + b1 * a13 + b2 * a23 + b3 * a33;
	b0 = b[8];
	b1 = b[9];
	b2 = b[10];
	b3 = b[11];
	out[8] = b0 * a00 + b1 * a10 + b2 * a20 + b3 * a30;
	out[9] = b0 * a01 + b1 * a11 + b2 * a21 + b3 * a31;
	out[10] = b0 * a02 + b1 * a12 + b2 * a22 + b3 * a32;
	out[11] = b0 * a03 + b1 * a13 + b2 * a23 + b3 * a33;
	b0 = b[12];
	b1 = b[13];
	b2 = b[14];
	b3 = b[15];
	out[12] = b0 * a00 + b1 * a10 + b2 * a20 + b3 * a30;
	out[13] = b0 * a01 + b1 * a11 + b2 * a21 + b3 * a31;
	out[14] = b0 * a02 + b1 * a12 + b2 * a22 + b3 * a32;
	out[15] = b0 * a03 + b1 * a13 + b2 * a23 + b3 * a33;
	return out;
}
/**
* Translate a mat4 by the given vector
*
* @param {mat4} out the receiving matrix
* @param {mat4} a the matrix to translate
* @param {vec3} v vector to translate by
* @returns {mat4} out
*/
function translate$1(out, a, v) {
	let x = v[0], y = v[1], z = v[2];
	let a00, a01, a02, a03;
	let a10, a11, a12, a13;
	let a20, a21, a22, a23;
	if (a === out) {
		out[12] = a[0] * x + a[4] * y + a[8] * z + a[12];
		out[13] = a[1] * x + a[5] * y + a[9] * z + a[13];
		out[14] = a[2] * x + a[6] * y + a[10] * z + a[14];
		out[15] = a[3] * x + a[7] * y + a[11] * z + a[15];
	} else {
		a00 = a[0];
		a01 = a[1];
		a02 = a[2];
		a03 = a[3];
		a10 = a[4];
		a11 = a[5];
		a12 = a[6];
		a13 = a[7];
		a20 = a[8];
		a21 = a[9];
		a22 = a[10];
		a23 = a[11];
		out[0] = a00;
		out[1] = a01;
		out[2] = a02;
		out[3] = a03;
		out[4] = a10;
		out[5] = a11;
		out[6] = a12;
		out[7] = a13;
		out[8] = a20;
		out[9] = a21;
		out[10] = a22;
		out[11] = a23;
		out[12] = a00 * x + a10 * y + a20 * z + a[12];
		out[13] = a01 * x + a11 * y + a21 * z + a[13];
		out[14] = a02 * x + a12 * y + a22 * z + a[14];
		out[15] = a03 * x + a13 * y + a23 * z + a[15];
	}
	return out;
}
/**
* Scales the mat4 by the dimensions in the given vec3 not using vectorization
*
* @param {mat4} out the receiving matrix
* @param {mat4} a the matrix to scale
* @param {vec3} v the vec3 to scale the matrix by
* @returns {mat4} out
**/
function scale$2(out, a, v) {
	let x = v[0], y = v[1], z = v[2];
	out[0] = a[0] * x;
	out[1] = a[1] * x;
	out[2] = a[2] * x;
	out[3] = a[3] * x;
	out[4] = a[4] * y;
	out[5] = a[5] * y;
	out[6] = a[6] * y;
	out[7] = a[7] * y;
	out[8] = a[8] * z;
	out[9] = a[9] * z;
	out[10] = a[10] * z;
	out[11] = a[11] * z;
	out[12] = a[12];
	out[13] = a[13];
	out[14] = a[14];
	out[15] = a[15];
	return out;
}
/**
* Rotates a mat4 by the given angle around the given axis
*
* @param {mat4} out the receiving matrix
* @param {mat4} a the matrix to rotate
* @param {Number} rad the angle to rotate the matrix by
* @param {vec3} axis the axis to rotate around
* @returns {mat4} out
*/
function rotate$1(out, a, rad, axis) {
	let x = axis[0], y = axis[1], z = axis[2];
	let len = Math.hypot(x, y, z);
	let s, c, t;
	let a00, a01, a02, a03;
	let a10, a11, a12, a13;
	let a20, a21, a22, a23;
	let b00, b01, b02;
	let b10, b11, b12;
	let b20, b21, b22;
	if (Math.abs(len) < EPSILON) return null;
	len = 1 / len;
	x *= len;
	y *= len;
	z *= len;
	s = Math.sin(rad);
	c = Math.cos(rad);
	t = 1 - c;
	a00 = a[0];
	a01 = a[1];
	a02 = a[2];
	a03 = a[3];
	a10 = a[4];
	a11 = a[5];
	a12 = a[6];
	a13 = a[7];
	a20 = a[8];
	a21 = a[9];
	a22 = a[10];
	a23 = a[11];
	b00 = x * x * t + c;
	b01 = y * x * t + z * s;
	b02 = z * x * t - y * s;
	b10 = x * y * t - z * s;
	b11 = y * y * t + c;
	b12 = z * y * t + x * s;
	b20 = x * z * t + y * s;
	b21 = y * z * t - x * s;
	b22 = z * z * t + c;
	out[0] = a00 * b00 + a10 * b01 + a20 * b02;
	out[1] = a01 * b00 + a11 * b01 + a21 * b02;
	out[2] = a02 * b00 + a12 * b01 + a22 * b02;
	out[3] = a03 * b00 + a13 * b01 + a23 * b02;
	out[4] = a00 * b10 + a10 * b11 + a20 * b12;
	out[5] = a01 * b10 + a11 * b11 + a21 * b12;
	out[6] = a02 * b10 + a12 * b11 + a22 * b12;
	out[7] = a03 * b10 + a13 * b11 + a23 * b12;
	out[8] = a00 * b20 + a10 * b21 + a20 * b22;
	out[9] = a01 * b20 + a11 * b21 + a21 * b22;
	out[10] = a02 * b20 + a12 * b21 + a22 * b22;
	out[11] = a03 * b20 + a13 * b21 + a23 * b22;
	if (a !== out) {
		out[12] = a[12];
		out[13] = a[13];
		out[14] = a[14];
		out[15] = a[15];
	}
	return out;
}
/**
* Returns the translation vector component of a transformation
*  matrix. If a matrix is built with fromRotationTranslation,
*  the returned vector will be the same as the translation vector
*  originally supplied.
* @param  {vec3} out Vector to receive translation component
* @param  {mat4} mat Matrix to be decomposed (input)
* @return {vec3} out
*/
function getTranslation(out, mat) {
	out[0] = mat[12];
	out[1] = mat[13];
	out[2] = mat[14];
	return out;
}
/**
* Returns the scaling factor component of a transformation
*  matrix. If a matrix is built with fromRotationTranslationScale
*  with a normalized Quaternion paramter, the returned vector will be
*  the same as the scaling vector
*  originally supplied.
* @param  {vec3} out Vector to receive scaling factor component
* @param  {mat4} mat Matrix to be decomposed (input)
* @return {vec3} out
*/
function getScaling(out, mat) {
	let m11 = mat[0];
	let m12 = mat[1];
	let m13 = mat[2];
	let m21 = mat[4];
	let m22 = mat[5];
	let m23 = mat[6];
	let m31 = mat[8];
	let m32 = mat[9];
	let m33 = mat[10];
	out[0] = Math.hypot(m11, m12, m13);
	out[1] = Math.hypot(m21, m22, m23);
	out[2] = Math.hypot(m31, m32, m33);
	return out;
}
function getMaxScaleOnAxis(mat) {
	let m11 = mat[0];
	let m12 = mat[1];
	let m13 = mat[2];
	let m21 = mat[4];
	let m22 = mat[5];
	let m23 = mat[6];
	let m31 = mat[8];
	let m32 = mat[9];
	let m33 = mat[10];
	const x = m11 * m11 + m12 * m12 + m13 * m13;
	const y = m21 * m21 + m22 * m22 + m23 * m23;
	const z = m31 * m31 + m32 * m32 + m33 * m33;
	return Math.sqrt(Math.max(x, y, z));
}
/**
* Returns a quaternion representing the rotational component
*  of a transformation matrix. If a matrix is built with
*  fromRotationTranslation, the returned quaternion will be the
*  same as the quaternion originally supplied.
* @param {quat} out Quaternion to receive the rotation component
* @param {mat4} mat Matrix to be decomposed (input)
* @return {quat} out
*/
var getRotation = (function() {
	const temp = [
		1,
		1,
		1
	];
	return function(out, mat) {
		let scaling = temp;
		getScaling(scaling, mat);
		let is1 = 1 / scaling[0];
		let is2 = 1 / scaling[1];
		let is3 = 1 / scaling[2];
		let sm11 = mat[0] * is1;
		let sm12 = mat[1] * is2;
		let sm13 = mat[2] * is3;
		let sm21 = mat[4] * is1;
		let sm22 = mat[5] * is2;
		let sm23 = mat[6] * is3;
		let sm31 = mat[8] * is1;
		let sm32 = mat[9] * is2;
		let sm33 = mat[10] * is3;
		let trace = sm11 + sm22 + sm33;
		let S = 0;
		if (trace > 0) {
			S = Math.sqrt(trace + 1) * 2;
			out[3] = .25 * S;
			out[0] = (sm23 - sm32) / S;
			out[1] = (sm31 - sm13) / S;
			out[2] = (sm12 - sm21) / S;
		} else if (sm11 > sm22 && sm11 > sm33) {
			S = Math.sqrt(1 + sm11 - sm22 - sm33) * 2;
			out[3] = (sm23 - sm32) / S;
			out[0] = .25 * S;
			out[1] = (sm12 + sm21) / S;
			out[2] = (sm31 + sm13) / S;
		} else if (sm22 > sm33) {
			S = Math.sqrt(1 + sm22 - sm11 - sm33) * 2;
			out[3] = (sm31 - sm13) / S;
			out[0] = (sm12 + sm21) / S;
			out[1] = .25 * S;
			out[2] = (sm23 + sm32) / S;
		} else {
			S = Math.sqrt(1 + sm33 - sm11 - sm22) * 2;
			out[3] = (sm12 - sm21) / S;
			out[0] = (sm31 + sm13) / S;
			out[1] = (sm23 + sm32) / S;
			out[2] = .25 * S;
		}
		return out;
	};
})();
/**
* From glTF-Transform
* https://github.com/donmccurdy/glTF-Transform/blob/main/packages/core/src/utils/math-utils.ts
*
* Decompose a mat4 to TRS properties.
*
* Equivalent to the Matrix4 decompose() method in three.js, and intentionally not using the
* gl-matrix version. See: https://github.com/toji/gl-matrix/issues/408
*
* @param {mat4} srcMat Matrix element, to be decomposed to TRS properties.
* @param {quat4} dstRotation Rotation element, to be overwritten.
* @param {vec3} dstTranslation Translation element, to be overwritten.
* @param {vec3} dstScale Scale element, to be overwritten
*/
function decompose(srcMat, dstRotation, dstTranslation, dstScale) {
	let sx = length$1([
		srcMat[0],
		srcMat[1],
		srcMat[2]
	]);
	const sy = length$1([
		srcMat[4],
		srcMat[5],
		srcMat[6]
	]);
	const sz = length$1([
		srcMat[8],
		srcMat[9],
		srcMat[10]
	]);
	if (determinant(srcMat) < 0) sx = -sx;
	dstTranslation[0] = srcMat[12];
	dstTranslation[1] = srcMat[13];
	dstTranslation[2] = srcMat[14];
	const _m1 = srcMat.slice();
	const invSX = 1 / sx;
	const invSY = 1 / sy;
	const invSZ = 1 / sz;
	_m1[0] *= invSX;
	_m1[1] *= invSX;
	_m1[2] *= invSX;
	_m1[4] *= invSY;
	_m1[5] *= invSY;
	_m1[6] *= invSY;
	_m1[8] *= invSZ;
	_m1[9] *= invSZ;
	_m1[10] *= invSZ;
	getRotation(dstRotation, _m1);
	dstScale[0] = sx;
	dstScale[1] = sy;
	dstScale[2] = sz;
}
/**
* From glTF-Transform
* https://github.com/donmccurdy/glTF-Transform/blob/main/packages/core/src/utils/math-utils.ts
*
* Compose TRS properties to a mat4.
*
* Equivalent to the Matrix4 compose() method in three.js, and intentionally not using the
* gl-matrix version. See: https://github.com/toji/gl-matrix/issues/408
*
* @param {mat4} dstMat Matrix element, to be modified and returned.
* @param {quat4} srcRotation Rotation element of matrix.
* @param {vec3} srcTranslation Translation element of matrix.
* @param {vec3} srcScale Scale element of matrix.
* @returns {mat4} dstMat, overwritten to mat4 equivalent of given TRS properties.
*/
function compose(dstMat, srcRotation, srcTranslation, srcScale) {
	const te = dstMat;
	const x = srcRotation[0], y = srcRotation[1], z = srcRotation[2], w = srcRotation[3];
	const x2 = x + x, y2 = y + y, z2 = z + z;
	const xx = x * x2, xy = x * y2, xz = x * z2;
	const yy = y * y2, yz = y * z2, zz = z * z2;
	const wx = w * x2, wy = w * y2, wz = w * z2;
	const sx = srcScale[0], sy = srcScale[1], sz = srcScale[2];
	te[0] = (1 - (yy + zz)) * sx;
	te[1] = (xy + wz) * sx;
	te[2] = (xz - wy) * sx;
	te[3] = 0;
	te[4] = (xy - wz) * sy;
	te[5] = (1 - (xx + zz)) * sy;
	te[6] = (yz + wx) * sy;
	te[7] = 0;
	te[8] = (xz + wy) * sz;
	te[9] = (yz - wx) * sz;
	te[10] = (1 - (xx + yy)) * sz;
	te[11] = 0;
	te[12] = srcTranslation[0];
	te[13] = srcTranslation[1];
	te[14] = srcTranslation[2];
	te[15] = 1;
	return te;
}
/**
* Calculates a 4x4 matrix from the given quaternion
*
* @param {mat4} out mat4 receiving operation result
* @param {quat} q Quaternion to create matrix from
*
* @returns {mat4} out
*/
function fromQuat$1(out, q) {
	let x = q[0], y = q[1], z = q[2], w = q[3];
	let x2 = x + x;
	let y2 = y + y;
	let z2 = z + z;
	let xx = x * x2;
	let yx = y * x2;
	let yy = y * y2;
	let zx = z * x2;
	let zy = z * y2;
	let zz = z * z2;
	let wx = w * x2;
	let wy = w * y2;
	let wz = w * z2;
	out[0] = 1 - yy - zz;
	out[1] = yx + wz;
	out[2] = zx - wy;
	out[3] = 0;
	out[4] = yx - wz;
	out[5] = 1 - xx - zz;
	out[6] = zy + wx;
	out[7] = 0;
	out[8] = zx + wy;
	out[9] = zy - wx;
	out[10] = 1 - xx - yy;
	out[11] = 0;
	out[12] = 0;
	out[13] = 0;
	out[14] = 0;
	out[15] = 1;
	return out;
}
/**
* Generates a perspective projection matrix with the given bounds
*
* @param {mat4} out mat4 frustum matrix will be written into
* @param {number} fovy Vertical field of view in radians
* @param {number} aspect Aspect ratio. typically viewport width/height
* @param {number} near Near bound of the frustum
* @param {number} far Far bound of the frustum
* @returns {mat4} out
*/
function perspective(out, fovy, aspect, near, far) {
	let f = 1 / Math.tan(fovy / 2);
	let nf = 1 / (near - far);
	out[0] = f / aspect;
	out[1] = 0;
	out[2] = 0;
	out[3] = 0;
	out[4] = 0;
	out[5] = f;
	out[6] = 0;
	out[7] = 0;
	out[8] = 0;
	out[9] = 0;
	out[10] = (far + near) * nf;
	out[11] = -1;
	out[12] = 0;
	out[13] = 0;
	out[14] = 2 * far * near * nf;
	out[15] = 0;
	return out;
}
/**
* Generates a orthogonal projection matrix with the given bounds
*
* @param {mat4} out mat4 frustum matrix will be written into
* @param {number} left Left bound of the frustum
* @param {number} right Right bound of the frustum
* @param {number} bottom Bottom bound of the frustum
* @param {number} top Top bound of the frustum
* @param {number} near Near bound of the frustum
* @param {number} far Far bound of the frustum
* @returns {mat4} out
*/
function ortho(out, left, right, bottom, top, near, far) {
	let lr = 1 / (left - right);
	let bt = 1 / (bottom - top);
	let nf = 1 / (near - far);
	out[0] = -2 * lr;
	out[1] = 0;
	out[2] = 0;
	out[3] = 0;
	out[4] = 0;
	out[5] = -2 * bt;
	out[6] = 0;
	out[7] = 0;
	out[8] = 0;
	out[9] = 0;
	out[10] = 2 * nf;
	out[11] = 0;
	out[12] = (left + right) * lr;
	out[13] = (top + bottom) * bt;
	out[14] = (far + near) * nf;
	out[15] = 1;
	return out;
}
/**
* Generates a matrix that makes something look at something else.
*
* @param {mat4} out mat4 frustum matrix will be written into
* @param {vec3} eye Position of the viewer
* @param {vec3} target Point the viewer is looking at
* @param {vec3} up vec3 pointing up
* @returns {mat4} out
*/
function targetTo(out, eye, target, up) {
	let eyex = eye[0], eyey = eye[1], eyez = eye[2], upx = up[0], upy = up[1], upz = up[2];
	let z0 = eyex - target[0], z1 = eyey - target[1], z2 = eyez - target[2];
	let len = z0 * z0 + z1 * z1 + z2 * z2;
	if (len === 0) z2 = 1;
	else {
		len = 1 / Math.sqrt(len);
		z0 *= len;
		z1 *= len;
		z2 *= len;
	}
	let x0 = upy * z2 - upz * z1, x1 = upz * z0 - upx * z2, x2 = upx * z1 - upy * z0;
	len = x0 * x0 + x1 * x1 + x2 * x2;
	if (len === 0) {
		if (upz) upx += 1e-6;
		else if (upy) upz += 1e-6;
		else upy += 1e-6;
		x0 = upy * z2 - upz * z1, x1 = upz * z0 - upx * z2, x2 = upx * z1 - upy * z0;
		len = x0 * x0 + x1 * x1 + x2 * x2;
	}
	len = 1 / Math.sqrt(len);
	x0 *= len;
	x1 *= len;
	x2 *= len;
	out[0] = x0;
	out[1] = x1;
	out[2] = x2;
	out[3] = 0;
	out[4] = z1 * x2 - z2 * x1;
	out[5] = z2 * x0 - z0 * x2;
	out[6] = z0 * x1 - z1 * x0;
	out[7] = 0;
	out[8] = z0;
	out[9] = z1;
	out[10] = z2;
	out[11] = 0;
	out[12] = eyex;
	out[13] = eyey;
	out[14] = eyez;
	out[15] = 1;
	return out;
}
/**
* Adds two mat4's
*
* @param {mat4} out the receiving matrix
* @param {mat4} a the first operand
* @param {mat4} b the second operand
* @returns {mat4} out
*/
function add$1(out, a, b) {
	out[0] = a[0] + b[0];
	out[1] = a[1] + b[1];
	out[2] = a[2] + b[2];
	out[3] = a[3] + b[3];
	out[4] = a[4] + b[4];
	out[5] = a[5] + b[5];
	out[6] = a[6] + b[6];
	out[7] = a[7] + b[7];
	out[8] = a[8] + b[8];
	out[9] = a[9] + b[9];
	out[10] = a[10] + b[10];
	out[11] = a[11] + b[11];
	out[12] = a[12] + b[12];
	out[13] = a[13] + b[13];
	out[14] = a[14] + b[14];
	out[15] = a[15] + b[15];
	return out;
}
/**
* Subtracts matrix b from matrix a
*
* @param {mat4} out the receiving matrix
* @param {mat4} a the first operand
* @param {mat4} b the second operand
* @returns {mat4} out
*/
function subtract$1(out, a, b) {
	out[0] = a[0] - b[0];
	out[1] = a[1] - b[1];
	out[2] = a[2] - b[2];
	out[3] = a[3] - b[3];
	out[4] = a[4] - b[4];
	out[5] = a[5] - b[5];
	out[6] = a[6] - b[6];
	out[7] = a[7] - b[7];
	out[8] = a[8] - b[8];
	out[9] = a[9] - b[9];
	out[10] = a[10] - b[10];
	out[11] = a[11] - b[11];
	out[12] = a[12] - b[12];
	out[13] = a[13] - b[13];
	out[14] = a[14] - b[14];
	out[15] = a[15] - b[15];
	return out;
}
/**
* Multiply each element of the matrix by a scalar.
*
* @param {mat4} out the receiving matrix
* @param {mat4} a the matrix to scale
* @param {Number} b amount to scale the matrix's elements by
* @returns {mat4} out
*/
function multiplyScalar(out, a, b) {
	out[0] = a[0] * b;
	out[1] = a[1] * b;
	out[2] = a[2] * b;
	out[3] = a[3] * b;
	out[4] = a[4] * b;
	out[5] = a[5] * b;
	out[6] = a[6] * b;
	out[7] = a[7] * b;
	out[8] = a[8] * b;
	out[9] = a[9] * b;
	out[10] = a[10] * b;
	out[11] = a[11] * b;
	out[12] = a[12] * b;
	out[13] = a[13] * b;
	out[14] = a[14] * b;
	out[15] = a[15] * b;
	return out;
}
//#endregion
//#region node_modules/ogl/src/math/Mat4.js
var Mat4 = class extends Array {
	constructor(m00 = 1, m01 = 0, m02 = 0, m03 = 0, m10 = 0, m11 = 1, m12 = 0, m13 = 0, m20 = 0, m21 = 0, m22 = 1, m23 = 0, m30 = 0, m31 = 0, m32 = 0, m33 = 1) {
		super(m00, m01, m02, m03, m10, m11, m12, m13, m20, m21, m22, m23, m30, m31, m32, m33);
		return this;
	}
	get x() {
		return this[12];
	}
	get y() {
		return this[13];
	}
	get z() {
		return this[14];
	}
	get w() {
		return this[15];
	}
	set x(v) {
		this[12] = v;
	}
	set y(v) {
		this[13] = v;
	}
	set z(v) {
		this[14] = v;
	}
	set w(v) {
		this[15] = v;
	}
	set(m00, m01, m02, m03, m10, m11, m12, m13, m20, m21, m22, m23, m30, m31, m32, m33) {
		if (m00.length) return this.copy(m00);
		set$2(this, m00, m01, m02, m03, m10, m11, m12, m13, m20, m21, m22, m23, m30, m31, m32, m33);
		return this;
	}
	translate(v, m = this) {
		translate$1(this, m, v);
		return this;
	}
	rotate(v, axis, m = this) {
		rotate$1(this, m, v, axis);
		return this;
	}
	scale(v, m = this) {
		scale$2(this, m, typeof v === "number" ? [
			v,
			v,
			v
		] : v);
		return this;
	}
	add(ma, mb) {
		if (mb) add$1(this, ma, mb);
		else add$1(this, this, ma);
		return this;
	}
	sub(ma, mb) {
		if (mb) subtract$1(this, ma, mb);
		else subtract$1(this, this, ma);
		return this;
	}
	multiply(ma, mb) {
		if (!ma.length) multiplyScalar(this, this, ma);
		else if (mb) multiply$2(this, ma, mb);
		else multiply$2(this, this, ma);
		return this;
	}
	identity() {
		identity$2(this);
		return this;
	}
	copy(m) {
		copy$2(this, m);
		return this;
	}
	fromPerspective({ fov, aspect, near, far } = {}) {
		perspective(this, fov, aspect, near, far);
		return this;
	}
	fromOrthogonal({ left, right, bottom, top, near, far }) {
		ortho(this, left, right, bottom, top, near, far);
		return this;
	}
	fromQuaternion(q) {
		fromQuat$1(this, q);
		return this;
	}
	setPosition(v) {
		this.x = v[0];
		this.y = v[1];
		this.z = v[2];
		return this;
	}
	inverse(m = this) {
		invert$1(this, m);
		return this;
	}
	compose(q, pos, scale) {
		compose(this, q, pos, scale);
		return this;
	}
	decompose(q, pos, scale) {
		decompose(this, q, pos, scale);
		return this;
	}
	getRotation(q) {
		getRotation(q, this);
		return this;
	}
	getTranslation(pos) {
		getTranslation(pos, this);
		return this;
	}
	getScaling(scale) {
		getScaling(scale, this);
		return this;
	}
	getMaxScaleOnAxis() {
		return getMaxScaleOnAxis(this);
	}
	lookAt(eye, target, up) {
		targetTo(this, eye, target, up);
		return this;
	}
	determinant() {
		return determinant(this);
	}
	fromArray(a, o = 0) {
		this[0] = a[o];
		this[1] = a[o + 1];
		this[2] = a[o + 2];
		this[3] = a[o + 3];
		this[4] = a[o + 4];
		this[5] = a[o + 5];
		this[6] = a[o + 6];
		this[7] = a[o + 7];
		this[8] = a[o + 8];
		this[9] = a[o + 9];
		this[10] = a[o + 10];
		this[11] = a[o + 11];
		this[12] = a[o + 12];
		this[13] = a[o + 13];
		this[14] = a[o + 14];
		this[15] = a[o + 15];
		return this;
	}
	toArray(a = [], o = 0) {
		a[o] = this[0];
		a[o + 1] = this[1];
		a[o + 2] = this[2];
		a[o + 3] = this[3];
		a[o + 4] = this[4];
		a[o + 5] = this[5];
		a[o + 6] = this[6];
		a[o + 7] = this[7];
		a[o + 8] = this[8];
		a[o + 9] = this[9];
		a[o + 10] = this[10];
		a[o + 11] = this[11];
		a[o + 12] = this[12];
		a[o + 13] = this[13];
		a[o + 14] = this[14];
		a[o + 15] = this[15];
		return a;
	}
};
//#endregion
//#region node_modules/ogl/src/math/functions/EulerFunc.js
function fromRotationMatrix(out, m, order = "YXZ") {
	if (order === "XYZ") {
		out[1] = Math.asin(Math.min(Math.max(m[8], -1), 1));
		if (Math.abs(m[8]) < .99999) {
			out[0] = Math.atan2(-m[9], m[10]);
			out[2] = Math.atan2(-m[4], m[0]);
		} else {
			out[0] = Math.atan2(m[6], m[5]);
			out[2] = 0;
		}
	} else if (order === "YXZ") {
		out[0] = Math.asin(-Math.min(Math.max(m[9], -1), 1));
		if (Math.abs(m[9]) < .99999) {
			out[1] = Math.atan2(m[8], m[10]);
			out[2] = Math.atan2(m[1], m[5]);
		} else {
			out[1] = Math.atan2(-m[2], m[0]);
			out[2] = 0;
		}
	} else if (order === "ZXY") {
		out[0] = Math.asin(Math.min(Math.max(m[6], -1), 1));
		if (Math.abs(m[6]) < .99999) {
			out[1] = Math.atan2(-m[2], m[10]);
			out[2] = Math.atan2(-m[4], m[5]);
		} else {
			out[1] = 0;
			out[2] = Math.atan2(m[1], m[0]);
		}
	} else if (order === "ZYX") {
		out[1] = Math.asin(-Math.min(Math.max(m[2], -1), 1));
		if (Math.abs(m[2]) < .99999) {
			out[0] = Math.atan2(m[6], m[10]);
			out[2] = Math.atan2(m[1], m[0]);
		} else {
			out[0] = 0;
			out[2] = Math.atan2(-m[4], m[5]);
		}
	} else if (order === "YZX") {
		out[2] = Math.asin(Math.min(Math.max(m[1], -1), 1));
		if (Math.abs(m[1]) < .99999) {
			out[0] = Math.atan2(-m[9], m[5]);
			out[1] = Math.atan2(-m[2], m[0]);
		} else {
			out[0] = 0;
			out[1] = Math.atan2(m[8], m[10]);
		}
	} else if (order === "XZY") {
		out[2] = Math.asin(-Math.min(Math.max(m[4], -1), 1));
		if (Math.abs(m[4]) < .99999) {
			out[0] = Math.atan2(m[6], m[5]);
			out[1] = Math.atan2(m[8], m[0]);
		} else {
			out[0] = Math.atan2(-m[9], m[10]);
			out[1] = 0;
		}
	}
	return out;
}
//#endregion
//#region node_modules/ogl/src/math/Euler.js
var tmpMat4 = /* @__PURE__ */ new Mat4();
var Euler = class extends Array {
	constructor(x = 0, y = x, z = x, order = "YXZ") {
		super(x, y, z);
		this.order = order;
		this.onChange = () => {};
		this._target = this;
		const triggerProps = [
			"0",
			"1",
			"2"
		];
		return new Proxy(this, { set(target, property) {
			const success = Reflect.set(...arguments);
			if (success && triggerProps.includes(property)) target.onChange();
			return success;
		} });
	}
	get x() {
		return this[0];
	}
	get y() {
		return this[1];
	}
	get z() {
		return this[2];
	}
	set x(v) {
		this._target[0] = v;
		this.onChange();
	}
	set y(v) {
		this._target[1] = v;
		this.onChange();
	}
	set z(v) {
		this._target[2] = v;
		this.onChange();
	}
	set(x, y = x, z = x) {
		if (x.length) return this.copy(x);
		this._target[0] = x;
		this._target[1] = y;
		this._target[2] = z;
		this.onChange();
		return this;
	}
	copy(v) {
		this._target[0] = v[0];
		this._target[1] = v[1];
		this._target[2] = v[2];
		this.onChange();
		return this;
	}
	reorder(order) {
		this._target.order = order;
		this.onChange();
		return this;
	}
	fromRotationMatrix(m, order = this.order) {
		fromRotationMatrix(this._target, m, order);
		this.onChange();
		return this;
	}
	fromQuaternion(q, order = this.order, isInternal) {
		tmpMat4.fromQuaternion(q);
		this._target.fromRotationMatrix(tmpMat4, order);
		if (!isInternal) this.onChange();
		return this;
	}
	fromArray(a, o = 0) {
		this._target[0] = a[o];
		this._target[1] = a[o + 1];
		this._target[2] = a[o + 2];
		return this;
	}
	toArray(a = [], o = 0) {
		a[o] = this[0];
		a[o + 1] = this[1];
		a[o + 2] = this[2];
		return a;
	}
};
//#endregion
//#region node_modules/ogl/src/core/Transform.js
var Transform = class {
	constructor() {
		this.parent = null;
		this.children = [];
		this.visible = true;
		this.matrix = new Mat4();
		this.worldMatrix = new Mat4();
		this.matrixAutoUpdate = true;
		this.worldMatrixNeedsUpdate = false;
		this.position = new Vec3();
		this.quaternion = new Quat();
		this.scale = new Vec3(1);
		this.rotation = new Euler();
		this.up = new Vec3(0, 1, 0);
		this.rotation._target.onChange = () => this.quaternion.fromEuler(this.rotation, true);
		this.quaternion._target.onChange = () => this.rotation.fromQuaternion(this.quaternion, void 0, true);
	}
	setParent(parent, notifyParent = true) {
		if (this.parent && parent !== this.parent) this.parent.removeChild(this, false);
		this.parent = parent;
		if (notifyParent && parent) parent.addChild(this, false);
	}
	addChild(child, notifyChild = true) {
		if (!~this.children.indexOf(child)) this.children.push(child);
		if (notifyChild) child.setParent(this, false);
	}
	removeChild(child, notifyChild = true) {
		if (!!~this.children.indexOf(child)) this.children.splice(this.children.indexOf(child), 1);
		if (notifyChild) child.setParent(null, false);
	}
	updateMatrixWorld(force) {
		if (this.matrixAutoUpdate) this.updateMatrix();
		if (this.worldMatrixNeedsUpdate || force) {
			if (this.parent === null) this.worldMatrix.copy(this.matrix);
			else this.worldMatrix.multiply(this.parent.worldMatrix, this.matrix);
			this.worldMatrixNeedsUpdate = false;
			force = true;
		}
		for (let i = 0, l = this.children.length; i < l; i++) this.children[i].updateMatrixWorld(force);
	}
	updateMatrix() {
		this.matrix.compose(this.quaternion, this.position, this.scale);
		this.worldMatrixNeedsUpdate = true;
	}
	traverse(callback) {
		if (callback(this)) return;
		for (let i = 0, l = this.children.length; i < l; i++) this.children[i].traverse(callback);
	}
	decompose() {
		this.matrix.decompose(this.quaternion._target, this.position, this.scale);
		this.rotation.fromQuaternion(this.quaternion);
	}
	lookAt(target, invert = false) {
		if (invert) this.matrix.lookAt(this.position, target, this.up);
		else this.matrix.lookAt(target, this.position, this.up);
		this.matrix.getRotation(this.quaternion._target);
		this.rotation.fromQuaternion(this.quaternion);
	}
};
//#endregion
//#region node_modules/ogl/src/core/Camera.js
var tempMat4$4 = /* @__PURE__ */ new Mat4();
var tempVec3a$1 = /* @__PURE__ */ new Vec3();
var tempVec3b$1 = /* @__PURE__ */ new Vec3();
var Camera = class extends Transform {
	constructor(gl, { near = .1, far = 100, fov = 45, aspect = 1, left, right, bottom, top, zoom = 1 } = {}) {
		super();
		Object.assign(this, {
			near,
			far,
			fov,
			aspect,
			left,
			right,
			bottom,
			top,
			zoom
		});
		this.projectionMatrix = new Mat4();
		this.viewMatrix = new Mat4();
		this.projectionViewMatrix = new Mat4();
		this.worldPosition = new Vec3();
		this.type = left || right ? "orthographic" : "perspective";
		if (this.type === "orthographic") this.orthographic();
		else this.perspective();
	}
	perspective({ near = this.near, far = this.far, fov = this.fov, aspect = this.aspect } = {}) {
		Object.assign(this, {
			near,
			far,
			fov,
			aspect
		});
		this.projectionMatrix.fromPerspective({
			fov: fov * (Math.PI / 180),
			aspect,
			near,
			far
		});
		this.type = "perspective";
		return this;
	}
	orthographic({ near = this.near, far = this.far, left = this.left || -1, right = this.right || 1, bottom = this.bottom || -1, top = this.top || 1, zoom = this.zoom } = {}) {
		Object.assign(this, {
			near,
			far,
			left,
			right,
			bottom,
			top,
			zoom
		});
		left /= zoom;
		right /= zoom;
		bottom /= zoom;
		top /= zoom;
		this.projectionMatrix.fromOrthogonal({
			left,
			right,
			bottom,
			top,
			near,
			far
		});
		this.type = "orthographic";
		return this;
	}
	updateMatrixWorld() {
		super.updateMatrixWorld();
		this.viewMatrix.inverse(this.worldMatrix);
		this.worldMatrix.getTranslation(this.worldPosition);
		this.projectionViewMatrix.multiply(this.projectionMatrix, this.viewMatrix);
		return this;
	}
	updateProjectionMatrix() {
		if (this.type === "perspective") return this.perspective();
		else return this.orthographic();
	}
	lookAt(target) {
		super.lookAt(target, true);
		return this;
	}
	project(v) {
		v.applyMatrix4(this.viewMatrix);
		v.applyMatrix4(this.projectionMatrix);
		return this;
	}
	unproject(v) {
		v.applyMatrix4(tempMat4$4.inverse(this.projectionMatrix));
		v.applyMatrix4(this.worldMatrix);
		return this;
	}
	updateFrustum() {
		if (!this.frustum) this.frustum = [
			new Vec3(),
			new Vec3(),
			new Vec3(),
			new Vec3(),
			new Vec3(),
			new Vec3()
		];
		const m = this.projectionViewMatrix;
		this.frustum[0].set(m[3] - m[0], m[7] - m[4], m[11] - m[8]).constant = m[15] - m[12];
		this.frustum[1].set(m[3] + m[0], m[7] + m[4], m[11] + m[8]).constant = m[15] + m[12];
		this.frustum[2].set(m[3] + m[1], m[7] + m[5], m[11] + m[9]).constant = m[15] + m[13];
		this.frustum[3].set(m[3] - m[1], m[7] - m[5], m[11] - m[9]).constant = m[15] - m[13];
		this.frustum[4].set(m[3] - m[2], m[7] - m[6], m[11] - m[10]).constant = m[15] - m[14];
		this.frustum[5].set(m[3] + m[2], m[7] + m[6], m[11] + m[10]).constant = m[15] + m[14];
		for (let i = 0; i < 6; i++) {
			const invLen = 1 / this.frustum[i].distance();
			this.frustum[i].multiply(invLen);
			this.frustum[i].constant *= invLen;
		}
	}
	frustumIntersectsMesh(node, worldMatrix = node.worldMatrix) {
		if (!node.geometry.attributes.position) return true;
		if (!node.geometry.bounds || node.geometry.bounds.radius === Infinity) node.geometry.computeBoundingSphere();
		if (!node.geometry.bounds) return true;
		const center = tempVec3a$1;
		center.copy(node.geometry.bounds.center);
		center.applyMatrix4(worldMatrix);
		const radius = node.geometry.bounds.radius * worldMatrix.getMaxScaleOnAxis();
		return this.frustumIntersectsSphere(center, radius);
	}
	frustumIntersectsSphere(center, radius) {
		const normal = tempVec3b$1;
		for (let i = 0; i < 6; i++) {
			const plane = this.frustum[i];
			if (normal.copy(plane).dot(center) + plane.constant < -radius) return false;
		}
		return true;
	}
};
//#endregion
//#region node_modules/ogl/src/math/functions/Mat3Func.js
/**
* Copies the upper-left 3x3 values into the given mat3.
*
* @param {mat3} out the receiving 3x3 matrix
* @param {mat4} a   the source 4x4 matrix
* @returns {mat3} out
*/
function fromMat4(out, a) {
	out[0] = a[0];
	out[1] = a[1];
	out[2] = a[2];
	out[3] = a[4];
	out[4] = a[5];
	out[5] = a[6];
	out[6] = a[8];
	out[7] = a[9];
	out[8] = a[10];
	return out;
}
/**
* Calculates a 3x3 matrix from the given quaternion
*
* @param {mat3} out mat3 receiving operation result
* @param {quat} q Quaternion to create matrix from
*
* @returns {mat3} out
*/
function fromQuat(out, q) {
	let x = q[0], y = q[1], z = q[2], w = q[3];
	let x2 = x + x;
	let y2 = y + y;
	let z2 = z + z;
	let xx = x * x2;
	let yx = y * x2;
	let yy = y * y2;
	let zx = z * x2;
	let zy = z * y2;
	let zz = z * z2;
	let wx = w * x2;
	let wy = w * y2;
	let wz = w * z2;
	out[0] = 1 - yy - zz;
	out[3] = yx - wz;
	out[6] = zx + wy;
	out[1] = yx + wz;
	out[4] = 1 - xx - zz;
	out[7] = zy - wx;
	out[2] = zx - wy;
	out[5] = zy + wx;
	out[8] = 1 - xx - yy;
	return out;
}
/**
* Copy the values from one mat3 to another
*
* @param {mat3} out the receiving matrix
* @param {mat3} a the source matrix
* @returns {mat3} out
*/
function copy$1(out, a) {
	out[0] = a[0];
	out[1] = a[1];
	out[2] = a[2];
	out[3] = a[3];
	out[4] = a[4];
	out[5] = a[5];
	out[6] = a[6];
	out[7] = a[7];
	out[8] = a[8];
	return out;
}
/**
* Set the components of a mat3 to the given values
*
* @param {mat3} out the receiving matrix
* @returns {mat3} out
*/
function set$1(out, m00, m01, m02, m10, m11, m12, m20, m21, m22) {
	out[0] = m00;
	out[1] = m01;
	out[2] = m02;
	out[3] = m10;
	out[4] = m11;
	out[5] = m12;
	out[6] = m20;
	out[7] = m21;
	out[8] = m22;
	return out;
}
/**
* Set a mat3 to the identity matrix
*
* @param {mat3} out the receiving matrix
* @returns {mat3} out
*/
function identity$1(out) {
	out[0] = 1;
	out[1] = 0;
	out[2] = 0;
	out[3] = 0;
	out[4] = 1;
	out[5] = 0;
	out[6] = 0;
	out[7] = 0;
	out[8] = 1;
	return out;
}
/**
* Inverts a mat3
*
* @param {mat3} out the receiving matrix
* @param {mat3} a the source matrix
* @returns {mat3} out
*/
function invert(out, a) {
	let a00 = a[0], a01 = a[1], a02 = a[2];
	let a10 = a[3], a11 = a[4], a12 = a[5];
	let a20 = a[6], a21 = a[7], a22 = a[8];
	let b01 = a22 * a11 - a12 * a21;
	let b11 = -a22 * a10 + a12 * a20;
	let b21 = a21 * a10 - a11 * a20;
	let det = a00 * b01 + a01 * b11 + a02 * b21;
	if (!det) return null;
	det = 1 / det;
	out[0] = b01 * det;
	out[1] = (-a22 * a01 + a02 * a21) * det;
	out[2] = (a12 * a01 - a02 * a11) * det;
	out[3] = b11 * det;
	out[4] = (a22 * a00 - a02 * a20) * det;
	out[5] = (-a12 * a00 + a02 * a10) * det;
	out[6] = b21 * det;
	out[7] = (-a21 * a00 + a01 * a20) * det;
	out[8] = (a11 * a00 - a01 * a10) * det;
	return out;
}
/**
* Multiplies two mat3's
*
* @param {mat3} out the receiving matrix
* @param {mat3} a the first operand
* @param {mat3} b the second operand
* @returns {mat3} out
*/
function multiply$1(out, a, b) {
	let a00 = a[0], a01 = a[1], a02 = a[2];
	let a10 = a[3], a11 = a[4], a12 = a[5];
	let a20 = a[6], a21 = a[7], a22 = a[8];
	let b00 = b[0], b01 = b[1], b02 = b[2];
	let b10 = b[3], b11 = b[4], b12 = b[5];
	let b20 = b[6], b21 = b[7], b22 = b[8];
	out[0] = b00 * a00 + b01 * a10 + b02 * a20;
	out[1] = b00 * a01 + b01 * a11 + b02 * a21;
	out[2] = b00 * a02 + b01 * a12 + b02 * a22;
	out[3] = b10 * a00 + b11 * a10 + b12 * a20;
	out[4] = b10 * a01 + b11 * a11 + b12 * a21;
	out[5] = b10 * a02 + b11 * a12 + b12 * a22;
	out[6] = b20 * a00 + b21 * a10 + b22 * a20;
	out[7] = b20 * a01 + b21 * a11 + b22 * a21;
	out[8] = b20 * a02 + b21 * a12 + b22 * a22;
	return out;
}
/**
* Translate a mat3 by the given vector
*
* @param {mat3} out the receiving matrix
* @param {mat3} a the matrix to translate
* @param {vec2} v vector to translate by
* @returns {mat3} out
*/
function translate(out, a, v) {
	let a00 = a[0], a01 = a[1], a02 = a[2], a10 = a[3], a11 = a[4], a12 = a[5], a20 = a[6], a21 = a[7], a22 = a[8], x = v[0], y = v[1];
	out[0] = a00;
	out[1] = a01;
	out[2] = a02;
	out[3] = a10;
	out[4] = a11;
	out[5] = a12;
	out[6] = x * a00 + y * a10 + a20;
	out[7] = x * a01 + y * a11 + a21;
	out[8] = x * a02 + y * a12 + a22;
	return out;
}
/**
* Rotates a mat3 by the given angle
*
* @param {mat3} out the receiving matrix
* @param {mat3} a the matrix to rotate
* @param {Number} rad the angle to rotate the matrix by
* @returns {mat3} out
*/
function rotate(out, a, rad) {
	let a00 = a[0], a01 = a[1], a02 = a[2], a10 = a[3], a11 = a[4], a12 = a[5], a20 = a[6], a21 = a[7], a22 = a[8], s = Math.sin(rad), c = Math.cos(rad);
	out[0] = c * a00 + s * a10;
	out[1] = c * a01 + s * a11;
	out[2] = c * a02 + s * a12;
	out[3] = c * a10 - s * a00;
	out[4] = c * a11 - s * a01;
	out[5] = c * a12 - s * a02;
	out[6] = a20;
	out[7] = a21;
	out[8] = a22;
	return out;
}
/**
* Scales the mat3 by the dimensions in the given vec2
*
* @param {mat3} out the receiving matrix
* @param {mat3} a the matrix to rotate
* @param {vec2} v the vec2 to scale the matrix by
* @returns {mat3} out
**/
function scale$1(out, a, v) {
	let x = v[0], y = v[1];
	out[0] = x * a[0];
	out[1] = x * a[1];
	out[2] = x * a[2];
	out[3] = y * a[3];
	out[4] = y * a[4];
	out[5] = y * a[5];
	out[6] = a[6];
	out[7] = a[7];
	out[8] = a[8];
	return out;
}
/**
* Calculates a 3x3 normal matrix (transpose inverse) from the 4x4 matrix
*
* @param {mat3} out mat3 receiving operation result
* @param {mat4} a Mat4 to derive the normal matrix from
*
* @returns {mat3} out
*/
function normalFromMat4(out, a) {
	let a00 = a[0], a01 = a[1], a02 = a[2], a03 = a[3];
	let a10 = a[4], a11 = a[5], a12 = a[6], a13 = a[7];
	let a20 = a[8], a21 = a[9], a22 = a[10], a23 = a[11];
	let a30 = a[12], a31 = a[13], a32 = a[14], a33 = a[15];
	let b00 = a00 * a11 - a01 * a10;
	let b01 = a00 * a12 - a02 * a10;
	let b02 = a00 * a13 - a03 * a10;
	let b03 = a01 * a12 - a02 * a11;
	let b04 = a01 * a13 - a03 * a11;
	let b05 = a02 * a13 - a03 * a12;
	let b06 = a20 * a31 - a21 * a30;
	let b07 = a20 * a32 - a22 * a30;
	let b08 = a20 * a33 - a23 * a30;
	let b09 = a21 * a32 - a22 * a31;
	let b10 = a21 * a33 - a23 * a31;
	let b11 = a22 * a33 - a23 * a32;
	let det = b00 * b11 - b01 * b10 + b02 * b09 + b03 * b08 - b04 * b07 + b05 * b06;
	if (!det) return null;
	det = 1 / det;
	out[0] = (a11 * b11 - a12 * b10 + a13 * b09) * det;
	out[1] = (a12 * b08 - a10 * b11 - a13 * b07) * det;
	out[2] = (a10 * b10 - a11 * b08 + a13 * b06) * det;
	out[3] = (a02 * b10 - a01 * b11 - a03 * b09) * det;
	out[4] = (a00 * b11 - a02 * b08 + a03 * b07) * det;
	out[5] = (a01 * b08 - a00 * b10 - a03 * b06) * det;
	out[6] = (a31 * b05 - a32 * b04 + a33 * b03) * det;
	out[7] = (a32 * b02 - a30 * b05 - a33 * b01) * det;
	out[8] = (a30 * b04 - a31 * b02 + a33 * b00) * det;
	return out;
}
//#endregion
//#region node_modules/ogl/src/math/Mat3.js
var Mat3 = class extends Array {
	constructor(m00 = 1, m01 = 0, m02 = 0, m10 = 0, m11 = 1, m12 = 0, m20 = 0, m21 = 0, m22 = 1) {
		super(m00, m01, m02, m10, m11, m12, m20, m21, m22);
		return this;
	}
	set(m00, m01, m02, m10, m11, m12, m20, m21, m22) {
		if (m00.length) return this.copy(m00);
		set$1(this, m00, m01, m02, m10, m11, m12, m20, m21, m22);
		return this;
	}
	translate(v, m = this) {
		translate(this, m, v);
		return this;
	}
	rotate(v, m = this) {
		rotate(this, m, v);
		return this;
	}
	scale(v, m = this) {
		scale$1(this, m, v);
		return this;
	}
	multiply(ma, mb) {
		if (mb) multiply$1(this, ma, mb);
		else multiply$1(this, this, ma);
		return this;
	}
	identity() {
		identity$1(this);
		return this;
	}
	copy(m) {
		copy$1(this, m);
		return this;
	}
	fromMatrix4(m) {
		fromMat4(this, m);
		return this;
	}
	fromQuaternion(q) {
		fromQuat(this, q);
		return this;
	}
	fromBasis(vec3a, vec3b, vec3c) {
		this.set(vec3a[0], vec3a[1], vec3a[2], vec3b[0], vec3b[1], vec3b[2], vec3c[0], vec3c[1], vec3c[2]);
		return this;
	}
	inverse(m = this) {
		invert(this, m);
		return this;
	}
	getNormalMatrix(m) {
		normalFromMat4(this, m);
		return this;
	}
};
//#endregion
//#region node_modules/ogl/src/core/Mesh.js
var ID$1 = 0;
var Mesh = class extends Transform {
	constructor(gl, { geometry, program, mode = gl.TRIANGLES, frustumCulled = true, renderOrder = 0 } = {}) {
		super();
		if (!gl.canvas) console.error("gl not passed as first argument to Mesh");
		this.gl = gl;
		this.id = ID$1++;
		this.geometry = geometry;
		this.program = program;
		this.mode = mode;
		this.frustumCulled = frustumCulled;
		this.renderOrder = renderOrder;
		this.modelViewMatrix = new Mat4();
		this.normalMatrix = new Mat3();
		this.beforeRenderCallbacks = [];
		this.afterRenderCallbacks = [];
	}
	onBeforeRender(f) {
		this.beforeRenderCallbacks.push(f);
		return this;
	}
	onAfterRender(f) {
		this.afterRenderCallbacks.push(f);
		return this;
	}
	draw({ camera } = {}) {
		if (camera) {
			if (!this.program.uniforms.modelMatrix) Object.assign(this.program.uniforms, {
				modelMatrix: { value: null },
				viewMatrix: { value: null },
				modelViewMatrix: { value: null },
				normalMatrix: { value: null },
				projectionMatrix: { value: null },
				cameraPosition: { value: null }
			});
			this.program.uniforms.projectionMatrix.value = camera.projectionMatrix;
			this.program.uniforms.cameraPosition.value = camera.worldPosition;
			this.program.uniforms.viewMatrix.value = camera.viewMatrix;
			this.modelViewMatrix.multiply(camera.viewMatrix, this.worldMatrix);
			this.normalMatrix.getNormalMatrix(this.modelViewMatrix);
			this.program.uniforms.modelMatrix.value = this.worldMatrix;
			this.program.uniforms.modelViewMatrix.value = this.modelViewMatrix;
			this.program.uniforms.normalMatrix.value = this.normalMatrix;
		}
		this.beforeRenderCallbacks.forEach((f) => f && f({
			mesh: this,
			camera
		}));
		let flipFaces = this.program.cullFace && this.worldMatrix.determinant() < 0;
		this.program.use({ flipFaces });
		this.geometry.draw({
			mode: this.mode,
			program: this.program
		});
		this.afterRenderCallbacks.forEach((f) => f && f({
			mesh: this,
			camera
		}));
	}
};
//#endregion
//#region node_modules/ogl/src/core/Texture.js
var emptyPixel = /* @__PURE__ */ new Uint8Array(4);
function isPowerOf2(value) {
	return (value & value - 1) === 0;
}
var ID = 1;
var Texture = class {
	constructor(gl, { image, target = gl.TEXTURE_2D, type = gl.UNSIGNED_BYTE, format = gl.RGBA, internalFormat = format, wrapS = gl.CLAMP_TO_EDGE, wrapT = gl.CLAMP_TO_EDGE, wrapR = gl.CLAMP_TO_EDGE, generateMipmaps = target === (gl.TEXTURE_2D || gl.TEXTURE_CUBE_MAP), minFilter = generateMipmaps ? gl.NEAREST_MIPMAP_LINEAR : gl.LINEAR, magFilter = gl.LINEAR, premultiplyAlpha = false, unpackAlignment = 4, flipY = target == (gl.TEXTURE_2D || gl.TEXTURE_3D) ? true : false, anisotropy = 0, level = 0, width, height = width, length = 1 } = {}) {
		this.gl = gl;
		this.id = ID++;
		this.image = image;
		this.target = target;
		this.type = type;
		this.format = format;
		this.internalFormat = internalFormat;
		this.minFilter = minFilter;
		this.magFilter = magFilter;
		this.wrapS = wrapS;
		this.wrapT = wrapT;
		this.wrapR = wrapR;
		this.generateMipmaps = generateMipmaps;
		this.premultiplyAlpha = premultiplyAlpha;
		this.unpackAlignment = unpackAlignment;
		this.flipY = flipY;
		this.anisotropy = Math.min(anisotropy, this.gl.renderer.parameters.maxAnisotropy);
		this.level = level;
		this.width = width;
		this.height = height;
		this.length = length;
		this.texture = this.gl.createTexture();
		this.store = { image: null };
		this.glState = this.gl.renderer.state;
		this.state = {};
		this.state.minFilter = this.gl.NEAREST_MIPMAP_LINEAR;
		this.state.magFilter = this.gl.LINEAR;
		this.state.wrapS = this.gl.REPEAT;
		this.state.wrapT = this.gl.REPEAT;
		this.state.anisotropy = 0;
	}
	bind() {
		if (this.glState.textureUnits[this.glState.activeTextureUnit] === this.id) return;
		this.gl.bindTexture(this.target, this.texture);
		this.glState.textureUnits[this.glState.activeTextureUnit] = this.id;
	}
	update(textureUnit = 0) {
		const needsUpdate = !(this.image === this.store.image && !this.needsUpdate);
		if (needsUpdate || this.glState.textureUnits[textureUnit] !== this.id) {
			this.gl.renderer.activeTexture(textureUnit);
			this.bind();
		}
		if (!needsUpdate) return;
		this.needsUpdate = false;
		if (this.flipY !== this.glState.flipY) {
			this.gl.pixelStorei(this.gl.UNPACK_FLIP_Y_WEBGL, this.flipY);
			this.glState.flipY = this.flipY;
		}
		if (this.premultiplyAlpha !== this.glState.premultiplyAlpha) {
			this.gl.pixelStorei(this.gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, this.premultiplyAlpha);
			this.glState.premultiplyAlpha = this.premultiplyAlpha;
		}
		if (this.unpackAlignment !== this.glState.unpackAlignment) {
			this.gl.pixelStorei(this.gl.UNPACK_ALIGNMENT, this.unpackAlignment);
			this.glState.unpackAlignment = this.unpackAlignment;
		}
		if (this.minFilter !== this.state.minFilter) {
			this.gl.texParameteri(this.target, this.gl.TEXTURE_MIN_FILTER, this.minFilter);
			this.state.minFilter = this.minFilter;
		}
		if (this.magFilter !== this.state.magFilter) {
			this.gl.texParameteri(this.target, this.gl.TEXTURE_MAG_FILTER, this.magFilter);
			this.state.magFilter = this.magFilter;
		}
		if (this.wrapS !== this.state.wrapS) {
			this.gl.texParameteri(this.target, this.gl.TEXTURE_WRAP_S, this.wrapS);
			this.state.wrapS = this.wrapS;
		}
		if (this.wrapT !== this.state.wrapT) {
			this.gl.texParameteri(this.target, this.gl.TEXTURE_WRAP_T, this.wrapT);
			this.state.wrapT = this.wrapT;
		}
		if (this.wrapR !== this.state.wrapR) {
			this.gl.texParameteri(this.target, this.gl.TEXTURE_WRAP_R, this.wrapR);
			this.state.wrapR = this.wrapR;
		}
		if (this.anisotropy && this.anisotropy !== this.state.anisotropy) {
			this.gl.texParameterf(this.target, this.gl.renderer.getExtension("EXT_texture_filter_anisotropic").TEXTURE_MAX_ANISOTROPY_EXT, this.anisotropy);
			this.state.anisotropy = this.anisotropy;
		}
		if (this.image) {
			if (this.image.width) {
				this.width = this.image.width;
				this.height = this.image.height;
			}
			if (this.target === this.gl.TEXTURE_CUBE_MAP) for (let i = 0; i < 6; i++) this.gl.texImage2D(this.gl.TEXTURE_CUBE_MAP_POSITIVE_X + i, this.level, this.internalFormat, this.format, this.type, this.image[i]);
			else if (ArrayBuffer.isView(this.image)) {
				if (this.target === this.gl.TEXTURE_2D) this.gl.texImage2D(this.target, this.level, this.internalFormat, this.width, this.height, 0, this.format, this.type, this.image);
				else if (this.target === this.gl.TEXTURE_2D_ARRAY || this.target === this.gl.TEXTURE_3D) this.gl.texImage3D(this.target, this.level, this.internalFormat, this.width, this.height, this.length, 0, this.format, this.type, this.image);
			} else if (this.image.isCompressedTexture) for (let level = 0; level < this.image.length; level++) this.gl.compressedTexImage2D(this.target, level, this.internalFormat, this.image[level].width, this.image[level].height, 0, this.image[level].data);
			else if (this.target === this.gl.TEXTURE_2D) this.gl.texImage2D(this.target, this.level, this.internalFormat, this.format, this.type, this.image);
			else this.gl.texImage3D(this.target, this.level, this.internalFormat, this.width, this.height, this.length, 0, this.format, this.type, this.image);
			if (this.generateMipmaps) {
				if (!this.gl.renderer.isWebgl2 && (!isPowerOf2(this.image.width) || !isPowerOf2(this.image.height))) {
					this.generateMipmaps = false;
					this.wrapS = this.wrapT = this.gl.CLAMP_TO_EDGE;
					this.minFilter = this.gl.LINEAR;
				} else this.gl.generateMipmap(this.target);
			}
			this.onUpdate && this.onUpdate();
		} else if (this.target === this.gl.TEXTURE_CUBE_MAP) for (let i = 0; i < 6; i++) this.gl.texImage2D(this.gl.TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, this.gl.RGBA, 1, 1, 0, this.gl.RGBA, this.gl.UNSIGNED_BYTE, emptyPixel);
		else if (this.width) {
			if (this.target === this.gl.TEXTURE_2D) this.gl.texImage2D(this.target, this.level, this.internalFormat, this.width, this.height, 0, this.format, this.type, null);
			else this.gl.texImage3D(this.target, this.level, this.internalFormat, this.width, this.height, this.length, 0, this.format, this.type, null);
		} else this.gl.texImage2D(this.target, 0, this.gl.RGBA, 1, 1, 0, this.gl.RGBA, this.gl.UNSIGNED_BYTE, emptyPixel);
		this.store.image = this.image;
	}
};
//#endregion
//#region node_modules/ogl/src/core/RenderTarget.js
var RenderTarget = class {
	constructor(gl, { width = gl.canvas.width, height = gl.canvas.height, target = gl.FRAMEBUFFER, color = 1, depth = true, stencil = false, depthTexture = false, wrapS = gl.CLAMP_TO_EDGE, wrapT = gl.CLAMP_TO_EDGE, wrapR = gl.CLAMP_TO_EDGE, minFilter = gl.LINEAR, magFilter = minFilter, type = gl.UNSIGNED_BYTE, format = gl.RGBA, internalFormat = format, unpackAlignment, premultiplyAlpha } = {}) {
		this.gl = gl;
		this.width = width;
		this.height = height;
		this.depth = depth;
		this.stencil = stencil;
		this.buffer = this.gl.createFramebuffer();
		this.target = target;
		this.gl.renderer.bindFramebuffer(this);
		this.textures = [];
		const drawBuffers = [];
		for (let i = 0; i < color; i++) {
			this.textures.push(new Texture(gl, {
				width,
				height,
				wrapS,
				wrapT,
				wrapR,
				minFilter,
				magFilter,
				type,
				format,
				internalFormat,
				unpackAlignment,
				premultiplyAlpha,
				flipY: false,
				generateMipmaps: false
			}));
			this.textures[i].update();
			this.gl.framebufferTexture2D(this.target, this.gl.COLOR_ATTACHMENT0 + i, this.gl.TEXTURE_2D, this.textures[i].texture, 0);
			drawBuffers.push(this.gl.COLOR_ATTACHMENT0 + i);
		}
		if (drawBuffers.length > 1) this.gl.renderer.drawBuffers(drawBuffers);
		this.texture = this.textures[0];
		if (depthTexture && (this.gl.renderer.isWebgl2 || this.gl.renderer.getExtension("WEBGL_depth_texture"))) {
			this.depthTexture = new Texture(gl, {
				width,
				height,
				minFilter: this.gl.NEAREST,
				magFilter: this.gl.NEAREST,
				format: this.stencil ? this.gl.DEPTH_STENCIL : this.gl.DEPTH_COMPONENT,
				internalFormat: gl.renderer.isWebgl2 ? this.stencil ? this.gl.DEPTH24_STENCIL8 : this.gl.DEPTH_COMPONENT16 : this.gl.DEPTH_COMPONENT,
				type: this.stencil ? this.gl.UNSIGNED_INT_24_8 : this.gl.UNSIGNED_INT
			});
			this.depthTexture.update();
			this.gl.framebufferTexture2D(this.target, this.stencil ? this.gl.DEPTH_STENCIL_ATTACHMENT : this.gl.DEPTH_ATTACHMENT, this.gl.TEXTURE_2D, this.depthTexture.texture, 0);
		} else {
			if (depth && !stencil) {
				this.depthBuffer = this.gl.createRenderbuffer();
				this.gl.bindRenderbuffer(this.gl.RENDERBUFFER, this.depthBuffer);
				this.gl.renderbufferStorage(this.gl.RENDERBUFFER, this.gl.DEPTH_COMPONENT16, width, height);
				this.gl.framebufferRenderbuffer(this.target, this.gl.DEPTH_ATTACHMENT, this.gl.RENDERBUFFER, this.depthBuffer);
			}
			if (stencil && !depth) {
				this.stencilBuffer = this.gl.createRenderbuffer();
				this.gl.bindRenderbuffer(this.gl.RENDERBUFFER, this.stencilBuffer);
				this.gl.renderbufferStorage(this.gl.RENDERBUFFER, this.gl.STENCIL_INDEX8, width, height);
				this.gl.framebufferRenderbuffer(this.target, this.gl.STENCIL_ATTACHMENT, this.gl.RENDERBUFFER, this.stencilBuffer);
			}
			if (depth && stencil) {
				this.depthStencilBuffer = this.gl.createRenderbuffer();
				this.gl.bindRenderbuffer(this.gl.RENDERBUFFER, this.depthStencilBuffer);
				this.gl.renderbufferStorage(this.gl.RENDERBUFFER, this.gl.DEPTH_STENCIL, width, height);
				this.gl.framebufferRenderbuffer(this.target, this.gl.DEPTH_STENCIL_ATTACHMENT, this.gl.RENDERBUFFER, this.depthStencilBuffer);
			}
		}
		this.gl.renderer.bindFramebuffer({ target: this.target });
	}
	setSize(width, height) {
		if (this.width === width && this.height === height) return;
		this.width = width;
		this.height = height;
		this.gl.renderer.bindFramebuffer(this);
		for (let i = 0; i < this.textures.length; i++) {
			this.textures[i].width = width;
			this.textures[i].height = height;
			this.textures[i].needsUpdate = true;
			this.textures[i].update();
			this.gl.framebufferTexture2D(this.target, this.gl.COLOR_ATTACHMENT0 + i, this.gl.TEXTURE_2D, this.textures[i].texture, 0);
		}
		if (this.depthTexture) {
			this.depthTexture.width = width;
			this.depthTexture.height = height;
			this.depthTexture.needsUpdate = true;
			this.depthTexture.update();
			this.gl.framebufferTexture2D(this.target, this.gl.DEPTH_ATTACHMENT, this.gl.TEXTURE_2D, this.depthTexture.texture, 0);
		} else {
			if (this.depthBuffer) {
				this.gl.bindRenderbuffer(this.gl.RENDERBUFFER, this.depthBuffer);
				this.gl.renderbufferStorage(this.gl.RENDERBUFFER, this.gl.DEPTH_COMPONENT16, width, height);
			}
			if (this.stencilBuffer) {
				this.gl.bindRenderbuffer(this.gl.RENDERBUFFER, this.stencilBuffer);
				this.gl.renderbufferStorage(this.gl.RENDERBUFFER, this.gl.STENCIL_INDEX8, width, height);
			}
			if (this.depthStencilBuffer) {
				this.gl.bindRenderbuffer(this.gl.RENDERBUFFER, this.depthStencilBuffer);
				this.gl.renderbufferStorage(this.gl.RENDERBUFFER, this.gl.DEPTH_STENCIL, width, height);
			}
		}
		this.gl.renderer.bindFramebuffer({ target: this.target });
	}
};
//#endregion
//#region node_modules/ogl/src/math/functions/ColorFunc.js
var NAMES = {
	black: "#000000",
	white: "#ffffff",
	red: "#ff0000",
	green: "#00ff00",
	blue: "#0000ff",
	fuchsia: "#ff00ff",
	cyan: "#00ffff",
	yellow: "#ffff00",
	orange: "#ff8000"
};
function hexToRGB(hex) {
	if (hex.length === 4) hex = hex[0] + hex[1] + hex[1] + hex[2] + hex[2] + hex[3] + hex[3];
	const rgb = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
	if (!rgb) console.warn(`Unable to convert hex string ${hex} to rgb values`);
	return [
		parseInt(rgb[1], 16) / 255,
		parseInt(rgb[2], 16) / 255,
		parseInt(rgb[3], 16) / 255
	];
}
function numberToRGB(num) {
	num = parseInt(num);
	return [
		(num >> 16 & 255) / 255,
		(num >> 8 & 255) / 255,
		(num & 255) / 255
	];
}
function parseColor(color) {
	if (color === void 0) return [
		0,
		0,
		0
	];
	if (arguments.length === 3) return arguments;
	if (!isNaN(color)) return numberToRGB(color);
	if (color[0] === "#") return hexToRGB(color);
	if (NAMES[color.toLowerCase()]) return hexToRGB(NAMES[color.toLowerCase()]);
	console.warn("Color format not recognised");
	return [
		0,
		0,
		0
	];
}
//#endregion
//#region node_modules/ogl/src/math/Color.js
var Color = class extends Array {
	constructor(color) {
		if (Array.isArray(color)) return super(...color);
		return super(...parseColor(...arguments));
	}
	get r() {
		return this[0];
	}
	get g() {
		return this[1];
	}
	get b() {
		return this[2];
	}
	set r(v) {
		this[0] = v;
	}
	set g(v) {
		this[1] = v;
	}
	set b(v) {
		this[2] = v;
	}
	set(color) {
		if (Array.isArray(color)) return this.copy(color);
		return this.copy(parseColor(...arguments));
	}
	copy(v) {
		this[0] = v[0];
		this[1] = v[1];
		this[2] = v[2];
		return this;
	}
};
//#endregion
//#region node_modules/ogl/src/math/functions/Vec2Func.js
/**
* Copy the values from one vec2 to another
*
* @param {vec2} out the receiving vector
* @param {vec2} a the source vector
* @returns {vec2} out
*/
function copy(out, a) {
	out[0] = a[0];
	out[1] = a[1];
	return out;
}
/**
* Set the components of a vec2 to the given values
*
* @param {vec2} out the receiving vector
* @param {Number} x X component
* @param {Number} y Y component
* @returns {vec2} out
*/
function set(out, x, y) {
	out[0] = x;
	out[1] = y;
	return out;
}
/**
* Adds two vec2's
*
* @param {vec2} out the receiving vector
* @param {vec2} a the first operand
* @param {vec2} b the second operand
* @returns {vec2} out
*/
function add(out, a, b) {
	out[0] = a[0] + b[0];
	out[1] = a[1] + b[1];
	return out;
}
/**
* Subtracts vector b from vector a
*
* @param {vec2} out the receiving vector
* @param {vec2} a the first operand
* @param {vec2} b the second operand
* @returns {vec2} out
*/
function subtract(out, a, b) {
	out[0] = a[0] - b[0];
	out[1] = a[1] - b[1];
	return out;
}
/**
* Multiplies two vec2's
*
* @param {vec2} out the receiving vector
* @param {vec2} a the first operand
* @param {vec2} b the second operand
* @returns {vec2} out
*/
function multiply(out, a, b) {
	out[0] = a[0] * b[0];
	out[1] = a[1] * b[1];
	return out;
}
/**
* Divides two vec2's
*
* @param {vec2} out the receiving vector
* @param {vec2} a the first operand
* @param {vec2} b the second operand
* @returns {vec2} out
*/
function divide(out, a, b) {
	out[0] = a[0] / b[0];
	out[1] = a[1] / b[1];
	return out;
}
/**
* Scales a vec2 by a scalar number
*
* @param {vec2} out the receiving vector
* @param {vec2} a the vector to scale
* @param {Number} b amount to scale the vector by
* @returns {vec2} out
*/
function scale(out, a, b) {
	out[0] = a[0] * b;
	out[1] = a[1] * b;
	return out;
}
/**
* Calculates the euclidian distance between two vec2's
*
* @param {vec2} a the first operand
* @param {vec2} b the second operand
* @returns {Number} distance between a and b
*/
function distance(a, b) {
	var x = b[0] - a[0], y = b[1] - a[1];
	return Math.sqrt(x * x + y * y);
}
/**
* Calculates the squared euclidian distance between two vec2's
*
* @param {vec2} a the first operand
* @param {vec2} b the second operand
* @returns {Number} squared distance between a and b
*/
function squaredDistance(a, b) {
	var x = b[0] - a[0], y = b[1] - a[1];
	return x * x + y * y;
}
/**
* Calculates the length of a vec2
*
* @param {vec2} a vector to calculate length of
* @returns {Number} length of a
*/
function length(a) {
	var x = a[0], y = a[1];
	return Math.sqrt(x * x + y * y);
}
/**
* Calculates the squared length of a vec2
*
* @param {vec2} a vector to calculate squared length of
* @returns {Number} squared length of a
*/
function squaredLength(a) {
	var x = a[0], y = a[1];
	return x * x + y * y;
}
/**
* Negates the components of a vec2
*
* @param {vec2} out the receiving vector
* @param {vec2} a vector to negate
* @returns {vec2} out
*/
function negate(out, a) {
	out[0] = -a[0];
	out[1] = -a[1];
	return out;
}
/**
* Returns the inverse of the components of a vec2
*
* @param {vec2} out the receiving vector
* @param {vec2} a vector to invert
* @returns {vec2} out
*/
function inverse(out, a) {
	out[0] = 1 / a[0];
	out[1] = 1 / a[1];
	return out;
}
/**
* Normalize a vec2
*
* @param {vec2} out the receiving vector
* @param {vec2} a vector to normalize
* @returns {vec2} out
*/
function normalize(out, a) {
	var x = a[0], y = a[1];
	var len = x * x + y * y;
	if (len > 0) len = 1 / Math.sqrt(len);
	out[0] = a[0] * len;
	out[1] = a[1] * len;
	return out;
}
/**
* Calculates the dot product of two vec2's
*
* @param {vec2} a the first operand
* @param {vec2} b the second operand
* @returns {Number} dot product of a and b
*/
function dot(a, b) {
	return a[0] * b[0] + a[1] * b[1];
}
/**
* Computes the cross product of two vec2's
* Note that the cross product returns a scalar
*
* @param {vec2} a the first operand
* @param {vec2} b the second operand
* @returns {Number} cross product of a and b
*/
function cross(a, b) {
	return a[0] * b[1] - a[1] * b[0];
}
/**
* Performs a linear interpolation between two vec2's
*
* @param {vec2} out the receiving vector
* @param {vec2} a the first operand
* @param {vec2} b the second operand
* @param {Number} t interpolation amount between the two inputs
* @returns {vec2} out
*/
function lerp(out, a, b, t) {
	var ax = a[0], ay = a[1];
	out[0] = ax + t * (b[0] - ax);
	out[1] = ay + t * (b[1] - ay);
	return out;
}
/**
* Performs a frame rate independant, linear interpolation between two vec2's
*
* @param {vec2} out the receiving vector
* @param {vec2} a the first operand
* @param {vec2} b the second operand
* @param {Number} decay decay constant for interpolation. useful range between 1 and 25, from slow to fast.
* @param {Number} dt delta time
* @returns {vec2} out
*/
function smoothLerp(out, a, b, decay, dt) {
	const exp = Math.exp(-decay * dt);
	let ax = a[0];
	let ay = a[1];
	out[0] = b[0] + (ax - b[0]) * exp;
	out[1] = b[1] + (ay - b[1]) * exp;
	return out;
}
/**
* Transforms the vec2 with a mat3
* 3rd vector component is implicitly '1'
*
* @param {vec2} out the receiving vector
* @param {vec2} a the vector to transform
* @param {mat3} m matrix to transform with
* @returns {vec2} out
*/
function transformMat3(out, a, m) {
	var x = a[0], y = a[1];
	out[0] = m[0] * x + m[3] * y + m[6];
	out[1] = m[1] * x + m[4] * y + m[7];
	return out;
}
/**
* Transforms the vec2 with a mat4
* 3rd vector component is implicitly '0'
* 4th vector component is implicitly '1'
*
* @param {vec2} out the receiving vector
* @param {vec2} a the vector to transform
* @param {mat4} m matrix to transform with
* @returns {vec2} out
*/
function transformMat4(out, a, m) {
	let x = a[0];
	let y = a[1];
	out[0] = m[0] * x + m[4] * y + m[12];
	out[1] = m[1] * x + m[5] * y + m[13];
	return out;
}
/**
* Returns whether or not the vectors exactly have the same elements in the same position (when compared with ===)
*
* @param {vec2} a The first vector.
* @param {vec2} b The second vector.
* @returns {Boolean} True if the vectors are equal, false otherwise.
*/
function exactEquals(a, b) {
	return a[0] === b[0] && a[1] === b[1];
}
//#endregion
//#region node_modules/ogl/src/math/Vec2.js
var Vec2 = class Vec2 extends Array {
	constructor(x = 0, y = x) {
		super(x, y);
		return this;
	}
	get x() {
		return this[0];
	}
	get y() {
		return this[1];
	}
	set x(v) {
		this[0] = v;
	}
	set y(v) {
		this[1] = v;
	}
	set(x, y = x) {
		if (x.length) return this.copy(x);
		set(this, x, y);
		return this;
	}
	copy(v) {
		copy(this, v);
		return this;
	}
	add(va, vb) {
		if (vb) add(this, va, vb);
		else add(this, this, va);
		return this;
	}
	sub(va, vb) {
		if (vb) subtract(this, va, vb);
		else subtract(this, this, va);
		return this;
	}
	multiply(v) {
		if (v.length) multiply(this, this, v);
		else scale(this, this, v);
		return this;
	}
	divide(v) {
		if (v.length) divide(this, this, v);
		else scale(this, this, 1 / v);
		return this;
	}
	inverse(v = this) {
		inverse(this, v);
		return this;
	}
	len() {
		return length(this);
	}
	distance(v) {
		if (v) return distance(this, v);
		else return length(this);
	}
	squaredLen() {
		return this.squaredDistance();
	}
	squaredDistance(v) {
		if (v) return squaredDistance(this, v);
		else return squaredLength(this);
	}
	negate(v = this) {
		negate(this, v);
		return this;
	}
	cross(va, vb) {
		if (vb) return cross(va, vb);
		return cross(this, va);
	}
	scale(v) {
		scale(this, this, v);
		return this;
	}
	normalize() {
		normalize(this, this);
		return this;
	}
	dot(v) {
		return dot(this, v);
	}
	equals(v) {
		return exactEquals(this, v);
	}
	applyMatrix3(mat3) {
		transformMat3(this, this, mat3);
		return this;
	}
	applyMatrix4(mat4) {
		transformMat4(this, this, mat4);
		return this;
	}
	lerp(v, a) {
		lerp(this, this, v, a);
		return this;
	}
	smoothLerp(v, decay, dt) {
		smoothLerp(this, this, v, decay, dt);
		return this;
	}
	clone() {
		return new Vec2(this[0], this[1]);
	}
	fromArray(a, o = 0) {
		this[0] = a[o];
		this[1] = a[o + 1];
		return this;
	}
	toArray(a = [], o = 0) {
		a[o] = this[0];
		a[o + 1] = this[1];
		return a;
	}
};
//#endregion
//#region node_modules/ogl/src/math/Vec4.js
var Vec4 = class extends Array {
	constructor(x = 0, y = x, z = x, w = x) {
		super(x, y, z, w);
		return this;
	}
	get x() {
		return this[0];
	}
	get y() {
		return this[1];
	}
	get z() {
		return this[2];
	}
	get w() {
		return this[3];
	}
	set x(v) {
		this[0] = v;
	}
	set y(v) {
		this[1] = v;
	}
	set z(v) {
		this[2] = v;
	}
	set w(v) {
		this[3] = v;
	}
	set(x, y = x, z = x, w = x) {
		if (x.length) return this.copy(x);
		set$4(this, x, y, z, w);
		return this;
	}
	copy(v) {
		copy$4(this, v);
		return this;
	}
	normalize() {
		normalize$2(this, this);
		return this;
	}
	multiply(v) {
		scale$3(this, this, v);
		return this;
	}
	dot(v) {
		return dot$2(this, v);
	}
	fromArray(a, o = 0) {
		this[0] = a[o];
		this[1] = a[o + 1];
		this[2] = a[o + 2];
		this[3] = a[o + 3];
		return this;
	}
	toArray(a = [], o = 0) {
		a[o] = this[0];
		a[o + 1] = this[1];
		a[o + 2] = this[2];
		a[o + 3] = this[3];
		return a;
	}
};
//#endregion
//#region node_modules/ogl/src/extras/Plane.js
var Plane = class Plane extends Geometry {
	constructor(gl, { width = 1, height = 1, widthSegments = 1, heightSegments = 1, attributes = {} } = {}) {
		const wSegs = widthSegments;
		const hSegs = heightSegments;
		const num = (wSegs + 1) * (hSegs + 1);
		const numIndices = wSegs * hSegs * 6;
		const position = new Float32Array(num * 3);
		const normal = new Float32Array(num * 3);
		const uv = new Float32Array(num * 2);
		const index = numIndices > 65536 ? new Uint32Array(numIndices) : new Uint16Array(numIndices);
		Plane.buildPlane(position, normal, uv, index, width, height, 0, wSegs, hSegs);
		Object.assign(attributes, {
			position: {
				size: 3,
				data: position
			},
			normal: {
				size: 3,
				data: normal
			},
			uv: {
				size: 2,
				data: uv
			},
			index: { data: index }
		});
		super(gl, attributes);
	}
	static buildPlane(position, normal, uv, index, width, height, depth, wSegs, hSegs, u = 0, v = 1, w = 2, uDir = 1, vDir = -1, i = 0, ii = 0) {
		const io = i;
		const segW = width / wSegs;
		const segH = height / hSegs;
		for (let iy = 0; iy <= hSegs; iy++) {
			let y = iy * segH - height / 2;
			for (let ix = 0; ix <= wSegs; ix++, i++) {
				let x = ix * segW - width / 2;
				position[i * 3 + u] = x * uDir;
				position[i * 3 + v] = y * vDir;
				position[i * 3 + w] = depth / 2;
				normal[i * 3 + u] = 0;
				normal[i * 3 + v] = 0;
				normal[i * 3 + w] = depth >= 0 ? 1 : -1;
				uv[i * 2] = ix / wSegs;
				uv[i * 2 + 1] = 1 - iy / hSegs;
				if (iy === hSegs || ix === wSegs) continue;
				let a = io + ix + iy * (wSegs + 1);
				let b = io + ix + (iy + 1) * (wSegs + 1);
				let c = io + ix + (iy + 1) * (wSegs + 1) + 1;
				let d = io + ix + iy * (wSegs + 1) + 1;
				index[ii * 6] = a;
				index[ii * 6 + 1] = b;
				index[ii * 6 + 2] = d;
				index[ii * 6 + 3] = b;
				index[ii * 6 + 4] = c;
				index[ii * 6 + 5] = d;
				ii++;
			}
		}
	}
};
//#endregion
//#region node_modules/ogl/src/extras/Box.js
var Box = class extends Geometry {
	constructor(gl, { width = 1, height = 1, depth = 1, widthSegments = 1, heightSegments = 1, depthSegments = 1, attributes = {} } = {}) {
		const wSegs = widthSegments;
		const hSegs = heightSegments;
		const dSegs = depthSegments;
		const num = (wSegs + 1) * (hSegs + 1) * 2 + (wSegs + 1) * (dSegs + 1) * 2 + (hSegs + 1) * (dSegs + 1) * 2;
		const numIndices = (wSegs * hSegs * 2 + wSegs * dSegs * 2 + hSegs * dSegs * 2) * 6;
		const position = new Float32Array(num * 3);
		const normal = new Float32Array(num * 3);
		const uv = new Float32Array(num * 2);
		const index = num > 65536 ? new Uint32Array(numIndices) : new Uint16Array(numIndices);
		let i = 0;
		let ii = 0;
		Plane.buildPlane(position, normal, uv, index, depth, height, width, dSegs, hSegs, 2, 1, 0, -1, -1, i, ii);
		i += (dSegs + 1) * (hSegs + 1);
		ii += dSegs * hSegs;
		Plane.buildPlane(position, normal, uv, index, depth, height, -width, dSegs, hSegs, 2, 1, 0, 1, -1, i, ii);
		i += (dSegs + 1) * (hSegs + 1);
		ii += dSegs * hSegs;
		Plane.buildPlane(position, normal, uv, index, width, depth, height, dSegs, wSegs, 0, 2, 1, 1, 1, i, ii);
		i += (wSegs + 1) * (dSegs + 1);
		ii += wSegs * dSegs;
		Plane.buildPlane(position, normal, uv, index, width, depth, -height, dSegs, wSegs, 0, 2, 1, 1, -1, i, ii);
		i += (wSegs + 1) * (dSegs + 1);
		ii += wSegs * dSegs;
		Plane.buildPlane(position, normal, uv, index, width, height, -depth, wSegs, hSegs, 0, 1, 2, -1, -1, i, ii);
		i += (wSegs + 1) * (hSegs + 1);
		ii += wSegs * hSegs;
		Plane.buildPlane(position, normal, uv, index, width, height, depth, wSegs, hSegs, 0, 1, 2, 1, -1, i, ii);
		Object.assign(attributes, {
			position: {
				size: 3,
				data: position
			},
			normal: {
				size: 3,
				data: normal
			},
			uv: {
				size: 2,
				data: uv
			},
			index: { data: index }
		});
		super(gl, attributes);
	}
};
//#endregion
//#region node_modules/ogl/src/extras/Sphere.js
var Sphere = class extends Geometry {
	constructor(gl, { radius = .5, widthSegments = 16, heightSegments = Math.ceil(widthSegments * .5), phiStart = 0, phiLength = Math.PI * 2, thetaStart = 0, thetaLength = Math.PI, attributes = {} } = {}) {
		const wSegs = widthSegments;
		const hSegs = heightSegments;
		const pStart = phiStart;
		const pLength = phiLength;
		const tStart = thetaStart;
		const tLength = thetaLength;
		const num = (wSegs + 1) * (hSegs + 1);
		const numIndices = wSegs * hSegs * 6;
		const position = new Float32Array(num * 3);
		const normal = new Float32Array(num * 3);
		const uv = new Float32Array(num * 2);
		const index = num > 65536 ? new Uint32Array(numIndices) : new Uint16Array(numIndices);
		let i = 0;
		let iv = 0;
		let ii = 0;
		let te = tStart + tLength;
		const grid = [];
		let n = new Vec3();
		for (let iy = 0; iy <= hSegs; iy++) {
			let vRow = [];
			let v = iy / hSegs;
			for (let ix = 0; ix <= wSegs; ix++, i++) {
				let u = ix / wSegs;
				let x = -radius * Math.cos(pStart + u * pLength) * Math.sin(tStart + v * tLength);
				let y = radius * Math.cos(tStart + v * tLength);
				let z = radius * Math.sin(pStart + u * pLength) * Math.sin(tStart + v * tLength);
				position[i * 3] = x;
				position[i * 3 + 1] = y;
				position[i * 3 + 2] = z;
				n.set(x, y, z).normalize();
				normal[i * 3] = n.x;
				normal[i * 3 + 1] = n.y;
				normal[i * 3 + 2] = n.z;
				uv[i * 2] = u;
				uv[i * 2 + 1] = 1 - v;
				vRow.push(iv++);
			}
			grid.push(vRow);
		}
		for (let iy = 0; iy < hSegs; iy++) for (let ix = 0; ix < wSegs; ix++) {
			let a = grid[iy][ix + 1];
			let b = grid[iy][ix];
			let c = grid[iy + 1][ix];
			let d = grid[iy + 1][ix + 1];
			if (iy !== 0 || tStart > 0) {
				index[ii * 3] = a;
				index[ii * 3 + 1] = b;
				index[ii * 3 + 2] = d;
				ii++;
			}
			if (iy !== hSegs - 1 || te < Math.PI) {
				index[ii * 3] = b;
				index[ii * 3 + 1] = c;
				index[ii * 3 + 2] = d;
				ii++;
			}
		}
		Object.assign(attributes, {
			position: {
				size: 3,
				data: position
			},
			normal: {
				size: 3,
				data: normal
			},
			uv: {
				size: 2,
				data: uv
			},
			index: { data: index }
		});
		super(gl, attributes);
	}
};
//#endregion
//#region node_modules/ogl/src/extras/Cylinder.js
var Cylinder = class extends Geometry {
	constructor(gl, { radiusTop = .5, radiusBottom = .5, height = 1, radialSegments = 8, heightSegments = 1, openEnded = false, thetaStart = 0, thetaLength = Math.PI * 2, attributes = {} } = {}) {
		const rSegs = radialSegments;
		const hSegs = heightSegments;
		const tStart = thetaStart;
		const tLength = thetaLength;
		const numCaps = openEnded ? 0 : radiusBottom && radiusTop ? 2 : 1;
		const num = (rSegs + 1) * (hSegs + 1 + numCaps) + numCaps;
		const numIndices = rSegs * hSegs * 6 + numCaps * rSegs * 3;
		const position = new Float32Array(num * 3);
		const normal = new Float32Array(num * 3);
		const uv = new Float32Array(num * 2);
		const index = num > 65536 ? new Uint32Array(numIndices) : new Uint16Array(numIndices);
		let i = 0;
		let ii = 0;
		const indexArray = [];
		addHeight();
		if (!openEnded) {
			if (radiusTop) addCap(true);
			if (radiusBottom) addCap(false);
		}
		function addHeight() {
			let x, y;
			const n = new Vec3();
			const slope = (radiusBottom - radiusTop) / height;
			for (y = 0; y <= hSegs; y++) {
				const indexRow = [];
				const v = y / hSegs;
				const r = v * (radiusBottom - radiusTop) + radiusTop;
				for (x = 0; x <= rSegs; x++) {
					const u = x / rSegs;
					const theta = u * tLength + tStart;
					const sinTheta = Math.sin(theta);
					const cosTheta = Math.cos(theta);
					position.set([
						r * sinTheta,
						(.5 - v) * height,
						r * cosTheta
					], i * 3);
					n.set(sinTheta, slope, cosTheta).normalize();
					normal.set([
						n.x,
						n.y,
						n.z
					], i * 3);
					uv.set([u, 1 - v], i * 2);
					indexRow.push(i++);
				}
				indexArray.push(indexRow);
			}
			for (x = 0; x < rSegs; x++) for (y = 0; y < hSegs; y++) {
				const a = indexArray[y][x];
				const b = indexArray[y + 1][x];
				const c = indexArray[y + 1][x + 1];
				const d = indexArray[y][x + 1];
				index.set([
					a,
					b,
					d,
					b,
					c,
					d
				], ii * 3);
				ii += 2;
			}
		}
		function addCap(isTop) {
			let x;
			const r = isTop === true ? radiusTop : radiusBottom;
			const sign = isTop === true ? 1 : -1;
			const centerIndex = i;
			position.set([
				0,
				.5 * height * sign,
				0
			], i * 3);
			normal.set([
				0,
				sign,
				0
			], i * 3);
			uv.set([.5, .5], i * 2);
			i++;
			for (x = 0; x <= rSegs; x++) {
				const theta = x / rSegs * tLength + tStart;
				const cosTheta = Math.cos(theta);
				const sinTheta = Math.sin(theta);
				position.set([
					r * sinTheta,
					.5 * height * sign,
					r * cosTheta
				], i * 3);
				normal.set([
					0,
					sign,
					0
				], i * 3);
				uv.set([cosTheta * .5 + .5, sinTheta * .5 * sign + .5], i * 2);
				i++;
			}
			for (x = 0; x < rSegs; x++) {
				const j = centerIndex + x + 1;
				if (isTop) index.set([
					j,
					j + 1,
					centerIndex
				], ii * 3);
				else index.set([
					j + 1,
					j,
					centerIndex
				], ii * 3);
				ii++;
			}
		}
		Object.assign(attributes, {
			position: {
				size: 3,
				data: position
			},
			normal: {
				size: 3,
				data: normal
			},
			uv: {
				size: 2,
				data: uv
			},
			index: { data: index }
		});
		super(gl, attributes);
	}
};
//#endregion
//#region node_modules/ogl/src/extras/Triangle.js
var Triangle = class extends Geometry {
	constructor(gl, { attributes = {} } = {}) {
		Object.assign(attributes, {
			position: {
				size: 2,
				data: new Float32Array([
					-1,
					-1,
					3,
					-1,
					-1,
					3
				])
			},
			uv: {
				size: 2,
				data: new Float32Array([
					0,
					0,
					2,
					0,
					0,
					2
				])
			}
		});
		super(gl, attributes);
	}
};
//#endregion
//#region node_modules/ogl/src/extras/Torus.js
var Torus = class extends Geometry {
	constructor(gl, { radius = .5, tube = .2, radialSegments = 8, tubularSegments = 6, arc = Math.PI * 2, attributes = {} } = {}) {
		const num = (radialSegments + 1) * (tubularSegments + 1);
		const numIndices = radialSegments * tubularSegments * 6;
		const vertices = new Float32Array(num * 3);
		const normals = new Float32Array(num * 3);
		const uvs = new Float32Array(num * 2);
		const indices = num > 65536 ? new Uint32Array(numIndices) : new Uint16Array(numIndices);
		const center = new Vec3();
		const vertex = new Vec3();
		const normal = new Vec3();
		let idx = 0;
		for (let j = 0; j <= radialSegments; j++) for (let i = 0; i <= tubularSegments; i++, idx++) {
			const u = i / tubularSegments * arc;
			const v = j / radialSegments * Math.PI * 2;
			vertex.x = (radius + tube * Math.cos(v)) * Math.cos(u);
			vertex.y = (radius + tube * Math.cos(v)) * Math.sin(u);
			vertex.z = tube * Math.sin(v);
			vertices.set([
				vertex.x,
				vertex.y,
				vertex.z
			], idx * 3);
			center.x = radius * Math.cos(u);
			center.y = radius * Math.sin(u);
			normal.sub(vertex, center).normalize();
			normals.set([
				normal.x,
				normal.y,
				normal.z
			], idx * 3);
			uvs.set([i / tubularSegments, j / radialSegments], idx * 2);
		}
		idx = 0;
		for (let j = 1; j <= radialSegments; j++) for (let i = 1; i <= tubularSegments; i++, idx++) {
			const a = (tubularSegments + 1) * j + i - 1;
			const b = (tubularSegments + 1) * (j - 1) + i - 1;
			const c = (tubularSegments + 1) * (j - 1) + i;
			const d = (tubularSegments + 1) * j + i;
			indices.set([
				a,
				b,
				d,
				b,
				c,
				d
			], idx * 6);
		}
		Object.assign(attributes, {
			position: {
				size: 3,
				data: vertices
			},
			normal: {
				size: 3,
				data: normals
			},
			uv: {
				size: 2,
				data: uvs
			},
			index: { data: indices }
		});
		super(gl, attributes);
	}
};
//#endregion
//#region node_modules/ogl/src/extras/Orbit.js
var STATE = {
	NONE: -1,
	ROTATE: 0,
	DOLLY: 1,
	PAN: 2,
	DOLLY_PAN: 3
};
var tempVec3$4 = /* @__PURE__ */ new Vec3();
var tempVec2a$1 = /* @__PURE__ */ new Vec2();
var tempVec2b$1 = /* @__PURE__ */ new Vec2();
function Orbit(object, { element = document, enabled = true, target = new Vec3(), ease = .25, inertia = .85, enableRotate = true, rotateSpeed = .1, autoRotate = false, autoRotateSpeed = 1, enableZoom = true, zoomSpeed = 1, zoomStyle = "dolly", enablePan = true, panSpeed = .1, minPolarAngle = 0, maxPolarAngle = Math.PI, minAzimuthAngle = -Infinity, maxAzimuthAngle = Infinity, minDistance = 0, maxDistance = Infinity } = {}) {
	this.enabled = enabled;
	this.target = target;
	this.zoomStyle = zoomStyle;
	ease = ease || 1;
	inertia = inertia || 0;
	this.minDistance = minDistance;
	this.maxDistance = maxDistance;
	const sphericalDelta = {
		radius: 1,
		phi: 0,
		theta: 0
	};
	const sphericalTarget = {
		radius: 1,
		phi: 0,
		theta: 0
	};
	const spherical = {
		radius: 1,
		phi: 0,
		theta: 0
	};
	const panDelta = new Vec3();
	const offset = new Vec3();
	offset.copy(object.position).sub(this.target);
	spherical.radius = sphericalTarget.radius = offset.distance();
	spherical.theta = sphericalTarget.theta = Math.atan2(offset.x, offset.z);
	spherical.phi = sphericalTarget.phi = Math.acos(Math.min(Math.max(offset.y / sphericalTarget.radius, -1), 1));
	this.offset = offset;
	this.update = () => {
		if (autoRotate) handleAutoRotate();
		sphericalTarget.radius *= sphericalDelta.radius;
		sphericalTarget.theta += sphericalDelta.theta;
		sphericalTarget.phi += sphericalDelta.phi;
		sphericalTarget.theta = Math.max(minAzimuthAngle, Math.min(maxAzimuthAngle, sphericalTarget.theta));
		sphericalTarget.phi = Math.max(minPolarAngle, Math.min(maxPolarAngle, sphericalTarget.phi));
		sphericalTarget.radius = Math.max(this.minDistance, Math.min(this.maxDistance, sphericalTarget.radius));
		spherical.phi += (sphericalTarget.phi - spherical.phi) * ease;
		spherical.theta += (sphericalTarget.theta - spherical.theta) * ease;
		spherical.radius += (sphericalTarget.radius - spherical.radius) * ease;
		this.target.add(panDelta);
		let sinPhiRadius = spherical.radius * Math.sin(Math.max(1e-6, spherical.phi));
		offset.x = sinPhiRadius * Math.sin(spherical.theta);
		offset.y = spherical.radius * Math.cos(spherical.phi);
		offset.z = sinPhiRadius * Math.cos(spherical.theta);
		object.position.copy(this.target).add(offset);
		object.lookAt(this.target);
		sphericalDelta.theta *= inertia;
		sphericalDelta.phi *= inertia;
		panDelta.multiply(inertia);
		sphericalDelta.radius = 1;
	};
	this.forcePosition = () => {
		offset.copy(object.position).sub(this.target);
		spherical.radius = sphericalTarget.radius = offset.distance();
		spherical.theta = sphericalTarget.theta = Math.atan2(offset.x, offset.z);
		spherical.phi = sphericalTarget.phi = Math.acos(Math.min(Math.max(offset.y / sphericalTarget.radius, -1), 1));
		object.lookAt(this.target);
	};
	const rotateStart = new Vec2();
	const panStart = new Vec2();
	const dollyStart = new Vec2();
	let state = STATE.NONE;
	this.mouseButtons = {
		ORBIT: 0,
		ZOOM: 1,
		PAN: 2
	};
	function getZoomScale() {
		return Math.pow(.95, zoomSpeed);
	}
	function panLeft(distance, m) {
		tempVec3$4.set(m[0], m[1], m[2]);
		tempVec3$4.multiply(-distance);
		panDelta.add(tempVec3$4);
	}
	function panUp(distance, m) {
		tempVec3$4.set(m[4], m[5], m[6]);
		tempVec3$4.multiply(distance);
		panDelta.add(tempVec3$4);
	}
	const pan = (deltaX, deltaY) => {
		let el = element === document ? document.body : element;
		tempVec3$4.copy(object.position).sub(this.target);
		let targetDistance = tempVec3$4.distance();
		targetDistance *= Math.tan((object.fov || 45) / 2 * Math.PI / 180);
		panLeft(2 * deltaX * targetDistance / el.clientHeight, object.matrix);
		panUp(2 * deltaY * targetDistance / el.clientHeight, object.matrix);
	};
	const dolly = (dollyScale) => {
		if (this.zoomStyle === "dolly") sphericalDelta.radius /= dollyScale;
		else {
			object.fov /= dollyScale;
			if (object.type === "orthographic") object.orthographic();
			else object.perspective();
		}
	};
	function handleAutoRotate() {
		const angle = 2 * Math.PI / 60 / 60 * autoRotateSpeed;
		sphericalDelta.theta -= angle;
	}
	function handleMoveRotate(x, y) {
		tempVec2a$1.set(x, y);
		tempVec2b$1.sub(tempVec2a$1, rotateStart).multiply(rotateSpeed);
		let el = element === document ? document.body : element;
		sphericalDelta.theta -= 2 * Math.PI * tempVec2b$1.x / el.clientHeight;
		sphericalDelta.phi -= 2 * Math.PI * tempVec2b$1.y / el.clientHeight;
		rotateStart.copy(tempVec2a$1);
	}
	function handleMouseMoveDolly(e) {
		tempVec2a$1.set(e.clientX, e.clientY);
		tempVec2b$1.sub(tempVec2a$1, dollyStart);
		if (tempVec2b$1.y > 0) dolly(getZoomScale());
		else if (tempVec2b$1.y < 0) dolly(1 / getZoomScale());
		dollyStart.copy(tempVec2a$1);
	}
	function handleMovePan(x, y) {
		tempVec2a$1.set(x, y);
		tempVec2b$1.sub(tempVec2a$1, panStart).multiply(panSpeed);
		pan(tempVec2b$1.x, tempVec2b$1.y);
		panStart.copy(tempVec2a$1);
	}
	function handleTouchStartDollyPan(e) {
		if (enableZoom) {
			let dx = e.touches[0].pageX - e.touches[1].pageX;
			let dy = e.touches[0].pageY - e.touches[1].pageY;
			let distance = Math.sqrt(dx * dx + dy * dy);
			dollyStart.set(0, distance);
		}
		if (enablePan) {
			let x = .5 * (e.touches[0].pageX + e.touches[1].pageX);
			let y = .5 * (e.touches[0].pageY + e.touches[1].pageY);
			panStart.set(x, y);
		}
	}
	function handleTouchMoveDollyPan(e) {
		if (enableZoom) {
			let dx = e.touches[0].pageX - e.touches[1].pageX;
			let dy = e.touches[0].pageY - e.touches[1].pageY;
			let distance = Math.sqrt(dx * dx + dy * dy);
			tempVec2a$1.set(0, distance);
			tempVec2b$1.set(0, Math.pow(tempVec2a$1.y / dollyStart.y, zoomSpeed));
			dolly(tempVec2b$1.y);
			dollyStart.copy(tempVec2a$1);
		}
		if (enablePan) handleMovePan(.5 * (e.touches[0].pageX + e.touches[1].pageX), .5 * (e.touches[0].pageY + e.touches[1].pageY));
	}
	const onMouseDown = (e) => {
		if (!this.enabled) return;
		switch (e.button) {
			case this.mouseButtons.ORBIT:
				if (enableRotate === false) return;
				rotateStart.set(e.clientX, e.clientY);
				state = STATE.ROTATE;
				break;
			case this.mouseButtons.ZOOM:
				if (enableZoom === false) return;
				dollyStart.set(e.clientX, e.clientY);
				state = STATE.DOLLY;
				break;
			case this.mouseButtons.PAN:
				if (enablePan === false) return;
				panStart.set(e.clientX, e.clientY);
				state = STATE.PAN;
		}
		if (state !== STATE.NONE) {
			window.addEventListener("mousemove", onMouseMove, false);
			window.addEventListener("mouseup", onMouseUp, false);
		}
	};
	const onMouseMove = (e) => {
		if (!this.enabled) return;
		switch (state) {
			case STATE.ROTATE:
				if (enableRotate === false) return;
				handleMoveRotate(e.clientX, e.clientY);
				break;
			case STATE.DOLLY:
				if (enableZoom === false) return;
				handleMouseMoveDolly(e);
				break;
			case STATE.PAN:
				if (enablePan === false) return;
				handleMovePan(e.clientX, e.clientY);
		}
	};
	const onMouseUp = () => {
		window.removeEventListener("mousemove", onMouseMove, false);
		window.removeEventListener("mouseup", onMouseUp, false);
		state = STATE.NONE;
	};
	const onMouseWheel = (e) => {
		if (!this.enabled || !enableZoom || state !== STATE.NONE && state !== STATE.ROTATE) return;
		e.stopPropagation();
		e.preventDefault();
		if (e.deltaY < 0) dolly(1 / getZoomScale());
		else if (e.deltaY > 0) dolly(getZoomScale());
	};
	const onTouchStart = (e) => {
		if (!this.enabled) return;
		e.preventDefault();
		switch (e.touches.length) {
			case 1:
				if (enableRotate === false) return;
				rotateStart.set(e.touches[0].pageX, e.touches[0].pageY);
				state = STATE.ROTATE;
				break;
			case 2:
				if (enableZoom === false && enablePan === false) return;
				handleTouchStartDollyPan(e);
				state = STATE.DOLLY_PAN;
				break;
			default: state = STATE.NONE;
		}
	};
	const onTouchMove = (e) => {
		if (!this.enabled) return;
		e.preventDefault();
		e.stopPropagation();
		switch (e.touches.length) {
			case 1:
				if (enableRotate === false) return;
				handleMoveRotate(e.touches[0].pageX, e.touches[0].pageY);
				break;
			case 2:
				if (enableZoom === false && enablePan === false) return;
				handleTouchMoveDollyPan(e);
				break;
			default: state = STATE.NONE;
		}
	};
	const onTouchEnd = () => {
		if (!this.enabled) return;
		state = STATE.NONE;
	};
	const onContextMenu = (e) => {
		if (!this.enabled) return;
		e.preventDefault();
	};
	function addHandlers() {
		element.addEventListener("contextmenu", onContextMenu, false);
		element.addEventListener("mousedown", onMouseDown, false);
		element.addEventListener("wheel", onMouseWheel, { passive: false });
		element.addEventListener("touchstart", onTouchStart, { passive: false });
		element.addEventListener("touchend", onTouchEnd, false);
		element.addEventListener("touchmove", onTouchMove, { passive: false });
	}
	this.remove = function() {
		element.removeEventListener("contextmenu", onContextMenu);
		element.removeEventListener("mousedown", onMouseDown);
		element.removeEventListener("wheel", onMouseWheel);
		element.removeEventListener("touchstart", onTouchStart);
		element.removeEventListener("touchend", onTouchEnd);
		element.removeEventListener("touchmove", onTouchMove);
		window.removeEventListener("mousemove", onMouseMove);
		window.removeEventListener("mouseup", onMouseUp);
	};
	addHandlers();
}
//#endregion
//#region node_modules/ogl/src/extras/Raycast.js
var tempVec2a = /* @__PURE__ */ new Vec2();
var tempVec2b = /* @__PURE__ */ new Vec2();
var tempVec2c = /* @__PURE__ */ new Vec2();
var tempVec3a = /* @__PURE__ */ new Vec3();
var tempVec3b = /* @__PURE__ */ new Vec3();
var tempVec3c = /* @__PURE__ */ new Vec3();
var tempVec3d = /* @__PURE__ */ new Vec3();
var tempVec3e = /* @__PURE__ */ new Vec3();
var tempVec3f = /* @__PURE__ */ new Vec3();
var tempVec3g = /* @__PURE__ */ new Vec3();
var tempVec3h = /* @__PURE__ */ new Vec3();
var tempVec3i = /* @__PURE__ */ new Vec3();
var tempVec3j = /* @__PURE__ */ new Vec3();
var tempVec3k = /* @__PURE__ */ new Vec3();
var tempMat4$3 = /* @__PURE__ */ new Mat4();
var Raycast = class {
	constructor() {
		this.origin = new Vec3();
		this.direction = new Vec3();
	}
	castMouse(camera, mouse = [0, 0]) {
		if (camera.type === "orthographic") {
			const { left, right, bottom, top, zoom } = camera;
			const x = left / zoom + (right - left) / zoom * (mouse[0] * .5 + .5);
			const y = bottom / zoom + (top - bottom) / zoom * (mouse[1] * .5 + .5);
			this.origin.set(x, y, 0);
			this.origin.applyMatrix4(camera.worldMatrix);
			this.direction.x = -camera.worldMatrix[8];
			this.direction.y = -camera.worldMatrix[9];
			this.direction.z = -camera.worldMatrix[10];
		} else {
			camera.worldMatrix.getTranslation(this.origin);
			this.direction.set(mouse[0], mouse[1], .5);
			camera.unproject(this.direction);
			this.direction.sub(this.origin).normalize();
		}
	}
	intersectBounds(meshes, { maxDistance, output = [] } = {}) {
		if (!Array.isArray(meshes)) meshes = [meshes];
		const invWorldMat4 = tempMat4$3;
		const origin = tempVec3a;
		const direction = tempVec3b;
		const hits = output;
		hits.length = 0;
		meshes.forEach((mesh) => {
			if (!mesh.geometry.bounds || mesh.geometry.bounds.radius === Infinity) mesh.geometry.computeBoundingSphere();
			const bounds = mesh.geometry.bounds;
			invWorldMat4.inverse(mesh.worldMatrix);
			let localMaxDistance;
			if (maxDistance) {
				direction.copy(this.direction).scaleRotateMatrix4(invWorldMat4);
				localMaxDistance = maxDistance * direction.len();
			}
			origin.copy(this.origin).applyMatrix4(invWorldMat4);
			direction.copy(this.direction).transformDirection(invWorldMat4);
			if (maxDistance) {
				if (origin.distance(bounds.center) - bounds.radius > localMaxDistance) return;
			}
			let localDistance = 0;
			if (mesh.geometry.raycast === "sphere") {
				if (origin.distance(bounds.center) > bounds.radius) {
					localDistance = this.intersectSphere(bounds, origin, direction);
					if (!localDistance) return;
				}
			} else if (origin.x < bounds.min.x || origin.x > bounds.max.x || origin.y < bounds.min.y || origin.y > bounds.max.y || origin.z < bounds.min.z || origin.z > bounds.max.z) {
				localDistance = this.intersectBox(bounds, origin, direction);
				if (!localDistance) return;
			}
			if (maxDistance && localDistance > localMaxDistance) return;
			if (!mesh.hit) mesh.hit = {
				localPoint: new Vec3(),
				point: new Vec3()
			};
			mesh.hit.localPoint.copy(direction).multiply(localDistance).add(origin);
			mesh.hit.point.copy(mesh.hit.localPoint).applyMatrix4(mesh.worldMatrix);
			mesh.hit.distance = mesh.hit.point.distance(this.origin);
			hits.push(mesh);
		});
		hits.sort((a, b) => a.hit.distance - b.hit.distance);
		return hits;
	}
	intersectMeshes(meshes, { cullFace = true, maxDistance, includeUV = true, includeNormal = true, output = [] } = {}) {
		const hits = this.intersectBounds(meshes, {
			maxDistance,
			output
		});
		if (!hits.length) return hits;
		const invWorldMat4 = tempMat4$3;
		const origin = tempVec3a;
		const direction = tempVec3b;
		const a = tempVec3c;
		const b = tempVec3d;
		const c = tempVec3e;
		const closestFaceNormal = tempVec3f;
		const faceNormal = tempVec3g;
		const barycoord = tempVec3h;
		const uvA = tempVec2a;
		const uvB = tempVec2b;
		const uvC = tempVec2c;
		for (let i = hits.length - 1; i >= 0; i--) {
			const mesh = hits[i];
			invWorldMat4.inverse(mesh.worldMatrix);
			let localMaxDistance;
			if (maxDistance) {
				direction.copy(this.direction).scaleRotateMatrix4(invWorldMat4);
				localMaxDistance = maxDistance * direction.len();
			}
			origin.copy(this.origin).applyMatrix4(invWorldMat4);
			direction.copy(this.direction).transformDirection(invWorldMat4);
			let localDistance = 0;
			let closestA, closestB, closestC;
			const geometry = mesh.geometry;
			const attributes = geometry.attributes;
			const index = attributes.index;
			const position = attributes.position;
			const start = Math.max(0, geometry.drawRange.start);
			const end = Math.min(index ? index.count : position.count, geometry.drawRange.start + geometry.drawRange.count);
			const stride = position.size;
			for (let j = start; j < end; j += 3) {
				const ai = index ? index.data[j] : j;
				const bi = index ? index.data[j + 1] : j + 1;
				const ci = index ? index.data[j + 2] : j + 2;
				a.fromArray(position.data, ai * stride);
				b.fromArray(position.data, bi * stride);
				c.fromArray(position.data, ci * stride);
				const distance = this.intersectTriangle(a, b, c, cullFace, origin, direction, faceNormal);
				if (!distance) continue;
				if (maxDistance && distance > localMaxDistance) continue;
				if (!localDistance || distance < localDistance) {
					localDistance = distance;
					closestA = ai;
					closestB = bi;
					closestC = ci;
					closestFaceNormal.copy(faceNormal);
				}
			}
			if (!localDistance) hits.splice(i, 1);
			mesh.hit.localPoint.copy(direction).multiply(localDistance).add(origin);
			mesh.hit.point.copy(mesh.hit.localPoint).applyMatrix4(mesh.worldMatrix);
			mesh.hit.distance = mesh.hit.point.distance(this.origin);
			if (!mesh.hit.faceNormal) {
				mesh.hit.localFaceNormal = new Vec3();
				mesh.hit.faceNormal = new Vec3();
				mesh.hit.uv = new Vec2();
				mesh.hit.localNormal = new Vec3();
				mesh.hit.normal = new Vec3();
			}
			mesh.hit.localFaceNormal.copy(closestFaceNormal);
			mesh.hit.faceNormal.copy(mesh.hit.localFaceNormal).transformDirection(mesh.worldMatrix);
			if (includeUV || includeNormal) {
				a.fromArray(position.data, closestA * 3);
				b.fromArray(position.data, closestB * 3);
				c.fromArray(position.data, closestC * 3);
				this.getBarycoord(mesh.hit.localPoint, a, b, c, barycoord);
			}
			if (includeUV && attributes.uv) {
				uvA.fromArray(attributes.uv.data, closestA * 2);
				uvB.fromArray(attributes.uv.data, closestB * 2);
				uvC.fromArray(attributes.uv.data, closestC * 2);
				mesh.hit.uv.set(uvA.x * barycoord.x + uvB.x * barycoord.y + uvC.x * barycoord.z, uvA.y * barycoord.x + uvB.y * barycoord.y + uvC.y * barycoord.z);
			}
			if (includeNormal && attributes.normal) {
				a.fromArray(attributes.normal.data, closestA * 3);
				b.fromArray(attributes.normal.data, closestB * 3);
				c.fromArray(attributes.normal.data, closestC * 3);
				mesh.hit.localNormal.set(a.x * barycoord.x + b.x * barycoord.y + c.x * barycoord.z, a.y * barycoord.x + b.y * barycoord.y + c.y * barycoord.z, a.z * barycoord.x + b.z * barycoord.y + c.z * barycoord.z);
				mesh.hit.normal.copy(mesh.hit.localNormal).transformDirection(mesh.worldMatrix);
			}
		}
		hits.sort((a, b) => a.hit.distance - b.hit.distance);
		return hits;
	}
	intersectPlane(plane, origin = this.origin, direction = this.direction) {
		const xminp = tempVec3a;
		xminp.sub(plane.origin, origin);
		const a = xminp.dot(plane.normal);
		const b = direction.dot(plane.normal);
		if (b == 0) return 0;
		const delta = a / b;
		if (delta <= 0) return 0;
		return origin.add(direction.scale(delta));
	}
	intersectSphere(sphere, origin = this.origin, direction = this.direction) {
		const ray = tempVec3c;
		ray.sub(sphere.center, origin);
		const tca = ray.dot(direction);
		const d2 = ray.dot(ray) - tca * tca;
		const radius2 = sphere.radius * sphere.radius;
		if (d2 > radius2) return 0;
		const thc = Math.sqrt(radius2 - d2);
		const t0 = tca - thc;
		const t1 = tca + thc;
		if (t0 < 0 && t1 < 0) return 0;
		if (t0 < 0) return t1;
		return t0;
	}
	intersectBox(box, origin = this.origin, direction = this.direction) {
		let tmin, tmax, tYmin, tYmax, tZmin, tZmax;
		const invdirx = 1 / direction.x;
		const invdiry = 1 / direction.y;
		const invdirz = 1 / direction.z;
		const min = box.min;
		const max = box.max;
		tmin = ((invdirx >= 0 ? min.x : max.x) - origin.x) * invdirx;
		tmax = ((invdirx >= 0 ? max.x : min.x) - origin.x) * invdirx;
		tYmin = ((invdiry >= 0 ? min.y : max.y) - origin.y) * invdiry;
		tYmax = ((invdiry >= 0 ? max.y : min.y) - origin.y) * invdiry;
		if (tmin > tYmax || tYmin > tmax) return 0;
		if (tYmin > tmin) tmin = tYmin;
		if (tYmax < tmax) tmax = tYmax;
		tZmin = ((invdirz >= 0 ? min.z : max.z) - origin.z) * invdirz;
		tZmax = ((invdirz >= 0 ? max.z : min.z) - origin.z) * invdirz;
		if (tmin > tZmax || tZmin > tmax) return 0;
		if (tZmin > tmin) tmin = tZmin;
		if (tZmax < tmax) tmax = tZmax;
		if (tmax < 0) return 0;
		return tmin >= 0 ? tmin : tmax;
	}
	intersectTriangle(a, b, c, backfaceCulling = true, origin = this.origin, direction = this.direction, normal = tempVec3g) {
		const edge1 = tempVec3h;
		const edge2 = tempVec3i;
		const diff = tempVec3j;
		edge1.sub(b, a);
		edge2.sub(c, a);
		normal.cross(edge1, edge2);
		let DdN = direction.dot(normal);
		if (!DdN) return 0;
		let sign;
		if (DdN > 0) {
			if (backfaceCulling) return 0;
			sign = 1;
		} else {
			sign = -1;
			DdN = -DdN;
		}
		diff.sub(origin, a);
		let DdQxE2 = sign * direction.dot(edge2.cross(diff, edge2));
		if (DdQxE2 < 0) return 0;
		let DdE1xQ = sign * direction.dot(edge1.cross(diff));
		if (DdE1xQ < 0) return 0;
		if (DdQxE2 + DdE1xQ > DdN) return 0;
		let QdN = -sign * diff.dot(normal);
		if (QdN < 0) return 0;
		return QdN / DdN;
	}
	getBarycoord(point, a, b, c, target = tempVec3h) {
		const v0 = tempVec3i;
		const v1 = tempVec3j;
		const v2 = tempVec3k;
		v0.sub(c, a);
		v1.sub(b, a);
		v2.sub(point, a);
		const dot00 = v0.dot(v0);
		const dot01 = v0.dot(v1);
		const dot02 = v0.dot(v2);
		const dot11 = v1.dot(v1);
		const dot12 = v1.dot(v2);
		const denom = dot00 * dot11 - dot01 * dot01;
		if (denom === 0) return target.set(-2, -1, -1);
		const invDenom = 1 / denom;
		const u = (dot11 * dot02 - dot01 * dot12) * invDenom;
		const v = (dot00 * dot12 - dot01 * dot02) * invDenom;
		return target.set(1 - u - v, v, u);
	}
};
//#endregion
//#region node_modules/ogl/src/extras/Curve.js
var CATMULLROM = "catmullrom";
var CUBICBEZIER = "cubicbezier";
var QUADRATICBEZIER = "quadraticbezier";
var _a0 = /* @__PURE__ */ new Vec3();
var _a1 = /* @__PURE__ */ new Vec3();
var _a2 = /* @__PURE__ */ new Vec3();
var _a3 = /* @__PURE__ */ new Vec3();
/**
* Get the control points of cubic bezier curve.
* @param {*} i
* @param {*} a
* @param {*} b
*/
function getCtrlPoint(points, i, a = .168, b = .168) {
	if (i < 1) _a0.sub(points[1], points[0]).scale(a).add(points[0]);
	else _a0.sub(points[i + 1], points[i - 1]).scale(a).add(points[i]);
	if (i > points.length - 3) {
		const last = points.length - 1;
		_a1.sub(points[last - 1], points[last]).scale(b).add(points[last]);
	} else _a1.sub(points[i], points[i + 2]).scale(b).add(points[i + 1]);
	return [_a0.clone(), _a1.clone()];
}
function getQuadraticBezierPoint(t, p0, c0, p1) {
	const k = 1 - t;
	_a0.copy(p0).scale(k ** 2);
	_a1.copy(c0).scale(2 * k * t);
	_a2.copy(p1).scale(t ** 2);
	const ret = new Vec3();
	ret.add(_a0, _a1).add(_a2);
	return ret;
}
function getCubicBezierPoint(t, p0, c0, c1, p1) {
	const k = 1 - t;
	_a0.copy(p0).scale(k ** 3);
	_a1.copy(c0).scale(3 * k ** 2 * t);
	_a2.copy(c1).scale(3 * k * t ** 2);
	_a3.copy(p1).scale(t ** 3);
	const ret = new Vec3();
	ret.add(_a0, _a1).add(_a2).add(_a3);
	return ret;
}
var Curve = class Curve {
	constructor({ points = [
		new Vec3(0, 0, 0),
		new Vec3(0, 1, 0),
		new Vec3(1, 1, 0),
		new Vec3(1, 0, 0)
	], divisions = 12, type = CATMULLROM } = {}) {
		this.points = points;
		this.divisions = divisions;
		this.type = type;
	}
	_getQuadraticBezierPoints(divisions = this.divisions) {
		const points = [];
		const count = this.points.length;
		if (count < 3) {
			console.warn("Not enough points provided.");
			return [];
		}
		const p0 = this.points[0];
		let c0 = this.points[1], p1 = this.points[2];
		for (let i = 0; i <= divisions; i++) {
			const p = getQuadraticBezierPoint(i / divisions, p0, c0, p1);
			points.push(p);
		}
		let offset = 3;
		while (count - offset > 0) {
			p0.copy(p1);
			c0 = p1.scale(2).sub(c0);
			p1 = this.points[offset];
			for (let i = 1; i <= divisions; i++) {
				const p = getQuadraticBezierPoint(i / divisions, p0, c0, p1);
				points.push(p);
			}
			offset++;
		}
		return points;
	}
	_getCubicBezierPoints(divisions = this.divisions) {
		const points = [];
		const count = this.points.length;
		if (count < 4) {
			console.warn("Not enough points provided.");
			return [];
		}
		let p0 = this.points[0], c0 = this.points[1], c1 = this.points[2], p1 = this.points[3];
		for (let i = 0; i <= divisions; i++) {
			const p = getCubicBezierPoint(i / divisions, p0, c0, c1, p1);
			points.push(p);
		}
		let offset = 4;
		while (count - offset > 1) {
			p0.copy(p1);
			c0 = p1.scale(2).sub(c1);
			c1 = this.points[offset];
			p1 = this.points[offset + 1];
			for (let i = 1; i <= divisions; i++) {
				const p = getCubicBezierPoint(i / divisions, p0, c0, c1, p1);
				points.push(p);
			}
			offset += 2;
		}
		return points;
	}
	_getCatmullRomPoints(divisions = this.divisions, a = .168, b = .168) {
		const points = [];
		if (this.points.length <= 2) return this.points;
		let p0;
		this.points.forEach((p, i) => {
			if (i === 0) p0 = p;
			else {
				const [c0, c1] = getCtrlPoint(this.points, i - 1, a, b);
				const c = new Curve({
					points: [
						p0,
						c0,
						c1,
						p
					],
					type: CUBICBEZIER
				});
				points.pop();
				points.push(...c.getPoints(divisions));
				p0 = p;
			}
		});
		return points;
	}
	getPoints(divisions = this.divisions, a = .168, b = .168) {
		const type = this.type;
		if (type === QUADRATICBEZIER) return this._getQuadraticBezierPoints(divisions);
		if (type === CUBICBEZIER) return this._getCubicBezierPoints(divisions);
		if (type === CATMULLROM) return this._getCatmullRomPoints(divisions, a, b);
		return this.points;
	}
};
Curve.CATMULLROM = CATMULLROM;
Curve.CUBICBEZIER = CUBICBEZIER;
Curve.QUADRATICBEZIER = QUADRATICBEZIER;
//#endregion
//#region node_modules/ogl/src/extras/path/BaseSegment.js
/**
* Abstract base class for path segments.
* This class contains common methods for all segments types.
*/
var BaseSegment = class {
	constructor() {
		this._len = -1;
		this.tiltStart = 0;
		this.tiltEnd = 0;
	}
	/**
	* Get segment length.
	* @returns {number} segment length
	*/
	getLength() {
		if (this._len < 0) this.updateLength();
		return this._len;
	}
	/**
	* Get tilt angle at t
	* @param {number} t Distance at time t in range [0 .. 1]
	* @returns {number} Tilt angle at t
	*/
	getTiltAt(t) {
		return this.tiltStart * (1 - t) * this.tiltEnd * t;
	}
	/**
	* Creates a clone of this instance
	* @returns {BaseSegment} cloned instance
	*/
	clone() {
		return new this.constructor().copy(this);
	}
	/**
	* Copies another segment object to this instance.
	* @param {BaseSegment} source reference object
	* @returns {BaseSegment} copy of source object
	*/
	copy(source) {
		this._len = source._len;
		this.tiltStart = source.tiltStart;
		this.tiltEnd = source.tiltEnd;
		return this;
	}
};
//#endregion
//#region node_modules/ogl/src/extras/path/utils.js
var T_VALUES = [
	-.06405689286260563,
	.06405689286260563,
	-.1911188674736163,
	.1911188674736163,
	-.3150426796961634,
	.3150426796961634,
	-.4337935076260451,
	.4337935076260451,
	-.5454214713888396,
	.5454214713888396,
	-.6480936519369755,
	.6480936519369755,
	-.7401241915785544,
	.7401241915785544,
	-.820001985973903,
	.820001985973903,
	-.8864155270044011,
	.8864155270044011,
	-.9382745520027328,
	.9382745520027328,
	-.9747285559713095,
	.9747285559713095,
	-.9951872199970213,
	.9951872199970213
];
var C_VALUES = [
	.12793819534675216,
	.12793819534675216,
	.1258374563468283,
	.1258374563468283,
	.12167047292780339,
	.12167047292780339,
	.1155056680537256,
	.1155056680537256,
	.10744427011596563,
	.10744427011596563,
	.09761865210411388,
	.09761865210411388,
	.08619016153195327,
	.08619016153195327,
	.0733464814110803,
	.0733464814110803,
	.05929858491543678,
	.05929858491543678,
	.04427743881741981,
	.04427743881741981,
	.028531388628933663,
	.028531388628933663,
	.0123412297999872,
	.0123412297999872
];
/**
* Convert Degree To Radian
* @param {number} a Angle in Degrees
* @returns {number} a Angle in Radians
*/
var toRadian = (a) => a * Math.PI / 180;
/**
* Convert Radian To Degree
* @param {number} a Angle in Radians
* @returns {number} a Angle in Radian
*/
var toDegrees = (a) => 180 * a / Math.PI;
var clamp = (val, min, max) => Math.max(min, Math.min(val, max));
/**
* Fills a rotation matrix with the given sine and cosine of the angle around the given axis
* This function helps to avoid inverse trigonometry
* @param {Mat4} out mat4 receiving operation result
* @param {Vec3} axis the axis to rotate around. Should be normalized
* @param {number} sin sine of rotation angle
* @param {number} cos cosine of rotation angle
* @returns {Mat4} out
*/
function mat4fromRotationSinCos(out, axis, sin, cos) {
	const x = axis[0];
	const y = axis[1];
	const z = axis[2];
	const t = 1 - cos;
	out[0] = x * x * t + cos;
	out[1] = y * x * t + z * sin;
	out[2] = z * x * t - y * sin;
	out[3] = 0;
	out[4] = x * y * t - z * sin;
	out[5] = y * y * t + cos;
	out[6] = z * y * t + x * sin;
	out[7] = 0;
	out[8] = x * z * t + y * sin;
	out[9] = y * z * t - x * sin;
	out[10] = z * z * t + cos;
	out[11] = 0;
	out[12] = 0;
	out[13] = 0;
	out[14] = 0;
	out[15] = 1;
	return out;
}
/**
* Rotates the normal and binormal around its tangent by the given angle.
*
* see: https://en.wikipedia.org/wiki/Rodrigues%27_rotation_formula
* @param {number} angle rotation angle
* @param {Vec3} norm unit normal vector
* @param {Vec3} binorm unit binormal vector
* @param {Vec3} outNorm optional normal output vector. If not present then normal vector changes in place
* @param {Vec3} outBinorm optional binormal output vector. If not present then binormal vector changes in place
*/
function rotateNormalBinormal(angle, norm, binorm, outNorm = norm, outBinorm = binorm) {
	const s = Math.sin(angle);
	const c = Math.cos(angle);
	const nx = c * norm.x + s * binorm.x;
	const ny = c * norm.y + s * binorm.y;
	const nz = c * norm.z + s * binorm.z;
	const bx = c * binorm.x - s * norm.x;
	const by = c * binorm.y - s * norm.y;
	const bz = c * binorm.z - s * norm.z;
	outNorm.set(nx, ny, nz);
	outBinorm.set(bx, by, bz);
}
//#endregion
//#region node_modules/ogl/src/extras/path/CubicBezierSegment.js
var tempVec3$3 = /* @__PURE__ */ new Vec3();
function cubicBezier(t, p0, p1, p2, p3) {
	const k = 1 - t;
	return k * k * k * p0 + 3 * k * k * t * p1 + 3 * k * t * t * p2 + t * t * t * p3;
}
function cubicBezierDeriv(t, p0, p1, p2, p3) {
	const k = 1 - t;
	return 3 * k * k * (p1 - p0) + 6 * k * t * (p2 - p1) + 3 * t * t * (p3 - p2);
}
var CubicBezierSegment = class extends BaseSegment {
	constructor(p0, p1, p2, p3, tiltStart = 0, tiltEnd = 0) {
		super();
		this.p0 = p0;
		this.p1 = p1;
		this.p2 = p2;
		this.p3 = p3;
		this.tiltStart = tiltStart;
		this.tiltEnd = tiltEnd;
		this._len = -1;
	}
	/**
	* Updates the segment length. You must call this method every time you change the curve's control points.
	*/
	updateLength() {
		const z = .5;
		const len = T_VALUES.length;
		let sum = 0;
		for (let i = 0, t; i < len; i++) {
			t = z * T_VALUES[i] + z;
			sum += C_VALUES[i] * this.getDerivativeAt(t, tempVec3$3).len();
		}
		this._len = z * sum;
	}
	/**
	* Get point at relative position in curve according to segment length.
	* @param {number} t Distance at time t in range [0 .. 1]
	* @param {Vec3} out Optional Vec3 to output
	* @returns {Vec3} Point at relative position
	*/
	getPointAt(t, out = new Vec3()) {
		out.x = cubicBezier(t, this.p0.x, this.p1.x, this.p2.x, this.p3.x);
		out.y = cubicBezier(t, this.p0.y, this.p1.y, this.p2.y, this.p3.y);
		out.z = cubicBezier(t, this.p0.z, this.p1.z, this.p2.z, this.p3.z);
		return out;
	}
	getDerivativeAt(t, out = new Vec3()) {
		out.x = cubicBezierDeriv(t, this.p0.x, this.p1.x, this.p2.x, this.p3.x);
		out.y = cubicBezierDeriv(t, this.p0.y, this.p1.y, this.p2.y, this.p3.y);
		out.z = cubicBezierDeriv(t, this.p0.z, this.p1.z, this.p2.z, this.p3.z);
		return out;
	}
	/**
	* Returns a unit vector tangent at t
	* @param {number} t Distance at time t in range [0 .. 1]
	* @param {Vec3} out Optional Vec3 to output
	* @returns {Vec3} A unit vector
	*/
	getTangentAt(t, out = new Vec3()) {
		return this.getDerivativeAt(t, out).normalize();
	}
	lastPoint() {
		return this.p3;
	}
};
//#endregion
//#region node_modules/ogl/src/extras/path/QuadraticBezierSegment.js
var tempVec3$2 = /* @__PURE__ */ new Vec3();
function quadraticBezier(t, p0, p1, p2) {
	const k = 1 - t;
	return k * k * p0 + 2 * k * t * p1 + t * t * p2;
}
function quadraticBezierDeriv(t, p0, p1, p2) {
	return 2 * (1 - t) * (p1 - p0) + 2 * t * (p2 - p1);
}
var QuadraticBezierSegment = class extends BaseSegment {
	constructor(p0, p1, p2, tiltStart = 0, tiltEnd = 0) {
		super();
		this.p0 = p0;
		this.p1 = p1;
		this.p2 = p2;
		this.tiltStart = tiltStart;
		this.tiltEnd = tiltEnd;
		this._len = -1;
	}
	/**
	* Updates the segment length. You must call this method every time you change the curve's control points.
	*/
	updateLength() {
		const z = .5;
		const len = T_VALUES.length;
		let sum = 0;
		for (let i = 0, t; i < len; i++) {
			t = z * T_VALUES[i] + z;
			sum += C_VALUES[i] * this.getDerivativeAt(t, tempVec3$2).len();
		}
		this._len = z * sum;
	}
	/**
	* Get point at relative position in curve according to segment length.
	* @param {number} t Distance at time t in range [0 .. 1]
	* @param {Vec3} out Optional Vec3 to output
	* @returns {Vec3} Point at relative position
	*/
	getPointAt(t, out = new Vec3()) {
		out.x = quadraticBezier(t, this.p0.x, this.p1.x, this.p2.x);
		out.y = quadraticBezier(t, this.p0.y, this.p1.y, this.p2.y);
		out.z = quadraticBezier(t, this.p0.z, this.p1.z, this.p2.z);
		return out;
	}
	getDerivativeAt(t, out = new Vec3()) {
		out.x = quadraticBezierDeriv(t, this.p0.x, this.p1.x, this.p2.x);
		out.y = quadraticBezierDeriv(t, this.p0.y, this.p1.y, this.p2.y);
		out.z = quadraticBezierDeriv(t, this.p0.z, this.p1.z, this.p2.z);
		return out;
	}
	/**
	* Returns a unit vector tangent at t
	* @param {number} t Distance at time t in range [0 .. 1]
	* @param {Vec3} out Optional Vec3 to output
	* @returns {Vec3} A unit vector
	*/
	getTangentAt(t, out = new Vec3()) {
		return this.getDerivativeAt(t, out).normalize();
	}
	lastPoint() {
		return this.p2;
	}
};
//#endregion
//#region node_modules/ogl/src/extras/path/LineSegment.js
var tempVec3$1 = /* @__PURE__ */ new Vec3();
var LineSegment = class extends BaseSegment {
	constructor(p0, p1, tiltStart = 0, tiltEnd = 0) {
		super();
		this.p0 = p0;
		this.p1 = p1;
		this.tiltStart = tiltStart;
		this.tiltEnd = tiltEnd;
		this._len = -1;
	}
	/**
	* Updates the segment length. You must call this method every time you change the curve's control points.
	*/
	updateLength() {
		this._len = tempVec3$1.sub(this.p1, this.p0).len();
	}
	/**
	* Get point at relative position in curve according to segment length.
	* @param {number} t Distance at time t in range [0 .. 1]
	* @param {Vec3} out Optional Vec3 to output
	* @returns {Vec3} Point at relative position
	*/
	getPointAt(t, out = new Vec3()) {
		lerp$1(out, this.p0, this.p1, t);
		return out;
	}
	/**
	* Returns a unit vector tangent at t
	* @param {number} t Distance at time t in range [0 .. 1]
	* @param {Vec3} out Optional Vec3 to output
	* @returns {Vec3} A unit vector
	*/
	getTangentAt(t, out = new Vec3()) {
		return out.sub(this.p1, this.p0).normalize();
	}
	lastPoint() {
		return this.p1;
	}
};
//#endregion
//#region node_modules/ogl/src/extras/path/Path.js
var tempVec3 = /* @__PURE__ */ new Vec3();
var tempMat4$2 = /* @__PURE__ */ new Mat4();
function throwIfNullProperty(property, message) {
	if (this[property] == null) throw new Error(message);
}
var Path = class {
	constructor() {
		this._segments = [];
		this._lengthOffsets = null;
		this._totalLength = -1;
		this._lastPoint = null;
		this._lastTilt = 0;
		this._assertLastPoint = throwIfNullProperty.bind(this, "_lastPoint", "Can`t get previous point of curve. Did you forget moveTo command?");
		this.tiltFunction = null;
	}
	moveTo(p, tilt = 0) {
		this._totalLength = -1;
		this._lastPoint = p;
		this._lastTilt = tilt;
	}
	bezierCurveTo(cp1, cp2, p, tilt = 0) {
		this._assertLastPoint();
		const seg = new CubicBezierSegment(this._lastPoint, cp1, cp2, p, this._lastTilt, tilt);
		this.addSegment(seg);
		return this;
	}
	quadraticCurveTo(cp, p, tilt = 0) {
		this._assertLastPoint();
		const seg = new QuadraticBezierSegment(this._lastPoint, cp, p, this._lastTilt, tilt);
		this.addSegment(seg);
		return this;
	}
	lineTo(p, tilt = 0) {
		this._assertLastPoint();
		const seg = new LineSegment(this._lastPoint, p, this._lastTilt, tilt);
		this.addSegment(seg);
		return this;
	}
	addSegment(segment) {
		this._totalLength = -1;
		this._lastPoint = segment.lastPoint();
		this._lastTilt = segment.tiltEnd;
		this._segments.push(segment);
		return this;
	}
	getSegments() {
		return this._segments;
	}
	updateLength() {
		const n = this._segments.length;
		this._lengthOffsets = new Array(n);
		let offset = 0;
		for (let i = 0; i < n; i++) {
			this._lengthOffsets[i] = offset;
			offset += this._segments[i].getLength();
		}
		this._totalLength = offset;
	}
	getLength() {
		if (this._totalLength < 0) this.updateLength();
		return this._totalLength;
	}
	/**
	* Finding a path segment at a given absolute length distance
	* @param {number} len absolute length distance
	* @returns {[number, number]} [_segment index_, _relative segment distance_]
	*/
	findSegmentIndexAtLength(len) {
		const totalLength = this.getLength();
		if (len <= 0) return [0, 0];
		if (len >= totalLength) return [this._segments.length - 1, 1];
		let start = 0;
		let end = this._lengthOffsets.length - 1;
		let index = -1;
		let mid;
		while (start <= end) {
			mid = Math.ceil((start + end) / 2);
			if (mid === 0 || mid === this._lengthOffsets.length - 1 || len >= this._lengthOffsets[mid] && len < this._lengthOffsets[mid + 1]) {
				index = mid;
				break;
			} else if (len < this._lengthOffsets[mid]) end = mid - 1;
			else start = mid + 1;
		}
		const segLen = this._segments[index].getLength();
		const t = (len - this._lengthOffsets[index]) / segLen;
		return [index, t];
	}
	getPointAtLength(len, out = new Vec3()) {
		const [i, t] = this.findSegmentIndexAtLength(len);
		return this._segments[i].getPointAt(t, out);
	}
	getPointAt(t, out = new Vec3()) {
		const totalLength = this.getLength();
		return this.getPointAtLength(t * totalLength, out);
	}
	getTangentAtLength(len, out = new Vec3()) {
		const [i, t] = this.findSegmentIndexAtLength(len);
		return this._segments[i].getTangentAt(t, out);
	}
	getTangentAt(t, out = new Vec3()) {
		const totalLength = this.getLength();
		return this.getTangentAtLength(t * totalLength, out);
	}
	getTiltAtLength(len) {
		const [i, t] = this.findSegmentIndexAtLength(len);
		return this._segments[i].getTiltAt(t);
	}
	getTiltAt(t) {
		const totalLength = this.getLength();
		return this.getTiltAtLength(t * totalLength);
	}
	/**
	* Get sequence of points using `getPointAt(t)`
	* @param {number} divisions number of subdivisions
	* @returns {Vec3[]} array of points
	*/
	getPoints(divisions = 64) {
		const points = new Array(divisions + 1);
		for (let i = 0; i <= divisions; i++) points[i] = this.getPointAt(i / divisions);
		return points;
	}
	/**
	* Generates the Frenet Frames.
	* See http://www.cs.indiana.edu/pub/techreports/TR425.pdf
	* @param {number} divisions number of subdivisions
	* @returns {{tangents: Vec3[], normals: Vec3[], binormals: Vec3[]}} Object with tangents, normals and binormals arrays
	*/
	computeFrenetFrames(divisions = 64, closed = false) {
		const tangents = new Array(divisions + 1);
		const tilts = new Array(divisions + 1);
		const tiltFunction = this.tiltFunction ?? ((a) => a);
		const totalLength = this.getLength();
		for (let i = 0; i <= divisions; i++) {
			const [si, st] = this.findSegmentIndexAtLength(totalLength * i / divisions);
			const segment = this._segments[si];
			tangents[i] = segment.getTangentAt(st);
			tilts[i] = tiltFunction(segment.getTiltAt(st), i / divisions, this);
		}
		const tx = Math.abs(tangents[0].x);
		const ty = Math.abs(tangents[0].y);
		const tz = Math.abs(tangents[0].z);
		const normal = new Vec3();
		if (tx < ty && tx < tz) normal.set(1, 0, 0);
		else if (ty < tx && ty < tz) normal.set(0, 1, 0);
		else normal.set(0, 0, 1);
		const normals = new Array(divisions + 1);
		const binormals = new Array(divisions + 1);
		normals[0] = new Vec3();
		binormals[0] = new Vec3();
		tempVec3.cross(tangents[0], normal).normalize();
		normals[0].cross(tangents[0], tempVec3);
		binormals[0].cross(tangents[0], normals[0]);
		for (let i = 1; i < tangents.length; i++) {
			normals[i] = normals[i - 1].clone();
			binormals[i] = new Vec3();
			tempVec3.cross(tangents[i - 1], tangents[i]);
			const crossLen = tempVec3.len();
			if (crossLen > Number.EPSILON) {
				tempVec3.scale(1 / crossLen);
				const cosTheta = clamp(tangents[i - 1].dot(tangents[i]), -1, 1);
				mat4fromRotationSinCos(tempMat4$2, tempVec3, clamp(crossLen, -1, 1), cosTheta);
				normals[i].applyMatrix4(tempMat4$2);
			}
			binormals[i].cross(tangents[i], normals[i]);
		}
		for (let i = 0; i < tilts.length; i++) rotateNormalBinormal(toRadian(tilts[i]), normals[i], binormals[i]);
		if (closed === true) {
			const normalLast = normals[normals.length - 1];
			let step = Math.acos(clamp(normals[0].dot(normalLast), -1, 1)) / (normals.length - 1);
			if (tangents[0].dot(tempVec3.cross(normals[0], normalLast)) > 0) step = -step;
			for (let i = 1; i < normals.length - 1; i++) {
				const angle = step * i;
				rotateNormalBinormal(angle, normals[i], binormals[i]);
				tilts[i] += toDegrees(angle);
			}
			normals[normals.length - 1] = normals[0].clone();
			binormals[binormals.length - 1] = binormals[0].clone();
		}
		return {
			tangents,
			normals,
			binormals,
			tilts
		};
	}
};
//#endregion
//#region node_modules/ogl/src/extras/Tube.js
var vertex$7 = /* @__PURE__ */ new Vec3();
var normal = /* @__PURE__ */ new Vec3();
var uv = /* @__PURE__ */ new Vec2();
var point = /* @__PURE__ */ new Vec3();
var Tube = class extends Geometry {
	constructor(gl, { path, radius = 1, tubularSegments = 64, radialSegments = 8, closed = false, attributes = {} } = {}) {
		super(gl, attributes);
		this.path = path;
		this.radius = radius;
		this.tubularSegments = tubularSegments;
		this.radialSegments = radialSegments;
		this.closed = closed;
		this.frenetFrames = path.computeFrenetFrames(tubularSegments, closed);
		const numVertices = (tubularSegments + 1) * (radialSegments + 1);
		const numIndices = tubularSegments * radialSegments * 6;
		this.positions = new Float32Array(numVertices * 3);
		this.normals = new Float32Array(numVertices * 3);
		this.uvs = new Float32Array(numVertices * 2);
		this.indices = numVertices > 65536 ? new Uint32Array(numIndices) : new Uint16Array(numIndices);
		this._generateAttributes();
		this._generateIndices();
		this.addAttribute("position", {
			size: 3,
			data: this.positions
		});
		this.addAttribute("normal", {
			size: 3,
			data: this.normals
		});
		this.addAttribute("uv", {
			size: 2,
			data: this.uvs
		});
		this.setIndex({ data: this.indices });
	}
	_generateAttributes() {
		for (let i = 0; i <= this.tubularSegments; i++) {
			let ci = i;
			if (i === this.tubularSegments) ci = this.closed ? 0 : this.tubularSegments;
			this.path.getPointAt(ci / this.tubularSegments, point);
			const N = this.frenetFrames.normals[ci];
			const B = this.frenetFrames.binormals[ci];
			for (let j = 0; j <= this.radialSegments; j++) {
				const v = j / this.radialSegments * Math.PI * 2;
				const sin = Math.sin(v);
				const cos = -Math.cos(v);
				const idx = i * (this.radialSegments + 1) + j;
				normal.x = cos * N.x + sin * B.x;
				normal.y = cos * N.y + sin * B.y;
				normal.z = cos * N.z + sin * B.z;
				this.normals.set(normal, idx * 3);
				vertex$7.x = point.x + this.radius * normal.x;
				vertex$7.y = point.y + this.radius * normal.y;
				vertex$7.z = point.z + this.radius * normal.z;
				this.positions.set(vertex$7, idx * 3);
				uv.x = i / this.tubularSegments;
				uv.y = j / this.radialSegments;
				this.uvs.set(uv, idx * 2);
			}
		}
	}
	_generateIndices() {
		for (let j = 1; j <= this.tubularSegments; j++) for (let i = 1; i <= this.radialSegments; i++) {
			const a = (this.radialSegments + 1) * (j - 1) + (i - 1);
			const b = (this.radialSegments + 1) * j + (i - 1);
			const c = (this.radialSegments + 1) * j + i;
			const d = (this.radialSegments + 1) * (j - 1) + i;
			const idx = (j - 1) * this.radialSegments + (i - 1);
			this.indices.set([
				a,
				b,
				d,
				b,
				c,
				d
			], idx * 6);
		}
	}
};
//#endregion
//#region node_modules/ogl/src/extras/Post.js
var Post = class {
	constructor(gl, { width, height, dpr, wrapS = gl.CLAMP_TO_EDGE, wrapT = gl.CLAMP_TO_EDGE, minFilter = gl.LINEAR, magFilter = gl.LINEAR, geometry = new Triangle(gl), targetOnly = null, depth = true } = {}) {
		this.gl = gl;
		this.passes = [];
		this.geometry = geometry;
		this.uniform = { value: null };
		this.targetOnly = targetOnly;
		if (dpr) this.dpr = dpr;
		if (width) this.width = width;
		if (height) this.height = height;
		dpr = this.dpr || this.gl.renderer.dpr;
		this.resolutionWidth = Math.floor(this.width || this.gl.renderer.width * dpr);
		this.resolutionHeight = Math.floor(this.height || this.gl.renderer.height * dpr);
		let options = {
			dpr: this.dpr,
			width: this.resolutionWidth,
			height: this.resolutionHeight,
			wrapS,
			wrapT,
			minFilter,
			magFilter,
			depth
		};
		const fbo = this.fbo = {
			read: new RenderTarget(this.gl, options),
			write: new RenderTarget(this.gl, options),
			swap: () => {
				let temp = fbo.read;
				fbo.read = fbo.write;
				fbo.write = temp;
			}
		};
	}
	addPass({ vertex = defaultVertex$3, fragment = defaultFragment$3, uniforms = {}, textureUniform = "tMap", enabled = true } = {}) {
		uniforms[textureUniform] = { value: this.fbo.read.texture };
		const program = new Program(this.gl, {
			vertex,
			fragment,
			uniforms
		});
		const pass = {
			mesh: new Mesh(this.gl, {
				geometry: this.geometry,
				program
			}),
			program,
			uniforms,
			enabled,
			textureUniform
		};
		this.passes.push(pass);
		return pass;
	}
	resize({ width, height, dpr } = {}) {
		if (dpr) this.dpr = dpr;
		if (width) this.width = width;
		if (height) this.height = height;
		dpr = this.dpr || this.gl.renderer.dpr;
		this.resolutionWidth = Math.floor(this.width || this.gl.renderer.width * dpr);
		this.resolutionHeight = Math.floor(this.height || this.gl.renderer.height * dpr);
		this.fbo.read.setSize(this.resolutionWidth, this.resolutionHeight);
		this.fbo.write.setSize(this.resolutionWidth, this.resolutionHeight);
	}
	render({ scene, camera, texture, target = null, update = true, sort = true, frustumCull = true, beforePostCallbacks }) {
		const enabledPasses = this.passes.filter((pass) => pass.enabled);
		if (!texture) {
			this.gl.renderer.render({
				scene,
				camera,
				target: enabledPasses.length || !target && this.targetOnly ? this.fbo.write : target,
				update,
				sort,
				frustumCull
			});
			this.fbo.swap();
			if (beforePostCallbacks) beforePostCallbacks.forEach((f) => f && f());
		}
		enabledPasses.forEach((pass, i) => {
			pass.mesh.program.uniforms[pass.textureUniform].value = !i && texture ? texture : this.fbo.read.texture;
			this.gl.renderer.render({
				scene: pass.mesh,
				target: i === enabledPasses.length - 1 && (target || !this.targetOnly) ? target : this.fbo.write,
				clear: true
			});
			this.fbo.swap();
		});
		this.uniform.value = this.fbo.read.texture;
	}
};
var defaultVertex$3 = `
    attribute vec2 uv;
    attribute vec2 position;

    varying vec2 vUv;

    void main() {
        vUv = uv;
        gl_Position = vec4(position, 0, 1);
    }
`;
var defaultFragment$3 = `
    precision highp float;

    uniform sampler2D tMap;
    varying vec2 vUv;

    void main() {
        gl_FragColor = texture2D(tMap, vUv);
    }
`;
//#endregion
//#region node_modules/ogl/src/extras/Animation.js
var prevPos = /* @__PURE__ */ new Vec3();
var prevRot = /* @__PURE__ */ new Quat();
var prevScl = /* @__PURE__ */ new Vec3();
var nextPos = /* @__PURE__ */ new Vec3();
var nextRot = /* @__PURE__ */ new Quat();
var nextScl = /* @__PURE__ */ new Vec3();
var Animation = class {
	constructor({ objects, data }) {
		this.objects = objects;
		this.data = data;
		this.elapsed = 0;
		this.weight = 1;
		this.duration = data.frames.length - 1;
	}
	update(totalWeight = 1, isSet) {
		const weight = isSet ? 1 : this.weight / totalWeight;
		const elapsed = this.elapsed % this.duration;
		const floorFrame = Math.floor(elapsed);
		const blend = elapsed - floorFrame;
		const prevKey = this.data.frames[floorFrame];
		const nextKey = this.data.frames[(floorFrame + 1) % this.duration];
		this.objects.forEach((object, i) => {
			prevPos.fromArray(prevKey.position, i * 3);
			prevRot.fromArray(prevKey.quaternion, i * 4);
			prevScl.fromArray(prevKey.scale, i * 3);
			nextPos.fromArray(nextKey.position, i * 3);
			nextRot.fromArray(nextKey.quaternion, i * 4);
			nextScl.fromArray(nextKey.scale, i * 3);
			prevPos.lerp(nextPos, blend);
			prevRot.slerp(nextRot, blend);
			prevScl.lerp(nextScl, blend);
			object.position.lerp(prevPos, weight);
			object.quaternion.slerp(prevRot, weight);
			object.scale.lerp(prevScl, weight);
		});
	}
};
//#endregion
//#region node_modules/ogl/src/extras/Skin.js
var tempMat4$1 = /* @__PURE__ */ new Mat4();
var Skin = class extends Mesh {
	constructor(gl, { rig, geometry, program, mode = gl.TRIANGLES } = {}) {
		super(gl, {
			geometry,
			program,
			mode
		});
		this.createBones(rig);
		this.createBoneTexture();
		this.animations = [];
		Object.assign(this.program.uniforms, {
			boneTexture: { value: this.boneTexture },
			boneTextureSize: { value: this.boneTextureSize }
		});
	}
	createBones(rig) {
		this.root = new Transform();
		this.bones = [];
		if (!rig.bones || !rig.bones.length) return;
		for (let i = 0; i < rig.bones.length; i++) {
			const bone = new Transform();
			bone.position.fromArray(rig.bindPose.position, i * 3);
			bone.quaternion.fromArray(rig.bindPose.quaternion, i * 4);
			bone.scale.fromArray(rig.bindPose.scale, i * 3);
			this.bones.push(bone);
		}
		rig.bones.forEach((data, i) => {
			this.bones[i].name = data.name;
			if (data.parent === -1) return this.bones[i].setParent(this.root);
			this.bones[i].setParent(this.bones[data.parent]);
		});
		this.root.updateMatrixWorld(true);
		this.bones.forEach((bone) => {
			bone.bindInverse = new Mat4(...bone.worldMatrix).inverse();
		});
	}
	createBoneTexture() {
		if (!this.bones.length) return;
		const size = Math.max(4, Math.pow(2, Math.ceil(Math.log(Math.sqrt(this.bones.length * 4)) / Math.LN2)));
		this.boneMatrices = new Float32Array(size * size * 4);
		this.boneTextureSize = size;
		this.boneTexture = new Texture(this.gl, {
			image: this.boneMatrices,
			generateMipmaps: false,
			type: this.gl.FLOAT,
			internalFormat: this.gl.renderer.isWebgl2 ? this.gl.RGBA32F : this.gl.RGBA,
			minFilter: this.gl.NEAREST,
			magFilter: this.gl.NEAREST,
			flipY: false,
			width: size
		});
	}
	addAnimation(data) {
		const animation = new Animation({
			objects: this.bones,
			data
		});
		this.animations.push(animation);
		return animation;
	}
	update() {
		let total = 0;
		this.animations.forEach((animation) => total += animation.weight);
		this.animations.forEach((animation, i) => {
			animation.update(total, i === 0);
		});
	}
	draw({ camera } = {}) {
		this.root.updateMatrixWorld(true);
		this.bones.forEach((bone, i) => {
			tempMat4$1.multiply(bone.worldMatrix, bone.bindInverse);
			this.boneMatrices.set(tempMat4$1, i * 16);
		});
		if (this.boneTexture) this.boneTexture.needsUpdate = true;
		super.draw({ camera });
	}
};
//#endregion
//#region node_modules/ogl/src/extras/Text.js
function Text({ font, text, width = Infinity, align = "left", size = 1, letterSpacing = 0, lineHeight = 1.4, wordSpacing = 0, wordBreak = false }) {
	const _this = this;
	let glyphs, buffers, baseline, scale;
	const newline = /\n/;
	const whitespace = /\s/;
	parseFont();
	createGeometry();
	function parseFont() {
		glyphs = {};
		font.chars.forEach((d) => glyphs[d.char] = d);
	}
	function createGeometry() {
		font.common.lineHeight;
		baseline = font.common.base;
		scale = size / baseline;
		let numChars = text.replace(/[ \n]/g, "").length;
		buffers = {
			position: new Float32Array(numChars * 4 * 3),
			uv: new Float32Array(numChars * 4 * 2),
			id: new Float32Array(numChars * 4),
			index: new Uint16Array(numChars * 6)
		};
		for (let i = 0; i < numChars; i++) {
			buffers.id.set([
				i,
				i,
				i,
				i
			], i * 4);
			buffers.index.set([
				i * 4,
				i * 4 + 2,
				i * 4 + 1,
				i * 4 + 1,
				i * 4 + 2,
				i * 4 + 3
			], i * 6);
		}
		layout();
	}
	function layout() {
		const lines = [];
		let cursor = 0;
		let wordCursor = 0;
		let wordWidth = 0;
		let line = newLine();
		function newLine() {
			const line = {
				width: 0,
				glyphs: []
			};
			lines.push(line);
			wordCursor = cursor;
			wordWidth = 0;
			return line;
		}
		let maxTimes = 100;
		let count = 0;
		while (cursor < text.length && count < maxTimes) {
			count++;
			const char = text[cursor];
			if (!line.width && whitespace.test(char)) {
				cursor++;
				wordCursor = cursor;
				wordWidth = 0;
				continue;
			}
			if (newline.test(char)) {
				cursor++;
				line = newLine();
				continue;
			}
			const glyph = glyphs[char] || glyphs[" "];
			if (line.glyphs.length) {
				const prevGlyph = line.glyphs[line.glyphs.length - 1][0];
				let kern = getKernPairOffset(glyph.id, prevGlyph.id) * scale;
				line.width += kern;
				wordWidth += kern;
			}
			line.glyphs.push([glyph, line.width]);
			let advance = 0;
			if (whitespace.test(char)) {
				wordCursor = cursor;
				wordWidth = 0;
				advance += wordSpacing * size;
			} else advance += letterSpacing * size;
			advance += glyph.xadvance * scale;
			line.width += advance;
			wordWidth += advance;
			if (line.width > width) {
				if (wordBreak && line.glyphs.length > 1) {
					line.width -= advance;
					line.glyphs.pop();
					line = newLine();
					continue;
				} else if (!wordBreak && wordWidth !== line.width) {
					let numGlyphs = cursor - wordCursor + 1;
					line.glyphs.splice(-numGlyphs, numGlyphs);
					cursor = wordCursor;
					line.width -= wordWidth;
					line = newLine();
					continue;
				}
			}
			cursor++;
			count = 0;
		}
		if (!line.width) lines.pop();
		populateBuffers(lines);
	}
	function populateBuffers(lines) {
		const texW = font.common.scaleW;
		const texH = font.common.scaleH;
		let y = .07 * size;
		let j = 0;
		for (let lineIndex = 0; lineIndex < lines.length; lineIndex++) {
			let line = lines[lineIndex];
			for (let i = 0; i < line.glyphs.length; i++) {
				const glyph = line.glyphs[i][0];
				let x = line.glyphs[i][1];
				if (align === "center") x -= line.width * .5;
				else if (align === "right") x -= line.width;
				if (whitespace.test(glyph.char)) continue;
				x += glyph.xoffset * scale;
				y -= glyph.yoffset * scale;
				let w = glyph.width * scale;
				let h = glyph.height * scale;
				buffers.position.set([
					x,
					y - h,
					0,
					x,
					y,
					0,
					x + w,
					y - h,
					0,
					x + w,
					y,
					0
				], j * 4 * 3);
				let u = glyph.x / texW;
				let uw = glyph.width / texW;
				let v = 1 - glyph.y / texH;
				let vh = glyph.height / texH;
				buffers.uv.set([
					u,
					v - vh,
					u,
					v,
					u + uw,
					v - vh,
					u + uw,
					v
				], j * 4 * 2);
				y += glyph.yoffset * scale;
				j++;
			}
			y -= size * lineHeight;
		}
		_this.buffers = buffers;
		_this.numLines = lines.length;
		_this.height = _this.numLines * size * lineHeight;
		_this.width = Math.max(...lines.map((line) => line.width));
	}
	function getKernPairOffset(id1, id2) {
		for (let i = 0; i < font.kernings.length; i++) {
			let k = font.kernings[i];
			if (k.first < id1) continue;
			if (k.second < id2) continue;
			if (k.first > id1) return 0;
			if (k.first === id1 && k.second > id2) return 0;
			return k.amount;
		}
		return 0;
	}
	this.resize = function(options) {
		({width} = options);
		layout();
	};
	this.update = function(options) {
		({text} = options);
		createGeometry();
	};
}
//#endregion
//#region node_modules/ogl/src/extras/NormalProgram.js
var vertex$6 = `
    precision highp float;
    precision highp int;

    attribute vec3 position;
    attribute vec3 normal;

    uniform mat3 normalMatrix;
    uniform mat4 modelViewMatrix;
    uniform mat4 projectionMatrix;

    varying vec3 vNormal;

    void main() {
        vNormal = normalize(normalMatrix * normal);
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
`;
var fragment$6 = `
    precision highp float;
    precision highp int;

    varying vec3 vNormal;

    void main() {
        gl_FragColor.rgb = normalize(vNormal);
        gl_FragColor.a = 1.0;
    }
`;
function NormalProgram(gl) {
	return new Program(gl, {
		vertex: vertex$6,
		fragment: fragment$6,
		cullFace: false
	});
}
//#endregion
//#region node_modules/ogl/src/extras/Flowmap.js
var Flowmap = class {
	constructor(gl, { size = 128, falloff = .3, alpha = 1, dissipation = .98, type } = {}) {
		const _this = this;
		this.gl = gl;
		this.uniform = { value: null };
		this.mask = {
			read: null,
			write: null,
			swap: () => {
				let temp = _this.mask.read;
				_this.mask.read = _this.mask.write;
				_this.mask.write = temp;
				_this.uniform.value = _this.mask.read.texture;
			}
		};
		createFBOs();
		this.aspect = 1;
		this.mouse = new Vec2();
		this.velocity = new Vec2();
		this.mesh = initProgram();
		function createFBOs() {
			if (!type) type = gl.HALF_FLOAT || gl.renderer.extensions["OES_texture_half_float"].HALF_FLOAT_OES;
			let minFilter = (() => {
				if (gl.renderer.isWebgl2) return gl.LINEAR;
				if (gl.renderer.extensions[`OES_texture_${type === gl.FLOAT ? "" : "half_"}float_linear`]) return gl.LINEAR;
				return gl.NEAREST;
			})();
			const options = {
				width: size,
				height: size,
				type,
				format: gl.RGBA,
				internalFormat: gl.renderer.isWebgl2 ? type === gl.FLOAT ? gl.RGBA32F : gl.RGBA16F : gl.RGBA,
				minFilter,
				depth: false
			};
			_this.mask.read = new RenderTarget(gl, options);
			_this.mask.write = new RenderTarget(gl, options);
			_this.mask.swap();
		}
		function initProgram() {
			return new Mesh(gl, {
				geometry: new Triangle(gl),
				program: new Program(gl, {
					vertex: vertex$5,
					fragment: fragment$5,
					uniforms: {
						tMap: _this.uniform,
						uFalloff: { value: falloff * .5 },
						uAlpha: { value: alpha },
						uDissipation: { value: dissipation },
						uAspect: { value: 1 },
						uMouse: { value: _this.mouse },
						uVelocity: { value: _this.velocity }
					},
					depthTest: false
				})
			});
		}
	}
	update() {
		this.mesh.program.uniforms.uAspect.value = this.aspect;
		this.gl.renderer.render({
			scene: this.mesh,
			target: this.mask.write,
			clear: false
		});
		this.mask.swap();
	}
};
var vertex$5 = `
    attribute vec2 uv;
    attribute vec2 position;

    varying vec2 vUv;

    void main() {
        vUv = uv;
        gl_Position = vec4(position, 0, 1);
    }
`;
var fragment$5 = `
    precision highp float;

    uniform sampler2D tMap;

    uniform float uFalloff;
    uniform float uAlpha;
    uniform float uDissipation;
    
    uniform float uAspect;
    uniform vec2 uMouse;
    uniform vec2 uVelocity;

    varying vec2 vUv;

    void main() {
        vec4 color = texture2D(tMap, vUv) * uDissipation;

        vec2 cursor = vUv - uMouse;
        cursor.x *= uAspect;

        vec3 stamp = vec3(uVelocity * vec2(1, -1), 1.0 - pow(1.0 - min(1.0, length(uVelocity)), 3.0));
        float falloff = smoothstep(uFalloff, 0.0, length(cursor)) * uAlpha;

        color.rgb = mix(color.rgb, stamp, vec3(falloff));

        gl_FragColor = color;
    }
`;
//#endregion
//#region node_modules/ogl/src/extras/GPGPU.js
var GPGPU = class {
	constructor(gl, { data = /* @__PURE__ */ new Float32Array(16), geometry = new Triangle(gl), type }) {
		this.gl = gl;
		const initialData = data;
		this.passes = [];
		this.geometry = geometry;
		this.dataLength = initialData.length / 4;
		this.size = Math.pow(2, Math.ceil(Math.log(Math.ceil(Math.sqrt(this.dataLength))) / Math.LN2));
		this.coords = new Float32Array(this.dataLength * 2);
		for (let i = 0; i < this.dataLength; i++) {
			const x = i % this.size / this.size;
			const y = Math.floor(i / this.size) / this.size;
			this.coords.set([x, y], i * 2);
		}
		const floatArray = (() => {
			if (initialData.length === this.size * this.size * 4) return initialData;
			else {
				const a = new Float32Array(this.size * this.size * 4);
				a.set(initialData);
				return a;
			}
		})();
		this.uniform = { value: new Texture(gl, {
			image: floatArray,
			target: gl.TEXTURE_2D,
			type: gl.FLOAT,
			format: gl.RGBA,
			internalFormat: gl.renderer.isWebgl2 ? gl.RGBA32F : gl.RGBA,
			wrapS: gl.CLAMP_TO_EDGE,
			wrapT: gl.CLAMP_TO_EDGE,
			generateMipmaps: false,
			minFilter: gl.NEAREST,
			magFilter: gl.NEAREST,
			width: this.size,
			flipY: false
		}) };
		const options = {
			width: this.size,
			height: this.size,
			type: type || gl.HALF_FLOAT || gl.renderer.extensions["OES_texture_half_float"].HALF_FLOAT_OES,
			format: gl.RGBA,
			internalFormat: gl.renderer.isWebgl2 ? type === gl.FLOAT ? gl.RGBA32F : gl.RGBA16F : gl.RGBA,
			minFilter: gl.NEAREST,
			depth: false,
			unpackAlignment: 1
		};
		this.fbo = {
			read: new RenderTarget(gl, options),
			write: new RenderTarget(gl, options),
			swap: () => {
				let temp = this.fbo.read;
				this.fbo.read = this.fbo.write;
				this.fbo.write = temp;
				this.uniform.value = this.fbo.read.texture;
			}
		};
	}
	addPass({ vertex = defaultVertex$2, fragment = defaultFragment$2, uniforms = {}, textureUniform = "tMap", enabled = true } = {}) {
		uniforms[textureUniform] = this.uniform;
		const program = new Program(this.gl, {
			vertex,
			fragment,
			uniforms
		});
		const pass = {
			mesh: new Mesh(this.gl, {
				geometry: this.geometry,
				program
			}),
			program,
			uniforms,
			enabled,
			textureUniform
		};
		this.passes.push(pass);
		return pass;
	}
	render() {
		this.passes.filter((pass) => pass.enabled).forEach((pass, i) => {
			this.gl.renderer.render({
				scene: pass.mesh,
				target: this.fbo.write,
				clear: false
			});
			this.fbo.swap();
		});
	}
};
var defaultVertex$2 = `
    attribute vec2 uv;
    attribute vec2 position;

    varying vec2 vUv;

    void main() {
        vUv = uv;
        gl_Position = vec4(position, 0, 1);
    }
`;
var defaultFragment$2 = `
    precision highp float;

    uniform sampler2D tMap;
    varying vec2 vUv;

    void main() {
        gl_FragColor = texture2D(tMap, vUv);
    }
`;
//#endregion
//#region node_modules/ogl/src/extras/Polyline.js
var tmp = /* @__PURE__ */ new Vec3();
var Polyline = class {
	constructor(gl, { points, vertex = defaultVertex$1, fragment = defaultFragment$1, uniforms = {}, attributes = {} }) {
		this.gl = gl;
		this.points = points;
		this.count = points.length;
		this.position = new Float32Array(this.count * 3 * 2);
		this.prev = new Float32Array(this.count * 3 * 2);
		this.next = new Float32Array(this.count * 3 * 2);
		const side = new Float32Array(this.count * 1 * 2);
		const uv = new Float32Array(this.count * 2 * 2);
		const index = new Uint16Array((this.count - 1) * 3 * 2);
		for (let i = 0; i < this.count; i++) {
			side.set([-1, 1], i * 2);
			const v = i / (this.count - 1);
			uv.set([
				0,
				v,
				1,
				v
			], i * 4);
			if (i === this.count - 1) continue;
			const ind = i * 2;
			index.set([
				ind + 0,
				ind + 1,
				ind + 2
			], (ind + 0) * 3);
			index.set([
				ind + 2,
				ind + 1,
				ind + 3
			], (ind + 1) * 3);
		}
		const geometry = this.geometry = new Geometry(gl, Object.assign(attributes, {
			position: {
				size: 3,
				data: this.position
			},
			prev: {
				size: 3,
				data: this.prev
			},
			next: {
				size: 3,
				data: this.next
			},
			side: {
				size: 1,
				data: side
			},
			uv: {
				size: 2,
				data: uv
			},
			index: {
				size: 1,
				data: index
			}
		}));
		this.updateGeometry();
		if (!uniforms.uResolution) this.resolution = uniforms.uResolution = { value: new Vec2() };
		if (!uniforms.uDPR) this.dpr = uniforms.uDPR = { value: 1 };
		if (!uniforms.uThickness) this.thickness = uniforms.uThickness = { value: 1 };
		if (!uniforms.uColor) this.color = uniforms.uColor = { value: new Color("#000") };
		if (!uniforms.uMiter) this.miter = uniforms.uMiter = { value: 1 };
		this.resize();
		const program = this.program = new Program(gl, {
			vertex,
			fragment,
			uniforms
		});
		this.mesh = new Mesh(gl, {
			geometry,
			program
		});
	}
	updateGeometry() {
		this.points.forEach((p, i) => {
			p.toArray(this.position, i * 3 * 2);
			p.toArray(this.position, i * 3 * 2 + 3);
			if (!i) {
				tmp.copy(p).sub(this.points[i + 1]).add(p);
				tmp.toArray(this.prev, i * 3 * 2);
				tmp.toArray(this.prev, i * 3 * 2 + 3);
			} else {
				p.toArray(this.next, (i - 1) * 3 * 2);
				p.toArray(this.next, (i - 1) * 3 * 2 + 3);
			}
			if (i === this.points.length - 1) {
				tmp.copy(p).sub(this.points[i - 1]).add(p);
				tmp.toArray(this.next, i * 3 * 2);
				tmp.toArray(this.next, i * 3 * 2 + 3);
			} else {
				p.toArray(this.prev, (i + 1) * 3 * 2);
				p.toArray(this.prev, (i + 1) * 3 * 2 + 3);
			}
		});
		this.geometry.attributes.position.needsUpdate = true;
		this.geometry.attributes.prev.needsUpdate = true;
		this.geometry.attributes.next.needsUpdate = true;
	}
	resize() {
		if (this.resolution) this.resolution.value.set(this.gl.canvas.width, this.gl.canvas.height);
		if (this.dpr) this.dpr.value = this.gl.renderer.dpr;
	}
};
var defaultVertex$1 = `
    precision highp float;

    attribute vec3 position;
    attribute vec3 next;
    attribute vec3 prev;
    attribute vec2 uv;
    attribute float side;

    uniform mat4 modelViewMatrix;
    uniform mat4 projectionMatrix;
    uniform vec2 uResolution;
    uniform float uDPR;
    uniform float uThickness;
    uniform float uMiter;

    varying vec2 vUv;

    vec4 getPosition() {
        mat4 mvp = projectionMatrix * modelViewMatrix;
        vec4 current = mvp * vec4(position, 1);
        vec4 nextPos = mvp * vec4(next, 1);
        vec4 prevPos = mvp * vec4(prev, 1);

        vec2 aspect = vec2(uResolution.x / uResolution.y, 1);    
        vec2 currentScreen = current.xy / current.w * aspect;
        vec2 nextScreen = nextPos.xy / nextPos.w * aspect;
        vec2 prevScreen = prevPos.xy / prevPos.w * aspect;
    
        vec2 dir1 = normalize(currentScreen - prevScreen);
        vec2 dir2 = normalize(nextScreen - currentScreen);
        vec2 dir = normalize(dir1 + dir2);
    
        vec2 normal = vec2(-dir.y, dir.x);
        normal /= mix(1.0, max(0.3, dot(normal, vec2(-dir1.y, dir1.x))), uMiter);
        normal /= aspect;

        float pixelWidthRatio = 1.0 / (uResolution.y / uDPR);
        float pixelWidth = current.w * pixelWidthRatio;
        normal *= pixelWidth * uThickness;
        current.xy -= normal * side;
    
        return current;
    }

    void main() {
        vUv = uv;
        gl_Position = getPosition();
    }
`;
var defaultFragment$1 = `
    precision highp float;

    uniform vec3 uColor;
    
    varying vec2 vUv;

    void main() {
        gl_FragColor.rgb = uColor;
        gl_FragColor.a = 1.0;
    }
`;
//#endregion
//#region node_modules/ogl/src/extras/Shadow.js
var Shadow = class {
	constructor(gl, { light = new Camera(gl), width = 1024, height = width }) {
		this.gl = gl;
		this.light = light;
		this.target = new RenderTarget(gl, {
			width,
			height
		});
		this.targetUniform = { value: this.target.texture };
		this.depthProgram = new Program(gl, {
			vertex: defaultVertex,
			fragment: defaultFragment,
			cullFace: false
		});
		this.castMeshes = [];
	}
	add({ mesh, receive = true, cast = true, vertex = defaultVertex, fragment = defaultFragment, uniformProjection = "shadowProjectionMatrix", uniformView = "shadowViewMatrix", uniformTexture = "tShadow" }) {
		if (receive && !mesh.program.uniforms[uniformProjection]) {
			mesh.program.uniforms[uniformProjection] = { value: this.light.projectionMatrix };
			mesh.program.uniforms[uniformView] = { value: this.light.viewMatrix };
			mesh.program.uniforms[uniformTexture] = this.targetUniform;
		}
		if (!cast) return;
		this.castMeshes.push(mesh);
		mesh.colorProgram = mesh.program;
		if (mesh.depthProgram) return;
		if (vertex === defaultVertex && fragment === defaultFragment) {
			mesh.depthProgram = this.depthProgram;
			return;
		}
		mesh.depthProgram = new Program(this.gl, {
			vertex,
			fragment,
			cullFace: false
		});
	}
	setSize({ width = 1024, height = width }) {
		this.target = new RenderTarget(this.gl, {
			width,
			height
		});
		this.targetUniform.value = this.target.texture;
	}
	render({ scene }) {
		scene.traverse((node) => {
			if (!node.draw) return;
			if (!!~this.castMeshes.indexOf(node)) node.program = node.depthProgram;
			else {
				node.isForceVisibility = node.visible;
				node.visible = false;
			}
		});
		this.gl.renderer.render({
			scene,
			camera: this.light,
			target: this.target
		});
		scene.traverse((node) => {
			if (!node.draw) return;
			if (!!~this.castMeshes.indexOf(node)) node.program = node.colorProgram;
			else node.visible = node.isForceVisibility;
		});
	}
};
var defaultVertex = `
    attribute vec3 position;
    attribute vec2 uv;

    uniform mat4 modelViewMatrix;
    uniform mat4 projectionMatrix;

    void main() {
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
`;
var defaultFragment = `
    precision highp float;

    vec4 packRGBA (float v) {
        vec4 pack = fract(vec4(1.0, 255.0, 65025.0, 16581375.0) * v);
        pack -= pack.yzww * vec2(1.0 / 255.0, 0.0).xxxy;
        return pack;
    }

    void main() {
        gl_FragColor = packRGBA(gl_FragCoord.z);
    }
`;
//#endregion
//#region node_modules/ogl/src/extras/KTXTexture.js
var KTXTexture = class extends Texture {
	constructor(gl, { buffer, wrapS = gl.CLAMP_TO_EDGE, wrapT = gl.CLAMP_TO_EDGE, anisotropy = 0, minFilter, magFilter } = {}) {
		super(gl, {
			generateMipmaps: false,
			wrapS,
			wrapT,
			anisotropy,
			minFilter,
			magFilter
		});
		if (buffer) return this.parseBuffer(buffer);
	}
	parseBuffer(buffer) {
		const ktx = new KhronosTextureContainer(buffer);
		ktx.mipmaps.isCompressedTexture = true;
		this.image = ktx.mipmaps;
		this.internalFormat = ktx.glInternalFormat;
		if (ktx.numberOfMipmapLevels > 1) {
			if (this.minFilter === this.gl.LINEAR) this.minFilter = this.gl.NEAREST_MIPMAP_LINEAR;
		} else if (this.minFilter === this.gl.NEAREST_MIPMAP_LINEAR) this.minFilter = this.gl.LINEAR;
	}
};
function KhronosTextureContainer(buffer) {
	const idCheck = [
		171,
		75,
		84,
		88,
		32,
		49,
		49,
		187,
		13,
		10,
		26,
		10
	];
	const id = new Uint8Array(buffer, 0, 12);
	for (let i = 0; i < id.length; i++) if (id[i] !== idCheck[i]) return console.error("File missing KTX identifier");
	const size = Uint32Array.BYTES_PER_ELEMENT;
	const head = new DataView(buffer, 12, 13 * size);
	const littleEndian = head.getUint32(0, true) === 67305985;
	if (head.getUint32(1 * size, littleEndian) !== 0) return console.warn("only compressed formats currently supported");
	this.glInternalFormat = head.getUint32(4 * size, littleEndian);
	let width = head.getUint32(6 * size, littleEndian);
	let height = head.getUint32(7 * size, littleEndian);
	this.numberOfFaces = head.getUint32(10 * size, littleEndian);
	this.numberOfMipmapLevels = Math.max(1, head.getUint32(11 * size, littleEndian));
	const bytesOfKeyValueData = head.getUint32(12 * size, littleEndian);
	this.mipmaps = [];
	let offset = 64 + bytesOfKeyValueData;
	for (let level = 0; level < this.numberOfMipmapLevels; level++) {
		const levelSize = new Int32Array(buffer, offset, 1)[0];
		offset += 4;
		for (let face = 0; face < this.numberOfFaces; face++) {
			const data = new Uint8Array(buffer, offset, levelSize);
			this.mipmaps.push({
				data,
				width,
				height
			});
			offset += levelSize;
			offset += 3 - (levelSize + 3) % 4;
		}
		width = width >> 1;
		height = height >> 1;
	}
}
//#endregion
//#region node_modules/ogl/src/extras/TextureLoader.js
var cache = {};
var supportedExtensions = [];
var TextureLoader = class {
	static load(gl, { src, wrapS = gl.CLAMP_TO_EDGE, wrapT = gl.CLAMP_TO_EDGE, anisotropy = 0, format = gl.RGBA, internalFormat = format, generateMipmaps = true, minFilter = generateMipmaps ? gl.NEAREST_MIPMAP_LINEAR : gl.LINEAR, magFilter = gl.LINEAR, premultiplyAlpha = false, unpackAlignment = 4, flipY = true } = {}) {
		const support = this.getSupportedExtensions(gl);
		let ext = "none";
		if (typeof src === "string") ext = src.split(".").pop().split("?")[0].toLowerCase();
		if (typeof src === "object") {
			for (const prop in src) if (support.includes(prop.toLowerCase())) {
				ext = prop.toLowerCase();
				src = src[prop];
				break;
			}
		}
		const cacheID = src + wrapS + wrapT + anisotropy + format + internalFormat + generateMipmaps + minFilter + magFilter + premultiplyAlpha + unpackAlignment + flipY + gl.renderer.id;
		if (cache[cacheID]) return cache[cacheID];
		let texture;
		switch (ext) {
			case "ktx":
			case "pvrtc":
			case "s3tc":
			case "etc":
			case "etc1":
			case "astc":
				texture = new KTXTexture(gl, {
					src,
					wrapS,
					wrapT,
					anisotropy,
					minFilter,
					magFilter
				});
				texture.loaded = this.loadKTX(src, texture);
				break;
			case "webp":
			case "jpg":
			case "jpeg":
			case "png":
				texture = new Texture(gl, {
					wrapS,
					wrapT,
					anisotropy,
					format,
					internalFormat,
					generateMipmaps,
					minFilter,
					magFilter,
					premultiplyAlpha,
					unpackAlignment,
					flipY
				});
				texture.loaded = this.loadImage(gl, src, texture, flipY);
				break;
			default:
				console.warn("No supported format supplied");
				texture = new Texture(gl);
		}
		texture.ext = ext;
		cache[cacheID] = texture;
		return texture;
	}
	static getSupportedExtensions(gl) {
		if (supportedExtensions.length) return supportedExtensions;
		const extensions = {
			pvrtc: gl.renderer.getExtension("WEBGL_compressed_texture_pvrtc") || gl.renderer.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc"),
			s3tc: gl.renderer.getExtension("WEBGL_compressed_texture_s3tc"),
			etc1: gl.renderer.getExtension("WEBGL_compressed_texture_etc1"),
			astc: gl.renderer.getExtension("WEBGL_compressed_texture_astc"),
			bc7: gl.renderer.getExtension("EXT_texture_compression_bptc")
		};
		for (const ext in extensions) if (extensions[ext]) supportedExtensions.push(ext);
		supportedExtensions.push("png", "jpg", "webp");
		return supportedExtensions;
	}
	static loadKTX(src, texture) {
		return fetch(src).then((res) => res.arrayBuffer()).then((buffer) => texture.parseBuffer(buffer));
	}
	static loadImage(gl, src, texture, flipY) {
		return decodeImage(src, flipY).then((imgBmp) => {
			if (!gl.renderer.isWebgl2 && (!powerOfTwo(imgBmp.width) || !powerOfTwo(imgBmp.height))) {
				if (texture.generateMipmaps) texture.generateMipmaps = false;
				if (texture.minFilter === gl.NEAREST_MIPMAP_LINEAR) texture.minFilter = gl.LINEAR;
				if (texture.wrapS === gl.REPEAT) texture.wrapS = texture.wrapT = gl.CLAMP_TO_EDGE;
			}
			texture.image = imgBmp;
			texture.onUpdate = () => {
				if (imgBmp.close) imgBmp.close();
				texture.onUpdate = null;
			};
			return imgBmp;
		});
	}
	static clearCache() {
		cache = {};
	}
};
function powerOfTwo(value) {
	return Math.log2(value) % 1 === 0;
}
function decodeImage(src, flipY) {
	return new Promise((resolve, reject) => {
		if (isCreateImageBitmap()) fetch(src, { mode: "cors" }).then((r) => r.blob()).then((b) => createImageBitmap(b, {
			imageOrientation: flipY ? "flipY" : "none",
			premultiplyAlpha: "none"
		})).then(resolve).catch((err) => reject(err));
		else {
			const img = new Image();
			img.crossOrigin = "";
			img.src = src;
			img.onerror = ({ type }) => reject(`${type}: Loading image`);
			img.onload = () => resolve(img);
		}
	});
}
function isCreateImageBitmap() {
	if (!navigator.userAgent.toLowerCase().includes("chrome")) return false;
	try {
		createImageBitmap;
	} catch (e) {
		return false;
	}
	return true;
}
//#endregion
//#region node_modules/ogl/src/extras/GLTFAnimation.js
var tmpVec3A = /* @__PURE__ */ new Vec3();
var tmpVec3B = /* @__PURE__ */ new Vec3();
var tmpVec3C = /* @__PURE__ */ new Vec3();
var tmpVec3D = /* @__PURE__ */ new Vec3();
var tmpQuatA = /* @__PURE__ */ new Quat();
var tmpQuatB = /* @__PURE__ */ new Quat();
var tmpQuatC = /* @__PURE__ */ new Quat();
var tmpQuatD = /* @__PURE__ */ new Quat();
var GLTFAnimation = class {
	constructor(data, weight = 1) {
		this.data = data;
		this.elapsed = 0;
		this.weight = weight;
		this.loop = true;
		this.startTime = data.reduce((a, { times }) => Math.min(a, times[0]), Infinity);
		this.endTime = data.reduce((a, { times }) => Math.max(a, times[times.length - 1]), 0);
		this.duration = this.endTime - this.startTime;
	}
	update(totalWeight = 1, isSet) {
		const weight = isSet ? 1 : this.weight / totalWeight;
		const elapsed = !this.duration ? 0 : (this.loop ? this.elapsed % this.duration : Math.min(this.elapsed, this.duration - .001)) + this.startTime;
		this.data.forEach(({ node, transform, interpolation, times, values }) => {
			if (!this.duration) {
				let val = tmpVec3A;
				let size = 3;
				if (transform === "quaternion") {
					val = tmpQuatA;
					size = 4;
				}
				val.fromArray(values, 0);
				if (size === 4) node[transform].slerp(val, weight);
				else node[transform].lerp(val, weight);
				return;
			}
			const prevIndex = Math.max(1, times.findIndex((t) => t > elapsed)) - 1;
			const nextIndex = prevIndex + 1;
			let alpha = (elapsed - times[prevIndex]) / (times[nextIndex] - times[prevIndex]);
			if (interpolation === "STEP") alpha = 0;
			let prevVal = tmpVec3A;
			let prevTan = tmpVec3B;
			let nextTan = tmpVec3C;
			let nextVal = tmpVec3D;
			let size = 3;
			if (transform === "quaternion") {
				prevVal = tmpQuatA;
				prevTan = tmpQuatB;
				nextTan = tmpQuatC;
				nextVal = tmpQuatD;
				size = 4;
			}
			if (interpolation === "CUBICSPLINE") {
				prevVal.fromArray(values, prevIndex * size * 3 + size * 1);
				prevTan.fromArray(values, prevIndex * size * 3 + size * 2);
				nextTan.fromArray(values, nextIndex * size * 3 + size * 0);
				nextVal.fromArray(values, nextIndex * size * 3 + size * 1);
				prevVal = this.cubicSplineInterpolate(alpha, prevVal, prevTan, nextTan, nextVal);
				if (size === 4) prevVal.normalize();
			} else {
				prevVal.fromArray(values, prevIndex * size);
				nextVal.fromArray(values, nextIndex * size);
				if (size === 4) prevVal.slerp(nextVal, alpha);
				else prevVal.lerp(nextVal, alpha);
			}
			if (size === 4) node[transform].slerp(prevVal, weight);
			else node[transform].lerp(prevVal, weight);
		});
	}
	cubicSplineInterpolate(t, prevVal, prevTan, nextTan, nextVal) {
		const t2 = t * t;
		const t3 = t2 * t;
		const s2 = 3 * t2 - 2 * t3;
		const s3 = t3 - t2;
		const s0 = 1 - s2;
		const s1 = s3 - t2 + t;
		for (let i = 0; i < prevVal.length; i++) prevVal[i] = s0 * prevVal[i] + s1 * (1 - t) * prevTan[i] + s2 * nextVal[i] + s3 * t * nextTan[i];
		return prevVal;
	}
};
//#endregion
//#region node_modules/ogl/src/extras/GLTFSkin.js
var tempMat4 = /* @__PURE__ */ new Mat4();
var identity = /* @__PURE__ */ new Mat4();
var GLTFSkin = class extends Mesh {
	constructor(gl, { skeleton, geometry, program, mode = gl.TRIANGLES } = {}) {
		super(gl, {
			geometry,
			program,
			mode
		});
		this.skeleton = skeleton;
		this.program = program;
		this.createBoneTexture();
	}
	createBoneTexture() {
		if (!this.skeleton.joints.length) return;
		const size = Math.max(4, Math.pow(2, Math.ceil(Math.log(Math.sqrt(this.skeleton.joints.length * 4)) / Math.LN2)));
		this.boneMatrices = new Float32Array(size * size * 4);
		this.boneTextureSize = size;
		this.boneTexture = new Texture(this.gl, {
			image: this.boneMatrices,
			generateMipmaps: false,
			type: this.gl.FLOAT,
			internalFormat: this.gl.renderer.isWebgl2 ? this.gl.RGBA32F : this.gl.RGBA,
			minFilter: this.gl.NEAREST,
			magFilter: this.gl.NEAREST,
			flipY: false,
			width: size
		});
	}
	updateUniforms() {
		this.skeleton.joints.forEach((bone, i) => {
			tempMat4.multiply(bone.worldMatrix, bone.bindInverse);
			this.boneMatrices.set(tempMat4, i * 16);
		});
		this.boneTexture.needsUpdate = true;
		this.program.uniforms.boneTexture.value = this.boneTexture;
		this.program.uniforms.boneTextureSize.value = this.boneTextureSize;
	}
	draw({ camera } = {}) {
		if (!this.program.uniforms.boneTexture) Object.assign(this.program.uniforms, {
			boneTexture: { value: this.boneTexture },
			boneTextureSize: { value: this.boneTextureSize }
		});
		this.updateUniforms();
		const _worldMatrix = this.worldMatrix;
		this.worldMatrix = identity;
		super.draw({ camera });
		this.worldMatrix = _worldMatrix;
	}
};
//#endregion
//#region node_modules/ogl/src/extras/InstancedMesh.js
var InstancedMesh = class extends Mesh {
	constructor(...args) {
		super(...args);
		this.frustumCulled = false;
		this.isInstancedMesh = true;
	}
	addFrustumCull() {
		this.instanceTransforms = null;
		this.instanceLightmapScaleOffset = null;
		this.totalInstanceCount = 0;
		this.frustumCullFunction = null;
		this.instanceRenderList = null;
		if (!this.geometry.attributes.instanceMatrix) console.error(`mesh ${this.name ? `"${this.name}" ` : ``}missing instanceMatrix attribute; unable to frustum cull`);
		const matrixData = this.geometry.attributes.instanceMatrix.data;
		this.instanceTransforms = [];
		for (let i = 0, j = 0; i < matrixData.length; i += 16, j++) {
			const transform = new Transform();
			transform.index = j;
			transform.matrix.fromArray(matrixData, i);
			transform.decompose();
			this.instanceTransforms.push(transform);
			transform.setParent(this.parent);
		}
		this.totalInstanceCount = this.instanceTransforms.length;
		if (!!this.geometry.attributes.lightmapScaleOffset) {
			const lightmapData = this.geometry.attributes.lightmapScaleOffset.data;
			for (let i = 0, j = 0; i < lightmapData.length; i += 4, j++) this.instanceTransforms[j].lightmapData = new Vec4().fromArray(lightmapData, i);
		}
		this.frustumCullFunction = ({ camera }) => {
			this.instanceRenderList = [];
			this.instanceTransforms.forEach((transform) => {
				if (!camera.frustumIntersectsMesh(this, transform.worldMatrix)) return;
				this.instanceRenderList.push(transform);
			});
			this.instanceRenderList.forEach((transform, i) => {
				transform.matrix.toArray(this.geometry.attributes.instanceMatrix.data, i * 16);
				if (transform.lightmapData) {
					transform.lightmapData.toArray(this.geometry.attributes.lightmapScaleOffset.data, i * 4);
					this.geometry.attributes.lightmapScaleOffset.needsUpdate = true;
				}
			});
			this.geometry.instancedCount = this.instanceRenderList.length;
			this.geometry.attributes.instanceMatrix.needsUpdate = true;
		};
		this.onBeforeRender(this.frustumCullFunction);
	}
	removeFrustumCull() {
		this.offBeforeRender(this.frustumCullFunction);
		this.geometry.instancedCount = this.totalInstanceCount;
		this.instanceTransforms.forEach((transform, i) => {
			transform.matrix.toArray(this.geometry.attributes.instanceMatrix.data, i * 16);
			if (transform.lightmapData) {
				transform.lightmapData.toArray(this.geometry.attributes.lightmapScaleOffset.data, i * 4);
				this.geometry.attributes.lightmapScaleOffset.needsUpdate = true;
			}
		});
		this.geometry.attributes.instanceMatrix.needsUpdate = true;
	}
};
//#endregion
//#region node_modules/ogl/src/extras/GLTFLoader.js
var TYPE_ARRAY = {
	5120: Int8Array,
	5121: Uint8Array,
	5122: Int16Array,
	5123: Uint16Array,
	5125: Uint32Array,
	5126: Float32Array,
	"image/jpeg": Uint8Array,
	"image/png": Uint8Array,
	"image/webp": Uint8Array
};
var TYPE_SIZE = {
	SCALAR: 1,
	VEC2: 2,
	VEC3: 3,
	VEC4: 4,
	MAT2: 4,
	MAT3: 9,
	MAT4: 16
};
var ATTRIBUTES = {
	POSITION: "position",
	NORMAL: "normal",
	TANGENT: "tangent",
	TEXCOORD_0: "uv",
	TEXCOORD_1: "uv2",
	COLOR_0: "color",
	WEIGHTS_0: "skinWeight",
	JOINTS_0: "skinIndex"
};
var TRANSFORMS = {
	translation: "position",
	rotation: "quaternion",
	scale: "scale"
};
var GLTFLoader = class {
	static setDracoManager(manager) {
		this.dracoManager = manager;
	}
	static setBasisManager(manager) {
		this.basisManager = manager;
	}
	static async load(gl, src) {
		const dir = src.split("/").slice(0, -1).join("/") + "/";
		const desc = await this.parseDesc(src);
		return this.parse(gl, desc, dir);
	}
	static async parse(gl, desc, dir) {
		if (desc.asset === void 0 || desc.asset.version[0] < 2) console.warn("Only GLTF >=2.0 supported. Attempting to parse.");
		if (desc.extensionsRequired?.includes("KHR_draco_mesh_compression") && !this.dracoManager) console.warn("KHR_draco_mesh_compression extension required but no manager supplied. Use .setDracoManager()");
		if (desc.extensionsRequired?.includes("KHR_texture_basisu") && !this.basisManager) console.warn("KHR_texture_basisu extension required but no manager supplied. Use .setBasisManager()");
		const buffers = await this.loadBuffers(desc, dir);
		gl.renderer.bindVertexArray(null);
		const bufferViews = this.parseBufferViews(gl, desc, buffers);
		const images = await this.parseImages(gl, desc, dir, bufferViews);
		const textures = this.parseTextures(gl, desc, images);
		const materials = this.parseMaterials(gl, desc, textures);
		const skins = this.parseSkins(gl, desc, bufferViews);
		const meshes = await this.parseMeshes(gl, desc, bufferViews, materials, skins);
		const [nodes, cameras] = this.parseNodes(gl, desc, meshes, skins, images);
		this.populateSkins(skins, nodes);
		const animations = this.parseAnimations(gl, desc, nodes, bufferViews);
		const scenes = this.parseScenes(desc, nodes);
		const scene = scenes[desc.scene];
		const lights = this.parseLights(gl, desc, nodes, scenes);
		for (let i = nodes.length; i >= 0; i--) if (!nodes[i]) nodes.splice(i, 1);
		return {
			json: desc,
			buffers,
			bufferViews,
			cameras,
			images,
			textures,
			materials,
			meshes,
			nodes,
			lights,
			animations,
			scenes,
			scene
		};
	}
	static parseDesc(src) {
		return fetch(src, { mode: "cors" }).then((res) => res.arrayBuffer()).then((data) => {
			const textDecoder = new TextDecoder();
			if (textDecoder.decode(new Uint8Array(data, 0, 4)) === "glTF") return this.unpackGLB(data);
			else return JSON.parse(textDecoder.decode(data));
		});
	}
	static unpackGLB(glb) {
		const header = new Uint32Array(glb, 0, 3);
		if (header[0] !== 1179937895) throw new Error("Invalid glTF asset.");
		else if (header[1] !== 2) throw new Error(`Unsupported glTF binary version, "${header[1]}".`);
		const jsonChunkHeader = new Uint32Array(glb, 12, 2);
		const jsonByteOffset = 20;
		const jsonByteLength = jsonChunkHeader[0];
		if (jsonChunkHeader[1] !== 1313821514) throw new Error("Unexpected GLB layout.");
		const jsonText = new TextDecoder().decode(glb.slice(jsonByteOffset, jsonByteOffset + jsonByteLength));
		const json = JSON.parse(jsonText);
		if (jsonByteOffset + jsonByteLength === glb.byteLength) return json;
		const binaryChunkHeader = new Uint32Array(glb, jsonByteOffset + jsonByteLength, 2);
		if (binaryChunkHeader[1] !== 5130562) throw new Error("Unexpected GLB layout.");
		const binaryByteOffset = jsonByteOffset + jsonByteLength + 8;
		const binaryByteLength = binaryChunkHeader[0];
		const binary = glb.slice(binaryByteOffset, binaryByteOffset + binaryByteLength);
		json.buffers[0].binary = binary;
		return json;
	}
	static resolveURI(uri, dir) {
		if (typeof uri !== "string" || uri === "") return "";
		if (/^https?:\/\//i.test(dir) && /^\//.test(uri)) dir = dir.replace(/(^https?:\/\/[^\/]+).*/i, "$1");
		if (/^(https?:)?\/\//i.test(uri)) return uri;
		if (/^data:.*,.*$/i.test(uri)) return uri;
		if (/^blob:.*$/i.test(uri)) return uri;
		return dir + uri;
	}
	static loadBuffers(desc, dir) {
		if (!desc.buffers) return null;
		return Promise.all(desc.buffers.map((buffer) => {
			if (buffer.binary) return buffer.binary;
			const uri = this.resolveURI(buffer.uri, dir);
			return fetch(uri, { mode: "cors" }).then((res) => res.arrayBuffer());
		}));
	}
	static parseBufferViews(gl, desc, buffers) {
		if (!desc.bufferViews) return null;
		const bufferViews = desc.bufferViews;
		desc.meshes && desc.meshes.forEach(({ primitives }) => {
			primitives.forEach(({ attributes, indices, extensions }) => {
				for (const attr in attributes) {
					const accessor = desc.accessors[attributes[attr]];
					if (accessor.bufferView === void 0 && !!extensions) {
						if (extensions.KHR_draco_mesh_compression) {
							accessor.bufferView = extensions.KHR_draco_mesh_compression.bufferView;
							bufferViews[accessor.bufferView].isDraco = true;
						}
					}
					bufferViews[accessor.bufferView].isAttribute = true;
				}
				if (indices !== void 0) {
					const accessor = desc.accessors[indices];
					if (accessor.bufferView === void 0 && !!extensions) {
						if (extensions.KHR_draco_mesh_compression) {
							accessor.bufferView = extensions.KHR_draco_mesh_compression.bufferView;
							bufferViews[accessor.bufferView].isDraco = true;
						}
					}
					bufferViews[accessor.bufferView].isAttribute = true;
					bufferViews[accessor.bufferView].target = gl.ELEMENT_ARRAY_BUFFER;
				}
			});
		});
		desc.accessors.forEach(({ bufferView: bufferViewIndex, componentType }) => {
			if (bufferViewIndex === void 0) return;
			bufferViews[bufferViewIndex].componentType = componentType;
		});
		desc.images && desc.images.forEach(({ uri, bufferView: bufferViewIndex, mimeType }) => {
			if (bufferViewIndex === void 0) return;
			bufferViews[bufferViewIndex].mimeType = mimeType;
		});
		bufferViews.forEach(({ buffer: bufferIndex, byteOffset = 0, byteLength, byteStride, target = gl.ARRAY_BUFFER, name, extensions, extras, componentType, mimeType, isAttribute, isDraco }, i) => {
			bufferViews[i].data = buffers[bufferIndex].slice(byteOffset, byteOffset + byteLength);
			if (!isAttribute || isDraco) return;
			const buffer = gl.createBuffer();
			gl.bindBuffer(target, buffer);
			gl.renderer.state.boundBuffer = buffer;
			gl.bufferData(target, bufferViews[i].data, gl.STATIC_DRAW);
			bufferViews[i].buffer = buffer;
		});
		return bufferViews;
	}
	static parseImages(gl, desc, dir, bufferViews) {
		if (!desc.images) return null;
		return Promise.all(desc.images.map(async ({ uri, bufferView: bufferViewIndex, mimeType, name }) => {
			if (mimeType === "image/ktx2") {
				const { data } = bufferViews[bufferViewIndex];
				return await this.basisManager.parseTexture(data);
			}
			const image = new Image();
			image.name = name;
			if (uri) image.src = this.resolveURI(uri, dir);
			else if (bufferViewIndex !== void 0) {
				const { data } = bufferViews[bufferViewIndex];
				const blob = new Blob([data], { type: mimeType });
				image.src = URL.createObjectURL(blob);
			}
			image.ready = new Promise((res) => {
				image.onload = () => res();
			});
			return image;
		}));
	}
	static parseTextures(gl, desc, images) {
		if (!desc.textures) return null;
		return desc.textures.map((textureInfo) => this.createTexture(gl, desc, images, textureInfo));
	}
	static createTexture(gl, desc, images, { sampler: samplerIndex, source: sourceIndex, name, extensions, extras }) {
		if (sourceIndex === void 0 && !!extensions) {
			if (extensions.EXT_texture_webp) sourceIndex = extensions.EXT_texture_webp.source;
			if (extensions.KHR_texture_basisu) sourceIndex = extensions.KHR_texture_basisu.source;
		}
		const image = images[sourceIndex];
		if (image.texture) return image.texture;
		const options = {
			flipY: false,
			wrapS: gl.REPEAT,
			wrapT: gl.REPEAT
		};
		const sampler = samplerIndex !== void 0 ? desc.samplers[samplerIndex] : null;
		if (sampler) [
			"magFilter",
			"minFilter",
			"wrapS",
			"wrapT"
		].forEach((prop) => {
			if (sampler[prop]) options[prop] = sampler[prop];
		});
		if (image.isBasis) {
			options.image = image;
			options.internalFormat = image.internalFormat;
			if (image.isCompressedTexture) {
				options.generateMipmaps = false;
				if (image.length > 1) this.minFilter = gl.NEAREST_MIPMAP_LINEAR;
			}
			const texture = new Texture(gl, options);
			texture.name = name;
			image.texture = texture;
			return texture;
		}
		const texture = new Texture(gl, options);
		texture.name = name;
		image.texture = texture;
		image.ready.then(() => {
			texture.image = image;
		});
		return texture;
	}
	static parseMaterials(gl, desc, textures) {
		if (!desc.materials) return null;
		return desc.materials.map(({ name, extensions, extras, pbrMetallicRoughness = {}, normalTexture, occlusionTexture, emissiveTexture, emissiveFactor = [
			0,
			0,
			0
		], alphaMode = "OPAQUE", alphaCutoff = .5, doubleSided = false }) => {
			const { baseColorFactor = [
				1,
				1,
				1,
				1
			], baseColorTexture, metallicFactor = 1, roughnessFactor = 1, metallicRoughnessTexture } = pbrMetallicRoughness;
			if (baseColorTexture) baseColorTexture.texture = textures[baseColorTexture.index];
			if (normalTexture) normalTexture.texture = textures[normalTexture.index];
			if (metallicRoughnessTexture) metallicRoughnessTexture.texture = textures[metallicRoughnessTexture.index];
			if (occlusionTexture) occlusionTexture.texture = textures[occlusionTexture.index];
			if (emissiveTexture) emissiveTexture.texture = textures[emissiveTexture.index];
			return {
				name,
				extensions,
				extras,
				baseColorFactor,
				baseColorTexture,
				metallicFactor,
				roughnessFactor,
				metallicRoughnessTexture,
				normalTexture,
				occlusionTexture,
				emissiveTexture,
				emissiveFactor,
				alphaMode,
				alphaCutoff,
				doubleSided
			};
		});
	}
	static parseSkins(gl, desc, bufferViews) {
		if (!desc.skins) return null;
		return desc.skins.map(({ inverseBindMatrices, skeleton, joints }) => {
			return {
				inverseBindMatrices: this.parseAccessor(inverseBindMatrices, desc, bufferViews),
				skeleton,
				joints
			};
		});
	}
	static parseMeshes(gl, desc, bufferViews, materials, skins) {
		if (!desc.meshes) return null;
		return Promise.all(desc.meshes.map(async ({ primitives, weights, name, extensions, extras = {} }, meshIndex) => {
			let numInstances = 0;
			let skinIndices = [];
			let isLightmap = false;
			desc.nodes && desc.nodes.forEach(({ mesh, skin, extras }) => {
				if (mesh === meshIndex) {
					numInstances++;
					if (skin !== void 0) skinIndices.push(skin);
					if (extras && extras.lightmap_scale_offset) isLightmap = true;
				}
			});
			if (!!skinIndices.length) {
				primitives = await Promise.all(skinIndices.map(async (skinIndex) => {
					return (await this.parsePrimitives(gl, primitives, desc, bufferViews, materials, 1, isLightmap)).map(({ geometry, program, mode }) => {
						const mesh = new GLTFSkin(gl, {
							skeleton: skins[skinIndex],
							geometry,
							program,
							mode
						});
						mesh.name = name;
						mesh.extras = extras;
						if (extensions) mesh.extensions = extensions;
						mesh.frustumCulled = false;
						return mesh;
					});
				}));
				primitives.instanceCount = 0;
				primitives.numInstances = numInstances;
			} else primitives = (await this.parsePrimitives(gl, primitives, desc, bufferViews, materials, numInstances, isLightmap)).map(({ geometry, program, mode }) => {
				const mesh = new (geometry.attributes.instanceMatrix ? InstancedMesh : Mesh)(gl, {
					geometry,
					program,
					mode
				});
				mesh.name = name;
				mesh.extras = extras;
				if (extensions) mesh.extensions = extensions;
				mesh.numInstances = numInstances;
				return mesh;
			});
			return {
				primitives,
				weights,
				name
			};
		}));
	}
	static parsePrimitives(gl, primitives, desc, bufferViews, materials, numInstances, isLightmap) {
		return Promise.all(primitives.map(async ({ attributes, indices, material: materialIndex, mode = 4, targets, extensions, extras }) => {
			const program = new NormalProgram(gl);
			if (materialIndex !== void 0) program.gltfMaterial = materials[materialIndex];
			const geometry = new Geometry(gl);
			if (extras) geometry.extras = extras;
			if (extensions) geometry.extensions = extensions;
			if (extensions && extensions.KHR_draco_mesh_compression) {
				const bufferViewIndex = extensions.KHR_draco_mesh_compression.bufferView;
				const gltfAttributeMap = extensions.KHR_draco_mesh_compression.attributes;
				const attributeMap = {};
				const attributeTypeMap = {};
				const attributeTypeNameMap = {};
				const attributeNormalizedMap = {};
				for (const attr in attributes) {
					const accessor = desc.accessors[attributes[attr]];
					const attributeName = ATTRIBUTES[attr];
					attributeMap[attributeName] = gltfAttributeMap[attr];
					attributeTypeMap[attributeName] = accessor.componentType;
					attributeTypeNameMap[attributeName] = TYPE_ARRAY[accessor.componentType].name;
					attributeNormalizedMap[attributeName] = accessor.normalized === true;
				}
				const { data } = bufferViews[bufferViewIndex];
				const geometryData = await this.dracoManager.decodeGeometry(data, {
					attributeIds: attributeMap,
					attributeTypes: attributeTypeNameMap
				});
				for (let i = 0; i < geometryData.attributes.length; i++) {
					const result = geometryData.attributes[i];
					const name = result.name;
					const data = result.array;
					const size = result.itemSize;
					const type = attributeTypeMap[name];
					const normalized = attributeNormalizedMap[name];
					const buffer = gl.createBuffer();
					gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
					gl.renderer.state.boundBuffer = buffer;
					gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
					geometry.addAttribute(name, {
						data,
						size,
						type,
						normalized,
						buffer
					});
				}
				if (geometryData.index) {
					const data = geometryData.index.array;
					const size = geometryData.index.itemSize;
					const buffer = gl.createBuffer();
					gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, buffer);
					gl.renderer.state.boundBuffer = buffer;
					gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, data, gl.STATIC_DRAW);
					geometry.addAttribute("index", {
						data,
						size,
						type: 5125,
						normalized: false,
						buffer
					});
				}
			} else {
				for (const attr in attributes) geometry.addAttribute(ATTRIBUTES[attr], this.parseAccessor(attributes[attr], desc, bufferViews));
				if (indices !== void 0) geometry.addAttribute("index", this.parseAccessor(indices, desc, bufferViews));
			}
			if (numInstances > 1) geometry.addAttribute("instanceMatrix", {
				instanced: 1,
				size: 16,
				data: new Float32Array(numInstances * 16)
			});
			if (isLightmap) geometry.addAttribute("lightmapScaleOffset", {
				instanced: 1,
				size: 4,
				data: new Float32Array(numInstances * 4)
			});
			return {
				geometry,
				program,
				mode
			};
		}));
	}
	static parseAccessor(index, desc, bufferViews) {
		const { bufferView: bufferViewIndex, byteOffset = 0, componentType, normalized = false, count, type, min, max, sparse } = desc.accessors[index];
		const { data, buffer, byteOffset: bufferByteOffset = 0, byteStride = 0, target } = bufferViews[bufferViewIndex];
		const size = TYPE_SIZE[type];
		const TypeArray = TYPE_ARRAY[componentType];
		const componentStride = byteStride / TypeArray.BYTES_PER_ELEMENT;
		const isInterleaved = !!byteStride && componentStride !== size;
		let filteredData;
		if (isInterleaved) {
			const typedData = new TypeArray(data, byteOffset);
			filteredData = new TypeArray(count * size);
			for (let i = 0; i < count; i++) {
				const start = componentStride * i;
				const end = start + size;
				filteredData.set(typedData.slice(start, end), i * size);
			}
		} else filteredData = new TypeArray(data, byteOffset, count * size);
		return {
			data: filteredData,
			size,
			type: componentType,
			normalized,
			buffer,
			stride: byteStride,
			offset: byteOffset,
			count,
			min,
			max
		};
	}
	static parseNodes(gl, desc, meshes, skins, images) {
		if (!desc.nodes) return null;
		const cameras = [];
		const nodes = desc.nodes.map(({ camera, children, skin: skinIndex, matrix, mesh: meshIndex, rotation, scale, translation, weights, name, extensions, extras }) => {
			const isCamera = camera !== void 0;
			const node = isCamera ? new Camera(gl) : new Transform();
			if (isCamera) {
				const cameraOpts = desc.cameras[camera];
				if (cameraOpts.type === "perspective") {
					const { yfov: fov, znear: near, zfar: far } = cameraOpts.perspective;
					node.perspective({
						fov: fov * (180 / Math.PI),
						near,
						far
					});
				} else {
					const { xmag, ymag, znear: near, zfar: far } = cameraOpts.orthographic;
					node.orthographic({
						near,
						far,
						left: -xmag,
						right: xmag,
						top: -ymag,
						bottom: ymag
					});
				}
				cameras.push(node);
			}
			if (name) node.name = name;
			if (extras) node.extras = extras;
			if (extensions) node.extensions = extensions;
			if (extras && extras.lightmapTexture !== void 0) extras.lightmapTexture.texture = this.createTexture(gl, desc, images, { source: extras.lightmapTexture.index });
			if (matrix) {
				node.matrix.copy(matrix);
				node.decompose();
			} else {
				if (rotation) node.quaternion.copy(rotation);
				if (scale) node.scale.copy(scale);
				if (translation) node.position.copy(translation);
				node.updateMatrix();
			}
			let isInstanced = false;
			let isFirstInstance = true;
			let isInstancedMatrix = false;
			let isSkin = skinIndex !== void 0;
			if (meshIndex !== void 0) {
				if (isSkin) {
					meshes[meshIndex].primitives[meshes[meshIndex].primitives.instanceCount].forEach((mesh) => {
						if (extras) Object.assign(mesh.extras, extras);
						mesh.setParent(node);
					});
					meshes[meshIndex].primitives.instanceCount++;
					if (meshes[meshIndex].primitives.instanceCount === meshes[meshIndex].primitives.numInstances) {
						delete meshes[meshIndex].primitives.numInstances;
						delete meshes[meshIndex].primitives.instanceCount;
					}
				} else meshes[meshIndex].primitives.forEach((mesh) => {
					if (extras) Object.assign(mesh.extras, extras);
					if (mesh.geometry.isInstanced) {
						isInstanced = true;
						if (!mesh.instanceCount) mesh.instanceCount = 0;
						else isFirstInstance = false;
						if (mesh.geometry.attributes.instanceMatrix) {
							isInstancedMatrix = true;
							node.matrix.toArray(mesh.geometry.attributes.instanceMatrix.data, mesh.instanceCount * 16);
						}
						if (mesh.geometry.attributes.lightmapScaleOffset) mesh.geometry.attributes.lightmapScaleOffset.data.set(extras.lightmap_scale_offset, mesh.instanceCount * 4);
						mesh.instanceCount++;
						if (mesh.instanceCount === mesh.numInstances) {
							delete mesh.numInstances;
							delete mesh.instanceCount;
							if (mesh.geometry.attributes.instanceMatrix) mesh.geometry.attributes.instanceMatrix.needsUpdate = true;
							if (mesh.geometry.attributes.lightmapScaleOffset) mesh.geometry.attributes.lightmapScaleOffset.needsUpdate = true;
						}
					}
					if (isInstanced) {
						if (isFirstInstance) mesh.setParent(node);
					} else mesh.setParent(node);
				});
			}
			if (isInstancedMatrix) {
				if (!isFirstInstance) return null;
				node.matrix.identity();
				node.decompose();
			}
			return node;
		});
		desc.nodes.forEach(({ children = [] }, i) => {
			children.forEach((childIndex) => {
				if (!nodes[childIndex]) return;
				nodes[childIndex].setParent(nodes[i]);
			});
		});
		meshes.forEach(({ primitives }, i) => {
			primitives.forEach((primitive, i) => {
				if (primitive.isInstancedMesh) primitive.addFrustumCull();
			});
		});
		return [nodes, cameras];
	}
	static populateSkins(skins, nodes) {
		if (!skins) return;
		skins.forEach((skin) => {
			skin.joints = skin.joints.map((i, index) => {
				const joint = nodes[i];
				joint.skin = skin;
				joint.bindInverse = new Mat4(...skin.inverseBindMatrices.data.slice(index * 16, (index + 1) * 16));
				return joint;
			});
			if (skin.skeleton) skin.skeleton = nodes[skin.skeleton];
		});
	}
	static parseAnimations(gl, desc, nodes, bufferViews) {
		if (!desc.animations) return null;
		return desc.animations.map(({ channels, samplers, name }, animationIndex) => {
			return {
				name,
				animation: new GLTFAnimation(channels.map(({ sampler: samplerIndex, target }) => {
					const { input: inputIndex, interpolation = "LINEAR", output: outputIndex } = samplers[samplerIndex];
					const { node: nodeIndex, path } = target;
					const node = nodes[nodeIndex];
					const transform = TRANSFORMS[path];
					const times = this.parseAccessor(inputIndex, desc, bufferViews).data;
					const values = this.parseAccessor(outputIndex, desc, bufferViews).data;
					if (!node.animations) node.animations = [];
					if (!node.animations.includes(animationIndex)) node.animations.push(animationIndex);
					return {
						node,
						transform,
						interpolation,
						times,
						values
					};
				}))
			};
		});
	}
	static parseScenes(desc, nodes) {
		if (!desc.scenes) return null;
		return desc.scenes.map(({ nodes: nodesIndices = [], name, extensions, extras }) => {
			const scene = nodesIndices.reduce((map, i) => {
				if (nodes[i]) map.push(nodes[i]);
				return map;
			}, []);
			scene.extras = extras;
			return scene;
		});
	}
	static parseLights(gl, desc, nodes, scenes) {
		const lights = {
			directional: [],
			point: [],
			spot: []
		};
		scenes.forEach((scene) => scene.forEach((node) => node.updateMatrixWorld()));
		const lightsDescArray = desc.extensions?.KHR_lights_punctual?.lights || [];
		nodes.forEach((node) => {
			if (!node?.extensions?.KHR_lights_punctual) return;
			const lightIndex = node.extensions.KHR_lights_punctual.light;
			const lightDesc = lightsDescArray[lightIndex];
			const light = {
				name: lightDesc.name || "",
				color: { value: new Vec3().set(lightDesc.color || 1) }
			};
			if (lightDesc.intensity !== void 0) light.color.value.multiply(lightDesc.intensity);
			switch (lightDesc.type) {
				case "directional":
					light.direction = { value: new Vec3(0, 0, 1).transformDirection(node.worldMatrix) };
					break;
				case "point":
					light.position = { value: new Vec3().applyMatrix4(node.worldMatrix) };
					light.distance = { value: lightDesc.range };
					light.decay = { value: 2 };
					break;
				case "spot": Object.assign(light, lightDesc);
			}
			lights[lightDesc.type].push(light);
		});
		return lights;
	}
};
//#endregion
//#region node_modules/ogl/src/extras/DracoManager.js
var id$1 = 0;
var DracoManager = class {
	constructor(workerSrc) {
		this.onMessage = this.onMessage.bind(this);
		this.queue = /* @__PURE__ */ new Map();
		this.initWorker(workerSrc);
	}
	initWorker(workerSrc) {
		this.worker = new Worker(workerSrc);
		this.worker.onmessage = this.onMessage;
	}
	onMessage({ data }) {
		const { id, error, geometry } = data;
		if (error) {
			console.log(error, id);
			return;
		}
		const geometryResolve = this.queue.get(id);
		this.queue.delete(id);
		geometryResolve(geometry);
	}
	decodeGeometry(buffer, config) {
		id$1++;
		this.worker.postMessage({
			id: id$1,
			buffer,
			config
		});
		let geometryResolve;
		const promise = new Promise((res) => geometryResolve = res);
		this.queue.set(id$1, geometryResolve);
		return promise;
	}
};
//#endregion
//#region node_modules/ogl/src/extras/BasisManager.js
var supportedFormat;
var id = 0;
var BasisManager = class {
	constructor(workerSrc, gl) {
		if (!supportedFormat) supportedFormat = this.getSupportedFormat(gl);
		this.onMessage = this.onMessage.bind(this);
		this.queue = /* @__PURE__ */ new Map();
		this.initWorker(workerSrc);
	}
	getSupportedFormat(gl = document.createElement("canvas").getContext("webgl")) {
		if (!!gl.getExtension("WEBGL_compressed_texture_astc")) return "astc";
		else if (!!gl.getExtension("EXT_texture_compression_bptc")) return "bptc";
		else if (!!gl.getExtension("WEBGL_compressed_texture_s3tc")) return "s3tc";
		else if (!!gl.getExtension("WEBGL_compressed_texture_etc1")) return "etc1";
		else if (!!gl.getExtension("WEBGL_compressed_texture_pvrtc") || !!gl.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc")) return "pvrtc";
		return "none";
	}
	initWorker(workerSrc) {
		this.worker = new Worker(workerSrc);
		this.worker.onmessage = this.onMessage;
	}
	onMessage({ data }) {
		const { id, error, image } = data;
		if (error) {
			console.log(error, id);
			return;
		}
		const textureResolve = this.queue.get(id);
		this.queue.delete(id);
		image.isBasis = true;
		textureResolve(image);
	}
	parseTexture(buffer) {
		id++;
		this.worker.postMessage({
			id,
			buffer,
			supportedFormat
		});
		let textureResolve;
		const promise = new Promise((res) => textureResolve = res);
		this.queue.set(id, textureResolve);
		return promise;
	}
};
//#endregion
//#region node_modules/ogl/src/extras/WireMesh.js
var WireMesh = class extends Mesh {
	constructor(gl, { geometry, wireColor = new Color(0, .75, .5), ...meshProps } = {}) {
		const wireProgram = new Program(gl, {
			vertex: vertex$4,
			fragment: fragment$4,
			uniforms: { wireColor: { value: wireColor } }
		});
		const positionArray = geometry.attributes.position.data;
		const indices = [];
		const hashSet = /* @__PURE__ */ new Set();
		function addUniqueIndices(idx) {
			for (let i = 0; i < idx.length; i += 2) if (isUniqueEdgePosition(idx[i] * 3, idx[i + 1] * 3, positionArray, hashSet)) indices.push(idx[i], idx[i + 1]);
		}
		if (geometry.attributes.index) {
			const idata = geometry.attributes.index.data;
			for (let i = 0; i < idata.length; i += 3) addUniqueIndices([
				idata[i],
				idata[i + 1],
				idata[i + 1],
				idata[i + 2],
				idata[i + 2],
				idata[i]
			]);
		} else {
			const numVertices = Math.floor(positionArray.length / 3);
			for (let i = 0; i < numVertices; i += 3) addUniqueIndices([
				i,
				i + 1,
				i + 1,
				i + 2,
				i + 2,
				i
			]);
		}
		const indicesTyped = indices.length > 65536 ? new Uint32Array(indices) : new Uint16Array(indices);
		const wireGeometry = new Geometry(gl, {
			position: { ...geometry.attributes.position },
			index: { data: indicesTyped }
		});
		super(gl, {
			...meshProps,
			mode: gl.LINES,
			geometry: wireGeometry,
			program: wireProgram
		});
	}
};
function isUniqueEdgePosition(start, end, pos, hashSet) {
	const hash1 = [
		pos[start],
		pos[start + 1],
		pos[start + 2],
		pos[end],
		pos[end + 1],
		pos[end + 2]
	].join("#");
	const hash2 = [
		pos[end],
		pos[end + 1],
		pos[end + 2],
		pos[start],
		pos[start + 1],
		pos[start + 2]
	].join("#");
	const oldSize = hashSet.size;
	hashSet.add(hash1);
	hashSet.add(hash2);
	return hashSet.size - oldSize === 2;
}
var vertex$4 = `
attribute vec3 position;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;

void main() {    
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`;
var fragment$4 = `
precision highp float;
uniform vec3 wireColor;

void main() {    
    gl_FragColor = vec4(wireColor, 1.0);
}
`;
//#endregion
//#region node_modules/ogl/src/extras/helpers/AxesHelper.js
var AxesHelper = class extends Mesh {
	constructor(gl, { size = 1, symmetric = false, xColor = new Vec3(.96, .21, .32), yColor = new Vec3(.44, .64, .11), zColor = new Vec3(.18, .52, .89), ...meshProps } = {}) {
		const a = symmetric ? -size : 0;
		const b = size;
		const vertices = new Float32Array([
			a,
			0,
			0,
			b,
			0,
			0,
			0,
			a,
			0,
			0,
			b,
			0,
			0,
			0,
			a,
			0,
			0,
			b
		]);
		const colors = new Float32Array([
			...xColor,
			...xColor,
			...yColor,
			...yColor,
			...zColor,
			...zColor
		]);
		const geometry = new Geometry(gl, {
			position: {
				size: 3,
				data: vertices
			},
			color: {
				size: 3,
				data: colors
			}
		});
		const program = new Program(gl, {
			vertex: vertex$3,
			fragment: fragment$3
		});
		super(gl, {
			...meshProps,
			mode: gl.LINES,
			geometry,
			program
		});
	}
};
var vertex$3 = `
attribute vec3 position;
attribute vec3 color;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;

varying vec3 vColor;

void main() {    
    vColor = color;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`;
var fragment$3 = `
precision highp float;
varying vec3 vColor;

void main() {    
    gl_FragColor = vec4(vColor, 1.0);
}
`;
//#endregion
//#region node_modules/ogl/src/extras/helpers/GridHelper.js
var GridHelper = class extends Mesh {
	constructor(gl, { size = 10, divisions = 10, color = new Vec3(.75, .75, .75), ...meshProps } = {}) {
		const numVertices = (size + 1) * 2 * 2;
		const vertices = new Float32Array(numVertices * 3);
		const hs = size / 2;
		for (let i = 0; i <= divisions; i++) {
			const o = i / divisions * size - hs;
			vertices.set([
				o,
				0,
				-hs,
				o,
				0,
				hs
			], i * 12);
			vertices.set([
				-hs,
				0,
				o,
				hs,
				0,
				o
			], i * 12 + 6);
		}
		const geometry = new Geometry(gl, { position: {
			size: 3,
			data: vertices
		} });
		const program = new Program(gl, {
			vertex: vertex$2,
			fragment: fragment$2,
			uniforms: { color: { value: color } }
		});
		super(gl, {
			...meshProps,
			mode: gl.LINES,
			geometry,
			program
		});
	}
};
var vertex$2 = `
attribute vec3 position;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;

void main() {    
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`;
var fragment$2 = `
precision highp float;
uniform vec3 color;

void main() {    
    gl_FragColor = vec4(color, 1.0);
}
`;
//#endregion
//#region node_modules/ogl/src/extras/helpers/VertexNormalsHelper.js
var VertexNormalsHelper = class extends Mesh {
	constructor(object, { size = .1, color = new Vec3(.86, .16, .86), ...meshProps } = {}) {
		const gl = object.gl;
		const nNormals = object.geometry.attributes.normal.count;
		const positionsArray = new Float32Array(nNormals * 2 * 3);
		const normalsArray = new Float32Array(nNormals * 2 * 3);
		const sizeArray = new Float32Array(nNormals * 2);
		const normalData = object.geometry.attributes.normal.data;
		const positionData = object.geometry.attributes.position.data;
		const sizeData = new Float32Array([0, size]);
		for (let i = 0; i < nNormals; i++) {
			const i6 = i * 6;
			const i3 = i * 3;
			const pSub = positionData.subarray(i3, i3 + 3);
			positionsArray.set(pSub, i6);
			positionsArray.set(pSub, i6 + 3);
			const nSub = normalData.subarray(i3, i3 + 3);
			normalsArray.set(nSub, i6);
			normalsArray.set(nSub, i6 + 3);
			sizeArray.set(sizeData, i * 2);
		}
		const geometry = new Geometry(gl, {
			position: {
				size: 3,
				data: positionsArray
			},
			normal: {
				size: 3,
				data: normalsArray
			},
			size: {
				size: 1,
				data: sizeArray
			}
		});
		const program = new Program(gl, {
			vertex: vertex$1,
			fragment: fragment$1,
			uniforms: {
				color: { value: color },
				worldNormalMatrix: { value: new Mat3() },
				objectWorldMatrix: { value: object.worldMatrix }
			}
		});
		super(gl, {
			...meshProps,
			mode: gl.LINES,
			geometry,
			program
		});
		this.object = object;
	}
	draw(arg) {
		this.program.uniforms.worldNormalMatrix.value.getNormalMatrix(this.object.worldMatrix);
		super.draw(arg);
	}
};
var vertex$1 = `
attribute vec3 position;
attribute vec3 normal;
attribute float size;

uniform mat4 viewMatrix;
uniform mat4 projectionMatrix;
uniform mat4 objectWorldMatrix;
uniform mat3 worldNormalMatrix;

void main() {
    vec3 n = normalize(worldNormalMatrix * normal) * size;
    vec3 p = (objectWorldMatrix * vec4(position, 1.0)).xyz;
    gl_Position = projectionMatrix * viewMatrix * vec4(p + n, 1.0);
}
`;
var fragment$1 = `
precision highp float;
uniform vec3 color;

void main() {    
    gl_FragColor = vec4(color, 1.0);
}
`;
//#endregion
//#region node_modules/ogl/src/extras/helpers/FaceNormalsHelper.js
var vA = /* @__PURE__ */ new Vec3();
var vB = /* @__PURE__ */ new Vec3();
var vC = /* @__PURE__ */ new Vec3();
var vCenter = /* @__PURE__ */ new Vec3();
var vNormal = /* @__PURE__ */ new Vec3();
var FaceNormalsHelper = class extends Mesh {
	constructor(object, { size = .1, color = new Vec3(.15, .86, .86), ...meshProps } = {}) {
		const gl = object.gl;
		const positionData = object.geometry.attributes.position.data;
		const sizeData = new Float32Array([0, size]);
		const indexAttr = object.geometry.attributes.index;
		const getIndex = indexAttr ? (i) => indexAttr.data[i] : (i) => i;
		const numVertices = indexAttr ? indexAttr.data.length : Math.floor(positionData.length / 3);
		const nNormals = Math.floor(numVertices / 3);
		const positionsArray = new Float32Array(nNormals * 2 * 3);
		const normalsArray = new Float32Array(nNormals * 2 * 3);
		const sizeArray = new Float32Array(nNormals * 2);
		for (let i = 0; i < numVertices; i += 3) {
			vA.fromArray(positionData, getIndex(i + 0) * 3);
			vB.fromArray(positionData, getIndex(i + 1) * 3);
			vC.fromArray(positionData, getIndex(i + 2) * 3);
			vCenter.add(vA, vB).add(vC).multiply(1 / 3);
			vA.sub(vA, vB);
			vC.sub(vC, vB);
			vNormal.cross(vC, vA).normalize();
			const i2 = i * 2;
			positionsArray.set(vCenter, i2);
			positionsArray.set(vCenter, i2 + 3);
			normalsArray.set(vNormal, i2);
			normalsArray.set(vNormal, i2 + 3);
			sizeArray.set(sizeData, i / 3 * 2);
		}
		const geometry = new Geometry(gl, {
			position: {
				size: 3,
				data: positionsArray
			},
			normal: {
				size: 3,
				data: normalsArray
			},
			size: {
				size: 1,
				data: sizeArray
			}
		});
		const program = new Program(gl, {
			vertex,
			fragment,
			uniforms: {
				color: { value: color },
				worldNormalMatrix: { value: new Mat3() },
				objectWorldMatrix: { value: object.worldMatrix }
			}
		});
		super(gl, {
			...meshProps,
			mode: gl.LINES,
			geometry,
			program
		});
		this.object = object;
	}
	draw(arg) {
		this.program.uniforms.worldNormalMatrix.value.getNormalMatrix(this.object.worldMatrix);
		super.draw(arg);
	}
};
var vertex = `
attribute vec3 position;
attribute vec3 normal;
attribute float size;

uniform mat4 viewMatrix;
uniform mat4 projectionMatrix;
uniform mat4 objectWorldMatrix;
uniform mat3 worldNormalMatrix;

void main() {
    vec3 n = normalize(worldNormalMatrix * normal) * size;
    vec3 p = (objectWorldMatrix * vec4(position, 1.0)).xyz;
    gl_Position = projectionMatrix * viewMatrix * vec4(p + n, 1.0);
}
`;
var fragment = `
precision highp float;
uniform vec3 color;

void main() {    
    gl_FragColor = vec4(color, 1.0);
}
`;
//#endregion
//#region node_modules/ogl/src/extras/Texture3D.js
var Texture3D = class extends Texture {
	constructor(gl, args) {
		super(gl, {
			...args,
			target: gl.TEXTURE_3D,
			width: args.width ? args.width : 2,
			height: args.height ? args.height : 2
		});
		const image = new Image();
		image.crossOrigin = "*";
		image.src = args.src;
		image.onload = () => {
			let canvas = document.createElement("canvas");
			canvas.width = image.width;
			canvas.height = image.height;
			let ctx = canvas.getContext("2d");
			ctx.scale(1, -1);
			ctx.translate(0, -image.height);
			ctx.drawImage(image, 0, 0);
			const imageData = ctx.getImageData(0, 0, image.width, image.height).data;
			canvas = null;
			ctx = null;
			let elementCount;
			switch (this.format) {
				case gl.RED:
					elementCount = 1;
					break;
				case gl.RG:
					elementCount = 2;
					break;
				case gl.RGB:
					elementCount = 3;
					break;
				default: elementCount = 4;
			}
			const dataCount = this.width * this.height * this.length * elementCount;
			const data = this.type === gl.UNSIGNED_BYTE ? new Uint8Array(dataCount) : new Float32Array(dataCount);
			let dataIterator = 0;
			for (let z = 0; z < this.length; z++) for (let y = 0; y < this.height; y++) for (let x = 0; x < this.width; x++) {
				let zOffsetX = z % args.tileCountX * this.width;
				let zOffsetY = Math.floor(z / args.tileCountX) * (this.width * this.height * args.tileCountX);
				let index = x + zOffsetX + (y * image.width + zOffsetY);
				let texel = [
					imageData[index * 4],
					imageData[index * 4 + 1],
					imageData[index * 4 + 2],
					imageData[index * 4 + 3]
				];
				for (let i = 0; i < elementCount; i++) if (this.type === this.gl.UNSIGNED_BYTE) data[dataIterator++] = texel[i];
				else data[dataIterator++] = texel[i] / 255;
			}
			this.image = data;
			this.needsUpdate = true;
		};
	}
};
//#endregion
export { Animation, AxesHelper, BasisManager, Box, Camera, Color, Curve, Cylinder, DracoManager, Euler, FaceNormalsHelper, Flowmap, GLTFAnimation, GLTFLoader, GLTFSkin, GPGPU, Geometry, GridHelper, InstancedMesh, KTXTexture, Mat3, Mat4, Mesh, NormalProgram, Orbit, Path, Plane, Polyline, Post, Program, Quat, Raycast, RenderTarget, Renderer, Shadow, Skin, Sphere, Text, Texture, Texture3D, TextureLoader, Torus, Transform, Triangle, Tube, Vec2, Vec3, Vec4, VertexNormalsHelper, WireMesh };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib2dsLmpzIiwibmFtZXMiOlsibGVuZ3RoIiwiY29weSIsInNldCIsImFkZCIsInN1YnRyYWN0IiwibXVsdGlwbHkiLCJkaXZpZGUiLCJzY2FsZSIsImRpc3RhbmNlIiwic3F1YXJlZERpc3RhbmNlIiwic3F1YXJlZExlbmd0aCIsIm5lZ2F0ZSIsImludmVyc2UiLCJub3JtYWxpemUiLCJkb3QiLCJjcm9zcyIsImxlcnAiLCJzbW9vdGhMZXJwIiwidHJhbnNmb3JtTWF0NCIsInRyYW5zZm9ybU1hdDMiLCJleGFjdEVxdWFscyIsIlZlYzNGdW5jLmxlbmd0aCIsIlZlYzNGdW5jLmRpc3RhbmNlIiwiVmVjM0Z1bmMuc3F1YXJlZExlbmd0aCIsIlZlYzNGdW5jLnNxdWFyZWREaXN0YW5jZSIsIlZlYzNGdW5jLmRvdCIsIlZlYzNGdW5jLmV4YWN0RXF1YWxzIiwiVmVjM0Z1bmMuYW5nbGUiLCJ0ZW1wVmVjMyIsIklEIiwiSUQiLCJ0ZW1wVmVjMyIsIklEIiwiY29weSIsInNldCIsInNjYWxlIiwibm9ybWFsaXplIiwiZG90IiwiaWRlbnRpdHkiLCJtdWx0aXBseSIsImludmVydCIsImNvcHkiLCJ2ZWM0LmNvcHkiLCJzZXQiLCJ2ZWM0LnNldCIsImRvdCIsInZlYzQuZG90Iiwibm9ybWFsaXplIiwidmVjNC5ub3JtYWxpemUiLCJRdWF0RnVuYy5kb3QiLCJjb3B5Iiwic2V0IiwiaWRlbnRpdHkiLCJpbnZlcnQiLCJtdWx0aXBseSIsInRyYW5zbGF0ZSIsInNjYWxlIiwicm90YXRlIiwidmVjMy5sZW5ndGgiLCJmcm9tUXVhdCIsImFkZCIsInN1YnRyYWN0IiwiTWF0NEZ1bmMuZ2V0TWF4U2NhbGVPbkF4aXMiLCJNYXQ0RnVuYy5kZXRlcm1pbmFudCIsInRlbXBNYXQ0IiwidGVtcFZlYzNhIiwidGVtcFZlYzNiIiwiY29weSIsInNldCIsImlkZW50aXR5IiwibXVsdGlwbHkiLCJzY2FsZSIsIklEIiwiQ29sb3JGdW5jLnBhcnNlQ29sb3IiLCJWZWMyRnVuYy5sZW5ndGgiLCJWZWMyRnVuYy5kaXN0YW5jZSIsIlZlYzJGdW5jLnNxdWFyZWREaXN0YW5jZSIsIlZlYzJGdW5jLnNxdWFyZWRMZW5ndGgiLCJWZWMyRnVuYy5jcm9zcyIsIlZlYzJGdW5jLmRvdCIsIlZlYzJGdW5jLmV4YWN0RXF1YWxzIiwiVmVjNEZ1bmMuZG90IiwidGVtcFZlYzMiLCJ0ZW1wVmVjMmEiLCJ0ZW1wVmVjMmIiLCJ0ZW1wTWF0NCIsInRlbXBWZWMzIiwidGVtcFZlYzMiLCJ0ZW1wVmVjMyIsInRlbXBNYXQ0IiwidmVydGV4IiwiZGVmYXVsdFZlcnRleCIsImRlZmF1bHRGcmFnbWVudCIsInRlbXBNYXQ0IiwidmVydGV4IiwiZnJhZ21lbnQiLCJ2ZXJ0ZXgiLCJmcmFnbWVudCIsImRlZmF1bHRWZXJ0ZXgiLCJkZWZhdWx0RnJhZ21lbnQiLCJkZWZhdWx0VmVydGV4IiwiZGVmYXVsdEZyYWdtZW50IiwiaWQiLCJ2ZXJ0ZXgiLCJmcmFnbWVudCIsInZlcnRleCIsImZyYWdtZW50IiwidmVydGV4IiwiZnJhZ21lbnQiLCJ2ZXJ0ZXgiLCJmcmFnbWVudCJdLCJzb3VyY2VzIjpbIi4uLy4uL29nbC9zcmMvbWF0aC9mdW5jdGlvbnMvVmVjM0Z1bmMuanMiLCIuLi8uLi9vZ2wvc3JjL21hdGgvVmVjMy5qcyIsIi4uLy4uL29nbC9zcmMvY29yZS9HZW9tZXRyeS5qcyIsIi4uLy4uL29nbC9zcmMvY29yZS9Qcm9ncmFtLmpzIiwiLi4vLi4vb2dsL3NyYy9jb3JlL1JlbmRlcmVyLmpzIiwiLi4vLi4vb2dsL3NyYy9tYXRoL2Z1bmN0aW9ucy9WZWM0RnVuYy5qcyIsIi4uLy4uL29nbC9zcmMvbWF0aC9mdW5jdGlvbnMvUXVhdEZ1bmMuanMiLCIuLi8uLi9vZ2wvc3JjL21hdGgvUXVhdC5qcyIsIi4uLy4uL29nbC9zcmMvbWF0aC9mdW5jdGlvbnMvTWF0NEZ1bmMuanMiLCIuLi8uLi9vZ2wvc3JjL21hdGgvTWF0NC5qcyIsIi4uLy4uL29nbC9zcmMvbWF0aC9mdW5jdGlvbnMvRXVsZXJGdW5jLmpzIiwiLi4vLi4vb2dsL3NyYy9tYXRoL0V1bGVyLmpzIiwiLi4vLi4vb2dsL3NyYy9jb3JlL1RyYW5zZm9ybS5qcyIsIi4uLy4uL29nbC9zcmMvY29yZS9DYW1lcmEuanMiLCIuLi8uLi9vZ2wvc3JjL21hdGgvZnVuY3Rpb25zL01hdDNGdW5jLmpzIiwiLi4vLi4vb2dsL3NyYy9tYXRoL01hdDMuanMiLCIuLi8uLi9vZ2wvc3JjL2NvcmUvTWVzaC5qcyIsIi4uLy4uL29nbC9zcmMvY29yZS9UZXh0dXJlLmpzIiwiLi4vLi4vb2dsL3NyYy9jb3JlL1JlbmRlclRhcmdldC5qcyIsIi4uLy4uL29nbC9zcmMvbWF0aC9mdW5jdGlvbnMvQ29sb3JGdW5jLmpzIiwiLi4vLi4vb2dsL3NyYy9tYXRoL0NvbG9yLmpzIiwiLi4vLi4vb2dsL3NyYy9tYXRoL2Z1bmN0aW9ucy9WZWMyRnVuYy5qcyIsIi4uLy4uL29nbC9zcmMvbWF0aC9WZWMyLmpzIiwiLi4vLi4vb2dsL3NyYy9tYXRoL1ZlYzQuanMiLCIuLi8uLi9vZ2wvc3JjL2V4dHJhcy9QbGFuZS5qcyIsIi4uLy4uL29nbC9zcmMvZXh0cmFzL0JveC5qcyIsIi4uLy4uL29nbC9zcmMvZXh0cmFzL1NwaGVyZS5qcyIsIi4uLy4uL29nbC9zcmMvZXh0cmFzL0N5bGluZGVyLmpzIiwiLi4vLi4vb2dsL3NyYy9leHRyYXMvVHJpYW5nbGUuanMiLCIuLi8uLi9vZ2wvc3JjL2V4dHJhcy9Ub3J1cy5qcyIsIi4uLy4uL29nbC9zcmMvZXh0cmFzL09yYml0LmpzIiwiLi4vLi4vb2dsL3NyYy9leHRyYXMvUmF5Y2FzdC5qcyIsIi4uLy4uL29nbC9zcmMvZXh0cmFzL0N1cnZlLmpzIiwiLi4vLi4vb2dsL3NyYy9leHRyYXMvcGF0aC9CYXNlU2VnbWVudC5qcyIsIi4uLy4uL29nbC9zcmMvZXh0cmFzL3BhdGgvdXRpbHMuanMiLCIuLi8uLi9vZ2wvc3JjL2V4dHJhcy9wYXRoL0N1YmljQmV6aWVyU2VnbWVudC5qcyIsIi4uLy4uL29nbC9zcmMvZXh0cmFzL3BhdGgvUXVhZHJhdGljQmV6aWVyU2VnbWVudC5qcyIsIi4uLy4uL29nbC9zcmMvZXh0cmFzL3BhdGgvTGluZVNlZ21lbnQuanMiLCIuLi8uLi9vZ2wvc3JjL2V4dHJhcy9wYXRoL1BhdGguanMiLCIuLi8uLi9vZ2wvc3JjL2V4dHJhcy9UdWJlLmpzIiwiLi4vLi4vb2dsL3NyYy9leHRyYXMvUG9zdC5qcyIsIi4uLy4uL29nbC9zcmMvZXh0cmFzL0FuaW1hdGlvbi5qcyIsIi4uLy4uL29nbC9zcmMvZXh0cmFzL1NraW4uanMiLCIuLi8uLi9vZ2wvc3JjL2V4dHJhcy9UZXh0LmpzIiwiLi4vLi4vb2dsL3NyYy9leHRyYXMvTm9ybWFsUHJvZ3JhbS5qcyIsIi4uLy4uL29nbC9zcmMvZXh0cmFzL0Zsb3dtYXAuanMiLCIuLi8uLi9vZ2wvc3JjL2V4dHJhcy9HUEdQVS5qcyIsIi4uLy4uL29nbC9zcmMvZXh0cmFzL1BvbHlsaW5lLmpzIiwiLi4vLi4vb2dsL3NyYy9leHRyYXMvU2hhZG93LmpzIiwiLi4vLi4vb2dsL3NyYy9leHRyYXMvS1RYVGV4dHVyZS5qcyIsIi4uLy4uL29nbC9zcmMvZXh0cmFzL1RleHR1cmVMb2FkZXIuanMiLCIuLi8uLi9vZ2wvc3JjL2V4dHJhcy9HTFRGQW5pbWF0aW9uLmpzIiwiLi4vLi4vb2dsL3NyYy9leHRyYXMvR0xURlNraW4uanMiLCIuLi8uLi9vZ2wvc3JjL2V4dHJhcy9JbnN0YW5jZWRNZXNoLmpzIiwiLi4vLi4vb2dsL3NyYy9leHRyYXMvR0xURkxvYWRlci5qcyIsIi4uLy4uL29nbC9zcmMvZXh0cmFzL0RyYWNvTWFuYWdlci5qcyIsIi4uLy4uL29nbC9zcmMvZXh0cmFzL0Jhc2lzTWFuYWdlci5qcyIsIi4uLy4uL29nbC9zcmMvZXh0cmFzL1dpcmVNZXNoLmpzIiwiLi4vLi4vb2dsL3NyYy9leHRyYXMvaGVscGVycy9BeGVzSGVscGVyLmpzIiwiLi4vLi4vb2dsL3NyYy9leHRyYXMvaGVscGVycy9HcmlkSGVscGVyLmpzIiwiLi4vLi4vb2dsL3NyYy9leHRyYXMvaGVscGVycy9WZXJ0ZXhOb3JtYWxzSGVscGVyLmpzIiwiLi4vLi4vb2dsL3NyYy9leHRyYXMvaGVscGVycy9GYWNlTm9ybWFsc0hlbHBlci5qcyIsIi4uLy4uL29nbC9zcmMvZXh0cmFzL1RleHR1cmUzRC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBFUFNJTE9OID0gMC4wMDAwMDE7XG5cbi8qKlxuICogQ2FsY3VsYXRlcyB0aGUgbGVuZ3RoIG9mIGEgdmVjM1xuICpcbiAqIEBwYXJhbSB7dmVjM30gYSB2ZWN0b3IgdG8gY2FsY3VsYXRlIGxlbmd0aCBvZlxuICogQHJldHVybnMge051bWJlcn0gbGVuZ3RoIG9mIGFcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGxlbmd0aChhKSB7XG4gICAgbGV0IHggPSBhWzBdO1xuICAgIGxldCB5ID0gYVsxXTtcbiAgICBsZXQgeiA9IGFbMl07XG4gICAgcmV0dXJuIE1hdGguc3FydCh4ICogeCArIHkgKiB5ICsgeiAqIHopO1xufVxuXG4vKipcbiAqIENvcHkgdGhlIHZhbHVlcyBmcm9tIG9uZSB2ZWMzIHRvIGFub3RoZXJcbiAqXG4gKiBAcGFyYW0ge3ZlYzN9IG91dCB0aGUgcmVjZWl2aW5nIHZlY3RvclxuICogQHBhcmFtIHt2ZWMzfSBhIHRoZSBzb3VyY2UgdmVjdG9yXG4gKiBAcmV0dXJucyB7dmVjM30gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjb3B5KG91dCwgYSkge1xuICAgIG91dFswXSA9IGFbMF07XG4gICAgb3V0WzFdID0gYVsxXTtcbiAgICBvdXRbMl0gPSBhWzJdO1xuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogU2V0IHRoZSBjb21wb25lbnRzIG9mIGEgdmVjMyB0byB0aGUgZ2l2ZW4gdmFsdWVzXG4gKlxuICogQHBhcmFtIHt2ZWMzfSBvdXQgdGhlIHJlY2VpdmluZyB2ZWN0b3JcbiAqIEBwYXJhbSB7TnVtYmVyfSB4IFggY29tcG9uZW50XG4gKiBAcGFyYW0ge051bWJlcn0geSBZIGNvbXBvbmVudFxuICogQHBhcmFtIHtOdW1iZXJ9IHogWiBjb21wb25lbnRcbiAqIEByZXR1cm5zIHt2ZWMzfSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNldChvdXQsIHgsIHksIHopIHtcbiAgICBvdXRbMF0gPSB4O1xuICAgIG91dFsxXSA9IHk7XG4gICAgb3V0WzJdID0gejtcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIEFkZHMgdHdvIHZlYzMnc1xuICpcbiAqIEBwYXJhbSB7dmVjM30gb3V0IHRoZSByZWNlaXZpbmcgdmVjdG9yXG4gKiBAcGFyYW0ge3ZlYzN9IGEgdGhlIGZpcnN0IG9wZXJhbmRcbiAqIEBwYXJhbSB7dmVjM30gYiB0aGUgc2Vjb25kIG9wZXJhbmRcbiAqIEByZXR1cm5zIHt2ZWMzfSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGFkZChvdXQsIGEsIGIpIHtcbiAgICBvdXRbMF0gPSBhWzBdICsgYlswXTtcbiAgICBvdXRbMV0gPSBhWzFdICsgYlsxXTtcbiAgICBvdXRbMl0gPSBhWzJdICsgYlsyXTtcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIFN1YnRyYWN0cyB2ZWN0b3IgYiBmcm9tIHZlY3RvciBhXG4gKlxuICogQHBhcmFtIHt2ZWMzfSBvdXQgdGhlIHJlY2VpdmluZyB2ZWN0b3JcbiAqIEBwYXJhbSB7dmVjM30gYSB0aGUgZmlyc3Qgb3BlcmFuZFxuICogQHBhcmFtIHt2ZWMzfSBiIHRoZSBzZWNvbmQgb3BlcmFuZFxuICogQHJldHVybnMge3ZlYzN9IG91dFxuICovXG5leHBvcnQgZnVuY3Rpb24gc3VidHJhY3Qob3V0LCBhLCBiKSB7XG4gICAgb3V0WzBdID0gYVswXSAtIGJbMF07XG4gICAgb3V0WzFdID0gYVsxXSAtIGJbMV07XG4gICAgb3V0WzJdID0gYVsyXSAtIGJbMl07XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBNdWx0aXBsaWVzIHR3byB2ZWMzJ3NcbiAqXG4gKiBAcGFyYW0ge3ZlYzN9IG91dCB0aGUgcmVjZWl2aW5nIHZlY3RvclxuICogQHBhcmFtIHt2ZWMzfSBhIHRoZSBmaXJzdCBvcGVyYW5kXG4gKiBAcGFyYW0ge3ZlYzN9IGIgdGhlIHNlY29uZCBvcGVyYW5kXG4gKiBAcmV0dXJucyB7dmVjM30gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtdWx0aXBseShvdXQsIGEsIGIpIHtcbiAgICBvdXRbMF0gPSBhWzBdICogYlswXTtcbiAgICBvdXRbMV0gPSBhWzFdICogYlsxXTtcbiAgICBvdXRbMl0gPSBhWzJdICogYlsyXTtcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIERpdmlkZXMgdHdvIHZlYzMnc1xuICpcbiAqIEBwYXJhbSB7dmVjM30gb3V0IHRoZSByZWNlaXZpbmcgdmVjdG9yXG4gKiBAcGFyYW0ge3ZlYzN9IGEgdGhlIGZpcnN0IG9wZXJhbmRcbiAqIEBwYXJhbSB7dmVjM30gYiB0aGUgc2Vjb25kIG9wZXJhbmRcbiAqIEByZXR1cm5zIHt2ZWMzfSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRpdmlkZShvdXQsIGEsIGIpIHtcbiAgICBvdXRbMF0gPSBhWzBdIC8gYlswXTtcbiAgICBvdXRbMV0gPSBhWzFdIC8gYlsxXTtcbiAgICBvdXRbMl0gPSBhWzJdIC8gYlsyXTtcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIFNjYWxlcyBhIHZlYzMgYnkgYSBzY2FsYXIgbnVtYmVyXG4gKlxuICogQHBhcmFtIHt2ZWMzfSBvdXQgdGhlIHJlY2VpdmluZyB2ZWN0b3JcbiAqIEBwYXJhbSB7dmVjM30gYSB0aGUgdmVjdG9yIHRvIHNjYWxlXG4gKiBAcGFyYW0ge051bWJlcn0gYiBhbW91bnQgdG8gc2NhbGUgdGhlIHZlY3RvciBieVxuICogQHJldHVybnMge3ZlYzN9IG91dFxuICovXG5leHBvcnQgZnVuY3Rpb24gc2NhbGUob3V0LCBhLCBiKSB7XG4gICAgb3V0WzBdID0gYVswXSAqIGI7XG4gICAgb3V0WzFdID0gYVsxXSAqIGI7XG4gICAgb3V0WzJdID0gYVsyXSAqIGI7XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBDYWxjdWxhdGVzIHRoZSBldWNsaWRpYW4gZGlzdGFuY2UgYmV0d2VlbiB0d28gdmVjMydzXG4gKlxuICogQHBhcmFtIHt2ZWMzfSBhIHRoZSBmaXJzdCBvcGVyYW5kXG4gKiBAcGFyYW0ge3ZlYzN9IGIgdGhlIHNlY29uZCBvcGVyYW5kXG4gKiBAcmV0dXJucyB7TnVtYmVyfSBkaXN0YW5jZSBiZXR3ZWVuIGEgYW5kIGJcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRpc3RhbmNlKGEsIGIpIHtcbiAgICBsZXQgeCA9IGJbMF0gLSBhWzBdO1xuICAgIGxldCB5ID0gYlsxXSAtIGFbMV07XG4gICAgbGV0IHogPSBiWzJdIC0gYVsyXTtcbiAgICByZXR1cm4gTWF0aC5zcXJ0KHggKiB4ICsgeSAqIHkgKyB6ICogeik7XG59XG5cbi8qKlxuICogQ2FsY3VsYXRlcyB0aGUgc3F1YXJlZCBldWNsaWRpYW4gZGlzdGFuY2UgYmV0d2VlbiB0d28gdmVjMydzXG4gKlxuICogQHBhcmFtIHt2ZWMzfSBhIHRoZSBmaXJzdCBvcGVyYW5kXG4gKiBAcGFyYW0ge3ZlYzN9IGIgdGhlIHNlY29uZCBvcGVyYW5kXG4gKiBAcmV0dXJucyB7TnVtYmVyfSBzcXVhcmVkIGRpc3RhbmNlIGJldHdlZW4gYSBhbmQgYlxuICovXG5leHBvcnQgZnVuY3Rpb24gc3F1YXJlZERpc3RhbmNlKGEsIGIpIHtcbiAgICBsZXQgeCA9IGJbMF0gLSBhWzBdO1xuICAgIGxldCB5ID0gYlsxXSAtIGFbMV07XG4gICAgbGV0IHogPSBiWzJdIC0gYVsyXTtcbiAgICByZXR1cm4geCAqIHggKyB5ICogeSArIHogKiB6O1xufVxuXG4vKipcbiAqIENhbGN1bGF0ZXMgdGhlIHNxdWFyZWQgbGVuZ3RoIG9mIGEgdmVjM1xuICpcbiAqIEBwYXJhbSB7dmVjM30gYSB2ZWN0b3IgdG8gY2FsY3VsYXRlIHNxdWFyZWQgbGVuZ3RoIG9mXG4gKiBAcmV0dXJucyB7TnVtYmVyfSBzcXVhcmVkIGxlbmd0aCBvZiBhXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzcXVhcmVkTGVuZ3RoKGEpIHtcbiAgICBsZXQgeCA9IGFbMF07XG4gICAgbGV0IHkgPSBhWzFdO1xuICAgIGxldCB6ID0gYVsyXTtcbiAgICByZXR1cm4geCAqIHggKyB5ICogeSArIHogKiB6O1xufVxuXG4vKipcbiAqIE5lZ2F0ZXMgdGhlIGNvbXBvbmVudHMgb2YgYSB2ZWMzXG4gKlxuICogQHBhcmFtIHt2ZWMzfSBvdXQgdGhlIHJlY2VpdmluZyB2ZWN0b3JcbiAqIEBwYXJhbSB7dmVjM30gYSB2ZWN0b3IgdG8gbmVnYXRlXG4gKiBAcmV0dXJucyB7dmVjM30gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBuZWdhdGUob3V0LCBhKSB7XG4gICAgb3V0WzBdID0gLWFbMF07XG4gICAgb3V0WzFdID0gLWFbMV07XG4gICAgb3V0WzJdID0gLWFbMl07XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBpbnZlcnNlIG9mIHRoZSBjb21wb25lbnRzIG9mIGEgdmVjM1xuICpcbiAqIEBwYXJhbSB7dmVjM30gb3V0IHRoZSByZWNlaXZpbmcgdmVjdG9yXG4gKiBAcGFyYW0ge3ZlYzN9IGEgdmVjdG9yIHRvIGludmVydFxuICogQHJldHVybnMge3ZlYzN9IG91dFxuICovXG5leHBvcnQgZnVuY3Rpb24gaW52ZXJzZShvdXQsIGEpIHtcbiAgICBvdXRbMF0gPSAxLjAgLyBhWzBdO1xuICAgIG91dFsxXSA9IDEuMCAvIGFbMV07XG4gICAgb3V0WzJdID0gMS4wIC8gYVsyXTtcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIE5vcm1hbGl6ZSBhIHZlYzNcbiAqXG4gKiBAcGFyYW0ge3ZlYzN9IG91dCB0aGUgcmVjZWl2aW5nIHZlY3RvclxuICogQHBhcmFtIHt2ZWMzfSBhIHZlY3RvciB0byBub3JtYWxpemVcbiAqIEByZXR1cm5zIHt2ZWMzfSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZShvdXQsIGEpIHtcbiAgICBsZXQgeCA9IGFbMF07XG4gICAgbGV0IHkgPSBhWzFdO1xuICAgIGxldCB6ID0gYVsyXTtcbiAgICBsZXQgbGVuID0geCAqIHggKyB5ICogeSArIHogKiB6O1xuICAgIGlmIChsZW4gPiAwKSB7XG4gICAgICAgIC8vVE9ETzogZXZhbHVhdGUgdXNlIG9mIGdsbV9pbnZzcXJ0IGhlcmU/XG4gICAgICAgIGxlbiA9IDEgLyBNYXRoLnNxcnQobGVuKTtcbiAgICB9XG4gICAgb3V0WzBdID0gYVswXSAqIGxlbjtcbiAgICBvdXRbMV0gPSBhWzFdICogbGVuO1xuICAgIG91dFsyXSA9IGFbMl0gKiBsZW47XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBDYWxjdWxhdGVzIHRoZSBkb3QgcHJvZHVjdCBvZiB0d28gdmVjMydzXG4gKlxuICogQHBhcmFtIHt2ZWMzfSBhIHRoZSBmaXJzdCBvcGVyYW5kXG4gKiBAcGFyYW0ge3ZlYzN9IGIgdGhlIHNlY29uZCBvcGVyYW5kXG4gKiBAcmV0dXJucyB7TnVtYmVyfSBkb3QgcHJvZHVjdCBvZiBhIGFuZCBiXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkb3QoYSwgYikge1xuICAgIHJldHVybiBhWzBdICogYlswXSArIGFbMV0gKiBiWzFdICsgYVsyXSAqIGJbMl07XG59XG5cbi8qKlxuICogQ29tcHV0ZXMgdGhlIGNyb3NzIHByb2R1Y3Qgb2YgdHdvIHZlYzMnc1xuICpcbiAqIEBwYXJhbSB7dmVjM30gb3V0IHRoZSByZWNlaXZpbmcgdmVjdG9yXG4gKiBAcGFyYW0ge3ZlYzN9IGEgdGhlIGZpcnN0IG9wZXJhbmRcbiAqIEBwYXJhbSB7dmVjM30gYiB0aGUgc2Vjb25kIG9wZXJhbmRcbiAqIEByZXR1cm5zIHt2ZWMzfSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNyb3NzKG91dCwgYSwgYikge1xuICAgIGxldCBheCA9IGFbMF0sXG4gICAgICAgIGF5ID0gYVsxXSxcbiAgICAgICAgYXogPSBhWzJdO1xuICAgIGxldCBieCA9IGJbMF0sXG4gICAgICAgIGJ5ID0gYlsxXSxcbiAgICAgICAgYnogPSBiWzJdO1xuXG4gICAgb3V0WzBdID0gYXkgKiBieiAtIGF6ICogYnk7XG4gICAgb3V0WzFdID0gYXogKiBieCAtIGF4ICogYno7XG4gICAgb3V0WzJdID0gYXggKiBieSAtIGF5ICogYng7XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBQZXJmb3JtcyBhIGxpbmVhciBpbnRlcnBvbGF0aW9uIGJldHdlZW4gdHdvIHZlYzMnc1xuICpcbiAqIEBwYXJhbSB7dmVjM30gb3V0IHRoZSByZWNlaXZpbmcgdmVjdG9yXG4gKiBAcGFyYW0ge3ZlYzN9IGEgdGhlIGZpcnN0IG9wZXJhbmRcbiAqIEBwYXJhbSB7dmVjM30gYiB0aGUgc2Vjb25kIG9wZXJhbmRcbiAqIEBwYXJhbSB7TnVtYmVyfSB0IGludGVycG9sYXRpb24gYW1vdW50IGJldHdlZW4gdGhlIHR3byBpbnB1dHNcbiAqIEByZXR1cm5zIHt2ZWMzfSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGxlcnAob3V0LCBhLCBiLCB0KSB7XG4gICAgbGV0IGF4ID0gYVswXTtcbiAgICBsZXQgYXkgPSBhWzFdO1xuICAgIGxldCBheiA9IGFbMl07XG4gICAgb3V0WzBdID0gYXggKyB0ICogKGJbMF0gLSBheCk7XG4gICAgb3V0WzFdID0gYXkgKyB0ICogKGJbMV0gLSBheSk7XG4gICAgb3V0WzJdID0gYXogKyB0ICogKGJbMl0gLSBheik7XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBQZXJmb3JtcyBhIGZyYW1lIHJhdGUgaW5kZXBlbmRhbnQsIGxpbmVhciBpbnRlcnBvbGF0aW9uIGJldHdlZW4gdHdvIHZlYzMnc1xuICpcbiAqIEBwYXJhbSB7dmVjM30gb3V0IHRoZSByZWNlaXZpbmcgdmVjdG9yXG4gKiBAcGFyYW0ge3ZlYzN9IGEgdGhlIGZpcnN0IG9wZXJhbmRcbiAqIEBwYXJhbSB7dmVjM30gYiB0aGUgc2Vjb25kIG9wZXJhbmRcbiAqIEBwYXJhbSB7TnVtYmVyfSBkZWNheSBkZWNheSBjb25zdGFudCBmb3IgaW50ZXJwb2xhdGlvbi4gdXNlZnVsIHJhbmdlIGJldHdlZW4gMSBhbmQgMjUsIGZyb20gc2xvdyB0byBmYXN0LlxuICogQHBhcmFtIHtOdW1iZXJ9IGR0IGRlbHRhIHRpbWVcbiAqIEByZXR1cm5zIHt2ZWMzfSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNtb290aExlcnAob3V0LCBhLCBiLCBkZWNheSwgZHQpIHtcbiAgICBjb25zdCBleHAgPSBNYXRoLmV4cCgtZGVjYXkgKiBkdCk7XG4gICAgbGV0IGF4ID0gYVswXTtcbiAgICBsZXQgYXkgPSBhWzFdO1xuICAgIGxldCBheiA9IGFbMl07XG5cbiAgICBvdXRbMF0gPSBiWzBdICsgKGF4IC0gYlswXSkgKiBleHA7XG4gICAgb3V0WzFdID0gYlsxXSArIChheSAtIGJbMV0pICogZXhwO1xuICAgIG91dFsyXSA9IGJbMl0gKyAoYXogLSBiWzJdKSAqIGV4cDtcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIFRyYW5zZm9ybXMgdGhlIHZlYzMgd2l0aCBhIG1hdDQuXG4gKiA0dGggdmVjdG9yIGNvbXBvbmVudCBpcyBpbXBsaWNpdGx5ICcxJ1xuICpcbiAqIEBwYXJhbSB7dmVjM30gb3V0IHRoZSByZWNlaXZpbmcgdmVjdG9yXG4gKiBAcGFyYW0ge3ZlYzN9IGEgdGhlIHZlY3RvciB0byB0cmFuc2Zvcm1cbiAqIEBwYXJhbSB7bWF0NH0gbSBtYXRyaXggdG8gdHJhbnNmb3JtIHdpdGhcbiAqIEByZXR1cm5zIHt2ZWMzfSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRyYW5zZm9ybU1hdDQob3V0LCBhLCBtKSB7XG4gICAgbGV0IHggPSBhWzBdLFxuICAgICAgICB5ID0gYVsxXSxcbiAgICAgICAgeiA9IGFbMl07XG4gICAgbGV0IHcgPSBtWzNdICogeCArIG1bN10gKiB5ICsgbVsxMV0gKiB6ICsgbVsxNV07XG4gICAgdyA9IHcgfHwgMS4wO1xuICAgIG91dFswXSA9IChtWzBdICogeCArIG1bNF0gKiB5ICsgbVs4XSAqIHogKyBtWzEyXSkgLyB3O1xuICAgIG91dFsxXSA9IChtWzFdICogeCArIG1bNV0gKiB5ICsgbVs5XSAqIHogKyBtWzEzXSkgLyB3O1xuICAgIG91dFsyXSA9IChtWzJdICogeCArIG1bNl0gKiB5ICsgbVsxMF0gKiB6ICsgbVsxNF0pIC8gdztcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIFNhbWUgYXMgYWJvdmUgYnV0IGRvZXNuJ3QgYXBwbHkgdHJhbnNsYXRpb24uXG4gKiBVc2VmdWwgZm9yIHJheXMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzY2FsZVJvdGF0ZU1hdDQob3V0LCBhLCBtKSB7XG4gICAgbGV0IHggPSBhWzBdLFxuICAgICAgICB5ID0gYVsxXSxcbiAgICAgICAgeiA9IGFbMl07XG4gICAgbGV0IHcgPSBtWzNdICogeCArIG1bN10gKiB5ICsgbVsxMV0gKiB6ICsgbVsxNV07XG4gICAgdyA9IHcgfHwgMS4wO1xuICAgIG91dFswXSA9IChtWzBdICogeCArIG1bNF0gKiB5ICsgbVs4XSAqIHopIC8gdztcbiAgICBvdXRbMV0gPSAobVsxXSAqIHggKyBtWzVdICogeSArIG1bOV0gKiB6KSAvIHc7XG4gICAgb3V0WzJdID0gKG1bMl0gKiB4ICsgbVs2XSAqIHkgKyBtWzEwXSAqIHopIC8gdztcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIFRyYW5zZm9ybXMgdGhlIHZlYzMgd2l0aCBhIG1hdDMuXG4gKlxuICogQHBhcmFtIHt2ZWMzfSBvdXQgdGhlIHJlY2VpdmluZyB2ZWN0b3JcbiAqIEBwYXJhbSB7dmVjM30gYSB0aGUgdmVjdG9yIHRvIHRyYW5zZm9ybVxuICogQHBhcmFtIHttYXQzfSBtIHRoZSAzeDMgbWF0cml4IHRvIHRyYW5zZm9ybSB3aXRoXG4gKiBAcmV0dXJucyB7dmVjM30gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0cmFuc2Zvcm1NYXQzKG91dCwgYSwgbSkge1xuICAgIGxldCB4ID0gYVswXSxcbiAgICAgICAgeSA9IGFbMV0sXG4gICAgICAgIHogPSBhWzJdO1xuICAgIG91dFswXSA9IHggKiBtWzBdICsgeSAqIG1bM10gKyB6ICogbVs2XTtcbiAgICBvdXRbMV0gPSB4ICogbVsxXSArIHkgKiBtWzRdICsgeiAqIG1bN107XG4gICAgb3V0WzJdID0geCAqIG1bMl0gKyB5ICogbVs1XSArIHogKiBtWzhdO1xuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogVHJhbnNmb3JtcyB0aGUgdmVjMyB3aXRoIGEgcXVhdFxuICpcbiAqIEBwYXJhbSB7dmVjM30gb3V0IHRoZSByZWNlaXZpbmcgdmVjdG9yXG4gKiBAcGFyYW0ge3ZlYzN9IGEgdGhlIHZlY3RvciB0byB0cmFuc2Zvcm1cbiAqIEBwYXJhbSB7cXVhdH0gcSBxdWF0ZXJuaW9uIHRvIHRyYW5zZm9ybSB3aXRoXG4gKiBAcmV0dXJucyB7dmVjM30gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0cmFuc2Zvcm1RdWF0KG91dCwgYSwgcSkge1xuICAgIC8vIGJlbmNobWFya3M6IGh0dHBzOi8vanNwZXJmLmNvbS9xdWF0ZXJuaW9uLXRyYW5zZm9ybS12ZWMzLWltcGxlbWVudGF0aW9ucy1maXhlZFxuXG4gICAgbGV0IHggPSBhWzBdLFxuICAgICAgICB5ID0gYVsxXSxcbiAgICAgICAgeiA9IGFbMl07XG4gICAgbGV0IHF4ID0gcVswXSxcbiAgICAgICAgcXkgPSBxWzFdLFxuICAgICAgICBxeiA9IHFbMl0sXG4gICAgICAgIHF3ID0gcVszXTtcblxuICAgIGxldCB1dnggPSBxeSAqIHogLSBxeiAqIHk7XG4gICAgbGV0IHV2eSA9IHF6ICogeCAtIHF4ICogejtcbiAgICBsZXQgdXZ6ID0gcXggKiB5IC0gcXkgKiB4O1xuXG4gICAgbGV0IHV1dnggPSBxeSAqIHV2eiAtIHF6ICogdXZ5O1xuICAgIGxldCB1dXZ5ID0gcXogKiB1dnggLSBxeCAqIHV2ejtcbiAgICBsZXQgdXV2eiA9IHF4ICogdXZ5IC0gcXkgKiB1dng7XG5cbiAgICBsZXQgdzIgPSBxdyAqIDI7XG4gICAgdXZ4ICo9IHcyO1xuICAgIHV2eSAqPSB3MjtcbiAgICB1dnogKj0gdzI7XG5cbiAgICB1dXZ4ICo9IDI7XG4gICAgdXV2eSAqPSAyO1xuICAgIHV1dnogKj0gMjtcblxuICAgIG91dFswXSA9IHggKyB1dnggKyB1dXZ4O1xuICAgIG91dFsxXSA9IHkgKyB1dnkgKyB1dXZ5O1xuICAgIG91dFsyXSA9IHogKyB1dnogKyB1dXZ6O1xuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogR2V0IHRoZSBhbmdsZSBiZXR3ZWVuIHR3byAzRCB2ZWN0b3JzXG4gKiBAcGFyYW0ge3ZlYzN9IGEgVGhlIGZpcnN0IG9wZXJhbmRcbiAqIEBwYXJhbSB7dmVjM30gYiBUaGUgc2Vjb25kIG9wZXJhbmRcbiAqIEByZXR1cm5zIHtOdW1iZXJ9IFRoZSBhbmdsZSBpbiByYWRpYW5zXG4gKi9cbmV4cG9ydCBjb25zdCBhbmdsZSA9IChmdW5jdGlvbiAoKSB7XG4gICAgY29uc3QgdGVtcEEgPSBbMCwgMCwgMF07XG4gICAgY29uc3QgdGVtcEIgPSBbMCwgMCwgMF07XG5cbiAgICByZXR1cm4gZnVuY3Rpb24gKGEsIGIpIHtcbiAgICAgICAgY29weSh0ZW1wQSwgYSk7XG4gICAgICAgIGNvcHkodGVtcEIsIGIpO1xuXG4gICAgICAgIG5vcm1hbGl6ZSh0ZW1wQSwgdGVtcEEpO1xuICAgICAgICBub3JtYWxpemUodGVtcEIsIHRlbXBCKTtcblxuICAgICAgICBsZXQgY29zaW5lID0gZG90KHRlbXBBLCB0ZW1wQik7XG5cbiAgICAgICAgaWYgKGNvc2luZSA+IDEuMCkge1xuICAgICAgICAgICAgcmV0dXJuIDA7XG4gICAgICAgIH0gZWxzZSBpZiAoY29zaW5lIDwgLTEuMCkge1xuICAgICAgICAgICAgcmV0dXJuIE1hdGguUEk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gTWF0aC5hY29zKGNvc2luZSk7XG4gICAgICAgIH1cbiAgICB9O1xufSkoKTtcblxuLyoqXG4gKiBSZXR1cm5zIHdoZXRoZXIgb3Igbm90IHRoZSB2ZWN0b3JzIGhhdmUgZXhhY3RseSB0aGUgc2FtZSBlbGVtZW50cyBpbiB0aGUgc2FtZSBwb3NpdGlvbiAod2hlbiBjb21wYXJlZCB3aXRoID09PSlcbiAqXG4gKiBAcGFyYW0ge3ZlYzN9IGEgVGhlIGZpcnN0IHZlY3Rvci5cbiAqIEBwYXJhbSB7dmVjM30gYiBUaGUgc2Vjb25kIHZlY3Rvci5cbiAqIEByZXR1cm5zIHtCb29sZWFufSBUcnVlIGlmIHRoZSB2ZWN0b3JzIGFyZSBlcXVhbCwgZmFsc2Ugb3RoZXJ3aXNlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZXhhY3RFcXVhbHMoYSwgYikge1xuICAgIHJldHVybiBhWzBdID09PSBiWzBdICYmIGFbMV0gPT09IGJbMV0gJiYgYVsyXSA9PT0gYlsyXTtcbn1cbiIsImltcG9ydCAqIGFzIFZlYzNGdW5jIGZyb20gJy4vZnVuY3Rpb25zL1ZlYzNGdW5jLmpzJztcblxuZXhwb3J0IGNsYXNzIFZlYzMgZXh0ZW5kcyBBcnJheSB7XG4gICAgY29uc3RydWN0b3IoeCA9IDAsIHkgPSB4LCB6ID0geCkge1xuICAgICAgICBzdXBlcih4LCB5LCB6KTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgZ2V0IHgoKSB7XG4gICAgICAgIHJldHVybiB0aGlzWzBdO1xuICAgIH1cblxuICAgIGdldCB5KCkge1xuICAgICAgICByZXR1cm4gdGhpc1sxXTtcbiAgICB9XG5cbiAgICBnZXQgeigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXNbMl07XG4gICAgfVxuXG4gICAgc2V0IHgodikge1xuICAgICAgICB0aGlzWzBdID0gdjtcbiAgICB9XG5cbiAgICBzZXQgeSh2KSB7XG4gICAgICAgIHRoaXNbMV0gPSB2O1xuICAgIH1cblxuICAgIHNldCB6KHYpIHtcbiAgICAgICAgdGhpc1syXSA9IHY7XG4gICAgfVxuXG4gICAgc2V0KHgsIHkgPSB4LCB6ID0geCkge1xuICAgICAgICBpZiAoeC5sZW5ndGgpIHJldHVybiB0aGlzLmNvcHkoeCk7XG4gICAgICAgIFZlYzNGdW5jLnNldCh0aGlzLCB4LCB5LCB6KTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgY29weSh2KSB7XG4gICAgICAgIFZlYzNGdW5jLmNvcHkodGhpcywgdik7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGFkZCh2YSwgdmIpIHtcbiAgICAgICAgaWYgKHZiKSBWZWMzRnVuYy5hZGQodGhpcywgdmEsIHZiKTtcbiAgICAgICAgZWxzZSBWZWMzRnVuYy5hZGQodGhpcywgdGhpcywgdmEpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBzdWIodmEsIHZiKSB7XG4gICAgICAgIGlmICh2YikgVmVjM0Z1bmMuc3VidHJhY3QodGhpcywgdmEsIHZiKTtcbiAgICAgICAgZWxzZSBWZWMzRnVuYy5zdWJ0cmFjdCh0aGlzLCB0aGlzLCB2YSk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIG11bHRpcGx5KHYpIHtcbiAgICAgICAgaWYgKHYubGVuZ3RoKSBWZWMzRnVuYy5tdWx0aXBseSh0aGlzLCB0aGlzLCB2KTtcbiAgICAgICAgZWxzZSBWZWMzRnVuYy5zY2FsZSh0aGlzLCB0aGlzLCB2KTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgZGl2aWRlKHYpIHtcbiAgICAgICAgaWYgKHYubGVuZ3RoKSBWZWMzRnVuYy5kaXZpZGUodGhpcywgdGhpcywgdik7XG4gICAgICAgIGVsc2UgVmVjM0Z1bmMuc2NhbGUodGhpcywgdGhpcywgMSAvIHYpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBpbnZlcnNlKHYgPSB0aGlzKSB7XG4gICAgICAgIFZlYzNGdW5jLmludmVyc2UodGhpcywgdik7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIC8vIENhbid0IHVzZSAnbGVuZ3RoJyBhcyBBcnJheS5wcm90b3R5cGUgdXNlcyBpdFxuICAgIGxlbigpIHtcbiAgICAgICAgcmV0dXJuIFZlYzNGdW5jLmxlbmd0aCh0aGlzKTtcbiAgICB9XG5cbiAgICBkaXN0YW5jZSh2KSB7XG4gICAgICAgIGlmICh2KSByZXR1cm4gVmVjM0Z1bmMuZGlzdGFuY2UodGhpcywgdik7XG4gICAgICAgIGVsc2UgcmV0dXJuIFZlYzNGdW5jLmxlbmd0aCh0aGlzKTtcbiAgICB9XG5cbiAgICBzcXVhcmVkTGVuKCkge1xuICAgICAgICByZXR1cm4gVmVjM0Z1bmMuc3F1YXJlZExlbmd0aCh0aGlzKTtcbiAgICB9XG5cbiAgICBzcXVhcmVkRGlzdGFuY2Uodikge1xuICAgICAgICBpZiAodikgcmV0dXJuIFZlYzNGdW5jLnNxdWFyZWREaXN0YW5jZSh0aGlzLCB2KTtcbiAgICAgICAgZWxzZSByZXR1cm4gVmVjM0Z1bmMuc3F1YXJlZExlbmd0aCh0aGlzKTtcbiAgICB9XG5cbiAgICBuZWdhdGUodiA9IHRoaXMpIHtcbiAgICAgICAgVmVjM0Z1bmMubmVnYXRlKHRoaXMsIHYpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBjcm9zcyh2YSwgdmIpIHtcbiAgICAgICAgaWYgKHZiKSBWZWMzRnVuYy5jcm9zcyh0aGlzLCB2YSwgdmIpO1xuICAgICAgICBlbHNlIFZlYzNGdW5jLmNyb3NzKHRoaXMsIHRoaXMsIHZhKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgc2NhbGUodikge1xuICAgICAgICBWZWMzRnVuYy5zY2FsZSh0aGlzLCB0aGlzLCB2KTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgbm9ybWFsaXplKCkge1xuICAgICAgICBWZWMzRnVuYy5ub3JtYWxpemUodGhpcywgdGhpcyk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGRvdCh2KSB7XG4gICAgICAgIHJldHVybiBWZWMzRnVuYy5kb3QodGhpcywgdik7XG4gICAgfVxuXG4gICAgZXF1YWxzKHYpIHtcbiAgICAgICAgcmV0dXJuIFZlYzNGdW5jLmV4YWN0RXF1YWxzKHRoaXMsIHYpO1xuICAgIH1cblxuICAgIGFwcGx5TWF0cml4MyhtYXQzKSB7XG4gICAgICAgIFZlYzNGdW5jLnRyYW5zZm9ybU1hdDModGhpcywgdGhpcywgbWF0Myk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGFwcGx5TWF0cml4NChtYXQ0KSB7XG4gICAgICAgIFZlYzNGdW5jLnRyYW5zZm9ybU1hdDQodGhpcywgdGhpcywgbWF0NCk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIHNjYWxlUm90YXRlTWF0cml4NChtYXQ0KSB7XG4gICAgICAgIFZlYzNGdW5jLnNjYWxlUm90YXRlTWF0NCh0aGlzLCB0aGlzLCBtYXQ0KTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgYXBwbHlRdWF0ZXJuaW9uKHEpIHtcbiAgICAgICAgVmVjM0Z1bmMudHJhbnNmb3JtUXVhdCh0aGlzLCB0aGlzLCBxKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgYW5nbGUodikge1xuICAgICAgICByZXR1cm4gVmVjM0Z1bmMuYW5nbGUodGhpcywgdik7XG4gICAgfVxuXG4gICAgbGVycCh2LCB0KSB7XG4gICAgICAgIFZlYzNGdW5jLmxlcnAodGhpcywgdGhpcywgdiwgdCk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIHNtb290aExlcnAodiwgZGVjYXksIGR0KSB7XG4gICAgICAgIFZlYzNGdW5jLnNtb290aExlcnAodGhpcywgdGhpcywgdiwgZGVjYXksIGR0KTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgY2xvbmUoKSB7XG4gICAgICAgIHJldHVybiBuZXcgVmVjMyh0aGlzWzBdLCB0aGlzWzFdLCB0aGlzWzJdKTtcbiAgICB9XG5cbiAgICBmcm9tQXJyYXkoYSwgbyA9IDApIHtcbiAgICAgICAgdGhpc1swXSA9IGFbb107XG4gICAgICAgIHRoaXNbMV0gPSBhW28gKyAxXTtcbiAgICAgICAgdGhpc1syXSA9IGFbbyArIDJdO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICB0b0FycmF5KGEgPSBbXSwgbyA9IDApIHtcbiAgICAgICAgYVtvXSA9IHRoaXNbMF07XG4gICAgICAgIGFbbyArIDFdID0gdGhpc1sxXTtcbiAgICAgICAgYVtvICsgMl0gPSB0aGlzWzJdO1xuICAgICAgICByZXR1cm4gYTtcbiAgICB9XG5cbiAgICB0cmFuc2Zvcm1EaXJlY3Rpb24obWF0NCkge1xuICAgICAgICBjb25zdCB4ID0gdGhpc1swXTtcbiAgICAgICAgY29uc3QgeSA9IHRoaXNbMV07XG4gICAgICAgIGNvbnN0IHogPSB0aGlzWzJdO1xuXG4gICAgICAgIHRoaXNbMF0gPSBtYXQ0WzBdICogeCArIG1hdDRbNF0gKiB5ICsgbWF0NFs4XSAqIHo7XG4gICAgICAgIHRoaXNbMV0gPSBtYXQ0WzFdICogeCArIG1hdDRbNV0gKiB5ICsgbWF0NFs5XSAqIHo7XG4gICAgICAgIHRoaXNbMl0gPSBtYXQ0WzJdICogeCArIG1hdDRbNl0gKiB5ICsgbWF0NFsxMF0gKiB6O1xuXG4gICAgICAgIHJldHVybiB0aGlzLm5vcm1hbGl6ZSgpO1xuICAgIH1cbn1cbiIsIi8vIGF0dHJpYnV0ZSBwYXJhbXNcbi8vIHtcbi8vICAgICBkYXRhIC0gdHlwZWQgYXJyYXkgZWcgVUludDE2QXJyYXkgZm9yIGluZGljZXMsIEZsb2F0MzJBcnJheVxuLy8gICAgIHNpemUgLSBpbnQgZGVmYXVsdCAxXG4vLyAgICAgaW5zdGFuY2VkIC0gZGVmYXVsdCBudWxsLiBQYXNzIGRpdmlzb3IgYW1vdW50XG4vLyAgICAgdHlwZSAtIGdsIGVudW0gZGVmYXVsdCBnbC5VTlNJR05FRF9TSE9SVCBmb3IgJ2luZGV4JywgZ2wuRkxPQVQgZm9yIG90aGVyc1xuLy8gICAgIG5vcm1hbGl6ZWQgLSBib29sZWFuIGRlZmF1bHQgZmFsc2VcblxuLy8gICAgIGJ1ZmZlciAtIGdsIGJ1ZmZlciwgaWYgYnVmZmVyIGV4aXN0cywgZG9uJ3QgbmVlZCB0byBwcm92aWRlIGRhdGEgLSBhbHRob3VnaCBuZWVkcyBwb3NpdGlvbiBkYXRhIGZvciBib3VuZHMgY2FsY3VsYXRpb25cbi8vICAgICBzdHJpZGUgLSBkZWZhdWx0IDAgLSBmb3Igd2hlbiBwYXNzaW5nIGluIGJ1ZmZlclxuLy8gICAgIG9mZnNldCAtIGRlZmF1bHQgMCAtIGZvciB3aGVuIHBhc3NpbmcgaW4gYnVmZmVyXG4vLyAgICAgY291bnQgLSBkZWZhdWx0IG51bGwgLSBmb3Igd2hlbiBwYXNzaW5nIGluIGJ1ZmZlclxuLy8gICAgIG1pbiAtIGFycmF5IC0gZm9yIHdoZW4gcGFzc2luZyBpbiBidWZmZXJcbi8vICAgICBtYXggLSBhcnJheSAtIGZvciB3aGVuIHBhc3NpbmcgaW4gYnVmZmVyXG4vLyB9XG5cbi8vIFRPRE86IGZpdCBpbiB0cmFuc2Zvcm0gZmVlZGJhY2tcblxuaW1wb3J0IHsgVmVjMyB9IGZyb20gJy4uL21hdGgvVmVjMy5qcyc7XG5cbmNvbnN0IHRlbXBWZWMzID0gLyogQF9fUFVSRV9fICovIG5ldyBWZWMzKCk7XG5cbmxldCBJRCA9IDE7XG5sZXQgQVRUUl9JRCA9IDE7XG5cbi8vIFRvIHN0b3AgaW5pZmluaXRlIHdhcm5pbmdzXG5sZXQgaXNCb3VuZHNXYXJuZWQgPSBmYWxzZTtcblxuZXhwb3J0IGNsYXNzIEdlb21ldHJ5IHtcbiAgICBjb25zdHJ1Y3RvcihnbCwgYXR0cmlidXRlcyA9IHt9KSB7XG4gICAgICAgIGlmICghZ2wuY2FudmFzKSBjb25zb2xlLmVycm9yKCdnbCBub3QgcGFzc2VkIGFzIGZpcnN0IGFyZ3VtZW50IHRvIEdlb21ldHJ5Jyk7XG4gICAgICAgIHRoaXMuZ2wgPSBnbDtcbiAgICAgICAgdGhpcy5hdHRyaWJ1dGVzID0gYXR0cmlidXRlcztcbiAgICAgICAgdGhpcy5pZCA9IElEKys7XG5cbiAgICAgICAgLy8gU3RvcmUgb25lIFZBTyBwZXIgcHJvZ3JhbSBhdHRyaWJ1dGUgbG9jYXRpb25zIG9yZGVyXG4gICAgICAgIHRoaXMuVkFPcyA9IHt9O1xuXG4gICAgICAgIHRoaXMuZHJhd1JhbmdlID0geyBzdGFydDogMCwgY291bnQ6IDAgfTtcbiAgICAgICAgdGhpcy5pbnN0YW5jZWRDb3VudCA9IDA7XG5cbiAgICAgICAgLy8gVW5iaW5kIGN1cnJlbnQgVkFPIHNvIHRoYXQgbmV3IGJ1ZmZlcnMgZG9uJ3QgZ2V0IGFkZGVkIHRvIGFjdGl2ZSBtZXNoXG4gICAgICAgIHRoaXMuZ2wucmVuZGVyZXIuYmluZFZlcnRleEFycmF5KG51bGwpO1xuICAgICAgICB0aGlzLmdsLnJlbmRlcmVyLmN1cnJlbnRHZW9tZXRyeSA9IG51bGw7XG5cbiAgICAgICAgLy8gQWxpYXMgZm9yIHN0YXRlIHN0b3JlIHRvIGF2b2lkIHJlZHVuZGFudCBjYWxscyBmb3IgZ2xvYmFsIHN0YXRlXG4gICAgICAgIHRoaXMuZ2xTdGF0ZSA9IHRoaXMuZ2wucmVuZGVyZXIuc3RhdGU7XG5cbiAgICAgICAgLy8gY3JlYXRlIHRoZSBidWZmZXJzXG4gICAgICAgIGZvciAobGV0IGtleSBpbiBhdHRyaWJ1dGVzKSB7XG4gICAgICAgICAgICB0aGlzLmFkZEF0dHJpYnV0ZShrZXksIGF0dHJpYnV0ZXNba2V5XSk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBhZGRBdHRyaWJ1dGUoa2V5LCBhdHRyKSB7XG4gICAgICAgIHRoaXMuYXR0cmlidXRlc1trZXldID0gYXR0cjtcblxuICAgICAgICAvLyBTZXQgb3B0aW9uc1xuICAgICAgICBhdHRyLmlkID0gQVRUUl9JRCsrOyAvLyBUT0RPOiBjdXJyZW50bHkgdW51c2VkLCByZW1vdmU/XG4gICAgICAgIGF0dHIuc2l6ZSA9IGF0dHIuc2l6ZSB8fCAxO1xuICAgICAgICBhdHRyLnR5cGUgPVxuICAgICAgICAgICAgYXR0ci50eXBlIHx8XG4gICAgICAgICAgICAoYXR0ci5kYXRhLmNvbnN0cnVjdG9yID09PSBGbG9hdDMyQXJyYXlcbiAgICAgICAgICAgICAgICA/IHRoaXMuZ2wuRkxPQVRcbiAgICAgICAgICAgICAgICA6IGF0dHIuZGF0YS5jb25zdHJ1Y3RvciA9PT0gVWludDE2QXJyYXlcbiAgICAgICAgICAgICAgICA/IHRoaXMuZ2wuVU5TSUdORURfU0hPUlRcbiAgICAgICAgICAgICAgICA6IHRoaXMuZ2wuVU5TSUdORURfSU5UKTsgLy8gVWludDMyQXJyYXlcbiAgICAgICAgYXR0ci50YXJnZXQgPSBrZXkgPT09ICdpbmRleCcgPyB0aGlzLmdsLkVMRU1FTlRfQVJSQVlfQlVGRkVSIDogdGhpcy5nbC5BUlJBWV9CVUZGRVI7XG4gICAgICAgIGF0dHIubm9ybWFsaXplZCA9IGF0dHIubm9ybWFsaXplZCB8fCBmYWxzZTtcbiAgICAgICAgYXR0ci5zdHJpZGUgPSBhdHRyLnN0cmlkZSB8fCAwO1xuICAgICAgICBhdHRyLm9mZnNldCA9IGF0dHIub2Zmc2V0IHx8IDA7XG4gICAgICAgIGF0dHIuY291bnQgPSBhdHRyLmNvdW50IHx8IChhdHRyLnN0cmlkZSA/IGF0dHIuZGF0YS5ieXRlTGVuZ3RoIC8gYXR0ci5zdHJpZGUgOiBhdHRyLmRhdGEubGVuZ3RoIC8gYXR0ci5zaXplKTtcbiAgICAgICAgYXR0ci5kaXZpc29yID0gYXR0ci5pbnN0YW5jZWQgfHwgMDtcbiAgICAgICAgYXR0ci5uZWVkc1VwZGF0ZSA9IGZhbHNlO1xuICAgICAgICBhdHRyLnVzYWdlID0gYXR0ci51c2FnZSB8fCB0aGlzLmdsLlNUQVRJQ19EUkFXO1xuXG4gICAgICAgIGlmICghYXR0ci5idWZmZXIpIHtcbiAgICAgICAgICAgIC8vIFB1c2ggZGF0YSB0byBidWZmZXJcbiAgICAgICAgICAgIHRoaXMudXBkYXRlQXR0cmlidXRlKGF0dHIpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gVXBkYXRlIGdlb21ldHJ5IGNvdW50cy4gSWYgaW5kZXhlZCwgaWdub3JlIHJlZ3VsYXIgYXR0cmlidXRlc1xuICAgICAgICBpZiAoYXR0ci5kaXZpc29yKSB7XG4gICAgICAgICAgICB0aGlzLmlzSW5zdGFuY2VkID0gdHJ1ZTtcbiAgICAgICAgICAgIGlmICh0aGlzLmluc3RhbmNlZENvdW50ICYmIHRoaXMuaW5zdGFuY2VkQ291bnQgIT09IGF0dHIuY291bnQgKiBhdHRyLmRpdmlzb3IpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oJ2dlb21ldHJ5IGhhcyBtdWx0aXBsZSBpbnN0YW5jZWQgYnVmZmVycyBvZiBkaWZmZXJlbnQgbGVuZ3RoJyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuICh0aGlzLmluc3RhbmNlZENvdW50ID0gTWF0aC5taW4odGhpcy5pbnN0YW5jZWRDb3VudCwgYXR0ci5jb3VudCAqIGF0dHIuZGl2aXNvcikpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5pbnN0YW5jZWRDb3VudCA9IGF0dHIuY291bnQgKiBhdHRyLmRpdmlzb3I7XG4gICAgICAgIH0gZWxzZSBpZiAoa2V5ID09PSAnaW5kZXgnKSB7XG4gICAgICAgICAgICB0aGlzLmRyYXdSYW5nZS5jb3VudCA9IGF0dHIuY291bnQ7XG4gICAgICAgIH0gZWxzZSBpZiAoIXRoaXMuYXR0cmlidXRlcy5pbmRleCkge1xuICAgICAgICAgICAgdGhpcy5kcmF3UmFuZ2UuY291bnQgPSBNYXRoLm1heCh0aGlzLmRyYXdSYW5nZS5jb3VudCwgYXR0ci5jb3VudCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICB1cGRhdGVBdHRyaWJ1dGUoYXR0cikge1xuICAgICAgICBjb25zdCBpc05ld0J1ZmZlciA9ICFhdHRyLmJ1ZmZlcjtcbiAgICAgICAgaWYgKGlzTmV3QnVmZmVyKSBhdHRyLmJ1ZmZlciA9IHRoaXMuZ2wuY3JlYXRlQnVmZmVyKCk7XG4gICAgICAgIGlmICh0aGlzLmdsU3RhdGUuYm91bmRCdWZmZXIgIT09IGF0dHIuYnVmZmVyKSB7XG4gICAgICAgICAgICB0aGlzLmdsLmJpbmRCdWZmZXIoYXR0ci50YXJnZXQsIGF0dHIuYnVmZmVyKTtcbiAgICAgICAgICAgIHRoaXMuZ2xTdGF0ZS5ib3VuZEJ1ZmZlciA9IGF0dHIuYnVmZmVyO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc05ld0J1ZmZlcikge1xuICAgICAgICAgICAgdGhpcy5nbC5idWZmZXJEYXRhKGF0dHIudGFyZ2V0LCBhdHRyLmRhdGEsIGF0dHIudXNhZ2UpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5nbC5idWZmZXJTdWJEYXRhKGF0dHIudGFyZ2V0LCAwLCBhdHRyLmRhdGEpO1xuICAgICAgICB9XG4gICAgICAgIGF0dHIubmVlZHNVcGRhdGUgPSBmYWxzZTtcbiAgICB9XG5cbiAgICBzZXRJbmRleCh2YWx1ZSkge1xuICAgICAgICB0aGlzLmFkZEF0dHJpYnV0ZSgnaW5kZXgnLCB2YWx1ZSk7XG4gICAgfVxuXG4gICAgc2V0RHJhd1JhbmdlKHN0YXJ0LCBjb3VudCkge1xuICAgICAgICB0aGlzLmRyYXdSYW5nZS5zdGFydCA9IHN0YXJ0O1xuICAgICAgICB0aGlzLmRyYXdSYW5nZS5jb3VudCA9IGNvdW50O1xuICAgIH1cblxuICAgIHNldEluc3RhbmNlZENvdW50KHZhbHVlKSB7XG4gICAgICAgIHRoaXMuaW5zdGFuY2VkQ291bnQgPSB2YWx1ZTtcbiAgICB9XG5cbiAgICBjcmVhdGVWQU8ocHJvZ3JhbSkge1xuICAgICAgICB0aGlzLlZBT3NbcHJvZ3JhbS5hdHRyaWJ1dGVPcmRlcl0gPSB0aGlzLmdsLnJlbmRlcmVyLmNyZWF0ZVZlcnRleEFycmF5KCk7XG4gICAgICAgIHRoaXMuZ2wucmVuZGVyZXIuYmluZFZlcnRleEFycmF5KHRoaXMuVkFPc1twcm9ncmFtLmF0dHJpYnV0ZU9yZGVyXSk7XG4gICAgICAgIHRoaXMuYmluZEF0dHJpYnV0ZXMocHJvZ3JhbSk7XG4gICAgfVxuXG4gICAgYmluZEF0dHJpYnV0ZXMocHJvZ3JhbSkge1xuICAgICAgICAvLyBMaW5rIGFsbCBhdHRyaWJ1dGVzIHRvIHByb2dyYW0gdXNpbmcgZ2wudmVydGV4QXR0cmliUG9pbnRlclxuICAgICAgICBwcm9ncmFtLmF0dHJpYnV0ZUxvY2F0aW9ucy5mb3JFYWNoKChsb2NhdGlvbiwgeyBuYW1lLCB0eXBlIH0pID0+IHtcbiAgICAgICAgICAgIC8vIElmIGdlb21ldHJ5IG1pc3NpbmcgYSByZXF1aXJlZCBzaGFkZXIgYXR0cmlidXRlXG4gICAgICAgICAgICBpZiAoIXRoaXMuYXR0cmlidXRlc1tuYW1lXSkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihgYWN0aXZlIGF0dHJpYnV0ZSAke25hbWV9IG5vdCBiZWluZyBzdXBwbGllZGApO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY29uc3QgYXR0ciA9IHRoaXMuYXR0cmlidXRlc1tuYW1lXTtcblxuICAgICAgICAgICAgdGhpcy5nbC5iaW5kQnVmZmVyKGF0dHIudGFyZ2V0LCBhdHRyLmJ1ZmZlcik7XG4gICAgICAgICAgICB0aGlzLmdsU3RhdGUuYm91bmRCdWZmZXIgPSBhdHRyLmJ1ZmZlcjtcblxuICAgICAgICAgICAgLy8gRm9yIG1hdHJpeCBhdHRyaWJ1dGVzLCBidWZmZXIgbmVlZHMgdG8gYmUgZGVmaW5lZCBwZXIgY29sdW1uXG4gICAgICAgICAgICBsZXQgbnVtTG9jID0gMTtcbiAgICAgICAgICAgIGlmICh0eXBlID09PSAzNTY3NCkgbnVtTG9jID0gMjsgLy8gbWF0MlxuICAgICAgICAgICAgaWYgKHR5cGUgPT09IDM1Njc1KSBudW1Mb2MgPSAzOyAvLyBtYXQzXG4gICAgICAgICAgICBpZiAodHlwZSA9PT0gMzU2NzYpIG51bUxvYyA9IDQ7IC8vIG1hdDRcblxuICAgICAgICAgICAgY29uc3Qgc2l6ZSA9IGF0dHIuc2l6ZSAvIG51bUxvYztcbiAgICAgICAgICAgIGNvbnN0IHN0cmlkZSA9IG51bUxvYyA9PT0gMSA/IDAgOiBudW1Mb2MgKiBudW1Mb2MgKiA0O1xuICAgICAgICAgICAgY29uc3Qgb2Zmc2V0ID0gbnVtTG9jID09PSAxID8gMCA6IG51bUxvYyAqIDQ7XG5cbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbnVtTG9jOyBpKyspIHtcbiAgICAgICAgICAgICAgICB0aGlzLmdsLnZlcnRleEF0dHJpYlBvaW50ZXIobG9jYXRpb24gKyBpLCBzaXplLCBhdHRyLnR5cGUsIGF0dHIubm9ybWFsaXplZCwgYXR0ci5zdHJpZGUgKyBzdHJpZGUsIGF0dHIub2Zmc2V0ICsgaSAqIG9mZnNldCk7XG4gICAgICAgICAgICAgICAgdGhpcy5nbC5lbmFibGVWZXJ0ZXhBdHRyaWJBcnJheShsb2NhdGlvbiArIGkpO1xuXG4gICAgICAgICAgICAgICAgLy8gRm9yIGluc3RhbmNlZCBhdHRyaWJ1dGVzLCBkaXZpc29yIG5lZWRzIHRvIGJlIHNldC5cbiAgICAgICAgICAgICAgICAvLyBGb3IgZmlyZWZveCwgbmVlZCB0byBzZXQgYmFjayB0byAwIGlmIG5vbi1pbnN0YW5jZWQgZHJhd24gYWZ0ZXIgaW5zdGFuY2VkLiBFbHNlIHdvbid0IHJlbmRlclxuICAgICAgICAgICAgICAgIHRoaXMuZ2wucmVuZGVyZXIudmVydGV4QXR0cmliRGl2aXNvcihsb2NhdGlvbiArIGksIGF0dHIuZGl2aXNvcik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8vIEJpbmQgaW5kaWNlcyBpZiBnZW9tZXRyeSBpbmRleGVkXG4gICAgICAgIGlmICh0aGlzLmF0dHJpYnV0ZXMuaW5kZXgpIHRoaXMuZ2wuYmluZEJ1ZmZlcih0aGlzLmdsLkVMRU1FTlRfQVJSQVlfQlVGRkVSLCB0aGlzLmF0dHJpYnV0ZXMuaW5kZXguYnVmZmVyKTtcbiAgICB9XG5cbiAgICBkcmF3KHsgcHJvZ3JhbSwgbW9kZSA9IHRoaXMuZ2wuVFJJQU5HTEVTIH0pIHtcbiAgICAgICAgaWYgKHRoaXMuZ2wucmVuZGVyZXIuY3VycmVudEdlb21ldHJ5ICE9PSBgJHt0aGlzLmlkfV8ke3Byb2dyYW0uYXR0cmlidXRlT3JkZXJ9YCkge1xuICAgICAgICAgICAgaWYgKCF0aGlzLlZBT3NbcHJvZ3JhbS5hdHRyaWJ1dGVPcmRlcl0pIHRoaXMuY3JlYXRlVkFPKHByb2dyYW0pO1xuICAgICAgICAgICAgdGhpcy5nbC5yZW5kZXJlci5iaW5kVmVydGV4QXJyYXkodGhpcy5WQU9zW3Byb2dyYW0uYXR0cmlidXRlT3JkZXJdKTtcbiAgICAgICAgICAgIHRoaXMuZ2wucmVuZGVyZXIuY3VycmVudEdlb21ldHJ5ID0gYCR7dGhpcy5pZH1fJHtwcm9ncmFtLmF0dHJpYnV0ZU9yZGVyfWA7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBDaGVjayBpZiBhbnkgYXR0cmlidXRlcyBuZWVkIHVwZGF0aW5nXG4gICAgICAgIHByb2dyYW0uYXR0cmlidXRlTG9jYXRpb25zLmZvckVhY2goKGxvY2F0aW9uLCB7IG5hbWUgfSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgYXR0ciA9IHRoaXMuYXR0cmlidXRlc1tuYW1lXTtcbiAgICAgICAgICAgIGlmIChhdHRyLm5lZWRzVXBkYXRlKSB0aGlzLnVwZGF0ZUF0dHJpYnV0ZShhdHRyKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gRm9yIGRyYXdFbGVtZW50cywgb2Zmc2V0IG5lZWRzIHRvIGJlIG11bHRpcGxlIG9mIHR5cGUgc2l6ZVxuICAgICAgICBsZXQgaW5kZXhCeXRlc1BlckVsZW1lbnQgPSAyO1xuICAgICAgICBpZiAodGhpcy5hdHRyaWJ1dGVzLmluZGV4Py50eXBlID09PSB0aGlzLmdsLlVOU0lHTkVEX0lOVCkgaW5kZXhCeXRlc1BlckVsZW1lbnQgPSA0O1xuXG4gICAgICAgIGlmICh0aGlzLmlzSW5zdGFuY2VkKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5hdHRyaWJ1dGVzLmluZGV4KSB7XG4gICAgICAgICAgICAgICAgdGhpcy5nbC5yZW5kZXJlci5kcmF3RWxlbWVudHNJbnN0YW5jZWQoXG4gICAgICAgICAgICAgICAgICAgIG1vZGUsXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZHJhd1JhbmdlLmNvdW50LFxuICAgICAgICAgICAgICAgICAgICB0aGlzLmF0dHJpYnV0ZXMuaW5kZXgudHlwZSxcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hdHRyaWJ1dGVzLmluZGV4Lm9mZnNldCArIHRoaXMuZHJhd1JhbmdlLnN0YXJ0ICogaW5kZXhCeXRlc1BlckVsZW1lbnQsXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaW5zdGFuY2VkQ291bnRcbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aGlzLmdsLnJlbmRlcmVyLmRyYXdBcnJheXNJbnN0YW5jZWQobW9kZSwgdGhpcy5kcmF3UmFuZ2Uuc3RhcnQsIHRoaXMuZHJhd1JhbmdlLmNvdW50LCB0aGlzLmluc3RhbmNlZENvdW50KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGlmICh0aGlzLmF0dHJpYnV0ZXMuaW5kZXgpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmdsLmRyYXdFbGVtZW50cyhcbiAgICAgICAgICAgICAgICAgICAgbW9kZSxcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5kcmF3UmFuZ2UuY291bnQsXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYXR0cmlidXRlcy5pbmRleC50eXBlLFxuICAgICAgICAgICAgICAgICAgICB0aGlzLmF0dHJpYnV0ZXMuaW5kZXgub2Zmc2V0ICsgdGhpcy5kcmF3UmFuZ2Uuc3RhcnQgKiBpbmRleEJ5dGVzUGVyRWxlbWVudFxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMuZ2wuZHJhd0FycmF5cyhtb2RlLCB0aGlzLmRyYXdSYW5nZS5zdGFydCwgdGhpcy5kcmF3UmFuZ2UuY291bnQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgZ2V0UG9zaXRpb24oKSB7XG4gICAgICAgIC8vIFVzZSBwb3NpdGlvbiBidWZmZXIsIG9yIG1pbi9tYXggaWYgYXZhaWxhYmxlXG4gICAgICAgIGNvbnN0IGF0dHIgPSB0aGlzLmF0dHJpYnV0ZXMucG9zaXRpb247XG4gICAgICAgIC8vIGlmIChhdHRyLm1pbikgcmV0dXJuIFsuLi5hdHRyLm1pbiwgLi4uYXR0ci5tYXhdO1xuICAgICAgICBpZiAoYXR0ci5kYXRhKSByZXR1cm4gYXR0cjtcbiAgICAgICAgaWYgKGlzQm91bmRzV2FybmVkKSByZXR1cm47XG4gICAgICAgIGNvbnNvbGUud2FybignTm8gcG9zaXRpb24gYnVmZmVyIGRhdGEgZm91bmQgdG8gY29tcHV0ZSBib3VuZHMnKTtcbiAgICAgICAgcmV0dXJuIChpc0JvdW5kc1dhcm5lZCA9IHRydWUpO1xuICAgIH1cblxuICAgIGNvbXB1dGVCb3VuZGluZ0JveChhdHRyKSB7XG4gICAgICAgIGlmICghYXR0cikgYXR0ciA9IHRoaXMuZ2V0UG9zaXRpb24oKTtcbiAgICAgICAgY29uc3QgYXJyYXkgPSBhdHRyLmRhdGE7XG4gICAgICAgIC8vIERhdGEgbG9hZGVkIHNob3VsZG4ndCBoYWF2ZSBzdHJpZGUsIG9ubHkgYnVmZmVyc1xuICAgICAgICAvLyBjb25zdCBzdHJpZGUgPSBhdHRyLnN0cmlkZSA/IGF0dHIuc3RyaWRlIC8gYXJyYXkuQllURVNfUEVSX0VMRU1FTlQgOiBhdHRyLnNpemU7XG4gICAgICAgIGNvbnN0IHN0cmlkZSA9IGF0dHIuc2l6ZTtcblxuICAgICAgICBpZiAoIXRoaXMuYm91bmRzKSB7XG4gICAgICAgICAgICB0aGlzLmJvdW5kcyA9IHtcbiAgICAgICAgICAgICAgICBtaW46IG5ldyBWZWMzKCksXG4gICAgICAgICAgICAgICAgbWF4OiBuZXcgVmVjMygpLFxuICAgICAgICAgICAgICAgIGNlbnRlcjogbmV3IFZlYzMoKSxcbiAgICAgICAgICAgICAgICBzY2FsZTogbmV3IFZlYzMoKSxcbiAgICAgICAgICAgICAgICByYWRpdXM6IEluZmluaXR5LFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IG1pbiA9IHRoaXMuYm91bmRzLm1pbjtcbiAgICAgICAgY29uc3QgbWF4ID0gdGhpcy5ib3VuZHMubWF4O1xuICAgICAgICBjb25zdCBjZW50ZXIgPSB0aGlzLmJvdW5kcy5jZW50ZXI7XG4gICAgICAgIGNvbnN0IHNjYWxlID0gdGhpcy5ib3VuZHMuc2NhbGU7XG5cbiAgICAgICAgbWluLnNldCgrSW5maW5pdHkpO1xuICAgICAgICBtYXguc2V0KC1JbmZpbml0eSk7XG5cbiAgICAgICAgLy8gVE9ETzogY2hlY2sgc2l6ZSBvZiBwb3NpdGlvbiAoZWcgdHJpYW5nbGUgd2l0aCBWZWMyKVxuICAgICAgICBmb3IgKGxldCBpID0gMCwgbCA9IGFycmF5Lmxlbmd0aDsgaSA8IGw7IGkgKz0gc3RyaWRlKSB7XG4gICAgICAgICAgICBjb25zdCB4ID0gYXJyYXlbaV07XG4gICAgICAgICAgICBjb25zdCB5ID0gYXJyYXlbaSArIDFdO1xuICAgICAgICAgICAgY29uc3QgeiA9IGFycmF5W2kgKyAyXTtcblxuICAgICAgICAgICAgbWluLnggPSBNYXRoLm1pbih4LCBtaW4ueCk7XG4gICAgICAgICAgICBtaW4ueSA9IE1hdGgubWluKHksIG1pbi55KTtcbiAgICAgICAgICAgIG1pbi56ID0gTWF0aC5taW4oeiwgbWluLnopO1xuXG4gICAgICAgICAgICBtYXgueCA9IE1hdGgubWF4KHgsIG1heC54KTtcbiAgICAgICAgICAgIG1heC55ID0gTWF0aC5tYXgoeSwgbWF4LnkpO1xuICAgICAgICAgICAgbWF4LnogPSBNYXRoLm1heCh6LCBtYXgueik7XG4gICAgICAgIH1cblxuICAgICAgICBzY2FsZS5zdWIobWF4LCBtaW4pO1xuICAgICAgICBjZW50ZXIuYWRkKG1pbiwgbWF4KS5kaXZpZGUoMik7XG4gICAgfVxuXG4gICAgY29tcHV0ZUJvdW5kaW5nU3BoZXJlKGF0dHIpIHtcbiAgICAgICAgaWYgKCFhdHRyKSBhdHRyID0gdGhpcy5nZXRQb3NpdGlvbigpO1xuICAgICAgICBjb25zdCBhcnJheSA9IGF0dHIuZGF0YTtcbiAgICAgICAgLy8gRGF0YSBsb2FkZWQgc2hvdWxkbid0IGhhYXZlIHN0cmlkZSwgb25seSBidWZmZXJzXG4gICAgICAgIC8vIGNvbnN0IHN0cmlkZSA9IGF0dHIuc3RyaWRlID8gYXR0ci5zdHJpZGUgLyBhcnJheS5CWVRFU19QRVJfRUxFTUVOVCA6IGF0dHIuc2l6ZTtcbiAgICAgICAgY29uc3Qgc3RyaWRlID0gYXR0ci5zaXplO1xuXG4gICAgICAgIGlmICghdGhpcy5ib3VuZHMpIHRoaXMuY29tcHV0ZUJvdW5kaW5nQm94KGF0dHIpO1xuXG4gICAgICAgIGxldCBtYXhSYWRpdXNTcSA9IDA7XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBsID0gYXJyYXkubGVuZ3RoOyBpIDwgbDsgaSArPSBzdHJpZGUpIHtcbiAgICAgICAgICAgIHRlbXBWZWMzLmZyb21BcnJheShhcnJheSwgaSk7XG4gICAgICAgICAgICBtYXhSYWRpdXNTcSA9IE1hdGgubWF4KG1heFJhZGl1c1NxLCB0aGlzLmJvdW5kcy5jZW50ZXIuc3F1YXJlZERpc3RhbmNlKHRlbXBWZWMzKSk7XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLmJvdW5kcy5yYWRpdXMgPSBNYXRoLnNxcnQobWF4UmFkaXVzU3EpO1xuICAgIH1cblxuICAgIHJlbW92ZSgpIHtcbiAgICAgICAgZm9yIChsZXQga2V5IGluIHRoaXMuVkFPcykge1xuICAgICAgICAgICAgdGhpcy5nbC5yZW5kZXJlci5kZWxldGVWZXJ0ZXhBcnJheSh0aGlzLlZBT3Nba2V5XSk7XG4gICAgICAgICAgICBkZWxldGUgdGhpcy5WQU9zW2tleV07XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChsZXQga2V5IGluIHRoaXMuYXR0cmlidXRlcykge1xuICAgICAgICAgICAgdGhpcy5nbC5kZWxldGVCdWZmZXIodGhpcy5hdHRyaWJ1dGVzW2tleV0uYnVmZmVyKTtcbiAgICAgICAgICAgIGRlbGV0ZSB0aGlzLmF0dHJpYnV0ZXNba2V5XTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiIsIi8vIFRPRE86IHVwbG9hZCBlbXB0eSB0ZXh0dXJlIGlmIG51bGwgPyBtYXliZSBub3Rcbi8vIFRPRE86IHVwbG9hZCBpZGVudGl0eSBtYXRyaXggaWYgbnVsbCA/XG4vLyBUT0RPOiBzYW1wbGVyIEN1YmVcblxubGV0IElEID0gMTtcblxuLy8gY2FjaGUgb2YgdHlwZWQgYXJyYXlzIHVzZWQgdG8gZmxhdHRlbiB1bmlmb3JtIGFycmF5c1xuY29uc3QgYXJyYXlDYWNoZUYzMiA9IHt9O1xuXG5leHBvcnQgY2xhc3MgUHJvZ3JhbSB7XG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIGdsLFxuICAgICAgICB7XG4gICAgICAgICAgICB2ZXJ0ZXgsXG4gICAgICAgICAgICBmcmFnbWVudCxcbiAgICAgICAgICAgIHVuaWZvcm1zID0ge30sXG5cbiAgICAgICAgICAgIHRyYW5zcGFyZW50ID0gZmFsc2UsXG4gICAgICAgICAgICBjdWxsRmFjZSA9IGdsLkJBQ0ssXG4gICAgICAgICAgICBmcm9udEZhY2UgPSBnbC5DQ1csXG4gICAgICAgICAgICBkZXB0aFRlc3QgPSB0cnVlLFxuICAgICAgICAgICAgZGVwdGhXcml0ZSA9IHRydWUsXG4gICAgICAgICAgICBkZXB0aEZ1bmMgPSBnbC5MRVFVQUwsXG4gICAgICAgIH0gPSB7fVxuICAgICkge1xuICAgICAgICBpZiAoIWdsLmNhbnZhcykgY29uc29sZS5lcnJvcignZ2wgbm90IHBhc3NlZCBhcyBmaXJzdCBhcmd1bWVudCB0byBQcm9ncmFtJyk7XG4gICAgICAgIHRoaXMuZ2wgPSBnbDtcbiAgICAgICAgdGhpcy51bmlmb3JtcyA9IHVuaWZvcm1zO1xuICAgICAgICB0aGlzLmlkID0gSUQrKztcblxuICAgICAgICBpZiAoIXZlcnRleCkgY29uc29sZS53YXJuKCd2ZXJ0ZXggc2hhZGVyIG5vdCBzdXBwbGllZCcpO1xuICAgICAgICBpZiAoIWZyYWdtZW50KSBjb25zb2xlLndhcm4oJ2ZyYWdtZW50IHNoYWRlciBub3Qgc3VwcGxpZWQnKTtcblxuICAgICAgICAvLyBTdG9yZSBwcm9ncmFtIHN0YXRlXG4gICAgICAgIHRoaXMudHJhbnNwYXJlbnQgPSB0cmFuc3BhcmVudDtcbiAgICAgICAgdGhpcy5jdWxsRmFjZSA9IGN1bGxGYWNlO1xuICAgICAgICB0aGlzLmZyb250RmFjZSA9IGZyb250RmFjZTtcbiAgICAgICAgdGhpcy5kZXB0aFRlc3QgPSBkZXB0aFRlc3Q7XG4gICAgICAgIHRoaXMuZGVwdGhXcml0ZSA9IGRlcHRoV3JpdGU7XG4gICAgICAgIHRoaXMuZGVwdGhGdW5jID0gZGVwdGhGdW5jO1xuICAgICAgICB0aGlzLmJsZW5kRnVuYyA9IHt9O1xuICAgICAgICB0aGlzLmJsZW5kRXF1YXRpb24gPSB7fTtcbiAgICAgICAgdGhpcy5zdGVuY2lsRnVuYyA9IHt9O1xuICAgICAgICB0aGlzLnN0ZW5jaWxPcCA9IHt9XG5cbiAgICAgICAgLy8gc2V0IGRlZmF1bHQgYmxlbmRGdW5jIGlmIHRyYW5zcGFyZW50IGZsYWdnZWRcbiAgICAgICAgaWYgKHRoaXMudHJhbnNwYXJlbnQgJiYgIXRoaXMuYmxlbmRGdW5jLnNyYykge1xuICAgICAgICAgICAgaWYgKHRoaXMuZ2wucmVuZGVyZXIucHJlbXVsdGlwbGllZEFscGhhKSB0aGlzLnNldEJsZW5kRnVuYyh0aGlzLmdsLk9ORSwgdGhpcy5nbC5PTkVfTUlOVVNfU1JDX0FMUEhBKTtcbiAgICAgICAgICAgIGVsc2UgdGhpcy5zZXRCbGVuZEZ1bmModGhpcy5nbC5TUkNfQUxQSEEsIHRoaXMuZ2wuT05FX01JTlVTX1NSQ19BTFBIQSk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBDcmVhdGUgZW1wdHkgc2hhZGVycyBhbmQgYXR0YWNoIHRvIHByb2dyYW1cbiAgICAgICAgdGhpcy52ZXJ0ZXhTaGFkZXIgPSBnbC5jcmVhdGVTaGFkZXIoZ2wuVkVSVEVYX1NIQURFUik7XG4gICAgICAgIHRoaXMuZnJhZ21lbnRTaGFkZXIgPSBnbC5jcmVhdGVTaGFkZXIoZ2wuRlJBR01FTlRfU0hBREVSKTtcbiAgICAgICAgdGhpcy5wcm9ncmFtID0gZ2wuY3JlYXRlUHJvZ3JhbSgpO1xuICAgICAgICBnbC5hdHRhY2hTaGFkZXIodGhpcy5wcm9ncmFtLCB0aGlzLnZlcnRleFNoYWRlcik7XG4gICAgICAgIGdsLmF0dGFjaFNoYWRlcih0aGlzLnByb2dyYW0sIHRoaXMuZnJhZ21lbnRTaGFkZXIpO1xuXG4gICAgICAgIC8vIENvbXBpbGUgc2hhZGVycyB3aXRoIHNvdXJjZVxuICAgICAgICB0aGlzLnNldFNoYWRlcnMoeyB2ZXJ0ZXgsIGZyYWdtZW50IH0pO1xuICAgIH1cblxuICAgIHNldFNoYWRlcnMoeyB2ZXJ0ZXgsIGZyYWdtZW50IH0pIHtcbiAgICAgICAgaWYgKHZlcnRleCkge1xuICAgICAgICAgICAgLy8gY29tcGlsZSB2ZXJ0ZXggc2hhZGVyIGFuZCBsb2cgZXJyb3JzXG4gICAgICAgICAgICB0aGlzLmdsLnNoYWRlclNvdXJjZSh0aGlzLnZlcnRleFNoYWRlciwgdmVydGV4KTtcbiAgICAgICAgICAgIHRoaXMuZ2wuY29tcGlsZVNoYWRlcih0aGlzLnZlcnRleFNoYWRlcik7XG4gICAgICAgICAgICBpZiAodGhpcy5nbC5nZXRTaGFkZXJJbmZvTG9nKHRoaXMudmVydGV4U2hhZGVyKSAhPT0gJycpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oYCR7dGhpcy5nbC5nZXRTaGFkZXJJbmZvTG9nKHRoaXMudmVydGV4U2hhZGVyKX1cXG5WZXJ0ZXggU2hhZGVyXFxuJHthZGRMaW5lTnVtYmVycyh2ZXJ0ZXgpfWApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGZyYWdtZW50KSB7XG4gICAgICAgICAgICAvLyBjb21waWxlIGZyYWdtZW50IHNoYWRlciBhbmQgbG9nIGVycm9yc1xuICAgICAgICAgICAgdGhpcy5nbC5zaGFkZXJTb3VyY2UodGhpcy5mcmFnbWVudFNoYWRlciwgZnJhZ21lbnQpO1xuICAgICAgICAgICAgdGhpcy5nbC5jb21waWxlU2hhZGVyKHRoaXMuZnJhZ21lbnRTaGFkZXIpO1xuICAgICAgICAgICAgaWYgKHRoaXMuZ2wuZ2V0U2hhZGVySW5mb0xvZyh0aGlzLmZyYWdtZW50U2hhZGVyKSAhPT0gJycpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oYCR7dGhpcy5nbC5nZXRTaGFkZXJJbmZvTG9nKHRoaXMuZnJhZ21lbnRTaGFkZXIpfVxcbkZyYWdtZW50IFNoYWRlclxcbiR7YWRkTGluZU51bWJlcnMoZnJhZ21lbnQpfWApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gY29tcGlsZSBwcm9ncmFtIGFuZCBsb2cgZXJyb3JzXG4gICAgICAgIHRoaXMuZ2wubGlua1Byb2dyYW0odGhpcy5wcm9ncmFtKTtcbiAgICAgICAgaWYgKCF0aGlzLmdsLmdldFByb2dyYW1QYXJhbWV0ZXIodGhpcy5wcm9ncmFtLCB0aGlzLmdsLkxJTktfU1RBVFVTKSkge1xuICAgICAgICAgICAgcmV0dXJuIGNvbnNvbGUud2Fybih0aGlzLmdsLmdldFByb2dyYW1JbmZvTG9nKHRoaXMucHJvZ3JhbSkpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gR2V0IGFjdGl2ZSB1bmlmb3JtIGxvY2F0aW9uc1xuICAgICAgICB0aGlzLnVuaWZvcm1Mb2NhdGlvbnMgPSBuZXcgTWFwKCk7XG4gICAgICAgIGxldCBudW1Vbmlmb3JtcyA9IHRoaXMuZ2wuZ2V0UHJvZ3JhbVBhcmFtZXRlcih0aGlzLnByb2dyYW0sIHRoaXMuZ2wuQUNUSVZFX1VOSUZPUk1TKTtcbiAgICAgICAgZm9yIChsZXQgdUluZGV4ID0gMDsgdUluZGV4IDwgbnVtVW5pZm9ybXM7IHVJbmRleCsrKSB7XG4gICAgICAgICAgICBsZXQgdW5pZm9ybSA9IHRoaXMuZ2wuZ2V0QWN0aXZlVW5pZm9ybSh0aGlzLnByb2dyYW0sIHVJbmRleCk7XG4gICAgICAgICAgICB0aGlzLnVuaWZvcm1Mb2NhdGlvbnMuc2V0KHVuaWZvcm0sIHRoaXMuZ2wuZ2V0VW5pZm9ybUxvY2F0aW9uKHRoaXMucHJvZ3JhbSwgdW5pZm9ybS5uYW1lKSk7XG5cbiAgICAgICAgICAgIC8vIHNwbGl0IHVuaWZvcm1zJyBuYW1lcyB0byBzZXBhcmF0ZSBhcnJheSBhbmQgc3RydWN0IGRlY2xhcmF0aW9uc1xuICAgICAgICAgICAgY29uc3Qgc3BsaXQgPSB1bmlmb3JtLm5hbWUubWF0Y2goLyhcXHcrKS9nKTtcblxuICAgICAgICAgICAgdW5pZm9ybS51bmlmb3JtTmFtZSA9IHNwbGl0WzBdO1xuICAgICAgICAgICAgdW5pZm9ybS5uYW1lQ29tcG9uZW50cyA9IHNwbGl0LnNsaWNlKDEpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gR2V0IGFjdGl2ZSBhdHRyaWJ1dGUgbG9jYXRpb25zXG4gICAgICAgIHRoaXMuYXR0cmlidXRlTG9jYXRpb25zID0gbmV3IE1hcCgpO1xuICAgICAgICBjb25zdCBsb2NhdGlvbnMgPSBbXTtcbiAgICAgICAgY29uc3QgbnVtQXR0cmlicyA9IHRoaXMuZ2wuZ2V0UHJvZ3JhbVBhcmFtZXRlcih0aGlzLnByb2dyYW0sIHRoaXMuZ2wuQUNUSVZFX0FUVFJJQlVURVMpO1xuICAgICAgICBmb3IgKGxldCBhSW5kZXggPSAwOyBhSW5kZXggPCBudW1BdHRyaWJzOyBhSW5kZXgrKykge1xuICAgICAgICAgICAgY29uc3QgYXR0cmlidXRlID0gdGhpcy5nbC5nZXRBY3RpdmVBdHRyaWIodGhpcy5wcm9ncmFtLCBhSW5kZXgpO1xuICAgICAgICAgICAgY29uc3QgbG9jYXRpb24gPSB0aGlzLmdsLmdldEF0dHJpYkxvY2F0aW9uKHRoaXMucHJvZ3JhbSwgYXR0cmlidXRlLm5hbWUpO1xuICAgICAgICAgICAgLy8gSWdub3JlIHNwZWNpYWwgYnVpbHQtaW4gaW5wdXRzLiBlZyBnbF9WZXJ0ZXhJRCwgZ2xfSW5zdGFuY2VJRFxuICAgICAgICAgICAgaWYgKGxvY2F0aW9uID09PSAtMSkgY29udGludWU7XG4gICAgICAgICAgICBsb2NhdGlvbnNbbG9jYXRpb25dID0gYXR0cmlidXRlLm5hbWU7XG4gICAgICAgICAgICB0aGlzLmF0dHJpYnV0ZUxvY2F0aW9ucy5zZXQoYXR0cmlidXRlLCBsb2NhdGlvbik7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5hdHRyaWJ1dGVPcmRlciA9IGxvY2F0aW9ucy5qb2luKCcnKTtcbiAgICB9XG5cbiAgICBzZXRCbGVuZEZ1bmMoc3JjLCBkc3QsIHNyY0FscGhhLCBkc3RBbHBoYSkge1xuICAgICAgICB0aGlzLmJsZW5kRnVuYy5zcmMgPSBzcmM7XG4gICAgICAgIHRoaXMuYmxlbmRGdW5jLmRzdCA9IGRzdDtcbiAgICAgICAgdGhpcy5ibGVuZEZ1bmMuc3JjQWxwaGEgPSBzcmNBbHBoYTtcbiAgICAgICAgdGhpcy5ibGVuZEZ1bmMuZHN0QWxwaGEgPSBkc3RBbHBoYTtcbiAgICAgICAgaWYgKHNyYykgdGhpcy50cmFuc3BhcmVudCA9IHRydWU7XG4gICAgfVxuXG4gICAgc2V0QmxlbmRFcXVhdGlvbihtb2RlUkdCLCBtb2RlQWxwaGEpIHtcbiAgICAgICAgdGhpcy5ibGVuZEVxdWF0aW9uLm1vZGVSR0IgPSBtb2RlUkdCO1xuICAgICAgICB0aGlzLmJsZW5kRXF1YXRpb24ubW9kZUFscGhhID0gbW9kZUFscGhhO1xuICAgIH1cblxuICAgIHNldFN0ZW5jaWxGdW5jKGZ1bmMsIHJlZiwgbWFzaykge1xuICAgICAgICB0aGlzLnN0ZW5jaWxSZWYgPSByZWY7XG4gICAgICAgIHRoaXMuc3RlbmNpbEZ1bmMuZnVuYyA9IGZ1bmM7XG4gICAgICAgIHRoaXMuc3RlbmNpbEZ1bmMucmVmID0gcmVmO1xuICAgICAgICB0aGlzLnN0ZW5jaWxGdW5jLm1hc2sgPSBtYXNrO1xuICAgIH1cblxuICAgIHNldFN0ZW5jaWxPcChzdGVuY2lsRmFpbCwgZGVwdGhGYWlsLCBkZXB0aFBhc3MpIHtcbiAgICAgICAgdGhpcy5zdGVuY2lsT3Auc3RlbmNpbEZhaWwgPSBzdGVuY2lsRmFpbDtcbiAgICAgICAgdGhpcy5zdGVuY2lsT3AuZGVwdGhGYWlsID0gZGVwdGhGYWlsO1xuICAgICAgICB0aGlzLnN0ZW5jaWxPcC5kZXB0aFBhc3MgPSBkZXB0aFBhc3M7XG4gICAgfVxuXG4gICAgYXBwbHlTdGF0ZSgpIHtcbiAgICAgICAgaWYgKHRoaXMuZGVwdGhUZXN0KSB0aGlzLmdsLnJlbmRlcmVyLmVuYWJsZSh0aGlzLmdsLkRFUFRIX1RFU1QpO1xuICAgICAgICBlbHNlIHRoaXMuZ2wucmVuZGVyZXIuZGlzYWJsZSh0aGlzLmdsLkRFUFRIX1RFU1QpO1xuXG4gICAgICAgIGlmICh0aGlzLmN1bGxGYWNlKSB0aGlzLmdsLnJlbmRlcmVyLmVuYWJsZSh0aGlzLmdsLkNVTExfRkFDRSk7XG4gICAgICAgIGVsc2UgdGhpcy5nbC5yZW5kZXJlci5kaXNhYmxlKHRoaXMuZ2wuQ1VMTF9GQUNFKTtcblxuICAgICAgICBpZiAodGhpcy5ibGVuZEZ1bmMuc3JjKSB0aGlzLmdsLnJlbmRlcmVyLmVuYWJsZSh0aGlzLmdsLkJMRU5EKTtcbiAgICAgICAgZWxzZSB0aGlzLmdsLnJlbmRlcmVyLmRpc2FibGUodGhpcy5nbC5CTEVORCk7XG5cbiAgICAgICAgaWYgKHRoaXMuY3VsbEZhY2UpIHRoaXMuZ2wucmVuZGVyZXIuc2V0Q3VsbEZhY2UodGhpcy5jdWxsRmFjZSk7XG4gICAgICAgIHRoaXMuZ2wucmVuZGVyZXIuc2V0RnJvbnRGYWNlKHRoaXMuZnJvbnRGYWNlKTtcbiAgICAgICAgdGhpcy5nbC5yZW5kZXJlci5zZXREZXB0aE1hc2sodGhpcy5kZXB0aFdyaXRlKTtcbiAgICAgICAgdGhpcy5nbC5yZW5kZXJlci5zZXREZXB0aEZ1bmModGhpcy5kZXB0aEZ1bmMpO1xuICAgICAgICBpZiAodGhpcy5ibGVuZEZ1bmMuc3JjKSB0aGlzLmdsLnJlbmRlcmVyLnNldEJsZW5kRnVuYyh0aGlzLmJsZW5kRnVuYy5zcmMsIHRoaXMuYmxlbmRGdW5jLmRzdCwgdGhpcy5ibGVuZEZ1bmMuc3JjQWxwaGEsIHRoaXMuYmxlbmRGdW5jLmRzdEFscGhhKTtcbiAgICAgICAgdGhpcy5nbC5yZW5kZXJlci5zZXRCbGVuZEVxdWF0aW9uKHRoaXMuYmxlbmRFcXVhdGlvbi5tb2RlUkdCLCB0aGlzLmJsZW5kRXF1YXRpb24ubW9kZUFscGhhKTtcblxuICAgICAgICBpZih0aGlzLnN0ZW5jaWxGdW5jLmZ1bmMgfHwgdGhpcy5zdGVuY2lsT3Auc3RlbmNpbEZhaWwpIHRoaXMuZ2wucmVuZGVyZXIuZW5hYmxlKHRoaXMuZ2wuU1RFTkNJTF9URVNUKVxuICAgICAgICAgICAgZWxzZSB0aGlzLmdsLnJlbmRlcmVyLmRpc2FibGUodGhpcy5nbC5TVEVOQ0lMX1RFU1QpXG5cbiAgICAgICAgdGhpcy5nbC5yZW5kZXJlci5zZXRTdGVuY2lsRnVuYyh0aGlzLnN0ZW5jaWxGdW5jLmZ1bmMsIHRoaXMuc3RlbmNpbEZ1bmMucmVmLCB0aGlzLnN0ZW5jaWxGdW5jLm1hc2spXG4gICAgICAgIHRoaXMuZ2wucmVuZGVyZXIuc2V0U3RlbmNpbE9wKHRoaXMuc3RlbmNpbE9wLnN0ZW5jaWxGYWlsLCB0aGlzLnN0ZW5jaWxPcC5kZXB0aEZhaWwsIHRoaXMuc3RlbmNpbE9wLmRlcHRoUGFzcylcblxuICAgIH1cblxuICAgIHVzZSh7IGZsaXBGYWNlcyA9IGZhbHNlIH0gPSB7fSkge1xuICAgICAgICBsZXQgdGV4dHVyZVVuaXQgPSAtMTtcbiAgICAgICAgY29uc3QgcHJvZ3JhbUFjdGl2ZSA9IHRoaXMuZ2wucmVuZGVyZXIuc3RhdGUuY3VycmVudFByb2dyYW0gPT09IHRoaXMuaWQ7XG5cbiAgICAgICAgLy8gQXZvaWQgZ2wgY2FsbCBpZiBwcm9ncmFtIGFscmVhZHkgaW4gdXNlXG4gICAgICAgIGlmICghcHJvZ3JhbUFjdGl2ZSkge1xuICAgICAgICAgICAgdGhpcy5nbC51c2VQcm9ncmFtKHRoaXMucHJvZ3JhbSk7XG4gICAgICAgICAgICB0aGlzLmdsLnJlbmRlcmVyLnN0YXRlLmN1cnJlbnRQcm9ncmFtID0gdGhpcy5pZDtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFNldCBvbmx5IHRoZSBhY3RpdmUgdW5pZm9ybXMgZm91bmQgaW4gdGhlIHNoYWRlclxuICAgICAgICB0aGlzLnVuaWZvcm1Mb2NhdGlvbnMuZm9yRWFjaCgobG9jYXRpb24sIGFjdGl2ZVVuaWZvcm0pID0+IHtcbiAgICAgICAgICAgIGxldCB1bmlmb3JtID0gdGhpcy51bmlmb3Jtc1thY3RpdmVVbmlmb3JtLnVuaWZvcm1OYW1lXTtcblxuICAgICAgICAgICAgZm9yIChjb25zdCBjb21wb25lbnQgb2YgYWN0aXZlVW5pZm9ybS5uYW1lQ29tcG9uZW50cykge1xuICAgICAgICAgICAgICAgIGlmICghdW5pZm9ybSkgYnJlYWs7XG5cbiAgICAgICAgICAgICAgICBpZiAoY29tcG9uZW50IGluIHVuaWZvcm0pIHtcbiAgICAgICAgICAgICAgICAgICAgdW5pZm9ybSA9IHVuaWZvcm1bY29tcG9uZW50XTtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkodW5pZm9ybS52YWx1ZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdW5pZm9ybSA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoIXVuaWZvcm0pIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gd2FybihgQWN0aXZlIHVuaWZvcm0gJHthY3RpdmVVbmlmb3JtLm5hbWV9IGhhcyBub3QgYmVlbiBzdXBwbGllZGApO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAodW5pZm9ybSAmJiB1bmlmb3JtLnZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gd2FybihgJHthY3RpdmVVbmlmb3JtLm5hbWV9IHVuaWZvcm0gaXMgbWlzc2luZyBhIHZhbHVlIHBhcmFtZXRlcmApO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAodW5pZm9ybS52YWx1ZS50ZXh0dXJlKSB7XG4gICAgICAgICAgICAgICAgdGV4dHVyZVVuaXQgPSB0ZXh0dXJlVW5pdCArIDE7XG5cbiAgICAgICAgICAgICAgICAvLyBDaGVjayBpZiB0ZXh0dXJlIG5lZWRzIHRvIGJlIHVwZGF0ZWRcbiAgICAgICAgICAgICAgICB1bmlmb3JtLnZhbHVlLnVwZGF0ZSh0ZXh0dXJlVW5pdCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHNldFVuaWZvcm0odGhpcy5nbCwgYWN0aXZlVW5pZm9ybS50eXBlLCBsb2NhdGlvbiwgdGV4dHVyZVVuaXQpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBGb3IgdGV4dHVyZSBhcnJheXMsIHNldCB1bmlmb3JtIGFzIGFuIGFycmF5IG9mIHRleHR1cmUgdW5pdHMgaW5zdGVhZCBvZiBqdXN0IG9uZVxuICAgICAgICAgICAgaWYgKHVuaWZvcm0udmFsdWUubGVuZ3RoICYmIHVuaWZvcm0udmFsdWVbMF0udGV4dHVyZSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHRleHR1cmVVbml0cyA9IFtdO1xuICAgICAgICAgICAgICAgIHVuaWZvcm0udmFsdWUuZm9yRWFjaCgodmFsdWUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGV4dHVyZVVuaXQgPSB0ZXh0dXJlVW5pdCArIDE7XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlLnVwZGF0ZSh0ZXh0dXJlVW5pdCk7XG4gICAgICAgICAgICAgICAgICAgIHRleHR1cmVVbml0cy5wdXNoKHRleHR1cmVVbml0KTtcbiAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgIHJldHVybiBzZXRVbmlmb3JtKHRoaXMuZ2wsIGFjdGl2ZVVuaWZvcm0udHlwZSwgbG9jYXRpb24sIHRleHR1cmVVbml0cyk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHNldFVuaWZvcm0odGhpcy5nbCwgYWN0aXZlVW5pZm9ybS50eXBlLCBsb2NhdGlvbiwgdW5pZm9ybS52YWx1ZSk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHRoaXMuYXBwbHlTdGF0ZSgpO1xuICAgICAgICBpZiAoZmxpcEZhY2VzKSB0aGlzLmdsLnJlbmRlcmVyLnNldEZyb250RmFjZSh0aGlzLmZyb250RmFjZSA9PT0gdGhpcy5nbC5DQ1cgPyB0aGlzLmdsLkNXIDogdGhpcy5nbC5DQ1cpO1xuICAgIH1cblxuICAgIHJlbW92ZSgpIHtcbiAgICAgICAgdGhpcy5nbC5kZWxldGVQcm9ncmFtKHRoaXMucHJvZ3JhbSk7XG4gICAgfVxufVxuXG5mdW5jdGlvbiBzZXRVbmlmb3JtKGdsLCB0eXBlLCBsb2NhdGlvbiwgdmFsdWUpIHtcbiAgICB2YWx1ZSA9IHZhbHVlLmxlbmd0aCA/IGZsYXR0ZW4odmFsdWUpIDogdmFsdWU7XG4gICAgY29uc3Qgc2V0VmFsdWUgPSBnbC5yZW5kZXJlci5zdGF0ZS51bmlmb3JtTG9jYXRpb25zLmdldChsb2NhdGlvbik7XG5cbiAgICAvLyBBdm9pZCByZWR1bmRhbnQgdW5pZm9ybSBjb21tYW5kc1xuICAgIGlmICh2YWx1ZS5sZW5ndGgpIHtcbiAgICAgICAgaWYgKHNldFZhbHVlID09PSB1bmRlZmluZWQgfHwgc2V0VmFsdWUubGVuZ3RoICE9PSB2YWx1ZS5sZW5ndGgpIHtcbiAgICAgICAgICAgIC8vIGNsb25lIGFycmF5IHRvIHN0b3JlIGFzIGNhY2hlXG4gICAgICAgICAgICBnbC5yZW5kZXJlci5zdGF0ZS51bmlmb3JtTG9jYXRpb25zLnNldChsb2NhdGlvbiwgdmFsdWUuc2xpY2UoMCkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaWYgKGFycmF5c0VxdWFsKHNldFZhbHVlLCB2YWx1ZSkpIHJldHVybjtcblxuICAgICAgICAgICAgLy8gVXBkYXRlIGNhY2hlZCBhcnJheSB2YWx1ZXNcbiAgICAgICAgICAgIHNldFZhbHVlLnNldCA/IHNldFZhbHVlLnNldCh2YWx1ZSkgOiBzZXRBcnJheShzZXRWYWx1ZSwgdmFsdWUpO1xuICAgICAgICAgICAgZ2wucmVuZGVyZXIuc3RhdGUudW5pZm9ybUxvY2F0aW9ucy5zZXQobG9jYXRpb24sIHNldFZhbHVlKTtcbiAgICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICAgIGlmIChzZXRWYWx1ZSA9PT0gdmFsdWUpIHJldHVybjtcbiAgICAgICAgZ2wucmVuZGVyZXIuc3RhdGUudW5pZm9ybUxvY2F0aW9ucy5zZXQobG9jYXRpb24sIHZhbHVlKTtcbiAgICB9XG5cbiAgICBzd2l0Y2ggKHR5cGUpIHtcbiAgICAgICAgY2FzZSA1MTI2OlxuICAgICAgICAgICAgcmV0dXJuIHZhbHVlLmxlbmd0aCA/IGdsLnVuaWZvcm0xZnYobG9jYXRpb24sIHZhbHVlKSA6IGdsLnVuaWZvcm0xZihsb2NhdGlvbiwgdmFsdWUpOyAvLyBGTE9BVFxuICAgICAgICBjYXNlIDM1NjY0OlxuICAgICAgICAgICAgcmV0dXJuIGdsLnVuaWZvcm0yZnYobG9jYXRpb24sIHZhbHVlKTsgLy8gRkxPQVRfVkVDMlxuICAgICAgICBjYXNlIDM1NjY1OlxuICAgICAgICAgICAgcmV0dXJuIGdsLnVuaWZvcm0zZnYobG9jYXRpb24sIHZhbHVlKTsgLy8gRkxPQVRfVkVDM1xuICAgICAgICBjYXNlIDM1NjY2OlxuICAgICAgICAgICAgcmV0dXJuIGdsLnVuaWZvcm00ZnYobG9jYXRpb24sIHZhbHVlKTsgLy8gRkxPQVRfVkVDNFxuICAgICAgICBjYXNlIDM1NjcwOiAvLyBCT09MXG4gICAgICAgIGNhc2UgNTEyNDogLy8gSU5UXG4gICAgICAgIGNhc2UgMzU2Nzg6IC8vIFNBTVBMRVJfMkRcbiAgICAgICAgY2FzZSAzNjMwNjogLy8gVV9TQU1QTEVSXzJEXG4gICAgICAgIGNhc2UgMzU2ODA6IC8vIFNBTVBMRVJfQ1VCRVxuICAgICAgICBjYXNlIDM2Mjg5OiAvLyBTQU1QTEVSXzJEX0FSUkFZXG4gICAgICAgICAgICByZXR1cm4gdmFsdWUubGVuZ3RoID8gZ2wudW5pZm9ybTFpdihsb2NhdGlvbiwgdmFsdWUpIDogZ2wudW5pZm9ybTFpKGxvY2F0aW9uLCB2YWx1ZSk7IC8vIFNBTVBMRVJfQ1VCRVxuICAgICAgICBjYXNlIDM1NjcxOiAvLyBCT09MX1ZFQzJcbiAgICAgICAgY2FzZSAzNTY2NzpcbiAgICAgICAgICAgIHJldHVybiBnbC51bmlmb3JtMml2KGxvY2F0aW9uLCB2YWx1ZSk7IC8vIElOVF9WRUMyXG4gICAgICAgIGNhc2UgMzU2NzI6IC8vIEJPT0xfVkVDM1xuICAgICAgICBjYXNlIDM1NjY4OlxuICAgICAgICAgICAgcmV0dXJuIGdsLnVuaWZvcm0zaXYobG9jYXRpb24sIHZhbHVlKTsgLy8gSU5UX1ZFQzNcbiAgICAgICAgY2FzZSAzNTY3MzogLy8gQk9PTF9WRUM0XG4gICAgICAgIGNhc2UgMzU2Njk6XG4gICAgICAgICAgICByZXR1cm4gZ2wudW5pZm9ybTRpdihsb2NhdGlvbiwgdmFsdWUpOyAvLyBJTlRfVkVDNFxuICAgICAgICBjYXNlIDM1Njc0OlxuICAgICAgICAgICAgcmV0dXJuIGdsLnVuaWZvcm1NYXRyaXgyZnYobG9jYXRpb24sIGZhbHNlLCB2YWx1ZSk7IC8vIEZMT0FUX01BVDJcbiAgICAgICAgY2FzZSAzNTY3NTpcbiAgICAgICAgICAgIHJldHVybiBnbC51bmlmb3JtTWF0cml4M2Z2KGxvY2F0aW9uLCBmYWxzZSwgdmFsdWUpOyAvLyBGTE9BVF9NQVQzXG4gICAgICAgIGNhc2UgMzU2NzY6XG4gICAgICAgICAgICByZXR1cm4gZ2wudW5pZm9ybU1hdHJpeDRmdihsb2NhdGlvbiwgZmFsc2UsIHZhbHVlKTsgLy8gRkxPQVRfTUFUNFxuICAgIH1cbn1cblxuZnVuY3Rpb24gYWRkTGluZU51bWJlcnMoc3RyaW5nKSB7XG4gICAgbGV0IGxpbmVzID0gc3RyaW5nLnNwbGl0KCdcXG4nKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxpbmVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGxpbmVzW2ldID0gaSArIDEgKyAnOiAnICsgbGluZXNbaV07XG4gICAgfVxuICAgIHJldHVybiBsaW5lcy5qb2luKCdcXG4nKTtcbn1cblxuZnVuY3Rpb24gZmxhdHRlbihhKSB7XG4gICAgY29uc3QgYXJyYXlMZW4gPSBhLmxlbmd0aDtcbiAgICBjb25zdCB2YWx1ZUxlbiA9IGFbMF0ubGVuZ3RoO1xuICAgIGlmICh2YWx1ZUxlbiA9PT0gdW5kZWZpbmVkKSByZXR1cm4gYTtcbiAgICBjb25zdCBsZW5ndGggPSBhcnJheUxlbiAqIHZhbHVlTGVuO1xuICAgIGxldCB2YWx1ZSA9IGFycmF5Q2FjaGVGMzJbbGVuZ3RoXTtcbiAgICBpZiAoIXZhbHVlKSBhcnJheUNhY2hlRjMyW2xlbmd0aF0gPSB2YWx1ZSA9IG5ldyBGbG9hdDMyQXJyYXkobGVuZ3RoKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGFycmF5TGVuOyBpKyspIHZhbHVlLnNldChhW2ldLCBpICogdmFsdWVMZW4pO1xuICAgIHJldHVybiB2YWx1ZTtcbn1cblxuZnVuY3Rpb24gYXJyYXlzRXF1YWwoYSwgYikge1xuICAgIGlmIChhLmxlbmd0aCAhPT0gYi5sZW5ndGgpIHJldHVybiBmYWxzZTtcbiAgICBmb3IgKGxldCBpID0gMCwgbCA9IGEubGVuZ3RoOyBpIDwgbDsgaSsrKSB7XG4gICAgICAgIGlmIChhW2ldICE9PSBiW2ldKSByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xufVxuXG5mdW5jdGlvbiBzZXRBcnJheShhLCBiKSB7XG4gICAgZm9yIChsZXQgaSA9IDAsIGwgPSBhLmxlbmd0aDsgaSA8IGw7IGkrKykge1xuICAgICAgICBhW2ldID0gYltpXTtcbiAgICB9XG59XG5cbmxldCB3YXJuQ291bnQgPSAwO1xuZnVuY3Rpb24gd2FybihtZXNzYWdlKSB7XG4gICAgaWYgKHdhcm5Db3VudCA+IDEwMCkgcmV0dXJuO1xuICAgIGNvbnNvbGUud2FybihtZXNzYWdlKTtcbiAgICB3YXJuQ291bnQrKztcbiAgICBpZiAod2FybkNvdW50ID4gMTAwKSBjb25zb2xlLndhcm4oJ01vcmUgdGhhbiAxMDAgcHJvZ3JhbSB3YXJuaW5ncyAtIHN0b3BwaW5nIGxvZ3MuJyk7XG59XG4iLCJpbXBvcnQgeyBWZWMzIH0gZnJvbSAnLi4vbWF0aC9WZWMzLmpzJztcblxuLy8gVE9ETzogSGFuZGxlIGNvbnRleHQgbG9zcyBodHRwczovL3d3dy5raHJvbm9zLm9yZy93ZWJnbC93aWtpL0hhbmRsaW5nQ29udGV4dExvc3RcblxuLy8gTm90IGF1dG9tYXRpYyAtIGRldnMgdG8gdXNlIHRoZXNlIG1ldGhvZHMgbWFudWFsbHlcbi8vIGdsLmNvbG9yTWFzayggY29sb3JNYXNrLCBjb2xvck1hc2ssIGNvbG9yTWFzaywgY29sb3JNYXNrICk7XG4vLyBnbC5jbGVhckNvbG9yKCByLCBnLCBiLCBhICk7XG4vLyBnbC5zdGVuY2lsTWFzayggc3RlbmNpbE1hc2sgKTtcbi8vIGdsLnN0ZW5jaWxGdW5jKCBzdGVuY2lsRnVuYywgc3RlbmNpbFJlZiwgc3RlbmNpbE1hc2sgKTtcbi8vIGdsLnN0ZW5jaWxPcCggc3RlbmNpbEZhaWwsIHN0ZW5jaWxaRmFpbCwgc3RlbmNpbFpQYXNzICk7XG4vLyBnbC5jbGVhclN0ZW5jaWwoIHN0ZW5jaWwgKTtcblxuY29uc3QgdGVtcFZlYzMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFZlYzMoKTtcbmxldCBJRCA9IDE7XG5cbmV4cG9ydCBjbGFzcyBSZW5kZXJlciB7XG4gICAgY29uc3RydWN0b3Ioe1xuICAgICAgICBjYW52YXMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdjYW52YXMnKSxcbiAgICAgICAgd2lkdGggPSAzMDAsXG4gICAgICAgIGhlaWdodCA9IDE1MCxcbiAgICAgICAgZHByID0gMSxcbiAgICAgICAgYWxwaGEgPSBmYWxzZSxcbiAgICAgICAgZGVwdGggPSB0cnVlLFxuICAgICAgICBzdGVuY2lsID0gZmFsc2UsXG4gICAgICAgIGFudGlhbGlhcyA9IGZhbHNlLFxuICAgICAgICBwcmVtdWx0aXBsaWVkQWxwaGEgPSBmYWxzZSxcbiAgICAgICAgcHJlc2VydmVEcmF3aW5nQnVmZmVyID0gZmFsc2UsXG4gICAgICAgIHBvd2VyUHJlZmVyZW5jZSA9ICdkZWZhdWx0JyxcbiAgICAgICAgYXV0b0NsZWFyID0gdHJ1ZSxcbiAgICAgICAgd2ViZ2wgPSAyLFxuICAgIH0gPSB7fSkge1xuICAgICAgICBjb25zdCBhdHRyaWJ1dGVzID0geyBhbHBoYSwgZGVwdGgsIHN0ZW5jaWwsIGFudGlhbGlhcywgcHJlbXVsdGlwbGllZEFscGhhLCBwcmVzZXJ2ZURyYXdpbmdCdWZmZXIsIHBvd2VyUHJlZmVyZW5jZSB9O1xuICAgICAgICB0aGlzLmRwciA9IGRwcjtcbiAgICAgICAgdGhpcy5hbHBoYSA9IGFscGhhO1xuICAgICAgICB0aGlzLmNvbG9yID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5kZXB0aCA9IGRlcHRoO1xuICAgICAgICB0aGlzLnN0ZW5jaWwgPSBzdGVuY2lsO1xuICAgICAgICB0aGlzLnByZW11bHRpcGxpZWRBbHBoYSA9IHByZW11bHRpcGxpZWRBbHBoYTtcbiAgICAgICAgdGhpcy5hdXRvQ2xlYXIgPSBhdXRvQ2xlYXI7XG4gICAgICAgIHRoaXMuaWQgPSBJRCsrO1xuXG4gICAgICAgIC8vIEF0dGVtcHQgV2ViR0wyIHVubGVzcyBmb3JjZWQgdG8gMSwgaWYgbm90IHN1cHBvcnRlZCBmYWxsYmFjayB0byBXZWJHTDFcbiAgICAgICAgaWYgKHdlYmdsID09PSAyKSB0aGlzLmdsID0gY2FudmFzLmdldENvbnRleHQoJ3dlYmdsMicsIGF0dHJpYnV0ZXMpO1xuICAgICAgICB0aGlzLmlzV2ViZ2wyID0gISF0aGlzLmdsO1xuICAgICAgICBpZiAoIXRoaXMuZ2wpIHRoaXMuZ2wgPSBjYW52YXMuZ2V0Q29udGV4dCgnd2ViZ2wnLCBhdHRyaWJ1dGVzKTtcbiAgICAgICAgaWYgKCF0aGlzLmdsKSBjb25zb2xlLmVycm9yKCd1bmFibGUgdG8gY3JlYXRlIHdlYmdsIGNvbnRleHQnKTtcblxuICAgICAgICAvLyBBdHRhY2ggcmVuZGVyZXIgdG8gZ2wgc28gdGhhdCBhbGwgY2xhc3NlcyBoYXZlIGFjY2VzcyB0byBpbnRlcm5hbCBzdGF0ZSBmdW5jdGlvbnNcbiAgICAgICAgdGhpcy5nbC5yZW5kZXJlciA9IHRoaXM7XG5cbiAgICAgICAgLy8gaW5pdGlhbGlzZSBzaXplIHZhbHVlc1xuICAgICAgICB0aGlzLnNldFNpemUod2lkdGgsIGhlaWdodCk7XG5cbiAgICAgICAgLy8gZ2wgc3RhdGUgc3RvcmVzIHRvIGF2b2lkIHJlZHVuZGFudCBjYWxscyBvbiBtZXRob2RzIHVzZWQgaW50ZXJuYWxseVxuICAgICAgICB0aGlzLnN0YXRlID0ge307XG4gICAgICAgIHRoaXMuc3RhdGUuYmxlbmRGdW5jID0geyBzcmM6IHRoaXMuZ2wuT05FLCBkc3Q6IHRoaXMuZ2wuWkVSTyB9O1xuICAgICAgICB0aGlzLnN0YXRlLmJsZW5kRXF1YXRpb24gPSB7IG1vZGVSR0I6IHRoaXMuZ2wuRlVOQ19BREQgfTtcbiAgICAgICAgdGhpcy5zdGF0ZS5jdWxsRmFjZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLnN0YXRlLmZyb250RmFjZSA9IHRoaXMuZ2wuQ0NXO1xuICAgICAgICB0aGlzLnN0YXRlLmRlcHRoTWFzayA9IHRydWU7XG4gICAgICAgIHRoaXMuc3RhdGUuZGVwdGhGdW5jID0gdGhpcy5nbC5MRVFVQUw7XG4gICAgICAgIHRoaXMuc3RhdGUucHJlbXVsdGlwbHlBbHBoYSA9IGZhbHNlO1xuICAgICAgICB0aGlzLnN0YXRlLmZsaXBZID0gZmFsc2U7XG4gICAgICAgIHRoaXMuc3RhdGUudW5wYWNrQWxpZ25tZW50ID0gNDtcbiAgICAgICAgdGhpcy5zdGF0ZS5mcmFtZWJ1ZmZlciA9IG51bGw7XG4gICAgICAgIHRoaXMuc3RhdGUudmlld3BvcnQgPSB7IHg6IDAsIHk6IDAsIHdpZHRoOiBudWxsLCBoZWlnaHQ6IG51bGwgfTtcbiAgICAgICAgdGhpcy5zdGF0ZS50ZXh0dXJlVW5pdHMgPSBbXTtcbiAgICAgICAgdGhpcy5zdGF0ZS5hY3RpdmVUZXh0dXJlVW5pdCA9IDA7XG4gICAgICAgIHRoaXMuc3RhdGUuYm91bmRCdWZmZXIgPSBudWxsO1xuICAgICAgICB0aGlzLnN0YXRlLnVuaWZvcm1Mb2NhdGlvbnMgPSBuZXcgTWFwKCk7XG4gICAgICAgIHRoaXMuc3RhdGUuY3VycmVudFByb2dyYW0gPSBudWxsO1xuXG4gICAgICAgIC8vIHN0b3JlIHJlcXVlc3RlZCBleHRlbnNpb25zXG4gICAgICAgIHRoaXMuZXh0ZW5zaW9ucyA9IHt9O1xuXG4gICAgICAgIC8vIEluaXRpYWxpc2UgZXh0cmEgZm9ybWF0IHR5cGVzXG4gICAgICAgIGlmICh0aGlzLmlzV2ViZ2wyKSB7XG4gICAgICAgICAgICB0aGlzLmdldEV4dGVuc2lvbignRVhUX2NvbG9yX2J1ZmZlcl9mbG9hdCcpO1xuICAgICAgICAgICAgdGhpcy5nZXRFeHRlbnNpb24oJ09FU190ZXh0dXJlX2Zsb2F0X2xpbmVhcicpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5nZXRFeHRlbnNpb24oJ09FU190ZXh0dXJlX2Zsb2F0Jyk7XG4gICAgICAgICAgICB0aGlzLmdldEV4dGVuc2lvbignT0VTX3RleHR1cmVfZmxvYXRfbGluZWFyJyk7XG4gICAgICAgICAgICB0aGlzLmdldEV4dGVuc2lvbignT0VTX3RleHR1cmVfaGFsZl9mbG9hdCcpO1xuICAgICAgICAgICAgdGhpcy5nZXRFeHRlbnNpb24oJ09FU190ZXh0dXJlX2hhbGZfZmxvYXRfbGluZWFyJyk7XG4gICAgICAgICAgICB0aGlzLmdldEV4dGVuc2lvbignT0VTX2VsZW1lbnRfaW5kZXhfdWludCcpO1xuICAgICAgICAgICAgdGhpcy5nZXRFeHRlbnNpb24oJ09FU19zdGFuZGFyZF9kZXJpdmF0aXZlcycpO1xuICAgICAgICAgICAgdGhpcy5nZXRFeHRlbnNpb24oJ0VYVF9zUkdCJyk7XG4gICAgICAgICAgICB0aGlzLmdldEV4dGVuc2lvbignV0VCR0xfZGVwdGhfdGV4dHVyZScpO1xuICAgICAgICAgICAgdGhpcy5nZXRFeHRlbnNpb24oJ1dFQkdMX2RyYXdfYnVmZmVycycpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZ2V0RXh0ZW5zaW9uKCdXRUJHTF9jb21wcmVzc2VkX3RleHR1cmVfYXN0YycpO1xuICAgICAgICB0aGlzLmdldEV4dGVuc2lvbignRVhUX3RleHR1cmVfY29tcHJlc3Npb25fYnB0YycpO1xuICAgICAgICB0aGlzLmdldEV4dGVuc2lvbignV0VCR0xfY29tcHJlc3NlZF90ZXh0dXJlX3MzdGMnKTtcbiAgICAgICAgdGhpcy5nZXRFeHRlbnNpb24oJ1dFQkdMX2NvbXByZXNzZWRfdGV4dHVyZV9ldGMxJyk7XG4gICAgICAgIHRoaXMuZ2V0RXh0ZW5zaW9uKCdXRUJHTF9jb21wcmVzc2VkX3RleHR1cmVfcHZydGMnKTtcbiAgICAgICAgdGhpcy5nZXRFeHRlbnNpb24oJ1dFQktJVF9XRUJHTF9jb21wcmVzc2VkX3RleHR1cmVfcHZydGMnKTtcblxuICAgICAgICAvLyBDcmVhdGUgbWV0aG9kIGFsaWFzZXMgdXNpbmcgZXh0ZW5zaW9uIChXZWJHTDEpIG9yIG5hdGl2ZSBpZiBhdmFpbGFibGUgKFdlYkdMMilcbiAgICAgICAgdGhpcy52ZXJ0ZXhBdHRyaWJEaXZpc29yID0gdGhpcy5nZXRFeHRlbnNpb24oJ0FOR0xFX2luc3RhbmNlZF9hcnJheXMnLCAndmVydGV4QXR0cmliRGl2aXNvcicsICd2ZXJ0ZXhBdHRyaWJEaXZpc29yQU5HTEUnKTtcbiAgICAgICAgdGhpcy5kcmF3QXJyYXlzSW5zdGFuY2VkID0gdGhpcy5nZXRFeHRlbnNpb24oJ0FOR0xFX2luc3RhbmNlZF9hcnJheXMnLCAnZHJhd0FycmF5c0luc3RhbmNlZCcsICdkcmF3QXJyYXlzSW5zdGFuY2VkQU5HTEUnKTtcbiAgICAgICAgdGhpcy5kcmF3RWxlbWVudHNJbnN0YW5jZWQgPSB0aGlzLmdldEV4dGVuc2lvbignQU5HTEVfaW5zdGFuY2VkX2FycmF5cycsICdkcmF3RWxlbWVudHNJbnN0YW5jZWQnLCAnZHJhd0VsZW1lbnRzSW5zdGFuY2VkQU5HTEUnKTtcbiAgICAgICAgdGhpcy5jcmVhdGVWZXJ0ZXhBcnJheSA9IHRoaXMuZ2V0RXh0ZW5zaW9uKCdPRVNfdmVydGV4X2FycmF5X29iamVjdCcsICdjcmVhdGVWZXJ0ZXhBcnJheScsICdjcmVhdGVWZXJ0ZXhBcnJheU9FUycpO1xuICAgICAgICB0aGlzLmJpbmRWZXJ0ZXhBcnJheSA9IHRoaXMuZ2V0RXh0ZW5zaW9uKCdPRVNfdmVydGV4X2FycmF5X29iamVjdCcsICdiaW5kVmVydGV4QXJyYXknLCAnYmluZFZlcnRleEFycmF5T0VTJyk7XG4gICAgICAgIHRoaXMuZGVsZXRlVmVydGV4QXJyYXkgPSB0aGlzLmdldEV4dGVuc2lvbignT0VTX3ZlcnRleF9hcnJheV9vYmplY3QnLCAnZGVsZXRlVmVydGV4QXJyYXknLCAnZGVsZXRlVmVydGV4QXJyYXlPRVMnKTtcbiAgICAgICAgdGhpcy5kcmF3QnVmZmVycyA9IHRoaXMuZ2V0RXh0ZW5zaW9uKCdXRUJHTF9kcmF3X2J1ZmZlcnMnLCAnZHJhd0J1ZmZlcnMnLCAnZHJhd0J1ZmZlcnNXRUJHTCcpO1xuXG4gICAgICAgIC8vIFN0b3JlIGRldmljZSBwYXJhbWV0ZXJzXG4gICAgICAgIHRoaXMucGFyYW1ldGVycyA9IHt9O1xuICAgICAgICB0aGlzLnBhcmFtZXRlcnMubWF4VGV4dHVyZVVuaXRzID0gdGhpcy5nbC5nZXRQYXJhbWV0ZXIodGhpcy5nbC5NQVhfQ09NQklORURfVEVYVFVSRV9JTUFHRV9VTklUUyk7XG4gICAgICAgIHRoaXMucGFyYW1ldGVycy5tYXhBbmlzb3Ryb3B5ID0gdGhpcy5nZXRFeHRlbnNpb24oJ0VYVF90ZXh0dXJlX2ZpbHRlcl9hbmlzb3Ryb3BpYycpXG4gICAgICAgICAgICA/IHRoaXMuZ2wuZ2V0UGFyYW1ldGVyKHRoaXMuZ2V0RXh0ZW5zaW9uKCdFWFRfdGV4dHVyZV9maWx0ZXJfYW5pc290cm9waWMnKS5NQVhfVEVYVFVSRV9NQVhfQU5JU09UUk9QWV9FWFQpXG4gICAgICAgICAgICA6IDA7XG4gICAgfVxuXG4gICAgc2V0U2l6ZSh3aWR0aCwgaGVpZ2h0KSB7XG4gICAgICAgIHRoaXMud2lkdGggPSB3aWR0aDtcbiAgICAgICAgdGhpcy5oZWlnaHQgPSBoZWlnaHQ7XG5cbiAgICAgICAgdGhpcy5nbC5jYW52YXMud2lkdGggPSB3aWR0aCAqIHRoaXMuZHByO1xuICAgICAgICB0aGlzLmdsLmNhbnZhcy5oZWlnaHQgPSBoZWlnaHQgKiB0aGlzLmRwcjtcblxuICAgICAgICBpZiAoIXRoaXMuZ2wuY2FudmFzLnN0eWxlKSByZXR1cm47XG4gICAgICAgIE9iamVjdC5hc3NpZ24odGhpcy5nbC5jYW52YXMuc3R5bGUsIHtcbiAgICAgICAgICAgIHdpZHRoOiB3aWR0aCArICdweCcsXG4gICAgICAgICAgICBoZWlnaHQ6IGhlaWdodCArICdweCcsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIHNldFZpZXdwb3J0KHdpZHRoLCBoZWlnaHQsIHggPSAwLCB5ID0gMCkge1xuICAgICAgICBpZiAodGhpcy5zdGF0ZS52aWV3cG9ydC53aWR0aCA9PT0gd2lkdGggJiYgdGhpcy5zdGF0ZS52aWV3cG9ydC5oZWlnaHQgPT09IGhlaWdodCkgcmV0dXJuO1xuICAgICAgICB0aGlzLnN0YXRlLnZpZXdwb3J0LndpZHRoID0gd2lkdGg7XG4gICAgICAgIHRoaXMuc3RhdGUudmlld3BvcnQuaGVpZ2h0ID0gaGVpZ2h0O1xuICAgICAgICB0aGlzLnN0YXRlLnZpZXdwb3J0LnggPSB4O1xuICAgICAgICB0aGlzLnN0YXRlLnZpZXdwb3J0LnkgPSB5O1xuICAgICAgICB0aGlzLmdsLnZpZXdwb3J0KHgsIHksIHdpZHRoLCBoZWlnaHQpO1xuICAgIH1cblxuICAgIHNldFNjaXNzb3Iod2lkdGgsIGhlaWdodCwgeCA9IDAsIHkgPSAwKSB7XG4gICAgICAgIHRoaXMuZ2wuc2Npc3Nvcih4LCB5LCB3aWR0aCwgaGVpZ2h0KTtcbiAgICB9XG5cbiAgICBlbmFibGUoaWQpIHtcbiAgICAgICAgaWYgKHRoaXMuc3RhdGVbaWRdID09PSB0cnVlKSByZXR1cm47XG4gICAgICAgIHRoaXMuZ2wuZW5hYmxlKGlkKTtcbiAgICAgICAgdGhpcy5zdGF0ZVtpZF0gPSB0cnVlO1xuICAgIH1cblxuICAgIGRpc2FibGUoaWQpIHtcbiAgICAgICAgaWYgKHRoaXMuc3RhdGVbaWRdID09PSBmYWxzZSkgcmV0dXJuO1xuICAgICAgICB0aGlzLmdsLmRpc2FibGUoaWQpO1xuICAgICAgICB0aGlzLnN0YXRlW2lkXSA9IGZhbHNlO1xuICAgIH1cblxuICAgIHNldEJsZW5kRnVuYyhzcmMsIGRzdCwgc3JjQWxwaGEsIGRzdEFscGhhKSB7XG4gICAgICAgIGlmIChcbiAgICAgICAgICAgIHRoaXMuc3RhdGUuYmxlbmRGdW5jLnNyYyA9PT0gc3JjICYmXG4gICAgICAgICAgICB0aGlzLnN0YXRlLmJsZW5kRnVuYy5kc3QgPT09IGRzdCAmJlxuICAgICAgICAgICAgdGhpcy5zdGF0ZS5ibGVuZEZ1bmMuc3JjQWxwaGEgPT09IHNyY0FscGhhICYmXG4gICAgICAgICAgICB0aGlzLnN0YXRlLmJsZW5kRnVuYy5kc3RBbHBoYSA9PT0gZHN0QWxwaGFcbiAgICAgICAgKVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB0aGlzLnN0YXRlLmJsZW5kRnVuYy5zcmMgPSBzcmM7XG4gICAgICAgIHRoaXMuc3RhdGUuYmxlbmRGdW5jLmRzdCA9IGRzdDtcbiAgICAgICAgdGhpcy5zdGF0ZS5ibGVuZEZ1bmMuc3JjQWxwaGEgPSBzcmNBbHBoYTtcbiAgICAgICAgdGhpcy5zdGF0ZS5ibGVuZEZ1bmMuZHN0QWxwaGEgPSBkc3RBbHBoYTtcbiAgICAgICAgaWYgKHNyY0FscGhhICE9PSB1bmRlZmluZWQpIHRoaXMuZ2wuYmxlbmRGdW5jU2VwYXJhdGUoc3JjLCBkc3QsIHNyY0FscGhhLCBkc3RBbHBoYSk7XG4gICAgICAgIGVsc2UgdGhpcy5nbC5ibGVuZEZ1bmMoc3JjLCBkc3QpO1xuICAgIH1cblxuICAgIHNldEJsZW5kRXF1YXRpb24obW9kZVJHQiwgbW9kZUFscGhhKSB7XG4gICAgICAgIG1vZGVSR0IgPSBtb2RlUkdCIHx8IHRoaXMuZ2wuRlVOQ19BREQ7XG4gICAgICAgIGlmICh0aGlzLnN0YXRlLmJsZW5kRXF1YXRpb24ubW9kZVJHQiA9PT0gbW9kZVJHQiAmJiB0aGlzLnN0YXRlLmJsZW5kRXF1YXRpb24ubW9kZUFscGhhID09PSBtb2RlQWxwaGEpIHJldHVybjtcbiAgICAgICAgdGhpcy5zdGF0ZS5ibGVuZEVxdWF0aW9uLm1vZGVSR0IgPSBtb2RlUkdCO1xuICAgICAgICB0aGlzLnN0YXRlLmJsZW5kRXF1YXRpb24ubW9kZUFscGhhID0gbW9kZUFscGhhO1xuICAgICAgICBpZiAobW9kZUFscGhhICE9PSB1bmRlZmluZWQpIHRoaXMuZ2wuYmxlbmRFcXVhdGlvblNlcGFyYXRlKG1vZGVSR0IsIG1vZGVBbHBoYSk7XG4gICAgICAgIGVsc2UgdGhpcy5nbC5ibGVuZEVxdWF0aW9uKG1vZGVSR0IpO1xuICAgIH1cblxuICAgIHNldEN1bGxGYWNlKHZhbHVlKSB7XG4gICAgICAgIGlmICh0aGlzLnN0YXRlLmN1bGxGYWNlID09PSB2YWx1ZSkgcmV0dXJuO1xuICAgICAgICB0aGlzLnN0YXRlLmN1bGxGYWNlID0gdmFsdWU7XG4gICAgICAgIHRoaXMuZ2wuY3VsbEZhY2UodmFsdWUpO1xuICAgIH1cblxuICAgIHNldEZyb250RmFjZSh2YWx1ZSkge1xuICAgICAgICBpZiAodGhpcy5zdGF0ZS5mcm9udEZhY2UgPT09IHZhbHVlKSByZXR1cm47XG4gICAgICAgIHRoaXMuc3RhdGUuZnJvbnRGYWNlID0gdmFsdWU7XG4gICAgICAgIHRoaXMuZ2wuZnJvbnRGYWNlKHZhbHVlKTtcbiAgICB9XG5cbiAgICBzZXREZXB0aE1hc2sodmFsdWUpIHtcbiAgICAgICAgaWYgKHRoaXMuc3RhdGUuZGVwdGhNYXNrID09PSB2YWx1ZSkgcmV0dXJuO1xuICAgICAgICB0aGlzLnN0YXRlLmRlcHRoTWFzayA9IHZhbHVlO1xuICAgICAgICB0aGlzLmdsLmRlcHRoTWFzayh2YWx1ZSk7XG4gICAgfVxuXG4gICAgc2V0RGVwdGhGdW5jKHZhbHVlKSB7XG4gICAgICAgIGlmICh0aGlzLnN0YXRlLmRlcHRoRnVuYyA9PT0gdmFsdWUpIHJldHVybjtcbiAgICAgICAgdGhpcy5zdGF0ZS5kZXB0aEZ1bmMgPSB2YWx1ZTtcbiAgICAgICAgdGhpcy5nbC5kZXB0aEZ1bmModmFsdWUpO1xuICAgIH1cblxuICAgIHNldFN0ZW5jaWxNYXNrKHZhbHVlKSB7XG4gICAgICAgIGlmKHRoaXMuc3RhdGUuc3RlbmNpbE1hc2sgPT09IHZhbHVlKSByZXR1cm47XG4gICAgICAgIHRoaXMuc3RhdGUuc3RlbmNpbE1hc2sgPSB2YWx1ZTtcbiAgICAgICAgdGhpcy5nbC5zdGVuY2lsTWFzayh2YWx1ZSlcbiAgICB9XG5cbiAgICBzZXRTdGVuY2lsRnVuYyhmdW5jLCByZWYsIG1hc2spIHtcblxuICAgICAgICBpZigodGhpcy5zdGF0ZS5zdGVuY2lsRnVuYyA9PT0gZnVuYykgJiZcbiAgICAgICAgICAgICh0aGlzLnN0YXRlLnN0ZW5jaWxSZWYgPT09IHJlZikgJiZcbiAgICAgICAgICAgICh0aGlzLnN0YXRlLnN0ZW5jaWxGdW5jTWFzayA9PT0gbWFzaylcbiAgICAgICAgKSByZXR1cm47XG5cbiAgICAgICAgdGhpcy5zdGF0ZS5zdGVuY2lsRnVuYyA9IGZ1bmMgfHwgdGhpcy5nbC5BTFdBWVM7XG4gICAgICAgIHRoaXMuc3RhdGUuc3RlbmNpbFJlZiA9IHJlZiB8fCAwO1xuICAgICAgICB0aGlzLnN0YXRlLnN0ZW5jaWxGdW5jTWFzayA9IG1hc2sgfHwgMDtcblxuICAgICAgICB0aGlzLmdsLnN0ZW5jaWxGdW5jKGZ1bmMgfHwgdGhpcy5nbC5BTFdBWVMsIHJlZiB8fCAwLCBtYXNrIHx8IDApO1xuICAgIH1cblxuICAgIHNldFN0ZW5jaWxPcChzdGVuY2lsRmFpbCwgZGVwdGhGYWlsLCBkZXB0aFBhc3MpIHtcblxuICAgICAgICBpZih0aGlzLnN0YXRlLnN0ZW5jaWxGYWlsID09PSBzdGVuY2lsRmFpbCAmJlxuICAgICAgICAgICAgdGhpcy5zdGF0ZS5zdGVuY2lsRGVwdGhGYWlsID09PSBkZXB0aEZhaWwgJiZcbiAgICAgICAgICAgIHRoaXMuc3RhdGUuc3RlbmNpbERlcHRoUGFzcyA9PT0gZGVwdGhQYXNzXG4gICAgICAgICkgcmV0dXJuO1xuXG4gICAgICAgIHRoaXMuc3RhdGUuc3RlbmNpbEZhaWwgPSBzdGVuY2lsRmFpbDtcbiAgICAgICAgdGhpcy5zdGF0ZS5zdGVuY2lsRGVwdGhGYWlsID0gZGVwdGhGYWlsO1xuICAgICAgICB0aGlzLnN0YXRlLnN0ZW5jaWxEZXB0aFBhc3MgPSBkZXB0aFBhc3M7XG4gICAgICAgIFxuICAgICAgICB0aGlzLmdsLnN0ZW5jaWxPcChzdGVuY2lsRmFpbCwgZGVwdGhGYWlsLCBkZXB0aFBhc3MpO1xuICAgICAgICBcbiAgICB9XG5cbiAgICBhY3RpdmVUZXh0dXJlKHZhbHVlKSB7XG4gICAgICAgIGlmICh0aGlzLnN0YXRlLmFjdGl2ZVRleHR1cmVVbml0ID09PSB2YWx1ZSkgcmV0dXJuO1xuICAgICAgICB0aGlzLnN0YXRlLmFjdGl2ZVRleHR1cmVVbml0ID0gdmFsdWU7XG4gICAgICAgIHRoaXMuZ2wuYWN0aXZlVGV4dHVyZSh0aGlzLmdsLlRFWFRVUkUwICsgdmFsdWUpO1xuICAgIH1cblxuICAgIGJpbmRGcmFtZWJ1ZmZlcih7IHRhcmdldCA9IHRoaXMuZ2wuRlJBTUVCVUZGRVIsIGJ1ZmZlciA9IG51bGwgfSA9IHt9KSB7XG4gICAgICAgIGlmICh0aGlzLnN0YXRlLmZyYW1lYnVmZmVyID09PSBidWZmZXIpIHJldHVybjtcbiAgICAgICAgdGhpcy5zdGF0ZS5mcmFtZWJ1ZmZlciA9IGJ1ZmZlcjtcbiAgICAgICAgdGhpcy5nbC5iaW5kRnJhbWVidWZmZXIodGFyZ2V0LCBidWZmZXIpO1xuICAgIH1cblxuICAgIGdldEV4dGVuc2lvbihleHRlbnNpb24sIHdlYmdsMkZ1bmMsIGV4dEZ1bmMpIHtcbiAgICAgICAgLy8gaWYgd2ViZ2wyIGZ1bmN0aW9uIHN1cHBvcnRlZCwgcmV0dXJuIGZ1bmMgYm91bmQgdG8gZ2wgY29udGV4dFxuICAgICAgICBpZiAod2ViZ2wyRnVuYyAmJiB0aGlzLmdsW3dlYmdsMkZ1bmNdKSByZXR1cm4gdGhpcy5nbFt3ZWJnbDJGdW5jXS5iaW5kKHRoaXMuZ2wpO1xuXG4gICAgICAgIC8vIGZldGNoIGV4dGVuc2lvbiBvbmNlIG9ubHlcbiAgICAgICAgaWYgKCF0aGlzLmV4dGVuc2lvbnNbZXh0ZW5zaW9uXSkge1xuICAgICAgICAgICAgdGhpcy5leHRlbnNpb25zW2V4dGVuc2lvbl0gPSB0aGlzLmdsLmdldEV4dGVuc2lvbihleHRlbnNpb24pO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gcmV0dXJuIGV4dGVuc2lvbiBpZiBubyBmdW5jdGlvbiByZXF1ZXN0ZWRcbiAgICAgICAgaWYgKCF3ZWJnbDJGdW5jKSByZXR1cm4gdGhpcy5leHRlbnNpb25zW2V4dGVuc2lvbl07XG5cbiAgICAgICAgLy8gUmV0dXJuIG51bGwgaWYgZXh0ZW5zaW9uIG5vdCBzdXBwb3J0ZWRcbiAgICAgICAgaWYgKCF0aGlzLmV4dGVuc2lvbnNbZXh0ZW5zaW9uXSkgcmV0dXJuIG51bGw7XG5cbiAgICAgICAgLy8gcmV0dXJuIGV4dGVuc2lvbiBmdW5jdGlvbiwgYm91bmQgdG8gZXh0ZW5zaW9uXG4gICAgICAgIHJldHVybiB0aGlzLmV4dGVuc2lvbnNbZXh0ZW5zaW9uXVtleHRGdW5jXS5iaW5kKHRoaXMuZXh0ZW5zaW9uc1tleHRlbnNpb25dKTtcbiAgICB9XG5cbiAgICBzb3J0T3BhcXVlKGEsIGIpIHtcbiAgICAgICAgaWYgKGEucmVuZGVyT3JkZXIgIT09IGIucmVuZGVyT3JkZXIpIHtcbiAgICAgICAgICAgIHJldHVybiBhLnJlbmRlck9yZGVyIC0gYi5yZW5kZXJPcmRlcjtcbiAgICAgICAgfSBlbHNlIGlmIChhLnByb2dyYW0uaWQgIT09IGIucHJvZ3JhbS5pZCkge1xuICAgICAgICAgICAgcmV0dXJuIGEucHJvZ3JhbS5pZCAtIGIucHJvZ3JhbS5pZDtcbiAgICAgICAgfSBlbHNlIGlmIChhLnpEZXB0aCAhPT0gYi56RGVwdGgpIHtcbiAgICAgICAgICAgIHJldHVybiBhLnpEZXB0aCAtIGIuekRlcHRoO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIGIuaWQgLSBhLmlkO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgc29ydFRyYW5zcGFyZW50KGEsIGIpIHtcbiAgICAgICAgaWYgKGEucmVuZGVyT3JkZXIgIT09IGIucmVuZGVyT3JkZXIpIHtcbiAgICAgICAgICAgIHJldHVybiBhLnJlbmRlck9yZGVyIC0gYi5yZW5kZXJPcmRlcjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoYS56RGVwdGggIT09IGIuekRlcHRoKSB7XG4gICAgICAgICAgICByZXR1cm4gYi56RGVwdGggLSBhLnpEZXB0aDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiBiLmlkIC0gYS5pZDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHNvcnRVSShhLCBiKSB7XG4gICAgICAgIGlmIChhLnJlbmRlck9yZGVyICE9PSBiLnJlbmRlck9yZGVyKSB7XG4gICAgICAgICAgICByZXR1cm4gYS5yZW5kZXJPcmRlciAtIGIucmVuZGVyT3JkZXI7XG4gICAgICAgIH0gZWxzZSBpZiAoYS5wcm9ncmFtLmlkICE9PSBiLnByb2dyYW0uaWQpIHtcbiAgICAgICAgICAgIHJldHVybiBhLnByb2dyYW0uaWQgLSBiLnByb2dyYW0uaWQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gYi5pZCAtIGEuaWQ7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBnZXRSZW5kZXJMaXN0KHsgc2NlbmUsIGNhbWVyYSwgZnJ1c3R1bUN1bGwsIHNvcnQgfSkge1xuICAgICAgICBsZXQgcmVuZGVyTGlzdCA9IFtdO1xuXG4gICAgICAgIGlmIChjYW1lcmEgJiYgZnJ1c3R1bUN1bGwpIGNhbWVyYS51cGRhdGVGcnVzdHVtKCk7XG5cbiAgICAgICAgLy8gR2V0IHZpc2libGVcbiAgICAgICAgc2NlbmUudHJhdmVyc2UoKG5vZGUpID0+IHtcbiAgICAgICAgICAgIGlmICghbm9kZS52aXNpYmxlKSByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIGlmICghbm9kZS5kcmF3KSByZXR1cm47XG5cbiAgICAgICAgICAgIGlmIChmcnVzdHVtQ3VsbCAmJiBub2RlLmZydXN0dW1DdWxsZWQgJiYgY2FtZXJhKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFjYW1lcmEuZnJ1c3R1bUludGVyc2VjdHNNZXNoKG5vZGUpKSByZXR1cm47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJlbmRlckxpc3QucHVzaChub2RlKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKHNvcnQpIHtcbiAgICAgICAgICAgIGNvbnN0IG9wYXF1ZSA9IFtdO1xuICAgICAgICAgICAgY29uc3QgdHJhbnNwYXJlbnQgPSBbXTsgLy8gZGVwdGhUZXN0IHRydWVcbiAgICAgICAgICAgIGNvbnN0IHVpID0gW107IC8vIGRlcHRoVGVzdCBmYWxzZVxuXG4gICAgICAgICAgICByZW5kZXJMaXN0LmZvckVhY2goKG5vZGUpID0+IHtcbiAgICAgICAgICAgICAgICAvLyBTcGxpdCBpbnRvIHRoZSAzIHJlbmRlciBncm91cHNcbiAgICAgICAgICAgICAgICBpZiAoIW5vZGUucHJvZ3JhbS50cmFuc3BhcmVudCkge1xuICAgICAgICAgICAgICAgICAgICBvcGFxdWUucHVzaChub2RlKTtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKG5vZGUucHJvZ3JhbS5kZXB0aFRlc3QpIHtcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNwYXJlbnQucHVzaChub2RlKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB1aS5wdXNoKG5vZGUpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIG5vZGUuekRlcHRoID0gMDtcblxuICAgICAgICAgICAgICAgIC8vIE9ubHkgY2FsY3VsYXRlIHotZGVwdGggaWYgcmVuZGVyT3JkZXIgdW5zZXQgYW5kIGRlcHRoVGVzdCBpcyB0cnVlXG4gICAgICAgICAgICAgICAgaWYgKG5vZGUucmVuZGVyT3JkZXIgIT09IDAgfHwgIW5vZGUucHJvZ3JhbS5kZXB0aFRlc3QgfHwgIWNhbWVyYSkgcmV0dXJuO1xuXG4gICAgICAgICAgICAgICAgLy8gdXBkYXRlIHotZGVwdGhcbiAgICAgICAgICAgICAgICBub2RlLndvcmxkTWF0cml4LmdldFRyYW5zbGF0aW9uKHRlbXBWZWMzKTtcbiAgICAgICAgICAgICAgICB0ZW1wVmVjMy5hcHBseU1hdHJpeDQoY2FtZXJhLnByb2plY3Rpb25WaWV3TWF0cml4KTtcbiAgICAgICAgICAgICAgICBub2RlLnpEZXB0aCA9IHRlbXBWZWMzLno7XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgb3BhcXVlLnNvcnQodGhpcy5zb3J0T3BhcXVlKTtcbiAgICAgICAgICAgIHRyYW5zcGFyZW50LnNvcnQodGhpcy5zb3J0VHJhbnNwYXJlbnQpO1xuICAgICAgICAgICAgdWkuc29ydCh0aGlzLnNvcnRVSSk7XG5cbiAgICAgICAgICAgIHJlbmRlckxpc3QgPSBvcGFxdWUuY29uY2F0KHRyYW5zcGFyZW50LCB1aSk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gcmVuZGVyTGlzdDtcbiAgICB9XG5cbiAgICByZW5kZXIoeyBzY2VuZSwgY2FtZXJhLCB0YXJnZXQgPSBudWxsLCB1cGRhdGUgPSB0cnVlLCBzb3J0ID0gdHJ1ZSwgZnJ1c3R1bUN1bGwgPSB0cnVlLCBjbGVhciB9KSB7XG4gICAgICAgIGlmICh0YXJnZXQgPT09IG51bGwpIHtcbiAgICAgICAgICAgIC8vIG1ha2Ugc3VyZSBubyByZW5kZXIgdGFyZ2V0IGJvdW5kIHNvIGRyYXdzIHRvIGNhbnZhc1xuICAgICAgICAgICAgdGhpcy5iaW5kRnJhbWVidWZmZXIoKTtcbiAgICAgICAgICAgIHRoaXMuc2V0Vmlld3BvcnQodGhpcy53aWR0aCAqIHRoaXMuZHByLCB0aGlzLmhlaWdodCAqIHRoaXMuZHByKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIGJpbmQgc3VwcGxpZWQgcmVuZGVyIHRhcmdldCBhbmQgdXBkYXRlIHZpZXdwb3J0XG4gICAgICAgICAgICB0aGlzLmJpbmRGcmFtZWJ1ZmZlcih0YXJnZXQpO1xuICAgICAgICAgICAgdGhpcy5zZXRWaWV3cG9ydCh0YXJnZXQud2lkdGgsIHRhcmdldC5oZWlnaHQpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGNsZWFyIHx8ICh0aGlzLmF1dG9DbGVhciAmJiBjbGVhciAhPT0gZmFsc2UpKSB7XG4gICAgICAgICAgICAvLyBFbnN1cmUgZGVwdGggYnVmZmVyIHdyaXRpbmcgaXMgZW5hYmxlZCBzbyBpdCBjYW4gYmUgY2xlYXJlZFxuICAgICAgICAgICAgaWYgKHRoaXMuZGVwdGggJiYgKCF0YXJnZXQgfHwgdGFyZ2V0LmRlcHRoKSkge1xuICAgICAgICAgICAgICAgIHRoaXMuZW5hYmxlKHRoaXMuZ2wuREVQVEhfVEVTVCk7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXREZXB0aE1hc2sodHJ1ZSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIFNhbWUgZm9yIHN0ZW5jaWxcbiAgICAgICAgICAgIGlmKHRoaXMuc3RlbmNpbCB8fCAoIXRhcmdldCB8fCB0YXJnZXQuc3RlbmNpbCkpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmVuYWJsZSh0aGlzLmdsLlNURU5DSUxfVEVTVCk7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXRTdGVuY2lsTWFzaygweGZmKVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB0aGlzLmdsLmNsZWFyKFxuICAgICAgICAgICAgICAgICh0aGlzLmNvbG9yID8gdGhpcy5nbC5DT0xPUl9CVUZGRVJfQklUIDogMCkgfFxuICAgICAgICAgICAgICAgICAgICAodGhpcy5kZXB0aCA/IHRoaXMuZ2wuREVQVEhfQlVGRkVSX0JJVCA6IDApIHxcbiAgICAgICAgICAgICAgICAgICAgKHRoaXMuc3RlbmNpbCA/IHRoaXMuZ2wuU1RFTkNJTF9CVUZGRVJfQklUIDogMClcbiAgICAgICAgICAgICk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyB1cGRhdGVzIGFsbCBzY2VuZSBncmFwaCBtYXRyaWNlc1xuICAgICAgICBpZiAodXBkYXRlKSBzY2VuZS51cGRhdGVNYXRyaXhXb3JsZCgpO1xuXG4gICAgICAgIC8vIFVwZGF0ZSBjYW1lcmEgc2VwYXJhdGVseSwgaW4gY2FzZSBub3QgaW4gc2NlbmUgZ3JhcGhcbiAgICAgICAgaWYgKGNhbWVyYSkgY2FtZXJhLnVwZGF0ZU1hdHJpeFdvcmxkKCk7XG5cbiAgICAgICAgLy8gR2V0IHJlbmRlciBsaXN0IC0gZW50YWlscyBjdWxsaW5nIGFuZCBzb3J0aW5nXG4gICAgICAgIGNvbnN0IHJlbmRlckxpc3QgPSB0aGlzLmdldFJlbmRlckxpc3QoeyBzY2VuZSwgY2FtZXJhLCBmcnVzdHVtQ3VsbCwgc29ydCB9KTtcblxuICAgICAgICByZW5kZXJMaXN0LmZvckVhY2goKG5vZGUpID0+IHtcbiAgICAgICAgICAgIG5vZGUuZHJhdyh7IGNhbWVyYSB9KTtcbiAgICAgICAgfSk7XG4gICAgfVxufVxuIiwiY29uc3QgRVBTSUxPTiA9IDAuMDAwMDAxO1xuXG4vKipcbiAqIENvcHkgdGhlIHZhbHVlcyBmcm9tIG9uZSB2ZWM0IHRvIGFub3RoZXJcbiAqXG4gKiBAcGFyYW0ge3ZlYzR9IG91dCB0aGUgcmVjZWl2aW5nIHZlY3RvclxuICogQHBhcmFtIHt2ZWM0fSBhIHRoZSBzb3VyY2UgdmVjdG9yXG4gKiBAcmV0dXJucyB7dmVjNH0gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjb3B5KG91dCwgYSkge1xuICAgIG91dFswXSA9IGFbMF07XG4gICAgb3V0WzFdID0gYVsxXTtcbiAgICBvdXRbMl0gPSBhWzJdO1xuICAgIG91dFszXSA9IGFbM107XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBTZXQgdGhlIGNvbXBvbmVudHMgb2YgYSB2ZWM0IHRvIHRoZSBnaXZlbiB2YWx1ZXNcbiAqXG4gKiBAcGFyYW0ge3ZlYzR9IG91dCB0aGUgcmVjZWl2aW5nIHZlY3RvclxuICogQHBhcmFtIHtOdW1iZXJ9IHggWCBjb21wb25lbnRcbiAqIEBwYXJhbSB7TnVtYmVyfSB5IFkgY29tcG9uZW50XG4gKiBAcGFyYW0ge051bWJlcn0geiBaIGNvbXBvbmVudFxuICogQHBhcmFtIHtOdW1iZXJ9IHcgVyBjb21wb25lbnRcbiAqIEByZXR1cm5zIHt2ZWM0fSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNldChvdXQsIHgsIHksIHosIHcpIHtcbiAgICBvdXRbMF0gPSB4O1xuICAgIG91dFsxXSA9IHk7XG4gICAgb3V0WzJdID0gejtcbiAgICBvdXRbM10gPSB3O1xuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogQWRkcyB0d28gdmVjNCdzXG4gKlxuICogQHBhcmFtIHt2ZWM0fSBvdXQgdGhlIHJlY2VpdmluZyB2ZWN0b3JcbiAqIEBwYXJhbSB7dmVjNH0gYSB0aGUgZmlyc3Qgb3BlcmFuZFxuICogQHBhcmFtIHt2ZWM0fSBiIHRoZSBzZWNvbmQgb3BlcmFuZFxuICogQHJldHVybnMge3ZlYzR9IG91dFxuICovXG5leHBvcnQgZnVuY3Rpb24gYWRkKG91dCwgYSwgYikge1xuICAgIG91dFswXSA9IGFbMF0gKyBiWzBdO1xuICAgIG91dFsxXSA9IGFbMV0gKyBiWzFdO1xuICAgIG91dFsyXSA9IGFbMl0gKyBiWzJdO1xuICAgIG91dFszXSA9IGFbM10gKyBiWzNdO1xuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogU2NhbGVzIGEgdmVjNCBieSBhIHNjYWxhciBudW1iZXJcbiAqXG4gKiBAcGFyYW0ge3ZlYzR9IG91dCB0aGUgcmVjZWl2aW5nIHZlY3RvclxuICogQHBhcmFtIHt2ZWM0fSBhIHRoZSB2ZWN0b3IgdG8gc2NhbGVcbiAqIEBwYXJhbSB7TnVtYmVyfSBiIGFtb3VudCB0byBzY2FsZSB0aGUgdmVjdG9yIGJ5XG4gKiBAcmV0dXJucyB7dmVjNH0gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzY2FsZShvdXQsIGEsIGIpIHtcbiAgICBvdXRbMF0gPSBhWzBdICogYjtcbiAgICBvdXRbMV0gPSBhWzFdICogYjtcbiAgICBvdXRbMl0gPSBhWzJdICogYjtcbiAgICBvdXRbM10gPSBhWzNdICogYjtcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIENhbGN1bGF0ZXMgdGhlIGxlbmd0aCBvZiBhIHZlYzRcbiAqXG4gKiBAcGFyYW0ge3ZlYzR9IGEgdmVjdG9yIHRvIGNhbGN1bGF0ZSBsZW5ndGggb2ZcbiAqIEByZXR1cm5zIHtOdW1iZXJ9IGxlbmd0aCBvZiBhXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBsZW5ndGgoYSkge1xuICAgIGxldCB4ID0gYVswXTtcbiAgICBsZXQgeSA9IGFbMV07XG4gICAgbGV0IHogPSBhWzJdO1xuICAgIGxldCB3ID0gYVszXTtcbiAgICByZXR1cm4gTWF0aC5zcXJ0KHggKiB4ICsgeSAqIHkgKyB6ICogeiArIHcgKiB3KTtcbn1cblxuLyoqXG4gKiBOb3JtYWxpemUgYSB2ZWM0XG4gKlxuICogQHBhcmFtIHt2ZWM0fSBvdXQgdGhlIHJlY2VpdmluZyB2ZWN0b3JcbiAqIEBwYXJhbSB7dmVjNH0gYSB2ZWN0b3IgdG8gbm9ybWFsaXplXG4gKiBAcmV0dXJucyB7dmVjNH0gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBub3JtYWxpemUob3V0LCBhKSB7XG4gICAgbGV0IHggPSBhWzBdO1xuICAgIGxldCB5ID0gYVsxXTtcbiAgICBsZXQgeiA9IGFbMl07XG4gICAgbGV0IHcgPSBhWzNdO1xuICAgIGxldCBsZW4gPSB4ICogeCArIHkgKiB5ICsgeiAqIHogKyB3ICogdztcbiAgICBpZiAobGVuID4gMCkge1xuICAgICAgICBsZW4gPSAxIC8gTWF0aC5zcXJ0KGxlbik7XG4gICAgfVxuICAgIG91dFswXSA9IHggKiBsZW47XG4gICAgb3V0WzFdID0geSAqIGxlbjtcbiAgICBvdXRbMl0gPSB6ICogbGVuO1xuICAgIG91dFszXSA9IHcgKiBsZW47XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBDYWxjdWxhdGVzIHRoZSBkb3QgcHJvZHVjdCBvZiB0d28gdmVjNCdzXG4gKlxuICogQHBhcmFtIHt2ZWM0fSBhIHRoZSBmaXJzdCBvcGVyYW5kXG4gKiBAcGFyYW0ge3ZlYzR9IGIgdGhlIHNlY29uZCBvcGVyYW5kXG4gKiBAcmV0dXJucyB7TnVtYmVyfSBkb3QgcHJvZHVjdCBvZiBhIGFuZCBiXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkb3QoYSwgYikge1xuICAgIHJldHVybiBhWzBdICogYlswXSArIGFbMV0gKiBiWzFdICsgYVsyXSAqIGJbMl0gKyBhWzNdICogYlszXTtcbn1cblxuLyoqXG4gKiBQZXJmb3JtcyBhIGxpbmVhciBpbnRlcnBvbGF0aW9uIGJldHdlZW4gdHdvIHZlYzQnc1xuICpcbiAqIEBwYXJhbSB7dmVjNH0gb3V0IHRoZSByZWNlaXZpbmcgdmVjdG9yXG4gKiBAcGFyYW0ge3ZlYzR9IGEgdGhlIGZpcnN0IG9wZXJhbmRcbiAqIEBwYXJhbSB7dmVjNH0gYiB0aGUgc2Vjb25kIG9wZXJhbmRcbiAqIEBwYXJhbSB7TnVtYmVyfSB0IGludGVycG9sYXRpb24gYW1vdW50IGJldHdlZW4gdGhlIHR3byBpbnB1dHNcbiAqIEByZXR1cm5zIHt2ZWM0fSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGxlcnAob3V0LCBhLCBiLCB0KSB7XG4gICAgbGV0IGF4ID0gYVswXTtcbiAgICBsZXQgYXkgPSBhWzFdO1xuICAgIGxldCBheiA9IGFbMl07XG4gICAgbGV0IGF3ID0gYVszXTtcbiAgICBvdXRbMF0gPSBheCArIHQgKiAoYlswXSAtIGF4KTtcbiAgICBvdXRbMV0gPSBheSArIHQgKiAoYlsxXSAtIGF5KTtcbiAgICBvdXRbMl0gPSBheiArIHQgKiAoYlsyXSAtIGF6KTtcbiAgICBvdXRbM10gPSBhdyArIHQgKiAoYlszXSAtIGF3KTtcbiAgICByZXR1cm4gb3V0O1xufVxuIiwiaW1wb3J0ICogYXMgdmVjNCBmcm9tICcuL1ZlYzRGdW5jLmpzJztcblxuLyoqXG4gKiBTZXQgYSBxdWF0IHRvIHRoZSBpZGVudGl0eSBxdWF0ZXJuaW9uXG4gKlxuICogQHBhcmFtIHtxdWF0fSBvdXQgdGhlIHJlY2VpdmluZyBxdWF0ZXJuaW9uXG4gKiBAcmV0dXJucyB7cXVhdH0gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpZGVudGl0eShvdXQpIHtcbiAgICBvdXRbMF0gPSAwO1xuICAgIG91dFsxXSA9IDA7XG4gICAgb3V0WzJdID0gMDtcbiAgICBvdXRbM10gPSAxO1xuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogU2V0cyBhIHF1YXQgZnJvbSB0aGUgZ2l2ZW4gYW5nbGUgYW5kIHJvdGF0aW9uIGF4aXMsXG4gKiB0aGVuIHJldHVybnMgaXQuXG4gKlxuICogQHBhcmFtIHtxdWF0fSBvdXQgdGhlIHJlY2VpdmluZyBxdWF0ZXJuaW9uXG4gKiBAcGFyYW0ge3ZlYzN9IGF4aXMgdGhlIGF4aXMgYXJvdW5kIHdoaWNoIHRvIHJvdGF0ZVxuICogQHBhcmFtIHtOdW1iZXJ9IHJhZCB0aGUgYW5nbGUgaW4gcmFkaWFuc1xuICogQHJldHVybnMge3F1YXR9IG91dFxuICoqL1xuZXhwb3J0IGZ1bmN0aW9uIHNldEF4aXNBbmdsZShvdXQsIGF4aXMsIHJhZCkge1xuICAgIHJhZCA9IHJhZCAqIDAuNTtcbiAgICBsZXQgcyA9IE1hdGguc2luKHJhZCk7XG4gICAgb3V0WzBdID0gcyAqIGF4aXNbMF07XG4gICAgb3V0WzFdID0gcyAqIGF4aXNbMV07XG4gICAgb3V0WzJdID0gcyAqIGF4aXNbMl07XG4gICAgb3V0WzNdID0gTWF0aC5jb3MocmFkKTtcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIE11bHRpcGxpZXMgdHdvIHF1YXRzXG4gKlxuICogQHBhcmFtIHtxdWF0fSBvdXQgdGhlIHJlY2VpdmluZyBxdWF0ZXJuaW9uXG4gKiBAcGFyYW0ge3F1YXR9IGEgdGhlIGZpcnN0IG9wZXJhbmRcbiAqIEBwYXJhbSB7cXVhdH0gYiB0aGUgc2Vjb25kIG9wZXJhbmRcbiAqIEByZXR1cm5zIHtxdWF0fSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG11bHRpcGx5KG91dCwgYSwgYikge1xuICAgIGxldCBheCA9IGFbMF0sXG4gICAgICAgIGF5ID0gYVsxXSxcbiAgICAgICAgYXogPSBhWzJdLFxuICAgICAgICBhdyA9IGFbM107XG4gICAgbGV0IGJ4ID0gYlswXSxcbiAgICAgICAgYnkgPSBiWzFdLFxuICAgICAgICBieiA9IGJbMl0sXG4gICAgICAgIGJ3ID0gYlszXTtcblxuICAgIG91dFswXSA9IGF4ICogYncgKyBhdyAqIGJ4ICsgYXkgKiBieiAtIGF6ICogYnk7XG4gICAgb3V0WzFdID0gYXkgKiBidyArIGF3ICogYnkgKyBheiAqIGJ4IC0gYXggKiBiejtcbiAgICBvdXRbMl0gPSBheiAqIGJ3ICsgYXcgKiBieiArIGF4ICogYnkgLSBheSAqIGJ4O1xuICAgIG91dFszXSA9IGF3ICogYncgLSBheCAqIGJ4IC0gYXkgKiBieSAtIGF6ICogYno7XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBSb3RhdGVzIGEgcXVhdGVybmlvbiBieSB0aGUgZ2l2ZW4gYW5nbGUgYWJvdXQgdGhlIFggYXhpc1xuICpcbiAqIEBwYXJhbSB7cXVhdH0gb3V0IHF1YXQgcmVjZWl2aW5nIG9wZXJhdGlvbiByZXN1bHRcbiAqIEBwYXJhbSB7cXVhdH0gYSBxdWF0IHRvIHJvdGF0ZVxuICogQHBhcmFtIHtudW1iZXJ9IHJhZCBhbmdsZSAoaW4gcmFkaWFucykgdG8gcm90YXRlXG4gKiBAcmV0dXJucyB7cXVhdH0gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByb3RhdGVYKG91dCwgYSwgcmFkKSB7XG4gICAgcmFkICo9IDAuNTtcblxuICAgIGxldCBheCA9IGFbMF0sXG4gICAgICAgIGF5ID0gYVsxXSxcbiAgICAgICAgYXogPSBhWzJdLFxuICAgICAgICBhdyA9IGFbM107XG4gICAgbGV0IGJ4ID0gTWF0aC5zaW4ocmFkKSxcbiAgICAgICAgYncgPSBNYXRoLmNvcyhyYWQpO1xuXG4gICAgb3V0WzBdID0gYXggKiBidyArIGF3ICogYng7XG4gICAgb3V0WzFdID0gYXkgKiBidyArIGF6ICogYng7XG4gICAgb3V0WzJdID0gYXogKiBidyAtIGF5ICogYng7XG4gICAgb3V0WzNdID0gYXcgKiBidyAtIGF4ICogYng7XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBSb3RhdGVzIGEgcXVhdGVybmlvbiBieSB0aGUgZ2l2ZW4gYW5nbGUgYWJvdXQgdGhlIFkgYXhpc1xuICpcbiAqIEBwYXJhbSB7cXVhdH0gb3V0IHF1YXQgcmVjZWl2aW5nIG9wZXJhdGlvbiByZXN1bHRcbiAqIEBwYXJhbSB7cXVhdH0gYSBxdWF0IHRvIHJvdGF0ZVxuICogQHBhcmFtIHtudW1iZXJ9IHJhZCBhbmdsZSAoaW4gcmFkaWFucykgdG8gcm90YXRlXG4gKiBAcmV0dXJucyB7cXVhdH0gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByb3RhdGVZKG91dCwgYSwgcmFkKSB7XG4gICAgcmFkICo9IDAuNTtcblxuICAgIGxldCBheCA9IGFbMF0sXG4gICAgICAgIGF5ID0gYVsxXSxcbiAgICAgICAgYXogPSBhWzJdLFxuICAgICAgICBhdyA9IGFbM107XG4gICAgbGV0IGJ5ID0gTWF0aC5zaW4ocmFkKSxcbiAgICAgICAgYncgPSBNYXRoLmNvcyhyYWQpO1xuXG4gICAgb3V0WzBdID0gYXggKiBidyAtIGF6ICogYnk7XG4gICAgb3V0WzFdID0gYXkgKiBidyArIGF3ICogYnk7XG4gICAgb3V0WzJdID0gYXogKiBidyArIGF4ICogYnk7XG4gICAgb3V0WzNdID0gYXcgKiBidyAtIGF5ICogYnk7XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBSb3RhdGVzIGEgcXVhdGVybmlvbiBieSB0aGUgZ2l2ZW4gYW5nbGUgYWJvdXQgdGhlIFogYXhpc1xuICpcbiAqIEBwYXJhbSB7cXVhdH0gb3V0IHF1YXQgcmVjZWl2aW5nIG9wZXJhdGlvbiByZXN1bHRcbiAqIEBwYXJhbSB7cXVhdH0gYSBxdWF0IHRvIHJvdGF0ZVxuICogQHBhcmFtIHtudW1iZXJ9IHJhZCBhbmdsZSAoaW4gcmFkaWFucykgdG8gcm90YXRlXG4gKiBAcmV0dXJucyB7cXVhdH0gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByb3RhdGVaKG91dCwgYSwgcmFkKSB7XG4gICAgcmFkICo9IDAuNTtcblxuICAgIGxldCBheCA9IGFbMF0sXG4gICAgICAgIGF5ID0gYVsxXSxcbiAgICAgICAgYXogPSBhWzJdLFxuICAgICAgICBhdyA9IGFbM107XG4gICAgbGV0IGJ6ID0gTWF0aC5zaW4ocmFkKSxcbiAgICAgICAgYncgPSBNYXRoLmNvcyhyYWQpO1xuXG4gICAgb3V0WzBdID0gYXggKiBidyArIGF5ICogYno7XG4gICAgb3V0WzFdID0gYXkgKiBidyAtIGF4ICogYno7XG4gICAgb3V0WzJdID0gYXogKiBidyArIGF3ICogYno7XG4gICAgb3V0WzNdID0gYXcgKiBidyAtIGF6ICogYno7XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBQZXJmb3JtcyBhIHNwaGVyaWNhbCBsaW5lYXIgaW50ZXJwb2xhdGlvbiBiZXR3ZWVuIHR3byBxdWF0XG4gKlxuICogQHBhcmFtIHtxdWF0fSBvdXQgdGhlIHJlY2VpdmluZyBxdWF0ZXJuaW9uXG4gKiBAcGFyYW0ge3F1YXR9IGEgdGhlIGZpcnN0IG9wZXJhbmRcbiAqIEBwYXJhbSB7cXVhdH0gYiB0aGUgc2Vjb25kIG9wZXJhbmRcbiAqIEBwYXJhbSB7TnVtYmVyfSB0IGludGVycG9sYXRpb24gYW1vdW50IGJldHdlZW4gdGhlIHR3byBpbnB1dHNcbiAqIEByZXR1cm5zIHtxdWF0fSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNsZXJwKG91dCwgYSwgYiwgdCkge1xuICAgIC8vIGJlbmNobWFya3M6XG4gICAgLy8gICAgaHR0cDovL2pzcGVyZi5jb20vcXVhdGVybmlvbi1zbGVycC1pbXBsZW1lbnRhdGlvbnNcbiAgICBsZXQgYXggPSBhWzBdLFxuICAgICAgICBheSA9IGFbMV0sXG4gICAgICAgIGF6ID0gYVsyXSxcbiAgICAgICAgYXcgPSBhWzNdO1xuICAgIGxldCBieCA9IGJbMF0sXG4gICAgICAgIGJ5ID0gYlsxXSxcbiAgICAgICAgYnogPSBiWzJdLFxuICAgICAgICBidyA9IGJbM107XG5cbiAgICBsZXQgb21lZ2EsIGNvc29tLCBzaW5vbSwgc2NhbGUwLCBzY2FsZTE7XG5cbiAgICAvLyBjYWxjIGNvc2luZVxuICAgIGNvc29tID0gYXggKiBieCArIGF5ICogYnkgKyBheiAqIGJ6ICsgYXcgKiBidztcbiAgICAvLyBhZGp1c3Qgc2lnbnMgKGlmIG5lY2Vzc2FyeSlcbiAgICBpZiAoY29zb20gPCAwLjApIHtcbiAgICAgICAgY29zb20gPSAtY29zb207XG4gICAgICAgIGJ4ID0gLWJ4O1xuICAgICAgICBieSA9IC1ieTtcbiAgICAgICAgYnogPSAtYno7XG4gICAgICAgIGJ3ID0gLWJ3O1xuICAgIH1cbiAgICAvLyBjYWxjdWxhdGUgY29lZmZpY2llbnRzXG4gICAgaWYgKDEuMCAtIGNvc29tID4gMC4wMDAwMDEpIHtcbiAgICAgICAgLy8gc3RhbmRhcmQgY2FzZSAoc2xlcnApXG4gICAgICAgIG9tZWdhID0gTWF0aC5hY29zKGNvc29tKTtcbiAgICAgICAgc2lub20gPSBNYXRoLnNpbihvbWVnYSk7XG4gICAgICAgIHNjYWxlMCA9IE1hdGguc2luKCgxLjAgLSB0KSAqIG9tZWdhKSAvIHNpbm9tO1xuICAgICAgICBzY2FsZTEgPSBNYXRoLnNpbih0ICogb21lZ2EpIC8gc2lub207XG4gICAgfSBlbHNlIHtcbiAgICAgICAgLy8gXCJmcm9tXCIgYW5kIFwidG9cIiBxdWF0ZXJuaW9ucyBhcmUgdmVyeSBjbG9zZVxuICAgICAgICAvLyAgLi4uIHNvIHdlIGNhbiBkbyBhIGxpbmVhciBpbnRlcnBvbGF0aW9uXG4gICAgICAgIHNjYWxlMCA9IDEuMCAtIHQ7XG4gICAgICAgIHNjYWxlMSA9IHQ7XG4gICAgfVxuICAgIC8vIGNhbGN1bGF0ZSBmaW5hbCB2YWx1ZXNcbiAgICBvdXRbMF0gPSBzY2FsZTAgKiBheCArIHNjYWxlMSAqIGJ4O1xuICAgIG91dFsxXSA9IHNjYWxlMCAqIGF5ICsgc2NhbGUxICogYnk7XG4gICAgb3V0WzJdID0gc2NhbGUwICogYXogKyBzY2FsZTEgKiBiejtcbiAgICBvdXRbM10gPSBzY2FsZTAgKiBhdyArIHNjYWxlMSAqIGJ3O1xuXG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBDYWxjdWxhdGVzIHRoZSBpbnZlcnNlIG9mIGEgcXVhdFxuICpcbiAqIEBwYXJhbSB7cXVhdH0gb3V0IHRoZSByZWNlaXZpbmcgcXVhdGVybmlvblxuICogQHBhcmFtIHtxdWF0fSBhIHF1YXQgdG8gY2FsY3VsYXRlIGludmVyc2Ugb2ZcbiAqIEByZXR1cm5zIHtxdWF0fSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGludmVydChvdXQsIGEpIHtcbiAgICBsZXQgYTAgPSBhWzBdLFxuICAgICAgICBhMSA9IGFbMV0sXG4gICAgICAgIGEyID0gYVsyXSxcbiAgICAgICAgYTMgPSBhWzNdO1xuICAgIGxldCBkb3QgPSBhMCAqIGEwICsgYTEgKiBhMSArIGEyICogYTIgKyBhMyAqIGEzO1xuICAgIGxldCBpbnZEb3QgPSBkb3QgPyAxLjAgLyBkb3QgOiAwO1xuXG4gICAgLy8gVE9ETzogV291bGQgYmUgZmFzdGVyIHRvIHJldHVybiBbMCwwLDAsMF0gaW1tZWRpYXRlbHkgaWYgZG90ID09IDBcblxuICAgIG91dFswXSA9IC1hMCAqIGludkRvdDtcbiAgICBvdXRbMV0gPSAtYTEgKiBpbnZEb3Q7XG4gICAgb3V0WzJdID0gLWEyICogaW52RG90O1xuICAgIG91dFszXSA9IGEzICogaW52RG90O1xuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogQ2FsY3VsYXRlcyB0aGUgY29uanVnYXRlIG9mIGEgcXVhdFxuICogSWYgdGhlIHF1YXRlcm5pb24gaXMgbm9ybWFsaXplZCwgdGhpcyBmdW5jdGlvbiBpcyBmYXN0ZXIgdGhhbiBxdWF0LmludmVyc2UgYW5kIHByb2R1Y2VzIHRoZSBzYW1lIHJlc3VsdC5cbiAqXG4gKiBAcGFyYW0ge3F1YXR9IG91dCB0aGUgcmVjZWl2aW5nIHF1YXRlcm5pb25cbiAqIEBwYXJhbSB7cXVhdH0gYSBxdWF0IHRvIGNhbGN1bGF0ZSBjb25qdWdhdGUgb2ZcbiAqIEByZXR1cm5zIHtxdWF0fSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNvbmp1Z2F0ZShvdXQsIGEpIHtcbiAgICBvdXRbMF0gPSAtYVswXTtcbiAgICBvdXRbMV0gPSAtYVsxXTtcbiAgICBvdXRbMl0gPSAtYVsyXTtcbiAgICBvdXRbM10gPSBhWzNdO1xuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogQ3JlYXRlcyBhIHF1YXRlcm5pb24gZnJvbSB0aGUgZ2l2ZW4gM3gzIHJvdGF0aW9uIG1hdHJpeC5cbiAqXG4gKiBOT1RFOiBUaGUgcmVzdWx0YW50IHF1YXRlcm5pb24gaXMgbm90IG5vcm1hbGl6ZWQsIHNvIHlvdSBzaG91bGQgYmUgc3VyZVxuICogdG8gcmVub3JtYWxpemUgdGhlIHF1YXRlcm5pb24geW91cnNlbGYgd2hlcmUgbmVjZXNzYXJ5LlxuICpcbiAqIEBwYXJhbSB7cXVhdH0gb3V0IHRoZSByZWNlaXZpbmcgcXVhdGVybmlvblxuICogQHBhcmFtIHttYXQzfSBtIHJvdGF0aW9uIG1hdHJpeFxuICogQHJldHVybnMge3F1YXR9IG91dFxuICogQGZ1bmN0aW9uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmcm9tTWF0MyhvdXQsIG0pIHtcbiAgICAvLyBBbGdvcml0aG0gaW4gS2VuIFNob2VtYWtlJ3MgYXJ0aWNsZSBpbiAxOTg3IFNJR0dSQVBIIGNvdXJzZSBub3Rlc1xuICAgIC8vIGFydGljbGUgXCJRdWF0ZXJuaW9uIENhbGN1bHVzIGFuZCBGYXN0IEFuaW1hdGlvblwiLlxuICAgIGxldCBmVHJhY2UgPSBtWzBdICsgbVs0XSArIG1bOF07XG4gICAgbGV0IGZSb290O1xuXG4gICAgaWYgKGZUcmFjZSA+IDAuMCkge1xuICAgICAgICAvLyB8d3wgPiAxLzIsIG1heSBhcyB3ZWxsIGNob29zZSB3ID4gMS8yXG4gICAgICAgIGZSb290ID0gTWF0aC5zcXJ0KGZUcmFjZSArIDEuMCk7IC8vIDJ3XG4gICAgICAgIG91dFszXSA9IDAuNSAqIGZSb290O1xuICAgICAgICBmUm9vdCA9IDAuNSAvIGZSb290OyAvLyAxLyg0dylcbiAgICAgICAgb3V0WzBdID0gKG1bNV0gLSBtWzddKSAqIGZSb290O1xuICAgICAgICBvdXRbMV0gPSAobVs2XSAtIG1bMl0pICogZlJvb3Q7XG4gICAgICAgIG91dFsyXSA9IChtWzFdIC0gbVszXSkgKiBmUm9vdDtcbiAgICB9IGVsc2Uge1xuICAgICAgICAvLyB8d3wgPD0gMS8yXG4gICAgICAgIGxldCBpID0gMDtcbiAgICAgICAgaWYgKG1bNF0gPiBtWzBdKSBpID0gMTtcbiAgICAgICAgaWYgKG1bOF0gPiBtW2kgKiAzICsgaV0pIGkgPSAyO1xuICAgICAgICBsZXQgaiA9IChpICsgMSkgJSAzO1xuICAgICAgICBsZXQgayA9IChpICsgMikgJSAzO1xuXG4gICAgICAgIGZSb290ID0gTWF0aC5zcXJ0KG1baSAqIDMgKyBpXSAtIG1baiAqIDMgKyBqXSAtIG1bayAqIDMgKyBrXSArIDEuMCk7XG4gICAgICAgIG91dFtpXSA9IDAuNSAqIGZSb290O1xuICAgICAgICBmUm9vdCA9IDAuNSAvIGZSb290O1xuICAgICAgICBvdXRbM10gPSAobVtqICogMyArIGtdIC0gbVtrICogMyArIGpdKSAqIGZSb290O1xuICAgICAgICBvdXRbal0gPSAobVtqICogMyArIGldICsgbVtpICogMyArIGpdKSAqIGZSb290O1xuICAgICAgICBvdXRba10gPSAobVtrICogMyArIGldICsgbVtpICogMyArIGtdKSAqIGZSb290O1xuICAgIH1cblxuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogQ3JlYXRlcyBhIHF1YXRlcm5pb24gZnJvbSB0aGUgZ2l2ZW4gZXVsZXIgYW5nbGUgeCwgeSwgei5cbiAqXG4gKiBAcGFyYW0ge3F1YXR9IG91dCB0aGUgcmVjZWl2aW5nIHF1YXRlcm5pb25cbiAqIEBwYXJhbSB7dmVjM30gZXVsZXIgQW5nbGVzIHRvIHJvdGF0ZSBhcm91bmQgZWFjaCBheGlzIGluIGRlZ3JlZXMuXG4gKiBAcGFyYW0ge1N0cmluZ30gb3JkZXIgZGV0YWlsaW5nIG9yZGVyIG9mIG9wZXJhdGlvbnMuIERlZmF1bHQgJ1hZWicuXG4gKiBAcmV0dXJucyB7cXVhdH0gb3V0XG4gKiBAZnVuY3Rpb25cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZyb21FdWxlcihvdXQsIGV1bGVyLCBvcmRlciA9ICdZWFonKSB7XG4gICAgbGV0IHN4ID0gTWF0aC5zaW4oZXVsZXJbMF0gKiAwLjUpO1xuICAgIGxldCBjeCA9IE1hdGguY29zKGV1bGVyWzBdICogMC41KTtcbiAgICBsZXQgc3kgPSBNYXRoLnNpbihldWxlclsxXSAqIDAuNSk7XG4gICAgbGV0IGN5ID0gTWF0aC5jb3MoZXVsZXJbMV0gKiAwLjUpO1xuICAgIGxldCBzeiA9IE1hdGguc2luKGV1bGVyWzJdICogMC41KTtcbiAgICBsZXQgY3ogPSBNYXRoLmNvcyhldWxlclsyXSAqIDAuNSk7XG5cbiAgICBpZiAob3JkZXIgPT09ICdYWVonKSB7XG4gICAgICAgIG91dFswXSA9IHN4ICogY3kgKiBjeiArIGN4ICogc3kgKiBzejtcbiAgICAgICAgb3V0WzFdID0gY3ggKiBzeSAqIGN6IC0gc3ggKiBjeSAqIHN6O1xuICAgICAgICBvdXRbMl0gPSBjeCAqIGN5ICogc3ogKyBzeCAqIHN5ICogY3o7XG4gICAgICAgIG91dFszXSA9IGN4ICogY3kgKiBjeiAtIHN4ICogc3kgKiBzejtcbiAgICB9IGVsc2UgaWYgKG9yZGVyID09PSAnWVhaJykge1xuICAgICAgICBvdXRbMF0gPSBzeCAqIGN5ICogY3ogKyBjeCAqIHN5ICogc3o7XG4gICAgICAgIG91dFsxXSA9IGN4ICogc3kgKiBjeiAtIHN4ICogY3kgKiBzejtcbiAgICAgICAgb3V0WzJdID0gY3ggKiBjeSAqIHN6IC0gc3ggKiBzeSAqIGN6O1xuICAgICAgICBvdXRbM10gPSBjeCAqIGN5ICogY3ogKyBzeCAqIHN5ICogc3o7XG4gICAgfSBlbHNlIGlmIChvcmRlciA9PT0gJ1pYWScpIHtcbiAgICAgICAgb3V0WzBdID0gc3ggKiBjeSAqIGN6IC0gY3ggKiBzeSAqIHN6O1xuICAgICAgICBvdXRbMV0gPSBjeCAqIHN5ICogY3ogKyBzeCAqIGN5ICogc3o7XG4gICAgICAgIG91dFsyXSA9IGN4ICogY3kgKiBzeiArIHN4ICogc3kgKiBjejtcbiAgICAgICAgb3V0WzNdID0gY3ggKiBjeSAqIGN6IC0gc3ggKiBzeSAqIHN6O1xuICAgIH0gZWxzZSBpZiAob3JkZXIgPT09ICdaWVgnKSB7XG4gICAgICAgIG91dFswXSA9IHN4ICogY3kgKiBjeiAtIGN4ICogc3kgKiBzejtcbiAgICAgICAgb3V0WzFdID0gY3ggKiBzeSAqIGN6ICsgc3ggKiBjeSAqIHN6O1xuICAgICAgICBvdXRbMl0gPSBjeCAqIGN5ICogc3ogLSBzeCAqIHN5ICogY3o7XG4gICAgICAgIG91dFszXSA9IGN4ICogY3kgKiBjeiArIHN4ICogc3kgKiBzejtcbiAgICB9IGVsc2UgaWYgKG9yZGVyID09PSAnWVpYJykge1xuICAgICAgICBvdXRbMF0gPSBzeCAqIGN5ICogY3ogKyBjeCAqIHN5ICogc3o7XG4gICAgICAgIG91dFsxXSA9IGN4ICogc3kgKiBjeiArIHN4ICogY3kgKiBzejtcbiAgICAgICAgb3V0WzJdID0gY3ggKiBjeSAqIHN6IC0gc3ggKiBzeSAqIGN6O1xuICAgICAgICBvdXRbM10gPSBjeCAqIGN5ICogY3ogLSBzeCAqIHN5ICogc3o7XG4gICAgfSBlbHNlIGlmIChvcmRlciA9PT0gJ1haWScpIHtcbiAgICAgICAgb3V0WzBdID0gc3ggKiBjeSAqIGN6IC0gY3ggKiBzeSAqIHN6O1xuICAgICAgICBvdXRbMV0gPSBjeCAqIHN5ICogY3ogLSBzeCAqIGN5ICogc3o7XG4gICAgICAgIG91dFsyXSA9IGN4ICogY3kgKiBzeiArIHN4ICogc3kgKiBjejtcbiAgICAgICAgb3V0WzNdID0gY3ggKiBjeSAqIGN6ICsgc3ggKiBzeSAqIHN6O1xuICAgIH1cblxuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogQ29weSB0aGUgdmFsdWVzIGZyb20gb25lIHF1YXQgdG8gYW5vdGhlclxuICpcbiAqIEBwYXJhbSB7cXVhdH0gb3V0IHRoZSByZWNlaXZpbmcgcXVhdGVybmlvblxuICogQHBhcmFtIHtxdWF0fSBhIHRoZSBzb3VyY2UgcXVhdGVybmlvblxuICogQHJldHVybnMge3F1YXR9IG91dFxuICogQGZ1bmN0aW9uXG4gKi9cbmV4cG9ydCBjb25zdCBjb3B5ID0gdmVjNC5jb3B5O1xuXG4vKipcbiAqIFNldCB0aGUgY29tcG9uZW50cyBvZiBhIHF1YXQgdG8gdGhlIGdpdmVuIHZhbHVlc1xuICpcbiAqIEBwYXJhbSB7cXVhdH0gb3V0IHRoZSByZWNlaXZpbmcgcXVhdGVybmlvblxuICogQHBhcmFtIHtOdW1iZXJ9IHggWCBjb21wb25lbnRcbiAqIEBwYXJhbSB7TnVtYmVyfSB5IFkgY29tcG9uZW50XG4gKiBAcGFyYW0ge051bWJlcn0geiBaIGNvbXBvbmVudFxuICogQHBhcmFtIHtOdW1iZXJ9IHcgVyBjb21wb25lbnRcbiAqIEByZXR1cm5zIHtxdWF0fSBvdXRcbiAqIEBmdW5jdGlvblxuICovXG5leHBvcnQgY29uc3Qgc2V0ID0gdmVjNC5zZXQ7XG5cbi8qKlxuICogQWRkcyB0d28gcXVhdCdzXG4gKlxuICogQHBhcmFtIHtxdWF0fSBvdXQgdGhlIHJlY2VpdmluZyBxdWF0ZXJuaW9uXG4gKiBAcGFyYW0ge3F1YXR9IGEgdGhlIGZpcnN0IG9wZXJhbmRcbiAqIEBwYXJhbSB7cXVhdH0gYiB0aGUgc2Vjb25kIG9wZXJhbmRcbiAqIEByZXR1cm5zIHtxdWF0fSBvdXRcbiAqIEBmdW5jdGlvblxuICovXG5leHBvcnQgY29uc3QgYWRkID0gdmVjNC5hZGQ7XG5cbi8qKlxuICogU2NhbGVzIGEgcXVhdCBieSBhIHNjYWxhciBudW1iZXJcbiAqXG4gKiBAcGFyYW0ge3F1YXR9IG91dCB0aGUgcmVjZWl2aW5nIHZlY3RvclxuICogQHBhcmFtIHtxdWF0fSBhIHRoZSB2ZWN0b3IgdG8gc2NhbGVcbiAqIEBwYXJhbSB7TnVtYmVyfSBiIGFtb3VudCB0byBzY2FsZSB0aGUgdmVjdG9yIGJ5XG4gKiBAcmV0dXJucyB7cXVhdH0gb3V0XG4gKiBAZnVuY3Rpb25cbiAqL1xuZXhwb3J0IGNvbnN0IHNjYWxlID0gdmVjNC5zY2FsZTtcblxuLyoqXG4gKiBDYWxjdWxhdGVzIHRoZSBkb3QgcHJvZHVjdCBvZiB0d28gcXVhdCdzXG4gKlxuICogQHBhcmFtIHtxdWF0fSBhIHRoZSBmaXJzdCBvcGVyYW5kXG4gKiBAcGFyYW0ge3F1YXR9IGIgdGhlIHNlY29uZCBvcGVyYW5kXG4gKiBAcmV0dXJucyB7TnVtYmVyfSBkb3QgcHJvZHVjdCBvZiBhIGFuZCBiXG4gKiBAZnVuY3Rpb25cbiAqL1xuZXhwb3J0IGNvbnN0IGRvdCA9IHZlYzQuZG90O1xuXG4vKipcbiAqIFBlcmZvcm1zIGEgbGluZWFyIGludGVycG9sYXRpb24gYmV0d2VlbiB0d28gcXVhdCdzXG4gKlxuICogQHBhcmFtIHtxdWF0fSBvdXQgdGhlIHJlY2VpdmluZyBxdWF0ZXJuaW9uXG4gKiBAcGFyYW0ge3F1YXR9IGEgdGhlIGZpcnN0IG9wZXJhbmRcbiAqIEBwYXJhbSB7cXVhdH0gYiB0aGUgc2Vjb25kIG9wZXJhbmRcbiAqIEBwYXJhbSB7TnVtYmVyfSB0IGludGVycG9sYXRpb24gYW1vdW50IGJldHdlZW4gdGhlIHR3byBpbnB1dHNcbiAqIEByZXR1cm5zIHtxdWF0fSBvdXRcbiAqIEBmdW5jdGlvblxuICovXG5leHBvcnQgY29uc3QgbGVycCA9IHZlYzQubGVycDtcblxuLyoqXG4gKiBDYWxjdWxhdGVzIHRoZSBsZW5ndGggb2YgYSBxdWF0XG4gKlxuICogQHBhcmFtIHtxdWF0fSBhIHZlY3RvciB0byBjYWxjdWxhdGUgbGVuZ3RoIG9mXG4gKiBAcmV0dXJucyB7TnVtYmVyfSBsZW5ndGggb2YgYVxuICovXG5leHBvcnQgY29uc3QgbGVuZ3RoID0gdmVjNC5sZW5ndGg7XG5cbi8qKlxuICogTm9ybWFsaXplIGEgcXVhdFxuICpcbiAqIEBwYXJhbSB7cXVhdH0gb3V0IHRoZSByZWNlaXZpbmcgcXVhdGVybmlvblxuICogQHBhcmFtIHtxdWF0fSBhIHF1YXRlcm5pb24gdG8gbm9ybWFsaXplXG4gKiBAcmV0dXJucyB7cXVhdH0gb3V0XG4gKiBAZnVuY3Rpb25cbiAqL1xuZXhwb3J0IGNvbnN0IG5vcm1hbGl6ZSA9IHZlYzQubm9ybWFsaXplO1xuIiwiaW1wb3J0ICogYXMgUXVhdEZ1bmMgZnJvbSAnLi9mdW5jdGlvbnMvUXVhdEZ1bmMuanMnO1xuXG5leHBvcnQgY2xhc3MgUXVhdCBleHRlbmRzIEFycmF5IHtcbiAgICBjb25zdHJ1Y3Rvcih4ID0gMCwgeSA9IDAsIHogPSAwLCB3ID0gMSkge1xuICAgICAgICBzdXBlcih4LCB5LCB6LCB3KTtcbiAgICAgICAgdGhpcy5vbkNoYW5nZSA9ICgpID0+IHt9O1xuXG4gICAgICAgIC8vIEtlZXAgcmVmZXJlbmNlIHRvIHByb3h5IHRhcmdldCB0byBhdm9pZCB0cmlnZ2VyaW5nIG9uQ2hhbmdlIGludGVybmFsbHlcbiAgICAgICAgdGhpcy5fdGFyZ2V0ID0gdGhpcztcblxuICAgICAgICAvLyBSZXR1cm4gYSBwcm94eSB0byB0cmlnZ2VyIG9uQ2hhbmdlIHdoZW4gYXJyYXkgZWxlbWVudHMgYXJlIGVkaXRlZCBkaXJlY3RseVxuICAgICAgICBjb25zdCB0cmlnZ2VyUHJvcHMgPSBbJzAnLCAnMScsICcyJywgJzMnXTtcbiAgICAgICAgcmV0dXJuIG5ldyBQcm94eSh0aGlzLCB7XG4gICAgICAgICAgICBzZXQodGFyZ2V0LCBwcm9wZXJ0eSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHN1Y2Nlc3MgPSBSZWZsZWN0LnNldCguLi5hcmd1bWVudHMpO1xuICAgICAgICAgICAgICAgIGlmIChzdWNjZXNzICYmIHRyaWdnZXJQcm9wcy5pbmNsdWRlcyhwcm9wZXJ0eSkpIHRhcmdldC5vbkNoYW5nZSgpO1xuICAgICAgICAgICAgICAgIHJldHVybiBzdWNjZXNzO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgZ2V0IHgoKSB7XG4gICAgICAgIHJldHVybiB0aGlzWzBdO1xuICAgIH1cblxuICAgIGdldCB5KCkge1xuICAgICAgICByZXR1cm4gdGhpc1sxXTtcbiAgICB9XG5cbiAgICBnZXQgeigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXNbMl07XG4gICAgfVxuXG4gICAgZ2V0IHcoKSB7XG4gICAgICAgIHJldHVybiB0aGlzWzNdO1xuICAgIH1cblxuICAgIHNldCB4KHYpIHtcbiAgICAgICAgdGhpcy5fdGFyZ2V0WzBdID0gdjtcbiAgICAgICAgdGhpcy5vbkNoYW5nZSgpO1xuICAgIH1cblxuICAgIHNldCB5KHYpIHtcbiAgICAgICAgdGhpcy5fdGFyZ2V0WzFdID0gdjtcbiAgICAgICAgdGhpcy5vbkNoYW5nZSgpO1xuICAgIH1cblxuICAgIHNldCB6KHYpIHtcbiAgICAgICAgdGhpcy5fdGFyZ2V0WzJdID0gdjtcbiAgICAgICAgdGhpcy5vbkNoYW5nZSgpO1xuICAgIH1cblxuICAgIHNldCB3KHYpIHtcbiAgICAgICAgdGhpcy5fdGFyZ2V0WzNdID0gdjtcbiAgICAgICAgdGhpcy5vbkNoYW5nZSgpO1xuICAgIH1cblxuICAgIGlkZW50aXR5KCkge1xuICAgICAgICBRdWF0RnVuYy5pZGVudGl0eSh0aGlzLl90YXJnZXQpO1xuICAgICAgICB0aGlzLm9uQ2hhbmdlKCk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIHNldCh4LCB5LCB6LCB3KSB7XG4gICAgICAgIGlmICh4Lmxlbmd0aCkgcmV0dXJuIHRoaXMuY29weSh4KTtcbiAgICAgICAgUXVhdEZ1bmMuc2V0KHRoaXMuX3RhcmdldCwgeCwgeSwgeiwgdyk7XG4gICAgICAgIHRoaXMub25DaGFuZ2UoKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgcm90YXRlWChhKSB7XG4gICAgICAgIFF1YXRGdW5jLnJvdGF0ZVgodGhpcy5fdGFyZ2V0LCB0aGlzLl90YXJnZXQsIGEpO1xuICAgICAgICB0aGlzLm9uQ2hhbmdlKCk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIHJvdGF0ZVkoYSkge1xuICAgICAgICBRdWF0RnVuYy5yb3RhdGVZKHRoaXMuX3RhcmdldCwgdGhpcy5fdGFyZ2V0LCBhKTtcbiAgICAgICAgdGhpcy5vbkNoYW5nZSgpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICByb3RhdGVaKGEpIHtcbiAgICAgICAgUXVhdEZ1bmMucm90YXRlWih0aGlzLl90YXJnZXQsIHRoaXMuX3RhcmdldCwgYSk7XG4gICAgICAgIHRoaXMub25DaGFuZ2UoKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgaW52ZXJzZShxID0gdGhpcy5fdGFyZ2V0KSB7XG4gICAgICAgIFF1YXRGdW5jLmludmVydCh0aGlzLl90YXJnZXQsIHEpO1xuICAgICAgICB0aGlzLm9uQ2hhbmdlKCk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGNvbmp1Z2F0ZShxID0gdGhpcy5fdGFyZ2V0KSB7XG4gICAgICAgIFF1YXRGdW5jLmNvbmp1Z2F0ZSh0aGlzLl90YXJnZXQsIHEpO1xuICAgICAgICB0aGlzLm9uQ2hhbmdlKCk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGNvcHkocSkge1xuICAgICAgICBRdWF0RnVuYy5jb3B5KHRoaXMuX3RhcmdldCwgcSk7XG4gICAgICAgIHRoaXMub25DaGFuZ2UoKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgbm9ybWFsaXplKHEgPSB0aGlzLl90YXJnZXQpIHtcbiAgICAgICAgUXVhdEZ1bmMubm9ybWFsaXplKHRoaXMuX3RhcmdldCwgcSk7XG4gICAgICAgIHRoaXMub25DaGFuZ2UoKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgbXVsdGlwbHkocUEsIHFCKSB7XG4gICAgICAgIGlmIChxQikge1xuICAgICAgICAgICAgUXVhdEZ1bmMubXVsdGlwbHkodGhpcy5fdGFyZ2V0LCBxQSwgcUIpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgUXVhdEZ1bmMubXVsdGlwbHkodGhpcy5fdGFyZ2V0LCB0aGlzLl90YXJnZXQsIHFBKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLm9uQ2hhbmdlKCk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGRvdCh2KSB7XG4gICAgICAgIHJldHVybiBRdWF0RnVuYy5kb3QodGhpcy5fdGFyZ2V0LCB2KTtcbiAgICB9XG5cbiAgICBmcm9tTWF0cml4MyhtYXRyaXgzKSB7XG4gICAgICAgIFF1YXRGdW5jLmZyb21NYXQzKHRoaXMuX3RhcmdldCwgbWF0cml4Myk7XG4gICAgICAgIHRoaXMub25DaGFuZ2UoKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgZnJvbUV1bGVyKGV1bGVyLCBpc0ludGVybmFsKSB7XG4gICAgICAgIFF1YXRGdW5jLmZyb21FdWxlcih0aGlzLl90YXJnZXQsIGV1bGVyLCBldWxlci5vcmRlcik7XG4gICAgICAgIC8vIEF2b2lkIGluZmluaXRlIHJlY3Vyc2lvblxuICAgICAgICBpZiAoIWlzSW50ZXJuYWwpIHRoaXMub25DaGFuZ2UoKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgZnJvbUF4aXNBbmdsZShheGlzLCBhKSB7XG4gICAgICAgIFF1YXRGdW5jLnNldEF4aXNBbmdsZSh0aGlzLl90YXJnZXQsIGF4aXMsIGEpO1xuICAgICAgICB0aGlzLm9uQ2hhbmdlKCk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIHNsZXJwKHEsIHQpIHtcbiAgICAgICAgUXVhdEZ1bmMuc2xlcnAodGhpcy5fdGFyZ2V0LCB0aGlzLl90YXJnZXQsIHEsIHQpO1xuICAgICAgICB0aGlzLm9uQ2hhbmdlKCk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGZyb21BcnJheShhLCBvID0gMCkge1xuICAgICAgICB0aGlzLl90YXJnZXRbMF0gPSBhW29dO1xuICAgICAgICB0aGlzLl90YXJnZXRbMV0gPSBhW28gKyAxXTtcbiAgICAgICAgdGhpcy5fdGFyZ2V0WzJdID0gYVtvICsgMl07XG4gICAgICAgIHRoaXMuX3RhcmdldFszXSA9IGFbbyArIDNdO1xuICAgICAgICB0aGlzLm9uQ2hhbmdlKCk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIHRvQXJyYXkoYSA9IFtdLCBvID0gMCkge1xuICAgICAgICBhW29dID0gdGhpc1swXTtcbiAgICAgICAgYVtvICsgMV0gPSB0aGlzWzFdO1xuICAgICAgICBhW28gKyAyXSA9IHRoaXNbMl07XG4gICAgICAgIGFbbyArIDNdID0gdGhpc1szXTtcbiAgICAgICAgcmV0dXJuIGE7XG4gICAgfVxufVxuIiwiaW1wb3J0ICogYXMgdmVjMyBmcm9tICcuL1ZlYzNGdW5jLmpzJztcblxuY29uc3QgRVBTSUxPTiA9IDAuMDAwMDAxO1xuXG4vKipcbiAqIENvcHkgdGhlIHZhbHVlcyBmcm9tIG9uZSBtYXQ0IHRvIGFub3RoZXJcbiAqXG4gKiBAcGFyYW0ge21hdDR9IG91dCB0aGUgcmVjZWl2aW5nIG1hdHJpeFxuICogQHBhcmFtIHttYXQ0fSBhIHRoZSBzb3VyY2UgbWF0cml4XG4gKiBAcmV0dXJucyB7bWF0NH0gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjb3B5KG91dCwgYSkge1xuICAgIG91dFswXSA9IGFbMF07XG4gICAgb3V0WzFdID0gYVsxXTtcbiAgICBvdXRbMl0gPSBhWzJdO1xuICAgIG91dFszXSA9IGFbM107XG4gICAgb3V0WzRdID0gYVs0XTtcbiAgICBvdXRbNV0gPSBhWzVdO1xuICAgIG91dFs2XSA9IGFbNl07XG4gICAgb3V0WzddID0gYVs3XTtcbiAgICBvdXRbOF0gPSBhWzhdO1xuICAgIG91dFs5XSA9IGFbOV07XG4gICAgb3V0WzEwXSA9IGFbMTBdO1xuICAgIG91dFsxMV0gPSBhWzExXTtcbiAgICBvdXRbMTJdID0gYVsxMl07XG4gICAgb3V0WzEzXSA9IGFbMTNdO1xuICAgIG91dFsxNF0gPSBhWzE0XTtcbiAgICBvdXRbMTVdID0gYVsxNV07XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBTZXQgdGhlIGNvbXBvbmVudHMgb2YgYSBtYXQ0IHRvIHRoZSBnaXZlbiB2YWx1ZXNcbiAqXG4gKiBAcGFyYW0ge21hdDR9IG91dCB0aGUgcmVjZWl2aW5nIG1hdHJpeFxuICogQHJldHVybnMge21hdDR9IG91dFxuICovXG5leHBvcnQgZnVuY3Rpb24gc2V0KG91dCwgbTAwLCBtMDEsIG0wMiwgbTAzLCBtMTAsIG0xMSwgbTEyLCBtMTMsIG0yMCwgbTIxLCBtMjIsIG0yMywgbTMwLCBtMzEsIG0zMiwgbTMzKSB7XG4gICAgb3V0WzBdID0gbTAwO1xuICAgIG91dFsxXSA9IG0wMTtcbiAgICBvdXRbMl0gPSBtMDI7XG4gICAgb3V0WzNdID0gbTAzO1xuICAgIG91dFs0XSA9IG0xMDtcbiAgICBvdXRbNV0gPSBtMTE7XG4gICAgb3V0WzZdID0gbTEyO1xuICAgIG91dFs3XSA9IG0xMztcbiAgICBvdXRbOF0gPSBtMjA7XG4gICAgb3V0WzldID0gbTIxO1xuICAgIG91dFsxMF0gPSBtMjI7XG4gICAgb3V0WzExXSA9IG0yMztcbiAgICBvdXRbMTJdID0gbTMwO1xuICAgIG91dFsxM10gPSBtMzE7XG4gICAgb3V0WzE0XSA9IG0zMjtcbiAgICBvdXRbMTVdID0gbTMzO1xuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogU2V0IGEgbWF0NCB0byB0aGUgaWRlbnRpdHkgbWF0cml4XG4gKlxuICogQHBhcmFtIHttYXQ0fSBvdXQgdGhlIHJlY2VpdmluZyBtYXRyaXhcbiAqIEByZXR1cm5zIHttYXQ0fSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlkZW50aXR5KG91dCkge1xuICAgIG91dFswXSA9IDE7XG4gICAgb3V0WzFdID0gMDtcbiAgICBvdXRbMl0gPSAwO1xuICAgIG91dFszXSA9IDA7XG4gICAgb3V0WzRdID0gMDtcbiAgICBvdXRbNV0gPSAxO1xuICAgIG91dFs2XSA9IDA7XG4gICAgb3V0WzddID0gMDtcbiAgICBvdXRbOF0gPSAwO1xuICAgIG91dFs5XSA9IDA7XG4gICAgb3V0WzEwXSA9IDE7XG4gICAgb3V0WzExXSA9IDA7XG4gICAgb3V0WzEyXSA9IDA7XG4gICAgb3V0WzEzXSA9IDA7XG4gICAgb3V0WzE0XSA9IDA7XG4gICAgb3V0WzE1XSA9IDE7XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBUcmFuc3Bvc2UgdGhlIHZhbHVlcyBvZiBhIG1hdDRcbiAqXG4gKiBAcGFyYW0ge21hdDR9IG91dCB0aGUgcmVjZWl2aW5nIG1hdHJpeFxuICogQHBhcmFtIHttYXQ0fSBhIHRoZSBzb3VyY2UgbWF0cml4XG4gKiBAcmV0dXJucyB7bWF0NH0gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0cmFuc3Bvc2Uob3V0LCBhKSB7XG4gICAgLy8gSWYgd2UgYXJlIHRyYW5zcG9zaW5nIG91cnNlbHZlcyB3ZSBjYW4gc2tpcCBhIGZldyBzdGVwcyBidXQgaGF2ZSB0byBjYWNoZSBzb21lIHZhbHVlc1xuICAgIGlmIChvdXQgPT09IGEpIHtcbiAgICAgICAgbGV0IGEwMSA9IGFbMV0sXG4gICAgICAgICAgICBhMDIgPSBhWzJdLFxuICAgICAgICAgICAgYTAzID0gYVszXTtcbiAgICAgICAgbGV0IGExMiA9IGFbNl0sXG4gICAgICAgICAgICBhMTMgPSBhWzddO1xuICAgICAgICBsZXQgYTIzID0gYVsxMV07XG5cbiAgICAgICAgb3V0WzFdID0gYVs0XTtcbiAgICAgICAgb3V0WzJdID0gYVs4XTtcbiAgICAgICAgb3V0WzNdID0gYVsxMl07XG4gICAgICAgIG91dFs0XSA9IGEwMTtcbiAgICAgICAgb3V0WzZdID0gYVs5XTtcbiAgICAgICAgb3V0WzddID0gYVsxM107XG4gICAgICAgIG91dFs4XSA9IGEwMjtcbiAgICAgICAgb3V0WzldID0gYTEyO1xuICAgICAgICBvdXRbMTFdID0gYVsxNF07XG4gICAgICAgIG91dFsxMl0gPSBhMDM7XG4gICAgICAgIG91dFsxM10gPSBhMTM7XG4gICAgICAgIG91dFsxNF0gPSBhMjM7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgb3V0WzBdID0gYVswXTtcbiAgICAgICAgb3V0WzFdID0gYVs0XTtcbiAgICAgICAgb3V0WzJdID0gYVs4XTtcbiAgICAgICAgb3V0WzNdID0gYVsxMl07XG4gICAgICAgIG91dFs0XSA9IGFbMV07XG4gICAgICAgIG91dFs1XSA9IGFbNV07XG4gICAgICAgIG91dFs2XSA9IGFbOV07XG4gICAgICAgIG91dFs3XSA9IGFbMTNdO1xuICAgICAgICBvdXRbOF0gPSBhWzJdO1xuICAgICAgICBvdXRbOV0gPSBhWzZdO1xuICAgICAgICBvdXRbMTBdID0gYVsxMF07XG4gICAgICAgIG91dFsxMV0gPSBhWzE0XTtcbiAgICAgICAgb3V0WzEyXSA9IGFbM107XG4gICAgICAgIG91dFsxM10gPSBhWzddO1xuICAgICAgICBvdXRbMTRdID0gYVsxMV07XG4gICAgICAgIG91dFsxNV0gPSBhWzE1XTtcbiAgICB9XG5cbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIEludmVydHMgYSBtYXQ0XG4gKlxuICogQHBhcmFtIHttYXQ0fSBvdXQgdGhlIHJlY2VpdmluZyBtYXRyaXhcbiAqIEBwYXJhbSB7bWF0NH0gYSB0aGUgc291cmNlIG1hdHJpeFxuICogQHJldHVybnMge21hdDR9IG91dFxuICovXG5leHBvcnQgZnVuY3Rpb24gaW52ZXJ0KG91dCwgYSkge1xuICAgIGxldCBhMDAgPSBhWzBdLFxuICAgICAgICBhMDEgPSBhWzFdLFxuICAgICAgICBhMDIgPSBhWzJdLFxuICAgICAgICBhMDMgPSBhWzNdO1xuICAgIGxldCBhMTAgPSBhWzRdLFxuICAgICAgICBhMTEgPSBhWzVdLFxuICAgICAgICBhMTIgPSBhWzZdLFxuICAgICAgICBhMTMgPSBhWzddO1xuICAgIGxldCBhMjAgPSBhWzhdLFxuICAgICAgICBhMjEgPSBhWzldLFxuICAgICAgICBhMjIgPSBhWzEwXSxcbiAgICAgICAgYTIzID0gYVsxMV07XG4gICAgbGV0IGEzMCA9IGFbMTJdLFxuICAgICAgICBhMzEgPSBhWzEzXSxcbiAgICAgICAgYTMyID0gYVsxNF0sXG4gICAgICAgIGEzMyA9IGFbMTVdO1xuXG4gICAgbGV0IGIwMCA9IGEwMCAqIGExMSAtIGEwMSAqIGExMDtcbiAgICBsZXQgYjAxID0gYTAwICogYTEyIC0gYTAyICogYTEwO1xuICAgIGxldCBiMDIgPSBhMDAgKiBhMTMgLSBhMDMgKiBhMTA7XG4gICAgbGV0IGIwMyA9IGEwMSAqIGExMiAtIGEwMiAqIGExMTtcbiAgICBsZXQgYjA0ID0gYTAxICogYTEzIC0gYTAzICogYTExO1xuICAgIGxldCBiMDUgPSBhMDIgKiBhMTMgLSBhMDMgKiBhMTI7XG4gICAgbGV0IGIwNiA9IGEyMCAqIGEzMSAtIGEyMSAqIGEzMDtcbiAgICBsZXQgYjA3ID0gYTIwICogYTMyIC0gYTIyICogYTMwO1xuICAgIGxldCBiMDggPSBhMjAgKiBhMzMgLSBhMjMgKiBhMzA7XG4gICAgbGV0IGIwOSA9IGEyMSAqIGEzMiAtIGEyMiAqIGEzMTtcbiAgICBsZXQgYjEwID0gYTIxICogYTMzIC0gYTIzICogYTMxO1xuICAgIGxldCBiMTEgPSBhMjIgKiBhMzMgLSBhMjMgKiBhMzI7XG5cbiAgICAvLyBDYWxjdWxhdGUgdGhlIGRldGVybWluYW50XG4gICAgbGV0IGRldCA9IGIwMCAqIGIxMSAtIGIwMSAqIGIxMCArIGIwMiAqIGIwOSArIGIwMyAqIGIwOCAtIGIwNCAqIGIwNyArIGIwNSAqIGIwNjtcblxuICAgIGlmICghZGV0KSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBkZXQgPSAxLjAgLyBkZXQ7XG5cbiAgICBvdXRbMF0gPSAoYTExICogYjExIC0gYTEyICogYjEwICsgYTEzICogYjA5KSAqIGRldDtcbiAgICBvdXRbMV0gPSAoYTAyICogYjEwIC0gYTAxICogYjExIC0gYTAzICogYjA5KSAqIGRldDtcbiAgICBvdXRbMl0gPSAoYTMxICogYjA1IC0gYTMyICogYjA0ICsgYTMzICogYjAzKSAqIGRldDtcbiAgICBvdXRbM10gPSAoYTIyICogYjA0IC0gYTIxICogYjA1IC0gYTIzICogYjAzKSAqIGRldDtcbiAgICBvdXRbNF0gPSAoYTEyICogYjA4IC0gYTEwICogYjExIC0gYTEzICogYjA3KSAqIGRldDtcbiAgICBvdXRbNV0gPSAoYTAwICogYjExIC0gYTAyICogYjA4ICsgYTAzICogYjA3KSAqIGRldDtcbiAgICBvdXRbNl0gPSAoYTMyICogYjAyIC0gYTMwICogYjA1IC0gYTMzICogYjAxKSAqIGRldDtcbiAgICBvdXRbN10gPSAoYTIwICogYjA1IC0gYTIyICogYjAyICsgYTIzICogYjAxKSAqIGRldDtcbiAgICBvdXRbOF0gPSAoYTEwICogYjEwIC0gYTExICogYjA4ICsgYTEzICogYjA2KSAqIGRldDtcbiAgICBvdXRbOV0gPSAoYTAxICogYjA4IC0gYTAwICogYjEwIC0gYTAzICogYjA2KSAqIGRldDtcbiAgICBvdXRbMTBdID0gKGEzMCAqIGIwNCAtIGEzMSAqIGIwMiArIGEzMyAqIGIwMCkgKiBkZXQ7XG4gICAgb3V0WzExXSA9IChhMjEgKiBiMDIgLSBhMjAgKiBiMDQgLSBhMjMgKiBiMDApICogZGV0O1xuICAgIG91dFsxMl0gPSAoYTExICogYjA3IC0gYTEwICogYjA5IC0gYTEyICogYjA2KSAqIGRldDtcbiAgICBvdXRbMTNdID0gKGEwMCAqIGIwOSAtIGEwMSAqIGIwNyArIGEwMiAqIGIwNikgKiBkZXQ7XG4gICAgb3V0WzE0XSA9IChhMzEgKiBiMDEgLSBhMzAgKiBiMDMgLSBhMzIgKiBiMDApICogZGV0O1xuICAgIG91dFsxNV0gPSAoYTIwICogYjAzIC0gYTIxICogYjAxICsgYTIyICogYjAwKSAqIGRldDtcblxuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogQ2FsY3VsYXRlcyB0aGUgZGV0ZXJtaW5hbnQgb2YgYSBtYXQ0XG4gKlxuICogQHBhcmFtIHttYXQ0fSBhIHRoZSBzb3VyY2UgbWF0cml4XG4gKiBAcmV0dXJucyB7TnVtYmVyfSBkZXRlcm1pbmFudCBvZiBhXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkZXRlcm1pbmFudChhKSB7XG4gICAgbGV0IGEwMCA9IGFbMF0sXG4gICAgICAgIGEwMSA9IGFbMV0sXG4gICAgICAgIGEwMiA9IGFbMl0sXG4gICAgICAgIGEwMyA9IGFbM107XG4gICAgbGV0IGExMCA9IGFbNF0sXG4gICAgICAgIGExMSA9IGFbNV0sXG4gICAgICAgIGExMiA9IGFbNl0sXG4gICAgICAgIGExMyA9IGFbN107XG4gICAgbGV0IGEyMCA9IGFbOF0sXG4gICAgICAgIGEyMSA9IGFbOV0sXG4gICAgICAgIGEyMiA9IGFbMTBdLFxuICAgICAgICBhMjMgPSBhWzExXTtcbiAgICBsZXQgYTMwID0gYVsxMl0sXG4gICAgICAgIGEzMSA9IGFbMTNdLFxuICAgICAgICBhMzIgPSBhWzE0XSxcbiAgICAgICAgYTMzID0gYVsxNV07XG5cbiAgICBsZXQgYjAwID0gYTAwICogYTExIC0gYTAxICogYTEwO1xuICAgIGxldCBiMDEgPSBhMDAgKiBhMTIgLSBhMDIgKiBhMTA7XG4gICAgbGV0IGIwMiA9IGEwMCAqIGExMyAtIGEwMyAqIGExMDtcbiAgICBsZXQgYjAzID0gYTAxICogYTEyIC0gYTAyICogYTExO1xuICAgIGxldCBiMDQgPSBhMDEgKiBhMTMgLSBhMDMgKiBhMTE7XG4gICAgbGV0IGIwNSA9IGEwMiAqIGExMyAtIGEwMyAqIGExMjtcbiAgICBsZXQgYjA2ID0gYTIwICogYTMxIC0gYTIxICogYTMwO1xuICAgIGxldCBiMDcgPSBhMjAgKiBhMzIgLSBhMjIgKiBhMzA7XG4gICAgbGV0IGIwOCA9IGEyMCAqIGEzMyAtIGEyMyAqIGEzMDtcbiAgICBsZXQgYjA5ID0gYTIxICogYTMyIC0gYTIyICogYTMxO1xuICAgIGxldCBiMTAgPSBhMjEgKiBhMzMgLSBhMjMgKiBhMzE7XG4gICAgbGV0IGIxMSA9IGEyMiAqIGEzMyAtIGEyMyAqIGEzMjtcblxuICAgIC8vIENhbGN1bGF0ZSB0aGUgZGV0ZXJtaW5hbnRcbiAgICByZXR1cm4gYjAwICogYjExIC0gYjAxICogYjEwICsgYjAyICogYjA5ICsgYjAzICogYjA4IC0gYjA0ICogYjA3ICsgYjA1ICogYjA2O1xufVxuXG4vKipcbiAqIE11bHRpcGxpZXMgdHdvIG1hdDRzXG4gKlxuICogQHBhcmFtIHttYXQ0fSBvdXQgdGhlIHJlY2VpdmluZyBtYXRyaXhcbiAqIEBwYXJhbSB7bWF0NH0gYSB0aGUgZmlyc3Qgb3BlcmFuZFxuICogQHBhcmFtIHttYXQ0fSBiIHRoZSBzZWNvbmQgb3BlcmFuZFxuICogQHJldHVybnMge21hdDR9IG91dFxuICovXG5leHBvcnQgZnVuY3Rpb24gbXVsdGlwbHkob3V0LCBhLCBiKSB7XG4gICAgbGV0IGEwMCA9IGFbMF0sXG4gICAgICAgIGEwMSA9IGFbMV0sXG4gICAgICAgIGEwMiA9IGFbMl0sXG4gICAgICAgIGEwMyA9IGFbM107XG4gICAgbGV0IGExMCA9IGFbNF0sXG4gICAgICAgIGExMSA9IGFbNV0sXG4gICAgICAgIGExMiA9IGFbNl0sXG4gICAgICAgIGExMyA9IGFbN107XG4gICAgbGV0IGEyMCA9IGFbOF0sXG4gICAgICAgIGEyMSA9IGFbOV0sXG4gICAgICAgIGEyMiA9IGFbMTBdLFxuICAgICAgICBhMjMgPSBhWzExXTtcbiAgICBsZXQgYTMwID0gYVsxMl0sXG4gICAgICAgIGEzMSA9IGFbMTNdLFxuICAgICAgICBhMzIgPSBhWzE0XSxcbiAgICAgICAgYTMzID0gYVsxNV07XG5cbiAgICAvLyBDYWNoZSBvbmx5IHRoZSBjdXJyZW50IGxpbmUgb2YgdGhlIHNlY29uZCBtYXRyaXhcbiAgICBsZXQgYjAgPSBiWzBdLFxuICAgICAgICBiMSA9IGJbMV0sXG4gICAgICAgIGIyID0gYlsyXSxcbiAgICAgICAgYjMgPSBiWzNdO1xuICAgIG91dFswXSA9IGIwICogYTAwICsgYjEgKiBhMTAgKyBiMiAqIGEyMCArIGIzICogYTMwO1xuICAgIG91dFsxXSA9IGIwICogYTAxICsgYjEgKiBhMTEgKyBiMiAqIGEyMSArIGIzICogYTMxO1xuICAgIG91dFsyXSA9IGIwICogYTAyICsgYjEgKiBhMTIgKyBiMiAqIGEyMiArIGIzICogYTMyO1xuICAgIG91dFszXSA9IGIwICogYTAzICsgYjEgKiBhMTMgKyBiMiAqIGEyMyArIGIzICogYTMzO1xuXG4gICAgYjAgPSBiWzRdO1xuICAgIGIxID0gYls1XTtcbiAgICBiMiA9IGJbNl07XG4gICAgYjMgPSBiWzddO1xuICAgIG91dFs0XSA9IGIwICogYTAwICsgYjEgKiBhMTAgKyBiMiAqIGEyMCArIGIzICogYTMwO1xuICAgIG91dFs1XSA9IGIwICogYTAxICsgYjEgKiBhMTEgKyBiMiAqIGEyMSArIGIzICogYTMxO1xuICAgIG91dFs2XSA9IGIwICogYTAyICsgYjEgKiBhMTIgKyBiMiAqIGEyMiArIGIzICogYTMyO1xuICAgIG91dFs3XSA9IGIwICogYTAzICsgYjEgKiBhMTMgKyBiMiAqIGEyMyArIGIzICogYTMzO1xuXG4gICAgYjAgPSBiWzhdO1xuICAgIGIxID0gYls5XTtcbiAgICBiMiA9IGJbMTBdO1xuICAgIGIzID0gYlsxMV07XG4gICAgb3V0WzhdID0gYjAgKiBhMDAgKyBiMSAqIGExMCArIGIyICogYTIwICsgYjMgKiBhMzA7XG4gICAgb3V0WzldID0gYjAgKiBhMDEgKyBiMSAqIGExMSArIGIyICogYTIxICsgYjMgKiBhMzE7XG4gICAgb3V0WzEwXSA9IGIwICogYTAyICsgYjEgKiBhMTIgKyBiMiAqIGEyMiArIGIzICogYTMyO1xuICAgIG91dFsxMV0gPSBiMCAqIGEwMyArIGIxICogYTEzICsgYjIgKiBhMjMgKyBiMyAqIGEzMztcblxuICAgIGIwID0gYlsxMl07XG4gICAgYjEgPSBiWzEzXTtcbiAgICBiMiA9IGJbMTRdO1xuICAgIGIzID0gYlsxNV07XG4gICAgb3V0WzEyXSA9IGIwICogYTAwICsgYjEgKiBhMTAgKyBiMiAqIGEyMCArIGIzICogYTMwO1xuICAgIG91dFsxM10gPSBiMCAqIGEwMSArIGIxICogYTExICsgYjIgKiBhMjEgKyBiMyAqIGEzMTtcbiAgICBvdXRbMTRdID0gYjAgKiBhMDIgKyBiMSAqIGExMiArIGIyICogYTIyICsgYjMgKiBhMzI7XG4gICAgb3V0WzE1XSA9IGIwICogYTAzICsgYjEgKiBhMTMgKyBiMiAqIGEyMyArIGIzICogYTMzO1xuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogVHJhbnNsYXRlIGEgbWF0NCBieSB0aGUgZ2l2ZW4gdmVjdG9yXG4gKlxuICogQHBhcmFtIHttYXQ0fSBvdXQgdGhlIHJlY2VpdmluZyBtYXRyaXhcbiAqIEBwYXJhbSB7bWF0NH0gYSB0aGUgbWF0cml4IHRvIHRyYW5zbGF0ZVxuICogQHBhcmFtIHt2ZWMzfSB2IHZlY3RvciB0byB0cmFuc2xhdGUgYnlcbiAqIEByZXR1cm5zIHttYXQ0fSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRyYW5zbGF0ZShvdXQsIGEsIHYpIHtcbiAgICBsZXQgeCA9IHZbMF0sXG4gICAgICAgIHkgPSB2WzFdLFxuICAgICAgICB6ID0gdlsyXTtcbiAgICBsZXQgYTAwLCBhMDEsIGEwMiwgYTAzO1xuICAgIGxldCBhMTAsIGExMSwgYTEyLCBhMTM7XG4gICAgbGV0IGEyMCwgYTIxLCBhMjIsIGEyMztcblxuICAgIGlmIChhID09PSBvdXQpIHtcbiAgICAgICAgb3V0WzEyXSA9IGFbMF0gKiB4ICsgYVs0XSAqIHkgKyBhWzhdICogeiArIGFbMTJdO1xuICAgICAgICBvdXRbMTNdID0gYVsxXSAqIHggKyBhWzVdICogeSArIGFbOV0gKiB6ICsgYVsxM107XG4gICAgICAgIG91dFsxNF0gPSBhWzJdICogeCArIGFbNl0gKiB5ICsgYVsxMF0gKiB6ICsgYVsxNF07XG4gICAgICAgIG91dFsxNV0gPSBhWzNdICogeCArIGFbN10gKiB5ICsgYVsxMV0gKiB6ICsgYVsxNV07XG4gICAgfSBlbHNlIHtcbiAgICAgICAgYTAwID0gYVswXTtcbiAgICAgICAgYTAxID0gYVsxXTtcbiAgICAgICAgYTAyID0gYVsyXTtcbiAgICAgICAgYTAzID0gYVszXTtcbiAgICAgICAgYTEwID0gYVs0XTtcbiAgICAgICAgYTExID0gYVs1XTtcbiAgICAgICAgYTEyID0gYVs2XTtcbiAgICAgICAgYTEzID0gYVs3XTtcbiAgICAgICAgYTIwID0gYVs4XTtcbiAgICAgICAgYTIxID0gYVs5XTtcbiAgICAgICAgYTIyID0gYVsxMF07XG4gICAgICAgIGEyMyA9IGFbMTFdO1xuXG4gICAgICAgIG91dFswXSA9IGEwMDtcbiAgICAgICAgb3V0WzFdID0gYTAxO1xuICAgICAgICBvdXRbMl0gPSBhMDI7XG4gICAgICAgIG91dFszXSA9IGEwMztcbiAgICAgICAgb3V0WzRdID0gYTEwO1xuICAgICAgICBvdXRbNV0gPSBhMTE7XG4gICAgICAgIG91dFs2XSA9IGExMjtcbiAgICAgICAgb3V0WzddID0gYTEzO1xuICAgICAgICBvdXRbOF0gPSBhMjA7XG4gICAgICAgIG91dFs5XSA9IGEyMTtcbiAgICAgICAgb3V0WzEwXSA9IGEyMjtcbiAgICAgICAgb3V0WzExXSA9IGEyMztcblxuICAgICAgICBvdXRbMTJdID0gYTAwICogeCArIGExMCAqIHkgKyBhMjAgKiB6ICsgYVsxMl07XG4gICAgICAgIG91dFsxM10gPSBhMDEgKiB4ICsgYTExICogeSArIGEyMSAqIHogKyBhWzEzXTtcbiAgICAgICAgb3V0WzE0XSA9IGEwMiAqIHggKyBhMTIgKiB5ICsgYTIyICogeiArIGFbMTRdO1xuICAgICAgICBvdXRbMTVdID0gYTAzICogeCArIGExMyAqIHkgKyBhMjMgKiB6ICsgYVsxNV07XG4gICAgfVxuXG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBTY2FsZXMgdGhlIG1hdDQgYnkgdGhlIGRpbWVuc2lvbnMgaW4gdGhlIGdpdmVuIHZlYzMgbm90IHVzaW5nIHZlY3Rvcml6YXRpb25cbiAqXG4gKiBAcGFyYW0ge21hdDR9IG91dCB0aGUgcmVjZWl2aW5nIG1hdHJpeFxuICogQHBhcmFtIHttYXQ0fSBhIHRoZSBtYXRyaXggdG8gc2NhbGVcbiAqIEBwYXJhbSB7dmVjM30gdiB0aGUgdmVjMyB0byBzY2FsZSB0aGUgbWF0cml4IGJ5XG4gKiBAcmV0dXJucyB7bWF0NH0gb3V0XG4gKiovXG5leHBvcnQgZnVuY3Rpb24gc2NhbGUob3V0LCBhLCB2KSB7XG4gICAgbGV0IHggPSB2WzBdLFxuICAgICAgICB5ID0gdlsxXSxcbiAgICAgICAgeiA9IHZbMl07XG5cbiAgICBvdXRbMF0gPSBhWzBdICogeDtcbiAgICBvdXRbMV0gPSBhWzFdICogeDtcbiAgICBvdXRbMl0gPSBhWzJdICogeDtcbiAgICBvdXRbM10gPSBhWzNdICogeDtcbiAgICBvdXRbNF0gPSBhWzRdICogeTtcbiAgICBvdXRbNV0gPSBhWzVdICogeTtcbiAgICBvdXRbNl0gPSBhWzZdICogeTtcbiAgICBvdXRbN10gPSBhWzddICogeTtcbiAgICBvdXRbOF0gPSBhWzhdICogejtcbiAgICBvdXRbOV0gPSBhWzldICogejtcbiAgICBvdXRbMTBdID0gYVsxMF0gKiB6O1xuICAgIG91dFsxMV0gPSBhWzExXSAqIHo7XG4gICAgb3V0WzEyXSA9IGFbMTJdO1xuICAgIG91dFsxM10gPSBhWzEzXTtcbiAgICBvdXRbMTRdID0gYVsxNF07XG4gICAgb3V0WzE1XSA9IGFbMTVdO1xuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogUm90YXRlcyBhIG1hdDQgYnkgdGhlIGdpdmVuIGFuZ2xlIGFyb3VuZCB0aGUgZ2l2ZW4gYXhpc1xuICpcbiAqIEBwYXJhbSB7bWF0NH0gb3V0IHRoZSByZWNlaXZpbmcgbWF0cml4XG4gKiBAcGFyYW0ge21hdDR9IGEgdGhlIG1hdHJpeCB0byByb3RhdGVcbiAqIEBwYXJhbSB7TnVtYmVyfSByYWQgdGhlIGFuZ2xlIHRvIHJvdGF0ZSB0aGUgbWF0cml4IGJ5XG4gKiBAcGFyYW0ge3ZlYzN9IGF4aXMgdGhlIGF4aXMgdG8gcm90YXRlIGFyb3VuZFxuICogQHJldHVybnMge21hdDR9IG91dFxuICovXG5leHBvcnQgZnVuY3Rpb24gcm90YXRlKG91dCwgYSwgcmFkLCBheGlzKSB7XG4gICAgbGV0IHggPSBheGlzWzBdLFxuICAgICAgICB5ID0gYXhpc1sxXSxcbiAgICAgICAgeiA9IGF4aXNbMl07XG4gICAgbGV0IGxlbiA9IE1hdGguaHlwb3QoeCwgeSwgeik7XG4gICAgbGV0IHMsIGMsIHQ7XG4gICAgbGV0IGEwMCwgYTAxLCBhMDIsIGEwMztcbiAgICBsZXQgYTEwLCBhMTEsIGExMiwgYTEzO1xuICAgIGxldCBhMjAsIGEyMSwgYTIyLCBhMjM7XG4gICAgbGV0IGIwMCwgYjAxLCBiMDI7XG4gICAgbGV0IGIxMCwgYjExLCBiMTI7XG4gICAgbGV0IGIyMCwgYjIxLCBiMjI7XG5cbiAgICBpZiAoTWF0aC5hYnMobGVuKSA8IEVQU0lMT04pIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuXG4gICAgbGVuID0gMSAvIGxlbjtcbiAgICB4ICo9IGxlbjtcbiAgICB5ICo9IGxlbjtcbiAgICB6ICo9IGxlbjtcblxuICAgIHMgPSBNYXRoLnNpbihyYWQpO1xuICAgIGMgPSBNYXRoLmNvcyhyYWQpO1xuICAgIHQgPSAxIC0gYztcblxuICAgIGEwMCA9IGFbMF07XG4gICAgYTAxID0gYVsxXTtcbiAgICBhMDIgPSBhWzJdO1xuICAgIGEwMyA9IGFbM107XG4gICAgYTEwID0gYVs0XTtcbiAgICBhMTEgPSBhWzVdO1xuICAgIGExMiA9IGFbNl07XG4gICAgYTEzID0gYVs3XTtcbiAgICBhMjAgPSBhWzhdO1xuICAgIGEyMSA9IGFbOV07XG4gICAgYTIyID0gYVsxMF07XG4gICAgYTIzID0gYVsxMV07XG5cbiAgICAvLyBDb25zdHJ1Y3QgdGhlIGVsZW1lbnRzIG9mIHRoZSByb3RhdGlvbiBtYXRyaXhcbiAgICBiMDAgPSB4ICogeCAqIHQgKyBjO1xuICAgIGIwMSA9IHkgKiB4ICogdCArIHogKiBzO1xuICAgIGIwMiA9IHogKiB4ICogdCAtIHkgKiBzO1xuICAgIGIxMCA9IHggKiB5ICogdCAtIHogKiBzO1xuICAgIGIxMSA9IHkgKiB5ICogdCArIGM7XG4gICAgYjEyID0geiAqIHkgKiB0ICsgeCAqIHM7XG4gICAgYjIwID0geCAqIHogKiB0ICsgeSAqIHM7XG4gICAgYjIxID0geSAqIHogKiB0IC0geCAqIHM7XG4gICAgYjIyID0geiAqIHogKiB0ICsgYztcblxuICAgIC8vIFBlcmZvcm0gcm90YXRpb24tc3BlY2lmaWMgbWF0cml4IG11bHRpcGxpY2F0aW9uXG4gICAgb3V0WzBdID0gYTAwICogYjAwICsgYTEwICogYjAxICsgYTIwICogYjAyO1xuICAgIG91dFsxXSA9IGEwMSAqIGIwMCArIGExMSAqIGIwMSArIGEyMSAqIGIwMjtcbiAgICBvdXRbMl0gPSBhMDIgKiBiMDAgKyBhMTIgKiBiMDEgKyBhMjIgKiBiMDI7XG4gICAgb3V0WzNdID0gYTAzICogYjAwICsgYTEzICogYjAxICsgYTIzICogYjAyO1xuICAgIG91dFs0XSA9IGEwMCAqIGIxMCArIGExMCAqIGIxMSArIGEyMCAqIGIxMjtcbiAgICBvdXRbNV0gPSBhMDEgKiBiMTAgKyBhMTEgKiBiMTEgKyBhMjEgKiBiMTI7XG4gICAgb3V0WzZdID0gYTAyICogYjEwICsgYTEyICogYjExICsgYTIyICogYjEyO1xuICAgIG91dFs3XSA9IGEwMyAqIGIxMCArIGExMyAqIGIxMSArIGEyMyAqIGIxMjtcbiAgICBvdXRbOF0gPSBhMDAgKiBiMjAgKyBhMTAgKiBiMjEgKyBhMjAgKiBiMjI7XG4gICAgb3V0WzldID0gYTAxICogYjIwICsgYTExICogYjIxICsgYTIxICogYjIyO1xuICAgIG91dFsxMF0gPSBhMDIgKiBiMjAgKyBhMTIgKiBiMjEgKyBhMjIgKiBiMjI7XG4gICAgb3V0WzExXSA9IGEwMyAqIGIyMCArIGExMyAqIGIyMSArIGEyMyAqIGIyMjtcblxuICAgIGlmIChhICE9PSBvdXQpIHtcbiAgICAgICAgLy8gSWYgdGhlIHNvdXJjZSBhbmQgZGVzdGluYXRpb24gZGlmZmVyLCBjb3B5IHRoZSB1bmNoYW5nZWQgbGFzdCByb3dcbiAgICAgICAgb3V0WzEyXSA9IGFbMTJdO1xuICAgICAgICBvdXRbMTNdID0gYVsxM107XG4gICAgICAgIG91dFsxNF0gPSBhWzE0XTtcbiAgICAgICAgb3V0WzE1XSA9IGFbMTVdO1xuICAgIH1cbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIHRyYW5zbGF0aW9uIHZlY3RvciBjb21wb25lbnQgb2YgYSB0cmFuc2Zvcm1hdGlvblxuICogIG1hdHJpeC4gSWYgYSBtYXRyaXggaXMgYnVpbHQgd2l0aCBmcm9tUm90YXRpb25UcmFuc2xhdGlvbixcbiAqICB0aGUgcmV0dXJuZWQgdmVjdG9yIHdpbGwgYmUgdGhlIHNhbWUgYXMgdGhlIHRyYW5zbGF0aW9uIHZlY3RvclxuICogIG9yaWdpbmFsbHkgc3VwcGxpZWQuXG4gKiBAcGFyYW0gIHt2ZWMzfSBvdXQgVmVjdG9yIHRvIHJlY2VpdmUgdHJhbnNsYXRpb24gY29tcG9uZW50XG4gKiBAcGFyYW0gIHttYXQ0fSBtYXQgTWF0cml4IHRvIGJlIGRlY29tcG9zZWQgKGlucHV0KVxuICogQHJldHVybiB7dmVjM30gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRUcmFuc2xhdGlvbihvdXQsIG1hdCkge1xuICAgIG91dFswXSA9IG1hdFsxMl07XG4gICAgb3V0WzFdID0gbWF0WzEzXTtcbiAgICBvdXRbMl0gPSBtYXRbMTRdO1xuXG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBzY2FsaW5nIGZhY3RvciBjb21wb25lbnQgb2YgYSB0cmFuc2Zvcm1hdGlvblxuICogIG1hdHJpeC4gSWYgYSBtYXRyaXggaXMgYnVpbHQgd2l0aCBmcm9tUm90YXRpb25UcmFuc2xhdGlvblNjYWxlXG4gKiAgd2l0aCBhIG5vcm1hbGl6ZWQgUXVhdGVybmlvbiBwYXJhbXRlciwgdGhlIHJldHVybmVkIHZlY3RvciB3aWxsIGJlXG4gKiAgdGhlIHNhbWUgYXMgdGhlIHNjYWxpbmcgdmVjdG9yXG4gKiAgb3JpZ2luYWxseSBzdXBwbGllZC5cbiAqIEBwYXJhbSAge3ZlYzN9IG91dCBWZWN0b3IgdG8gcmVjZWl2ZSBzY2FsaW5nIGZhY3RvciBjb21wb25lbnRcbiAqIEBwYXJhbSAge21hdDR9IG1hdCBNYXRyaXggdG8gYmUgZGVjb21wb3NlZCAoaW5wdXQpXG4gKiBAcmV0dXJuIHt2ZWMzfSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldFNjYWxpbmcob3V0LCBtYXQpIHtcbiAgICBsZXQgbTExID0gbWF0WzBdO1xuICAgIGxldCBtMTIgPSBtYXRbMV07XG4gICAgbGV0IG0xMyA9IG1hdFsyXTtcbiAgICBsZXQgbTIxID0gbWF0WzRdO1xuICAgIGxldCBtMjIgPSBtYXRbNV07XG4gICAgbGV0IG0yMyA9IG1hdFs2XTtcbiAgICBsZXQgbTMxID0gbWF0WzhdO1xuICAgIGxldCBtMzIgPSBtYXRbOV07XG4gICAgbGV0IG0zMyA9IG1hdFsxMF07XG5cbiAgICBvdXRbMF0gPSBNYXRoLmh5cG90KG0xMSwgbTEyLCBtMTMpO1xuICAgIG91dFsxXSA9IE1hdGguaHlwb3QobTIxLCBtMjIsIG0yMyk7XG4gICAgb3V0WzJdID0gTWF0aC5oeXBvdChtMzEsIG0zMiwgbTMzKTtcblxuICAgIHJldHVybiBvdXQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRNYXhTY2FsZU9uQXhpcyhtYXQpIHtcbiAgICBsZXQgbTExID0gbWF0WzBdO1xuICAgIGxldCBtMTIgPSBtYXRbMV07XG4gICAgbGV0IG0xMyA9IG1hdFsyXTtcbiAgICBsZXQgbTIxID0gbWF0WzRdO1xuICAgIGxldCBtMjIgPSBtYXRbNV07XG4gICAgbGV0IG0yMyA9IG1hdFs2XTtcbiAgICBsZXQgbTMxID0gbWF0WzhdO1xuICAgIGxldCBtMzIgPSBtYXRbOV07XG4gICAgbGV0IG0zMyA9IG1hdFsxMF07XG5cbiAgICBjb25zdCB4ID0gbTExICogbTExICsgbTEyICogbTEyICsgbTEzICogbTEzO1xuICAgIGNvbnN0IHkgPSBtMjEgKiBtMjEgKyBtMjIgKiBtMjIgKyBtMjMgKiBtMjM7XG4gICAgY29uc3QgeiA9IG0zMSAqIG0zMSArIG0zMiAqIG0zMiArIG0zMyAqIG0zMztcblxuICAgIHJldHVybiBNYXRoLnNxcnQoTWF0aC5tYXgoeCwgeSwgeikpO1xufVxuXG4vKipcbiAqIFJldHVybnMgYSBxdWF0ZXJuaW9uIHJlcHJlc2VudGluZyB0aGUgcm90YXRpb25hbCBjb21wb25lbnRcbiAqICBvZiBhIHRyYW5zZm9ybWF0aW9uIG1hdHJpeC4gSWYgYSBtYXRyaXggaXMgYnVpbHQgd2l0aFxuICogIGZyb21Sb3RhdGlvblRyYW5zbGF0aW9uLCB0aGUgcmV0dXJuZWQgcXVhdGVybmlvbiB3aWxsIGJlIHRoZVxuICogIHNhbWUgYXMgdGhlIHF1YXRlcm5pb24gb3JpZ2luYWxseSBzdXBwbGllZC5cbiAqIEBwYXJhbSB7cXVhdH0gb3V0IFF1YXRlcm5pb24gdG8gcmVjZWl2ZSB0aGUgcm90YXRpb24gY29tcG9uZW50XG4gKiBAcGFyYW0ge21hdDR9IG1hdCBNYXRyaXggdG8gYmUgZGVjb21wb3NlZCAoaW5wdXQpXG4gKiBAcmV0dXJuIHtxdWF0fSBvdXRcbiAqL1xuZXhwb3J0IGNvbnN0IGdldFJvdGF0aW9uID0gKGZ1bmN0aW9uICgpIHtcbiAgICBjb25zdCB0ZW1wID0gWzEsIDEsIDFdO1xuXG4gICAgcmV0dXJuIGZ1bmN0aW9uIChvdXQsIG1hdCkge1xuICAgICAgICBsZXQgc2NhbGluZyA9IHRlbXA7XG4gICAgICAgIGdldFNjYWxpbmcoc2NhbGluZywgbWF0KTtcblxuICAgICAgICBsZXQgaXMxID0gMSAvIHNjYWxpbmdbMF07XG4gICAgICAgIGxldCBpczIgPSAxIC8gc2NhbGluZ1sxXTtcbiAgICAgICAgbGV0IGlzMyA9IDEgLyBzY2FsaW5nWzJdO1xuXG4gICAgICAgIGxldCBzbTExID0gbWF0WzBdICogaXMxO1xuICAgICAgICBsZXQgc20xMiA9IG1hdFsxXSAqIGlzMjtcbiAgICAgICAgbGV0IHNtMTMgPSBtYXRbMl0gKiBpczM7XG4gICAgICAgIGxldCBzbTIxID0gbWF0WzRdICogaXMxO1xuICAgICAgICBsZXQgc20yMiA9IG1hdFs1XSAqIGlzMjtcbiAgICAgICAgbGV0IHNtMjMgPSBtYXRbNl0gKiBpczM7XG4gICAgICAgIGxldCBzbTMxID0gbWF0WzhdICogaXMxO1xuICAgICAgICBsZXQgc20zMiA9IG1hdFs5XSAqIGlzMjtcbiAgICAgICAgbGV0IHNtMzMgPSBtYXRbMTBdICogaXMzO1xuXG4gICAgICAgIGxldCB0cmFjZSA9IHNtMTEgKyBzbTIyICsgc20zMztcbiAgICAgICAgbGV0IFMgPSAwO1xuXG4gICAgICAgIGlmICh0cmFjZSA+IDApIHtcbiAgICAgICAgICAgIFMgPSBNYXRoLnNxcnQodHJhY2UgKyAxLjApICogMjtcbiAgICAgICAgICAgIG91dFszXSA9IDAuMjUgKiBTO1xuICAgICAgICAgICAgb3V0WzBdID0gKHNtMjMgLSBzbTMyKSAvIFM7XG4gICAgICAgICAgICBvdXRbMV0gPSAoc20zMSAtIHNtMTMpIC8gUztcbiAgICAgICAgICAgIG91dFsyXSA9IChzbTEyIC0gc20yMSkgLyBTO1xuICAgICAgICB9IGVsc2UgaWYgKHNtMTEgPiBzbTIyICYmIHNtMTEgPiBzbTMzKSB7XG4gICAgICAgICAgICBTID0gTWF0aC5zcXJ0KDEuMCArIHNtMTEgLSBzbTIyIC0gc20zMykgKiAyO1xuICAgICAgICAgICAgb3V0WzNdID0gKHNtMjMgLSBzbTMyKSAvIFM7XG4gICAgICAgICAgICBvdXRbMF0gPSAwLjI1ICogUztcbiAgICAgICAgICAgIG91dFsxXSA9IChzbTEyICsgc20yMSkgLyBTO1xuICAgICAgICAgICAgb3V0WzJdID0gKHNtMzEgKyBzbTEzKSAvIFM7XG4gICAgICAgIH0gZWxzZSBpZiAoc20yMiA+IHNtMzMpIHtcbiAgICAgICAgICAgIFMgPSBNYXRoLnNxcnQoMS4wICsgc20yMiAtIHNtMTEgLSBzbTMzKSAqIDI7XG4gICAgICAgICAgICBvdXRbM10gPSAoc20zMSAtIHNtMTMpIC8gUztcbiAgICAgICAgICAgIG91dFswXSA9IChzbTEyICsgc20yMSkgLyBTO1xuICAgICAgICAgICAgb3V0WzFdID0gMC4yNSAqIFM7XG4gICAgICAgICAgICBvdXRbMl0gPSAoc20yMyArIHNtMzIpIC8gUztcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIFMgPSBNYXRoLnNxcnQoMS4wICsgc20zMyAtIHNtMTEgLSBzbTIyKSAqIDI7XG4gICAgICAgICAgICBvdXRbM10gPSAoc20xMiAtIHNtMjEpIC8gUztcbiAgICAgICAgICAgIG91dFswXSA9IChzbTMxICsgc20xMykgLyBTO1xuICAgICAgICAgICAgb3V0WzFdID0gKHNtMjMgKyBzbTMyKSAvIFM7XG4gICAgICAgICAgICBvdXRbMl0gPSAwLjI1ICogUztcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBvdXQ7XG4gICAgfTtcbn0pKCk7XG5cbi8qKlxuICogRnJvbSBnbFRGLVRyYW5zZm9ybVxuICogaHR0cHM6Ly9naXRodWIuY29tL2Rvbm1jY3VyZHkvZ2xURi1UcmFuc2Zvcm0vYmxvYi9tYWluL3BhY2thZ2VzL2NvcmUvc3JjL3V0aWxzL21hdGgtdXRpbHMudHNcbiAqXG4gKiBEZWNvbXBvc2UgYSBtYXQ0IHRvIFRSUyBwcm9wZXJ0aWVzLlxuICpcbiAqIEVxdWl2YWxlbnQgdG8gdGhlIE1hdHJpeDQgZGVjb21wb3NlKCkgbWV0aG9kIGluIHRocmVlLmpzLCBhbmQgaW50ZW50aW9uYWxseSBub3QgdXNpbmcgdGhlXG4gKiBnbC1tYXRyaXggdmVyc2lvbi4gU2VlOiBodHRwczovL2dpdGh1Yi5jb20vdG9qaS9nbC1tYXRyaXgvaXNzdWVzLzQwOFxuICpcbiAqIEBwYXJhbSB7bWF0NH0gc3JjTWF0IE1hdHJpeCBlbGVtZW50LCB0byBiZSBkZWNvbXBvc2VkIHRvIFRSUyBwcm9wZXJ0aWVzLlxuICogQHBhcmFtIHtxdWF0NH0gZHN0Um90YXRpb24gUm90YXRpb24gZWxlbWVudCwgdG8gYmUgb3ZlcndyaXR0ZW4uXG4gKiBAcGFyYW0ge3ZlYzN9IGRzdFRyYW5zbGF0aW9uIFRyYW5zbGF0aW9uIGVsZW1lbnQsIHRvIGJlIG92ZXJ3cml0dGVuLlxuICogQHBhcmFtIHt2ZWMzfSBkc3RTY2FsZSBTY2FsZSBlbGVtZW50LCB0byBiZSBvdmVyd3JpdHRlblxuICovXG5leHBvcnQgZnVuY3Rpb24gZGVjb21wb3NlKHNyY01hdCwgZHN0Um90YXRpb24sIGRzdFRyYW5zbGF0aW9uLCBkc3RTY2FsZSkge1xuICAgIGxldCBzeCA9IHZlYzMubGVuZ3RoKFtzcmNNYXRbMF0sIHNyY01hdFsxXSwgc3JjTWF0WzJdXSk7XG4gICAgY29uc3Qgc3kgPSB2ZWMzLmxlbmd0aChbc3JjTWF0WzRdLCBzcmNNYXRbNV0sIHNyY01hdFs2XV0pO1xuICAgIGNvbnN0IHN6ID0gdmVjMy5sZW5ndGgoW3NyY01hdFs4XSwgc3JjTWF0WzldLCBzcmNNYXRbMTBdXSk7XG5cbiAgICAvLyBpZiBkZXRlcm1pbmUgaXMgbmVnYXRpdmUsIHdlIG5lZWQgdG8gaW52ZXJ0IG9uZSBzY2FsZVxuICAgIGNvbnN0IGRldCA9IGRldGVybWluYW50KHNyY01hdCk7XG4gICAgaWYgKGRldCA8IDApIHN4ID0gLXN4O1xuXG4gICAgZHN0VHJhbnNsYXRpb25bMF0gPSBzcmNNYXRbMTJdO1xuICAgIGRzdFRyYW5zbGF0aW9uWzFdID0gc3JjTWF0WzEzXTtcbiAgICBkc3RUcmFuc2xhdGlvblsyXSA9IHNyY01hdFsxNF07XG5cbiAgICAvLyBzY2FsZSB0aGUgcm90YXRpb24gcGFydFxuICAgIGNvbnN0IF9tMSA9IHNyY01hdC5zbGljZSgpO1xuXG4gICAgY29uc3QgaW52U1ggPSAxIC8gc3g7XG4gICAgY29uc3QgaW52U1kgPSAxIC8gc3k7XG4gICAgY29uc3QgaW52U1ogPSAxIC8gc3o7XG5cbiAgICBfbTFbMF0gKj0gaW52U1g7XG4gICAgX20xWzFdICo9IGludlNYO1xuICAgIF9tMVsyXSAqPSBpbnZTWDtcblxuICAgIF9tMVs0XSAqPSBpbnZTWTtcbiAgICBfbTFbNV0gKj0gaW52U1k7XG4gICAgX20xWzZdICo9IGludlNZO1xuXG4gICAgX20xWzhdICo9IGludlNaO1xuICAgIF9tMVs5XSAqPSBpbnZTWjtcbiAgICBfbTFbMTBdICo9IGludlNaO1xuXG4gICAgZ2V0Um90YXRpb24oZHN0Um90YXRpb24sIF9tMSk7XG5cbiAgICBkc3RTY2FsZVswXSA9IHN4O1xuICAgIGRzdFNjYWxlWzFdID0gc3k7XG4gICAgZHN0U2NhbGVbMl0gPSBzejtcbn1cblxuLyoqXG4gKiBGcm9tIGdsVEYtVHJhbnNmb3JtXG4gKiBodHRwczovL2dpdGh1Yi5jb20vZG9ubWNjdXJkeS9nbFRGLVRyYW5zZm9ybS9ibG9iL21haW4vcGFja2FnZXMvY29yZS9zcmMvdXRpbHMvbWF0aC11dGlscy50c1xuICpcbiAqIENvbXBvc2UgVFJTIHByb3BlcnRpZXMgdG8gYSBtYXQ0LlxuICpcbiAqIEVxdWl2YWxlbnQgdG8gdGhlIE1hdHJpeDQgY29tcG9zZSgpIG1ldGhvZCBpbiB0aHJlZS5qcywgYW5kIGludGVudGlvbmFsbHkgbm90IHVzaW5nIHRoZVxuICogZ2wtbWF0cml4IHZlcnNpb24uIFNlZTogaHR0cHM6Ly9naXRodWIuY29tL3RvamkvZ2wtbWF0cml4L2lzc3Vlcy80MDhcbiAqXG4gKiBAcGFyYW0ge21hdDR9IGRzdE1hdCBNYXRyaXggZWxlbWVudCwgdG8gYmUgbW9kaWZpZWQgYW5kIHJldHVybmVkLlxuICogQHBhcmFtIHtxdWF0NH0gc3JjUm90YXRpb24gUm90YXRpb24gZWxlbWVudCBvZiBtYXRyaXguXG4gKiBAcGFyYW0ge3ZlYzN9IHNyY1RyYW5zbGF0aW9uIFRyYW5zbGF0aW9uIGVsZW1lbnQgb2YgbWF0cml4LlxuICogQHBhcmFtIHt2ZWMzfSBzcmNTY2FsZSBTY2FsZSBlbGVtZW50IG9mIG1hdHJpeC5cbiAqIEByZXR1cm5zIHttYXQ0fSBkc3RNYXQsIG92ZXJ3cml0dGVuIHRvIG1hdDQgZXF1aXZhbGVudCBvZiBnaXZlbiBUUlMgcHJvcGVydGllcy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNvbXBvc2UoZHN0TWF0LCBzcmNSb3RhdGlvbiwgc3JjVHJhbnNsYXRpb24sIHNyY1NjYWxlKSB7XG4gICAgY29uc3QgdGUgPSBkc3RNYXQ7XG5cbiAgICBjb25zdCB4ID0gc3JjUm90YXRpb25bMF0sXG4gICAgICAgIHkgPSBzcmNSb3RhdGlvblsxXSxcbiAgICAgICAgeiA9IHNyY1JvdGF0aW9uWzJdLFxuICAgICAgICB3ID0gc3JjUm90YXRpb25bM107XG4gICAgY29uc3QgeDIgPSB4ICsgeCxcbiAgICAgICAgeTIgPSB5ICsgeSxcbiAgICAgICAgejIgPSB6ICsgejtcbiAgICBjb25zdCB4eCA9IHggKiB4MixcbiAgICAgICAgeHkgPSB4ICogeTIsXG4gICAgICAgIHh6ID0geCAqIHoyO1xuICAgIGNvbnN0IHl5ID0geSAqIHkyLFxuICAgICAgICB5eiA9IHkgKiB6MixcbiAgICAgICAgenogPSB6ICogejI7XG4gICAgY29uc3Qgd3ggPSB3ICogeDIsXG4gICAgICAgIHd5ID0gdyAqIHkyLFxuICAgICAgICB3eiA9IHcgKiB6MjtcblxuICAgIGNvbnN0IHN4ID0gc3JjU2NhbGVbMF0sXG4gICAgICAgIHN5ID0gc3JjU2NhbGVbMV0sXG4gICAgICAgIHN6ID0gc3JjU2NhbGVbMl07XG5cbiAgICB0ZVswXSA9ICgxIC0gKHl5ICsgenopKSAqIHN4O1xuICAgIHRlWzFdID0gKHh5ICsgd3opICogc3g7XG4gICAgdGVbMl0gPSAoeHogLSB3eSkgKiBzeDtcbiAgICB0ZVszXSA9IDA7XG5cbiAgICB0ZVs0XSA9ICh4eSAtIHd6KSAqIHN5O1xuICAgIHRlWzVdID0gKDEgLSAoeHggKyB6eikpICogc3k7XG4gICAgdGVbNl0gPSAoeXogKyB3eCkgKiBzeTtcbiAgICB0ZVs3XSA9IDA7XG5cbiAgICB0ZVs4XSA9ICh4eiArIHd5KSAqIHN6O1xuICAgIHRlWzldID0gKHl6IC0gd3gpICogc3o7XG4gICAgdGVbMTBdID0gKDEgLSAoeHggKyB5eSkpICogc3o7XG4gICAgdGVbMTFdID0gMDtcblxuICAgIHRlWzEyXSA9IHNyY1RyYW5zbGF0aW9uWzBdO1xuICAgIHRlWzEzXSA9IHNyY1RyYW5zbGF0aW9uWzFdO1xuICAgIHRlWzE0XSA9IHNyY1RyYW5zbGF0aW9uWzJdO1xuICAgIHRlWzE1XSA9IDE7XG5cbiAgICByZXR1cm4gdGU7XG59XG5cbi8qKlxuICogQ3JlYXRlcyBhIG1hdHJpeCBmcm9tIGEgcXVhdGVybmlvbiByb3RhdGlvbiwgdmVjdG9yIHRyYW5zbGF0aW9uIGFuZCB2ZWN0b3Igc2NhbGVcbiAqIFRoaXMgaXMgZXF1aXZhbGVudCB0byAoYnV0IG11Y2ggZmFzdGVyIHRoYW4pOlxuICpcbiAqICAgICBtYXQ0LmlkZW50aXR5KGRlc3QpO1xuICogICAgIG1hdDQudHJhbnNsYXRlKGRlc3QsIHZlYyk7XG4gKiAgICAgbGV0IHF1YXRNYXQgPSBtYXQ0LmNyZWF0ZSgpO1xuICogICAgIHF1YXQ0LnRvTWF0NChxdWF0LCBxdWF0TWF0KTtcbiAqICAgICBtYXQ0Lm11bHRpcGx5KGRlc3QsIHF1YXRNYXQpO1xuICogICAgIG1hdDQuc2NhbGUoZGVzdCwgc2NhbGUpXG4gKlxuICogQHBhcmFtIHttYXQ0fSBvdXQgbWF0NCByZWNlaXZpbmcgb3BlcmF0aW9uIHJlc3VsdFxuICogQHBhcmFtIHtxdWF0NH0gcSBSb3RhdGlvbiBxdWF0ZXJuaW9uXG4gKiBAcGFyYW0ge3ZlYzN9IHYgVHJhbnNsYXRpb24gdmVjdG9yXG4gKiBAcGFyYW0ge3ZlYzN9IHMgU2NhbGluZyB2ZWN0b3JcbiAqIEByZXR1cm5zIHttYXQ0fSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZyb21Sb3RhdGlvblRyYW5zbGF0aW9uU2NhbGUob3V0LCBxLCB2LCBzKSB7XG4gICAgLy8gUXVhdGVybmlvbiBtYXRoXG4gICAgbGV0IHggPSBxWzBdLFxuICAgICAgICB5ID0gcVsxXSxcbiAgICAgICAgeiA9IHFbMl0sXG4gICAgICAgIHcgPSBxWzNdO1xuICAgIGxldCB4MiA9IHggKyB4O1xuICAgIGxldCB5MiA9IHkgKyB5O1xuICAgIGxldCB6MiA9IHogKyB6O1xuXG4gICAgbGV0IHh4ID0geCAqIHgyO1xuICAgIGxldCB4eSA9IHggKiB5MjtcbiAgICBsZXQgeHogPSB4ICogejI7XG4gICAgbGV0IHl5ID0geSAqIHkyO1xuICAgIGxldCB5eiA9IHkgKiB6MjtcbiAgICBsZXQgenogPSB6ICogejI7XG4gICAgbGV0IHd4ID0gdyAqIHgyO1xuICAgIGxldCB3eSA9IHcgKiB5MjtcbiAgICBsZXQgd3ogPSB3ICogejI7XG4gICAgbGV0IHN4ID0gc1swXTtcbiAgICBsZXQgc3kgPSBzWzFdO1xuICAgIGxldCBzeiA9IHNbMl07XG5cbiAgICBvdXRbMF0gPSAoMSAtICh5eSArIHp6KSkgKiBzeDtcbiAgICBvdXRbMV0gPSAoeHkgKyB3eikgKiBzeDtcbiAgICBvdXRbMl0gPSAoeHogLSB3eSkgKiBzeDtcbiAgICBvdXRbM10gPSAwO1xuICAgIG91dFs0XSA9ICh4eSAtIHd6KSAqIHN5O1xuICAgIG91dFs1XSA9ICgxIC0gKHh4ICsgenopKSAqIHN5O1xuICAgIG91dFs2XSA9ICh5eiArIHd4KSAqIHN5O1xuICAgIG91dFs3XSA9IDA7XG4gICAgb3V0WzhdID0gKHh6ICsgd3kpICogc3o7XG4gICAgb3V0WzldID0gKHl6IC0gd3gpICogc3o7XG4gICAgb3V0WzEwXSA9ICgxIC0gKHh4ICsgeXkpKSAqIHN6O1xuICAgIG91dFsxMV0gPSAwO1xuICAgIG91dFsxMl0gPSB2WzBdO1xuICAgIG91dFsxM10gPSB2WzFdO1xuICAgIG91dFsxNF0gPSB2WzJdO1xuICAgIG91dFsxNV0gPSAxO1xuXG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBDYWxjdWxhdGVzIGEgNHg0IG1hdHJpeCBmcm9tIHRoZSBnaXZlbiBxdWF0ZXJuaW9uXG4gKlxuICogQHBhcmFtIHttYXQ0fSBvdXQgbWF0NCByZWNlaXZpbmcgb3BlcmF0aW9uIHJlc3VsdFxuICogQHBhcmFtIHtxdWF0fSBxIFF1YXRlcm5pb24gdG8gY3JlYXRlIG1hdHJpeCBmcm9tXG4gKlxuICogQHJldHVybnMge21hdDR9IG91dFxuICovXG5leHBvcnQgZnVuY3Rpb24gZnJvbVF1YXQob3V0LCBxKSB7XG4gICAgbGV0IHggPSBxWzBdLFxuICAgICAgICB5ID0gcVsxXSxcbiAgICAgICAgeiA9IHFbMl0sXG4gICAgICAgIHcgPSBxWzNdO1xuICAgIGxldCB4MiA9IHggKyB4O1xuICAgIGxldCB5MiA9IHkgKyB5O1xuICAgIGxldCB6MiA9IHogKyB6O1xuXG4gICAgbGV0IHh4ID0geCAqIHgyO1xuICAgIGxldCB5eCA9IHkgKiB4MjtcbiAgICBsZXQgeXkgPSB5ICogeTI7XG4gICAgbGV0IHp4ID0geiAqIHgyO1xuICAgIGxldCB6eSA9IHogKiB5MjtcbiAgICBsZXQgenogPSB6ICogejI7XG4gICAgbGV0IHd4ID0gdyAqIHgyO1xuICAgIGxldCB3eSA9IHcgKiB5MjtcbiAgICBsZXQgd3ogPSB3ICogejI7XG5cbiAgICBvdXRbMF0gPSAxIC0geXkgLSB6ejtcbiAgICBvdXRbMV0gPSB5eCArIHd6O1xuICAgIG91dFsyXSA9IHp4IC0gd3k7XG4gICAgb3V0WzNdID0gMDtcblxuICAgIG91dFs0XSA9IHl4IC0gd3o7XG4gICAgb3V0WzVdID0gMSAtIHh4IC0geno7XG4gICAgb3V0WzZdID0genkgKyB3eDtcbiAgICBvdXRbN10gPSAwO1xuXG4gICAgb3V0WzhdID0genggKyB3eTtcbiAgICBvdXRbOV0gPSB6eSAtIHd4O1xuICAgIG91dFsxMF0gPSAxIC0geHggLSB5eTtcbiAgICBvdXRbMTFdID0gMDtcblxuICAgIG91dFsxMl0gPSAwO1xuICAgIG91dFsxM10gPSAwO1xuICAgIG91dFsxNF0gPSAwO1xuICAgIG91dFsxNV0gPSAxO1xuXG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBHZW5lcmF0ZXMgYSBwZXJzcGVjdGl2ZSBwcm9qZWN0aW9uIG1hdHJpeCB3aXRoIHRoZSBnaXZlbiBib3VuZHNcbiAqXG4gKiBAcGFyYW0ge21hdDR9IG91dCBtYXQ0IGZydXN0dW0gbWF0cml4IHdpbGwgYmUgd3JpdHRlbiBpbnRvXG4gKiBAcGFyYW0ge251bWJlcn0gZm92eSBWZXJ0aWNhbCBmaWVsZCBvZiB2aWV3IGluIHJhZGlhbnNcbiAqIEBwYXJhbSB7bnVtYmVyfSBhc3BlY3QgQXNwZWN0IHJhdGlvLiB0eXBpY2FsbHkgdmlld3BvcnQgd2lkdGgvaGVpZ2h0XG4gKiBAcGFyYW0ge251bWJlcn0gbmVhciBOZWFyIGJvdW5kIG9mIHRoZSBmcnVzdHVtXG4gKiBAcGFyYW0ge251bWJlcn0gZmFyIEZhciBib3VuZCBvZiB0aGUgZnJ1c3R1bVxuICogQHJldHVybnMge21hdDR9IG91dFxuICovXG5leHBvcnQgZnVuY3Rpb24gcGVyc3BlY3RpdmUob3V0LCBmb3Z5LCBhc3BlY3QsIG5lYXIsIGZhcikge1xuICAgIGxldCBmID0gMS4wIC8gTWF0aC50YW4oZm92eSAvIDIpO1xuICAgIGxldCBuZiA9IDEgLyAobmVhciAtIGZhcik7XG4gICAgb3V0WzBdID0gZiAvIGFzcGVjdDtcbiAgICBvdXRbMV0gPSAwO1xuICAgIG91dFsyXSA9IDA7XG4gICAgb3V0WzNdID0gMDtcbiAgICBvdXRbNF0gPSAwO1xuICAgIG91dFs1XSA9IGY7XG4gICAgb3V0WzZdID0gMDtcbiAgICBvdXRbN10gPSAwO1xuICAgIG91dFs4XSA9IDA7XG4gICAgb3V0WzldID0gMDtcbiAgICBvdXRbMTBdID0gKGZhciArIG5lYXIpICogbmY7XG4gICAgb3V0WzExXSA9IC0xO1xuICAgIG91dFsxMl0gPSAwO1xuICAgIG91dFsxM10gPSAwO1xuICAgIG91dFsxNF0gPSAyICogZmFyICogbmVhciAqIG5mO1xuICAgIG91dFsxNV0gPSAwO1xuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogR2VuZXJhdGVzIGEgb3J0aG9nb25hbCBwcm9qZWN0aW9uIG1hdHJpeCB3aXRoIHRoZSBnaXZlbiBib3VuZHNcbiAqXG4gKiBAcGFyYW0ge21hdDR9IG91dCBtYXQ0IGZydXN0dW0gbWF0cml4IHdpbGwgYmUgd3JpdHRlbiBpbnRvXG4gKiBAcGFyYW0ge251bWJlcn0gbGVmdCBMZWZ0IGJvdW5kIG9mIHRoZSBmcnVzdHVtXG4gKiBAcGFyYW0ge251bWJlcn0gcmlnaHQgUmlnaHQgYm91bmQgb2YgdGhlIGZydXN0dW1cbiAqIEBwYXJhbSB7bnVtYmVyfSBib3R0b20gQm90dG9tIGJvdW5kIG9mIHRoZSBmcnVzdHVtXG4gKiBAcGFyYW0ge251bWJlcn0gdG9wIFRvcCBib3VuZCBvZiB0aGUgZnJ1c3R1bVxuICogQHBhcmFtIHtudW1iZXJ9IG5lYXIgTmVhciBib3VuZCBvZiB0aGUgZnJ1c3R1bVxuICogQHBhcmFtIHtudW1iZXJ9IGZhciBGYXIgYm91bmQgb2YgdGhlIGZydXN0dW1cbiAqIEByZXR1cm5zIHttYXQ0fSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG9ydGhvKG91dCwgbGVmdCwgcmlnaHQsIGJvdHRvbSwgdG9wLCBuZWFyLCBmYXIpIHtcbiAgICBsZXQgbHIgPSAxIC8gKGxlZnQgLSByaWdodCk7XG4gICAgbGV0IGJ0ID0gMSAvIChib3R0b20gLSB0b3ApO1xuICAgIGxldCBuZiA9IDEgLyAobmVhciAtIGZhcik7XG4gICAgb3V0WzBdID0gLTIgKiBscjtcbiAgICBvdXRbMV0gPSAwO1xuICAgIG91dFsyXSA9IDA7XG4gICAgb3V0WzNdID0gMDtcbiAgICBvdXRbNF0gPSAwO1xuICAgIG91dFs1XSA9IC0yICogYnQ7XG4gICAgb3V0WzZdID0gMDtcbiAgICBvdXRbN10gPSAwO1xuICAgIG91dFs4XSA9IDA7XG4gICAgb3V0WzldID0gMDtcbiAgICBvdXRbMTBdID0gMiAqIG5mO1xuICAgIG91dFsxMV0gPSAwO1xuICAgIG91dFsxMl0gPSAobGVmdCArIHJpZ2h0KSAqIGxyO1xuICAgIG91dFsxM10gPSAodG9wICsgYm90dG9tKSAqIGJ0O1xuICAgIG91dFsxNF0gPSAoZmFyICsgbmVhcikgKiBuZjtcbiAgICBvdXRbMTVdID0gMTtcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIEdlbmVyYXRlcyBhIG1hdHJpeCB0aGF0IG1ha2VzIHNvbWV0aGluZyBsb29rIGF0IHNvbWV0aGluZyBlbHNlLlxuICpcbiAqIEBwYXJhbSB7bWF0NH0gb3V0IG1hdDQgZnJ1c3R1bSBtYXRyaXggd2lsbCBiZSB3cml0dGVuIGludG9cbiAqIEBwYXJhbSB7dmVjM30gZXllIFBvc2l0aW9uIG9mIHRoZSB2aWV3ZXJcbiAqIEBwYXJhbSB7dmVjM30gdGFyZ2V0IFBvaW50IHRoZSB2aWV3ZXIgaXMgbG9va2luZyBhdFxuICogQHBhcmFtIHt2ZWMzfSB1cCB2ZWMzIHBvaW50aW5nIHVwXG4gKiBAcmV0dXJucyB7bWF0NH0gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0YXJnZXRUbyhvdXQsIGV5ZSwgdGFyZ2V0LCB1cCkge1xuICAgIGxldCBleWV4ID0gZXllWzBdLFxuICAgICAgICBleWV5ID0gZXllWzFdLFxuICAgICAgICBleWV6ID0gZXllWzJdLFxuICAgICAgICB1cHggPSB1cFswXSxcbiAgICAgICAgdXB5ID0gdXBbMV0sXG4gICAgICAgIHVweiA9IHVwWzJdO1xuXG4gICAgbGV0IHowID0gZXlleCAtIHRhcmdldFswXSxcbiAgICAgICAgejEgPSBleWV5IC0gdGFyZ2V0WzFdLFxuICAgICAgICB6MiA9IGV5ZXogLSB0YXJnZXRbMl07XG5cbiAgICBsZXQgbGVuID0gejAgKiB6MCArIHoxICogejEgKyB6MiAqIHoyO1xuICAgIGlmIChsZW4gPT09IDApIHtcbiAgICAgICAgLy8gZXllIGFuZCB0YXJnZXQgYXJlIGluIHRoZSBzYW1lIHBvc2l0aW9uXG4gICAgICAgIHoyID0gMTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBsZW4gPSAxIC8gTWF0aC5zcXJ0KGxlbik7XG4gICAgICAgIHowICo9IGxlbjtcbiAgICAgICAgejEgKj0gbGVuO1xuICAgICAgICB6MiAqPSBsZW47XG4gICAgfVxuXG4gICAgbGV0IHgwID0gdXB5ICogejIgLSB1cHogKiB6MSxcbiAgICAgICAgeDEgPSB1cHogKiB6MCAtIHVweCAqIHoyLFxuICAgICAgICB4MiA9IHVweCAqIHoxIC0gdXB5ICogejA7XG5cbiAgICBsZW4gPSB4MCAqIHgwICsgeDEgKiB4MSArIHgyICogeDI7XG4gICAgaWYgKGxlbiA9PT0gMCkge1xuICAgICAgICAvLyB1cCBhbmQgeiBhcmUgcGFyYWxsZWxcbiAgICAgICAgaWYgKHVweikge1xuICAgICAgICAgICAgdXB4ICs9IDFlLTY7XG4gICAgICAgIH0gZWxzZSBpZiAodXB5KSB7XG4gICAgICAgICAgICB1cHogKz0gMWUtNjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHVweSArPSAxZS02O1xuICAgICAgICB9XG4gICAgICAgICh4MCA9IHVweSAqIHoyIC0gdXB6ICogejEpLCAoeDEgPSB1cHogKiB6MCAtIHVweCAqIHoyKSwgKHgyID0gdXB4ICogejEgLSB1cHkgKiB6MCk7XG5cbiAgICAgICAgbGVuID0geDAgKiB4MCArIHgxICogeDEgKyB4MiAqIHgyO1xuICAgIH1cblxuICAgIGxlbiA9IDEgLyBNYXRoLnNxcnQobGVuKTtcbiAgICB4MCAqPSBsZW47XG4gICAgeDEgKj0gbGVuO1xuICAgIHgyICo9IGxlbjtcblxuICAgIG91dFswXSA9IHgwO1xuICAgIG91dFsxXSA9IHgxO1xuICAgIG91dFsyXSA9IHgyO1xuICAgIG91dFszXSA9IDA7XG4gICAgb3V0WzRdID0gejEgKiB4MiAtIHoyICogeDE7XG4gICAgb3V0WzVdID0gejIgKiB4MCAtIHowICogeDI7XG4gICAgb3V0WzZdID0gejAgKiB4MSAtIHoxICogeDA7XG4gICAgb3V0WzddID0gMDtcbiAgICBvdXRbOF0gPSB6MDtcbiAgICBvdXRbOV0gPSB6MTtcbiAgICBvdXRbMTBdID0gejI7XG4gICAgb3V0WzExXSA9IDA7XG4gICAgb3V0WzEyXSA9IGV5ZXg7XG4gICAgb3V0WzEzXSA9IGV5ZXk7XG4gICAgb3V0WzE0XSA9IGV5ZXo7XG4gICAgb3V0WzE1XSA9IDE7XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBBZGRzIHR3byBtYXQ0J3NcbiAqXG4gKiBAcGFyYW0ge21hdDR9IG91dCB0aGUgcmVjZWl2aW5nIG1hdHJpeFxuICogQHBhcmFtIHttYXQ0fSBhIHRoZSBmaXJzdCBvcGVyYW5kXG4gKiBAcGFyYW0ge21hdDR9IGIgdGhlIHNlY29uZCBvcGVyYW5kXG4gKiBAcmV0dXJucyB7bWF0NH0gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhZGQob3V0LCBhLCBiKSB7XG4gICAgb3V0WzBdID0gYVswXSArIGJbMF07XG4gICAgb3V0WzFdID0gYVsxXSArIGJbMV07XG4gICAgb3V0WzJdID0gYVsyXSArIGJbMl07XG4gICAgb3V0WzNdID0gYVszXSArIGJbM107XG4gICAgb3V0WzRdID0gYVs0XSArIGJbNF07XG4gICAgb3V0WzVdID0gYVs1XSArIGJbNV07XG4gICAgb3V0WzZdID0gYVs2XSArIGJbNl07XG4gICAgb3V0WzddID0gYVs3XSArIGJbN107XG4gICAgb3V0WzhdID0gYVs4XSArIGJbOF07XG4gICAgb3V0WzldID0gYVs5XSArIGJbOV07XG4gICAgb3V0WzEwXSA9IGFbMTBdICsgYlsxMF07XG4gICAgb3V0WzExXSA9IGFbMTFdICsgYlsxMV07XG4gICAgb3V0WzEyXSA9IGFbMTJdICsgYlsxMl07XG4gICAgb3V0WzEzXSA9IGFbMTNdICsgYlsxM107XG4gICAgb3V0WzE0XSA9IGFbMTRdICsgYlsxNF07XG4gICAgb3V0WzE1XSA9IGFbMTVdICsgYlsxNV07XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBTdWJ0cmFjdHMgbWF0cml4IGIgZnJvbSBtYXRyaXggYVxuICpcbiAqIEBwYXJhbSB7bWF0NH0gb3V0IHRoZSByZWNlaXZpbmcgbWF0cml4XG4gKiBAcGFyYW0ge21hdDR9IGEgdGhlIGZpcnN0IG9wZXJhbmRcbiAqIEBwYXJhbSB7bWF0NH0gYiB0aGUgc2Vjb25kIG9wZXJhbmRcbiAqIEByZXR1cm5zIHttYXQ0fSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHN1YnRyYWN0KG91dCwgYSwgYikge1xuICAgIG91dFswXSA9IGFbMF0gLSBiWzBdO1xuICAgIG91dFsxXSA9IGFbMV0gLSBiWzFdO1xuICAgIG91dFsyXSA9IGFbMl0gLSBiWzJdO1xuICAgIG91dFszXSA9IGFbM10gLSBiWzNdO1xuICAgIG91dFs0XSA9IGFbNF0gLSBiWzRdO1xuICAgIG91dFs1XSA9IGFbNV0gLSBiWzVdO1xuICAgIG91dFs2XSA9IGFbNl0gLSBiWzZdO1xuICAgIG91dFs3XSA9IGFbN10gLSBiWzddO1xuICAgIG91dFs4XSA9IGFbOF0gLSBiWzhdO1xuICAgIG91dFs5XSA9IGFbOV0gLSBiWzldO1xuICAgIG91dFsxMF0gPSBhWzEwXSAtIGJbMTBdO1xuICAgIG91dFsxMV0gPSBhWzExXSAtIGJbMTFdO1xuICAgIG91dFsxMl0gPSBhWzEyXSAtIGJbMTJdO1xuICAgIG91dFsxM10gPSBhWzEzXSAtIGJbMTNdO1xuICAgIG91dFsxNF0gPSBhWzE0XSAtIGJbMTRdO1xuICAgIG91dFsxNV0gPSBhWzE1XSAtIGJbMTVdO1xuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogTXVsdGlwbHkgZWFjaCBlbGVtZW50IG9mIHRoZSBtYXRyaXggYnkgYSBzY2FsYXIuXG4gKlxuICogQHBhcmFtIHttYXQ0fSBvdXQgdGhlIHJlY2VpdmluZyBtYXRyaXhcbiAqIEBwYXJhbSB7bWF0NH0gYSB0aGUgbWF0cml4IHRvIHNjYWxlXG4gKiBAcGFyYW0ge051bWJlcn0gYiBhbW91bnQgdG8gc2NhbGUgdGhlIG1hdHJpeCdzIGVsZW1lbnRzIGJ5XG4gKiBAcmV0dXJucyB7bWF0NH0gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtdWx0aXBseVNjYWxhcihvdXQsIGEsIGIpIHtcbiAgICBvdXRbMF0gPSBhWzBdICogYjtcbiAgICBvdXRbMV0gPSBhWzFdICogYjtcbiAgICBvdXRbMl0gPSBhWzJdICogYjtcbiAgICBvdXRbM10gPSBhWzNdICogYjtcbiAgICBvdXRbNF0gPSBhWzRdICogYjtcbiAgICBvdXRbNV0gPSBhWzVdICogYjtcbiAgICBvdXRbNl0gPSBhWzZdICogYjtcbiAgICBvdXRbN10gPSBhWzddICogYjtcbiAgICBvdXRbOF0gPSBhWzhdICogYjtcbiAgICBvdXRbOV0gPSBhWzldICogYjtcbiAgICBvdXRbMTBdID0gYVsxMF0gKiBiO1xuICAgIG91dFsxMV0gPSBhWzExXSAqIGI7XG4gICAgb3V0WzEyXSA9IGFbMTJdICogYjtcbiAgICBvdXRbMTNdID0gYVsxM10gKiBiO1xuICAgIG91dFsxNF0gPSBhWzE0XSAqIGI7XG4gICAgb3V0WzE1XSA9IGFbMTVdICogYjtcbiAgICByZXR1cm4gb3V0O1xufVxuIiwiaW1wb3J0ICogYXMgTWF0NEZ1bmMgZnJvbSAnLi9mdW5jdGlvbnMvTWF0NEZ1bmMuanMnO1xuXG5leHBvcnQgY2xhc3MgTWF0NCBleHRlbmRzIEFycmF5IHtcbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgbTAwID0gMSxcbiAgICAgICAgbTAxID0gMCxcbiAgICAgICAgbTAyID0gMCxcbiAgICAgICAgbTAzID0gMCxcbiAgICAgICAgbTEwID0gMCxcbiAgICAgICAgbTExID0gMSxcbiAgICAgICAgbTEyID0gMCxcbiAgICAgICAgbTEzID0gMCxcbiAgICAgICAgbTIwID0gMCxcbiAgICAgICAgbTIxID0gMCxcbiAgICAgICAgbTIyID0gMSxcbiAgICAgICAgbTIzID0gMCxcbiAgICAgICAgbTMwID0gMCxcbiAgICAgICAgbTMxID0gMCxcbiAgICAgICAgbTMyID0gMCxcbiAgICAgICAgbTMzID0gMVxuICAgICkge1xuICAgICAgICBzdXBlcihtMDAsIG0wMSwgbTAyLCBtMDMsIG0xMCwgbTExLCBtMTIsIG0xMywgbTIwLCBtMjEsIG0yMiwgbTIzLCBtMzAsIG0zMSwgbTMyLCBtMzMpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBnZXQgeCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXNbMTJdO1xuICAgIH1cblxuICAgIGdldCB5KCkge1xuICAgICAgICByZXR1cm4gdGhpc1sxM107XG4gICAgfVxuXG4gICAgZ2V0IHooKSB7XG4gICAgICAgIHJldHVybiB0aGlzWzE0XTtcbiAgICB9XG5cbiAgICBnZXQgdygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXNbMTVdO1xuICAgIH1cblxuICAgIHNldCB4KHYpIHtcbiAgICAgICAgdGhpc1sxMl0gPSB2O1xuICAgIH1cblxuICAgIHNldCB5KHYpIHtcbiAgICAgICAgdGhpc1sxM10gPSB2O1xuICAgIH1cblxuICAgIHNldCB6KHYpIHtcbiAgICAgICAgdGhpc1sxNF0gPSB2O1xuICAgIH1cblxuICAgIHNldCB3KHYpIHtcbiAgICAgICAgdGhpc1sxNV0gPSB2O1xuICAgIH1cblxuICAgIHNldChtMDAsIG0wMSwgbTAyLCBtMDMsIG0xMCwgbTExLCBtMTIsIG0xMywgbTIwLCBtMjEsIG0yMiwgbTIzLCBtMzAsIG0zMSwgbTMyLCBtMzMpIHtcbiAgICAgICAgaWYgKG0wMC5sZW5ndGgpIHJldHVybiB0aGlzLmNvcHkobTAwKTtcbiAgICAgICAgTWF0NEZ1bmMuc2V0KHRoaXMsIG0wMCwgbTAxLCBtMDIsIG0wMywgbTEwLCBtMTEsIG0xMiwgbTEzLCBtMjAsIG0yMSwgbTIyLCBtMjMsIG0zMCwgbTMxLCBtMzIsIG0zMyk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIHRyYW5zbGF0ZSh2LCBtID0gdGhpcykge1xuICAgICAgICBNYXQ0RnVuYy50cmFuc2xhdGUodGhpcywgbSwgdik7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIHJvdGF0ZSh2LCBheGlzLCBtID0gdGhpcykge1xuICAgICAgICBNYXQ0RnVuYy5yb3RhdGUodGhpcywgbSwgdiwgYXhpcyk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIHNjYWxlKHYsIG0gPSB0aGlzKSB7XG4gICAgICAgIE1hdDRGdW5jLnNjYWxlKHRoaXMsIG0sIHR5cGVvZiB2ID09PSAnbnVtYmVyJyA/IFt2LCB2LCB2XSA6IHYpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBhZGQobWEsIG1iKSB7XG4gICAgICAgIGlmIChtYikgTWF0NEZ1bmMuYWRkKHRoaXMsIG1hLCBtYik7XG4gICAgICAgIGVsc2UgTWF0NEZ1bmMuYWRkKHRoaXMsIHRoaXMsIG1hKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgc3ViKG1hLCBtYikge1xuICAgICAgICBpZiAobWIpIE1hdDRGdW5jLnN1YnRyYWN0KHRoaXMsIG1hLCBtYik7XG4gICAgICAgIGVsc2UgTWF0NEZ1bmMuc3VidHJhY3QodGhpcywgdGhpcywgbWEpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBtdWx0aXBseShtYSwgbWIpIHtcbiAgICAgICAgaWYgKCFtYS5sZW5ndGgpIHtcbiAgICAgICAgICAgIE1hdDRGdW5jLm11bHRpcGx5U2NhbGFyKHRoaXMsIHRoaXMsIG1hKTtcbiAgICAgICAgfSBlbHNlIGlmIChtYikge1xuICAgICAgICAgICAgTWF0NEZ1bmMubXVsdGlwbHkodGhpcywgbWEsIG1iKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIE1hdDRGdW5jLm11bHRpcGx5KHRoaXMsIHRoaXMsIG1hKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBpZGVudGl0eSgpIHtcbiAgICAgICAgTWF0NEZ1bmMuaWRlbnRpdHkodGhpcyk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGNvcHkobSkge1xuICAgICAgICBNYXQ0RnVuYy5jb3B5KHRoaXMsIG0pO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBmcm9tUGVyc3BlY3RpdmUoeyBmb3YsIGFzcGVjdCwgbmVhciwgZmFyIH0gPSB7fSkge1xuICAgICAgICBNYXQ0RnVuYy5wZXJzcGVjdGl2ZSh0aGlzLCBmb3YsIGFzcGVjdCwgbmVhciwgZmFyKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgZnJvbU9ydGhvZ29uYWwoeyBsZWZ0LCByaWdodCwgYm90dG9tLCB0b3AsIG5lYXIsIGZhciB9KSB7XG4gICAgICAgIE1hdDRGdW5jLm9ydGhvKHRoaXMsIGxlZnQsIHJpZ2h0LCBib3R0b20sIHRvcCwgbmVhciwgZmFyKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgZnJvbVF1YXRlcm5pb24ocSkge1xuICAgICAgICBNYXQ0RnVuYy5mcm9tUXVhdCh0aGlzLCBxKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgc2V0UG9zaXRpb24odikge1xuICAgICAgICB0aGlzLnggPSB2WzBdO1xuICAgICAgICB0aGlzLnkgPSB2WzFdO1xuICAgICAgICB0aGlzLnogPSB2WzJdO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBpbnZlcnNlKG0gPSB0aGlzKSB7XG4gICAgICAgIE1hdDRGdW5jLmludmVydCh0aGlzLCBtKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgY29tcG9zZShxLCBwb3MsIHNjYWxlKSB7XG4gICAgICAgIE1hdDRGdW5jLmNvbXBvc2UodGhpcywgcSwgcG9zLCBzY2FsZSk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGRlY29tcG9zZShxLCBwb3MsIHNjYWxlKSB7XG4gICAgICAgIE1hdDRGdW5jLmRlY29tcG9zZSh0aGlzLCBxLCBwb3MsIHNjYWxlKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgZ2V0Um90YXRpb24ocSkge1xuICAgICAgICBNYXQ0RnVuYy5nZXRSb3RhdGlvbihxLCB0aGlzKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgZ2V0VHJhbnNsYXRpb24ocG9zKSB7XG4gICAgICAgIE1hdDRGdW5jLmdldFRyYW5zbGF0aW9uKHBvcywgdGhpcyk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGdldFNjYWxpbmcoc2NhbGUpIHtcbiAgICAgICAgTWF0NEZ1bmMuZ2V0U2NhbGluZyhzY2FsZSwgdGhpcyk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGdldE1heFNjYWxlT25BeGlzKCkge1xuICAgICAgICByZXR1cm4gTWF0NEZ1bmMuZ2V0TWF4U2NhbGVPbkF4aXModGhpcyk7XG4gICAgfVxuXG4gICAgbG9va0F0KGV5ZSwgdGFyZ2V0LCB1cCkge1xuICAgICAgICBNYXQ0RnVuYy50YXJnZXRUbyh0aGlzLCBleWUsIHRhcmdldCwgdXApO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBkZXRlcm1pbmFudCgpIHtcbiAgICAgICAgcmV0dXJuIE1hdDRGdW5jLmRldGVybWluYW50KHRoaXMpO1xuICAgIH1cblxuICAgIGZyb21BcnJheShhLCBvID0gMCkge1xuICAgICAgICB0aGlzWzBdID0gYVtvXTtcbiAgICAgICAgdGhpc1sxXSA9IGFbbyArIDFdO1xuICAgICAgICB0aGlzWzJdID0gYVtvICsgMl07XG4gICAgICAgIHRoaXNbM10gPSBhW28gKyAzXTtcbiAgICAgICAgdGhpc1s0XSA9IGFbbyArIDRdO1xuICAgICAgICB0aGlzWzVdID0gYVtvICsgNV07XG4gICAgICAgIHRoaXNbNl0gPSBhW28gKyA2XTtcbiAgICAgICAgdGhpc1s3XSA9IGFbbyArIDddO1xuICAgICAgICB0aGlzWzhdID0gYVtvICsgOF07XG4gICAgICAgIHRoaXNbOV0gPSBhW28gKyA5XTtcbiAgICAgICAgdGhpc1sxMF0gPSBhW28gKyAxMF07XG4gICAgICAgIHRoaXNbMTFdID0gYVtvICsgMTFdO1xuICAgICAgICB0aGlzWzEyXSA9IGFbbyArIDEyXTtcbiAgICAgICAgdGhpc1sxM10gPSBhW28gKyAxM107XG4gICAgICAgIHRoaXNbMTRdID0gYVtvICsgMTRdO1xuICAgICAgICB0aGlzWzE1XSA9IGFbbyArIDE1XTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgdG9BcnJheShhID0gW10sIG8gPSAwKSB7XG4gICAgICAgIGFbb10gPSB0aGlzWzBdO1xuICAgICAgICBhW28gKyAxXSA9IHRoaXNbMV07XG4gICAgICAgIGFbbyArIDJdID0gdGhpc1syXTtcbiAgICAgICAgYVtvICsgM10gPSB0aGlzWzNdO1xuICAgICAgICBhW28gKyA0XSA9IHRoaXNbNF07XG4gICAgICAgIGFbbyArIDVdID0gdGhpc1s1XTtcbiAgICAgICAgYVtvICsgNl0gPSB0aGlzWzZdO1xuICAgICAgICBhW28gKyA3XSA9IHRoaXNbN107XG4gICAgICAgIGFbbyArIDhdID0gdGhpc1s4XTtcbiAgICAgICAgYVtvICsgOV0gPSB0aGlzWzldO1xuICAgICAgICBhW28gKyAxMF0gPSB0aGlzWzEwXTtcbiAgICAgICAgYVtvICsgMTFdID0gdGhpc1sxMV07XG4gICAgICAgIGFbbyArIDEyXSA9IHRoaXNbMTJdO1xuICAgICAgICBhW28gKyAxM10gPSB0aGlzWzEzXTtcbiAgICAgICAgYVtvICsgMTRdID0gdGhpc1sxNF07XG4gICAgICAgIGFbbyArIDE1XSA9IHRoaXNbMTVdO1xuICAgICAgICByZXR1cm4gYTtcbiAgICB9XG59XG4iLCIvLyBhc3N1bWVzIHRoZSB1cHBlciAzeDMgb2YgbSBpcyBhIHB1cmUgcm90YXRpb24gbWF0cml4IChpLmUsIHVuc2NhbGVkKVxuZXhwb3J0IGZ1bmN0aW9uIGZyb21Sb3RhdGlvbk1hdHJpeChvdXQsIG0sIG9yZGVyID0gJ1lYWicpIHtcbiAgICBpZiAob3JkZXIgPT09ICdYWVonKSB7XG4gICAgICAgIG91dFsxXSA9IE1hdGguYXNpbihNYXRoLm1pbihNYXRoLm1heChtWzhdLCAtMSksIDEpKTtcbiAgICAgICAgaWYgKE1hdGguYWJzKG1bOF0pIDwgMC45OTk5OSkge1xuICAgICAgICAgICAgb3V0WzBdID0gTWF0aC5hdGFuMigtbVs5XSwgbVsxMF0pO1xuICAgICAgICAgICAgb3V0WzJdID0gTWF0aC5hdGFuMigtbVs0XSwgbVswXSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBvdXRbMF0gPSBNYXRoLmF0YW4yKG1bNl0sIG1bNV0pO1xuICAgICAgICAgICAgb3V0WzJdID0gMDtcbiAgICAgICAgfVxuICAgIH0gZWxzZSBpZiAob3JkZXIgPT09ICdZWFonKSB7XG4gICAgICAgIG91dFswXSA9IE1hdGguYXNpbigtTWF0aC5taW4oTWF0aC5tYXgobVs5XSwgLTEpLCAxKSk7XG4gICAgICAgIGlmIChNYXRoLmFicyhtWzldKSA8IDAuOTk5OTkpIHtcbiAgICAgICAgICAgIG91dFsxXSA9IE1hdGguYXRhbjIobVs4XSwgbVsxMF0pO1xuICAgICAgICAgICAgb3V0WzJdID0gTWF0aC5hdGFuMihtWzFdLCBtWzVdKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG91dFsxXSA9IE1hdGguYXRhbjIoLW1bMl0sIG1bMF0pO1xuICAgICAgICAgICAgb3V0WzJdID0gMDtcbiAgICAgICAgfVxuICAgIH0gZWxzZSBpZiAob3JkZXIgPT09ICdaWFknKSB7XG4gICAgICAgIG91dFswXSA9IE1hdGguYXNpbihNYXRoLm1pbihNYXRoLm1heChtWzZdLCAtMSksIDEpKTtcbiAgICAgICAgaWYgKE1hdGguYWJzKG1bNl0pIDwgMC45OTk5OSkge1xuICAgICAgICAgICAgb3V0WzFdID0gTWF0aC5hdGFuMigtbVsyXSwgbVsxMF0pO1xuICAgICAgICAgICAgb3V0WzJdID0gTWF0aC5hdGFuMigtbVs0XSwgbVs1XSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBvdXRbMV0gPSAwO1xuICAgICAgICAgICAgb3V0WzJdID0gTWF0aC5hdGFuMihtWzFdLCBtWzBdKTtcbiAgICAgICAgfVxuICAgIH0gZWxzZSBpZiAob3JkZXIgPT09ICdaWVgnKSB7XG4gICAgICAgIG91dFsxXSA9IE1hdGguYXNpbigtTWF0aC5taW4oTWF0aC5tYXgobVsyXSwgLTEpLCAxKSk7XG4gICAgICAgIGlmIChNYXRoLmFicyhtWzJdKSA8IDAuOTk5OTkpIHtcbiAgICAgICAgICAgIG91dFswXSA9IE1hdGguYXRhbjIobVs2XSwgbVsxMF0pO1xuICAgICAgICAgICAgb3V0WzJdID0gTWF0aC5hdGFuMihtWzFdLCBtWzBdKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG91dFswXSA9IDA7XG4gICAgICAgICAgICBvdXRbMl0gPSBNYXRoLmF0YW4yKC1tWzRdLCBtWzVdKTtcbiAgICAgICAgfVxuICAgIH0gZWxzZSBpZiAob3JkZXIgPT09ICdZWlgnKSB7XG4gICAgICAgIG91dFsyXSA9IE1hdGguYXNpbihNYXRoLm1pbihNYXRoLm1heChtWzFdLCAtMSksIDEpKTtcbiAgICAgICAgaWYgKE1hdGguYWJzKG1bMV0pIDwgMC45OTk5OSkge1xuICAgICAgICAgICAgb3V0WzBdID0gTWF0aC5hdGFuMigtbVs5XSwgbVs1XSk7XG4gICAgICAgICAgICBvdXRbMV0gPSBNYXRoLmF0YW4yKC1tWzJdLCBtWzBdKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG91dFswXSA9IDA7XG4gICAgICAgICAgICBvdXRbMV0gPSBNYXRoLmF0YW4yKG1bOF0sIG1bMTBdKTtcbiAgICAgICAgfVxuICAgIH0gZWxzZSBpZiAob3JkZXIgPT09ICdYWlknKSB7XG4gICAgICAgIG91dFsyXSA9IE1hdGguYXNpbigtTWF0aC5taW4oTWF0aC5tYXgobVs0XSwgLTEpLCAxKSk7XG4gICAgICAgIGlmIChNYXRoLmFicyhtWzRdKSA8IDAuOTk5OTkpIHtcbiAgICAgICAgICAgIG91dFswXSA9IE1hdGguYXRhbjIobVs2XSwgbVs1XSk7XG4gICAgICAgICAgICBvdXRbMV0gPSBNYXRoLmF0YW4yKG1bOF0sIG1bMF0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgb3V0WzBdID0gTWF0aC5hdGFuMigtbVs5XSwgbVsxMF0pO1xuICAgICAgICAgICAgb3V0WzFdID0gMDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBvdXQ7XG59XG4iLCJpbXBvcnQgKiBhcyBFdWxlckZ1bmMgZnJvbSAnLi9mdW5jdGlvbnMvRXVsZXJGdW5jLmpzJztcbmltcG9ydCB7IE1hdDQgfSBmcm9tICcuL01hdDQuanMnO1xuXG5jb25zdCB0bXBNYXQ0ID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXQ0KCk7XG5cbmV4cG9ydCBjbGFzcyBFdWxlciBleHRlbmRzIEFycmF5IHtcbiAgICBjb25zdHJ1Y3Rvcih4ID0gMCwgeSA9IHgsIHogPSB4LCBvcmRlciA9ICdZWFonKSB7XG4gICAgICAgIHN1cGVyKHgsIHksIHopO1xuICAgICAgICB0aGlzLm9yZGVyID0gb3JkZXI7XG4gICAgICAgIHRoaXMub25DaGFuZ2UgPSAoKSA9PiB7fTtcblxuICAgICAgICAvLyBLZWVwIHJlZmVyZW5jZSB0byBwcm94eSB0YXJnZXQgdG8gYXZvaWQgdHJpZ2dlcmluZyBvbkNoYW5nZSBpbnRlcm5hbGx5XG4gICAgICAgIHRoaXMuX3RhcmdldCA9IHRoaXM7XG5cbiAgICAgICAgLy8gUmV0dXJuIGEgcHJveHkgdG8gdHJpZ2dlciBvbkNoYW5nZSB3aGVuIGFycmF5IGVsZW1lbnRzIGFyZSBlZGl0ZWQgZGlyZWN0bHlcbiAgICAgICAgY29uc3QgdHJpZ2dlclByb3BzID0gWycwJywgJzEnLCAnMiddO1xuICAgICAgICByZXR1cm4gbmV3IFByb3h5KHRoaXMsIHtcbiAgICAgICAgICAgIHNldCh0YXJnZXQsIHByb3BlcnR5KSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgc3VjY2VzcyA9IFJlZmxlY3Quc2V0KC4uLmFyZ3VtZW50cyk7XG4gICAgICAgICAgICAgICAgaWYgKHN1Y2Nlc3MgJiYgdHJpZ2dlclByb3BzLmluY2x1ZGVzKHByb3BlcnR5KSkgdGFyZ2V0Lm9uQ2hhbmdlKCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHN1Y2Nlc3M7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBnZXQgeCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXNbMF07XG4gICAgfVxuXG4gICAgZ2V0IHkoKSB7XG4gICAgICAgIHJldHVybiB0aGlzWzFdO1xuICAgIH1cblxuICAgIGdldCB6KCkge1xuICAgICAgICByZXR1cm4gdGhpc1syXTtcbiAgICB9XG5cbiAgICBzZXQgeCh2KSB7XG4gICAgICAgIHRoaXMuX3RhcmdldFswXSA9IHY7XG4gICAgICAgIHRoaXMub25DaGFuZ2UoKTtcbiAgICB9XG5cbiAgICBzZXQgeSh2KSB7XG4gICAgICAgIHRoaXMuX3RhcmdldFsxXSA9IHY7XG4gICAgICAgIHRoaXMub25DaGFuZ2UoKTtcbiAgICB9XG5cbiAgICBzZXQgeih2KSB7XG4gICAgICAgIHRoaXMuX3RhcmdldFsyXSA9IHY7XG4gICAgICAgIHRoaXMub25DaGFuZ2UoKTtcbiAgICB9XG5cbiAgICBzZXQoeCwgeSA9IHgsIHogPSB4KSB7XG4gICAgICAgIGlmICh4Lmxlbmd0aCkgcmV0dXJuIHRoaXMuY29weSh4KTtcbiAgICAgICAgdGhpcy5fdGFyZ2V0WzBdID0geDtcbiAgICAgICAgdGhpcy5fdGFyZ2V0WzFdID0geTtcbiAgICAgICAgdGhpcy5fdGFyZ2V0WzJdID0gejtcbiAgICAgICAgdGhpcy5vbkNoYW5nZSgpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBjb3B5KHYpIHtcbiAgICAgICAgdGhpcy5fdGFyZ2V0WzBdID0gdlswXTtcbiAgICAgICAgdGhpcy5fdGFyZ2V0WzFdID0gdlsxXTtcbiAgICAgICAgdGhpcy5fdGFyZ2V0WzJdID0gdlsyXTtcbiAgICAgICAgdGhpcy5vbkNoYW5nZSgpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICByZW9yZGVyKG9yZGVyKSB7XG4gICAgICAgIHRoaXMuX3RhcmdldC5vcmRlciA9IG9yZGVyO1xuICAgICAgICB0aGlzLm9uQ2hhbmdlKCk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGZyb21Sb3RhdGlvbk1hdHJpeChtLCBvcmRlciA9IHRoaXMub3JkZXIpIHtcbiAgICAgICAgRXVsZXJGdW5jLmZyb21Sb3RhdGlvbk1hdHJpeCh0aGlzLl90YXJnZXQsIG0sIG9yZGVyKTtcbiAgICAgICAgdGhpcy5vbkNoYW5nZSgpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBmcm9tUXVhdGVybmlvbihxLCBvcmRlciA9IHRoaXMub3JkZXIsIGlzSW50ZXJuYWwpIHtcbiAgICAgICAgdG1wTWF0NC5mcm9tUXVhdGVybmlvbihxKTtcbiAgICAgICAgdGhpcy5fdGFyZ2V0LmZyb21Sb3RhdGlvbk1hdHJpeCh0bXBNYXQ0LCBvcmRlcik7XG4gICAgICAgIC8vIEF2b2lkIGluZmluaXRlIHJlY3Vyc2lvblxuICAgICAgICBpZiAoIWlzSW50ZXJuYWwpIHRoaXMub25DaGFuZ2UoKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgZnJvbUFycmF5KGEsIG8gPSAwKSB7XG4gICAgICAgIHRoaXMuX3RhcmdldFswXSA9IGFbb107XG4gICAgICAgIHRoaXMuX3RhcmdldFsxXSA9IGFbbyArIDFdO1xuICAgICAgICB0aGlzLl90YXJnZXRbMl0gPSBhW28gKyAyXTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgdG9BcnJheShhID0gW10sIG8gPSAwKSB7XG4gICAgICAgIGFbb10gPSB0aGlzWzBdO1xuICAgICAgICBhW28gKyAxXSA9IHRoaXNbMV07XG4gICAgICAgIGFbbyArIDJdID0gdGhpc1syXTtcbiAgICAgICAgcmV0dXJuIGE7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgVmVjMyB9IGZyb20gJy4uL21hdGgvVmVjMy5qcyc7XG5pbXBvcnQgeyBRdWF0IH0gZnJvbSAnLi4vbWF0aC9RdWF0LmpzJztcbmltcG9ydCB7IE1hdDQgfSBmcm9tICcuLi9tYXRoL01hdDQuanMnO1xuaW1wb3J0IHsgRXVsZXIgfSBmcm9tICcuLi9tYXRoL0V1bGVyLmpzJztcblxuZXhwb3J0IGNsYXNzIFRyYW5zZm9ybSB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHRoaXMucGFyZW50ID0gbnVsbDtcbiAgICAgICAgdGhpcy5jaGlsZHJlbiA9IFtdO1xuICAgICAgICB0aGlzLnZpc2libGUgPSB0cnVlO1xuXG4gICAgICAgIHRoaXMubWF0cml4ID0gbmV3IE1hdDQoKTtcbiAgICAgICAgdGhpcy53b3JsZE1hdHJpeCA9IG5ldyBNYXQ0KCk7XG4gICAgICAgIHRoaXMubWF0cml4QXV0b1VwZGF0ZSA9IHRydWU7XG4gICAgICAgIHRoaXMud29ybGRNYXRyaXhOZWVkc1VwZGF0ZSA9IGZhbHNlO1xuXG4gICAgICAgIHRoaXMucG9zaXRpb24gPSBuZXcgVmVjMygpO1xuICAgICAgICB0aGlzLnF1YXRlcm5pb24gPSBuZXcgUXVhdCgpO1xuICAgICAgICB0aGlzLnNjYWxlID0gbmV3IFZlYzMoMSk7XG4gICAgICAgIHRoaXMucm90YXRpb24gPSBuZXcgRXVsZXIoKTtcbiAgICAgICAgdGhpcy51cCA9IG5ldyBWZWMzKDAsIDEsIDApO1xuXG4gICAgICAgIHRoaXMucm90YXRpb24uX3RhcmdldC5vbkNoYW5nZSA9ICgpID0+IHRoaXMucXVhdGVybmlvbi5mcm9tRXVsZXIodGhpcy5yb3RhdGlvbiwgdHJ1ZSk7XG4gICAgICAgIHRoaXMucXVhdGVybmlvbi5fdGFyZ2V0Lm9uQ2hhbmdlID0gKCkgPT4gdGhpcy5yb3RhdGlvbi5mcm9tUXVhdGVybmlvbih0aGlzLnF1YXRlcm5pb24sIHVuZGVmaW5lZCwgdHJ1ZSk7XG4gICAgfVxuXG4gICAgc2V0UGFyZW50KHBhcmVudCwgbm90aWZ5UGFyZW50ID0gdHJ1ZSkge1xuICAgICAgICBpZiAodGhpcy5wYXJlbnQgJiYgcGFyZW50ICE9PSB0aGlzLnBhcmVudCkgdGhpcy5wYXJlbnQucmVtb3ZlQ2hpbGQodGhpcywgZmFsc2UpO1xuICAgICAgICB0aGlzLnBhcmVudCA9IHBhcmVudDtcbiAgICAgICAgaWYgKG5vdGlmeVBhcmVudCAmJiBwYXJlbnQpIHBhcmVudC5hZGRDaGlsZCh0aGlzLCBmYWxzZSk7XG4gICAgfVxuXG4gICAgYWRkQ2hpbGQoY2hpbGQsIG5vdGlmeUNoaWxkID0gdHJ1ZSkge1xuICAgICAgICBpZiAoIX50aGlzLmNoaWxkcmVuLmluZGV4T2YoY2hpbGQpKSB0aGlzLmNoaWxkcmVuLnB1c2goY2hpbGQpO1xuICAgICAgICBpZiAobm90aWZ5Q2hpbGQpIGNoaWxkLnNldFBhcmVudCh0aGlzLCBmYWxzZSk7XG4gICAgfVxuXG4gICAgcmVtb3ZlQ2hpbGQoY2hpbGQsIG5vdGlmeUNoaWxkID0gdHJ1ZSkge1xuICAgICAgICBpZiAoISF+dGhpcy5jaGlsZHJlbi5pbmRleE9mKGNoaWxkKSkgdGhpcy5jaGlsZHJlbi5zcGxpY2UodGhpcy5jaGlsZHJlbi5pbmRleE9mKGNoaWxkKSwgMSk7XG4gICAgICAgIGlmIChub3RpZnlDaGlsZCkgY2hpbGQuc2V0UGFyZW50KG51bGwsIGZhbHNlKTtcbiAgICB9XG5cbiAgICB1cGRhdGVNYXRyaXhXb3JsZChmb3JjZSkge1xuICAgICAgICBpZiAodGhpcy5tYXRyaXhBdXRvVXBkYXRlKSB0aGlzLnVwZGF0ZU1hdHJpeCgpO1xuICAgICAgICBpZiAodGhpcy53b3JsZE1hdHJpeE5lZWRzVXBkYXRlIHx8IGZvcmNlKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5wYXJlbnQgPT09IG51bGwpIHRoaXMud29ybGRNYXRyaXguY29weSh0aGlzLm1hdHJpeCk7XG4gICAgICAgICAgICBlbHNlIHRoaXMud29ybGRNYXRyaXgubXVsdGlwbHkodGhpcy5wYXJlbnQud29ybGRNYXRyaXgsIHRoaXMubWF0cml4KTtcbiAgICAgICAgICAgIHRoaXMud29ybGRNYXRyaXhOZWVkc1VwZGF0ZSA9IGZhbHNlO1xuICAgICAgICAgICAgZm9yY2UgPSB0cnVlO1xuICAgICAgICB9XG5cbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIGwgPSB0aGlzLmNoaWxkcmVuLmxlbmd0aDsgaSA8IGw7IGkrKykge1xuICAgICAgICAgICAgdGhpcy5jaGlsZHJlbltpXS51cGRhdGVNYXRyaXhXb3JsZChmb3JjZSk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICB1cGRhdGVNYXRyaXgoKSB7XG4gICAgICAgIHRoaXMubWF0cml4LmNvbXBvc2UodGhpcy5xdWF0ZXJuaW9uLCB0aGlzLnBvc2l0aW9uLCB0aGlzLnNjYWxlKTtcbiAgICAgICAgdGhpcy53b3JsZE1hdHJpeE5lZWRzVXBkYXRlID0gdHJ1ZTtcbiAgICB9XG5cbiAgICB0cmF2ZXJzZShjYWxsYmFjaykge1xuICAgICAgICAvLyBSZXR1cm4gdHJ1ZSBpbiBjYWxsYmFjayB0byBzdG9wIHRyYXZlcnNpbmcgY2hpbGRyZW5cbiAgICAgICAgaWYgKGNhbGxiYWNrKHRoaXMpKSByZXR1cm47XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBsID0gdGhpcy5jaGlsZHJlbi5sZW5ndGg7IGkgPCBsOyBpKyspIHtcbiAgICAgICAgICAgIHRoaXMuY2hpbGRyZW5baV0udHJhdmVyc2UoY2FsbGJhY2spO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgZGVjb21wb3NlKCkge1xuICAgICAgICB0aGlzLm1hdHJpeC5kZWNvbXBvc2UodGhpcy5xdWF0ZXJuaW9uLl90YXJnZXQsIHRoaXMucG9zaXRpb24sIHRoaXMuc2NhbGUpO1xuICAgICAgICB0aGlzLnJvdGF0aW9uLmZyb21RdWF0ZXJuaW9uKHRoaXMucXVhdGVybmlvbik7XG4gICAgfVxuXG4gICAgbG9va0F0KHRhcmdldCwgaW52ZXJ0ID0gZmFsc2UpIHtcbiAgICAgICAgaWYgKGludmVydCkgdGhpcy5tYXRyaXgubG9va0F0KHRoaXMucG9zaXRpb24sIHRhcmdldCwgdGhpcy51cCk7XG4gICAgICAgIGVsc2UgdGhpcy5tYXRyaXgubG9va0F0KHRhcmdldCwgdGhpcy5wb3NpdGlvbiwgdGhpcy51cCk7XG4gICAgICAgIHRoaXMubWF0cml4LmdldFJvdGF0aW9uKHRoaXMucXVhdGVybmlvbi5fdGFyZ2V0KTtcbiAgICAgICAgdGhpcy5yb3RhdGlvbi5mcm9tUXVhdGVybmlvbih0aGlzLnF1YXRlcm5pb24pO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IFRyYW5zZm9ybSB9IGZyb20gJy4vVHJhbnNmb3JtLmpzJztcbmltcG9ydCB7IE1hdDQgfSBmcm9tICcuLi9tYXRoL01hdDQuanMnO1xuaW1wb3J0IHsgVmVjMyB9IGZyb20gJy4uL21hdGgvVmVjMy5qcyc7XG5cbmNvbnN0IHRlbXBNYXQ0ID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXQ0KCk7XG5jb25zdCB0ZW1wVmVjM2EgPSAvKiBAX19QVVJFX18gKi8gbmV3IFZlYzMoKTtcbmNvbnN0IHRlbXBWZWMzYiA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgVmVjMygpO1xuXG5leHBvcnQgY2xhc3MgQ2FtZXJhIGV4dGVuZHMgVHJhbnNmb3JtIHtcbiAgICBjb25zdHJ1Y3RvcihnbCwgeyBuZWFyID0gMC4xLCBmYXIgPSAxMDAsIGZvdiA9IDQ1LCBhc3BlY3QgPSAxLCBsZWZ0LCByaWdodCwgYm90dG9tLCB0b3AsIHpvb20gPSAxIH0gPSB7fSkge1xuICAgICAgICBzdXBlcigpO1xuXG4gICAgICAgIE9iamVjdC5hc3NpZ24odGhpcywgeyBuZWFyLCBmYXIsIGZvdiwgYXNwZWN0LCBsZWZ0LCByaWdodCwgYm90dG9tLCB0b3AsIHpvb20gfSk7XG5cbiAgICAgICAgdGhpcy5wcm9qZWN0aW9uTWF0cml4ID0gbmV3IE1hdDQoKTtcbiAgICAgICAgdGhpcy52aWV3TWF0cml4ID0gbmV3IE1hdDQoKTtcbiAgICAgICAgdGhpcy5wcm9qZWN0aW9uVmlld01hdHJpeCA9IG5ldyBNYXQ0KCk7XG4gICAgICAgIHRoaXMud29ybGRQb3NpdGlvbiA9IG5ldyBWZWMzKCk7XG5cbiAgICAgICAgLy8gVXNlIG9ydGhvZ3JhcGhpYyBpZiBsZWZ0L3JpZ2h0IHNldCwgZWxzZSBkZWZhdWx0IHRvIHBlcnNwZWN0aXZlIGNhbWVyYVxuICAgICAgICB0aGlzLnR5cGUgPSBsZWZ0IHx8IHJpZ2h0ID8gJ29ydGhvZ3JhcGhpYycgOiAncGVyc3BlY3RpdmUnO1xuXG4gICAgICAgIGlmICh0aGlzLnR5cGUgPT09ICdvcnRob2dyYXBoaWMnKSB0aGlzLm9ydGhvZ3JhcGhpYygpO1xuICAgICAgICBlbHNlIHRoaXMucGVyc3BlY3RpdmUoKTtcbiAgICB9XG5cbiAgICBwZXJzcGVjdGl2ZSh7IG5lYXIgPSB0aGlzLm5lYXIsIGZhciA9IHRoaXMuZmFyLCBmb3YgPSB0aGlzLmZvdiwgYXNwZWN0ID0gdGhpcy5hc3BlY3QgfSA9IHt9KSB7XG4gICAgICAgIE9iamVjdC5hc3NpZ24odGhpcywgeyBuZWFyLCBmYXIsIGZvdiwgYXNwZWN0IH0pO1xuICAgICAgICB0aGlzLnByb2plY3Rpb25NYXRyaXguZnJvbVBlcnNwZWN0aXZlKHsgZm92OiBmb3YgKiAoTWF0aC5QSSAvIDE4MCksIGFzcGVjdCwgbmVhciwgZmFyIH0pO1xuICAgICAgICB0aGlzLnR5cGUgPSAncGVyc3BlY3RpdmUnO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBvcnRob2dyYXBoaWMoe1xuICAgICAgICBuZWFyID0gdGhpcy5uZWFyLFxuICAgICAgICBmYXIgPSB0aGlzLmZhcixcbiAgICAgICAgbGVmdCA9IHRoaXMubGVmdCB8fCAtMSxcbiAgICAgICAgcmlnaHQgPSB0aGlzLnJpZ2h0IHx8IDEsXG4gICAgICAgIGJvdHRvbSA9IHRoaXMuYm90dG9tIHx8IC0xLFxuICAgICAgICB0b3AgPSB0aGlzLnRvcCB8fCAxLFxuICAgICAgICB6b29tID0gdGhpcy56b29tLFxuICAgIH0gPSB7fSkge1xuICAgICAgICBPYmplY3QuYXNzaWduKHRoaXMsIHsgbmVhciwgZmFyLCBsZWZ0LCByaWdodCwgYm90dG9tLCB0b3AsIHpvb20gfSk7XG4gICAgICAgIGxlZnQgLz0gem9vbTtcbiAgICAgICAgcmlnaHQgLz0gem9vbTtcbiAgICAgICAgYm90dG9tIC89IHpvb207XG4gICAgICAgIHRvcCAvPSB6b29tO1xuICAgICAgICB0aGlzLnByb2plY3Rpb25NYXRyaXguZnJvbU9ydGhvZ29uYWwoeyBsZWZ0LCByaWdodCwgYm90dG9tLCB0b3AsIG5lYXIsIGZhciB9KTtcbiAgICAgICAgdGhpcy50eXBlID0gJ29ydGhvZ3JhcGhpYyc7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIHVwZGF0ZU1hdHJpeFdvcmxkKCkge1xuICAgICAgICBzdXBlci51cGRhdGVNYXRyaXhXb3JsZCgpO1xuICAgICAgICB0aGlzLnZpZXdNYXRyaXguaW52ZXJzZSh0aGlzLndvcmxkTWF0cml4KTtcbiAgICAgICAgdGhpcy53b3JsZE1hdHJpeC5nZXRUcmFuc2xhdGlvbih0aGlzLndvcmxkUG9zaXRpb24pO1xuXG4gICAgICAgIC8vIHVzZWQgZm9yIHNvcnRpbmdcbiAgICAgICAgdGhpcy5wcm9qZWN0aW9uVmlld01hdHJpeC5tdWx0aXBseSh0aGlzLnByb2plY3Rpb25NYXRyaXgsIHRoaXMudmlld01hdHJpeCk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIHVwZGF0ZVByb2plY3Rpb25NYXRyaXgoKSB7XG4gICAgICAgIGlmICh0aGlzLnR5cGUgPT09ICdwZXJzcGVjdGl2ZScpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnBlcnNwZWN0aXZlKCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5vcnRob2dyYXBoaWMoKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGxvb2tBdCh0YXJnZXQpIHtcbiAgICAgICAgc3VwZXIubG9va0F0KHRhcmdldCwgdHJ1ZSk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIC8vIFByb2plY3QgM0QgY29vcmRpbmF0ZSB0byAyRCBwb2ludFxuICAgIHByb2plY3Qodikge1xuICAgICAgICB2LmFwcGx5TWF0cml4NCh0aGlzLnZpZXdNYXRyaXgpO1xuICAgICAgICB2LmFwcGx5TWF0cml4NCh0aGlzLnByb2plY3Rpb25NYXRyaXgpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICAvLyBVbnByb2plY3QgMkQgcG9pbnQgdG8gM0QgY29vcmRpbmF0ZVxuICAgIHVucHJvamVjdCh2KSB7XG4gICAgICAgIHYuYXBwbHlNYXRyaXg0KHRlbXBNYXQ0LmludmVyc2UodGhpcy5wcm9qZWN0aW9uTWF0cml4KSk7XG4gICAgICAgIHYuYXBwbHlNYXRyaXg0KHRoaXMud29ybGRNYXRyaXgpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICB1cGRhdGVGcnVzdHVtKCkge1xuICAgICAgICBpZiAoIXRoaXMuZnJ1c3R1bSkge1xuICAgICAgICAgICAgdGhpcy5mcnVzdHVtID0gW25ldyBWZWMzKCksIG5ldyBWZWMzKCksIG5ldyBWZWMzKCksIG5ldyBWZWMzKCksIG5ldyBWZWMzKCksIG5ldyBWZWMzKCldO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgbSA9IHRoaXMucHJvamVjdGlvblZpZXdNYXRyaXg7XG4gICAgICAgIHRoaXMuZnJ1c3R1bVswXS5zZXQobVszXSAtIG1bMF0sIG1bN10gLSBtWzRdLCBtWzExXSAtIG1bOF0pLmNvbnN0YW50ID0gbVsxNV0gLSBtWzEyXTsgLy8gLXhcbiAgICAgICAgdGhpcy5mcnVzdHVtWzFdLnNldChtWzNdICsgbVswXSwgbVs3XSArIG1bNF0sIG1bMTFdICsgbVs4XSkuY29uc3RhbnQgPSBtWzE1XSArIG1bMTJdOyAvLyAreFxuICAgICAgICB0aGlzLmZydXN0dW1bMl0uc2V0KG1bM10gKyBtWzFdLCBtWzddICsgbVs1XSwgbVsxMV0gKyBtWzldKS5jb25zdGFudCA9IG1bMTVdICsgbVsxM107IC8vICt5XG4gICAgICAgIHRoaXMuZnJ1c3R1bVszXS5zZXQobVszXSAtIG1bMV0sIG1bN10gLSBtWzVdLCBtWzExXSAtIG1bOV0pLmNvbnN0YW50ID0gbVsxNV0gLSBtWzEzXTsgLy8gLXlcbiAgICAgICAgdGhpcy5mcnVzdHVtWzRdLnNldChtWzNdIC0gbVsyXSwgbVs3XSAtIG1bNl0sIG1bMTFdIC0gbVsxMF0pLmNvbnN0YW50ID0gbVsxNV0gLSBtWzE0XTsgLy8gK3ogKGZhcilcbiAgICAgICAgdGhpcy5mcnVzdHVtWzVdLnNldChtWzNdICsgbVsyXSwgbVs3XSArIG1bNl0sIG1bMTFdICsgbVsxMF0pLmNvbnN0YW50ID0gbVsxNV0gKyBtWzE0XTsgLy8gLXogKG5lYXIpXG5cbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCA2OyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGludkxlbiA9IDEuMCAvIHRoaXMuZnJ1c3R1bVtpXS5kaXN0YW5jZSgpO1xuICAgICAgICAgICAgdGhpcy5mcnVzdHVtW2ldLm11bHRpcGx5KGludkxlbik7XG4gICAgICAgICAgICB0aGlzLmZydXN0dW1baV0uY29uc3RhbnQgKj0gaW52TGVuO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgZnJ1c3R1bUludGVyc2VjdHNNZXNoKG5vZGUsIHdvcmxkTWF0cml4ID0gbm9kZS53b3JsZE1hdHJpeCkge1xuICAgICAgICAvLyBJZiBubyBwb3NpdGlvbiBhdHRyaWJ1dGUsIHRyZWF0IGFzIGZydXN0dW1DdWxsZWQgZmFsc2VcbiAgICAgICAgaWYgKCFub2RlLmdlb21ldHJ5LmF0dHJpYnV0ZXMucG9zaXRpb24pIHJldHVybiB0cnVlO1xuXG4gICAgICAgIGlmICghbm9kZS5nZW9tZXRyeS5ib3VuZHMgfHwgbm9kZS5nZW9tZXRyeS5ib3VuZHMucmFkaXVzID09PSBJbmZpbml0eSkgbm9kZS5nZW9tZXRyeS5jb21wdXRlQm91bmRpbmdTcGhlcmUoKTtcblxuICAgICAgICBpZiAoIW5vZGUuZ2VvbWV0cnkuYm91bmRzKSByZXR1cm4gdHJ1ZTtcblxuICAgICAgICBjb25zdCBjZW50ZXIgPSB0ZW1wVmVjM2E7XG4gICAgICAgIGNlbnRlci5jb3B5KG5vZGUuZ2VvbWV0cnkuYm91bmRzLmNlbnRlcik7XG4gICAgICAgIGNlbnRlci5hcHBseU1hdHJpeDQod29ybGRNYXRyaXgpO1xuXG4gICAgICAgIGNvbnN0IHJhZGl1cyA9IG5vZGUuZ2VvbWV0cnkuYm91bmRzLnJhZGl1cyAqIHdvcmxkTWF0cml4LmdldE1heFNjYWxlT25BeGlzKCk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMuZnJ1c3R1bUludGVyc2VjdHNTcGhlcmUoY2VudGVyLCByYWRpdXMpO1xuICAgIH1cblxuICAgIGZydXN0dW1JbnRlcnNlY3RzU3BoZXJlKGNlbnRlciwgcmFkaXVzKSB7XG4gICAgICAgIGNvbnN0IG5vcm1hbCA9IHRlbXBWZWMzYjtcblxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IDY7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgcGxhbmUgPSB0aGlzLmZydXN0dW1baV07XG4gICAgICAgICAgICBjb25zdCBkaXN0YW5jZSA9IG5vcm1hbC5jb3B5KHBsYW5lKS5kb3QoY2VudGVyKSArIHBsYW5lLmNvbnN0YW50O1xuICAgICAgICAgICAgaWYgKGRpc3RhbmNlIDwgLXJhZGl1cykgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbn1cbiIsImNvbnN0IEVQU0lMT04gPSAwLjAwMDAwMTtcblxuLyoqXG4gKiBDb3BpZXMgdGhlIHVwcGVyLWxlZnQgM3gzIHZhbHVlcyBpbnRvIHRoZSBnaXZlbiBtYXQzLlxuICpcbiAqIEBwYXJhbSB7bWF0M30gb3V0IHRoZSByZWNlaXZpbmcgM3gzIG1hdHJpeFxuICogQHBhcmFtIHttYXQ0fSBhICAgdGhlIHNvdXJjZSA0eDQgbWF0cml4XG4gKiBAcmV0dXJucyB7bWF0M30gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmcm9tTWF0NChvdXQsIGEpIHtcbiAgICBvdXRbMF0gPSBhWzBdO1xuICAgIG91dFsxXSA9IGFbMV07XG4gICAgb3V0WzJdID0gYVsyXTtcbiAgICBvdXRbM10gPSBhWzRdO1xuICAgIG91dFs0XSA9IGFbNV07XG4gICAgb3V0WzVdID0gYVs2XTtcbiAgICBvdXRbNl0gPSBhWzhdO1xuICAgIG91dFs3XSA9IGFbOV07XG4gICAgb3V0WzhdID0gYVsxMF07XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBDYWxjdWxhdGVzIGEgM3gzIG1hdHJpeCBmcm9tIHRoZSBnaXZlbiBxdWF0ZXJuaW9uXG4gKlxuICogQHBhcmFtIHttYXQzfSBvdXQgbWF0MyByZWNlaXZpbmcgb3BlcmF0aW9uIHJlc3VsdFxuICogQHBhcmFtIHtxdWF0fSBxIFF1YXRlcm5pb24gdG8gY3JlYXRlIG1hdHJpeCBmcm9tXG4gKlxuICogQHJldHVybnMge21hdDN9IG91dFxuICovXG5leHBvcnQgZnVuY3Rpb24gZnJvbVF1YXQob3V0LCBxKSB7XG4gICAgbGV0IHggPSBxWzBdLFxuICAgICAgICB5ID0gcVsxXSxcbiAgICAgICAgeiA9IHFbMl0sXG4gICAgICAgIHcgPSBxWzNdO1xuICAgIGxldCB4MiA9IHggKyB4O1xuICAgIGxldCB5MiA9IHkgKyB5O1xuICAgIGxldCB6MiA9IHogKyB6O1xuXG4gICAgbGV0IHh4ID0geCAqIHgyO1xuICAgIGxldCB5eCA9IHkgKiB4MjtcbiAgICBsZXQgeXkgPSB5ICogeTI7XG4gICAgbGV0IHp4ID0geiAqIHgyO1xuICAgIGxldCB6eSA9IHogKiB5MjtcbiAgICBsZXQgenogPSB6ICogejI7XG4gICAgbGV0IHd4ID0gdyAqIHgyO1xuICAgIGxldCB3eSA9IHcgKiB5MjtcbiAgICBsZXQgd3ogPSB3ICogejI7XG5cbiAgICBvdXRbMF0gPSAxIC0geXkgLSB6ejtcbiAgICBvdXRbM10gPSB5eCAtIHd6O1xuICAgIG91dFs2XSA9IHp4ICsgd3k7XG5cbiAgICBvdXRbMV0gPSB5eCArIHd6O1xuICAgIG91dFs0XSA9IDEgLSB4eCAtIHp6O1xuICAgIG91dFs3XSA9IHp5IC0gd3g7XG5cbiAgICBvdXRbMl0gPSB6eCAtIHd5O1xuICAgIG91dFs1XSA9IHp5ICsgd3g7XG4gICAgb3V0WzhdID0gMSAtIHh4IC0geXk7XG5cbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIENvcHkgdGhlIHZhbHVlcyBmcm9tIG9uZSBtYXQzIHRvIGFub3RoZXJcbiAqXG4gKiBAcGFyYW0ge21hdDN9IG91dCB0aGUgcmVjZWl2aW5nIG1hdHJpeFxuICogQHBhcmFtIHttYXQzfSBhIHRoZSBzb3VyY2UgbWF0cml4XG4gKiBAcmV0dXJucyB7bWF0M30gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjb3B5KG91dCwgYSkge1xuICAgIG91dFswXSA9IGFbMF07XG4gICAgb3V0WzFdID0gYVsxXTtcbiAgICBvdXRbMl0gPSBhWzJdO1xuICAgIG91dFszXSA9IGFbM107XG4gICAgb3V0WzRdID0gYVs0XTtcbiAgICBvdXRbNV0gPSBhWzVdO1xuICAgIG91dFs2XSA9IGFbNl07XG4gICAgb3V0WzddID0gYVs3XTtcbiAgICBvdXRbOF0gPSBhWzhdO1xuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogU2V0IHRoZSBjb21wb25lbnRzIG9mIGEgbWF0MyB0byB0aGUgZ2l2ZW4gdmFsdWVzXG4gKlxuICogQHBhcmFtIHttYXQzfSBvdXQgdGhlIHJlY2VpdmluZyBtYXRyaXhcbiAqIEByZXR1cm5zIHttYXQzfSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNldChvdXQsIG0wMCwgbTAxLCBtMDIsIG0xMCwgbTExLCBtMTIsIG0yMCwgbTIxLCBtMjIpIHtcbiAgICBvdXRbMF0gPSBtMDA7XG4gICAgb3V0WzFdID0gbTAxO1xuICAgIG91dFsyXSA9IG0wMjtcbiAgICBvdXRbM10gPSBtMTA7XG4gICAgb3V0WzRdID0gbTExO1xuICAgIG91dFs1XSA9IG0xMjtcbiAgICBvdXRbNl0gPSBtMjA7XG4gICAgb3V0WzddID0gbTIxO1xuICAgIG91dFs4XSA9IG0yMjtcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIFNldCBhIG1hdDMgdG8gdGhlIGlkZW50aXR5IG1hdHJpeFxuICpcbiAqIEBwYXJhbSB7bWF0M30gb3V0IHRoZSByZWNlaXZpbmcgbWF0cml4XG4gKiBAcmV0dXJucyB7bWF0M30gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpZGVudGl0eShvdXQpIHtcbiAgICBvdXRbMF0gPSAxO1xuICAgIG91dFsxXSA9IDA7XG4gICAgb3V0WzJdID0gMDtcbiAgICBvdXRbM10gPSAwO1xuICAgIG91dFs0XSA9IDE7XG4gICAgb3V0WzVdID0gMDtcbiAgICBvdXRbNl0gPSAwO1xuICAgIG91dFs3XSA9IDA7XG4gICAgb3V0WzhdID0gMTtcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIFRyYW5zcG9zZSB0aGUgdmFsdWVzIG9mIGEgbWF0M1xuICpcbiAqIEBwYXJhbSB7bWF0M30gb3V0IHRoZSByZWNlaXZpbmcgbWF0cml4XG4gKiBAcGFyYW0ge21hdDN9IGEgdGhlIHNvdXJjZSBtYXRyaXhcbiAqIEByZXR1cm5zIHttYXQzfSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRyYW5zcG9zZShvdXQsIGEpIHtcbiAgICAvLyBJZiB3ZSBhcmUgdHJhbnNwb3Npbmcgb3Vyc2VsdmVzIHdlIGNhbiBza2lwIGEgZmV3IHN0ZXBzIGJ1dCBoYXZlIHRvIGNhY2hlIHNvbWUgdmFsdWVzXG4gICAgaWYgKG91dCA9PT0gYSkge1xuICAgICAgICBsZXQgYTAxID0gYVsxXSxcbiAgICAgICAgICAgIGEwMiA9IGFbMl0sXG4gICAgICAgICAgICBhMTIgPSBhWzVdO1xuICAgICAgICBvdXRbMV0gPSBhWzNdO1xuICAgICAgICBvdXRbMl0gPSBhWzZdO1xuICAgICAgICBvdXRbM10gPSBhMDE7XG4gICAgICAgIG91dFs1XSA9IGFbN107XG4gICAgICAgIG91dFs2XSA9IGEwMjtcbiAgICAgICAgb3V0WzddID0gYTEyO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIG91dFswXSA9IGFbMF07XG4gICAgICAgIG91dFsxXSA9IGFbM107XG4gICAgICAgIG91dFsyXSA9IGFbNl07XG4gICAgICAgIG91dFszXSA9IGFbMV07XG4gICAgICAgIG91dFs0XSA9IGFbNF07XG4gICAgICAgIG91dFs1XSA9IGFbN107XG4gICAgICAgIG91dFs2XSA9IGFbMl07XG4gICAgICAgIG91dFs3XSA9IGFbNV07XG4gICAgICAgIG91dFs4XSA9IGFbOF07XG4gICAgfVxuXG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBJbnZlcnRzIGEgbWF0M1xuICpcbiAqIEBwYXJhbSB7bWF0M30gb3V0IHRoZSByZWNlaXZpbmcgbWF0cml4XG4gKiBAcGFyYW0ge21hdDN9IGEgdGhlIHNvdXJjZSBtYXRyaXhcbiAqIEByZXR1cm5zIHttYXQzfSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGludmVydChvdXQsIGEpIHtcbiAgICBsZXQgYTAwID0gYVswXSxcbiAgICAgICAgYTAxID0gYVsxXSxcbiAgICAgICAgYTAyID0gYVsyXTtcbiAgICBsZXQgYTEwID0gYVszXSxcbiAgICAgICAgYTExID0gYVs0XSxcbiAgICAgICAgYTEyID0gYVs1XTtcbiAgICBsZXQgYTIwID0gYVs2XSxcbiAgICAgICAgYTIxID0gYVs3XSxcbiAgICAgICAgYTIyID0gYVs4XTtcblxuICAgIGxldCBiMDEgPSBhMjIgKiBhMTEgLSBhMTIgKiBhMjE7XG4gICAgbGV0IGIxMSA9IC1hMjIgKiBhMTAgKyBhMTIgKiBhMjA7XG4gICAgbGV0IGIyMSA9IGEyMSAqIGExMCAtIGExMSAqIGEyMDtcblxuICAgIC8vIENhbGN1bGF0ZSB0aGUgZGV0ZXJtaW5hbnRcbiAgICBsZXQgZGV0ID0gYTAwICogYjAxICsgYTAxICogYjExICsgYTAyICogYjIxO1xuXG4gICAgaWYgKCFkZXQpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGRldCA9IDEuMCAvIGRldDtcblxuICAgIG91dFswXSA9IGIwMSAqIGRldDtcbiAgICBvdXRbMV0gPSAoLWEyMiAqIGEwMSArIGEwMiAqIGEyMSkgKiBkZXQ7XG4gICAgb3V0WzJdID0gKGExMiAqIGEwMSAtIGEwMiAqIGExMSkgKiBkZXQ7XG4gICAgb3V0WzNdID0gYjExICogZGV0O1xuICAgIG91dFs0XSA9IChhMjIgKiBhMDAgLSBhMDIgKiBhMjApICogZGV0O1xuICAgIG91dFs1XSA9ICgtYTEyICogYTAwICsgYTAyICogYTEwKSAqIGRldDtcbiAgICBvdXRbNl0gPSBiMjEgKiBkZXQ7XG4gICAgb3V0WzddID0gKC1hMjEgKiBhMDAgKyBhMDEgKiBhMjApICogZGV0O1xuICAgIG91dFs4XSA9IChhMTEgKiBhMDAgLSBhMDEgKiBhMTApICogZGV0O1xuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogQ2FsY3VsYXRlcyB0aGUgZGV0ZXJtaW5hbnQgb2YgYSBtYXQzXG4gKlxuICogQHBhcmFtIHttYXQzfSBhIHRoZSBzb3VyY2UgbWF0cml4XG4gKiBAcmV0dXJucyB7TnVtYmVyfSBkZXRlcm1pbmFudCBvZiBhXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkZXRlcm1pbmFudChhKSB7XG4gICAgbGV0IGEwMCA9IGFbMF0sXG4gICAgICAgIGEwMSA9IGFbMV0sXG4gICAgICAgIGEwMiA9IGFbMl07XG4gICAgbGV0IGExMCA9IGFbM10sXG4gICAgICAgIGExMSA9IGFbNF0sXG4gICAgICAgIGExMiA9IGFbNV07XG4gICAgbGV0IGEyMCA9IGFbNl0sXG4gICAgICAgIGEyMSA9IGFbN10sXG4gICAgICAgIGEyMiA9IGFbOF07XG5cbiAgICByZXR1cm4gYTAwICogKGEyMiAqIGExMSAtIGExMiAqIGEyMSkgKyBhMDEgKiAoLWEyMiAqIGExMCArIGExMiAqIGEyMCkgKyBhMDIgKiAoYTIxICogYTEwIC0gYTExICogYTIwKTtcbn1cblxuLyoqXG4gKiBNdWx0aXBsaWVzIHR3byBtYXQzJ3NcbiAqXG4gKiBAcGFyYW0ge21hdDN9IG91dCB0aGUgcmVjZWl2aW5nIG1hdHJpeFxuICogQHBhcmFtIHttYXQzfSBhIHRoZSBmaXJzdCBvcGVyYW5kXG4gKiBAcGFyYW0ge21hdDN9IGIgdGhlIHNlY29uZCBvcGVyYW5kXG4gKiBAcmV0dXJucyB7bWF0M30gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtdWx0aXBseShvdXQsIGEsIGIpIHtcbiAgICBsZXQgYTAwID0gYVswXSxcbiAgICAgICAgYTAxID0gYVsxXSxcbiAgICAgICAgYTAyID0gYVsyXTtcbiAgICBsZXQgYTEwID0gYVszXSxcbiAgICAgICAgYTExID0gYVs0XSxcbiAgICAgICAgYTEyID0gYVs1XTtcbiAgICBsZXQgYTIwID0gYVs2XSxcbiAgICAgICAgYTIxID0gYVs3XSxcbiAgICAgICAgYTIyID0gYVs4XTtcblxuICAgIGxldCBiMDAgPSBiWzBdLFxuICAgICAgICBiMDEgPSBiWzFdLFxuICAgICAgICBiMDIgPSBiWzJdO1xuICAgIGxldCBiMTAgPSBiWzNdLFxuICAgICAgICBiMTEgPSBiWzRdLFxuICAgICAgICBiMTIgPSBiWzVdO1xuICAgIGxldCBiMjAgPSBiWzZdLFxuICAgICAgICBiMjEgPSBiWzddLFxuICAgICAgICBiMjIgPSBiWzhdO1xuXG4gICAgb3V0WzBdID0gYjAwICogYTAwICsgYjAxICogYTEwICsgYjAyICogYTIwO1xuICAgIG91dFsxXSA9IGIwMCAqIGEwMSArIGIwMSAqIGExMSArIGIwMiAqIGEyMTtcbiAgICBvdXRbMl0gPSBiMDAgKiBhMDIgKyBiMDEgKiBhMTIgKyBiMDIgKiBhMjI7XG5cbiAgICBvdXRbM10gPSBiMTAgKiBhMDAgKyBiMTEgKiBhMTAgKyBiMTIgKiBhMjA7XG4gICAgb3V0WzRdID0gYjEwICogYTAxICsgYjExICogYTExICsgYjEyICogYTIxO1xuICAgIG91dFs1XSA9IGIxMCAqIGEwMiArIGIxMSAqIGExMiArIGIxMiAqIGEyMjtcblxuICAgIG91dFs2XSA9IGIyMCAqIGEwMCArIGIyMSAqIGExMCArIGIyMiAqIGEyMDtcbiAgICBvdXRbN10gPSBiMjAgKiBhMDEgKyBiMjEgKiBhMTEgKyBiMjIgKiBhMjE7XG4gICAgb3V0WzhdID0gYjIwICogYTAyICsgYjIxICogYTEyICsgYjIyICogYTIyO1xuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogVHJhbnNsYXRlIGEgbWF0MyBieSB0aGUgZ2l2ZW4gdmVjdG9yXG4gKlxuICogQHBhcmFtIHttYXQzfSBvdXQgdGhlIHJlY2VpdmluZyBtYXRyaXhcbiAqIEBwYXJhbSB7bWF0M30gYSB0aGUgbWF0cml4IHRvIHRyYW5zbGF0ZVxuICogQHBhcmFtIHt2ZWMyfSB2IHZlY3RvciB0byB0cmFuc2xhdGUgYnlcbiAqIEByZXR1cm5zIHttYXQzfSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRyYW5zbGF0ZShvdXQsIGEsIHYpIHtcbiAgICBsZXQgYTAwID0gYVswXSxcbiAgICAgICAgYTAxID0gYVsxXSxcbiAgICAgICAgYTAyID0gYVsyXSxcbiAgICAgICAgYTEwID0gYVszXSxcbiAgICAgICAgYTExID0gYVs0XSxcbiAgICAgICAgYTEyID0gYVs1XSxcbiAgICAgICAgYTIwID0gYVs2XSxcbiAgICAgICAgYTIxID0gYVs3XSxcbiAgICAgICAgYTIyID0gYVs4XSxcbiAgICAgICAgeCA9IHZbMF0sXG4gICAgICAgIHkgPSB2WzFdO1xuXG4gICAgb3V0WzBdID0gYTAwO1xuICAgIG91dFsxXSA9IGEwMTtcbiAgICBvdXRbMl0gPSBhMDI7XG5cbiAgICBvdXRbM10gPSBhMTA7XG4gICAgb3V0WzRdID0gYTExO1xuICAgIG91dFs1XSA9IGExMjtcblxuICAgIG91dFs2XSA9IHggKiBhMDAgKyB5ICogYTEwICsgYTIwO1xuICAgIG91dFs3XSA9IHggKiBhMDEgKyB5ICogYTExICsgYTIxO1xuICAgIG91dFs4XSA9IHggKiBhMDIgKyB5ICogYTEyICsgYTIyO1xuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogUm90YXRlcyBhIG1hdDMgYnkgdGhlIGdpdmVuIGFuZ2xlXG4gKlxuICogQHBhcmFtIHttYXQzfSBvdXQgdGhlIHJlY2VpdmluZyBtYXRyaXhcbiAqIEBwYXJhbSB7bWF0M30gYSB0aGUgbWF0cml4IHRvIHJvdGF0ZVxuICogQHBhcmFtIHtOdW1iZXJ9IHJhZCB0aGUgYW5nbGUgdG8gcm90YXRlIHRoZSBtYXRyaXggYnlcbiAqIEByZXR1cm5zIHttYXQzfSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJvdGF0ZShvdXQsIGEsIHJhZCkge1xuICAgIGxldCBhMDAgPSBhWzBdLFxuICAgICAgICBhMDEgPSBhWzFdLFxuICAgICAgICBhMDIgPSBhWzJdLFxuICAgICAgICBhMTAgPSBhWzNdLFxuICAgICAgICBhMTEgPSBhWzRdLFxuICAgICAgICBhMTIgPSBhWzVdLFxuICAgICAgICBhMjAgPSBhWzZdLFxuICAgICAgICBhMjEgPSBhWzddLFxuICAgICAgICBhMjIgPSBhWzhdLFxuICAgICAgICBzID0gTWF0aC5zaW4ocmFkKSxcbiAgICAgICAgYyA9IE1hdGguY29zKHJhZCk7XG5cbiAgICBvdXRbMF0gPSBjICogYTAwICsgcyAqIGExMDtcbiAgICBvdXRbMV0gPSBjICogYTAxICsgcyAqIGExMTtcbiAgICBvdXRbMl0gPSBjICogYTAyICsgcyAqIGExMjtcblxuICAgIG91dFszXSA9IGMgKiBhMTAgLSBzICogYTAwO1xuICAgIG91dFs0XSA9IGMgKiBhMTEgLSBzICogYTAxO1xuICAgIG91dFs1XSA9IGMgKiBhMTIgLSBzICogYTAyO1xuXG4gICAgb3V0WzZdID0gYTIwO1xuICAgIG91dFs3XSA9IGEyMTtcbiAgICBvdXRbOF0gPSBhMjI7XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBTY2FsZXMgdGhlIG1hdDMgYnkgdGhlIGRpbWVuc2lvbnMgaW4gdGhlIGdpdmVuIHZlYzJcbiAqXG4gKiBAcGFyYW0ge21hdDN9IG91dCB0aGUgcmVjZWl2aW5nIG1hdHJpeFxuICogQHBhcmFtIHttYXQzfSBhIHRoZSBtYXRyaXggdG8gcm90YXRlXG4gKiBAcGFyYW0ge3ZlYzJ9IHYgdGhlIHZlYzIgdG8gc2NhbGUgdGhlIG1hdHJpeCBieVxuICogQHJldHVybnMge21hdDN9IG91dFxuICoqL1xuZXhwb3J0IGZ1bmN0aW9uIHNjYWxlKG91dCwgYSwgdikge1xuICAgIGxldCB4ID0gdlswXSxcbiAgICAgICAgeSA9IHZbMV07XG5cbiAgICBvdXRbMF0gPSB4ICogYVswXTtcbiAgICBvdXRbMV0gPSB4ICogYVsxXTtcbiAgICBvdXRbMl0gPSB4ICogYVsyXTtcblxuICAgIG91dFszXSA9IHkgKiBhWzNdO1xuICAgIG91dFs0XSA9IHkgKiBhWzRdO1xuICAgIG91dFs1XSA9IHkgKiBhWzVdO1xuXG4gICAgb3V0WzZdID0gYVs2XTtcbiAgICBvdXRbN10gPSBhWzddO1xuICAgIG91dFs4XSA9IGFbOF07XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBDYWxjdWxhdGVzIGEgM3gzIG5vcm1hbCBtYXRyaXggKHRyYW5zcG9zZSBpbnZlcnNlKSBmcm9tIHRoZSA0eDQgbWF0cml4XG4gKlxuICogQHBhcmFtIHttYXQzfSBvdXQgbWF0MyByZWNlaXZpbmcgb3BlcmF0aW9uIHJlc3VsdFxuICogQHBhcmFtIHttYXQ0fSBhIE1hdDQgdG8gZGVyaXZlIHRoZSBub3JtYWwgbWF0cml4IGZyb21cbiAqXG4gKiBAcmV0dXJucyB7bWF0M30gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBub3JtYWxGcm9tTWF0NChvdXQsIGEpIHtcbiAgICBsZXQgYTAwID0gYVswXSxcbiAgICAgICAgYTAxID0gYVsxXSxcbiAgICAgICAgYTAyID0gYVsyXSxcbiAgICAgICAgYTAzID0gYVszXTtcbiAgICBsZXQgYTEwID0gYVs0XSxcbiAgICAgICAgYTExID0gYVs1XSxcbiAgICAgICAgYTEyID0gYVs2XSxcbiAgICAgICAgYTEzID0gYVs3XTtcbiAgICBsZXQgYTIwID0gYVs4XSxcbiAgICAgICAgYTIxID0gYVs5XSxcbiAgICAgICAgYTIyID0gYVsxMF0sXG4gICAgICAgIGEyMyA9IGFbMTFdO1xuICAgIGxldCBhMzAgPSBhWzEyXSxcbiAgICAgICAgYTMxID0gYVsxM10sXG4gICAgICAgIGEzMiA9IGFbMTRdLFxuICAgICAgICBhMzMgPSBhWzE1XTtcblxuICAgIGxldCBiMDAgPSBhMDAgKiBhMTEgLSBhMDEgKiBhMTA7XG4gICAgbGV0IGIwMSA9IGEwMCAqIGExMiAtIGEwMiAqIGExMDtcbiAgICBsZXQgYjAyID0gYTAwICogYTEzIC0gYTAzICogYTEwO1xuICAgIGxldCBiMDMgPSBhMDEgKiBhMTIgLSBhMDIgKiBhMTE7XG4gICAgbGV0IGIwNCA9IGEwMSAqIGExMyAtIGEwMyAqIGExMTtcbiAgICBsZXQgYjA1ID0gYTAyICogYTEzIC0gYTAzICogYTEyO1xuICAgIGxldCBiMDYgPSBhMjAgKiBhMzEgLSBhMjEgKiBhMzA7XG4gICAgbGV0IGIwNyA9IGEyMCAqIGEzMiAtIGEyMiAqIGEzMDtcbiAgICBsZXQgYjA4ID0gYTIwICogYTMzIC0gYTIzICogYTMwO1xuICAgIGxldCBiMDkgPSBhMjEgKiBhMzIgLSBhMjIgKiBhMzE7XG4gICAgbGV0IGIxMCA9IGEyMSAqIGEzMyAtIGEyMyAqIGEzMTtcbiAgICBsZXQgYjExID0gYTIyICogYTMzIC0gYTIzICogYTMyO1xuXG4gICAgLy8gQ2FsY3VsYXRlIHRoZSBkZXRlcm1pbmFudFxuICAgIGxldCBkZXQgPSBiMDAgKiBiMTEgLSBiMDEgKiBiMTAgKyBiMDIgKiBiMDkgKyBiMDMgKiBiMDggLSBiMDQgKiBiMDcgKyBiMDUgKiBiMDY7XG5cbiAgICBpZiAoIWRldCkge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgZGV0ID0gMS4wIC8gZGV0O1xuXG4gICAgb3V0WzBdID0gKGExMSAqIGIxMSAtIGExMiAqIGIxMCArIGExMyAqIGIwOSkgKiBkZXQ7XG4gICAgb3V0WzFdID0gKGExMiAqIGIwOCAtIGExMCAqIGIxMSAtIGExMyAqIGIwNykgKiBkZXQ7XG4gICAgb3V0WzJdID0gKGExMCAqIGIxMCAtIGExMSAqIGIwOCArIGExMyAqIGIwNikgKiBkZXQ7XG5cbiAgICBvdXRbM10gPSAoYTAyICogYjEwIC0gYTAxICogYjExIC0gYTAzICogYjA5KSAqIGRldDtcbiAgICBvdXRbNF0gPSAoYTAwICogYjExIC0gYTAyICogYjA4ICsgYTAzICogYjA3KSAqIGRldDtcbiAgICBvdXRbNV0gPSAoYTAxICogYjA4IC0gYTAwICogYjEwIC0gYTAzICogYjA2KSAqIGRldDtcblxuICAgIG91dFs2XSA9IChhMzEgKiBiMDUgLSBhMzIgKiBiMDQgKyBhMzMgKiBiMDMpICogZGV0O1xuICAgIG91dFs3XSA9IChhMzIgKiBiMDIgLSBhMzAgKiBiMDUgLSBhMzMgKiBiMDEpICogZGV0O1xuICAgIG91dFs4XSA9IChhMzAgKiBiMDQgLSBhMzEgKiBiMDIgKyBhMzMgKiBiMDApICogZGV0O1xuXG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBHZW5lcmF0ZXMgYSAyRCBwcm9qZWN0aW9uIG1hdHJpeCB3aXRoIHRoZSBnaXZlbiBib3VuZHNcbiAqXG4gKiBAcGFyYW0ge21hdDN9IG91dCBtYXQzIGZydXN0dW0gbWF0cml4IHdpbGwgYmUgd3JpdHRlbiBpbnRvXG4gKiBAcGFyYW0ge251bWJlcn0gd2lkdGggV2lkdGggb2YgeW91ciBnbCBjb250ZXh0XG4gKiBAcGFyYW0ge251bWJlcn0gaGVpZ2h0IEhlaWdodCBvZiBnbCBjb250ZXh0XG4gKiBAcmV0dXJucyB7bWF0M30gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwcm9qZWN0aW9uKG91dCwgd2lkdGgsIGhlaWdodCkge1xuICAgIG91dFswXSA9IDIgLyB3aWR0aDtcbiAgICBvdXRbMV0gPSAwO1xuICAgIG91dFsyXSA9IDA7XG4gICAgb3V0WzNdID0gMDtcbiAgICBvdXRbNF0gPSAtMiAvIGhlaWdodDtcbiAgICBvdXRbNV0gPSAwO1xuICAgIG91dFs2XSA9IC0xO1xuICAgIG91dFs3XSA9IDE7XG4gICAgb3V0WzhdID0gMTtcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIEFkZHMgdHdvIG1hdDMnc1xuICpcbiAqIEBwYXJhbSB7bWF0M30gb3V0IHRoZSByZWNlaXZpbmcgbWF0cml4XG4gKiBAcGFyYW0ge21hdDN9IGEgdGhlIGZpcnN0IG9wZXJhbmRcbiAqIEBwYXJhbSB7bWF0M30gYiB0aGUgc2Vjb25kIG9wZXJhbmRcbiAqIEByZXR1cm5zIHttYXQzfSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGFkZChvdXQsIGEsIGIpIHtcbiAgICBvdXRbMF0gPSBhWzBdICsgYlswXTtcbiAgICBvdXRbMV0gPSBhWzFdICsgYlsxXTtcbiAgICBvdXRbMl0gPSBhWzJdICsgYlsyXTtcbiAgICBvdXRbM10gPSBhWzNdICsgYlszXTtcbiAgICBvdXRbNF0gPSBhWzRdICsgYls0XTtcbiAgICBvdXRbNV0gPSBhWzVdICsgYls1XTtcbiAgICBvdXRbNl0gPSBhWzZdICsgYls2XTtcbiAgICBvdXRbN10gPSBhWzddICsgYls3XTtcbiAgICBvdXRbOF0gPSBhWzhdICsgYls4XTtcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIFN1YnRyYWN0cyBtYXRyaXggYiBmcm9tIG1hdHJpeCBhXG4gKlxuICogQHBhcmFtIHttYXQzfSBvdXQgdGhlIHJlY2VpdmluZyBtYXRyaXhcbiAqIEBwYXJhbSB7bWF0M30gYSB0aGUgZmlyc3Qgb3BlcmFuZFxuICogQHBhcmFtIHttYXQzfSBiIHRoZSBzZWNvbmQgb3BlcmFuZFxuICogQHJldHVybnMge21hdDN9IG91dFxuICovXG5leHBvcnQgZnVuY3Rpb24gc3VidHJhY3Qob3V0LCBhLCBiKSB7XG4gICAgb3V0WzBdID0gYVswXSAtIGJbMF07XG4gICAgb3V0WzFdID0gYVsxXSAtIGJbMV07XG4gICAgb3V0WzJdID0gYVsyXSAtIGJbMl07XG4gICAgb3V0WzNdID0gYVszXSAtIGJbM107XG4gICAgb3V0WzRdID0gYVs0XSAtIGJbNF07XG4gICAgb3V0WzVdID0gYVs1XSAtIGJbNV07XG4gICAgb3V0WzZdID0gYVs2XSAtIGJbNl07XG4gICAgb3V0WzddID0gYVs3XSAtIGJbN107XG4gICAgb3V0WzhdID0gYVs4XSAtIGJbOF07XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBNdWx0aXBseSBlYWNoIGVsZW1lbnQgb2YgdGhlIG1hdHJpeCBieSBhIHNjYWxhci5cbiAqXG4gKiBAcGFyYW0ge21hdDN9IG91dCB0aGUgcmVjZWl2aW5nIG1hdHJpeFxuICogQHBhcmFtIHttYXQzfSBhIHRoZSBtYXRyaXggdG8gc2NhbGVcbiAqIEBwYXJhbSB7TnVtYmVyfSBiIGFtb3VudCB0byBzY2FsZSB0aGUgbWF0cml4J3MgZWxlbWVudHMgYnlcbiAqIEByZXR1cm5zIHttYXQzfSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG11bHRpcGx5U2NhbGFyKG91dCwgYSwgYikge1xuICAgIG91dFswXSA9IGFbMF0gKiBiO1xuICAgIG91dFsxXSA9IGFbMV0gKiBiO1xuICAgIG91dFsyXSA9IGFbMl0gKiBiO1xuICAgIG91dFszXSA9IGFbM10gKiBiO1xuICAgIG91dFs0XSA9IGFbNF0gKiBiO1xuICAgIG91dFs1XSA9IGFbNV0gKiBiO1xuICAgIG91dFs2XSA9IGFbNl0gKiBiO1xuICAgIG91dFs3XSA9IGFbN10gKiBiO1xuICAgIG91dFs4XSA9IGFbOF0gKiBiO1xuICAgIHJldHVybiBvdXQ7XG59XG4iLCJpbXBvcnQgKiBhcyBNYXQzRnVuYyBmcm9tICcuL2Z1bmN0aW9ucy9NYXQzRnVuYy5qcyc7XG5cbmV4cG9ydCBjbGFzcyBNYXQzIGV4dGVuZHMgQXJyYXkge1xuICAgIGNvbnN0cnVjdG9yKG0wMCA9IDEsIG0wMSA9IDAsIG0wMiA9IDAsIG0xMCA9IDAsIG0xMSA9IDEsIG0xMiA9IDAsIG0yMCA9IDAsIG0yMSA9IDAsIG0yMiA9IDEpIHtcbiAgICAgICAgc3VwZXIobTAwLCBtMDEsIG0wMiwgbTEwLCBtMTEsIG0xMiwgbTIwLCBtMjEsIG0yMik7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIHNldChtMDAsIG0wMSwgbTAyLCBtMTAsIG0xMSwgbTEyLCBtMjAsIG0yMSwgbTIyKSB7XG4gICAgICAgIGlmIChtMDAubGVuZ3RoKSByZXR1cm4gdGhpcy5jb3B5KG0wMCk7XG4gICAgICAgIE1hdDNGdW5jLnNldCh0aGlzLCBtMDAsIG0wMSwgbTAyLCBtMTAsIG0xMSwgbTEyLCBtMjAsIG0yMSwgbTIyKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgdHJhbnNsYXRlKHYsIG0gPSB0aGlzKSB7XG4gICAgICAgIE1hdDNGdW5jLnRyYW5zbGF0ZSh0aGlzLCBtLCB2KTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgcm90YXRlKHYsIG0gPSB0aGlzKSB7XG4gICAgICAgIE1hdDNGdW5jLnJvdGF0ZSh0aGlzLCBtLCB2KTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgc2NhbGUodiwgbSA9IHRoaXMpIHtcbiAgICAgICAgTWF0M0Z1bmMuc2NhbGUodGhpcywgbSwgdik7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIG11bHRpcGx5KG1hLCBtYikge1xuICAgICAgICBpZiAobWIpIHtcbiAgICAgICAgICAgIE1hdDNGdW5jLm11bHRpcGx5KHRoaXMsIG1hLCBtYik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBNYXQzRnVuYy5tdWx0aXBseSh0aGlzLCB0aGlzLCBtYSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgaWRlbnRpdHkoKSB7XG4gICAgICAgIE1hdDNGdW5jLmlkZW50aXR5KHRoaXMpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBjb3B5KG0pIHtcbiAgICAgICAgTWF0M0Z1bmMuY29weSh0aGlzLCBtKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgZnJvbU1hdHJpeDQobSkge1xuICAgICAgICBNYXQzRnVuYy5mcm9tTWF0NCh0aGlzLCBtKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgZnJvbVF1YXRlcm5pb24ocSkge1xuICAgICAgICBNYXQzRnVuYy5mcm9tUXVhdCh0aGlzLCBxKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgZnJvbUJhc2lzKHZlYzNhLCB2ZWMzYiwgdmVjM2MpIHtcbiAgICAgICAgdGhpcy5zZXQodmVjM2FbMF0sIHZlYzNhWzFdLCB2ZWMzYVsyXSwgdmVjM2JbMF0sIHZlYzNiWzFdLCB2ZWMzYlsyXSwgdmVjM2NbMF0sIHZlYzNjWzFdLCB2ZWMzY1syXSk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGludmVyc2UobSA9IHRoaXMpIHtcbiAgICAgICAgTWF0M0Z1bmMuaW52ZXJ0KHRoaXMsIG0pO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBnZXROb3JtYWxNYXRyaXgobSkge1xuICAgICAgICBNYXQzRnVuYy5ub3JtYWxGcm9tTWF0NCh0aGlzLCBtKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgVHJhbnNmb3JtIH0gZnJvbSAnLi9UcmFuc2Zvcm0uanMnO1xuaW1wb3J0IHsgTWF0MyB9IGZyb20gJy4uL21hdGgvTWF0My5qcyc7XG5pbXBvcnQgeyBNYXQ0IH0gZnJvbSAnLi4vbWF0aC9NYXQ0LmpzJztcblxubGV0IElEID0gMDtcblxuZXhwb3J0IGNsYXNzIE1lc2ggZXh0ZW5kcyBUcmFuc2Zvcm0ge1xuICAgIGNvbnN0cnVjdG9yKGdsLCB7IGdlb21ldHJ5LCBwcm9ncmFtLCBtb2RlID0gZ2wuVFJJQU5HTEVTLCBmcnVzdHVtQ3VsbGVkID0gdHJ1ZSwgcmVuZGVyT3JkZXIgPSAwIH0gPSB7fSkge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICBpZiAoIWdsLmNhbnZhcykgY29uc29sZS5lcnJvcignZ2wgbm90IHBhc3NlZCBhcyBmaXJzdCBhcmd1bWVudCB0byBNZXNoJyk7XG4gICAgICAgIHRoaXMuZ2wgPSBnbDtcbiAgICAgICAgdGhpcy5pZCA9IElEKys7XG4gICAgICAgIHRoaXMuZ2VvbWV0cnkgPSBnZW9tZXRyeTtcbiAgICAgICAgdGhpcy5wcm9ncmFtID0gcHJvZ3JhbTtcbiAgICAgICAgdGhpcy5tb2RlID0gbW9kZTtcblxuICAgICAgICAvLyBVc2VkIHRvIHNraXAgZnJ1c3R1bSBjdWxsaW5nXG4gICAgICAgIHRoaXMuZnJ1c3R1bUN1bGxlZCA9IGZydXN0dW1DdWxsZWQ7XG5cbiAgICAgICAgLy8gT3ZlcnJpZGUgc29ydGluZyB0byBmb3JjZSBhbiBvcmRlclxuICAgICAgICB0aGlzLnJlbmRlck9yZGVyID0gcmVuZGVyT3JkZXI7XG4gICAgICAgIHRoaXMubW9kZWxWaWV3TWF0cml4ID0gbmV3IE1hdDQoKTtcbiAgICAgICAgdGhpcy5ub3JtYWxNYXRyaXggPSBuZXcgTWF0MygpO1xuICAgICAgICB0aGlzLmJlZm9yZVJlbmRlckNhbGxiYWNrcyA9IFtdO1xuICAgICAgICB0aGlzLmFmdGVyUmVuZGVyQ2FsbGJhY2tzID0gW107XG4gICAgfVxuXG4gICAgb25CZWZvcmVSZW5kZXIoZikge1xuICAgICAgICB0aGlzLmJlZm9yZVJlbmRlckNhbGxiYWNrcy5wdXNoKGYpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBvbkFmdGVyUmVuZGVyKGYpIHtcbiAgICAgICAgdGhpcy5hZnRlclJlbmRlckNhbGxiYWNrcy5wdXNoKGYpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBkcmF3KHsgY2FtZXJhIH0gPSB7fSkge1xuICAgICAgICBpZiAoY2FtZXJhKSB7XG4gICAgICAgICAgICAvLyBBZGQgZW1wdHkgbWF0cml4IHVuaWZvcm1zIHRvIHByb2dyYW0gaWYgdW5zZXRcbiAgICAgICAgICAgIGlmICghdGhpcy5wcm9ncmFtLnVuaWZvcm1zLm1vZGVsTWF0cml4KSB7XG4gICAgICAgICAgICAgICAgT2JqZWN0LmFzc2lnbih0aGlzLnByb2dyYW0udW5pZm9ybXMsIHtcbiAgICAgICAgICAgICAgICAgICAgbW9kZWxNYXRyaXg6IHsgdmFsdWU6IG51bGwgfSxcbiAgICAgICAgICAgICAgICAgICAgdmlld01hdHJpeDogeyB2YWx1ZTogbnVsbCB9LFxuICAgICAgICAgICAgICAgICAgICBtb2RlbFZpZXdNYXRyaXg6IHsgdmFsdWU6IG51bGwgfSxcbiAgICAgICAgICAgICAgICAgICAgbm9ybWFsTWF0cml4OiB7IHZhbHVlOiBudWxsIH0sXG4gICAgICAgICAgICAgICAgICAgIHByb2plY3Rpb25NYXRyaXg6IHsgdmFsdWU6IG51bGwgfSxcbiAgICAgICAgICAgICAgICAgICAgY2FtZXJhUG9zaXRpb246IHsgdmFsdWU6IG51bGwgfSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gU2V0IHRoZSBtYXRyaXggdW5pZm9ybXNcbiAgICAgICAgICAgIHRoaXMucHJvZ3JhbS51bmlmb3Jtcy5wcm9qZWN0aW9uTWF0cml4LnZhbHVlID0gY2FtZXJhLnByb2plY3Rpb25NYXRyaXg7XG4gICAgICAgICAgICB0aGlzLnByb2dyYW0udW5pZm9ybXMuY2FtZXJhUG9zaXRpb24udmFsdWUgPSBjYW1lcmEud29ybGRQb3NpdGlvbjtcbiAgICAgICAgICAgIHRoaXMucHJvZ3JhbS51bmlmb3Jtcy52aWV3TWF0cml4LnZhbHVlID0gY2FtZXJhLnZpZXdNYXRyaXg7XG4gICAgICAgICAgICB0aGlzLm1vZGVsVmlld01hdHJpeC5tdWx0aXBseShjYW1lcmEudmlld01hdHJpeCwgdGhpcy53b3JsZE1hdHJpeCk7XG4gICAgICAgICAgICB0aGlzLm5vcm1hbE1hdHJpeC5nZXROb3JtYWxNYXRyaXgodGhpcy5tb2RlbFZpZXdNYXRyaXgpO1xuICAgICAgICAgICAgdGhpcy5wcm9ncmFtLnVuaWZvcm1zLm1vZGVsTWF0cml4LnZhbHVlID0gdGhpcy53b3JsZE1hdHJpeDtcbiAgICAgICAgICAgIHRoaXMucHJvZ3JhbS51bmlmb3Jtcy5tb2RlbFZpZXdNYXRyaXgudmFsdWUgPSB0aGlzLm1vZGVsVmlld01hdHJpeDtcbiAgICAgICAgICAgIHRoaXMucHJvZ3JhbS51bmlmb3Jtcy5ub3JtYWxNYXRyaXgudmFsdWUgPSB0aGlzLm5vcm1hbE1hdHJpeDtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmJlZm9yZVJlbmRlckNhbGxiYWNrcy5mb3JFYWNoKChmKSA9PiBmICYmIGYoeyBtZXNoOiB0aGlzLCBjYW1lcmEgfSkpO1xuXG4gICAgICAgIC8vIGRldGVybWluZSBpZiBmYWNlcyBuZWVkIHRvIGJlIGZsaXBwZWQgLSB3aGVuIG1lc2ggc2NhbGVkIG5lZ2F0aXZlbHlcbiAgICAgICAgbGV0IGZsaXBGYWNlcyA9IHRoaXMucHJvZ3JhbS5jdWxsRmFjZSAmJiB0aGlzLndvcmxkTWF0cml4LmRldGVybWluYW50KCkgPCAwO1xuICAgICAgICB0aGlzLnByb2dyYW0udXNlKHsgZmxpcEZhY2VzIH0pO1xuICAgICAgICB0aGlzLmdlb21ldHJ5LmRyYXcoeyBtb2RlOiB0aGlzLm1vZGUsIHByb2dyYW06IHRoaXMucHJvZ3JhbSB9KTtcbiAgICAgICAgdGhpcy5hZnRlclJlbmRlckNhbGxiYWNrcy5mb3JFYWNoKChmKSA9PiBmICYmIGYoeyBtZXNoOiB0aGlzLCBjYW1lcmEgfSkpO1xuICAgIH1cbn1cbiIsIi8vIFRPRE86IGRlbGV0ZSB0ZXh0dXJlXG4vLyBUT0RPOiB1c2UgdGV4U3ViSW1hZ2UyRCBmb3IgdXBkYXRlcyAodmlkZW8gb3Igd2hlbiBsb2FkZWQpXG4vLyBUT0RPOiBuZWVkPyBlbmNvZGluZyA9IGxpbmVhckVuY29kaW5nXG4vLyBUT0RPOiBzdXBwb3J0IG5vbi1jb21wcmVzc2VkIG1pcG1hcHMgdXBsb2Fkc1xuXG5jb25zdCBlbXB0eVBpeGVsID0gbmV3IFVpbnQ4QXJyYXkoNCk7XG5cbmZ1bmN0aW9uIGlzUG93ZXJPZjIodmFsdWUpIHtcbiAgICByZXR1cm4gKHZhbHVlICYgKHZhbHVlIC0gMSkpID09PSAwO1xufVxuXG5sZXQgSUQgPSAxO1xuXG5leHBvcnQgY2xhc3MgVGV4dHVyZSB7XG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIGdsLFxuICAgICAgICB7XG4gICAgICAgICAgICBpbWFnZSxcbiAgICAgICAgICAgIHRhcmdldCA9IGdsLlRFWFRVUkVfMkQsXG4gICAgICAgICAgICB0eXBlID0gZ2wuVU5TSUdORURfQllURSxcbiAgICAgICAgICAgIGZvcm1hdCA9IGdsLlJHQkEsXG4gICAgICAgICAgICBpbnRlcm5hbEZvcm1hdCA9IGZvcm1hdCxcbiAgICAgICAgICAgIHdyYXBTID0gZ2wuQ0xBTVBfVE9fRURHRSxcbiAgICAgICAgICAgIHdyYXBUID0gZ2wuQ0xBTVBfVE9fRURHRSxcbiAgICAgICAgICAgIHdyYXBSID0gZ2wuQ0xBTVBfVE9fRURHRSxcbiAgICAgICAgICAgIGdlbmVyYXRlTWlwbWFwcyA9IHRhcmdldCA9PT0gKGdsLlRFWFRVUkVfMkQgfHwgZ2wuVEVYVFVSRV9DVUJFX01BUCksXG4gICAgICAgICAgICBtaW5GaWx0ZXIgPSBnZW5lcmF0ZU1pcG1hcHMgPyBnbC5ORUFSRVNUX01JUE1BUF9MSU5FQVIgOiBnbC5MSU5FQVIsXG4gICAgICAgICAgICBtYWdGaWx0ZXIgPSBnbC5MSU5FQVIsXG4gICAgICAgICAgICBwcmVtdWx0aXBseUFscGhhID0gZmFsc2UsXG4gICAgICAgICAgICB1bnBhY2tBbGlnbm1lbnQgPSA0LFxuICAgICAgICAgICAgZmxpcFkgPSB0YXJnZXQgPT0gKGdsLlRFWFRVUkVfMkQgfHwgZ2wuVEVYVFVSRV8zRCkgPyB0cnVlIDogZmFsc2UsXG4gICAgICAgICAgICBhbmlzb3Ryb3B5ID0gMCxcbiAgICAgICAgICAgIGxldmVsID0gMCxcbiAgICAgICAgICAgIHdpZHRoLCAvLyB1c2VkIGZvciBSZW5kZXJUYXJnZXRzIG9yIERhdGEgVGV4dHVyZXNcbiAgICAgICAgICAgIGhlaWdodCA9IHdpZHRoLFxuICAgICAgICAgICAgbGVuZ3RoID0gMSxcbiAgICAgICAgfSA9IHt9XG4gICAgKSB7XG4gICAgICAgIHRoaXMuZ2wgPSBnbDtcbiAgICAgICAgdGhpcy5pZCA9IElEKys7XG5cbiAgICAgICAgdGhpcy5pbWFnZSA9IGltYWdlO1xuICAgICAgICB0aGlzLnRhcmdldCA9IHRhcmdldDtcbiAgICAgICAgdGhpcy50eXBlID0gdHlwZTtcbiAgICAgICAgdGhpcy5mb3JtYXQgPSBmb3JtYXQ7XG4gICAgICAgIHRoaXMuaW50ZXJuYWxGb3JtYXQgPSBpbnRlcm5hbEZvcm1hdDtcbiAgICAgICAgdGhpcy5taW5GaWx0ZXIgPSBtaW5GaWx0ZXI7XG4gICAgICAgIHRoaXMubWFnRmlsdGVyID0gbWFnRmlsdGVyO1xuICAgICAgICB0aGlzLndyYXBTID0gd3JhcFM7XG4gICAgICAgIHRoaXMud3JhcFQgPSB3cmFwVDtcbiAgICAgICAgdGhpcy53cmFwUiA9IHdyYXBSO1xuICAgICAgICB0aGlzLmdlbmVyYXRlTWlwbWFwcyA9IGdlbmVyYXRlTWlwbWFwcztcbiAgICAgICAgdGhpcy5wcmVtdWx0aXBseUFscGhhID0gcHJlbXVsdGlwbHlBbHBoYTtcbiAgICAgICAgdGhpcy51bnBhY2tBbGlnbm1lbnQgPSB1bnBhY2tBbGlnbm1lbnQ7XG4gICAgICAgIHRoaXMuZmxpcFkgPSBmbGlwWTtcbiAgICAgICAgdGhpcy5hbmlzb3Ryb3B5ID0gTWF0aC5taW4oYW5pc290cm9weSwgdGhpcy5nbC5yZW5kZXJlci5wYXJhbWV0ZXJzLm1heEFuaXNvdHJvcHkpO1xuICAgICAgICB0aGlzLmxldmVsID0gbGV2ZWw7XG4gICAgICAgIHRoaXMud2lkdGggPSB3aWR0aDtcbiAgICAgICAgdGhpcy5oZWlnaHQgPSBoZWlnaHQ7XG4gICAgICAgIHRoaXMubGVuZ3RoID0gbGVuZ3RoO1xuICAgICAgICB0aGlzLnRleHR1cmUgPSB0aGlzLmdsLmNyZWF0ZVRleHR1cmUoKTtcblxuICAgICAgICB0aGlzLnN0b3JlID0ge1xuICAgICAgICAgICAgaW1hZ2U6IG51bGwsXG4gICAgICAgIH07XG5cbiAgICAgICAgLy8gQWxpYXMgZm9yIHN0YXRlIHN0b3JlIHRvIGF2b2lkIHJlZHVuZGFudCBjYWxscyBmb3IgZ2xvYmFsIHN0YXRlXG4gICAgICAgIHRoaXMuZ2xTdGF0ZSA9IHRoaXMuZ2wucmVuZGVyZXIuc3RhdGU7XG5cbiAgICAgICAgLy8gU3RhdGUgc3RvcmUgdG8gYXZvaWQgcmVkdW5kYW50IGNhbGxzIGZvciBwZXItdGV4dHVyZSBzdGF0ZVxuICAgICAgICB0aGlzLnN0YXRlID0ge307XG4gICAgICAgIHRoaXMuc3RhdGUubWluRmlsdGVyID0gdGhpcy5nbC5ORUFSRVNUX01JUE1BUF9MSU5FQVI7XG4gICAgICAgIHRoaXMuc3RhdGUubWFnRmlsdGVyID0gdGhpcy5nbC5MSU5FQVI7XG4gICAgICAgIHRoaXMuc3RhdGUud3JhcFMgPSB0aGlzLmdsLlJFUEVBVDtcbiAgICAgICAgdGhpcy5zdGF0ZS53cmFwVCA9IHRoaXMuZ2wuUkVQRUFUO1xuICAgICAgICB0aGlzLnN0YXRlLmFuaXNvdHJvcHkgPSAwO1xuICAgIH1cblxuICAgIGJpbmQoKSB7XG4gICAgICAgIC8vIEFscmVhZHkgYm91bmQgdG8gYWN0aXZlIHRleHR1cmUgdW5pdFxuICAgICAgICBpZiAodGhpcy5nbFN0YXRlLnRleHR1cmVVbml0c1t0aGlzLmdsU3RhdGUuYWN0aXZlVGV4dHVyZVVuaXRdID09PSB0aGlzLmlkKSByZXR1cm47XG4gICAgICAgIHRoaXMuZ2wuYmluZFRleHR1cmUodGhpcy50YXJnZXQsIHRoaXMudGV4dHVyZSk7XG4gICAgICAgIHRoaXMuZ2xTdGF0ZS50ZXh0dXJlVW5pdHNbdGhpcy5nbFN0YXRlLmFjdGl2ZVRleHR1cmVVbml0XSA9IHRoaXMuaWQ7XG4gICAgfVxuXG4gICAgdXBkYXRlKHRleHR1cmVVbml0ID0gMCkge1xuICAgICAgICBjb25zdCBuZWVkc1VwZGF0ZSA9ICEodGhpcy5pbWFnZSA9PT0gdGhpcy5zdG9yZS5pbWFnZSAmJiAhdGhpcy5uZWVkc1VwZGF0ZSk7XG5cbiAgICAgICAgLy8gTWFrZSBzdXJlIHRoYXQgdGV4dHVyZSBpcyBib3VuZCB0byBpdHMgdGV4dHVyZSB1bml0XG4gICAgICAgIGlmIChuZWVkc1VwZGF0ZSB8fCB0aGlzLmdsU3RhdGUudGV4dHVyZVVuaXRzW3RleHR1cmVVbml0XSAhPT0gdGhpcy5pZCkge1xuICAgICAgICAgICAgLy8gc2V0IGFjdGl2ZSB0ZXh0dXJlIHVuaXQgdG8gcGVyZm9ybSB0ZXh0dXJlIGZ1bmN0aW9uc1xuICAgICAgICAgICAgdGhpcy5nbC5yZW5kZXJlci5hY3RpdmVUZXh0dXJlKHRleHR1cmVVbml0KTtcbiAgICAgICAgICAgIHRoaXMuYmluZCgpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCFuZWVkc1VwZGF0ZSkgcmV0dXJuO1xuICAgICAgICB0aGlzLm5lZWRzVXBkYXRlID0gZmFsc2U7XG5cbiAgICAgICAgaWYgKHRoaXMuZmxpcFkgIT09IHRoaXMuZ2xTdGF0ZS5mbGlwWSkge1xuICAgICAgICAgICAgdGhpcy5nbC5waXhlbFN0b3JlaSh0aGlzLmdsLlVOUEFDS19GTElQX1lfV0VCR0wsIHRoaXMuZmxpcFkpO1xuICAgICAgICAgICAgdGhpcy5nbFN0YXRlLmZsaXBZID0gdGhpcy5mbGlwWTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh0aGlzLnByZW11bHRpcGx5QWxwaGEgIT09IHRoaXMuZ2xTdGF0ZS5wcmVtdWx0aXBseUFscGhhKSB7XG4gICAgICAgICAgICB0aGlzLmdsLnBpeGVsU3RvcmVpKHRoaXMuZ2wuVU5QQUNLX1BSRU1VTFRJUExZX0FMUEhBX1dFQkdMLCB0aGlzLnByZW11bHRpcGx5QWxwaGEpO1xuICAgICAgICAgICAgdGhpcy5nbFN0YXRlLnByZW11bHRpcGx5QWxwaGEgPSB0aGlzLnByZW11bHRpcGx5QWxwaGE7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAodGhpcy51bnBhY2tBbGlnbm1lbnQgIT09IHRoaXMuZ2xTdGF0ZS51bnBhY2tBbGlnbm1lbnQpIHtcbiAgICAgICAgICAgIHRoaXMuZ2wucGl4ZWxTdG9yZWkodGhpcy5nbC5VTlBBQ0tfQUxJR05NRU5ULCB0aGlzLnVucGFja0FsaWdubWVudCk7XG4gICAgICAgICAgICB0aGlzLmdsU3RhdGUudW5wYWNrQWxpZ25tZW50ID0gdGhpcy51bnBhY2tBbGlnbm1lbnQ7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAodGhpcy5taW5GaWx0ZXIgIT09IHRoaXMuc3RhdGUubWluRmlsdGVyKSB7XG4gICAgICAgICAgICB0aGlzLmdsLnRleFBhcmFtZXRlcmkodGhpcy50YXJnZXQsIHRoaXMuZ2wuVEVYVFVSRV9NSU5fRklMVEVSLCB0aGlzLm1pbkZpbHRlcik7XG4gICAgICAgICAgICB0aGlzLnN0YXRlLm1pbkZpbHRlciA9IHRoaXMubWluRmlsdGVyO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMubWFnRmlsdGVyICE9PSB0aGlzLnN0YXRlLm1hZ0ZpbHRlcikge1xuICAgICAgICAgICAgdGhpcy5nbC50ZXhQYXJhbWV0ZXJpKHRoaXMudGFyZ2V0LCB0aGlzLmdsLlRFWFRVUkVfTUFHX0ZJTFRFUiwgdGhpcy5tYWdGaWx0ZXIpO1xuICAgICAgICAgICAgdGhpcy5zdGF0ZS5tYWdGaWx0ZXIgPSB0aGlzLm1hZ0ZpbHRlcjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh0aGlzLndyYXBTICE9PSB0aGlzLnN0YXRlLndyYXBTKSB7XG4gICAgICAgICAgICB0aGlzLmdsLnRleFBhcmFtZXRlcmkodGhpcy50YXJnZXQsIHRoaXMuZ2wuVEVYVFVSRV9XUkFQX1MsIHRoaXMud3JhcFMpO1xuICAgICAgICAgICAgdGhpcy5zdGF0ZS53cmFwUyA9IHRoaXMud3JhcFM7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAodGhpcy53cmFwVCAhPT0gdGhpcy5zdGF0ZS53cmFwVCkge1xuICAgICAgICAgICAgdGhpcy5nbC50ZXhQYXJhbWV0ZXJpKHRoaXMudGFyZ2V0LCB0aGlzLmdsLlRFWFRVUkVfV1JBUF9ULCB0aGlzLndyYXBUKTtcbiAgICAgICAgICAgIHRoaXMuc3RhdGUud3JhcFQgPSB0aGlzLndyYXBUO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMud3JhcFIgIT09IHRoaXMuc3RhdGUud3JhcFIpIHtcbiAgICAgICAgICAgIHRoaXMuZ2wudGV4UGFyYW1ldGVyaSh0aGlzLnRhcmdldCwgdGhpcy5nbC5URVhUVVJFX1dSQVBfUiwgdGhpcy53cmFwUik7XG4gICAgICAgICAgICB0aGlzLnN0YXRlLndyYXBSID0gdGhpcy53cmFwUjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh0aGlzLmFuaXNvdHJvcHkgJiYgdGhpcy5hbmlzb3Ryb3B5ICE9PSB0aGlzLnN0YXRlLmFuaXNvdHJvcHkpIHtcbiAgICAgICAgICAgIHRoaXMuZ2wudGV4UGFyYW1ldGVyZih0aGlzLnRhcmdldCwgdGhpcy5nbC5yZW5kZXJlci5nZXRFeHRlbnNpb24oJ0VYVF90ZXh0dXJlX2ZpbHRlcl9hbmlzb3Ryb3BpYycpLlRFWFRVUkVfTUFYX0FOSVNPVFJPUFlfRVhULCB0aGlzLmFuaXNvdHJvcHkpO1xuICAgICAgICAgICAgdGhpcy5zdGF0ZS5hbmlzb3Ryb3B5ID0gdGhpcy5hbmlzb3Ryb3B5O1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMuaW1hZ2UpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLmltYWdlLndpZHRoKSB7XG4gICAgICAgICAgICAgICAgdGhpcy53aWR0aCA9IHRoaXMuaW1hZ2Uud2lkdGg7XG4gICAgICAgICAgICAgICAgdGhpcy5oZWlnaHQgPSB0aGlzLmltYWdlLmhlaWdodDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKHRoaXMudGFyZ2V0ID09PSB0aGlzLmdsLlRFWFRVUkVfQ1VCRV9NQVApIHtcbiAgICAgICAgICAgICAgICAvLyBGb3IgY3ViZSBtYXBzXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCA2OyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5nbC50ZXhJbWFnZTJEKHRoaXMuZ2wuVEVYVFVSRV9DVUJFX01BUF9QT1NJVElWRV9YICsgaSwgdGhpcy5sZXZlbCwgdGhpcy5pbnRlcm5hbEZvcm1hdCwgdGhpcy5mb3JtYXQsIHRoaXMudHlwZSwgdGhpcy5pbWFnZVtpXSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIGlmIChBcnJheUJ1ZmZlci5pc1ZpZXcodGhpcy5pbWFnZSkpIHtcbiAgICAgICAgICAgICAgICAvLyBEYXRhIHRleHR1cmVcbiAgICAgICAgICAgICAgICBpZiAodGhpcy50YXJnZXQgPT09IHRoaXMuZ2wuVEVYVFVSRV8yRCkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmdsLnRleEltYWdlMkQodGhpcy50YXJnZXQsIHRoaXMubGV2ZWwsIHRoaXMuaW50ZXJuYWxGb3JtYXQsIHRoaXMud2lkdGgsIHRoaXMuaGVpZ2h0LCAwLCB0aGlzLmZvcm1hdCwgdGhpcy50eXBlLCB0aGlzLmltYWdlKTtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHRoaXMudGFyZ2V0ID09PSB0aGlzLmdsLlRFWFRVUkVfMkRfQVJSQVkgfHwgdGhpcy50YXJnZXQgPT09IHRoaXMuZ2wuVEVYVFVSRV8zRCkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmdsLnRleEltYWdlM0QodGhpcy50YXJnZXQsIHRoaXMubGV2ZWwsIHRoaXMuaW50ZXJuYWxGb3JtYXQsIHRoaXMud2lkdGgsIHRoaXMuaGVpZ2h0LCB0aGlzLmxlbmd0aCwgMCwgdGhpcy5mb3JtYXQsIHRoaXMudHlwZSwgdGhpcy5pbWFnZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLmltYWdlLmlzQ29tcHJlc3NlZFRleHR1cmUpIHtcbiAgICAgICAgICAgICAgICAvLyBDb21wcmVzc2VkIHRleHR1cmVcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBsZXZlbCA9IDA7IGxldmVsIDwgdGhpcy5pbWFnZS5sZW5ndGg7IGxldmVsKyspIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5nbC5jb21wcmVzc2VkVGV4SW1hZ2UyRCh0aGlzLnRhcmdldCwgbGV2ZWwsIHRoaXMuaW50ZXJuYWxGb3JtYXQsIHRoaXMuaW1hZ2VbbGV2ZWxdLndpZHRoLCB0aGlzLmltYWdlW2xldmVsXS5oZWlnaHQsIDAsIHRoaXMuaW1hZ2VbbGV2ZWxdLmRhdGEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgLy8gUmVndWxhciB0ZXh0dXJlXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMudGFyZ2V0ID09PSB0aGlzLmdsLlRFWFRVUkVfMkQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5nbC50ZXhJbWFnZTJEKHRoaXMudGFyZ2V0LCB0aGlzLmxldmVsLCB0aGlzLmludGVybmFsRm9ybWF0LCB0aGlzLmZvcm1hdCwgdGhpcy50eXBlLCB0aGlzLmltYWdlKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmdsLnRleEltYWdlM0QodGhpcy50YXJnZXQsIHRoaXMubGV2ZWwsIHRoaXMuaW50ZXJuYWxGb3JtYXQsIHRoaXMud2lkdGgsIHRoaXMuaGVpZ2h0LCB0aGlzLmxlbmd0aCwgMCwgdGhpcy5mb3JtYXQsIHRoaXMudHlwZSwgdGhpcy5pbWFnZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAodGhpcy5nZW5lcmF0ZU1pcG1hcHMpIHtcbiAgICAgICAgICAgICAgICAvLyBGb3IgV2ViR0wxLCBpZiBub3QgYSBwb3dlciBvZiAyLCB0dXJuIG9mZiBtaXBzLCBzZXQgd3JhcHBpbmcgdG8gY2xhbXAgdG8gZWRnZSBhbmQgbWluRmlsdGVyIHRvIGxpbmVhclxuICAgICAgICAgICAgICAgIGlmICghdGhpcy5nbC5yZW5kZXJlci5pc1dlYmdsMiAmJiAoIWlzUG93ZXJPZjIodGhpcy5pbWFnZS53aWR0aCkgfHwgIWlzUG93ZXJPZjIodGhpcy5pbWFnZS5oZWlnaHQpKSkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmdlbmVyYXRlTWlwbWFwcyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLndyYXBTID0gdGhpcy53cmFwVCA9IHRoaXMuZ2wuQ0xBTVBfVE9fRURHRTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5taW5GaWx0ZXIgPSB0aGlzLmdsLkxJTkVBUjtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmdsLmdlbmVyYXRlTWlwbWFwKHRoaXMudGFyZ2V0KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIENhbGxiYWNrIGZvciB3aGVuIGRhdGEgaXMgcHVzaGVkIHRvIEdQVVxuICAgICAgICAgICAgdGhpcy5vblVwZGF0ZSAmJiB0aGlzLm9uVXBkYXRlKCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBpZiAodGhpcy50YXJnZXQgPT09IHRoaXMuZ2wuVEVYVFVSRV9DVUJFX01BUCkge1xuICAgICAgICAgICAgICAgIC8vIFVwbG9hZCBlbXB0eSBwaXhlbCBmb3IgZWFjaCBzaWRlIHdoaWxlIG5vIGltYWdlIHRvIGF2b2lkIGVycm9ycyB3aGlsZSBpbWFnZSBvciB2aWRlbyBsb2FkaW5nXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCA2OyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5nbC50ZXhJbWFnZTJEKHRoaXMuZ2wuVEVYVFVSRV9DVUJFX01BUF9QT1NJVElWRV9YICsgaSwgMCwgdGhpcy5nbC5SR0JBLCAxLCAxLCAwLCB0aGlzLmdsLlJHQkEsIHRoaXMuZ2wuVU5TSUdORURfQllURSwgZW1wdHlQaXhlbCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLndpZHRoKSB7XG4gICAgICAgICAgICAgICAgLy8gaW1hZ2UgaW50ZW50aW9uYWxseSBsZWZ0IG51bGwgZm9yIFJlbmRlclRhcmdldFxuICAgICAgICAgICAgICAgIGlmICh0aGlzLnRhcmdldCA9PT0gdGhpcy5nbC5URVhUVVJFXzJEKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZ2wudGV4SW1hZ2UyRCh0aGlzLnRhcmdldCwgdGhpcy5sZXZlbCwgdGhpcy5pbnRlcm5hbEZvcm1hdCwgdGhpcy53aWR0aCwgdGhpcy5oZWlnaHQsIDAsIHRoaXMuZm9ybWF0LCB0aGlzLnR5cGUsIG51bGwpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZ2wudGV4SW1hZ2UzRCh0aGlzLnRhcmdldCwgdGhpcy5sZXZlbCwgdGhpcy5pbnRlcm5hbEZvcm1hdCwgdGhpcy53aWR0aCwgdGhpcy5oZWlnaHQsIHRoaXMubGVuZ3RoLCAwLCB0aGlzLmZvcm1hdCwgdGhpcy50eXBlLCBudWxsKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIFVwbG9hZCBlbXB0eSBwaXhlbCBpZiBubyBpbWFnZSB0byBhdm9pZCBlcnJvcnMgd2hpbGUgaW1hZ2Ugb3IgdmlkZW8gbG9hZGluZ1xuICAgICAgICAgICAgICAgIHRoaXMuZ2wudGV4SW1hZ2UyRCh0aGlzLnRhcmdldCwgMCwgdGhpcy5nbC5SR0JBLCAxLCAxLCAwLCB0aGlzLmdsLlJHQkEsIHRoaXMuZ2wuVU5TSUdORURfQllURSwgZW1wdHlQaXhlbCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zdG9yZS5pbWFnZSA9IHRoaXMuaW1hZ2U7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgVGV4dHVyZSB9IGZyb20gJy4vVGV4dHVyZS5qcydcblxuZXhwb3J0IGNsYXNzIFJlbmRlclRhcmdldCB7XG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIGdsLFxuICAgICAgICB7XG4gICAgICAgICAgICB3aWR0aCA9IGdsLmNhbnZhcy53aWR0aCxcbiAgICAgICAgICAgIGhlaWdodCA9IGdsLmNhbnZhcy5oZWlnaHQsXG4gICAgICAgICAgICB0YXJnZXQgPSBnbC5GUkFNRUJVRkZFUixcbiAgICAgICAgICAgIGNvbG9yID0gMSwgLy8gbnVtYmVyIG9mIGNvbG9yIGF0dGFjaG1lbnRzXG4gICAgICAgICAgICBkZXB0aCA9IHRydWUsXG4gICAgICAgICAgICBzdGVuY2lsID0gZmFsc2UsXG4gICAgICAgICAgICBkZXB0aFRleHR1cmUgPSBmYWxzZSxcbiAgICAgICAgICAgIHdyYXBTID0gZ2wuQ0xBTVBfVE9fRURHRSxcbiAgICAgICAgICAgIHdyYXBUID0gZ2wuQ0xBTVBfVE9fRURHRSxcbiAgICAgICAgICAgIHdyYXBSID0gZ2wuQ0xBTVBfVE9fRURHRSxcbiAgICAgICAgICAgIG1pbkZpbHRlciA9IGdsLkxJTkVBUixcbiAgICAgICAgICAgIG1hZ0ZpbHRlciA9IG1pbkZpbHRlcixcbiAgICAgICAgICAgIHR5cGUgPSBnbC5VTlNJR05FRF9CWVRFLFxuICAgICAgICAgICAgZm9ybWF0ID0gZ2wuUkdCQSxcbiAgICAgICAgICAgIGludGVybmFsRm9ybWF0ID0gZm9ybWF0LFxuICAgICAgICAgICAgdW5wYWNrQWxpZ25tZW50LFxuICAgICAgICAgICAgcHJlbXVsdGlwbHlBbHBoYSxcbiAgICAgICAgfSA9IHt9XG4gICAgKSB7XG4gICAgICAgIHRoaXMuZ2wgPSBnbDtcbiAgICAgICAgdGhpcy53aWR0aCA9IHdpZHRoO1xuICAgICAgICB0aGlzLmhlaWdodCA9IGhlaWdodDtcbiAgICAgICAgdGhpcy5kZXB0aCA9IGRlcHRoO1xuICAgICAgICB0aGlzLnN0ZW5jaWwgPSBzdGVuY2lsO1xuICAgICAgICB0aGlzLmJ1ZmZlciA9IHRoaXMuZ2wuY3JlYXRlRnJhbWVidWZmZXIoKTtcbiAgICAgICAgdGhpcy50YXJnZXQgPSB0YXJnZXQ7XG4gICAgICAgIHRoaXMuZ2wucmVuZGVyZXIuYmluZEZyYW1lYnVmZmVyKHRoaXMpO1xuXG4gICAgICAgIHRoaXMudGV4dHVyZXMgPSBbXTtcbiAgICAgICAgY29uc3QgZHJhd0J1ZmZlcnMgPSBbXTtcblxuICAgICAgICAvLyBjcmVhdGUgYW5kIGF0dGFjaCByZXF1aXJlZCBudW0gb2YgY29sb3IgdGV4dHVyZXNcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb2xvcjsgaSsrKSB7XG4gICAgICAgICAgICB0aGlzLnRleHR1cmVzLnB1c2goXG4gICAgICAgICAgICAgICAgbmV3IFRleHR1cmUoZ2wsIHtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGgsXG4gICAgICAgICAgICAgICAgICAgIGhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgd3JhcFMsXG4gICAgICAgICAgICAgICAgICAgIHdyYXBULFxuICAgICAgICAgICAgICAgICAgICB3cmFwUixcbiAgICAgICAgICAgICAgICAgICAgbWluRmlsdGVyLFxuICAgICAgICAgICAgICAgICAgICBtYWdGaWx0ZXIsXG4gICAgICAgICAgICAgICAgICAgIHR5cGUsXG4gICAgICAgICAgICAgICAgICAgIGZvcm1hdCxcbiAgICAgICAgICAgICAgICAgICAgaW50ZXJuYWxGb3JtYXQsXG4gICAgICAgICAgICAgICAgICAgIHVucGFja0FsaWdubWVudCxcbiAgICAgICAgICAgICAgICAgICAgcHJlbXVsdGlwbHlBbHBoYSxcbiAgICAgICAgICAgICAgICAgICAgZmxpcFk6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICBnZW5lcmF0ZU1pcG1hcHM6IGZhbHNlLFxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgdGhpcy50ZXh0dXJlc1tpXS51cGRhdGUoKTtcbiAgICAgICAgICAgIHRoaXMuZ2wuZnJhbWVidWZmZXJUZXh0dXJlMkQodGhpcy50YXJnZXQsIHRoaXMuZ2wuQ09MT1JfQVRUQUNITUVOVDAgKyBpLCB0aGlzLmdsLlRFWFRVUkVfMkQsIHRoaXMudGV4dHVyZXNbaV0udGV4dHVyZSwgMCAvKiBsZXZlbCAqLyk7XG4gICAgICAgICAgICBkcmF3QnVmZmVycy5wdXNoKHRoaXMuZ2wuQ09MT1JfQVRUQUNITUVOVDAgKyBpKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIEZvciBtdWx0aS1yZW5kZXIgdGFyZ2V0cyBzaGFkZXIgYWNjZXNzXG4gICAgICAgIGlmIChkcmF3QnVmZmVycy5sZW5ndGggPiAxKSB0aGlzLmdsLnJlbmRlcmVyLmRyYXdCdWZmZXJzKGRyYXdCdWZmZXJzKTtcblxuICAgICAgICAvLyBhbGlhcyBmb3IgbWFqb3JpdHkgb2YgdXNlIGNhc2VzXG4gICAgICAgIHRoaXMudGV4dHVyZSA9IHRoaXMudGV4dHVyZXNbMF07XG5cbiAgICAgICAgLy8gbm90ZSBkZXB0aCB0ZXh0dXJlcyBicmVhayBzdGVuY2lsIC0gc28gY2FuJ3QgdXNlIHRvZ2V0aGVyXG4gICAgICAgIGlmIChkZXB0aFRleHR1cmUgJiYgKHRoaXMuZ2wucmVuZGVyZXIuaXNXZWJnbDIgfHwgdGhpcy5nbC5yZW5kZXJlci5nZXRFeHRlbnNpb24oJ1dFQkdMX2RlcHRoX3RleHR1cmUnKSkpIHtcbiAgICAgICAgICAgIHRoaXMuZGVwdGhUZXh0dXJlID0gbmV3IFRleHR1cmUoZ2wsIHtcbiAgICAgICAgICAgICAgICB3aWR0aCxcbiAgICAgICAgICAgICAgICBoZWlnaHQsXG4gICAgICAgICAgICAgICAgbWluRmlsdGVyOiB0aGlzLmdsLk5FQVJFU1QsXG4gICAgICAgICAgICAgICAgbWFnRmlsdGVyOiB0aGlzLmdsLk5FQVJFU1QsXG4gICAgICAgICAgICAgICAgZm9ybWF0OiB0aGlzLnN0ZW5jaWwgPyB0aGlzLmdsLkRFUFRIX1NURU5DSUwgOiB0aGlzLmdsLkRFUFRIX0NPTVBPTkVOVCxcbiAgICAgICAgICAgICAgICBpbnRlcm5hbEZvcm1hdDogZ2wucmVuZGVyZXIuaXNXZWJnbDIgPyAodGhpcy5zdGVuY2lsID8gdGhpcy5nbC5ERVBUSDI0X1NURU5DSUw4IDogdGhpcy5nbC5ERVBUSF9DT01QT05FTlQxNikgOiB0aGlzLmdsLkRFUFRIX0NPTVBPTkVOVCxcbiAgICAgICAgICAgICAgICB0eXBlOiB0aGlzLnN0ZW5jaWwgPyB0aGlzLmdsLlVOU0lHTkVEX0lOVF8yNF84IDogdGhpcy5nbC5VTlNJR05FRF9JTlQsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuZGVwdGhUZXh0dXJlLnVwZGF0ZSgpO1xuICAgICAgICAgICAgdGhpcy5nbC5mcmFtZWJ1ZmZlclRleHR1cmUyRCh0aGlzLnRhcmdldCwgdGhpcy5zdGVuY2lsID8gdGhpcy5nbC5ERVBUSF9TVEVOQ0lMX0FUVEFDSE1FTlQgOiB0aGlzLmdsLkRFUFRIX0FUVEFDSE1FTlQsIHRoaXMuZ2wuVEVYVFVSRV8yRCwgdGhpcy5kZXB0aFRleHR1cmUudGV4dHVyZSwgMCAvKiBsZXZlbCAqLyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBSZW5kZXIgYnVmZmVyc1xuICAgICAgICAgICAgaWYgKGRlcHRoICYmICFzdGVuY2lsKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5kZXB0aEJ1ZmZlciA9IHRoaXMuZ2wuY3JlYXRlUmVuZGVyYnVmZmVyKCk7XG4gICAgICAgICAgICAgICAgdGhpcy5nbC5iaW5kUmVuZGVyYnVmZmVyKHRoaXMuZ2wuUkVOREVSQlVGRkVSLCB0aGlzLmRlcHRoQnVmZmVyKTtcbiAgICAgICAgICAgICAgICB0aGlzLmdsLnJlbmRlcmJ1ZmZlclN0b3JhZ2UodGhpcy5nbC5SRU5ERVJCVUZGRVIsIHRoaXMuZ2wuREVQVEhfQ09NUE9ORU5UMTYsIHdpZHRoLCBoZWlnaHQpO1xuICAgICAgICAgICAgICAgIHRoaXMuZ2wuZnJhbWVidWZmZXJSZW5kZXJidWZmZXIodGhpcy50YXJnZXQsIHRoaXMuZ2wuREVQVEhfQVRUQUNITUVOVCwgdGhpcy5nbC5SRU5ERVJCVUZGRVIsIHRoaXMuZGVwdGhCdWZmZXIpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoc3RlbmNpbCAmJiAhZGVwdGgpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnN0ZW5jaWxCdWZmZXIgPSB0aGlzLmdsLmNyZWF0ZVJlbmRlcmJ1ZmZlcigpO1xuICAgICAgICAgICAgICAgIHRoaXMuZ2wuYmluZFJlbmRlcmJ1ZmZlcih0aGlzLmdsLlJFTkRFUkJVRkZFUiwgdGhpcy5zdGVuY2lsQnVmZmVyKTtcbiAgICAgICAgICAgICAgICB0aGlzLmdsLnJlbmRlcmJ1ZmZlclN0b3JhZ2UodGhpcy5nbC5SRU5ERVJCVUZGRVIsIHRoaXMuZ2wuU1RFTkNJTF9JTkRFWDgsIHdpZHRoLCBoZWlnaHQpO1xuICAgICAgICAgICAgICAgIHRoaXMuZ2wuZnJhbWVidWZmZXJSZW5kZXJidWZmZXIodGhpcy50YXJnZXQsIHRoaXMuZ2wuU1RFTkNJTF9BVFRBQ0hNRU5ULCB0aGlzLmdsLlJFTkRFUkJVRkZFUiwgdGhpcy5zdGVuY2lsQnVmZmVyKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKGRlcHRoICYmIHN0ZW5jaWwpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmRlcHRoU3RlbmNpbEJ1ZmZlciA9IHRoaXMuZ2wuY3JlYXRlUmVuZGVyYnVmZmVyKCk7XG4gICAgICAgICAgICAgICAgdGhpcy5nbC5iaW5kUmVuZGVyYnVmZmVyKHRoaXMuZ2wuUkVOREVSQlVGRkVSLCB0aGlzLmRlcHRoU3RlbmNpbEJ1ZmZlcik7XG4gICAgICAgICAgICAgICAgdGhpcy5nbC5yZW5kZXJidWZmZXJTdG9yYWdlKHRoaXMuZ2wuUkVOREVSQlVGRkVSLCB0aGlzLmdsLkRFUFRIX1NURU5DSUwsIHdpZHRoLCBoZWlnaHQpO1xuICAgICAgICAgICAgICAgIHRoaXMuZ2wuZnJhbWVidWZmZXJSZW5kZXJidWZmZXIodGhpcy50YXJnZXQsIHRoaXMuZ2wuREVQVEhfU1RFTkNJTF9BVFRBQ0hNRU5ULCB0aGlzLmdsLlJFTkRFUkJVRkZFUiwgdGhpcy5kZXB0aFN0ZW5jaWxCdWZmZXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5nbC5yZW5kZXJlci5iaW5kRnJhbWVidWZmZXIoeyB0YXJnZXQ6IHRoaXMudGFyZ2V0IH0pO1xuICAgIH1cblxuICAgIHNldFNpemUod2lkdGgsIGhlaWdodCkge1xuICAgICAgICBpZiAodGhpcy53aWR0aCA9PT0gd2lkdGggJiYgdGhpcy5oZWlnaHQgPT09IGhlaWdodCkgcmV0dXJuO1xuXG4gICAgICAgIHRoaXMud2lkdGggPSB3aWR0aDtcbiAgICAgICAgdGhpcy5oZWlnaHQgPSBoZWlnaHQ7XG4gICAgICAgIHRoaXMuZ2wucmVuZGVyZXIuYmluZEZyYW1lYnVmZmVyKHRoaXMpO1xuXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy50ZXh0dXJlcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgdGhpcy50ZXh0dXJlc1tpXS53aWR0aCA9IHdpZHRoO1xuICAgICAgICAgICAgdGhpcy50ZXh0dXJlc1tpXS5oZWlnaHQgPSBoZWlnaHQ7XG4gICAgICAgICAgICB0aGlzLnRleHR1cmVzW2ldLm5lZWRzVXBkYXRlID0gdHJ1ZTtcbiAgICAgICAgICAgIHRoaXMudGV4dHVyZXNbaV0udXBkYXRlKCk7XG4gICAgICAgICAgICB0aGlzLmdsLmZyYW1lYnVmZmVyVGV4dHVyZTJEKHRoaXMudGFyZ2V0LCB0aGlzLmdsLkNPTE9SX0FUVEFDSE1FTlQwICsgaSwgdGhpcy5nbC5URVhUVVJFXzJELCB0aGlzLnRleHR1cmVzW2ldLnRleHR1cmUsIDAgLyogbGV2ZWwgKi8pO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMuZGVwdGhUZXh0dXJlKSB7XG4gICAgICAgICAgICB0aGlzLmRlcHRoVGV4dHVyZS53aWR0aCA9IHdpZHRoO1xuICAgICAgICAgICAgdGhpcy5kZXB0aFRleHR1cmUuaGVpZ2h0ID0gaGVpZ2h0O1xuICAgICAgICAgICAgdGhpcy5kZXB0aFRleHR1cmUubmVlZHNVcGRhdGUgPSB0cnVlO1xuICAgICAgICAgICAgdGhpcy5kZXB0aFRleHR1cmUudXBkYXRlKCk7XG4gICAgICAgICAgICB0aGlzLmdsLmZyYW1lYnVmZmVyVGV4dHVyZTJEKHRoaXMudGFyZ2V0LCB0aGlzLmdsLkRFUFRIX0FUVEFDSE1FTlQsIHRoaXMuZ2wuVEVYVFVSRV8yRCwgdGhpcy5kZXB0aFRleHR1cmUudGV4dHVyZSwgMCAvKiBsZXZlbCAqLyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBpZiAodGhpcy5kZXB0aEJ1ZmZlcikge1xuICAgICAgICAgICAgICAgIHRoaXMuZ2wuYmluZFJlbmRlcmJ1ZmZlcih0aGlzLmdsLlJFTkRFUkJVRkZFUiwgdGhpcy5kZXB0aEJ1ZmZlcik7XG4gICAgICAgICAgICAgICAgdGhpcy5nbC5yZW5kZXJidWZmZXJTdG9yYWdlKHRoaXMuZ2wuUkVOREVSQlVGRkVSLCB0aGlzLmdsLkRFUFRIX0NPTVBPTkVOVDE2LCB3aWR0aCwgaGVpZ2h0KTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKHRoaXMuc3RlbmNpbEJ1ZmZlcikge1xuICAgICAgICAgICAgICAgIHRoaXMuZ2wuYmluZFJlbmRlcmJ1ZmZlcih0aGlzLmdsLlJFTkRFUkJVRkZFUiwgdGhpcy5zdGVuY2lsQnVmZmVyKTtcbiAgICAgICAgICAgICAgICB0aGlzLmdsLnJlbmRlcmJ1ZmZlclN0b3JhZ2UodGhpcy5nbC5SRU5ERVJCVUZGRVIsIHRoaXMuZ2wuU1RFTkNJTF9JTkRFWDgsIHdpZHRoLCBoZWlnaHQpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAodGhpcy5kZXB0aFN0ZW5jaWxCdWZmZXIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmdsLmJpbmRSZW5kZXJidWZmZXIodGhpcy5nbC5SRU5ERVJCVUZGRVIsIHRoaXMuZGVwdGhTdGVuY2lsQnVmZmVyKTtcbiAgICAgICAgICAgICAgICB0aGlzLmdsLnJlbmRlcmJ1ZmZlclN0b3JhZ2UodGhpcy5nbC5SRU5ERVJCVUZGRVIsIHRoaXMuZ2wuREVQVEhfU1RFTkNJTCwgd2lkdGgsIGhlaWdodCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLmdsLnJlbmRlcmVyLmJpbmRGcmFtZWJ1ZmZlcih7IHRhcmdldDogdGhpcy50YXJnZXQgfSk7XG4gICAgfVxufVxuIiwiY29uc3QgTkFNRVMgPSB7XG4gICAgYmxhY2s6ICcjMDAwMDAwJyxcbiAgICB3aGl0ZTogJyNmZmZmZmYnLFxuICAgIHJlZDogJyNmZjAwMDAnLFxuICAgIGdyZWVuOiAnIzAwZmYwMCcsXG4gICAgYmx1ZTogJyMwMDAwZmYnLFxuICAgIGZ1Y2hzaWE6ICcjZmYwMGZmJyxcbiAgICBjeWFuOiAnIzAwZmZmZicsXG4gICAgeWVsbG93OiAnI2ZmZmYwMCcsXG4gICAgb3JhbmdlOiAnI2ZmODAwMCcsXG59O1xuXG5leHBvcnQgZnVuY3Rpb24gaGV4VG9SR0IoaGV4KSB7XG4gICAgaWYgKGhleC5sZW5ndGggPT09IDQpIGhleCA9IGhleFswXSArIGhleFsxXSArIGhleFsxXSArIGhleFsyXSArIGhleFsyXSArIGhleFszXSArIGhleFszXTtcbiAgICBjb25zdCByZ2IgPSAvXiM/KFthLWZcXGRdezJ9KShbYS1mXFxkXXsyfSkoW2EtZlxcZF17Mn0pJC9pLmV4ZWMoaGV4KTtcbiAgICBpZiAoIXJnYikgY29uc29sZS53YXJuKGBVbmFibGUgdG8gY29udmVydCBoZXggc3RyaW5nICR7aGV4fSB0byByZ2IgdmFsdWVzYCk7XG4gICAgcmV0dXJuIFtwYXJzZUludChyZ2JbMV0sIDE2KSAvIDI1NSwgcGFyc2VJbnQocmdiWzJdLCAxNikgLyAyNTUsIHBhcnNlSW50KHJnYlszXSwgMTYpIC8gMjU1XTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG51bWJlclRvUkdCKG51bSkge1xuICAgIG51bSA9IHBhcnNlSW50KG51bSk7XG4gICAgcmV0dXJuIFsoKG51bSA+PiAxNikgJiAyNTUpIC8gMjU1LCAoKG51bSA+PiA4KSAmIDI1NSkgLyAyNTUsIChudW0gJiAyNTUpIC8gMjU1XTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlQ29sb3IoY29sb3IpIHtcbiAgICAvLyBFbXB0eVxuICAgIGlmIChjb2xvciA9PT0gdW5kZWZpbmVkKSByZXR1cm4gWzAsIDAsIDBdO1xuXG4gICAgLy8gRGVjaW1hbFxuICAgIGlmIChhcmd1bWVudHMubGVuZ3RoID09PSAzKSByZXR1cm4gYXJndW1lbnRzO1xuXG4gICAgLy8gTnVtYmVyXG4gICAgaWYgKCFpc05hTihjb2xvcikpIHJldHVybiBudW1iZXJUb1JHQihjb2xvcik7XG5cbiAgICAvLyBIZXhcbiAgICBpZiAoY29sb3JbMF0gPT09ICcjJykgcmV0dXJuIGhleFRvUkdCKGNvbG9yKTtcblxuICAgIC8vIE5hbWVzXG4gICAgaWYgKE5BTUVTW2NvbG9yLnRvTG93ZXJDYXNlKCldKSByZXR1cm4gaGV4VG9SR0IoTkFNRVNbY29sb3IudG9Mb3dlckNhc2UoKV0pO1xuXG4gICAgY29uc29sZS53YXJuKCdDb2xvciBmb3JtYXQgbm90IHJlY29nbmlzZWQnKTtcbiAgICByZXR1cm4gWzAsIDAsIDBdO1xufVxuIiwiaW1wb3J0ICogYXMgQ29sb3JGdW5jIGZyb20gJy4vZnVuY3Rpb25zL0NvbG9yRnVuYy5qcyc7XG5cbi8vIENvbG9yIHN0b3JlZCBhcyBhbiBhcnJheSBvZiBSR0IgZGVjaW1hbCB2YWx1ZXMgKGJldHdlZW4gMCA+IDEpXG4vLyBDb25zdHJ1Y3RvciBhbmQgc2V0IG1ldGhvZCBhY2NlcHQgZm9sbG93aW5nIGZvcm1hdHM6XG4vLyBuZXcgQ29sb3IoKSAtIEVtcHR5IChkZWZhdWx0cyB0byBibGFjaylcbi8vIG5ldyBDb2xvcihbMC4yLCAwLjQsIDEuMF0pIC0gRGVjaW1hbCBBcnJheSAob3IgYW5vdGhlciBDb2xvciBpbnN0YW5jZSlcbi8vIG5ldyBDb2xvcigwLjcsIDAuMCwgMC4xKSAtIERlY2ltYWwgUkdCIHZhbHVlc1xuLy8gbmV3IENvbG9yKCcjZmYwMDAwJykgLSBIZXggc3RyaW5nXG4vLyBuZXcgQ29sb3IoJyNjY2MnKSAtIFNob3J0LWhhbmQgSGV4IHN0cmluZ1xuLy8gbmV3IENvbG9yKDB4NGYyN2U4KSAtIE51bWJlclxuLy8gbmV3IENvbG9yKCdyZWQnKSAtIENvbG9yIG5hbWUgc3RyaW5nIChzaG9ydCBsaXN0IGluIENvbG9yRnVuYy5qcylcblxuZXhwb3J0IGNsYXNzIENvbG9yIGV4dGVuZHMgQXJyYXkge1xuICAgIGNvbnN0cnVjdG9yKGNvbG9yKSB7XG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KGNvbG9yKSkgcmV0dXJuIHN1cGVyKC4uLmNvbG9yKTtcbiAgICAgICAgcmV0dXJuIHN1cGVyKC4uLkNvbG9yRnVuYy5wYXJzZUNvbG9yKC4uLmFyZ3VtZW50cykpO1xuICAgIH1cblxuICAgIGdldCByKCkge1xuICAgICAgICByZXR1cm4gdGhpc1swXTtcbiAgICB9XG5cbiAgICBnZXQgZygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXNbMV07XG4gICAgfVxuXG4gICAgZ2V0IGIoKSB7XG4gICAgICAgIHJldHVybiB0aGlzWzJdO1xuICAgIH1cblxuICAgIHNldCByKHYpIHtcbiAgICAgICAgdGhpc1swXSA9IHY7XG4gICAgfVxuXG4gICAgc2V0IGcodikge1xuICAgICAgICB0aGlzWzFdID0gdjtcbiAgICB9XG5cbiAgICBzZXQgYih2KSB7XG4gICAgICAgIHRoaXNbMl0gPSB2O1xuICAgIH1cblxuICAgIHNldChjb2xvcikge1xuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShjb2xvcikpIHJldHVybiB0aGlzLmNvcHkoY29sb3IpO1xuICAgICAgICByZXR1cm4gdGhpcy5jb3B5KENvbG9yRnVuYy5wYXJzZUNvbG9yKC4uLmFyZ3VtZW50cykpO1xuICAgIH1cblxuICAgIGNvcHkodikge1xuICAgICAgICB0aGlzWzBdID0gdlswXTtcbiAgICAgICAgdGhpc1sxXSA9IHZbMV07XG4gICAgICAgIHRoaXNbMl0gPSB2WzJdO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG59XG4iLCJjb25zdCBFUFNJTE9OID0gMC4wMDAwMDE7XG5cbi8qKlxuICogQ29weSB0aGUgdmFsdWVzIGZyb20gb25lIHZlYzIgdG8gYW5vdGhlclxuICpcbiAqIEBwYXJhbSB7dmVjMn0gb3V0IHRoZSByZWNlaXZpbmcgdmVjdG9yXG4gKiBAcGFyYW0ge3ZlYzJ9IGEgdGhlIHNvdXJjZSB2ZWN0b3JcbiAqIEByZXR1cm5zIHt2ZWMyfSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNvcHkob3V0LCBhKSB7XG4gICAgb3V0WzBdID0gYVswXTtcbiAgICBvdXRbMV0gPSBhWzFdO1xuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogU2V0IHRoZSBjb21wb25lbnRzIG9mIGEgdmVjMiB0byB0aGUgZ2l2ZW4gdmFsdWVzXG4gKlxuICogQHBhcmFtIHt2ZWMyfSBvdXQgdGhlIHJlY2VpdmluZyB2ZWN0b3JcbiAqIEBwYXJhbSB7TnVtYmVyfSB4IFggY29tcG9uZW50XG4gKiBAcGFyYW0ge051bWJlcn0geSBZIGNvbXBvbmVudFxuICogQHJldHVybnMge3ZlYzJ9IG91dFxuICovXG5leHBvcnQgZnVuY3Rpb24gc2V0KG91dCwgeCwgeSkge1xuICAgIG91dFswXSA9IHg7XG4gICAgb3V0WzFdID0geTtcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIEFkZHMgdHdvIHZlYzInc1xuICpcbiAqIEBwYXJhbSB7dmVjMn0gb3V0IHRoZSByZWNlaXZpbmcgdmVjdG9yXG4gKiBAcGFyYW0ge3ZlYzJ9IGEgdGhlIGZpcnN0IG9wZXJhbmRcbiAqIEBwYXJhbSB7dmVjMn0gYiB0aGUgc2Vjb25kIG9wZXJhbmRcbiAqIEByZXR1cm5zIHt2ZWMyfSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGFkZChvdXQsIGEsIGIpIHtcbiAgICBvdXRbMF0gPSBhWzBdICsgYlswXTtcbiAgICBvdXRbMV0gPSBhWzFdICsgYlsxXTtcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIFN1YnRyYWN0cyB2ZWN0b3IgYiBmcm9tIHZlY3RvciBhXG4gKlxuICogQHBhcmFtIHt2ZWMyfSBvdXQgdGhlIHJlY2VpdmluZyB2ZWN0b3JcbiAqIEBwYXJhbSB7dmVjMn0gYSB0aGUgZmlyc3Qgb3BlcmFuZFxuICogQHBhcmFtIHt2ZWMyfSBiIHRoZSBzZWNvbmQgb3BlcmFuZFxuICogQHJldHVybnMge3ZlYzJ9IG91dFxuICovXG5leHBvcnQgZnVuY3Rpb24gc3VidHJhY3Qob3V0LCBhLCBiKSB7XG4gICAgb3V0WzBdID0gYVswXSAtIGJbMF07XG4gICAgb3V0WzFdID0gYVsxXSAtIGJbMV07XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBNdWx0aXBsaWVzIHR3byB2ZWMyJ3NcbiAqXG4gKiBAcGFyYW0ge3ZlYzJ9IG91dCB0aGUgcmVjZWl2aW5nIHZlY3RvclxuICogQHBhcmFtIHt2ZWMyfSBhIHRoZSBmaXJzdCBvcGVyYW5kXG4gKiBAcGFyYW0ge3ZlYzJ9IGIgdGhlIHNlY29uZCBvcGVyYW5kXG4gKiBAcmV0dXJucyB7dmVjMn0gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtdWx0aXBseShvdXQsIGEsIGIpIHtcbiAgICBvdXRbMF0gPSBhWzBdICogYlswXTtcbiAgICBvdXRbMV0gPSBhWzFdICogYlsxXTtcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIERpdmlkZXMgdHdvIHZlYzInc1xuICpcbiAqIEBwYXJhbSB7dmVjMn0gb3V0IHRoZSByZWNlaXZpbmcgdmVjdG9yXG4gKiBAcGFyYW0ge3ZlYzJ9IGEgdGhlIGZpcnN0IG9wZXJhbmRcbiAqIEBwYXJhbSB7dmVjMn0gYiB0aGUgc2Vjb25kIG9wZXJhbmRcbiAqIEByZXR1cm5zIHt2ZWMyfSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRpdmlkZShvdXQsIGEsIGIpIHtcbiAgICBvdXRbMF0gPSBhWzBdIC8gYlswXTtcbiAgICBvdXRbMV0gPSBhWzFdIC8gYlsxXTtcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIFNjYWxlcyBhIHZlYzIgYnkgYSBzY2FsYXIgbnVtYmVyXG4gKlxuICogQHBhcmFtIHt2ZWMyfSBvdXQgdGhlIHJlY2VpdmluZyB2ZWN0b3JcbiAqIEBwYXJhbSB7dmVjMn0gYSB0aGUgdmVjdG9yIHRvIHNjYWxlXG4gKiBAcGFyYW0ge051bWJlcn0gYiBhbW91bnQgdG8gc2NhbGUgdGhlIHZlY3RvciBieVxuICogQHJldHVybnMge3ZlYzJ9IG91dFxuICovXG5leHBvcnQgZnVuY3Rpb24gc2NhbGUob3V0LCBhLCBiKSB7XG4gICAgb3V0WzBdID0gYVswXSAqIGI7XG4gICAgb3V0WzFdID0gYVsxXSAqIGI7XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBDYWxjdWxhdGVzIHRoZSBldWNsaWRpYW4gZGlzdGFuY2UgYmV0d2VlbiB0d28gdmVjMidzXG4gKlxuICogQHBhcmFtIHt2ZWMyfSBhIHRoZSBmaXJzdCBvcGVyYW5kXG4gKiBAcGFyYW0ge3ZlYzJ9IGIgdGhlIHNlY29uZCBvcGVyYW5kXG4gKiBAcmV0dXJucyB7TnVtYmVyfSBkaXN0YW5jZSBiZXR3ZWVuIGEgYW5kIGJcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRpc3RhbmNlKGEsIGIpIHtcbiAgICB2YXIgeCA9IGJbMF0gLSBhWzBdLFxuICAgICAgICB5ID0gYlsxXSAtIGFbMV07XG4gICAgcmV0dXJuIE1hdGguc3FydCh4ICogeCArIHkgKiB5KTtcbn1cblxuLyoqXG4gKiBDYWxjdWxhdGVzIHRoZSBzcXVhcmVkIGV1Y2xpZGlhbiBkaXN0YW5jZSBiZXR3ZWVuIHR3byB2ZWMyJ3NcbiAqXG4gKiBAcGFyYW0ge3ZlYzJ9IGEgdGhlIGZpcnN0IG9wZXJhbmRcbiAqIEBwYXJhbSB7dmVjMn0gYiB0aGUgc2Vjb25kIG9wZXJhbmRcbiAqIEByZXR1cm5zIHtOdW1iZXJ9IHNxdWFyZWQgZGlzdGFuY2UgYmV0d2VlbiBhIGFuZCBiXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzcXVhcmVkRGlzdGFuY2UoYSwgYikge1xuICAgIHZhciB4ID0gYlswXSAtIGFbMF0sXG4gICAgICAgIHkgPSBiWzFdIC0gYVsxXTtcbiAgICByZXR1cm4geCAqIHggKyB5ICogeTtcbn1cblxuLyoqXG4gKiBDYWxjdWxhdGVzIHRoZSBsZW5ndGggb2YgYSB2ZWMyXG4gKlxuICogQHBhcmFtIHt2ZWMyfSBhIHZlY3RvciB0byBjYWxjdWxhdGUgbGVuZ3RoIG9mXG4gKiBAcmV0dXJucyB7TnVtYmVyfSBsZW5ndGggb2YgYVxuICovXG5leHBvcnQgZnVuY3Rpb24gbGVuZ3RoKGEpIHtcbiAgICB2YXIgeCA9IGFbMF0sXG4gICAgICAgIHkgPSBhWzFdO1xuICAgIHJldHVybiBNYXRoLnNxcnQoeCAqIHggKyB5ICogeSk7XG59XG5cbi8qKlxuICogQ2FsY3VsYXRlcyB0aGUgc3F1YXJlZCBsZW5ndGggb2YgYSB2ZWMyXG4gKlxuICogQHBhcmFtIHt2ZWMyfSBhIHZlY3RvciB0byBjYWxjdWxhdGUgc3F1YXJlZCBsZW5ndGggb2ZcbiAqIEByZXR1cm5zIHtOdW1iZXJ9IHNxdWFyZWQgbGVuZ3RoIG9mIGFcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNxdWFyZWRMZW5ndGgoYSkge1xuICAgIHZhciB4ID0gYVswXSxcbiAgICAgICAgeSA9IGFbMV07XG4gICAgcmV0dXJuIHggKiB4ICsgeSAqIHk7XG59XG5cbi8qKlxuICogTmVnYXRlcyB0aGUgY29tcG9uZW50cyBvZiBhIHZlYzJcbiAqXG4gKiBAcGFyYW0ge3ZlYzJ9IG91dCB0aGUgcmVjZWl2aW5nIHZlY3RvclxuICogQHBhcmFtIHt2ZWMyfSBhIHZlY3RvciB0byBuZWdhdGVcbiAqIEByZXR1cm5zIHt2ZWMyfSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG5lZ2F0ZShvdXQsIGEpIHtcbiAgICBvdXRbMF0gPSAtYVswXTtcbiAgICBvdXRbMV0gPSAtYVsxXTtcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGludmVyc2Ugb2YgdGhlIGNvbXBvbmVudHMgb2YgYSB2ZWMyXG4gKlxuICogQHBhcmFtIHt2ZWMyfSBvdXQgdGhlIHJlY2VpdmluZyB2ZWN0b3JcbiAqIEBwYXJhbSB7dmVjMn0gYSB2ZWN0b3IgdG8gaW52ZXJ0XG4gKiBAcmV0dXJucyB7dmVjMn0gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpbnZlcnNlKG91dCwgYSkge1xuICAgIG91dFswXSA9IDEuMCAvIGFbMF07XG4gICAgb3V0WzFdID0gMS4wIC8gYVsxXTtcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIE5vcm1hbGl6ZSBhIHZlYzJcbiAqXG4gKiBAcGFyYW0ge3ZlYzJ9IG91dCB0aGUgcmVjZWl2aW5nIHZlY3RvclxuICogQHBhcmFtIHt2ZWMyfSBhIHZlY3RvciB0byBub3JtYWxpemVcbiAqIEByZXR1cm5zIHt2ZWMyfSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZShvdXQsIGEpIHtcbiAgICB2YXIgeCA9IGFbMF0sXG4gICAgICAgIHkgPSBhWzFdO1xuICAgIHZhciBsZW4gPSB4ICogeCArIHkgKiB5O1xuICAgIGlmIChsZW4gPiAwKSB7XG4gICAgICAgIC8vVE9ETzogZXZhbHVhdGUgdXNlIG9mIGdsbV9pbnZzcXJ0IGhlcmU/XG4gICAgICAgIGxlbiA9IDEgLyBNYXRoLnNxcnQobGVuKTtcbiAgICB9XG4gICAgb3V0WzBdID0gYVswXSAqIGxlbjtcbiAgICBvdXRbMV0gPSBhWzFdICogbGVuO1xuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogQ2FsY3VsYXRlcyB0aGUgZG90IHByb2R1Y3Qgb2YgdHdvIHZlYzInc1xuICpcbiAqIEBwYXJhbSB7dmVjMn0gYSB0aGUgZmlyc3Qgb3BlcmFuZFxuICogQHBhcmFtIHt2ZWMyfSBiIHRoZSBzZWNvbmQgb3BlcmFuZFxuICogQHJldHVybnMge051bWJlcn0gZG90IHByb2R1Y3Qgb2YgYSBhbmQgYlxuICovXG5leHBvcnQgZnVuY3Rpb24gZG90KGEsIGIpIHtcbiAgICByZXR1cm4gYVswXSAqIGJbMF0gKyBhWzFdICogYlsxXTtcbn1cblxuLyoqXG4gKiBDb21wdXRlcyB0aGUgY3Jvc3MgcHJvZHVjdCBvZiB0d28gdmVjMidzXG4gKiBOb3RlIHRoYXQgdGhlIGNyb3NzIHByb2R1Y3QgcmV0dXJucyBhIHNjYWxhclxuICpcbiAqIEBwYXJhbSB7dmVjMn0gYSB0aGUgZmlyc3Qgb3BlcmFuZFxuICogQHBhcmFtIHt2ZWMyfSBiIHRoZSBzZWNvbmQgb3BlcmFuZFxuICogQHJldHVybnMge051bWJlcn0gY3Jvc3MgcHJvZHVjdCBvZiBhIGFuZCBiXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcm9zcyhhLCBiKSB7XG4gICAgcmV0dXJuIGFbMF0gKiBiWzFdIC0gYVsxXSAqIGJbMF07XG59XG5cbi8qKlxuICogUGVyZm9ybXMgYSBsaW5lYXIgaW50ZXJwb2xhdGlvbiBiZXR3ZWVuIHR3byB2ZWMyJ3NcbiAqXG4gKiBAcGFyYW0ge3ZlYzJ9IG91dCB0aGUgcmVjZWl2aW5nIHZlY3RvclxuICogQHBhcmFtIHt2ZWMyfSBhIHRoZSBmaXJzdCBvcGVyYW5kXG4gKiBAcGFyYW0ge3ZlYzJ9IGIgdGhlIHNlY29uZCBvcGVyYW5kXG4gKiBAcGFyYW0ge051bWJlcn0gdCBpbnRlcnBvbGF0aW9uIGFtb3VudCBiZXR3ZWVuIHRoZSB0d28gaW5wdXRzXG4gKiBAcmV0dXJucyB7dmVjMn0gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBsZXJwKG91dCwgYSwgYiwgdCkge1xuICAgIHZhciBheCA9IGFbMF0sXG4gICAgICAgIGF5ID0gYVsxXTtcbiAgICBvdXRbMF0gPSBheCArIHQgKiAoYlswXSAtIGF4KTtcbiAgICBvdXRbMV0gPSBheSArIHQgKiAoYlsxXSAtIGF5KTtcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIFBlcmZvcm1zIGEgZnJhbWUgcmF0ZSBpbmRlcGVuZGFudCwgbGluZWFyIGludGVycG9sYXRpb24gYmV0d2VlbiB0d28gdmVjMidzXG4gKlxuICogQHBhcmFtIHt2ZWMyfSBvdXQgdGhlIHJlY2VpdmluZyB2ZWN0b3JcbiAqIEBwYXJhbSB7dmVjMn0gYSB0aGUgZmlyc3Qgb3BlcmFuZFxuICogQHBhcmFtIHt2ZWMyfSBiIHRoZSBzZWNvbmQgb3BlcmFuZFxuICogQHBhcmFtIHtOdW1iZXJ9IGRlY2F5IGRlY2F5IGNvbnN0YW50IGZvciBpbnRlcnBvbGF0aW9uLiB1c2VmdWwgcmFuZ2UgYmV0d2VlbiAxIGFuZCAyNSwgZnJvbSBzbG93IHRvIGZhc3QuXG4gKiBAcGFyYW0ge051bWJlcn0gZHQgZGVsdGEgdGltZVxuICogQHJldHVybnMge3ZlYzJ9IG91dFxuICovXG5leHBvcnQgZnVuY3Rpb24gc21vb3RoTGVycChvdXQsIGEsIGIsIGRlY2F5LCBkdCkge1xuICAgIGNvbnN0IGV4cCA9IE1hdGguZXhwKC1kZWNheSAqIGR0KTtcbiAgICBsZXQgYXggPSBhWzBdO1xuICAgIGxldCBheSA9IGFbMV07XG5cbiAgICBvdXRbMF0gPSBiWzBdICsgKGF4IC0gYlswXSkgKiBleHA7XG4gICAgb3V0WzFdID0gYlsxXSArIChheSAtIGJbMV0pICogZXhwO1xuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogVHJhbnNmb3JtcyB0aGUgdmVjMiB3aXRoIGEgbWF0MlxuICpcbiAqIEBwYXJhbSB7dmVjMn0gb3V0IHRoZSByZWNlaXZpbmcgdmVjdG9yXG4gKiBAcGFyYW0ge3ZlYzJ9IGEgdGhlIHZlY3RvciB0byB0cmFuc2Zvcm1cbiAqIEBwYXJhbSB7bWF0Mn0gbSBtYXRyaXggdG8gdHJhbnNmb3JtIHdpdGhcbiAqIEByZXR1cm5zIHt2ZWMyfSBvdXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRyYW5zZm9ybU1hdDIob3V0LCBhLCBtKSB7XG4gICAgdmFyIHggPSBhWzBdLFxuICAgICAgICB5ID0gYVsxXTtcbiAgICBvdXRbMF0gPSBtWzBdICogeCArIG1bMl0gKiB5O1xuICAgIG91dFsxXSA9IG1bMV0gKiB4ICsgbVszXSAqIHk7XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBUcmFuc2Zvcm1zIHRoZSB2ZWMyIHdpdGggYSBtYXQyZFxuICpcbiAqIEBwYXJhbSB7dmVjMn0gb3V0IHRoZSByZWNlaXZpbmcgdmVjdG9yXG4gKiBAcGFyYW0ge3ZlYzJ9IGEgdGhlIHZlY3RvciB0byB0cmFuc2Zvcm1cbiAqIEBwYXJhbSB7bWF0MmR9IG0gbWF0cml4IHRvIHRyYW5zZm9ybSB3aXRoXG4gKiBAcmV0dXJucyB7dmVjMn0gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0cmFuc2Zvcm1NYXQyZChvdXQsIGEsIG0pIHtcbiAgICB2YXIgeCA9IGFbMF0sXG4gICAgICAgIHkgPSBhWzFdO1xuICAgIG91dFswXSA9IG1bMF0gKiB4ICsgbVsyXSAqIHkgKyBtWzRdO1xuICAgIG91dFsxXSA9IG1bMV0gKiB4ICsgbVszXSAqIHkgKyBtWzVdO1xuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogVHJhbnNmb3JtcyB0aGUgdmVjMiB3aXRoIGEgbWF0M1xuICogM3JkIHZlY3RvciBjb21wb25lbnQgaXMgaW1wbGljaXRseSAnMSdcbiAqXG4gKiBAcGFyYW0ge3ZlYzJ9IG91dCB0aGUgcmVjZWl2aW5nIHZlY3RvclxuICogQHBhcmFtIHt2ZWMyfSBhIHRoZSB2ZWN0b3IgdG8gdHJhbnNmb3JtXG4gKiBAcGFyYW0ge21hdDN9IG0gbWF0cml4IHRvIHRyYW5zZm9ybSB3aXRoXG4gKiBAcmV0dXJucyB7dmVjMn0gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0cmFuc2Zvcm1NYXQzKG91dCwgYSwgbSkge1xuICAgIHZhciB4ID0gYVswXSxcbiAgICAgICAgeSA9IGFbMV07XG4gICAgb3V0WzBdID0gbVswXSAqIHggKyBtWzNdICogeSArIG1bNl07XG4gICAgb3V0WzFdID0gbVsxXSAqIHggKyBtWzRdICogeSArIG1bN107XG4gICAgcmV0dXJuIG91dDtcbn1cblxuLyoqXG4gKiBUcmFuc2Zvcm1zIHRoZSB2ZWMyIHdpdGggYSBtYXQ0XG4gKiAzcmQgdmVjdG9yIGNvbXBvbmVudCBpcyBpbXBsaWNpdGx5ICcwJ1xuICogNHRoIHZlY3RvciBjb21wb25lbnQgaXMgaW1wbGljaXRseSAnMSdcbiAqXG4gKiBAcGFyYW0ge3ZlYzJ9IG91dCB0aGUgcmVjZWl2aW5nIHZlY3RvclxuICogQHBhcmFtIHt2ZWMyfSBhIHRoZSB2ZWN0b3IgdG8gdHJhbnNmb3JtXG4gKiBAcGFyYW0ge21hdDR9IG0gbWF0cml4IHRvIHRyYW5zZm9ybSB3aXRoXG4gKiBAcmV0dXJucyB7dmVjMn0gb3V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0cmFuc2Zvcm1NYXQ0KG91dCwgYSwgbSkge1xuICAgIGxldCB4ID0gYVswXTtcbiAgICBsZXQgeSA9IGFbMV07XG4gICAgb3V0WzBdID0gbVswXSAqIHggKyBtWzRdICogeSArIG1bMTJdO1xuICAgIG91dFsxXSA9IG1bMV0gKiB4ICsgbVs1XSAqIHkgKyBtWzEzXTtcbiAgICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIFJldHVybnMgd2hldGhlciBvciBub3QgdGhlIHZlY3RvcnMgZXhhY3RseSBoYXZlIHRoZSBzYW1lIGVsZW1lbnRzIGluIHRoZSBzYW1lIHBvc2l0aW9uICh3aGVuIGNvbXBhcmVkIHdpdGggPT09KVxuICpcbiAqIEBwYXJhbSB7dmVjMn0gYSBUaGUgZmlyc3QgdmVjdG9yLlxuICogQHBhcmFtIHt2ZWMyfSBiIFRoZSBzZWNvbmQgdmVjdG9yLlxuICogQHJldHVybnMge0Jvb2xlYW59IFRydWUgaWYgdGhlIHZlY3RvcnMgYXJlIGVxdWFsLCBmYWxzZSBvdGhlcndpc2UuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBleGFjdEVxdWFscyhhLCBiKSB7XG4gICAgcmV0dXJuIGFbMF0gPT09IGJbMF0gJiYgYVsxXSA9PT0gYlsxXTtcbn1cbiIsImltcG9ydCAqIGFzIFZlYzJGdW5jIGZyb20gJy4vZnVuY3Rpb25zL1ZlYzJGdW5jLmpzJztcblxuZXhwb3J0IGNsYXNzIFZlYzIgZXh0ZW5kcyBBcnJheSB7XG4gICAgY29uc3RydWN0b3IoeCA9IDAsIHkgPSB4KSB7XG4gICAgICAgIHN1cGVyKHgsIHkpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBnZXQgeCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXNbMF07XG4gICAgfVxuXG4gICAgZ2V0IHkoKSB7XG4gICAgICAgIHJldHVybiB0aGlzWzFdO1xuICAgIH1cblxuICAgIHNldCB4KHYpIHtcbiAgICAgICAgdGhpc1swXSA9IHY7XG4gICAgfVxuXG4gICAgc2V0IHkodikge1xuICAgICAgICB0aGlzWzFdID0gdjtcbiAgICB9XG5cbiAgICBzZXQoeCwgeSA9IHgpIHtcbiAgICAgICAgaWYgKHgubGVuZ3RoKSByZXR1cm4gdGhpcy5jb3B5KHgpO1xuICAgICAgICBWZWMyRnVuYy5zZXQodGhpcywgeCwgeSk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGNvcHkodikge1xuICAgICAgICBWZWMyRnVuYy5jb3B5KHRoaXMsIHYpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBhZGQodmEsIHZiKSB7XG4gICAgICAgIGlmICh2YikgVmVjMkZ1bmMuYWRkKHRoaXMsIHZhLCB2Yik7XG4gICAgICAgIGVsc2UgVmVjMkZ1bmMuYWRkKHRoaXMsIHRoaXMsIHZhKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgc3ViKHZhLCB2Yikge1xuICAgICAgICBpZiAodmIpIFZlYzJGdW5jLnN1YnRyYWN0KHRoaXMsIHZhLCB2Yik7XG4gICAgICAgIGVsc2UgVmVjMkZ1bmMuc3VidHJhY3QodGhpcywgdGhpcywgdmEpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBtdWx0aXBseSh2KSB7XG4gICAgICAgIGlmICh2Lmxlbmd0aCkgVmVjMkZ1bmMubXVsdGlwbHkodGhpcywgdGhpcywgdik7XG4gICAgICAgIGVsc2UgVmVjMkZ1bmMuc2NhbGUodGhpcywgdGhpcywgdik7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGRpdmlkZSh2KSB7XG4gICAgICAgIGlmICh2Lmxlbmd0aCkgVmVjMkZ1bmMuZGl2aWRlKHRoaXMsIHRoaXMsIHYpO1xuICAgICAgICBlbHNlIFZlYzJGdW5jLnNjYWxlKHRoaXMsIHRoaXMsIDEgLyB2KTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgaW52ZXJzZSh2ID0gdGhpcykge1xuICAgICAgICBWZWMyRnVuYy5pbnZlcnNlKHRoaXMsIHYpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICAvLyBDYW4ndCB1c2UgJ2xlbmd0aCcgYXMgQXJyYXkucHJvdG90eXBlIHVzZXMgaXRcbiAgICBsZW4oKSB7XG4gICAgICAgIHJldHVybiBWZWMyRnVuYy5sZW5ndGgodGhpcyk7XG4gICAgfVxuXG4gICAgZGlzdGFuY2Uodikge1xuICAgICAgICBpZiAodikgcmV0dXJuIFZlYzJGdW5jLmRpc3RhbmNlKHRoaXMsIHYpO1xuICAgICAgICBlbHNlIHJldHVybiBWZWMyRnVuYy5sZW5ndGgodGhpcyk7XG4gICAgfVxuXG4gICAgc3F1YXJlZExlbigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuc3F1YXJlZERpc3RhbmNlKCk7XG4gICAgfVxuXG4gICAgc3F1YXJlZERpc3RhbmNlKHYpIHtcbiAgICAgICAgaWYgKHYpIHJldHVybiBWZWMyRnVuYy5zcXVhcmVkRGlzdGFuY2UodGhpcywgdik7XG4gICAgICAgIGVsc2UgcmV0dXJuIFZlYzJGdW5jLnNxdWFyZWRMZW5ndGgodGhpcyk7XG4gICAgfVxuXG4gICAgbmVnYXRlKHYgPSB0aGlzKSB7XG4gICAgICAgIFZlYzJGdW5jLm5lZ2F0ZSh0aGlzLCB2KTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgY3Jvc3ModmEsIHZiKSB7XG4gICAgICAgIGlmICh2YikgcmV0dXJuIFZlYzJGdW5jLmNyb3NzKHZhLCB2Yik7XG4gICAgICAgIHJldHVybiBWZWMyRnVuYy5jcm9zcyh0aGlzLCB2YSk7XG4gICAgfVxuXG4gICAgc2NhbGUodikge1xuICAgICAgICBWZWMyRnVuYy5zY2FsZSh0aGlzLCB0aGlzLCB2KTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgbm9ybWFsaXplKCkge1xuICAgICAgICBWZWMyRnVuYy5ub3JtYWxpemUodGhpcywgdGhpcyk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGRvdCh2KSB7XG4gICAgICAgIHJldHVybiBWZWMyRnVuYy5kb3QodGhpcywgdik7XG4gICAgfVxuXG4gICAgZXF1YWxzKHYpIHtcbiAgICAgICAgcmV0dXJuIFZlYzJGdW5jLmV4YWN0RXF1YWxzKHRoaXMsIHYpO1xuICAgIH1cblxuICAgIGFwcGx5TWF0cml4MyhtYXQzKSB7XG4gICAgICAgIFZlYzJGdW5jLnRyYW5zZm9ybU1hdDModGhpcywgdGhpcywgbWF0Myk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGFwcGx5TWF0cml4NChtYXQ0KSB7XG4gICAgICAgIFZlYzJGdW5jLnRyYW5zZm9ybU1hdDQodGhpcywgdGhpcywgbWF0NCk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGxlcnAodiwgYSkge1xuICAgICAgICBWZWMyRnVuYy5sZXJwKHRoaXMsIHRoaXMsIHYsIGEpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBzbW9vdGhMZXJwKHYsIGRlY2F5LCBkdCkge1xuICAgICAgICBWZWMyRnVuYy5zbW9vdGhMZXJwKHRoaXMsIHRoaXMsIHYsIGRlY2F5LCBkdCk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGNsb25lKCkge1xuICAgICAgICByZXR1cm4gbmV3IFZlYzIodGhpc1swXSwgdGhpc1sxXSk7XG4gICAgfVxuXG4gICAgZnJvbUFycmF5KGEsIG8gPSAwKSB7XG4gICAgICAgIHRoaXNbMF0gPSBhW29dO1xuICAgICAgICB0aGlzWzFdID0gYVtvICsgMV07XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIHRvQXJyYXkoYSA9IFtdLCBvID0gMCkge1xuICAgICAgICBhW29dID0gdGhpc1swXTtcbiAgICAgICAgYVtvICsgMV0gPSB0aGlzWzFdO1xuICAgICAgICByZXR1cm4gYTtcbiAgICB9XG59XG4iLCJpbXBvcnQgKiBhcyBWZWM0RnVuYyBmcm9tICcuL2Z1bmN0aW9ucy9WZWM0RnVuYy5qcyc7XG5cbmV4cG9ydCBjbGFzcyBWZWM0IGV4dGVuZHMgQXJyYXkge1xuICAgIGNvbnN0cnVjdG9yKHggPSAwLCB5ID0geCwgeiA9IHgsIHcgPSB4KSB7XG4gICAgICAgIHN1cGVyKHgsIHksIHosIHcpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBnZXQgeCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXNbMF07XG4gICAgfVxuXG4gICAgZ2V0IHkoKSB7XG4gICAgICAgIHJldHVybiB0aGlzWzFdO1xuICAgIH1cblxuICAgIGdldCB6KCkge1xuICAgICAgICByZXR1cm4gdGhpc1syXTtcbiAgICB9XG5cbiAgICBnZXQgdygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXNbM107XG4gICAgfVxuXG4gICAgc2V0IHgodikge1xuICAgICAgICB0aGlzWzBdID0gdjtcbiAgICB9XG5cbiAgICBzZXQgeSh2KSB7XG4gICAgICAgIHRoaXNbMV0gPSB2O1xuICAgIH1cblxuICAgIHNldCB6KHYpIHtcbiAgICAgICAgdGhpc1syXSA9IHY7XG4gICAgfVxuXG4gICAgc2V0IHcodikge1xuICAgICAgICB0aGlzWzNdID0gdjtcbiAgICB9XG5cbiAgICBzZXQoeCwgeSA9IHgsIHogPSB4LCB3ID0geCkge1xuICAgICAgICBpZiAoeC5sZW5ndGgpIHJldHVybiB0aGlzLmNvcHkoeCk7XG4gICAgICAgIFZlYzRGdW5jLnNldCh0aGlzLCB4LCB5LCB6LCB3KTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgY29weSh2KSB7XG4gICAgICAgIFZlYzRGdW5jLmNvcHkodGhpcywgdik7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIG5vcm1hbGl6ZSgpIHtcbiAgICAgICAgVmVjNEZ1bmMubm9ybWFsaXplKHRoaXMsIHRoaXMpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBtdWx0aXBseSh2KSB7XG4gICAgICAgIFZlYzRGdW5jLnNjYWxlKHRoaXMsIHRoaXMsIHYpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBkb3Qodikge1xuICAgICAgICByZXR1cm4gVmVjNEZ1bmMuZG90KHRoaXMsIHYpO1xuICAgIH1cblxuICAgIGZyb21BcnJheShhLCBvID0gMCkge1xuICAgICAgICB0aGlzWzBdID0gYVtvXTtcbiAgICAgICAgdGhpc1sxXSA9IGFbbyArIDFdO1xuICAgICAgICB0aGlzWzJdID0gYVtvICsgMl07XG4gICAgICAgIHRoaXNbM10gPSBhW28gKyAzXTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgdG9BcnJheShhID0gW10sIG8gPSAwKSB7XG4gICAgICAgIGFbb10gPSB0aGlzWzBdO1xuICAgICAgICBhW28gKyAxXSA9IHRoaXNbMV07XG4gICAgICAgIGFbbyArIDJdID0gdGhpc1syXTtcbiAgICAgICAgYVtvICsgM10gPSB0aGlzWzNdO1xuICAgICAgICByZXR1cm4gYTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBHZW9tZXRyeSB9IGZyb20gJy4uL2NvcmUvR2VvbWV0cnkuanMnO1xuXG5leHBvcnQgY2xhc3MgUGxhbmUgZXh0ZW5kcyBHZW9tZXRyeSB7XG4gICAgY29uc3RydWN0b3IoZ2wsIHsgd2lkdGggPSAxLCBoZWlnaHQgPSAxLCB3aWR0aFNlZ21lbnRzID0gMSwgaGVpZ2h0U2VnbWVudHMgPSAxLCBhdHRyaWJ1dGVzID0ge30gfSA9IHt9KSB7XG4gICAgICAgIGNvbnN0IHdTZWdzID0gd2lkdGhTZWdtZW50cztcbiAgICAgICAgY29uc3QgaFNlZ3MgPSBoZWlnaHRTZWdtZW50cztcblxuICAgICAgICAvLyBEZXRlcm1pbmUgbGVuZ3RoIG9mIGFycmF5c1xuICAgICAgICBjb25zdCBudW0gPSAod1NlZ3MgKyAxKSAqIChoU2VncyArIDEpO1xuICAgICAgICBjb25zdCBudW1JbmRpY2VzID0gd1NlZ3MgKiBoU2VncyAqIDY7XG5cbiAgICAgICAgLy8gR2VuZXJhdGUgZW1wdHkgYXJyYXlzIG9uY2VcbiAgICAgICAgY29uc3QgcG9zaXRpb24gPSBuZXcgRmxvYXQzMkFycmF5KG51bSAqIDMpO1xuICAgICAgICBjb25zdCBub3JtYWwgPSBuZXcgRmxvYXQzMkFycmF5KG51bSAqIDMpO1xuICAgICAgICBjb25zdCB1diA9IG5ldyBGbG9hdDMyQXJyYXkobnVtICogMik7XG4gICAgICAgIGNvbnN0IGluZGV4ID0gbnVtSW5kaWNlcyA+IDY1NTM2ID8gbmV3IFVpbnQzMkFycmF5KG51bUluZGljZXMpIDogbmV3IFVpbnQxNkFycmF5KG51bUluZGljZXMpO1xuXG4gICAgICAgIFBsYW5lLmJ1aWxkUGxhbmUocG9zaXRpb24sIG5vcm1hbCwgdXYsIGluZGV4LCB3aWR0aCwgaGVpZ2h0LCAwLCB3U2VncywgaFNlZ3MpO1xuXG4gICAgICAgIE9iamVjdC5hc3NpZ24oYXR0cmlidXRlcywge1xuICAgICAgICAgICAgcG9zaXRpb246IHsgc2l6ZTogMywgZGF0YTogcG9zaXRpb24gfSxcbiAgICAgICAgICAgIG5vcm1hbDogeyBzaXplOiAzLCBkYXRhOiBub3JtYWwgfSxcbiAgICAgICAgICAgIHV2OiB7IHNpemU6IDIsIGRhdGE6IHV2IH0sXG4gICAgICAgICAgICBpbmRleDogeyBkYXRhOiBpbmRleCB9LFxuICAgICAgICB9KTtcblxuICAgICAgICBzdXBlcihnbCwgYXR0cmlidXRlcyk7XG4gICAgfVxuXG4gICAgc3RhdGljIGJ1aWxkUGxhbmUocG9zaXRpb24sIG5vcm1hbCwgdXYsIGluZGV4LCB3aWR0aCwgaGVpZ2h0LCBkZXB0aCwgd1NlZ3MsIGhTZWdzLCB1ID0gMCwgdiA9IDEsIHcgPSAyLCB1RGlyID0gMSwgdkRpciA9IC0xLCBpID0gMCwgaWkgPSAwKSB7XG4gICAgICAgIGNvbnN0IGlvID0gaTtcbiAgICAgICAgY29uc3Qgc2VnVyA9IHdpZHRoIC8gd1NlZ3M7XG4gICAgICAgIGNvbnN0IHNlZ0ggPSBoZWlnaHQgLyBoU2VncztcblxuICAgICAgICBmb3IgKGxldCBpeSA9IDA7IGl5IDw9IGhTZWdzOyBpeSsrKSB7XG4gICAgICAgICAgICBsZXQgeSA9IGl5ICogc2VnSCAtIGhlaWdodCAvIDI7XG4gICAgICAgICAgICBmb3IgKGxldCBpeCA9IDA7IGl4IDw9IHdTZWdzOyBpeCsrLCBpKyspIHtcbiAgICAgICAgICAgICAgICBsZXQgeCA9IGl4ICogc2VnVyAtIHdpZHRoIC8gMjtcblxuICAgICAgICAgICAgICAgIHBvc2l0aW9uW2kgKiAzICsgdV0gPSB4ICogdURpcjtcbiAgICAgICAgICAgICAgICBwb3NpdGlvbltpICogMyArIHZdID0geSAqIHZEaXI7XG4gICAgICAgICAgICAgICAgcG9zaXRpb25baSAqIDMgKyB3XSA9IGRlcHRoIC8gMjtcblxuICAgICAgICAgICAgICAgIG5vcm1hbFtpICogMyArIHVdID0gMDtcbiAgICAgICAgICAgICAgICBub3JtYWxbaSAqIDMgKyB2XSA9IDA7XG4gICAgICAgICAgICAgICAgbm9ybWFsW2kgKiAzICsgd10gPSBkZXB0aCA+PSAwID8gMSA6IC0xO1xuXG4gICAgICAgICAgICAgICAgdXZbaSAqIDJdID0gaXggLyB3U2VncztcbiAgICAgICAgICAgICAgICB1dltpICogMiArIDFdID0gMSAtIGl5IC8gaFNlZ3M7XG5cbiAgICAgICAgICAgICAgICBpZiAoaXkgPT09IGhTZWdzIHx8IGl4ID09PSB3U2VncykgY29udGludWU7XG4gICAgICAgICAgICAgICAgbGV0IGEgPSBpbyArIGl4ICsgaXkgKiAod1NlZ3MgKyAxKTtcbiAgICAgICAgICAgICAgICBsZXQgYiA9IGlvICsgaXggKyAoaXkgKyAxKSAqICh3U2VncyArIDEpO1xuICAgICAgICAgICAgICAgIGxldCBjID0gaW8gKyBpeCArIChpeSArIDEpICogKHdTZWdzICsgMSkgKyAxO1xuICAgICAgICAgICAgICAgIGxldCBkID0gaW8gKyBpeCArIGl5ICogKHdTZWdzICsgMSkgKyAxO1xuXG4gICAgICAgICAgICAgICAgaW5kZXhbaWkgKiA2XSA9IGE7XG4gICAgICAgICAgICAgICAgaW5kZXhbaWkgKiA2ICsgMV0gPSBiO1xuICAgICAgICAgICAgICAgIGluZGV4W2lpICogNiArIDJdID0gZDtcbiAgICAgICAgICAgICAgICBpbmRleFtpaSAqIDYgKyAzXSA9IGI7XG4gICAgICAgICAgICAgICAgaW5kZXhbaWkgKiA2ICsgNF0gPSBjO1xuICAgICAgICAgICAgICAgIGluZGV4W2lpICogNiArIDVdID0gZDtcbiAgICAgICAgICAgICAgICBpaSsrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgR2VvbWV0cnkgfSBmcm9tICcuLi9jb3JlL0dlb21ldHJ5LmpzJztcbmltcG9ydCB7IFBsYW5lIH0gZnJvbSAnLi9QbGFuZS5qcyc7XG5cbmV4cG9ydCBjbGFzcyBCb3ggZXh0ZW5kcyBHZW9tZXRyeSB7XG4gICAgY29uc3RydWN0b3IoZ2wsIHsgd2lkdGggPSAxLCBoZWlnaHQgPSAxLCBkZXB0aCA9IDEsIHdpZHRoU2VnbWVudHMgPSAxLCBoZWlnaHRTZWdtZW50cyA9IDEsIGRlcHRoU2VnbWVudHMgPSAxLCBhdHRyaWJ1dGVzID0ge30gfSA9IHt9KSB7XG4gICAgICAgIGNvbnN0IHdTZWdzID0gd2lkdGhTZWdtZW50cztcbiAgICAgICAgY29uc3QgaFNlZ3MgPSBoZWlnaHRTZWdtZW50cztcbiAgICAgICAgY29uc3QgZFNlZ3MgPSBkZXB0aFNlZ21lbnRzO1xuXG4gICAgICAgIGNvbnN0IG51bSA9ICh3U2VncyArIDEpICogKGhTZWdzICsgMSkgKiAyICsgKHdTZWdzICsgMSkgKiAoZFNlZ3MgKyAxKSAqIDIgKyAoaFNlZ3MgKyAxKSAqIChkU2VncyArIDEpICogMjtcbiAgICAgICAgY29uc3QgbnVtSW5kaWNlcyA9ICh3U2VncyAqIGhTZWdzICogMiArIHdTZWdzICogZFNlZ3MgKiAyICsgaFNlZ3MgKiBkU2VncyAqIDIpICogNjtcblxuICAgICAgICBjb25zdCBwb3NpdGlvbiA9IG5ldyBGbG9hdDMyQXJyYXkobnVtICogMyk7XG4gICAgICAgIGNvbnN0IG5vcm1hbCA9IG5ldyBGbG9hdDMyQXJyYXkobnVtICogMyk7XG4gICAgICAgIGNvbnN0IHV2ID0gbmV3IEZsb2F0MzJBcnJheShudW0gKiAyKTtcbiAgICAgICAgY29uc3QgaW5kZXggPSBudW0gPiA2NTUzNiA/IG5ldyBVaW50MzJBcnJheShudW1JbmRpY2VzKSA6IG5ldyBVaW50MTZBcnJheShudW1JbmRpY2VzKTtcblxuICAgICAgICBsZXQgaSA9IDA7XG4gICAgICAgIGxldCBpaSA9IDA7XG5cbiAgICAgICAgLy8gbGVmdCwgcmlnaHRcbiAgICAgICAgUGxhbmUuYnVpbGRQbGFuZShwb3NpdGlvbiwgbm9ybWFsLCB1diwgaW5kZXgsIGRlcHRoLCBoZWlnaHQsIHdpZHRoLCBkU2VncywgaFNlZ3MsIDIsIDEsIDAsIC0xLCAtMSwgaSwgaWkpO1xuICAgICAgICBpICs9IChkU2VncyArIDEpICogKGhTZWdzICsgMSk7XG4gICAgICAgIGlpICs9IGRTZWdzICogaFNlZ3M7XG5cbiAgICAgICAgUGxhbmUuYnVpbGRQbGFuZShwb3NpdGlvbiwgbm9ybWFsLCB1diwgaW5kZXgsIGRlcHRoLCBoZWlnaHQsIC13aWR0aCwgZFNlZ3MsIGhTZWdzLCAyLCAxLCAwLCAxLCAtMSwgaSwgaWkpO1xuICAgICAgICBpICs9IChkU2VncyArIDEpICogKGhTZWdzICsgMSk7XG4gICAgICAgIGlpICs9IGRTZWdzICogaFNlZ3M7XG5cbiAgICAgICAgLy8gdG9wLCBib3R0b21cbiAgICAgICAgUGxhbmUuYnVpbGRQbGFuZShwb3NpdGlvbiwgbm9ybWFsLCB1diwgaW5kZXgsIHdpZHRoLCBkZXB0aCwgaGVpZ2h0LCBkU2Vncywgd1NlZ3MsIDAsIDIsIDEsIDEsIDEsIGksIGlpKTtcbiAgICAgICAgaSArPSAod1NlZ3MgKyAxKSAqIChkU2VncyArIDEpO1xuICAgICAgICBpaSArPSB3U2VncyAqIGRTZWdzO1xuXG4gICAgICAgIFBsYW5lLmJ1aWxkUGxhbmUocG9zaXRpb24sIG5vcm1hbCwgdXYsIGluZGV4LCB3aWR0aCwgZGVwdGgsIC1oZWlnaHQsIGRTZWdzLCB3U2VncywgMCwgMiwgMSwgMSwgLTEsIGksIGlpKTtcbiAgICAgICAgaSArPSAod1NlZ3MgKyAxKSAqIChkU2VncyArIDEpO1xuICAgICAgICBpaSArPSB3U2VncyAqIGRTZWdzO1xuXG4gICAgICAgIC8vIGZyb250LCBiYWNrXG4gICAgICAgIFBsYW5lLmJ1aWxkUGxhbmUocG9zaXRpb24sIG5vcm1hbCwgdXYsIGluZGV4LCB3aWR0aCwgaGVpZ2h0LCAtZGVwdGgsIHdTZWdzLCBoU2VncywgMCwgMSwgMiwgLTEsIC0xLCBpLCBpaSk7XG4gICAgICAgIGkgKz0gKHdTZWdzICsgMSkgKiAoaFNlZ3MgKyAxKTtcbiAgICAgICAgaWkgKz0gd1NlZ3MgKiBoU2VncztcblxuICAgICAgICBQbGFuZS5idWlsZFBsYW5lKHBvc2l0aW9uLCBub3JtYWwsIHV2LCBpbmRleCwgd2lkdGgsIGhlaWdodCwgZGVwdGgsIHdTZWdzLCBoU2VncywgMCwgMSwgMiwgMSwgLTEsIGksIGlpKTtcblxuICAgICAgICBPYmplY3QuYXNzaWduKGF0dHJpYnV0ZXMsIHtcbiAgICAgICAgICAgIHBvc2l0aW9uOiB7IHNpemU6IDMsIGRhdGE6IHBvc2l0aW9uIH0sXG4gICAgICAgICAgICBub3JtYWw6IHsgc2l6ZTogMywgZGF0YTogbm9ybWFsIH0sXG4gICAgICAgICAgICB1djogeyBzaXplOiAyLCBkYXRhOiB1diB9LFxuICAgICAgICAgICAgaW5kZXg6IHsgZGF0YTogaW5kZXggfSxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgc3VwZXIoZ2wsIGF0dHJpYnV0ZXMpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEdlb21ldHJ5IH0gZnJvbSAnLi4vY29yZS9HZW9tZXRyeS5qcyc7XG5pbXBvcnQgeyBWZWMzIH0gZnJvbSAnLi4vbWF0aC9WZWMzLmpzJztcblxuZXhwb3J0IGNsYXNzIFNwaGVyZSBleHRlbmRzIEdlb21ldHJ5IHtcbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgZ2wsXG4gICAgICAgIHtcbiAgICAgICAgICAgIHJhZGl1cyA9IDAuNSxcbiAgICAgICAgICAgIHdpZHRoU2VnbWVudHMgPSAxNixcbiAgICAgICAgICAgIGhlaWdodFNlZ21lbnRzID0gTWF0aC5jZWlsKHdpZHRoU2VnbWVudHMgKiAwLjUpLFxuICAgICAgICAgICAgcGhpU3RhcnQgPSAwLFxuICAgICAgICAgICAgcGhpTGVuZ3RoID0gTWF0aC5QSSAqIDIsXG4gICAgICAgICAgICB0aGV0YVN0YXJ0ID0gMCxcbiAgICAgICAgICAgIHRoZXRhTGVuZ3RoID0gTWF0aC5QSSxcbiAgICAgICAgICAgIGF0dHJpYnV0ZXMgPSB7fSxcbiAgICAgICAgfSA9IHt9XG4gICAgKSB7XG4gICAgICAgIGNvbnN0IHdTZWdzID0gd2lkdGhTZWdtZW50cztcbiAgICAgICAgY29uc3QgaFNlZ3MgPSBoZWlnaHRTZWdtZW50cztcbiAgICAgICAgY29uc3QgcFN0YXJ0ID0gcGhpU3RhcnQ7XG4gICAgICAgIGNvbnN0IHBMZW5ndGggPSBwaGlMZW5ndGg7XG4gICAgICAgIGNvbnN0IHRTdGFydCA9IHRoZXRhU3RhcnQ7XG4gICAgICAgIGNvbnN0IHRMZW5ndGggPSB0aGV0YUxlbmd0aDtcblxuICAgICAgICBjb25zdCBudW0gPSAod1NlZ3MgKyAxKSAqIChoU2VncyArIDEpO1xuICAgICAgICBjb25zdCBudW1JbmRpY2VzID0gd1NlZ3MgKiBoU2VncyAqIDY7XG5cbiAgICAgICAgY29uc3QgcG9zaXRpb24gPSBuZXcgRmxvYXQzMkFycmF5KG51bSAqIDMpO1xuICAgICAgICBjb25zdCBub3JtYWwgPSBuZXcgRmxvYXQzMkFycmF5KG51bSAqIDMpO1xuICAgICAgICBjb25zdCB1diA9IG5ldyBGbG9hdDMyQXJyYXkobnVtICogMik7XG4gICAgICAgIGNvbnN0IGluZGV4ID0gbnVtID4gNjU1MzYgPyBuZXcgVWludDMyQXJyYXkobnVtSW5kaWNlcykgOiBuZXcgVWludDE2QXJyYXkobnVtSW5kaWNlcyk7XG5cbiAgICAgICAgbGV0IGkgPSAwO1xuICAgICAgICBsZXQgaXYgPSAwO1xuICAgICAgICBsZXQgaWkgPSAwO1xuICAgICAgICBsZXQgdGUgPSB0U3RhcnQgKyB0TGVuZ3RoO1xuICAgICAgICBjb25zdCBncmlkID0gW107XG5cbiAgICAgICAgbGV0IG4gPSBuZXcgVmVjMygpO1xuXG4gICAgICAgIGZvciAobGV0IGl5ID0gMDsgaXkgPD0gaFNlZ3M7IGl5KyspIHtcbiAgICAgICAgICAgIGxldCB2Um93ID0gW107XG4gICAgICAgICAgICBsZXQgdiA9IGl5IC8gaFNlZ3M7XG4gICAgICAgICAgICBmb3IgKGxldCBpeCA9IDA7IGl4IDw9IHdTZWdzOyBpeCsrLCBpKyspIHtcbiAgICAgICAgICAgICAgICBsZXQgdSA9IGl4IC8gd1NlZ3M7XG4gICAgICAgICAgICAgICAgbGV0IHggPSAtcmFkaXVzICogTWF0aC5jb3MocFN0YXJ0ICsgdSAqIHBMZW5ndGgpICogTWF0aC5zaW4odFN0YXJ0ICsgdiAqIHRMZW5ndGgpO1xuICAgICAgICAgICAgICAgIGxldCB5ID0gcmFkaXVzICogTWF0aC5jb3ModFN0YXJ0ICsgdiAqIHRMZW5ndGgpO1xuICAgICAgICAgICAgICAgIGxldCB6ID0gcmFkaXVzICogTWF0aC5zaW4ocFN0YXJ0ICsgdSAqIHBMZW5ndGgpICogTWF0aC5zaW4odFN0YXJ0ICsgdiAqIHRMZW5ndGgpO1xuXG4gICAgICAgICAgICAgICAgcG9zaXRpb25baSAqIDNdID0geDtcbiAgICAgICAgICAgICAgICBwb3NpdGlvbltpICogMyArIDFdID0geTtcbiAgICAgICAgICAgICAgICBwb3NpdGlvbltpICogMyArIDJdID0gejtcblxuICAgICAgICAgICAgICAgIG4uc2V0KHgsIHksIHopLm5vcm1hbGl6ZSgpO1xuICAgICAgICAgICAgICAgIG5vcm1hbFtpICogM10gPSBuLng7XG4gICAgICAgICAgICAgICAgbm9ybWFsW2kgKiAzICsgMV0gPSBuLnk7XG4gICAgICAgICAgICAgICAgbm9ybWFsW2kgKiAzICsgMl0gPSBuLno7XG5cbiAgICAgICAgICAgICAgICB1dltpICogMl0gPSB1O1xuICAgICAgICAgICAgICAgIHV2W2kgKiAyICsgMV0gPSAxIC0gdjtcblxuICAgICAgICAgICAgICAgIHZSb3cucHVzaChpdisrKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgZ3JpZC5wdXNoKHZSb3cpO1xuICAgICAgICB9XG5cbiAgICAgICAgZm9yIChsZXQgaXkgPSAwOyBpeSA8IGhTZWdzOyBpeSsrKSB7XG4gICAgICAgICAgICBmb3IgKGxldCBpeCA9IDA7IGl4IDwgd1NlZ3M7IGl4KyspIHtcbiAgICAgICAgICAgICAgICBsZXQgYSA9IGdyaWRbaXldW2l4ICsgMV07XG4gICAgICAgICAgICAgICAgbGV0IGIgPSBncmlkW2l5XVtpeF07XG4gICAgICAgICAgICAgICAgbGV0IGMgPSBncmlkW2l5ICsgMV1baXhdO1xuICAgICAgICAgICAgICAgIGxldCBkID0gZ3JpZFtpeSArIDFdW2l4ICsgMV07XG5cbiAgICAgICAgICAgICAgICBpZiAoaXkgIT09IDAgfHwgdFN0YXJ0ID4gMCkge1xuICAgICAgICAgICAgICAgICAgICBpbmRleFtpaSAqIDNdID0gYTtcbiAgICAgICAgICAgICAgICAgICAgaW5kZXhbaWkgKiAzICsgMV0gPSBiO1xuICAgICAgICAgICAgICAgICAgICBpbmRleFtpaSAqIDMgKyAyXSA9IGQ7XG4gICAgICAgICAgICAgICAgICAgIGlpKys7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChpeSAhPT0gaFNlZ3MgLSAxIHx8IHRlIDwgTWF0aC5QSSkge1xuICAgICAgICAgICAgICAgICAgICBpbmRleFtpaSAqIDNdID0gYjtcbiAgICAgICAgICAgICAgICAgICAgaW5kZXhbaWkgKiAzICsgMV0gPSBjO1xuICAgICAgICAgICAgICAgICAgICBpbmRleFtpaSAqIDMgKyAyXSA9IGQ7XG4gICAgICAgICAgICAgICAgICAgIGlpKys7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgT2JqZWN0LmFzc2lnbihhdHRyaWJ1dGVzLCB7XG4gICAgICAgICAgICBwb3NpdGlvbjogeyBzaXplOiAzLCBkYXRhOiBwb3NpdGlvbiB9LFxuICAgICAgICAgICAgbm9ybWFsOiB7IHNpemU6IDMsIGRhdGE6IG5vcm1hbCB9LFxuICAgICAgICAgICAgdXY6IHsgc2l6ZTogMiwgZGF0YTogdXYgfSxcbiAgICAgICAgICAgIGluZGV4OiB7IGRhdGE6IGluZGV4IH0sXG4gICAgICAgIH0pO1xuXG4gICAgICAgIHN1cGVyKGdsLCBhdHRyaWJ1dGVzKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBHZW9tZXRyeSB9IGZyb20gJy4uL2NvcmUvR2VvbWV0cnkuanMnO1xuaW1wb3J0IHsgVmVjMyB9IGZyb20gJy4uL21hdGgvVmVjMy5qcyc7XG5cbmV4cG9ydCBjbGFzcyBDeWxpbmRlciBleHRlbmRzIEdlb21ldHJ5IHtcbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgZ2wsXG4gICAgICAgIHtcbiAgICAgICAgICAgIHJhZGl1c1RvcCA9IDAuNSxcbiAgICAgICAgICAgIHJhZGl1c0JvdHRvbSA9IDAuNSxcbiAgICAgICAgICAgIGhlaWdodCA9IDEsXG4gICAgICAgICAgICByYWRpYWxTZWdtZW50cyA9IDgsXG4gICAgICAgICAgICBoZWlnaHRTZWdtZW50cyA9IDEsXG4gICAgICAgICAgICBvcGVuRW5kZWQgPSBmYWxzZSxcbiAgICAgICAgICAgIHRoZXRhU3RhcnQgPSAwLFxuICAgICAgICAgICAgdGhldGFMZW5ndGggPSBNYXRoLlBJICogMixcbiAgICAgICAgICAgIGF0dHJpYnV0ZXMgPSB7fSxcbiAgICAgICAgfSA9IHt9XG4gICAgKSB7XG4gICAgICAgIGNvbnN0IHJTZWdzID0gcmFkaWFsU2VnbWVudHM7XG4gICAgICAgIGNvbnN0IGhTZWdzID0gaGVpZ2h0U2VnbWVudHM7XG4gICAgICAgIGNvbnN0IHRTdGFydCA9IHRoZXRhU3RhcnQ7XG4gICAgICAgIGNvbnN0IHRMZW5ndGggPSB0aGV0YUxlbmd0aDtcblxuICAgICAgICBjb25zdCBudW1DYXBzID0gb3BlbkVuZGVkID8gMCA6IHJhZGl1c0JvdHRvbSAmJiByYWRpdXNUb3AgPyAyIDogMTtcbiAgICAgICAgY29uc3QgbnVtID0gKHJTZWdzICsgMSkgKiAoaFNlZ3MgKyAxICsgbnVtQ2FwcykgKyBudW1DYXBzO1xuICAgICAgICBjb25zdCBudW1JbmRpY2VzID0gclNlZ3MgKiBoU2VncyAqIDYgKyBudW1DYXBzICogclNlZ3MgKiAzO1xuXG4gICAgICAgIGNvbnN0IHBvc2l0aW9uID0gbmV3IEZsb2F0MzJBcnJheShudW0gKiAzKTtcbiAgICAgICAgY29uc3Qgbm9ybWFsID0gbmV3IEZsb2F0MzJBcnJheShudW0gKiAzKTtcbiAgICAgICAgY29uc3QgdXYgPSBuZXcgRmxvYXQzMkFycmF5KG51bSAqIDIpO1xuICAgICAgICBjb25zdCBpbmRleCA9IG51bSA+IDY1NTM2ID8gbmV3IFVpbnQzMkFycmF5KG51bUluZGljZXMpIDogbmV3IFVpbnQxNkFycmF5KG51bUluZGljZXMpO1xuXG4gICAgICAgIGxldCBpID0gMDtcbiAgICAgICAgbGV0IGlpID0gMDtcbiAgICAgICAgY29uc3QgaW5kZXhBcnJheSA9IFtdO1xuXG4gICAgICAgIGFkZEhlaWdodCgpO1xuICAgICAgICBpZiAoIW9wZW5FbmRlZCkge1xuICAgICAgICAgICAgaWYgKHJhZGl1c1RvcCkgYWRkQ2FwKHRydWUpO1xuICAgICAgICAgICAgaWYgKHJhZGl1c0JvdHRvbSkgYWRkQ2FwKGZhbHNlKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIGFkZEhlaWdodCgpIHtcbiAgICAgICAgICAgIGxldCB4LCB5O1xuICAgICAgICAgICAgY29uc3QgbiA9IG5ldyBWZWMzKCk7XG4gICAgICAgICAgICBjb25zdCBzbG9wZSA9IChyYWRpdXNCb3R0b20gLSByYWRpdXNUb3ApIC8gaGVpZ2h0O1xuXG4gICAgICAgICAgICBmb3IgKHkgPSAwOyB5IDw9IGhTZWdzOyB5KyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBpbmRleFJvdyA9IFtdO1xuICAgICAgICAgICAgICAgIGNvbnN0IHYgPSB5IC8gaFNlZ3M7XG5cbiAgICAgICAgICAgICAgICBjb25zdCByID0gdiAqIChyYWRpdXNCb3R0b20gLSByYWRpdXNUb3ApICsgcmFkaXVzVG9wO1xuICAgICAgICAgICAgICAgIGZvciAoeCA9IDA7IHggPD0gclNlZ3M7IHgrKykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB1ID0geCAvIHJTZWdzO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB0aGV0YSA9IHUgKiB0TGVuZ3RoICsgdFN0YXJ0O1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBzaW5UaGV0YSA9IE1hdGguc2luKHRoZXRhKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY29zVGhldGEgPSBNYXRoLmNvcyh0aGV0YSk7XG5cbiAgICAgICAgICAgICAgICAgICAgcG9zaXRpb24uc2V0KFtyICogc2luVGhldGEsICgwLjUgLSB2KSAqIGhlaWdodCwgciAqIGNvc1RoZXRhXSwgaSAqIDMpO1xuICAgICAgICAgICAgICAgICAgICBuLnNldChzaW5UaGV0YSwgc2xvcGUsIGNvc1RoZXRhKS5ub3JtYWxpemUoKTtcbiAgICAgICAgICAgICAgICAgICAgbm9ybWFsLnNldChbbi54LCBuLnksIG4uel0sIGkgKiAzKTtcbiAgICAgICAgICAgICAgICAgICAgdXYuc2V0KFt1LCAxIC0gdl0sIGkgKiAyKTtcbiAgICAgICAgICAgICAgICAgICAgaW5kZXhSb3cucHVzaChpKyspO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpbmRleEFycmF5LnB1c2goaW5kZXhSb3cpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBmb3IgKHggPSAwOyB4IDwgclNlZ3M7IHgrKykge1xuICAgICAgICAgICAgICAgIGZvciAoeSA9IDA7IHkgPCBoU2VnczsgeSsrKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGEgPSBpbmRleEFycmF5W3ldW3hdO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBiID0gaW5kZXhBcnJheVt5ICsgMV1beF07XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGMgPSBpbmRleEFycmF5W3kgKyAxXVt4ICsgMV07XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGQgPSBpbmRleEFycmF5W3ldW3ggKyAxXTtcblxuICAgICAgICAgICAgICAgICAgICBpbmRleC5zZXQoW2EsIGIsIGQsIGIsIGMsIGRdLCBpaSAqIDMpO1xuICAgICAgICAgICAgICAgICAgICBpaSArPSAyO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIGFkZENhcChpc1RvcCkge1xuICAgICAgICAgICAgbGV0IHg7XG4gICAgICAgICAgICBjb25zdCByID0gaXNUb3AgPT09IHRydWUgPyByYWRpdXNUb3AgOiByYWRpdXNCb3R0b207XG4gICAgICAgICAgICBjb25zdCBzaWduID0gaXNUb3AgPT09IHRydWUgPyAxIDogLTE7XG5cbiAgICAgICAgICAgIGNvbnN0IGNlbnRlckluZGV4ID0gaTtcbiAgICAgICAgICAgIHBvc2l0aW9uLnNldChbMCwgMC41ICogaGVpZ2h0ICogc2lnbiwgMF0sIGkgKiAzKTtcbiAgICAgICAgICAgIG5vcm1hbC5zZXQoWzAsIHNpZ24sIDBdLCBpICogMyk7XG4gICAgICAgICAgICB1di5zZXQoWzAuNSwgMC41XSwgaSAqIDIpO1xuICAgICAgICAgICAgaSsrO1xuXG4gICAgICAgICAgICBmb3IgKHggPSAwOyB4IDw9IHJTZWdzOyB4KyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCB1ID0geCAvIHJTZWdzO1xuICAgICAgICAgICAgICAgIGNvbnN0IHRoZXRhID0gdSAqIHRMZW5ndGggKyB0U3RhcnQ7XG4gICAgICAgICAgICAgICAgY29uc3QgY29zVGhldGEgPSBNYXRoLmNvcyh0aGV0YSk7XG4gICAgICAgICAgICAgICAgY29uc3Qgc2luVGhldGEgPSBNYXRoLnNpbih0aGV0YSk7XG5cbiAgICAgICAgICAgICAgICBwb3NpdGlvbi5zZXQoW3IgKiBzaW5UaGV0YSwgMC41ICogaGVpZ2h0ICogc2lnbiwgciAqIGNvc1RoZXRhXSwgaSAqIDMpO1xuICAgICAgICAgICAgICAgIG5vcm1hbC5zZXQoWzAsIHNpZ24sIDBdLCBpICogMyk7XG4gICAgICAgICAgICAgICAgdXYuc2V0KFtjb3NUaGV0YSAqIDAuNSArIDAuNSwgc2luVGhldGEgKiAwLjUgKiBzaWduICsgMC41XSwgaSAqIDIpO1xuICAgICAgICAgICAgICAgIGkrKztcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgZm9yICh4ID0gMDsgeCA8IHJTZWdzOyB4KyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBqID0gY2VudGVySW5kZXggKyB4ICsgMTtcbiAgICAgICAgICAgICAgICBpZiAoaXNUb3ApIHtcbiAgICAgICAgICAgICAgICAgICAgaW5kZXguc2V0KFtqLCBqICsgMSwgY2VudGVySW5kZXhdLCBpaSAqIDMpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGluZGV4LnNldChbaiArIDEsIGosIGNlbnRlckluZGV4XSwgaWkgKiAzKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWkrKztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIE9iamVjdC5hc3NpZ24oYXR0cmlidXRlcywge1xuICAgICAgICAgICAgcG9zaXRpb246IHsgc2l6ZTogMywgZGF0YTogcG9zaXRpb24gfSxcbiAgICAgICAgICAgIG5vcm1hbDogeyBzaXplOiAzLCBkYXRhOiBub3JtYWwgfSxcbiAgICAgICAgICAgIHV2OiB7IHNpemU6IDIsIGRhdGE6IHV2IH0sXG4gICAgICAgICAgICBpbmRleDogeyBkYXRhOiBpbmRleCB9LFxuICAgICAgICB9KTtcblxuICAgICAgICBzdXBlcihnbCwgYXR0cmlidXRlcyk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgR2VvbWV0cnkgfSBmcm9tICcuLi9jb3JlL0dlb21ldHJ5LmpzJztcblxuZXhwb3J0IGNsYXNzIFRyaWFuZ2xlIGV4dGVuZHMgR2VvbWV0cnkge1xuICAgIGNvbnN0cnVjdG9yKGdsLCB7IGF0dHJpYnV0ZXMgPSB7fSB9ID0ge30pIHtcbiAgICAgICAgT2JqZWN0LmFzc2lnbihhdHRyaWJ1dGVzLCB7XG4gICAgICAgICAgICBwb3NpdGlvbjogeyBzaXplOiAyLCBkYXRhOiBuZXcgRmxvYXQzMkFycmF5KFstMSwgLTEsIDMsIC0xLCAtMSwgM10pIH0sXG4gICAgICAgICAgICB1djogeyBzaXplOiAyLCBkYXRhOiBuZXcgRmxvYXQzMkFycmF5KFswLCAwLCAyLCAwLCAwLCAyXSkgfSxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgc3VwZXIoZ2wsIGF0dHJpYnV0ZXMpO1xuICAgIH1cbn1cbiIsIi8vIGh0dHBzOi8vZ2l0aHViLmNvbS9tcmRvb2IvdGhyZWUuanMvYmxvYi9tYXN0ZXIvc3JjL2dlb21ldHJpZXMvVG9ydXNHZW9tZXRyeS5qc1xuXG5pbXBvcnQgeyBHZW9tZXRyeSB9IGZyb20gJy4uL2NvcmUvR2VvbWV0cnkuanMnO1xuaW1wb3J0IHsgVmVjMyB9IGZyb20gJy4uL21hdGgvVmVjMy5qcyc7XG5cbmV4cG9ydCBjbGFzcyBUb3J1cyBleHRlbmRzIEdlb21ldHJ5IHtcbiAgICBjb25zdHJ1Y3RvcihnbCwgeyByYWRpdXMgPSAwLjUsIHR1YmUgPSAwLjIsIHJhZGlhbFNlZ21lbnRzID0gOCwgdHVidWxhclNlZ21lbnRzID0gNiwgYXJjID0gTWF0aC5QSSAqIDIsIGF0dHJpYnV0ZXMgPSB7fSB9ID0ge30pIHtcbiAgICAgICAgY29uc3QgbnVtID0gKHJhZGlhbFNlZ21lbnRzICsgMSkgKiAodHVidWxhclNlZ21lbnRzICsgMSk7XG4gICAgICAgIGNvbnN0IG51bUluZGljZXMgPSByYWRpYWxTZWdtZW50cyAqIHR1YnVsYXJTZWdtZW50cyAqIDY7XG5cbiAgICAgICAgY29uc3QgdmVydGljZXMgPSBuZXcgRmxvYXQzMkFycmF5KG51bSAqIDMpO1xuICAgICAgICBjb25zdCBub3JtYWxzID0gbmV3IEZsb2F0MzJBcnJheShudW0gKiAzKTtcbiAgICAgICAgY29uc3QgdXZzID0gbmV3IEZsb2F0MzJBcnJheShudW0gKiAyKTtcbiAgICAgICAgY29uc3QgaW5kaWNlcyA9IG51bSA+IDY1NTM2ID8gbmV3IFVpbnQzMkFycmF5KG51bUluZGljZXMpIDogbmV3IFVpbnQxNkFycmF5KG51bUluZGljZXMpO1xuXG4gICAgICAgIGNvbnN0IGNlbnRlciA9IG5ldyBWZWMzKCk7XG4gICAgICAgIGNvbnN0IHZlcnRleCA9IG5ldyBWZWMzKCk7XG4gICAgICAgIGNvbnN0IG5vcm1hbCA9IG5ldyBWZWMzKCk7XG5cbiAgICAgICAgLy8gZ2VuZXJhdGUgdmVydGljZXMsIG5vcm1hbHMgYW5kIHV2c1xuICAgICAgICBsZXQgaWR4ID0gMDtcbiAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPD0gcmFkaWFsU2VnbWVudHM7IGorKykge1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPD0gdHVidWxhclNlZ21lbnRzOyBpKyssIGlkeCsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgdSA9IChpIC8gdHVidWxhclNlZ21lbnRzKSAqIGFyYztcbiAgICAgICAgICAgICAgICBjb25zdCB2ID0gKGogLyByYWRpYWxTZWdtZW50cykgKiBNYXRoLlBJICogMjtcblxuICAgICAgICAgICAgICAgIC8vIHZlcnRleFxuICAgICAgICAgICAgICAgIHZlcnRleC54ID0gKHJhZGl1cyArIHR1YmUgKiBNYXRoLmNvcyh2KSkgKiBNYXRoLmNvcyh1KTtcbiAgICAgICAgICAgICAgICB2ZXJ0ZXgueSA9IChyYWRpdXMgKyB0dWJlICogTWF0aC5jb3ModikpICogTWF0aC5zaW4odSk7XG4gICAgICAgICAgICAgICAgdmVydGV4LnogPSB0dWJlICogTWF0aC5zaW4odik7XG5cbiAgICAgICAgICAgICAgICB2ZXJ0aWNlcy5zZXQoW3ZlcnRleC54LCB2ZXJ0ZXgueSwgdmVydGV4LnpdLCBpZHggKiAzKTtcblxuICAgICAgICAgICAgICAgIC8vIG5vcm1hbFxuICAgICAgICAgICAgICAgIGNlbnRlci54ID0gcmFkaXVzICogTWF0aC5jb3ModSk7XG4gICAgICAgICAgICAgICAgY2VudGVyLnkgPSByYWRpdXMgKiBNYXRoLnNpbih1KTtcbiAgICAgICAgICAgICAgICBub3JtYWwuc3ViKHZlcnRleCwgY2VudGVyKS5ub3JtYWxpemUoKTtcblxuICAgICAgICAgICAgICAgIG5vcm1hbHMuc2V0KFtub3JtYWwueCwgbm9ybWFsLnksIG5vcm1hbC56XSwgaWR4ICogMyk7XG5cbiAgICAgICAgICAgICAgICAvLyB1dlxuICAgICAgICAgICAgICAgIHV2cy5zZXQoW2kgLyB0dWJ1bGFyU2VnbWVudHMsIGogLyByYWRpYWxTZWdtZW50c10sIGlkeCAqIDIpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gZ2VuZXJhdGUgaW5kaWNlc1xuICAgICAgICBpZHggPSAwO1xuICAgICAgICBmb3IgKGxldCBqID0gMTsgaiA8PSByYWRpYWxTZWdtZW50czsgaisrKSB7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMTsgaSA8PSB0dWJ1bGFyU2VnbWVudHM7IGkrKywgaWR4KyspIHtcbiAgICAgICAgICAgICAgICAvLyBpbmRpY2VzXG4gICAgICAgICAgICAgICAgY29uc3QgYSA9ICh0dWJ1bGFyU2VnbWVudHMgKyAxKSAqIGogKyBpIC0gMTtcbiAgICAgICAgICAgICAgICBjb25zdCBiID0gKHR1YnVsYXJTZWdtZW50cyArIDEpICogKGogLSAxKSArIGkgLSAxO1xuICAgICAgICAgICAgICAgIGNvbnN0IGMgPSAodHVidWxhclNlZ21lbnRzICsgMSkgKiAoaiAtIDEpICsgaTtcbiAgICAgICAgICAgICAgICBjb25zdCBkID0gKHR1YnVsYXJTZWdtZW50cyArIDEpICogaiArIGk7XG5cbiAgICAgICAgICAgICAgICAvLyBmYWNlc1xuICAgICAgICAgICAgICAgIGluZGljZXMuc2V0KFthLCBiLCBkLCBiLCBjLCBkXSwgaWR4ICogNik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBPYmplY3QuYXNzaWduKGF0dHJpYnV0ZXMsIHtcbiAgICAgICAgICAgIHBvc2l0aW9uOiB7IHNpemU6IDMsIGRhdGE6IHZlcnRpY2VzIH0sXG4gICAgICAgICAgICBub3JtYWw6IHsgc2l6ZTogMywgZGF0YTogbm9ybWFscyB9LFxuICAgICAgICAgICAgdXY6IHsgc2l6ZTogMiwgZGF0YTogdXZzIH0sXG4gICAgICAgICAgICBpbmRleDogeyBkYXRhOiBpbmRpY2VzIH0sXG4gICAgICAgIH0pO1xuXG4gICAgICAgIHN1cGVyKGdsLCBhdHRyaWJ1dGVzKTtcbiAgICB9XG59XG4iLCIvLyBCYXNlZCBmcm9tIFRocmVlSlMnIE9yYml0Q29udHJvbHMgY2xhc3MsIHJld3JpdHRlbiB1c2luZyBlczYgd2l0aCBzb21lIGFkZGl0aW9ucyBhbmQgc3VidHJhY3Rpb25zLlxuLy8gVE9ETzogYWJzdHJhY3QgZXZlbnQgaGFuZGxlcnMgc28gY2FuIGJlIGZlZCBmcm9tIG90aGVyIHNvdXJjZXNcbi8vIFRPRE86IG1ha2Ugc2Nyb2xsIHpvb20gbW9yZSBhY2N1cmF0ZSB0aGFuIGp1c3QgPi88IHplcm9cbi8vIFRPRE86IGJlIGFibGUgdG8gcGFzcyBpbiBuZXcgY2FtZXJhIHBvc2l0aW9uXG5cbmltcG9ydCB7IFZlYzMgfSBmcm9tICcuLi9tYXRoL1ZlYzMuanMnO1xuaW1wb3J0IHsgVmVjMiB9IGZyb20gJy4uL21hdGgvVmVjMi5qcyc7XG5cbmNvbnN0IFNUQVRFID0geyBOT05FOiAtMSwgUk9UQVRFOiAwLCBET0xMWTogMSwgUEFOOiAyLCBET0xMWV9QQU46IDMgfTtcbmNvbnN0IHRlbXBWZWMzID0gLyogQF9fUFVSRV9fICovIG5ldyBWZWMzKCk7XG5jb25zdCB0ZW1wVmVjMmEgPSAvKiBAX19QVVJFX18gKi8gbmV3IFZlYzIoKTtcbmNvbnN0IHRlbXBWZWMyYiA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgVmVjMigpO1xuXG5leHBvcnQgZnVuY3Rpb24gT3JiaXQoXG4gICAgb2JqZWN0LFxuICAgIHtcbiAgICAgICAgZWxlbWVudCA9IGRvY3VtZW50LFxuICAgICAgICBlbmFibGVkID0gdHJ1ZSxcbiAgICAgICAgdGFyZ2V0ID0gbmV3IFZlYzMoKSxcbiAgICAgICAgZWFzZSA9IDAuMjUsXG4gICAgICAgIGluZXJ0aWEgPSAwLjg1LFxuICAgICAgICBlbmFibGVSb3RhdGUgPSB0cnVlLFxuICAgICAgICByb3RhdGVTcGVlZCA9IDAuMSxcbiAgICAgICAgYXV0b1JvdGF0ZSA9IGZhbHNlLFxuICAgICAgICBhdXRvUm90YXRlU3BlZWQgPSAxLjAsXG4gICAgICAgIGVuYWJsZVpvb20gPSB0cnVlLFxuICAgICAgICB6b29tU3BlZWQgPSAxLFxuICAgICAgICB6b29tU3R5bGUgPSAnZG9sbHknLFxuICAgICAgICBlbmFibGVQYW4gPSB0cnVlLFxuICAgICAgICBwYW5TcGVlZCA9IDAuMSxcbiAgICAgICAgbWluUG9sYXJBbmdsZSA9IDAsXG4gICAgICAgIG1heFBvbGFyQW5nbGUgPSBNYXRoLlBJLFxuICAgICAgICBtaW5BemltdXRoQW5nbGUgPSAtSW5maW5pdHksXG4gICAgICAgIG1heEF6aW11dGhBbmdsZSA9IEluZmluaXR5LFxuICAgICAgICBtaW5EaXN0YW5jZSA9IDAsXG4gICAgICAgIG1heERpc3RhbmNlID0gSW5maW5pdHksXG4gICAgfSA9IHt9XG4pIHtcbiAgICB0aGlzLmVuYWJsZWQgPSBlbmFibGVkO1xuICAgIHRoaXMudGFyZ2V0ID0gdGFyZ2V0O1xuICAgIHRoaXMuem9vbVN0eWxlID0gem9vbVN0eWxlO1xuXG4gICAgLy8gQ2F0Y2ggYXR0ZW1wdHMgdG8gZGlzYWJsZSAtIHNldCB0byAxIHNvIGhhcyBubyBlZmZlY3RcbiAgICBlYXNlID0gZWFzZSB8fCAxO1xuICAgIGluZXJ0aWEgPSBpbmVydGlhIHx8IDA7XG5cbiAgICB0aGlzLm1pbkRpc3RhbmNlID0gbWluRGlzdGFuY2U7XG4gICAgdGhpcy5tYXhEaXN0YW5jZSA9IG1heERpc3RhbmNlO1xuXG4gICAgLy8gY3VycmVudCBwb3NpdGlvbiBpbiBzcGhlcmljYWxUYXJnZXQgY29vcmRpbmF0ZXNcbiAgICBjb25zdCBzcGhlcmljYWxEZWx0YSA9IHsgcmFkaXVzOiAxLCBwaGk6IDAsIHRoZXRhOiAwIH07XG4gICAgY29uc3Qgc3BoZXJpY2FsVGFyZ2V0ID0geyByYWRpdXM6IDEsIHBoaTogMCwgdGhldGE6IDAgfTtcbiAgICBjb25zdCBzcGhlcmljYWwgPSB7IHJhZGl1czogMSwgcGhpOiAwLCB0aGV0YTogMCB9O1xuICAgIGNvbnN0IHBhbkRlbHRhID0gbmV3IFZlYzMoKTtcblxuICAgIC8vIEdyYWIgaW5pdGlhbCBwb3NpdGlvbiB2YWx1ZXNcbiAgICBjb25zdCBvZmZzZXQgPSBuZXcgVmVjMygpO1xuICAgIG9mZnNldC5jb3B5KG9iamVjdC5wb3NpdGlvbikuc3ViKHRoaXMudGFyZ2V0KTtcbiAgICBzcGhlcmljYWwucmFkaXVzID0gc3BoZXJpY2FsVGFyZ2V0LnJhZGl1cyA9IG9mZnNldC5kaXN0YW5jZSgpO1xuICAgIHNwaGVyaWNhbC50aGV0YSA9IHNwaGVyaWNhbFRhcmdldC50aGV0YSA9IE1hdGguYXRhbjIob2Zmc2V0LngsIG9mZnNldC56KTtcbiAgICBzcGhlcmljYWwucGhpID0gc3BoZXJpY2FsVGFyZ2V0LnBoaSA9IE1hdGguYWNvcyhNYXRoLm1pbihNYXRoLm1heChvZmZzZXQueSAvIHNwaGVyaWNhbFRhcmdldC5yYWRpdXMsIC0xKSwgMSkpO1xuXG4gICAgdGhpcy5vZmZzZXQgPSBvZmZzZXQ7XG5cbiAgICB0aGlzLnVwZGF0ZSA9ICgpID0+IHtcbiAgICAgICAgaWYgKGF1dG9Sb3RhdGUpIHtcbiAgICAgICAgICAgIGhhbmRsZUF1dG9Sb3RhdGUoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIGFwcGx5IGRlbHRhXG4gICAgICAgIHNwaGVyaWNhbFRhcmdldC5yYWRpdXMgKj0gc3BoZXJpY2FsRGVsdGEucmFkaXVzO1xuICAgICAgICBzcGhlcmljYWxUYXJnZXQudGhldGEgKz0gc3BoZXJpY2FsRGVsdGEudGhldGE7XG4gICAgICAgIHNwaGVyaWNhbFRhcmdldC5waGkgKz0gc3BoZXJpY2FsRGVsdGEucGhpO1xuXG4gICAgICAgIC8vIGFwcGx5IGJvdW5kYXJpZXNcbiAgICAgICAgc3BoZXJpY2FsVGFyZ2V0LnRoZXRhID0gTWF0aC5tYXgobWluQXppbXV0aEFuZ2xlLCBNYXRoLm1pbihtYXhBemltdXRoQW5nbGUsIHNwaGVyaWNhbFRhcmdldC50aGV0YSkpO1xuICAgICAgICBzcGhlcmljYWxUYXJnZXQucGhpID0gTWF0aC5tYXgobWluUG9sYXJBbmdsZSwgTWF0aC5taW4obWF4UG9sYXJBbmdsZSwgc3BoZXJpY2FsVGFyZ2V0LnBoaSkpO1xuICAgICAgICBzcGhlcmljYWxUYXJnZXQucmFkaXVzID0gTWF0aC5tYXgodGhpcy5taW5EaXN0YW5jZSwgTWF0aC5taW4odGhpcy5tYXhEaXN0YW5jZSwgc3BoZXJpY2FsVGFyZ2V0LnJhZGl1cykpO1xuXG4gICAgICAgIC8vIGVhc2UgdmFsdWVzXG4gICAgICAgIHNwaGVyaWNhbC5waGkgKz0gKHNwaGVyaWNhbFRhcmdldC5waGkgLSBzcGhlcmljYWwucGhpKSAqIGVhc2U7XG4gICAgICAgIHNwaGVyaWNhbC50aGV0YSArPSAoc3BoZXJpY2FsVGFyZ2V0LnRoZXRhIC0gc3BoZXJpY2FsLnRoZXRhKSAqIGVhc2U7XG4gICAgICAgIHNwaGVyaWNhbC5yYWRpdXMgKz0gKHNwaGVyaWNhbFRhcmdldC5yYWRpdXMgLSBzcGhlcmljYWwucmFkaXVzKSAqIGVhc2U7XG5cbiAgICAgICAgLy8gYXBwbHkgcGFuIHRvIHRhcmdldC4gQXMgb2Zmc2V0IGlzIHJlbGF0aXZlIHRvIHRhcmdldCwgaXQgYWxzbyBzaGlmdHNcbiAgICAgICAgdGhpcy50YXJnZXQuYWRkKHBhbkRlbHRhKTtcblxuICAgICAgICAvLyBhcHBseSByb3RhdGlvbiB0byBvZmZzZXRcbiAgICAgICAgbGV0IHNpblBoaVJhZGl1cyA9IHNwaGVyaWNhbC5yYWRpdXMgKiBNYXRoLnNpbihNYXRoLm1heCgwLjAwMDAwMSwgc3BoZXJpY2FsLnBoaSkpO1xuICAgICAgICBvZmZzZXQueCA9IHNpblBoaVJhZGl1cyAqIE1hdGguc2luKHNwaGVyaWNhbC50aGV0YSk7XG4gICAgICAgIG9mZnNldC55ID0gc3BoZXJpY2FsLnJhZGl1cyAqIE1hdGguY29zKHNwaGVyaWNhbC5waGkpO1xuICAgICAgICBvZmZzZXQueiA9IHNpblBoaVJhZGl1cyAqIE1hdGguY29zKHNwaGVyaWNhbC50aGV0YSk7XG5cbiAgICAgICAgLy8gQXBwbHkgdXBkYXRlZCB2YWx1ZXMgdG8gb2JqZWN0XG4gICAgICAgIG9iamVjdC5wb3NpdGlvbi5jb3B5KHRoaXMudGFyZ2V0KS5hZGQob2Zmc2V0KTtcbiAgICAgICAgb2JqZWN0Lmxvb2tBdCh0aGlzLnRhcmdldCk7XG5cbiAgICAgICAgLy8gQXBwbHkgaW5lcnRpYSB0byB2YWx1ZXNcbiAgICAgICAgc3BoZXJpY2FsRGVsdGEudGhldGEgKj0gaW5lcnRpYTtcbiAgICAgICAgc3BoZXJpY2FsRGVsdGEucGhpICo9IGluZXJ0aWE7XG4gICAgICAgIHBhbkRlbHRhLm11bHRpcGx5KGluZXJ0aWEpO1xuXG4gICAgICAgIC8vIFJlc2V0IHNjYWxlIGV2ZXJ5IGZyYW1lIHRvIGF2b2lkIGFwcGx5aW5nIHNjYWxlIG11bHRpcGxlIHRpbWVzXG4gICAgICAgIHNwaGVyaWNhbERlbHRhLnJhZGl1cyA9IDE7XG4gICAgfTtcblxuICAgIC8vIFVwZGF0ZXMgaW50ZXJuYWxzIHdpdGggbmV3IHBvc2l0aW9uXG4gICAgdGhpcy5mb3JjZVBvc2l0aW9uID0gKCkgPT4ge1xuICAgICAgICBvZmZzZXQuY29weShvYmplY3QucG9zaXRpb24pLnN1Yih0aGlzLnRhcmdldCk7XG4gICAgICAgIHNwaGVyaWNhbC5yYWRpdXMgPSBzcGhlcmljYWxUYXJnZXQucmFkaXVzID0gb2Zmc2V0LmRpc3RhbmNlKCk7XG4gICAgICAgIHNwaGVyaWNhbC50aGV0YSA9IHNwaGVyaWNhbFRhcmdldC50aGV0YSA9IE1hdGguYXRhbjIob2Zmc2V0LngsIG9mZnNldC56KTtcbiAgICAgICAgc3BoZXJpY2FsLnBoaSA9IHNwaGVyaWNhbFRhcmdldC5waGkgPSBNYXRoLmFjb3MoTWF0aC5taW4oTWF0aC5tYXgob2Zmc2V0LnkgLyBzcGhlcmljYWxUYXJnZXQucmFkaXVzLCAtMSksIDEpKTtcbiAgICAgICAgb2JqZWN0Lmxvb2tBdCh0aGlzLnRhcmdldCk7XG4gICAgfTtcblxuICAgIC8vIEV2ZXJ5dGhpbmcgYmVsb3cgaGVyZSBqdXN0IHVwZGF0ZXMgcGFuRGVsdGEgYW5kIHNwaGVyaWNhbERlbHRhXG4gICAgLy8gVXNpbmcgdGhvc2UgdHdvIG9iamVjdHMnIHZhbHVlcywgdGhlIG9yYml0IGlzIGNhbGN1bGF0ZWRcblxuICAgIGNvbnN0IHJvdGF0ZVN0YXJ0ID0gbmV3IFZlYzIoKTtcbiAgICBjb25zdCBwYW5TdGFydCA9IG5ldyBWZWMyKCk7XG4gICAgY29uc3QgZG9sbHlTdGFydCA9IG5ldyBWZWMyKCk7XG5cbiAgICBsZXQgc3RhdGUgPSBTVEFURS5OT05FO1xuICAgIHRoaXMubW91c2VCdXR0b25zID0geyBPUkJJVDogMCwgWk9PTTogMSwgUEFOOiAyIH07XG5cbiAgICBmdW5jdGlvbiBnZXRab29tU2NhbGUoKSB7XG4gICAgICAgIHJldHVybiBNYXRoLnBvdygwLjk1LCB6b29tU3BlZWQpO1xuICAgIH1cblxuICAgIGZ1bmN0aW9uIHBhbkxlZnQoZGlzdGFuY2UsIG0pIHtcbiAgICAgICAgdGVtcFZlYzMuc2V0KG1bMF0sIG1bMV0sIG1bMl0pO1xuICAgICAgICB0ZW1wVmVjMy5tdWx0aXBseSgtZGlzdGFuY2UpO1xuICAgICAgICBwYW5EZWx0YS5hZGQodGVtcFZlYzMpO1xuICAgIH1cblxuICAgIGZ1bmN0aW9uIHBhblVwKGRpc3RhbmNlLCBtKSB7XG4gICAgICAgIHRlbXBWZWMzLnNldChtWzRdLCBtWzVdLCBtWzZdKTtcbiAgICAgICAgdGVtcFZlYzMubXVsdGlwbHkoZGlzdGFuY2UpO1xuICAgICAgICBwYW5EZWx0YS5hZGQodGVtcFZlYzMpO1xuICAgIH1cblxuICAgIGNvbnN0IHBhbiA9IChkZWx0YVgsIGRlbHRhWSkgPT4ge1xuICAgICAgICBsZXQgZWwgPSBlbGVtZW50ID09PSBkb2N1bWVudCA/IGRvY3VtZW50LmJvZHkgOiBlbGVtZW50O1xuICAgICAgICB0ZW1wVmVjMy5jb3B5KG9iamVjdC5wb3NpdGlvbikuc3ViKHRoaXMudGFyZ2V0KTtcbiAgICAgICAgbGV0IHRhcmdldERpc3RhbmNlID0gdGVtcFZlYzMuZGlzdGFuY2UoKTtcbiAgICAgICAgdGFyZ2V0RGlzdGFuY2UgKj0gTWF0aC50YW4oKCgob2JqZWN0LmZvdiB8fCA0NSkgLyAyKSAqIE1hdGguUEkpIC8gMTgwLjApO1xuICAgICAgICBwYW5MZWZ0KCgyICogZGVsdGFYICogdGFyZ2V0RGlzdGFuY2UpIC8gZWwuY2xpZW50SGVpZ2h0LCBvYmplY3QubWF0cml4KTtcbiAgICAgICAgcGFuVXAoKDIgKiBkZWx0YVkgKiB0YXJnZXREaXN0YW5jZSkgLyBlbC5jbGllbnRIZWlnaHQsIG9iamVjdC5tYXRyaXgpO1xuICAgIH07XG5cbiAgICBjb25zdCBkb2xseSA9IChkb2xseVNjYWxlKSA9PiB7XG4gICAgICAgIGlmICh0aGlzLnpvb21TdHlsZSA9PT0gJ2RvbGx5Jykgc3BoZXJpY2FsRGVsdGEucmFkaXVzIC89IGRvbGx5U2NhbGU7XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgb2JqZWN0LmZvdiAvPSBkb2xseVNjYWxlO1xuICAgICAgICAgICAgaWYgKG9iamVjdC50eXBlID09PSAnb3J0aG9ncmFwaGljJykgb2JqZWN0Lm9ydGhvZ3JhcGhpYygpO1xuICAgICAgICAgICAgZWxzZSBvYmplY3QucGVyc3BlY3RpdmUoKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBmdW5jdGlvbiBoYW5kbGVBdXRvUm90YXRlKCkge1xuICAgICAgICBjb25zdCBhbmdsZSA9ICgoMiAqIE1hdGguUEkpIC8gNjAgLyA2MCkgKiBhdXRvUm90YXRlU3BlZWQ7XG4gICAgICAgIHNwaGVyaWNhbERlbHRhLnRoZXRhIC09IGFuZ2xlO1xuICAgIH1cblxuICAgIGZ1bmN0aW9uIGhhbmRsZU1vdmVSb3RhdGUoeCwgeSkge1xuICAgICAgICB0ZW1wVmVjMmEuc2V0KHgsIHkpO1xuICAgICAgICB0ZW1wVmVjMmIuc3ViKHRlbXBWZWMyYSwgcm90YXRlU3RhcnQpLm11bHRpcGx5KHJvdGF0ZVNwZWVkKTtcbiAgICAgICAgbGV0IGVsID0gZWxlbWVudCA9PT0gZG9jdW1lbnQgPyBkb2N1bWVudC5ib2R5IDogZWxlbWVudDtcbiAgICAgICAgc3BoZXJpY2FsRGVsdGEudGhldGEgLT0gKDIgKiBNYXRoLlBJICogdGVtcFZlYzJiLngpIC8gZWwuY2xpZW50SGVpZ2h0O1xuICAgICAgICBzcGhlcmljYWxEZWx0YS5waGkgLT0gKDIgKiBNYXRoLlBJICogdGVtcFZlYzJiLnkpIC8gZWwuY2xpZW50SGVpZ2h0O1xuICAgICAgICByb3RhdGVTdGFydC5jb3B5KHRlbXBWZWMyYSk7XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gaGFuZGxlTW91c2VNb3ZlRG9sbHkoZSkge1xuICAgICAgICB0ZW1wVmVjMmEuc2V0KGUuY2xpZW50WCwgZS5jbGllbnRZKTtcbiAgICAgICAgdGVtcFZlYzJiLnN1Yih0ZW1wVmVjMmEsIGRvbGx5U3RhcnQpO1xuICAgICAgICBpZiAodGVtcFZlYzJiLnkgPiAwKSB7XG4gICAgICAgICAgICBkb2xseShnZXRab29tU2NhbGUoKSk7XG4gICAgICAgIH0gZWxzZSBpZiAodGVtcFZlYzJiLnkgPCAwKSB7XG4gICAgICAgICAgICBkb2xseSgxIC8gZ2V0Wm9vbVNjYWxlKCkpO1xuICAgICAgICB9XG4gICAgICAgIGRvbGx5U3RhcnQuY29weSh0ZW1wVmVjMmEpO1xuICAgIH1cblxuICAgIGZ1bmN0aW9uIGhhbmRsZU1vdmVQYW4oeCwgeSkge1xuICAgICAgICB0ZW1wVmVjMmEuc2V0KHgsIHkpO1xuICAgICAgICB0ZW1wVmVjMmIuc3ViKHRlbXBWZWMyYSwgcGFuU3RhcnQpLm11bHRpcGx5KHBhblNwZWVkKTtcbiAgICAgICAgcGFuKHRlbXBWZWMyYi54LCB0ZW1wVmVjMmIueSk7XG4gICAgICAgIHBhblN0YXJ0LmNvcHkodGVtcFZlYzJhKTtcbiAgICB9XG5cbiAgICBmdW5jdGlvbiBoYW5kbGVUb3VjaFN0YXJ0RG9sbHlQYW4oZSkge1xuICAgICAgICBpZiAoZW5hYmxlWm9vbSkge1xuICAgICAgICAgICAgbGV0IGR4ID0gZS50b3VjaGVzWzBdLnBhZ2VYIC0gZS50b3VjaGVzWzFdLnBhZ2VYO1xuICAgICAgICAgICAgbGV0IGR5ID0gZS50b3VjaGVzWzBdLnBhZ2VZIC0gZS50b3VjaGVzWzFdLnBhZ2VZO1xuICAgICAgICAgICAgbGV0IGRpc3RhbmNlID0gTWF0aC5zcXJ0KGR4ICogZHggKyBkeSAqIGR5KTtcbiAgICAgICAgICAgIGRvbGx5U3RhcnQuc2V0KDAsIGRpc3RhbmNlKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChlbmFibGVQYW4pIHtcbiAgICAgICAgICAgIGxldCB4ID0gMC41ICogKGUudG91Y2hlc1swXS5wYWdlWCArIGUudG91Y2hlc1sxXS5wYWdlWCk7XG4gICAgICAgICAgICBsZXQgeSA9IDAuNSAqIChlLnRvdWNoZXNbMF0ucGFnZVkgKyBlLnRvdWNoZXNbMV0ucGFnZVkpO1xuICAgICAgICAgICAgcGFuU3RhcnQuc2V0KHgsIHkpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gaGFuZGxlVG91Y2hNb3ZlRG9sbHlQYW4oZSkge1xuICAgICAgICBpZiAoZW5hYmxlWm9vbSkge1xuICAgICAgICAgICAgbGV0IGR4ID0gZS50b3VjaGVzWzBdLnBhZ2VYIC0gZS50b3VjaGVzWzFdLnBhZ2VYO1xuICAgICAgICAgICAgbGV0IGR5ID0gZS50b3VjaGVzWzBdLnBhZ2VZIC0gZS50b3VjaGVzWzFdLnBhZ2VZO1xuICAgICAgICAgICAgbGV0IGRpc3RhbmNlID0gTWF0aC5zcXJ0KGR4ICogZHggKyBkeSAqIGR5KTtcbiAgICAgICAgICAgIHRlbXBWZWMyYS5zZXQoMCwgZGlzdGFuY2UpO1xuICAgICAgICAgICAgdGVtcFZlYzJiLnNldCgwLCBNYXRoLnBvdyh0ZW1wVmVjMmEueSAvIGRvbGx5U3RhcnQueSwgem9vbVNwZWVkKSk7XG4gICAgICAgICAgICBkb2xseSh0ZW1wVmVjMmIueSk7XG4gICAgICAgICAgICBkb2xseVN0YXJ0LmNvcHkodGVtcFZlYzJhKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChlbmFibGVQYW4pIHtcbiAgICAgICAgICAgIGxldCB4ID0gMC41ICogKGUudG91Y2hlc1swXS5wYWdlWCArIGUudG91Y2hlc1sxXS5wYWdlWCk7XG4gICAgICAgICAgICBsZXQgeSA9IDAuNSAqIChlLnRvdWNoZXNbMF0ucGFnZVkgKyBlLnRvdWNoZXNbMV0ucGFnZVkpO1xuICAgICAgICAgICAgaGFuZGxlTW92ZVBhbih4LCB5KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IG9uTW91c2VEb3duID0gKGUpID0+IHtcbiAgICAgICAgaWYgKCF0aGlzLmVuYWJsZWQpIHJldHVybjtcblxuICAgICAgICBzd2l0Y2ggKGUuYnV0dG9uKSB7XG4gICAgICAgICAgICBjYXNlIHRoaXMubW91c2VCdXR0b25zLk9SQklUOlxuICAgICAgICAgICAgICAgIGlmIChlbmFibGVSb3RhdGUgPT09IGZhbHNlKSByZXR1cm47XG4gICAgICAgICAgICAgICAgcm90YXRlU3RhcnQuc2V0KGUuY2xpZW50WCwgZS5jbGllbnRZKTtcbiAgICAgICAgICAgICAgICBzdGF0ZSA9IFNUQVRFLlJPVEFURTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgdGhpcy5tb3VzZUJ1dHRvbnMuWk9PTTpcbiAgICAgICAgICAgICAgICBpZiAoZW5hYmxlWm9vbSA9PT0gZmFsc2UpIHJldHVybjtcbiAgICAgICAgICAgICAgICBkb2xseVN0YXJ0LnNldChlLmNsaWVudFgsIGUuY2xpZW50WSk7XG4gICAgICAgICAgICAgICAgc3RhdGUgPSBTVEFURS5ET0xMWTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgdGhpcy5tb3VzZUJ1dHRvbnMuUEFOOlxuICAgICAgICAgICAgICAgIGlmIChlbmFibGVQYW4gPT09IGZhbHNlKSByZXR1cm47XG4gICAgICAgICAgICAgICAgcGFuU3RhcnQuc2V0KGUuY2xpZW50WCwgZS5jbGllbnRZKTtcbiAgICAgICAgICAgICAgICBzdGF0ZSA9IFNUQVRFLlBBTjtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChzdGF0ZSAhPT0gU1RBVEUuTk9ORSkge1xuICAgICAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlbW92ZScsIG9uTW91c2VNb3ZlLCBmYWxzZSk7XG4gICAgICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignbW91c2V1cCcsIG9uTW91c2VVcCwgZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IG9uTW91c2VNb3ZlID0gKGUpID0+IHtcbiAgICAgICAgaWYgKCF0aGlzLmVuYWJsZWQpIHJldHVybjtcblxuICAgICAgICBzd2l0Y2ggKHN0YXRlKSB7XG4gICAgICAgICAgICBjYXNlIFNUQVRFLlJPVEFURTpcbiAgICAgICAgICAgICAgICBpZiAoZW5hYmxlUm90YXRlID09PSBmYWxzZSkgcmV0dXJuO1xuICAgICAgICAgICAgICAgIGhhbmRsZU1vdmVSb3RhdGUoZS5jbGllbnRYLCBlLmNsaWVudFkpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBTVEFURS5ET0xMWTpcbiAgICAgICAgICAgICAgICBpZiAoZW5hYmxlWm9vbSA9PT0gZmFsc2UpIHJldHVybjtcbiAgICAgICAgICAgICAgICBoYW5kbGVNb3VzZU1vdmVEb2xseShlKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgU1RBVEUuUEFOOlxuICAgICAgICAgICAgICAgIGlmIChlbmFibGVQYW4gPT09IGZhbHNlKSByZXR1cm47XG4gICAgICAgICAgICAgICAgaGFuZGxlTW92ZVBhbihlLmNsaWVudFgsIGUuY2xpZW50WSk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3Qgb25Nb3VzZVVwID0gKCkgPT4ge1xuICAgICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignbW91c2Vtb3ZlJywgb25Nb3VzZU1vdmUsIGZhbHNlKTtcbiAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ21vdXNldXAnLCBvbk1vdXNlVXAsIGZhbHNlKTtcbiAgICAgICAgc3RhdGUgPSBTVEFURS5OT05FO1xuICAgIH07XG5cbiAgICBjb25zdCBvbk1vdXNlV2hlZWwgPSAoZSkgPT4ge1xuICAgICAgICBpZiAoIXRoaXMuZW5hYmxlZCB8fCAhZW5hYmxlWm9vbSB8fCAoc3RhdGUgIT09IFNUQVRFLk5PTkUgJiYgc3RhdGUgIT09IFNUQVRFLlJPVEFURSkpIHJldHVybjtcbiAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuXG4gICAgICAgIGlmIChlLmRlbHRhWSA8IDApIHtcbiAgICAgICAgICAgIGRvbGx5KDEgLyBnZXRab29tU2NhbGUoKSk7XG4gICAgICAgIH0gZWxzZSBpZiAoZS5kZWx0YVkgPiAwKSB7XG4gICAgICAgICAgICBkb2xseShnZXRab29tU2NhbGUoKSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3Qgb25Ub3VjaFN0YXJ0ID0gKGUpID0+IHtcbiAgICAgICAgaWYgKCF0aGlzLmVuYWJsZWQpIHJldHVybjtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuXG4gICAgICAgIHN3aXRjaCAoZS50b3VjaGVzLmxlbmd0aCkge1xuICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgIGlmIChlbmFibGVSb3RhdGUgPT09IGZhbHNlKSByZXR1cm47XG4gICAgICAgICAgICAgICAgcm90YXRlU3RhcnQuc2V0KGUudG91Y2hlc1swXS5wYWdlWCwgZS50b3VjaGVzWzBdLnBhZ2VZKTtcbiAgICAgICAgICAgICAgICBzdGF0ZSA9IFNUQVRFLlJPVEFURTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgMjpcbiAgICAgICAgICAgICAgICBpZiAoZW5hYmxlWm9vbSA9PT0gZmFsc2UgJiYgZW5hYmxlUGFuID09PSBmYWxzZSkgcmV0dXJuO1xuICAgICAgICAgICAgICAgIGhhbmRsZVRvdWNoU3RhcnREb2xseVBhbihlKTtcbiAgICAgICAgICAgICAgICBzdGF0ZSA9IFNUQVRFLkRPTExZX1BBTjtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgc3RhdGUgPSBTVEFURS5OT05FO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IG9uVG91Y2hNb3ZlID0gKGUpID0+IHtcbiAgICAgICAgaWYgKCF0aGlzLmVuYWJsZWQpIHJldHVybjtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuXG4gICAgICAgIHN3aXRjaCAoZS50b3VjaGVzLmxlbmd0aCkge1xuICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgIGlmIChlbmFibGVSb3RhdGUgPT09IGZhbHNlKSByZXR1cm47XG4gICAgICAgICAgICAgICAgaGFuZGxlTW92ZVJvdGF0ZShlLnRvdWNoZXNbMF0ucGFnZVgsIGUudG91Y2hlc1swXS5wYWdlWSk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIDI6XG4gICAgICAgICAgICAgICAgaWYgKGVuYWJsZVpvb20gPT09IGZhbHNlICYmIGVuYWJsZVBhbiA9PT0gZmFsc2UpIHJldHVybjtcbiAgICAgICAgICAgICAgICBoYW5kbGVUb3VjaE1vdmVEb2xseVBhbihlKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgc3RhdGUgPSBTVEFURS5OT05FO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IG9uVG91Y2hFbmQgPSAoKSA9PiB7XG4gICAgICAgIGlmICghdGhpcy5lbmFibGVkKSByZXR1cm47XG4gICAgICAgIHN0YXRlID0gU1RBVEUuTk9ORTtcbiAgICB9O1xuXG4gICAgY29uc3Qgb25Db250ZXh0TWVudSA9IChlKSA9PiB7XG4gICAgICAgIGlmICghdGhpcy5lbmFibGVkKSByZXR1cm47XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICB9O1xuXG4gICAgZnVuY3Rpb24gYWRkSGFuZGxlcnMoKSB7XG4gICAgICAgIGVsZW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignY29udGV4dG1lbnUnLCBvbkNvbnRleHRNZW51LCBmYWxzZSk7XG4gICAgICAgIGVsZW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgb25Nb3VzZURvd24sIGZhbHNlKTtcbiAgICAgICAgZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKCd3aGVlbCcsIG9uTW91c2VXaGVlbCwgeyBwYXNzaXZlOiBmYWxzZSB9KTtcbiAgICAgICAgZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKCd0b3VjaHN0YXJ0Jywgb25Ub3VjaFN0YXJ0LCB7IHBhc3NpdmU6IGZhbHNlIH0pO1xuICAgICAgICBlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3RvdWNoZW5kJywgb25Ub3VjaEVuZCwgZmFsc2UpO1xuICAgICAgICBlbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3RvdWNobW92ZScsIG9uVG91Y2hNb3ZlLCB7IHBhc3NpdmU6IGZhbHNlIH0pO1xuICAgIH1cblxuICAgIHRoaXMucmVtb3ZlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICBlbGVtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2NvbnRleHRtZW51Jywgb25Db250ZXh0TWVudSk7XG4gICAgICAgIGVsZW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgb25Nb3VzZURvd24pO1xuICAgICAgICBlbGVtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3doZWVsJywgb25Nb3VzZVdoZWVsKTtcbiAgICAgICAgZWxlbWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCd0b3VjaHN0YXJ0Jywgb25Ub3VjaFN0YXJ0KTtcbiAgICAgICAgZWxlbWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCd0b3VjaGVuZCcsIG9uVG91Y2hFbmQpO1xuICAgICAgICBlbGVtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3RvdWNobW92ZScsIG9uVG91Y2hNb3ZlKTtcbiAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ21vdXNlbW92ZScsIG9uTW91c2VNb3ZlKTtcbiAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ21vdXNldXAnLCBvbk1vdXNlVXApO1xuICAgIH07XG5cbiAgICBhZGRIYW5kbGVycygpO1xufVxuIiwiLy8gVE9ETzogYmFyeWNlbnRyaWMgY29kZSBzaG91bGRuJ3QgYmUgaGVyZSwgYnV0IHdoZXJlP1xuLy8gVE9ETzogU3BoZXJlQ2FzdD9cblxuaW1wb3J0IHsgVmVjMiB9IGZyb20gJy4uL21hdGgvVmVjMi5qcyc7XG5pbXBvcnQgeyBWZWMzIH0gZnJvbSAnLi4vbWF0aC9WZWMzLmpzJztcbmltcG9ydCB7IE1hdDQgfSBmcm9tICcuLi9tYXRoL01hdDQuanMnO1xuXG5jb25zdCB0ZW1wVmVjMmEgPSAvKiBAX19QVVJFX18gKi8gbmV3IFZlYzIoKTtcbmNvbnN0IHRlbXBWZWMyYiA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgVmVjMigpO1xuY29uc3QgdGVtcFZlYzJjID0gLyogQF9fUFVSRV9fICovIG5ldyBWZWMyKCk7XG5cbmNvbnN0IHRlbXBWZWMzYSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgVmVjMygpO1xuY29uc3QgdGVtcFZlYzNiID0gLyogQF9fUFVSRV9fICovIG5ldyBWZWMzKCk7XG5jb25zdCB0ZW1wVmVjM2MgPSAvKiBAX19QVVJFX18gKi8gbmV3IFZlYzMoKTtcbmNvbnN0IHRlbXBWZWMzZCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgVmVjMygpO1xuY29uc3QgdGVtcFZlYzNlID0gLyogQF9fUFVSRV9fICovIG5ldyBWZWMzKCk7XG5jb25zdCB0ZW1wVmVjM2YgPSAvKiBAX19QVVJFX18gKi8gbmV3IFZlYzMoKTtcbmNvbnN0IHRlbXBWZWMzZyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgVmVjMygpO1xuY29uc3QgdGVtcFZlYzNoID0gLyogQF9fUFVSRV9fICovIG5ldyBWZWMzKCk7XG5jb25zdCB0ZW1wVmVjM2kgPSAvKiBAX19QVVJFX18gKi8gbmV3IFZlYzMoKTtcbmNvbnN0IHRlbXBWZWMzaiA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgVmVjMygpO1xuY29uc3QgdGVtcFZlYzNrID0gLyogQF9fUFVSRV9fICovIG5ldyBWZWMzKCk7XG5cbmNvbnN0IHRlbXBNYXQ0ID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXQ0KCk7XG5cbmV4cG9ydCBjbGFzcyBSYXljYXN0IHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgdGhpcy5vcmlnaW4gPSBuZXcgVmVjMygpO1xuICAgICAgICB0aGlzLmRpcmVjdGlvbiA9IG5ldyBWZWMzKCk7XG4gICAgfVxuXG4gICAgLy8gU2V0IHJheSBmcm9tIG1vdXNlIHVucHJvamVjdGlvblxuICAgIGNhc3RNb3VzZShjYW1lcmEsIG1vdXNlID0gWzAsIDBdKSB7XG4gICAgICAgIGlmIChjYW1lcmEudHlwZSA9PT0gJ29ydGhvZ3JhcGhpYycpIHtcbiAgICAgICAgICAgIC8vIFNldCBvcmlnaW5cbiAgICAgICAgICAgIC8vIFNpbmNlIGNhbWVyYSBpcyBvcnRob2dyYXBoaWMsIG9yaWdpbiBpcyBub3QgdGhlIGNhbWVyYSBwb3NpdGlvblxuICAgICAgICAgICAgY29uc3QgeyBsZWZ0LCByaWdodCwgYm90dG9tLCB0b3AsIHpvb20gfSA9IGNhbWVyYTtcbiAgICAgICAgICAgIGNvbnN0IHggPSBsZWZ0IC8gem9vbSArICgocmlnaHQgLSBsZWZ0KSAvIHpvb20pICogKG1vdXNlWzBdICogMC41ICsgMC41KTtcbiAgICAgICAgICAgIGNvbnN0IHkgPSBib3R0b20gLyB6b29tICsgKCh0b3AgLSBib3R0b20pIC8gem9vbSkgKiAobW91c2VbMV0gKiAwLjUgKyAwLjUpO1xuICAgICAgICAgICAgdGhpcy5vcmlnaW4uc2V0KHgsIHksIDApO1xuICAgICAgICAgICAgdGhpcy5vcmlnaW4uYXBwbHlNYXRyaXg0KGNhbWVyYS53b3JsZE1hdHJpeCk7XG5cbiAgICAgICAgICAgIC8vIFNldCBkaXJlY3Rpb25cbiAgICAgICAgICAgIC8vIGh0dHBzOi8vY29tbXVuaXR5Lmtocm9ub3Mub3JnL3QvZ2V0LWRpcmVjdGlvbi1mcm9tLXRyYW5zZm9ybWF0aW9uLW1hdHJpeC1vci1xdWF0LzY1NTAyLzJcbiAgICAgICAgICAgIHRoaXMuZGlyZWN0aW9uLnggPSAtY2FtZXJhLndvcmxkTWF0cml4WzhdO1xuICAgICAgICAgICAgdGhpcy5kaXJlY3Rpb24ueSA9IC1jYW1lcmEud29ybGRNYXRyaXhbOV07XG4gICAgICAgICAgICB0aGlzLmRpcmVjdGlvbi56ID0gLWNhbWVyYS53b3JsZE1hdHJpeFsxMF07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBTZXQgb3JpZ2luXG4gICAgICAgICAgICBjYW1lcmEud29ybGRNYXRyaXguZ2V0VHJhbnNsYXRpb24odGhpcy5vcmlnaW4pO1xuXG4gICAgICAgICAgICAvLyBTZXQgZGlyZWN0aW9uXG4gICAgICAgICAgICB0aGlzLmRpcmVjdGlvbi5zZXQobW91c2VbMF0sIG1vdXNlWzFdLCAwLjUpO1xuICAgICAgICAgICAgY2FtZXJhLnVucHJvamVjdCh0aGlzLmRpcmVjdGlvbik7XG4gICAgICAgICAgICB0aGlzLmRpcmVjdGlvbi5zdWIodGhpcy5vcmlnaW4pLm5vcm1hbGl6ZSgpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgaW50ZXJzZWN0Qm91bmRzKG1lc2hlcywgeyBtYXhEaXN0YW5jZSwgb3V0cHV0ID0gW10gfSA9IHt9KSB7XG4gICAgICAgIGlmICghQXJyYXkuaXNBcnJheShtZXNoZXMpKSBtZXNoZXMgPSBbbWVzaGVzXTtcblxuICAgICAgICBjb25zdCBpbnZXb3JsZE1hdDQgPSB0ZW1wTWF0NDtcbiAgICAgICAgY29uc3Qgb3JpZ2luID0gdGVtcFZlYzNhO1xuICAgICAgICBjb25zdCBkaXJlY3Rpb24gPSB0ZW1wVmVjM2I7XG5cbiAgICAgICAgY29uc3QgaGl0cyA9IG91dHB1dDtcbiAgICAgICAgaGl0cy5sZW5ndGggPSAwO1xuXG4gICAgICAgIG1lc2hlcy5mb3JFYWNoKChtZXNoKSA9PiB7XG4gICAgICAgICAgICAvLyBDcmVhdGUgYm91bmRzXG4gICAgICAgICAgICBpZiAoIW1lc2guZ2VvbWV0cnkuYm91bmRzIHx8IG1lc2guZ2VvbWV0cnkuYm91bmRzLnJhZGl1cyA9PT0gSW5maW5pdHkpIG1lc2guZ2VvbWV0cnkuY29tcHV0ZUJvdW5kaW5nU3BoZXJlKCk7XG4gICAgICAgICAgICBjb25zdCBib3VuZHMgPSBtZXNoLmdlb21ldHJ5LmJvdW5kcztcbiAgICAgICAgICAgIGludldvcmxkTWF0NC5pbnZlcnNlKG1lc2gud29ybGRNYXRyaXgpO1xuXG4gICAgICAgICAgICAvLyBHZXQgbWF4IGRpc3RhbmNlIGxvY2FsbHlcbiAgICAgICAgICAgIGxldCBsb2NhbE1heERpc3RhbmNlO1xuICAgICAgICAgICAgaWYgKG1heERpc3RhbmNlKSB7XG4gICAgICAgICAgICAgICAgZGlyZWN0aW9uLmNvcHkodGhpcy5kaXJlY3Rpb24pLnNjYWxlUm90YXRlTWF0cml4NChpbnZXb3JsZE1hdDQpO1xuICAgICAgICAgICAgICAgIGxvY2FsTWF4RGlzdGFuY2UgPSBtYXhEaXN0YW5jZSAqIGRpcmVjdGlvbi5sZW4oKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gVGFrZSB3b3JsZCBzcGFjZSByYXkgYW5kIG1ha2UgaXQgb2JqZWN0IHNwYWNlIHRvIGFsaWduIHdpdGggYm91bmRpbmcgYm94XG4gICAgICAgICAgICBvcmlnaW4uY29weSh0aGlzLm9yaWdpbikuYXBwbHlNYXRyaXg0KGludldvcmxkTWF0NCk7XG4gICAgICAgICAgICBkaXJlY3Rpb24uY29weSh0aGlzLmRpcmVjdGlvbikudHJhbnNmb3JtRGlyZWN0aW9uKGludldvcmxkTWF0NCk7XG5cbiAgICAgICAgICAgIC8vIEJyZWFrIG91dCBlYXJseSBpZiBib3VuZHMgdG9vIGZhciBhd2F5IGZyb20gb3JpZ2luXG4gICAgICAgICAgICBpZiAobWF4RGlzdGFuY2UpIHtcbiAgICAgICAgICAgICAgICBpZiAob3JpZ2luLmRpc3RhbmNlKGJvdW5kcy5jZW50ZXIpIC0gYm91bmRzLnJhZGl1cyA+IGxvY2FsTWF4RGlzdGFuY2UpIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgbGV0IGxvY2FsRGlzdGFuY2UgPSAwO1xuXG4gICAgICAgICAgICAvLyBDaGVjayBvcmlnaW4gaXNuJ3QgaW5zaWRlIGJvdW5kcyBiZWZvcmUgdGVzdGluZyBpbnRlcnNlY3Rpb25cbiAgICAgICAgICAgIGlmIChtZXNoLmdlb21ldHJ5LnJheWNhc3QgPT09ICdzcGhlcmUnKSB7XG4gICAgICAgICAgICAgICAgaWYgKG9yaWdpbi5kaXN0YW5jZShib3VuZHMuY2VudGVyKSA+IGJvdW5kcy5yYWRpdXMpIHtcbiAgICAgICAgICAgICAgICAgICAgbG9jYWxEaXN0YW5jZSA9IHRoaXMuaW50ZXJzZWN0U3BoZXJlKGJvdW5kcywgb3JpZ2luLCBkaXJlY3Rpb24pO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWxvY2FsRGlzdGFuY2UpIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGlmIChcbiAgICAgICAgICAgICAgICAgICAgb3JpZ2luLnggPCBib3VuZHMubWluLnggfHxcbiAgICAgICAgICAgICAgICAgICAgb3JpZ2luLnggPiBib3VuZHMubWF4LnggfHxcbiAgICAgICAgICAgICAgICAgICAgb3JpZ2luLnkgPCBib3VuZHMubWluLnkgfHxcbiAgICAgICAgICAgICAgICAgICAgb3JpZ2luLnkgPiBib3VuZHMubWF4LnkgfHxcbiAgICAgICAgICAgICAgICAgICAgb3JpZ2luLnogPCBib3VuZHMubWluLnogfHxcbiAgICAgICAgICAgICAgICAgICAgb3JpZ2luLnogPiBib3VuZHMubWF4LnpcbiAgICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICAgICAgbG9jYWxEaXN0YW5jZSA9IHRoaXMuaW50ZXJzZWN0Qm94KGJvdW5kcywgb3JpZ2luLCBkaXJlY3Rpb24pO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWxvY2FsRGlzdGFuY2UpIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChtYXhEaXN0YW5jZSAmJiBsb2NhbERpc3RhbmNlID4gbG9jYWxNYXhEaXN0YW5jZSkgcmV0dXJuO1xuXG4gICAgICAgICAgICAvLyBDcmVhdGUgb2JqZWN0IG9uIG1lc2ggdG8gYXZvaWQgZ2VuZXJhdGluZyBsb3RzIG9mIG9iamVjdHNcbiAgICAgICAgICAgIGlmICghbWVzaC5oaXQpIG1lc2guaGl0ID0geyBsb2NhbFBvaW50OiBuZXcgVmVjMygpLCBwb2ludDogbmV3IFZlYzMoKSB9O1xuXG4gICAgICAgICAgICBtZXNoLmhpdC5sb2NhbFBvaW50LmNvcHkoZGlyZWN0aW9uKS5tdWx0aXBseShsb2NhbERpc3RhbmNlKS5hZGQob3JpZ2luKTtcbiAgICAgICAgICAgIG1lc2guaGl0LnBvaW50LmNvcHkobWVzaC5oaXQubG9jYWxQb2ludCkuYXBwbHlNYXRyaXg0KG1lc2gud29ybGRNYXRyaXgpO1xuICAgICAgICAgICAgbWVzaC5oaXQuZGlzdGFuY2UgPSBtZXNoLmhpdC5wb2ludC5kaXN0YW5jZSh0aGlzLm9yaWdpbik7XG5cbiAgICAgICAgICAgIGhpdHMucHVzaChtZXNoKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaGl0cy5zb3J0KChhLCBiKSA9PiBhLmhpdC5kaXN0YW5jZSAtIGIuaGl0LmRpc3RhbmNlKTtcbiAgICAgICAgcmV0dXJuIGhpdHM7XG4gICAgfVxuXG4gICAgaW50ZXJzZWN0TWVzaGVzKG1lc2hlcywgeyBjdWxsRmFjZSA9IHRydWUsIG1heERpc3RhbmNlLCBpbmNsdWRlVVYgPSB0cnVlLCBpbmNsdWRlTm9ybWFsID0gdHJ1ZSwgb3V0cHV0ID0gW10gfSA9IHt9KSB7XG4gICAgICAgIC8vIFRlc3QgYm91bmRzIGZpcnN0IGJlZm9yZSB0ZXN0aW5nIGdlb21ldHJ5XG4gICAgICAgIGNvbnN0IGhpdHMgPSB0aGlzLmludGVyc2VjdEJvdW5kcyhtZXNoZXMsIHsgbWF4RGlzdGFuY2UsIG91dHB1dCB9KTtcbiAgICAgICAgaWYgKCFoaXRzLmxlbmd0aCkgcmV0dXJuIGhpdHM7XG5cbiAgICAgICAgY29uc3QgaW52V29ybGRNYXQ0ID0gdGVtcE1hdDQ7XG4gICAgICAgIGNvbnN0IG9yaWdpbiA9IHRlbXBWZWMzYTtcbiAgICAgICAgY29uc3QgZGlyZWN0aW9uID0gdGVtcFZlYzNiO1xuICAgICAgICBjb25zdCBhID0gdGVtcFZlYzNjO1xuICAgICAgICBjb25zdCBiID0gdGVtcFZlYzNkO1xuICAgICAgICBjb25zdCBjID0gdGVtcFZlYzNlO1xuICAgICAgICBjb25zdCBjbG9zZXN0RmFjZU5vcm1hbCA9IHRlbXBWZWMzZjtcbiAgICAgICAgY29uc3QgZmFjZU5vcm1hbCA9IHRlbXBWZWMzZztcbiAgICAgICAgY29uc3QgYmFyeWNvb3JkID0gdGVtcFZlYzNoO1xuICAgICAgICBjb25zdCB1dkEgPSB0ZW1wVmVjMmE7XG4gICAgICAgIGNvbnN0IHV2QiA9IHRlbXBWZWMyYjtcbiAgICAgICAgY29uc3QgdXZDID0gdGVtcFZlYzJjO1xuXG4gICAgICAgIGZvciAobGV0IGkgPSBoaXRzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICAgICAgICBjb25zdCBtZXNoID0gaGl0c1tpXTtcbiAgICAgICAgICAgIGludldvcmxkTWF0NC5pbnZlcnNlKG1lc2gud29ybGRNYXRyaXgpO1xuXG4gICAgICAgICAgICAvLyBHZXQgbWF4IGRpc3RhbmNlIGxvY2FsbHlcbiAgICAgICAgICAgIGxldCBsb2NhbE1heERpc3RhbmNlO1xuICAgICAgICAgICAgaWYgKG1heERpc3RhbmNlKSB7XG4gICAgICAgICAgICAgICAgZGlyZWN0aW9uLmNvcHkodGhpcy5kaXJlY3Rpb24pLnNjYWxlUm90YXRlTWF0cml4NChpbnZXb3JsZE1hdDQpO1xuICAgICAgICAgICAgICAgIGxvY2FsTWF4RGlzdGFuY2UgPSBtYXhEaXN0YW5jZSAqIGRpcmVjdGlvbi5sZW4oKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gVGFrZSB3b3JsZCBzcGFjZSByYXkgYW5kIG1ha2UgaXQgb2JqZWN0IHNwYWNlIHRvIGFsaWduIHdpdGggYm91bmRpbmcgYm94XG4gICAgICAgICAgICBvcmlnaW4uY29weSh0aGlzLm9yaWdpbikuYXBwbHlNYXRyaXg0KGludldvcmxkTWF0NCk7XG4gICAgICAgICAgICBkaXJlY3Rpb24uY29weSh0aGlzLmRpcmVjdGlvbikudHJhbnNmb3JtRGlyZWN0aW9uKGludldvcmxkTWF0NCk7XG5cbiAgICAgICAgICAgIGxldCBsb2NhbERpc3RhbmNlID0gMDtcbiAgICAgICAgICAgIGxldCBjbG9zZXN0QSwgY2xvc2VzdEIsIGNsb3Nlc3RDO1xuXG4gICAgICAgICAgICBjb25zdCBnZW9tZXRyeSA9IG1lc2guZ2VvbWV0cnk7XG4gICAgICAgICAgICBjb25zdCBhdHRyaWJ1dGVzID0gZ2VvbWV0cnkuYXR0cmlidXRlcztcbiAgICAgICAgICAgIGNvbnN0IGluZGV4ID0gYXR0cmlidXRlcy5pbmRleDtcbiAgICAgICAgICAgIGNvbnN0IHBvc2l0aW9uID0gYXR0cmlidXRlcy5wb3NpdGlvbjtcblxuICAgICAgICAgICAgY29uc3Qgc3RhcnQgPSBNYXRoLm1heCgwLCBnZW9tZXRyeS5kcmF3UmFuZ2Uuc3RhcnQpO1xuICAgICAgICAgICAgY29uc3QgZW5kID0gTWF0aC5taW4oaW5kZXggPyBpbmRleC5jb3VudCA6IHBvc2l0aW9uLmNvdW50LCBnZW9tZXRyeS5kcmF3UmFuZ2Uuc3RhcnQgKyBnZW9tZXRyeS5kcmF3UmFuZ2UuY291bnQpO1xuICAgICAgICAgICAgLy8gRGF0YSBsb2FkZWQgc2hvdWxkbid0IGhhYXZlIHN0cmlkZSwgb25seSBidWZmZXJzXG4gICAgICAgICAgICAvLyBjb25zdCBzdHJpZGUgPSBwb3NpdGlvbi5zdHJpZGUgPyBwb3NpdGlvbi5zdHJpZGUgLyBwb3NpdGlvbi5kYXRhLkJZVEVTX1BFUl9FTEVNRU5UIDogcG9zaXRpb24uc2l6ZTtcbiAgICAgICAgICAgIGNvbnN0IHN0cmlkZSA9IHBvc2l0aW9uLnNpemU7XG5cbiAgICAgICAgICAgIGZvciAobGV0IGogPSBzdGFydDsgaiA8IGVuZDsgaiArPSAzKSB7XG4gICAgICAgICAgICAgICAgLy8gUG9zaXRpb24gYXR0cmlidXRlIGluZGljZXMgZm9yIGVhY2ggdHJpYW5nbGVcbiAgICAgICAgICAgICAgICBjb25zdCBhaSA9IGluZGV4ID8gaW5kZXguZGF0YVtqXSA6IGo7XG4gICAgICAgICAgICAgICAgY29uc3QgYmkgPSBpbmRleCA/IGluZGV4LmRhdGFbaiArIDFdIDogaiArIDE7XG4gICAgICAgICAgICAgICAgY29uc3QgY2kgPSBpbmRleCA/IGluZGV4LmRhdGFbaiArIDJdIDogaiArIDI7XG5cbiAgICAgICAgICAgICAgICBhLmZyb21BcnJheShwb3NpdGlvbi5kYXRhLCBhaSAqIHN0cmlkZSk7XG4gICAgICAgICAgICAgICAgYi5mcm9tQXJyYXkocG9zaXRpb24uZGF0YSwgYmkgKiBzdHJpZGUpO1xuICAgICAgICAgICAgICAgIGMuZnJvbUFycmF5KHBvc2l0aW9uLmRhdGEsIGNpICogc3RyaWRlKTtcblxuICAgICAgICAgICAgICAgIGNvbnN0IGRpc3RhbmNlID0gdGhpcy5pbnRlcnNlY3RUcmlhbmdsZShhLCBiLCBjLCBjdWxsRmFjZSwgb3JpZ2luLCBkaXJlY3Rpb24sIGZhY2VOb3JtYWwpO1xuICAgICAgICAgICAgICAgIGlmICghZGlzdGFuY2UpIGNvbnRpbnVlO1xuXG4gICAgICAgICAgICAgICAgLy8gVG9vIGZhciBhd2F5XG4gICAgICAgICAgICAgICAgaWYgKG1heERpc3RhbmNlICYmIGRpc3RhbmNlID4gbG9jYWxNYXhEaXN0YW5jZSkgY29udGludWU7XG5cbiAgICAgICAgICAgICAgICBpZiAoIWxvY2FsRGlzdGFuY2UgfHwgZGlzdGFuY2UgPCBsb2NhbERpc3RhbmNlKSB7XG4gICAgICAgICAgICAgICAgICAgIGxvY2FsRGlzdGFuY2UgPSBkaXN0YW5jZTtcbiAgICAgICAgICAgICAgICAgICAgY2xvc2VzdEEgPSBhaTtcbiAgICAgICAgICAgICAgICAgICAgY2xvc2VzdEIgPSBiaTtcbiAgICAgICAgICAgICAgICAgICAgY2xvc2VzdEMgPSBjaTtcbiAgICAgICAgICAgICAgICAgICAgY2xvc2VzdEZhY2VOb3JtYWwuY29weShmYWNlTm9ybWFsKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmICghbG9jYWxEaXN0YW5jZSkgaGl0cy5zcGxpY2UoaSwgMSk7XG5cbiAgICAgICAgICAgIC8vIFVwZGF0ZSBoaXQgdmFsdWVzIGZyb20gYm91bmRzLXRlc3RcbiAgICAgICAgICAgIG1lc2guaGl0LmxvY2FsUG9pbnQuY29weShkaXJlY3Rpb24pLm11bHRpcGx5KGxvY2FsRGlzdGFuY2UpLmFkZChvcmlnaW4pO1xuICAgICAgICAgICAgbWVzaC5oaXQucG9pbnQuY29weShtZXNoLmhpdC5sb2NhbFBvaW50KS5hcHBseU1hdHJpeDQobWVzaC53b3JsZE1hdHJpeCk7XG4gICAgICAgICAgICBtZXNoLmhpdC5kaXN0YW5jZSA9IG1lc2guaGl0LnBvaW50LmRpc3RhbmNlKHRoaXMub3JpZ2luKTtcblxuICAgICAgICAgICAgLy8gQWRkIHVuaXF1ZSBoaXQgb2JqZWN0cyBvbiBtZXNoIHRvIGF2b2lkIGdlbmVyYXRpbmcgbG90cyBvZiBvYmplY3RzXG4gICAgICAgICAgICBpZiAoIW1lc2guaGl0LmZhY2VOb3JtYWwpIHtcbiAgICAgICAgICAgICAgICBtZXNoLmhpdC5sb2NhbEZhY2VOb3JtYWwgPSBuZXcgVmVjMygpO1xuICAgICAgICAgICAgICAgIG1lc2guaGl0LmZhY2VOb3JtYWwgPSBuZXcgVmVjMygpO1xuICAgICAgICAgICAgICAgIG1lc2guaGl0LnV2ID0gbmV3IFZlYzIoKTtcbiAgICAgICAgICAgICAgICBtZXNoLmhpdC5sb2NhbE5vcm1hbCA9IG5ldyBWZWMzKCk7XG4gICAgICAgICAgICAgICAgbWVzaC5oaXQubm9ybWFsID0gbmV3IFZlYzMoKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gQWRkIGZhY2Ugbm9ybWFsIGRhdGEgd2hpY2ggaXMgYWxyZWFkeSBjb21wdXRlZFxuICAgICAgICAgICAgbWVzaC5oaXQubG9jYWxGYWNlTm9ybWFsLmNvcHkoY2xvc2VzdEZhY2VOb3JtYWwpO1xuICAgICAgICAgICAgbWVzaC5oaXQuZmFjZU5vcm1hbC5jb3B5KG1lc2guaGl0LmxvY2FsRmFjZU5vcm1hbCkudHJhbnNmb3JtRGlyZWN0aW9uKG1lc2gud29ybGRNYXRyaXgpO1xuXG4gICAgICAgICAgICAvLyBPcHRpb25hbCBkYXRhLCBvcHQgb3V0IHRvIG9wdGltaXNlIGEgYml0IGlmIG5lY2Vzc2FyeVxuICAgICAgICAgICAgaWYgKGluY2x1ZGVVViB8fCBpbmNsdWRlTm9ybWFsKSB7XG4gICAgICAgICAgICAgICAgLy8gQ2FsY3VsYXRlIGJhcnljb29yZHMgdG8gZmluZCB1diB2YWx1ZXMgYXQgaGl0IHBvaW50XG4gICAgICAgICAgICAgICAgYS5mcm9tQXJyYXkocG9zaXRpb24uZGF0YSwgY2xvc2VzdEEgKiAzKTtcbiAgICAgICAgICAgICAgICBiLmZyb21BcnJheShwb3NpdGlvbi5kYXRhLCBjbG9zZXN0QiAqIDMpO1xuICAgICAgICAgICAgICAgIGMuZnJvbUFycmF5KHBvc2l0aW9uLmRhdGEsIGNsb3Nlc3RDICogMyk7XG4gICAgICAgICAgICAgICAgdGhpcy5nZXRCYXJ5Y29vcmQobWVzaC5oaXQubG9jYWxQb2ludCwgYSwgYiwgYywgYmFyeWNvb3JkKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKGluY2x1ZGVVViAmJiBhdHRyaWJ1dGVzLnV2KSB7XG4gICAgICAgICAgICAgICAgdXZBLmZyb21BcnJheShhdHRyaWJ1dGVzLnV2LmRhdGEsIGNsb3Nlc3RBICogMik7XG4gICAgICAgICAgICAgICAgdXZCLmZyb21BcnJheShhdHRyaWJ1dGVzLnV2LmRhdGEsIGNsb3Nlc3RCICogMik7XG4gICAgICAgICAgICAgICAgdXZDLmZyb21BcnJheShhdHRyaWJ1dGVzLnV2LmRhdGEsIGNsb3Nlc3RDICogMik7XG4gICAgICAgICAgICAgICAgbWVzaC5oaXQudXYuc2V0KFxuICAgICAgICAgICAgICAgICAgICB1dkEueCAqIGJhcnljb29yZC54ICsgdXZCLnggKiBiYXJ5Y29vcmQueSArIHV2Qy54ICogYmFyeWNvb3JkLnosXG4gICAgICAgICAgICAgICAgICAgIHV2QS55ICogYmFyeWNvb3JkLnggKyB1dkIueSAqIGJhcnljb29yZC55ICsgdXZDLnkgKiBiYXJ5Y29vcmQuelxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChpbmNsdWRlTm9ybWFsICYmIGF0dHJpYnV0ZXMubm9ybWFsKSB7XG4gICAgICAgICAgICAgICAgYS5mcm9tQXJyYXkoYXR0cmlidXRlcy5ub3JtYWwuZGF0YSwgY2xvc2VzdEEgKiAzKTtcbiAgICAgICAgICAgICAgICBiLmZyb21BcnJheShhdHRyaWJ1dGVzLm5vcm1hbC5kYXRhLCBjbG9zZXN0QiAqIDMpO1xuICAgICAgICAgICAgICAgIGMuZnJvbUFycmF5KGF0dHJpYnV0ZXMubm9ybWFsLmRhdGEsIGNsb3Nlc3RDICogMyk7XG4gICAgICAgICAgICAgICAgbWVzaC5oaXQubG9jYWxOb3JtYWwuc2V0KFxuICAgICAgICAgICAgICAgICAgICBhLnggKiBiYXJ5Y29vcmQueCArIGIueCAqIGJhcnljb29yZC55ICsgYy54ICogYmFyeWNvb3JkLnosXG4gICAgICAgICAgICAgICAgICAgIGEueSAqIGJhcnljb29yZC54ICsgYi55ICogYmFyeWNvb3JkLnkgKyBjLnkgKiBiYXJ5Y29vcmQueixcbiAgICAgICAgICAgICAgICAgICAgYS56ICogYmFyeWNvb3JkLnggKyBiLnogKiBiYXJ5Y29vcmQueSArIGMueiAqIGJhcnljb29yZC56XG4gICAgICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgICAgIG1lc2guaGl0Lm5vcm1hbC5jb3B5KG1lc2guaGl0LmxvY2FsTm9ybWFsKS50cmFuc2Zvcm1EaXJlY3Rpb24obWVzaC53b3JsZE1hdHJpeCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBoaXRzLnNvcnQoKGEsIGIpID0+IGEuaGl0LmRpc3RhbmNlIC0gYi5oaXQuZGlzdGFuY2UpO1xuICAgICAgICByZXR1cm4gaGl0cztcbiAgICB9XG5cbiAgICBpbnRlcnNlY3RQbGFuZShwbGFuZSwgb3JpZ2luID0gdGhpcy5vcmlnaW4sIGRpcmVjdGlvbiA9IHRoaXMuZGlyZWN0aW9uKSB7XG4gICAgICAgIGNvbnN0IHhtaW5wID0gdGVtcFZlYzNhO1xuICAgICAgICB4bWlucC5zdWIocGxhbmUub3JpZ2luLCBvcmlnaW4pO1xuXG4gICAgICAgIGNvbnN0IGEgPSB4bWlucC5kb3QocGxhbmUubm9ybWFsKTtcbiAgICAgICAgY29uc3QgYiA9IGRpcmVjdGlvbi5kb3QocGxhbmUubm9ybWFsKTtcbiAgICAgICAgLy8gQXNzdW1pbmcgd2UgZG9uJ3Qgd2FudCB0byBjb3VudCBhIHJheSBwYXJhbGxlbCB0byB0aGUgcGxhbmUgYXMgaW50ZXJzZWN0aW5nXG4gICAgICAgIGlmIChiID09IDApIHJldHVybiAwO1xuICAgICAgICBjb25zdCBkZWx0YSA9IGEgLyBiO1xuICAgICAgICBpZiAoZGVsdGEgPD0gMCkgcmV0dXJuIDA7XG4gICAgICAgIHJldHVybiBvcmlnaW4uYWRkKGRpcmVjdGlvbi5zY2FsZShkZWx0YSkpO1xuICAgIH1cblxuICAgIGludGVyc2VjdFNwaGVyZShzcGhlcmUsIG9yaWdpbiA9IHRoaXMub3JpZ2luLCBkaXJlY3Rpb24gPSB0aGlzLmRpcmVjdGlvbikge1xuICAgICAgICBjb25zdCByYXkgPSB0ZW1wVmVjM2M7XG4gICAgICAgIHJheS5zdWIoc3BoZXJlLmNlbnRlciwgb3JpZ2luKTtcbiAgICAgICAgY29uc3QgdGNhID0gcmF5LmRvdChkaXJlY3Rpb24pO1xuICAgICAgICBjb25zdCBkMiA9IHJheS5kb3QocmF5KSAtIHRjYSAqIHRjYTtcbiAgICAgICAgY29uc3QgcmFkaXVzMiA9IHNwaGVyZS5yYWRpdXMgKiBzcGhlcmUucmFkaXVzO1xuICAgICAgICBpZiAoZDIgPiByYWRpdXMyKSByZXR1cm4gMDtcbiAgICAgICAgY29uc3QgdGhjID0gTWF0aC5zcXJ0KHJhZGl1czIgLSBkMik7XG4gICAgICAgIGNvbnN0IHQwID0gdGNhIC0gdGhjO1xuICAgICAgICBjb25zdCB0MSA9IHRjYSArIHRoYztcbiAgICAgICAgaWYgKHQwIDwgMCAmJiB0MSA8IDApIHJldHVybiAwO1xuICAgICAgICBpZiAodDAgPCAwKSByZXR1cm4gdDE7XG4gICAgICAgIHJldHVybiB0MDtcbiAgICB9XG5cbiAgICAvLyBSYXkgQUFCQiAtIFJheSBBeGlzIGFsaWduZWQgYm91bmRpbmcgYm94IHRlc3RpbmdcbiAgICBpbnRlcnNlY3RCb3goYm94LCBvcmlnaW4gPSB0aGlzLm9yaWdpbiwgZGlyZWN0aW9uID0gdGhpcy5kaXJlY3Rpb24pIHtcbiAgICAgICAgbGV0IHRtaW4sIHRtYXgsIHRZbWluLCB0WW1heCwgdFptaW4sIHRabWF4O1xuICAgICAgICBjb25zdCBpbnZkaXJ4ID0gMSAvIGRpcmVjdGlvbi54O1xuICAgICAgICBjb25zdCBpbnZkaXJ5ID0gMSAvIGRpcmVjdGlvbi55O1xuICAgICAgICBjb25zdCBpbnZkaXJ6ID0gMSAvIGRpcmVjdGlvbi56O1xuICAgICAgICBjb25zdCBtaW4gPSBib3gubWluO1xuICAgICAgICBjb25zdCBtYXggPSBib3gubWF4O1xuICAgICAgICB0bWluID0gKChpbnZkaXJ4ID49IDAgPyBtaW4ueCA6IG1heC54KSAtIG9yaWdpbi54KSAqIGludmRpcng7XG4gICAgICAgIHRtYXggPSAoKGludmRpcnggPj0gMCA/IG1heC54IDogbWluLngpIC0gb3JpZ2luLngpICogaW52ZGlyeDtcbiAgICAgICAgdFltaW4gPSAoKGludmRpcnkgPj0gMCA/IG1pbi55IDogbWF4LnkpIC0gb3JpZ2luLnkpICogaW52ZGlyeTtcbiAgICAgICAgdFltYXggPSAoKGludmRpcnkgPj0gMCA/IG1heC55IDogbWluLnkpIC0gb3JpZ2luLnkpICogaW52ZGlyeTtcbiAgICAgICAgaWYgKHRtaW4gPiB0WW1heCB8fCB0WW1pbiA+IHRtYXgpIHJldHVybiAwO1xuICAgICAgICBpZiAodFltaW4gPiB0bWluKSB0bWluID0gdFltaW47XG4gICAgICAgIGlmICh0WW1heCA8IHRtYXgpIHRtYXggPSB0WW1heDtcbiAgICAgICAgdFptaW4gPSAoKGludmRpcnogPj0gMCA/IG1pbi56IDogbWF4LnopIC0gb3JpZ2luLnopICogaW52ZGlyejtcbiAgICAgICAgdFptYXggPSAoKGludmRpcnogPj0gMCA/IG1heC56IDogbWluLnopIC0gb3JpZ2luLnopICogaW52ZGlyejtcbiAgICAgICAgaWYgKHRtaW4gPiB0Wm1heCB8fCB0Wm1pbiA+IHRtYXgpIHJldHVybiAwO1xuICAgICAgICBpZiAodFptaW4gPiB0bWluKSB0bWluID0gdFptaW47XG4gICAgICAgIGlmICh0Wm1heCA8IHRtYXgpIHRtYXggPSB0Wm1heDtcbiAgICAgICAgaWYgKHRtYXggPCAwKSByZXR1cm4gMDtcbiAgICAgICAgcmV0dXJuIHRtaW4gPj0gMCA/IHRtaW4gOiB0bWF4O1xuICAgIH1cblxuICAgIGludGVyc2VjdFRyaWFuZ2xlKGEsIGIsIGMsIGJhY2tmYWNlQ3VsbGluZyA9IHRydWUsIG9yaWdpbiA9IHRoaXMub3JpZ2luLCBkaXJlY3Rpb24gPSB0aGlzLmRpcmVjdGlvbiwgbm9ybWFsID0gdGVtcFZlYzNnKSB7XG4gICAgICAgIC8vIGZyb20gaHR0cHM6Ly9naXRodWIuY29tL21yZG9vYi90aHJlZS5qcy9ibG9iL21hc3Rlci9zcmMvbWF0aC9SYXkuanNcbiAgICAgICAgLy8gd2hpY2ggaXMgZnJvbSBodHRwOi8vd3d3Lmdlb21ldHJpY3Rvb2xzLmNvbS9HVEVuZ2luZS9JbmNsdWRlL01hdGhlbWF0aWNzL0d0ZUludHJSYXkzVHJpYW5nbGUzLmhcbiAgICAgICAgY29uc3QgZWRnZTEgPSB0ZW1wVmVjM2g7XG4gICAgICAgIGNvbnN0IGVkZ2UyID0gdGVtcFZlYzNpO1xuICAgICAgICBjb25zdCBkaWZmID0gdGVtcFZlYzNqO1xuICAgICAgICBlZGdlMS5zdWIoYiwgYSk7XG4gICAgICAgIGVkZ2UyLnN1YihjLCBhKTtcbiAgICAgICAgbm9ybWFsLmNyb3NzKGVkZ2UxLCBlZGdlMik7XG4gICAgICAgIGxldCBEZE4gPSBkaXJlY3Rpb24uZG90KG5vcm1hbCk7XG4gICAgICAgIGlmICghRGROKSByZXR1cm4gMDtcbiAgICAgICAgbGV0IHNpZ247XG4gICAgICAgIGlmIChEZE4gPiAwKSB7XG4gICAgICAgICAgICBpZiAoYmFja2ZhY2VDdWxsaW5nKSByZXR1cm4gMDtcbiAgICAgICAgICAgIHNpZ24gPSAxO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2lnbiA9IC0xO1xuICAgICAgICAgICAgRGROID0gLURkTjtcbiAgICAgICAgfVxuICAgICAgICBkaWZmLnN1YihvcmlnaW4sIGEpO1xuICAgICAgICBsZXQgRGRReEUyID0gc2lnbiAqIGRpcmVjdGlvbi5kb3QoZWRnZTIuY3Jvc3MoZGlmZiwgZWRnZTIpKTtcbiAgICAgICAgaWYgKERkUXhFMiA8IDApIHJldHVybiAwO1xuICAgICAgICBsZXQgRGRFMXhRID0gc2lnbiAqIGRpcmVjdGlvbi5kb3QoZWRnZTEuY3Jvc3MoZGlmZikpO1xuICAgICAgICBpZiAoRGRFMXhRIDwgMCkgcmV0dXJuIDA7XG4gICAgICAgIGlmIChEZFF4RTIgKyBEZEUxeFEgPiBEZE4pIHJldHVybiAwO1xuICAgICAgICBsZXQgUWROID0gLXNpZ24gKiBkaWZmLmRvdChub3JtYWwpO1xuICAgICAgICBpZiAoUWROIDwgMCkgcmV0dXJuIDA7XG4gICAgICAgIHJldHVybiBRZE4gLyBEZE47XG4gICAgfVxuXG4gICAgZ2V0QmFyeWNvb3JkKHBvaW50LCBhLCBiLCBjLCB0YXJnZXQgPSB0ZW1wVmVjM2gpIHtcbiAgICAgICAgLy8gRnJvbSBodHRwczovL2dpdGh1Yi5jb20vbXJkb29iL3RocmVlLmpzL2Jsb2IvbWFzdGVyL3NyYy9tYXRoL1RyaWFuZ2xlLmpzXG4gICAgICAgIC8vIHN0YXRpYy9pbnN0YW5jZSBtZXRob2QgdG8gY2FsY3VsYXRlIGJhcnljZW50cmljIGNvb3JkaW5hdGVzXG4gICAgICAgIC8vIGJhc2VkIG9uOiBodHRwOi8vd3d3LmJsYWNrcGF3bi5jb20vdGV4dHMvcG9pbnRpbnBvbHkvZGVmYXVsdC5odG1sXG4gICAgICAgIGNvbnN0IHYwID0gdGVtcFZlYzNpO1xuICAgICAgICBjb25zdCB2MSA9IHRlbXBWZWMzajtcbiAgICAgICAgY29uc3QgdjIgPSB0ZW1wVmVjM2s7XG4gICAgICAgIHYwLnN1YihjLCBhKTtcbiAgICAgICAgdjEuc3ViKGIsIGEpO1xuICAgICAgICB2Mi5zdWIocG9pbnQsIGEpO1xuICAgICAgICBjb25zdCBkb3QwMCA9IHYwLmRvdCh2MCk7XG4gICAgICAgIGNvbnN0IGRvdDAxID0gdjAuZG90KHYxKTtcbiAgICAgICAgY29uc3QgZG90MDIgPSB2MC5kb3QodjIpO1xuICAgICAgICBjb25zdCBkb3QxMSA9IHYxLmRvdCh2MSk7XG4gICAgICAgIGNvbnN0IGRvdDEyID0gdjEuZG90KHYyKTtcbiAgICAgICAgY29uc3QgZGVub20gPSBkb3QwMCAqIGRvdDExIC0gZG90MDEgKiBkb3QwMTtcbiAgICAgICAgaWYgKGRlbm9tID09PSAwKSByZXR1cm4gdGFyZ2V0LnNldCgtMiwgLTEsIC0xKTtcbiAgICAgICAgY29uc3QgaW52RGVub20gPSAxIC8gZGVub207XG4gICAgICAgIGNvbnN0IHUgPSAoZG90MTEgKiBkb3QwMiAtIGRvdDAxICogZG90MTIpICogaW52RGVub207XG4gICAgICAgIGNvbnN0IHYgPSAoZG90MDAgKiBkb3QxMiAtIGRvdDAxICogZG90MDIpICogaW52RGVub207XG4gICAgICAgIHJldHVybiB0YXJnZXQuc2V0KDEgLSB1IC0gdiwgdiwgdSk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgVmVjMyB9IGZyb20gJy4uL21hdGgvVmVjMy5qcyc7XG5cbmNvbnN0IENBVE1VTExST00gPSAnY2F0bXVsbHJvbSc7XG5jb25zdCBDVUJJQ0JFWklFUiA9ICdjdWJpY2Jlemllcic7XG5jb25zdCBRVUFEUkFUSUNCRVpJRVIgPSAncXVhZHJhdGljYmV6aWVyJztcblxuLy8gdGVtcFxuY29uc3QgX2EwID0gLyogQF9fUFVSRV9fICovIG5ldyBWZWMzKCksXG4gICAgX2ExID0gLyogQF9fUFVSRV9fICovIG5ldyBWZWMzKCksXG4gICAgX2EyID0gLyogQF9fUFVSRV9fICovIG5ldyBWZWMzKCksXG4gICAgX2EzID0gLyogQF9fUFVSRV9fICovIG5ldyBWZWMzKCk7XG5cbi8qKlxuICogR2V0IHRoZSBjb250cm9sIHBvaW50cyBvZiBjdWJpYyBiZXppZXIgY3VydmUuXG4gKiBAcGFyYW0geyp9IGlcbiAqIEBwYXJhbSB7Kn0gYVxuICogQHBhcmFtIHsqfSBiXG4gKi9cbmZ1bmN0aW9uIGdldEN0cmxQb2ludChwb2ludHMsIGksIGEgPSAwLjE2OCwgYiA9IDAuMTY4KSB7XG4gICAgaWYgKGkgPCAxKSB7XG4gICAgICAgIF9hMC5zdWIocG9pbnRzWzFdLCBwb2ludHNbMF0pLnNjYWxlKGEpLmFkZChwb2ludHNbMF0pO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIF9hMC5zdWIocG9pbnRzW2kgKyAxXSwgcG9pbnRzW2kgLSAxXSlcbiAgICAgICAgICAgIC5zY2FsZShhKVxuICAgICAgICAgICAgLmFkZChwb2ludHNbaV0pO1xuICAgIH1cbiAgICBpZiAoaSA+IHBvaW50cy5sZW5ndGggLSAzKSB7XG4gICAgICAgIGNvbnN0IGxhc3QgPSBwb2ludHMubGVuZ3RoIC0gMTtcbiAgICAgICAgX2ExLnN1Yihwb2ludHNbbGFzdCAtIDFdLCBwb2ludHNbbGFzdF0pXG4gICAgICAgICAgICAuc2NhbGUoYilcbiAgICAgICAgICAgIC5hZGQocG9pbnRzW2xhc3RdKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBfYTEuc3ViKHBvaW50c1tpXSwgcG9pbnRzW2kgKyAyXSlcbiAgICAgICAgICAgIC5zY2FsZShiKVxuICAgICAgICAgICAgLmFkZChwb2ludHNbaSArIDFdKTtcbiAgICB9XG4gICAgcmV0dXJuIFtfYTAuY2xvbmUoKSwgX2ExLmNsb25lKCldO1xufVxuXG5mdW5jdGlvbiBnZXRRdWFkcmF0aWNCZXppZXJQb2ludCh0LCBwMCwgYzAsIHAxKSB7XG4gICAgY29uc3QgayA9IDEgLSB0O1xuICAgIF9hMC5jb3B5KHAwKS5zY2FsZShrICoqIDIpO1xuICAgIF9hMS5jb3B5KGMwKS5zY2FsZSgyICogayAqIHQpO1xuICAgIF9hMi5jb3B5KHAxKS5zY2FsZSh0ICoqIDIpO1xuICAgIGNvbnN0IHJldCA9IG5ldyBWZWMzKCk7XG4gICAgcmV0LmFkZChfYTAsIF9hMSkuYWRkKF9hMik7XG4gICAgcmV0dXJuIHJldDtcbn1cblxuZnVuY3Rpb24gZ2V0Q3ViaWNCZXppZXJQb2ludCh0LCBwMCwgYzAsIGMxLCBwMSkge1xuICAgIGNvbnN0IGsgPSAxIC0gdDtcbiAgICBfYTAuY29weShwMCkuc2NhbGUoayAqKiAzKTtcbiAgICBfYTEuY29weShjMCkuc2NhbGUoMyAqIGsgKiogMiAqIHQpO1xuICAgIF9hMi5jb3B5KGMxKS5zY2FsZSgzICogayAqIHQgKiogMik7XG4gICAgX2EzLmNvcHkocDEpLnNjYWxlKHQgKiogMyk7XG4gICAgY29uc3QgcmV0ID0gbmV3IFZlYzMoKTtcbiAgICByZXQuYWRkKF9hMCwgX2ExKS5hZGQoX2EyKS5hZGQoX2EzKTtcbiAgICByZXR1cm4gcmV0O1xufVxuXG5leHBvcnQgY2xhc3MgQ3VydmUge1xuICAgIGNvbnN0cnVjdG9yKHsgcG9pbnRzID0gW25ldyBWZWMzKDAsIDAsIDApLCBuZXcgVmVjMygwLCAxLCAwKSwgbmV3IFZlYzMoMSwgMSwgMCksIG5ldyBWZWMzKDEsIDAsIDApXSwgZGl2aXNpb25zID0gMTIsIHR5cGUgPSBDQVRNVUxMUk9NIH0gPSB7fSkge1xuICAgICAgICB0aGlzLnBvaW50cyA9IHBvaW50cztcbiAgICAgICAgdGhpcy5kaXZpc2lvbnMgPSBkaXZpc2lvbnM7XG4gICAgICAgIHRoaXMudHlwZSA9IHR5cGU7XG4gICAgfVxuXG4gICAgX2dldFF1YWRyYXRpY0JlemllclBvaW50cyhkaXZpc2lvbnMgPSB0aGlzLmRpdmlzaW9ucykge1xuICAgICAgICBjb25zdCBwb2ludHMgPSBbXTtcbiAgICAgICAgY29uc3QgY291bnQgPSB0aGlzLnBvaW50cy5sZW5ndGg7XG5cbiAgICAgICAgaWYgKGNvdW50IDwgMykge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKCdOb3QgZW5vdWdoIHBvaW50cyBwcm92aWRlZC4nKTtcbiAgICAgICAgICAgIHJldHVybiBbXTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHAwID0gdGhpcy5wb2ludHNbMF07XG4gICAgICAgIGxldCBjMCA9IHRoaXMucG9pbnRzWzFdLFxuICAgICAgICAgICAgcDEgPSB0aGlzLnBvaW50c1syXTtcblxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8PSBkaXZpc2lvbnM7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgcCA9IGdldFF1YWRyYXRpY0JlemllclBvaW50KGkgLyBkaXZpc2lvbnMsIHAwLCBjMCwgcDEpO1xuICAgICAgICAgICAgcG9pbnRzLnB1c2gocCk7XG4gICAgICAgIH1cblxuICAgICAgICBsZXQgb2Zmc2V0ID0gMztcbiAgICAgICAgd2hpbGUgKGNvdW50IC0gb2Zmc2V0ID4gMCkge1xuICAgICAgICAgICAgcDAuY29weShwMSk7XG4gICAgICAgICAgICBjMCA9IHAxLnNjYWxlKDIpLnN1YihjMCk7XG4gICAgICAgICAgICBwMSA9IHRoaXMucG9pbnRzW29mZnNldF07XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMTsgaSA8PSBkaXZpc2lvbnM7IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IHAgPSBnZXRRdWFkcmF0aWNCZXppZXJQb2ludChpIC8gZGl2aXNpb25zLCBwMCwgYzAsIHAxKTtcbiAgICAgICAgICAgICAgICBwb2ludHMucHVzaChwKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG9mZnNldCsrO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHBvaW50cztcbiAgICB9XG5cbiAgICBfZ2V0Q3ViaWNCZXppZXJQb2ludHMoZGl2aXNpb25zID0gdGhpcy5kaXZpc2lvbnMpIHtcbiAgICAgICAgY29uc3QgcG9pbnRzID0gW107XG4gICAgICAgIGNvbnN0IGNvdW50ID0gdGhpcy5wb2ludHMubGVuZ3RoO1xuXG4gICAgICAgIGlmIChjb3VudCA8IDQpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignTm90IGVub3VnaCBwb2ludHMgcHJvdmlkZWQuJyk7XG4gICAgICAgICAgICByZXR1cm4gW107XG4gICAgICAgIH1cblxuICAgICAgICBsZXQgcDAgPSB0aGlzLnBvaW50c1swXSxcbiAgICAgICAgICAgIGMwID0gdGhpcy5wb2ludHNbMV0sXG4gICAgICAgICAgICBjMSA9IHRoaXMucG9pbnRzWzJdLFxuICAgICAgICAgICAgcDEgPSB0aGlzLnBvaW50c1szXTtcblxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8PSBkaXZpc2lvbnM7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgcCA9IGdldEN1YmljQmV6aWVyUG9pbnQoaSAvIGRpdmlzaW9ucywgcDAsIGMwLCBjMSwgcDEpO1xuICAgICAgICAgICAgcG9pbnRzLnB1c2gocCk7XG4gICAgICAgIH1cblxuICAgICAgICBsZXQgb2Zmc2V0ID0gNDtcbiAgICAgICAgd2hpbGUgKGNvdW50IC0gb2Zmc2V0ID4gMSkge1xuICAgICAgICAgICAgcDAuY29weShwMSk7XG4gICAgICAgICAgICBjMCA9IHAxLnNjYWxlKDIpLnN1YihjMSk7XG4gICAgICAgICAgICBjMSA9IHRoaXMucG9pbnRzW29mZnNldF07XG4gICAgICAgICAgICBwMSA9IHRoaXMucG9pbnRzW29mZnNldCArIDFdO1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDE7IGkgPD0gZGl2aXNpb25zOyBpKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBwID0gZ2V0Q3ViaWNCZXppZXJQb2ludChpIC8gZGl2aXNpb25zLCBwMCwgYzAsIGMxLCBwMSk7XG4gICAgICAgICAgICAgICAgcG9pbnRzLnB1c2gocCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvZmZzZXQgKz0gMjtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBwb2ludHM7XG4gICAgfVxuXG4gICAgX2dldENhdG11bGxSb21Qb2ludHMoZGl2aXNpb25zID0gdGhpcy5kaXZpc2lvbnMsIGEgPSAwLjE2OCwgYiA9IDAuMTY4KSB7XG4gICAgICAgIGNvbnN0IHBvaW50cyA9IFtdO1xuICAgICAgICBjb25zdCBjb3VudCA9IHRoaXMucG9pbnRzLmxlbmd0aDtcblxuICAgICAgICBpZiAoY291bnQgPD0gMikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMucG9pbnRzO1xuICAgICAgICB9XG5cbiAgICAgICAgbGV0IHAwO1xuICAgICAgICB0aGlzLnBvaW50cy5mb3JFYWNoKChwLCBpKSA9PiB7XG4gICAgICAgICAgICBpZiAoaSA9PT0gMCkge1xuICAgICAgICAgICAgICAgIHAwID0gcDtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgY29uc3QgW2MwLCBjMV0gPSBnZXRDdHJsUG9pbnQodGhpcy5wb2ludHMsIGkgLSAxLCBhLCBiKTtcbiAgICAgICAgICAgICAgICBjb25zdCBjID0gbmV3IEN1cnZlKHtcbiAgICAgICAgICAgICAgICAgICAgcG9pbnRzOiBbcDAsIGMwLCBjMSwgcF0sXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IENVQklDQkVaSUVSLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHBvaW50cy5wb3AoKTtcbiAgICAgICAgICAgICAgICBwb2ludHMucHVzaCguLi5jLmdldFBvaW50cyhkaXZpc2lvbnMpKTtcbiAgICAgICAgICAgICAgICBwMCA9IHA7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHJldHVybiBwb2ludHM7XG4gICAgfVxuXG4gICAgZ2V0UG9pbnRzKGRpdmlzaW9ucyA9IHRoaXMuZGl2aXNpb25zLCBhID0gMC4xNjgsIGIgPSAwLjE2OCkge1xuICAgICAgICBjb25zdCB0eXBlID0gdGhpcy50eXBlO1xuXG4gICAgICAgIGlmICh0eXBlID09PSBRVUFEUkFUSUNCRVpJRVIpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9nZXRRdWFkcmF0aWNCZXppZXJQb2ludHMoZGl2aXNpb25zKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh0eXBlID09PSBDVUJJQ0JFWklFUikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2dldEN1YmljQmV6aWVyUG9pbnRzKGRpdmlzaW9ucyk7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAodHlwZSA9PT0gQ0FUTVVMTFJPTSkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2dldENhdG11bGxSb21Qb2ludHMoZGl2aXNpb25zLCBhLCBiKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB0aGlzLnBvaW50cztcbiAgICB9XG59XG5cbkN1cnZlLkNBVE1VTExST00gPSBDQVRNVUxMUk9NO1xuQ3VydmUuQ1VCSUNCRVpJRVIgPSBDVUJJQ0JFWklFUjtcbkN1cnZlLlFVQURSQVRJQ0JFWklFUiA9IFFVQURSQVRJQ0JFWklFUjtcbiIsIi8qKlxuICogQWJzdHJhY3QgYmFzZSBjbGFzcyBmb3IgcGF0aCBzZWdtZW50cy5cbiAqIFRoaXMgY2xhc3MgY29udGFpbnMgY29tbW9uIG1ldGhvZHMgZm9yIGFsbCBzZWdtZW50cyB0eXBlcy5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQmFzZVNlZ21lbnQge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICB0aGlzLl9sZW4gPSAtMTtcbiAgICAgICAgdGhpcy50aWx0U3RhcnQgPSAwO1xuICAgICAgICB0aGlzLnRpbHRFbmQgPSAwO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCBzZWdtZW50IGxlbmd0aC5cbiAgICAgKiBAcmV0dXJucyB7bnVtYmVyfSBzZWdtZW50IGxlbmd0aFxuICAgICAqL1xuICAgIGdldExlbmd0aCgpIHtcbiAgICAgICAgaWYgKHRoaXMuX2xlbiA8IDApIHtcbiAgICAgICAgICAgIHRoaXMudXBkYXRlTGVuZ3RoKCk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdGhpcy5fbGVuO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCB0aWx0IGFuZ2xlIGF0IHRcbiAgICAgKiBAcGFyYW0ge251bWJlcn0gdCBEaXN0YW5jZSBhdCB0aW1lIHQgaW4gcmFuZ2UgWzAgLi4gMV1cbiAgICAgKiBAcmV0dXJucyB7bnVtYmVyfSBUaWx0IGFuZ2xlIGF0IHRcbiAgICAgKi9cbiAgICBnZXRUaWx0QXQodCkge1xuICAgICAgICByZXR1cm4gdGhpcy50aWx0U3RhcnQgKiAoMSAtIHQpICogdGhpcy50aWx0RW5kICogdDtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDcmVhdGVzIGEgY2xvbmUgb2YgdGhpcyBpbnN0YW5jZVxuICAgICAqIEByZXR1cm5zIHtCYXNlU2VnbWVudH0gY2xvbmVkIGluc3RhbmNlXG4gICAgICovXG4gICAgY2xvbmUoKSB7XG4gICAgICAgIHJldHVybiBuZXcgdGhpcy5jb25zdHJ1Y3RvcigpLmNvcHkodGhpcyk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ29waWVzIGFub3RoZXIgc2VnbWVudCBvYmplY3QgdG8gdGhpcyBpbnN0YW5jZS5cbiAgICAgKiBAcGFyYW0ge0Jhc2VTZWdtZW50fSBzb3VyY2UgcmVmZXJlbmNlIG9iamVjdFxuICAgICAqIEByZXR1cm5zIHtCYXNlU2VnbWVudH0gY29weSBvZiBzb3VyY2Ugb2JqZWN0XG4gICAgICovXG4gICAgY29weShzb3VyY2UpIHtcbiAgICAgICAgdGhpcy5fbGVuID0gc291cmNlLl9sZW47XG4gICAgICAgIHRoaXMudGlsdFN0YXJ0ID0gc291cmNlLnRpbHRTdGFydDtcbiAgICAgICAgdGhpcy50aWx0RW5kID0gc291cmNlLnRpbHRFbmQ7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbn1cbiIsIi8vIGZyb20gaHR0cHM6Ly9naXRodWIuY29tL1BvbWF4L2JlemllcmpzL2Jsb2IvZDE5Njk1ZjNjYzNjZTM4M2NmMzhjZTQ2NDNmNDY3ZGVjYTdlZGI5Mi9zcmMvdXRpbHMuanMjTDI2XG4vLyBMZWdlbmRyZS1HYXVzcyBhYnNjaXNzYWUgd2l0aCBuPTI0ICh4X2kgdmFsdWVzLCBkZWZpbmVkIGF0IGk9biBhcyB0aGUgcm9vdHMgb2YgdGhlIG50aCBvcmRlciBMZWdlbmRyZSBwb2x5bm9taWFsIFBuKHgpKVxuZXhwb3J0IGNvbnN0IFRfVkFMVUVTID0gW1xuICAgIC0wLjA2NDA1Njg5Mjg2MjYwNTYyNjA4NTA0MzA4MjYyNDc0NTAzODU5MDksIDAuMDY0MDU2ODkyODYyNjA1NjI2MDg1MDQzMDgyNjI0NzQ1MDM4NTkwOSwgLTAuMTkxMTE4ODY3NDczNjE2MzA5MTU4NjM5ODIwNzU3MDY5NjMxODQwNCxcbiAgICAwLjE5MTExODg2NzQ3MzYxNjMwOTE1ODYzOTgyMDc1NzA2OTYzMTg0MDQsIC0wLjMxNTA0MjY3OTY5NjE2MzM3NDM4Njc5MzI5MTMxOTgxMDI0MDc4NjQsIDAuMzE1MDQyNjc5Njk2MTYzMzc0Mzg2NzkzMjkxMzE5ODEwMjQwNzg2NCxcbiAgICAtMC40MzM3OTM1MDc2MjYwNDUxMzg0ODcwODQyMzE5MTMzNDk3MTI0NTI0LCAwLjQzMzc5MzUwNzYyNjA0NTEzODQ4NzA4NDIzMTkxMzM0OTcxMjQ1MjQsIC0wLjU0NTQyMTQ3MTM4ODgzOTUzNTY1ODM3NTYxNzIxODM3MjM3MDAxMDcsXG4gICAgMC41NDU0MjE0NzEzODg4Mzk1MzU2NTgzNzU2MTcyMTgzNzIzNzAwMTA3LCAtMC42NDgwOTM2NTE5MzY5NzU1NjkyNTI0OTU3ODY5MTA3NDc2MjY2Njk2LCAwLjY0ODA5MzY1MTkzNjk3NTU2OTI1MjQ5NTc4NjkxMDc0NzYyNjY2OTYsXG4gICAgLTAuNzQwMTI0MTkxNTc4NTU0MzY0MjQzODI4MTAzMDk5OTc4NDI1NTIzMiwgMC43NDAxMjQxOTE1Nzg1NTQzNjQyNDM4MjgxMDMwOTk5Nzg0MjU1MjMyLCAtMC44MjAwMDE5ODU5NzM5MDI5MjE5NTM5NDk4NzI2Njk3NDUyMDgwNzYxLFxuICAgIDAuODIwMDAxOTg1OTczOTAyOTIxOTUzOTQ5ODcyNjY5NzQ1MjA4MDc2MSwgLTAuODg2NDE1NTI3MDA0NDAxMDM0MjEzMTU0MzQxOTgyMTk2NzU1MDg3MywgMC44ODY0MTU1MjcwMDQ0MDEwMzQyMTMxNTQzNDE5ODIxOTY3NTUwODczLFxuICAgIC0wLjkzODI3NDU1MjAwMjczMjc1ODUyMzY0OTAwMTcwODcyMTQ0OTY1NDgsIDAuOTM4Mjc0NTUyMDAyNzMyNzU4NTIzNjQ5MDAxNzA4NzIxNDQ5NjU0OCwgLTAuOTc0NzI4NTU1OTcxMzA5NDk4MTk4MzkxOTkzMDA4MTY5MDYxNzQxMSxcbiAgICAwLjk3NDcyODU1NTk3MTMwOTQ5ODE5ODM5MTk5MzAwODE2OTA2MTc0MTEsIC0wLjk5NTE4NzIxOTk5NzAyMTM2MDE3OTk5NzQwOTcwMDczNjgxMTg3NDUsIDAuOTk1MTg3MjE5OTk3MDIxMzYwMTc5OTk3NDA5NzAwNzM2ODExODc0NSxcbl07XG5cbi8vIExlZ2VuZHJlLUdhdXNzIHdlaWdodHMgd2l0aCBuPTI0ICh3X2kgdmFsdWVzLCBkZWZpbmVkIGJ5IGEgZnVuY3Rpb24gbGlua2VkIHRvIGluIHRoZSBCZXppZXIgcHJpbWVyIGFydGljbGUpXG5leHBvcnQgY29uc3QgQ19WQUxVRVMgPSBbXG4gICAgMC4xMjc5MzgxOTUzNDY3NTIxNTY5NzQwNTYxNjUyMjQ2OTUzNzE4NTE3LCAwLjEyNzkzODE5NTM0Njc1MjE1Njk3NDA1NjE2NTIyNDY5NTM3MTg1MTcsIDAuMTI1ODM3NDU2MzQ2ODI4Mjk2MTIxMzc1MzgyNTExMTgzNjg4NzI2NCxcbiAgICAwLjEyNTgzNzQ1NjM0NjgyODI5NjEyMTM3NTM4MjUxMTE4MzY4ODcyNjQsIDAuMTIxNjcwNDcyOTI3ODAzMzkxMjA0NDYzMTUzNDc2MjYyNDI1NjA3LCAwLjEyMTY3MDQ3MjkyNzgwMzM5MTIwNDQ2MzE1MzQ3NjI2MjQyNTYwNyxcbiAgICAwLjExNTUwNTY2ODA1MzcyNTYwMTM1MzM0NDQ4MzkwNjc4MzU1OTg2MjIsIDAuMTE1NTA1NjY4MDUzNzI1NjAxMzUzMzQ0NDgzOTA2NzgzNTU5ODYyMiwgMC4xMDc0NDQyNzAxMTU5NjU2MzQ3ODI1NzczNDI0NDY2MDYyMjI3OTQ2LFxuICAgIDAuMTA3NDQ0MjcwMTE1OTY1NjM0NzgyNTc3MzQyNDQ2NjA2MjIyNzk0NiwgMC4wOTc2MTg2NTIxMDQxMTM4ODgyNjk4ODA2NjQ0NjQyNDcxNTQ0Mjc5LCAwLjA5NzYxODY1MjEwNDExMzg4ODI2OTg4MDY2NDQ2NDI0NzE1NDQyNzksXG4gICAgMC4wODYxOTAxNjE1MzE5NTMyNzU5MTcxODUyMDI5ODM3NDI2NjcxODUsIDAuMDg2MTkwMTYxNTMxOTUzMjc1OTE3MTg1MjAyOTgzNzQyNjY3MTg1LCAwLjA3MzM0NjQ4MTQxMTA4MDMwNTczNDAzMzYxNTI1MzExNjUxODExOTMsXG4gICAgMC4wNzMzNDY0ODE0MTEwODAzMDU3MzQwMzM2MTUyNTMxMTY1MTgxMTkzLCAwLjA1OTI5ODU4NDkxNTQzNjc4MDc0NjM2Nzc1ODUwMDEwODU4NDU0MTIsIDAuMDU5Mjk4NTg0OTE1NDM2NzgwNzQ2MzY3NzU4NTAwMTA4NTg0NTQxMixcbiAgICAwLjA0NDI3NzQzODgxNzQxOTgwNjE2ODYwMjc0ODIxMTMzODIyODg1OTMsIDAuMDQ0Mjc3NDM4ODE3NDE5ODA2MTY4NjAyNzQ4MjExMzM4MjI4ODU5MywgMC4wMjg1MzEzODg2Mjg5MzM2NjMxODEzMDc4MTU5NTE4NzgyODY0NDkxLFxuICAgIDAuMDI4NTMxMzg4NjI4OTMzNjYzMTgxMzA3ODE1OTUxODc4Mjg2NDQ5MSwgMC4wMTIzNDEyMjk3OTk5ODcxOTk1NDY4MDU2NjcwNzAwMzcyOTE1NzU5LCAwLjAxMjM0MTIyOTc5OTk4NzE5OTU0NjgwNTY2NzA3MDAzNzI5MTU3NTksXG5dO1xuXG4vKipcbiAqIENvbnZlcnQgRGVncmVlIFRvIFJhZGlhblxuICogQHBhcmFtIHtudW1iZXJ9IGEgQW5nbGUgaW4gRGVncmVlc1xuICogQHJldHVybnMge251bWJlcn0gYSBBbmdsZSBpbiBSYWRpYW5zXG4gKi9cbmV4cG9ydCBjb25zdCB0b1JhZGlhbiA9IChhKSA9PiAoYSAqIE1hdGguUEkpIC8gMTgwO1xuXG4vKipcbiAqIENvbnZlcnQgUmFkaWFuIFRvIERlZ3JlZVxuICogQHBhcmFtIHtudW1iZXJ9IGEgQW5nbGUgaW4gUmFkaWFuc1xuICogQHJldHVybnMge251bWJlcn0gYSBBbmdsZSBpbiBSYWRpYW5cbiAqL1xuZXhwb3J0IGNvbnN0IHRvRGVncmVlcyA9IChhKSA9PiAoMTgwICogYSkgLyBNYXRoLlBJO1xuXG5leHBvcnQgY29uc3QgY2xhbXAgPSAodmFsLCBtaW4sIG1heCkgPT4gTWF0aC5tYXgobWluLCBNYXRoLm1pbih2YWwsIG1heCkpO1xuZXhwb3J0IGNvbnN0IGxlcnAgPSAodCwgdjAsIHYxKSA9PiB2MCAqICh0IC0gMSkgKyB2MSAqIHQ7XG5cbi8qKlxuICogRmlsbHMgYSByb3RhdGlvbiBtYXRyaXggd2l0aCB0aGUgZ2l2ZW4gc2luZSBhbmQgY29zaW5lIG9mIHRoZSBhbmdsZSBhcm91bmQgdGhlIGdpdmVuIGF4aXNcbiAqIFRoaXMgZnVuY3Rpb24gaGVscHMgdG8gYXZvaWQgaW52ZXJzZSB0cmlnb25vbWV0cnlcbiAqIEBwYXJhbSB7TWF0NH0gb3V0IG1hdDQgcmVjZWl2aW5nIG9wZXJhdGlvbiByZXN1bHRcbiAqIEBwYXJhbSB7VmVjM30gYXhpcyB0aGUgYXhpcyB0byByb3RhdGUgYXJvdW5kLiBTaG91bGQgYmUgbm9ybWFsaXplZFxuICogQHBhcmFtIHtudW1iZXJ9IHNpbiBzaW5lIG9mIHJvdGF0aW9uIGFuZ2xlXG4gKiBAcGFyYW0ge251bWJlcn0gY29zIGNvc2luZSBvZiByb3RhdGlvbiBhbmdsZVxuICogQHJldHVybnMge01hdDR9IG91dFxuICovXG5leHBvcnQgZnVuY3Rpb24gbWF0NGZyb21Sb3RhdGlvblNpbkNvcyhvdXQsIGF4aXMsIHNpbiwgY29zKSB7XG4gICAgY29uc3QgeCA9IGF4aXNbMF07XG4gICAgY29uc3QgeSA9IGF4aXNbMV07XG4gICAgY29uc3QgeiA9IGF4aXNbMl07XG4gICAgY29uc3QgdCA9IDEgLSBjb3M7XG5cbiAgICBvdXRbMF0gPSB4ICogeCAqIHQgKyBjb3M7XG4gICAgb3V0WzFdID0geSAqIHggKiB0ICsgeiAqIHNpbjtcbiAgICBvdXRbMl0gPSB6ICogeCAqIHQgLSB5ICogc2luO1xuICAgIG91dFszXSA9IDA7XG4gICAgb3V0WzRdID0geCAqIHkgKiB0IC0geiAqIHNpbjtcbiAgICBvdXRbNV0gPSB5ICogeSAqIHQgKyBjb3M7XG4gICAgb3V0WzZdID0geiAqIHkgKiB0ICsgeCAqIHNpbjtcbiAgICBvdXRbN10gPSAwO1xuICAgIG91dFs4XSA9IHggKiB6ICogdCArIHkgKiBzaW47XG4gICAgb3V0WzldID0geSAqIHogKiB0IC0geCAqIHNpbjtcbiAgICBvdXRbMTBdID0geiAqIHogKiB0ICsgY29zO1xuICAgIG91dFsxMV0gPSAwO1xuICAgIG91dFsxMl0gPSAwO1xuICAgIG91dFsxM10gPSAwO1xuICAgIG91dFsxNF0gPSAwO1xuICAgIG91dFsxNV0gPSAxO1xuICAgIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogUm90YXRlcyB0aGUgbm9ybWFsIGFuZCBiaW5vcm1hbCBhcm91bmQgaXRzIHRhbmdlbnQgYnkgdGhlIGdpdmVuIGFuZ2xlLlxuICpcbiAqIHNlZTogaHR0cHM6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvUm9kcmlndWVzJTI3X3JvdGF0aW9uX2Zvcm11bGFcbiAqIEBwYXJhbSB7bnVtYmVyfSBhbmdsZSByb3RhdGlvbiBhbmdsZVxuICogQHBhcmFtIHtWZWMzfSBub3JtIHVuaXQgbm9ybWFsIHZlY3RvclxuICogQHBhcmFtIHtWZWMzfSBiaW5vcm0gdW5pdCBiaW5vcm1hbCB2ZWN0b3JcbiAqIEBwYXJhbSB7VmVjM30gb3V0Tm9ybSBvcHRpb25hbCBub3JtYWwgb3V0cHV0IHZlY3Rvci4gSWYgbm90IHByZXNlbnQgdGhlbiBub3JtYWwgdmVjdG9yIGNoYW5nZXMgaW4gcGxhY2VcbiAqIEBwYXJhbSB7VmVjM30gb3V0Qmlub3JtIG9wdGlvbmFsIGJpbm9ybWFsIG91dHB1dCB2ZWN0b3IuIElmIG5vdCBwcmVzZW50IHRoZW4gYmlub3JtYWwgdmVjdG9yIGNoYW5nZXMgaW4gcGxhY2VcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJvdGF0ZU5vcm1hbEJpbm9ybWFsKGFuZ2xlLCBub3JtLCBiaW5vcm0sIG91dE5vcm0gPSBub3JtLCBvdXRCaW5vcm0gPSBiaW5vcm0pIHtcbiAgICBjb25zdCBzID0gTWF0aC5zaW4oYW5nbGUpO1xuICAgIGNvbnN0IGMgPSBNYXRoLmNvcyhhbmdsZSk7XG5cbiAgICBjb25zdCBueCA9IGMgKiBub3JtLnggKyBzICogYmlub3JtLng7XG4gICAgY29uc3QgbnkgPSBjICogbm9ybS55ICsgcyAqIGJpbm9ybS55O1xuICAgIGNvbnN0IG56ID0gYyAqIG5vcm0ueiArIHMgKiBiaW5vcm0uejtcblxuICAgIGNvbnN0IGJ4ID0gYyAqIGJpbm9ybS54IC0gcyAqIG5vcm0ueDtcbiAgICBjb25zdCBieSA9IGMgKiBiaW5vcm0ueSAtIHMgKiBub3JtLnk7XG4gICAgY29uc3QgYnogPSBjICogYmlub3JtLnogLSBzICogbm9ybS56O1xuXG4gICAgb3V0Tm9ybS5zZXQobngsIG55LCBueik7XG4gICAgb3V0Qmlub3JtLnNldChieCwgYnksIGJ6KTtcbn1cbiIsImltcG9ydCBCYXNlU2VnbWVudCBmcm9tICcuL0Jhc2VTZWdtZW50LmpzJztcbmltcG9ydCB7IFZlYzMgfSBmcm9tICcuLi8uLi9tYXRoL1ZlYzMuanMnO1xuaW1wb3J0IHsgVF9WQUxVRVMsIENfVkFMVUVTIH0gZnJvbSAnLi91dGlscy5qcyc7XG5cbmNvbnN0IHRlbXBWZWMzID0gLyogQF9fUFVSRV9fICovIG5ldyBWZWMzKCk7XG5cbmZ1bmN0aW9uIGN1YmljQmV6aWVyKHQsIHAwLCBwMSwgcDIsIHAzKSB7XG4gICAgY29uc3QgayA9IDEgLSB0O1xuICAgIC8vIHByZXR0aWVyLWlnbm9yZVxuICAgIHJldHVybiAoXG4gICAgICAgIChrICogayAqIGsgKiBwMCkgK1xuICAgICAgICAoMyAqIGsgKiBrICogdCAqIHAxKSArXG4gICAgICAgICgzICogayAqIHQgKiB0ICogcDIpICtcbiAgICAgICAgKHQgKiB0ICogdCAqIHAzKVxuICAgICk7XG59XG5cbmZ1bmN0aW9uIGN1YmljQmV6aWVyRGVyaXYodCwgcDAsIHAxLCBwMiwgcDMpIHtcbiAgICBjb25zdCBrID0gMSAtIHQ7XG4gICAgLy8gcHJldHRpZXItaWdub3JlXG4gICAgcmV0dXJuIChcbiAgICAgICAgKDMgKiBrICogayAqIChwMSAtIHAwKSkgK1xuICAgICAgICAoNiAqIGsgKiB0ICogKHAyIC0gcDEpKSArXG4gICAgICAgICgzICogdCAqIHQgKiAocDMgLSBwMikpXG4gICAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQ3ViaWNCZXppZXJTZWdtZW50IGV4dGVuZHMgQmFzZVNlZ21lbnQge1xuICAgIGNvbnN0cnVjdG9yKHAwLCBwMSwgcDIsIHAzLCB0aWx0U3RhcnQgPSAwLCB0aWx0RW5kID0gMCkge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICB0aGlzLnAwID0gcDA7XG4gICAgICAgIHRoaXMucDEgPSBwMTtcbiAgICAgICAgdGhpcy5wMiA9IHAyO1xuICAgICAgICB0aGlzLnAzID0gcDM7XG5cbiAgICAgICAgdGhpcy50aWx0U3RhcnQgPSB0aWx0U3RhcnQ7XG4gICAgICAgIHRoaXMudGlsdEVuZCA9IHRpbHRFbmQ7XG5cbiAgICAgICAgdGhpcy5fbGVuID0gLTE7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVXBkYXRlcyB0aGUgc2VnbWVudCBsZW5ndGguIFlvdSBtdXN0IGNhbGwgdGhpcyBtZXRob2QgZXZlcnkgdGltZSB5b3UgY2hhbmdlIHRoZSBjdXJ2ZSdzIGNvbnRyb2wgcG9pbnRzLlxuICAgICAqL1xuICAgIHVwZGF0ZUxlbmd0aCgpIHtcbiAgICAgICAgLy8gZnJvbSBodHRwczovL2dpdGh1Yi5jb20vUG9tYXgvYmV6aWVyanMvYmxvYi9kMTk2OTVmM2NjM2NlMzgzY2YzOGNlNDY0M2Y0NjdkZWNhN2VkYjkyL3NyYy91dGlscy5qcyNMMjY1XG4gICAgICAgIGNvbnN0IHogPSAwLjU7XG4gICAgICAgIGNvbnN0IGxlbiA9IFRfVkFMVUVTLmxlbmd0aDtcblxuICAgICAgICBsZXQgc3VtID0gMDtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIHQ7IGkgPCBsZW47IGkrKykge1xuICAgICAgICAgICAgdCA9IHogKiBUX1ZBTFVFU1tpXSArIHo7XG4gICAgICAgICAgICBzdW0gKz0gQ19WQUxVRVNbaV0gKiB0aGlzLmdldERlcml2YXRpdmVBdCh0LCB0ZW1wVmVjMykubGVuKCk7XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLl9sZW4gPSB6ICogc3VtO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdldCBwb2ludCBhdCByZWxhdGl2ZSBwb3NpdGlvbiBpbiBjdXJ2ZSBhY2NvcmRpbmcgdG8gc2VnbWVudCBsZW5ndGguXG4gICAgICogQHBhcmFtIHtudW1iZXJ9IHQgRGlzdGFuY2UgYXQgdGltZSB0IGluIHJhbmdlIFswIC4uIDFdXG4gICAgICogQHBhcmFtIHtWZWMzfSBvdXQgT3B0aW9uYWwgVmVjMyB0byBvdXRwdXRcbiAgICAgKiBAcmV0dXJucyB7VmVjM30gUG9pbnQgYXQgcmVsYXRpdmUgcG9zaXRpb25cbiAgICAgKi9cbiAgICBnZXRQb2ludEF0KHQsIG91dCA9IG5ldyBWZWMzKCkpIHtcbiAgICAgICAgb3V0LnggPSBjdWJpY0Jlemllcih0LCB0aGlzLnAwLngsIHRoaXMucDEueCwgdGhpcy5wMi54LCB0aGlzLnAzLngpO1xuICAgICAgICBvdXQueSA9IGN1YmljQmV6aWVyKHQsIHRoaXMucDAueSwgdGhpcy5wMS55LCB0aGlzLnAyLnksIHRoaXMucDMueSk7XG4gICAgICAgIG91dC56ID0gY3ViaWNCZXppZXIodCwgdGhpcy5wMC56LCB0aGlzLnAxLnosIHRoaXMucDIueiwgdGhpcy5wMy56KTtcbiAgICAgICAgcmV0dXJuIG91dDtcbiAgICB9XG5cbiAgICBnZXREZXJpdmF0aXZlQXQodCwgb3V0ID0gbmV3IFZlYzMoKSkge1xuICAgICAgICBvdXQueCA9IGN1YmljQmV6aWVyRGVyaXYodCwgdGhpcy5wMC54LCB0aGlzLnAxLngsIHRoaXMucDIueCwgdGhpcy5wMy54KTtcbiAgICAgICAgb3V0LnkgPSBjdWJpY0JlemllckRlcml2KHQsIHRoaXMucDAueSwgdGhpcy5wMS55LCB0aGlzLnAyLnksIHRoaXMucDMueSk7XG4gICAgICAgIG91dC56ID0gY3ViaWNCZXppZXJEZXJpdih0LCB0aGlzLnAwLnosIHRoaXMucDEueiwgdGhpcy5wMi56LCB0aGlzLnAzLnopO1xuICAgICAgICByZXR1cm4gb3V0O1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgYSB1bml0IHZlY3RvciB0YW5nZW50IGF0IHRcbiAgICAgKiBAcGFyYW0ge251bWJlcn0gdCBEaXN0YW5jZSBhdCB0aW1lIHQgaW4gcmFuZ2UgWzAgLi4gMV1cbiAgICAgKiBAcGFyYW0ge1ZlYzN9IG91dCBPcHRpb25hbCBWZWMzIHRvIG91dHB1dFxuICAgICAqIEByZXR1cm5zIHtWZWMzfSBBIHVuaXQgdmVjdG9yXG4gICAgICovXG4gICAgZ2V0VGFuZ2VudEF0KHQsIG91dCA9IG5ldyBWZWMzKCkpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0RGVyaXZhdGl2ZUF0KHQsIG91dCkubm9ybWFsaXplKCk7XG4gICAgfVxuXG4gICAgbGFzdFBvaW50KCkge1xuICAgICAgICByZXR1cm4gdGhpcy5wMztcbiAgICB9XG59XG4iLCJpbXBvcnQgQmFzZVNlZ21lbnQgZnJvbSAnLi9CYXNlU2VnbWVudC5qcyc7XG5pbXBvcnQgeyBWZWMzIH0gZnJvbSAnLi4vLi4vbWF0aC9WZWMzLmpzJztcbmltcG9ydCB7IFRfVkFMVUVTLCBDX1ZBTFVFUyB9IGZyb20gJy4vdXRpbHMuanMnO1xuXG5jb25zdCB0ZW1wVmVjMyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgVmVjMygpO1xuXG5mdW5jdGlvbiBxdWFkcmF0aWNCZXppZXIodCwgcDAsIHAxLCBwMikge1xuICAgIGNvbnN0IGsgPSAxIC0gdDtcbiAgICByZXR1cm4gayAqIGsgKiBwMCArIDIgKiBrICogdCAqIHAxICsgdCAqIHQgKiBwMjtcbn1cblxuZnVuY3Rpb24gcXVhZHJhdGljQmV6aWVyRGVyaXYodCwgcDAsIHAxLCBwMikge1xuICAgIGNvbnN0IGsgPSAxIC0gdDtcbiAgICByZXR1cm4gMiAqIGsgKiAocDEgLSBwMCkgKyAyICogdCAqIChwMiAtIHAxKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUXVhZHJhdGljQmV6aWVyU2VnbWVudCBleHRlbmRzIEJhc2VTZWdtZW50IHtcbiAgICBjb25zdHJ1Y3RvcihwMCwgcDEsIHAyLCB0aWx0U3RhcnQgPSAwLCB0aWx0RW5kID0gMCkge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICB0aGlzLnAwID0gcDA7XG4gICAgICAgIHRoaXMucDEgPSBwMTtcbiAgICAgICAgdGhpcy5wMiA9IHAyO1xuXG4gICAgICAgIHRoaXMudGlsdFN0YXJ0ID0gdGlsdFN0YXJ0O1xuICAgICAgICB0aGlzLnRpbHRFbmQgPSB0aWx0RW5kO1xuXG4gICAgICAgIHRoaXMuX2xlbiA9IC0xO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFVwZGF0ZXMgdGhlIHNlZ21lbnQgbGVuZ3RoLiBZb3UgbXVzdCBjYWxsIHRoaXMgbWV0aG9kIGV2ZXJ5IHRpbWUgeW91IGNoYW5nZSB0aGUgY3VydmUncyBjb250cm9sIHBvaW50cy5cbiAgICAgKi9cbiAgICB1cGRhdGVMZW5ndGgoKSB7XG4gICAgICAgIC8vIGZyb20gaHR0cHM6Ly9naXRodWIuY29tL1BvbWF4L2JlemllcmpzL2Jsb2IvZDE5Njk1ZjNjYzNjZTM4M2NmMzhjZTQ2NDNmNDY3ZGVjYTdlZGI5Mi9zcmMvdXRpbHMuanMjTDI2NVxuICAgICAgICBjb25zdCB6ID0gMC41O1xuICAgICAgICBjb25zdCBsZW4gPSBUX1ZBTFVFUy5sZW5ndGg7XG5cbiAgICAgICAgbGV0IHN1bSA9IDA7XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCB0OyBpIDwgbGVuOyBpKyspIHtcbiAgICAgICAgICAgIHQgPSB6ICogVF9WQUxVRVNbaV0gKyB6O1xuICAgICAgICAgICAgc3VtICs9IENfVkFMVUVTW2ldICogdGhpcy5nZXREZXJpdmF0aXZlQXQodCwgdGVtcFZlYzMpLmxlbigpO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5fbGVuID0geiAqIHN1bTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXQgcG9pbnQgYXQgcmVsYXRpdmUgcG9zaXRpb24gaW4gY3VydmUgYWNjb3JkaW5nIHRvIHNlZ21lbnQgbGVuZ3RoLlxuICAgICAqIEBwYXJhbSB7bnVtYmVyfSB0IERpc3RhbmNlIGF0IHRpbWUgdCBpbiByYW5nZSBbMCAuLiAxXVxuICAgICAqIEBwYXJhbSB7VmVjM30gb3V0IE9wdGlvbmFsIFZlYzMgdG8gb3V0cHV0XG4gICAgICogQHJldHVybnMge1ZlYzN9IFBvaW50IGF0IHJlbGF0aXZlIHBvc2l0aW9uXG4gICAgICovXG4gICAgZ2V0UG9pbnRBdCh0LCBvdXQgPSBuZXcgVmVjMygpKSB7XG4gICAgICAgIG91dC54ID0gcXVhZHJhdGljQmV6aWVyKHQsIHRoaXMucDAueCwgdGhpcy5wMS54LCB0aGlzLnAyLngpO1xuICAgICAgICBvdXQueSA9IHF1YWRyYXRpY0Jlemllcih0LCB0aGlzLnAwLnksIHRoaXMucDEueSwgdGhpcy5wMi55KTtcbiAgICAgICAgb3V0LnogPSBxdWFkcmF0aWNCZXppZXIodCwgdGhpcy5wMC56LCB0aGlzLnAxLnosIHRoaXMucDIueik7XG4gICAgICAgIHJldHVybiBvdXQ7XG4gICAgfVxuXG4gICAgZ2V0RGVyaXZhdGl2ZUF0KHQsIG91dCA9IG5ldyBWZWMzKCkpIHtcbiAgICAgICAgb3V0LnggPSBxdWFkcmF0aWNCZXppZXJEZXJpdih0LCB0aGlzLnAwLngsIHRoaXMucDEueCwgdGhpcy5wMi54KTtcbiAgICAgICAgb3V0LnkgPSBxdWFkcmF0aWNCZXppZXJEZXJpdih0LCB0aGlzLnAwLnksIHRoaXMucDEueSwgdGhpcy5wMi55KTtcbiAgICAgICAgb3V0LnogPSBxdWFkcmF0aWNCZXppZXJEZXJpdih0LCB0aGlzLnAwLnosIHRoaXMucDEueiwgdGhpcy5wMi56KTtcbiAgICAgICAgcmV0dXJuIG91dDtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIGEgdW5pdCB2ZWN0b3IgdGFuZ2VudCBhdCB0XG4gICAgICogQHBhcmFtIHtudW1iZXJ9IHQgRGlzdGFuY2UgYXQgdGltZSB0IGluIHJhbmdlIFswIC4uIDFdXG4gICAgICogQHBhcmFtIHtWZWMzfSBvdXQgT3B0aW9uYWwgVmVjMyB0byBvdXRwdXRcbiAgICAgKiBAcmV0dXJucyB7VmVjM30gQSB1bml0IHZlY3RvclxuICAgICAqL1xuICAgIGdldFRhbmdlbnRBdCh0LCBvdXQgPSBuZXcgVmVjMygpKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmdldERlcml2YXRpdmVBdCh0LCBvdXQpLm5vcm1hbGl6ZSgpO1xuICAgIH1cblxuICAgIGxhc3RQb2ludCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucDI7XG4gICAgfVxufVxuIiwiaW1wb3J0IEJhc2VTZWdtZW50IGZyb20gJy4vQmFzZVNlZ21lbnQuanMnO1xuaW1wb3J0IHsgVmVjMyB9IGZyb20gJy4uLy4uL21hdGgvVmVjMy5qcyc7XG5pbXBvcnQgeyBsZXJwIGFzIGxlcnAzIH0gZnJvbSAnLi4vLi4vbWF0aC9mdW5jdGlvbnMvVmVjM0Z1bmMuanMnO1xuXG5jb25zdCB0ZW1wVmVjMyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgVmVjMygpO1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBMaW5lU2VnbWVudCBleHRlbmRzIEJhc2VTZWdtZW50IHtcbiAgICBjb25zdHJ1Y3RvcihwMCwgcDEsIHRpbHRTdGFydCA9IDAsIHRpbHRFbmQgPSAwKSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHRoaXMucDAgPSBwMDtcbiAgICAgICAgdGhpcy5wMSA9IHAxO1xuXG4gICAgICAgIHRoaXMudGlsdFN0YXJ0ID0gdGlsdFN0YXJ0O1xuICAgICAgICB0aGlzLnRpbHRFbmQgPSB0aWx0RW5kO1xuXG4gICAgICAgIHRoaXMuX2xlbiA9IC0xO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFVwZGF0ZXMgdGhlIHNlZ21lbnQgbGVuZ3RoLiBZb3UgbXVzdCBjYWxsIHRoaXMgbWV0aG9kIGV2ZXJ5IHRpbWUgeW91IGNoYW5nZSB0aGUgY3VydmUncyBjb250cm9sIHBvaW50cy5cbiAgICAgKi9cbiAgICB1cGRhdGVMZW5ndGgoKSB7XG4gICAgICAgIHRoaXMuX2xlbiA9IHRlbXBWZWMzLnN1Yih0aGlzLnAxLCB0aGlzLnAwKS5sZW4oKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBHZXQgcG9pbnQgYXQgcmVsYXRpdmUgcG9zaXRpb24gaW4gY3VydmUgYWNjb3JkaW5nIHRvIHNlZ21lbnQgbGVuZ3RoLlxuICAgICAqIEBwYXJhbSB7bnVtYmVyfSB0IERpc3RhbmNlIGF0IHRpbWUgdCBpbiByYW5nZSBbMCAuLiAxXVxuICAgICAqIEBwYXJhbSB7VmVjM30gb3V0IE9wdGlvbmFsIFZlYzMgdG8gb3V0cHV0XG4gICAgICogQHJldHVybnMge1ZlYzN9IFBvaW50IGF0IHJlbGF0aXZlIHBvc2l0aW9uXG4gICAgICovXG4gICAgZ2V0UG9pbnRBdCh0LCBvdXQgPSBuZXcgVmVjMygpKSB7XG4gICAgICAgIGxlcnAzKG91dCwgdGhpcy5wMCwgdGhpcy5wMSwgdCk7XG4gICAgICAgIHJldHVybiBvdXQ7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmV0dXJucyBhIHVuaXQgdmVjdG9yIHRhbmdlbnQgYXQgdFxuICAgICAqIEBwYXJhbSB7bnVtYmVyfSB0IERpc3RhbmNlIGF0IHRpbWUgdCBpbiByYW5nZSBbMCAuLiAxXVxuICAgICAqIEBwYXJhbSB7VmVjM30gb3V0IE9wdGlvbmFsIFZlYzMgdG8gb3V0cHV0XG4gICAgICogQHJldHVybnMge1ZlYzN9IEEgdW5pdCB2ZWN0b3JcbiAgICAgKi9cbiAgICBnZXRUYW5nZW50QXQodCwgb3V0ID0gbmV3IFZlYzMoKSkge1xuICAgICAgICByZXR1cm4gb3V0LnN1Yih0aGlzLnAxLCB0aGlzLnAwKS5ub3JtYWxpemUoKTtcbiAgICB9XG5cbiAgICBsYXN0UG9pbnQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnAxO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IFZlYzMgfSBmcm9tICcuLi8uLi9tYXRoL1ZlYzMuanMnO1xuaW1wb3J0IHsgTWF0NCB9IGZyb20gJy4uLy4uL21hdGgvTWF0NC5qcyc7XG5pbXBvcnQgQ3ViaWNCZXppZXJTZWdtZW50IGZyb20gJy4vQ3ViaWNCZXppZXJTZWdtZW50LmpzJztcbmltcG9ydCBRdWFkcmF0aWNCZXppZXJTZWdtZW50IGZyb20gJy4vUXVhZHJhdGljQmV6aWVyU2VnbWVudC5qcyc7XG5pbXBvcnQgTGluZVNlZ21lbnQgZnJvbSAnLi9MaW5lU2VnbWVudC5qcyc7XG5pbXBvcnQgeyBjbGFtcCwgdG9EZWdyZWVzLCB0b1JhZGlhbiwgbWF0NGZyb21Sb3RhdGlvblNpbkNvcywgcm90YXRlTm9ybWFsQmlub3JtYWwgfSBmcm9tICcuL3V0aWxzLmpzJztcblxuY29uc3QgdGVtcFZlYzMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFZlYzMoKTtcbmNvbnN0IHRlbXBNYXQ0ID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXQ0KCk7XG5cbmZ1bmN0aW9uIHRocm93SWZOdWxsUHJvcGVydHkocHJvcGVydHksIG1lc3NhZ2UpIHtcbiAgICBpZiAodGhpc1twcm9wZXJ0eV0gPT0gbnVsbCkgdGhyb3cgbmV3IEVycm9yKG1lc3NhZ2UpO1xufVxuXG5leHBvcnQgY2xhc3MgUGF0aCB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHRoaXMuX3NlZ21lbnRzID0gW107XG4gICAgICAgIHRoaXMuX2xlbmd0aE9mZnNldHMgPSBudWxsO1xuICAgICAgICB0aGlzLl90b3RhbExlbmd0aCA9IC0xO1xuICAgICAgICB0aGlzLl9sYXN0UG9pbnQgPSBudWxsO1xuICAgICAgICB0aGlzLl9sYXN0VGlsdCA9IDA7XG5cbiAgICAgICAgdGhpcy5fYXNzZXJ0TGFzdFBvaW50ID0gdGhyb3dJZk51bGxQcm9wZXJ0eS5iaW5kKHRoaXMsICdfbGFzdFBvaW50JywgJ0NhbmB0IGdldCBwcmV2aW91cyBwb2ludCBvZiBjdXJ2ZS4gRGlkIHlvdSBmb3JnZXQgbW92ZVRvIGNvbW1hbmQ/Jyk7XG5cbiAgICAgICAgdGhpcy50aWx0RnVuY3Rpb24gPSBudWxsO1xuICAgIH1cblxuICAgIG1vdmVUbyhwLCB0aWx0ID0gMCkge1xuICAgICAgICB0aGlzLl90b3RhbExlbmd0aCA9IC0xO1xuICAgICAgICB0aGlzLl9sYXN0UG9pbnQgPSBwO1xuICAgICAgICB0aGlzLl9sYXN0VGlsdCA9IHRpbHQ7XG4gICAgfVxuXG4gICAgYmV6aWVyQ3VydmVUbyhjcDEsIGNwMiwgcCwgdGlsdCA9IDApIHtcbiAgICAgICAgdGhpcy5fYXNzZXJ0TGFzdFBvaW50KCk7XG4gICAgICAgIGNvbnN0IHNlZyA9IG5ldyBDdWJpY0JlemllclNlZ21lbnQodGhpcy5fbGFzdFBvaW50LCBjcDEsIGNwMiwgcCwgdGhpcy5fbGFzdFRpbHQsIHRpbHQpO1xuICAgICAgICB0aGlzLmFkZFNlZ21lbnQoc2VnKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgcXVhZHJhdGljQ3VydmVUbyhjcCwgcCwgdGlsdCA9IDApIHtcbiAgICAgICAgdGhpcy5fYXNzZXJ0TGFzdFBvaW50KCk7XG4gICAgICAgIGNvbnN0IHNlZyA9IG5ldyBRdWFkcmF0aWNCZXppZXJTZWdtZW50KHRoaXMuX2xhc3RQb2ludCwgY3AsIHAsIHRoaXMuX2xhc3RUaWx0LCB0aWx0KTtcbiAgICAgICAgdGhpcy5hZGRTZWdtZW50KHNlZyk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGxpbmVUbyhwLCB0aWx0ID0gMCkge1xuICAgICAgICB0aGlzLl9hc3NlcnRMYXN0UG9pbnQoKTtcbiAgICAgICAgY29uc3Qgc2VnID0gbmV3IExpbmVTZWdtZW50KHRoaXMuX2xhc3RQb2ludCwgcCwgdGhpcy5fbGFzdFRpbHQsIHRpbHQpO1xuICAgICAgICB0aGlzLmFkZFNlZ21lbnQoc2VnKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgYWRkU2VnbWVudChzZWdtZW50KSB7XG4gICAgICAgIHRoaXMuX3RvdGFsTGVuZ3RoID0gLTE7XG4gICAgICAgIHRoaXMuX2xhc3RQb2ludCA9IHNlZ21lbnQubGFzdFBvaW50KCk7XG4gICAgICAgIHRoaXMuX2xhc3RUaWx0ID0gc2VnbWVudC50aWx0RW5kO1xuICAgICAgICB0aGlzLl9zZWdtZW50cy5wdXNoKHNlZ21lbnQpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICBnZXRTZWdtZW50cygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3NlZ21lbnRzO1xuICAgIH1cblxuICAgIHVwZGF0ZUxlbmd0aCgpIHtcbiAgICAgICAgY29uc3QgbiA9IHRoaXMuX3NlZ21lbnRzLmxlbmd0aDtcbiAgICAgICAgdGhpcy5fbGVuZ3RoT2Zmc2V0cyA9IG5ldyBBcnJheShuKTtcblxuICAgICAgICBsZXQgb2Zmc2V0ID0gMDtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIHRoaXMuX2xlbmd0aE9mZnNldHNbaV0gPSBvZmZzZXQ7XG4gICAgICAgICAgICBvZmZzZXQgKz0gdGhpcy5fc2VnbWVudHNbaV0uZ2V0TGVuZ3RoKCk7XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLl90b3RhbExlbmd0aCA9IG9mZnNldDtcbiAgICB9XG5cbiAgICBnZXRMZW5ndGgoKSB7XG4gICAgICAgIGlmICh0aGlzLl90b3RhbExlbmd0aCA8IDApIHtcbiAgICAgICAgICAgIHRoaXMudXBkYXRlTGVuZ3RoKCk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdGhpcy5fdG90YWxMZW5ndGg7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogRmluZGluZyBhIHBhdGggc2VnbWVudCBhdCBhIGdpdmVuIGFic29sdXRlIGxlbmd0aCBkaXN0YW5jZVxuICAgICAqIEBwYXJhbSB7bnVtYmVyfSBsZW4gYWJzb2x1dGUgbGVuZ3RoIGRpc3RhbmNlXG4gICAgICogQHJldHVybnMge1tudW1iZXIsIG51bWJlcl19IFtfc2VnbWVudCBpbmRleF8sIF9yZWxhdGl2ZSBzZWdtZW50IGRpc3RhbmNlX11cbiAgICAgKi9cbiAgICBmaW5kU2VnbWVudEluZGV4QXRMZW5ndGgobGVuKSB7XG4gICAgICAgIGNvbnN0IHRvdGFsTGVuZ3RoID0gdGhpcy5nZXRMZW5ndGgoKTtcblxuICAgICAgICBpZiAobGVuIDw9IDApIHtcbiAgICAgICAgICAgIHJldHVybiBbMCwgMF07XG4gICAgICAgIH1cblxuICAgICAgICBpZiAobGVuID49IHRvdGFsTGVuZ3RoKSB7XG4gICAgICAgICAgICByZXR1cm4gW3RoaXMuX3NlZ21lbnRzLmxlbmd0aCAtIDEsIDFdO1xuICAgICAgICB9XG5cbiAgICAgICAgbGV0IHN0YXJ0ID0gMDtcbiAgICAgICAgbGV0IGVuZCA9IHRoaXMuX2xlbmd0aE9mZnNldHMubGVuZ3RoIC0gMTtcbiAgICAgICAgbGV0IGluZGV4ID0gLTE7XG4gICAgICAgIGxldCBtaWQ7XG5cbiAgICAgICAgd2hpbGUgKHN0YXJ0IDw9IGVuZCkge1xuICAgICAgICAgICAgbWlkID0gTWF0aC5jZWlsKChzdGFydCArIGVuZCkgLyAyKTtcblxuICAgICAgICAgICAgaWYgKG1pZCA9PT0gMCB8fCBtaWQgPT09IHRoaXMuX2xlbmd0aE9mZnNldHMubGVuZ3RoIC0gMSB8fCAobGVuID49IHRoaXMuX2xlbmd0aE9mZnNldHNbbWlkXSAmJiBsZW4gPCB0aGlzLl9sZW5ndGhPZmZzZXRzW21pZCArIDFdKSkge1xuICAgICAgICAgICAgICAgIGluZGV4ID0gbWlkO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChsZW4gPCB0aGlzLl9sZW5ndGhPZmZzZXRzW21pZF0pIHtcbiAgICAgICAgICAgICAgICBlbmQgPSBtaWQgLSAxO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBzdGFydCA9IG1pZCArIDE7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBzZWcgPSB0aGlzLl9zZWdtZW50c1tpbmRleF07XG4gICAgICAgIGNvbnN0IHNlZ0xlbiA9IHNlZy5nZXRMZW5ndGgoKTtcbiAgICAgICAgY29uc3QgdCA9IChsZW4gLSB0aGlzLl9sZW5ndGhPZmZzZXRzW2luZGV4XSkgLyBzZWdMZW47XG5cbiAgICAgICAgcmV0dXJuIFtpbmRleCwgdF07XG4gICAgfVxuXG4gICAgZ2V0UG9pbnRBdExlbmd0aChsZW4sIG91dCA9IG5ldyBWZWMzKCkpIHtcbiAgICAgICAgY29uc3QgW2ksIHRdID0gdGhpcy5maW5kU2VnbWVudEluZGV4QXRMZW5ndGgobGVuKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3NlZ21lbnRzW2ldLmdldFBvaW50QXQodCwgb3V0KTtcbiAgICB9XG5cbiAgICBnZXRQb2ludEF0KHQsIG91dCA9IG5ldyBWZWMzKCkpIHtcbiAgICAgICAgY29uc3QgdG90YWxMZW5ndGggPSB0aGlzLmdldExlbmd0aCgpO1xuICAgICAgICByZXR1cm4gdGhpcy5nZXRQb2ludEF0TGVuZ3RoKHQgKiB0b3RhbExlbmd0aCwgb3V0KTtcbiAgICB9XG5cbiAgICBnZXRUYW5nZW50QXRMZW5ndGgobGVuLCBvdXQgPSBuZXcgVmVjMygpKSB7XG4gICAgICAgIGNvbnN0IFtpLCB0XSA9IHRoaXMuZmluZFNlZ21lbnRJbmRleEF0TGVuZ3RoKGxlbik7XG4gICAgICAgIHJldHVybiB0aGlzLl9zZWdtZW50c1tpXS5nZXRUYW5nZW50QXQodCwgb3V0KTtcbiAgICB9XG5cbiAgICBnZXRUYW5nZW50QXQodCwgb3V0ID0gbmV3IFZlYzMoKSkge1xuICAgICAgICBjb25zdCB0b3RhbExlbmd0aCA9IHRoaXMuZ2V0TGVuZ3RoKCk7XG4gICAgICAgIHJldHVybiB0aGlzLmdldFRhbmdlbnRBdExlbmd0aCh0ICogdG90YWxMZW5ndGgsIG91dCk7XG4gICAgfVxuXG4gICAgZ2V0VGlsdEF0TGVuZ3RoKGxlbikge1xuICAgICAgICBjb25zdCBbaSwgdF0gPSB0aGlzLmZpbmRTZWdtZW50SW5kZXhBdExlbmd0aChsZW4pO1xuICAgICAgICByZXR1cm4gdGhpcy5fc2VnbWVudHNbaV0uZ2V0VGlsdEF0KHQpO1xuICAgIH1cblxuICAgIGdldFRpbHRBdCh0KSB7XG4gICAgICAgIGNvbnN0IHRvdGFsTGVuZ3RoID0gdGhpcy5nZXRMZW5ndGgoKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0VGlsdEF0TGVuZ3RoKHQgKiB0b3RhbExlbmd0aCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2V0IHNlcXVlbmNlIG9mIHBvaW50cyB1c2luZyBgZ2V0UG9pbnRBdCh0KWBcbiAgICAgKiBAcGFyYW0ge251bWJlcn0gZGl2aXNpb25zIG51bWJlciBvZiBzdWJkaXZpc2lvbnNcbiAgICAgKiBAcmV0dXJucyB7VmVjM1tdfSBhcnJheSBvZiBwb2ludHNcbiAgICAgKi9cbiAgICBnZXRQb2ludHMoZGl2aXNpb25zID0gNjQpIHtcbiAgICAgICAgY29uc3QgcG9pbnRzID0gbmV3IEFycmF5KGRpdmlzaW9ucyArIDEpO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8PSBkaXZpc2lvbnM7IGkrKykge1xuICAgICAgICAgICAgcG9pbnRzW2ldID0gdGhpcy5nZXRQb2ludEF0KGkgLyBkaXZpc2lvbnMpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBwb2ludHM7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogR2VuZXJhdGVzIHRoZSBGcmVuZXQgRnJhbWVzLlxuICAgICAqIFNlZSBodHRwOi8vd3d3LmNzLmluZGlhbmEuZWR1L3B1Yi90ZWNocmVwb3J0cy9UUjQyNS5wZGZcbiAgICAgKiBAcGFyYW0ge251bWJlcn0gZGl2aXNpb25zIG51bWJlciBvZiBzdWJkaXZpc2lvbnNcbiAgICAgKiBAcmV0dXJucyB7e3RhbmdlbnRzOiBWZWMzW10sIG5vcm1hbHM6IFZlYzNbXSwgYmlub3JtYWxzOiBWZWMzW119fSBPYmplY3Qgd2l0aCB0YW5nZW50cywgbm9ybWFscyBhbmQgYmlub3JtYWxzIGFycmF5c1xuICAgICAqL1xuICAgIGNvbXB1dGVGcmVuZXRGcmFtZXMoZGl2aXNpb25zID0gNjQsIGNsb3NlZCA9IGZhbHNlKSB7XG4gICAgICAgIGNvbnN0IHRhbmdlbnRzID0gbmV3IEFycmF5KGRpdmlzaW9ucyArIDEpO1xuICAgICAgICBjb25zdCB0aWx0cyA9IG5ldyBBcnJheShkaXZpc2lvbnMgKyAxKTtcblxuICAgICAgICBjb25zdCB0aWx0RnVuY3Rpb24gPSB0aGlzLnRpbHRGdW5jdGlvbiA/PyAoKGEpID0+IGEpO1xuXG4gICAgICAgIC8vIGNvbXB1dGUgdGhlIHRhbmdlbnQgdmVjdG9ycyBhbmQgdGlsdCBmb3IgZWFjaCBzZWdtZW50IG9uIHRoZSBjdXJ2ZVxuICAgICAgICBjb25zdCB0b3RhbExlbmd0aCA9IHRoaXMuZ2V0TGVuZ3RoKCk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDw9IGRpdmlzaW9uczsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBbc2ksIHN0XSA9IHRoaXMuZmluZFNlZ21lbnRJbmRleEF0TGVuZ3RoKCh0b3RhbExlbmd0aCAqIGkpIC8gZGl2aXNpb25zKTtcbiAgICAgICAgICAgIGNvbnN0IHNlZ21lbnQgPSB0aGlzLl9zZWdtZW50c1tzaV07XG4gICAgICAgICAgICB0YW5nZW50c1tpXSA9IHNlZ21lbnQuZ2V0VGFuZ2VudEF0KHN0KTtcbiAgICAgICAgICAgIHRpbHRzW2ldID0gdGlsdEZ1bmN0aW9uKHNlZ21lbnQuZ2V0VGlsdEF0KHN0KSwgaSAvIGRpdmlzaW9ucywgdGhpcyk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB0eCA9IE1hdGguYWJzKHRhbmdlbnRzWzBdLngpO1xuICAgICAgICBjb25zdCB0eSA9IE1hdGguYWJzKHRhbmdlbnRzWzBdLnkpO1xuICAgICAgICBjb25zdCB0eiA9IE1hdGguYWJzKHRhbmdlbnRzWzBdLnopO1xuXG4gICAgICAgIGNvbnN0IG5vcm1hbCA9IG5ldyBWZWMzKCk7XG4gICAgICAgIGlmICh0eCA8IHR5ICYmIHR4IDwgdHopIHtcbiAgICAgICAgICAgIG5vcm1hbC5zZXQoMSwgMCwgMCk7XG4gICAgICAgIH0gZWxzZSBpZiAodHkgPCB0eCAmJiB0eSA8IHR6KSB7XG4gICAgICAgICAgICBub3JtYWwuc2V0KDAsIDEsIDApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbm9ybWFsLnNldCgwLCAwLCAxKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHNlbGVjdCBhbiBpbml0aWFsIG5vcm1hbCB2ZWN0b3IgcGVycGVuZGljdWxhciB0byB0aGUgZmlyc3QgdGFuZ2VudCB2ZWN0b3IsXG4gICAgICAgIC8vIGFuZCBpbiB0aGUgZGlyZWN0aW9uIG9mIHRoZSBtaW5pbXVtIHRhbmdlbnQgeHl6IGNvbXBvbmVudFxuICAgICAgICBjb25zdCBub3JtYWxzID0gbmV3IEFycmF5KGRpdmlzaW9ucyArIDEpO1xuICAgICAgICBjb25zdCBiaW5vcm1hbHMgPSBuZXcgQXJyYXkoZGl2aXNpb25zICsgMSk7XG4gICAgICAgIG5vcm1hbHNbMF0gPSBuZXcgVmVjMygpO1xuICAgICAgICBiaW5vcm1hbHNbMF0gPSBuZXcgVmVjMygpO1xuXG4gICAgICAgIHRlbXBWZWMzLmNyb3NzKHRhbmdlbnRzWzBdLCBub3JtYWwpLm5vcm1hbGl6ZSgpO1xuICAgICAgICBub3JtYWxzWzBdLmNyb3NzKHRhbmdlbnRzWzBdLCB0ZW1wVmVjMyk7XG4gICAgICAgIGJpbm9ybWFsc1swXS5jcm9zcyh0YW5nZW50c1swXSwgbm9ybWFsc1swXSk7XG5cbiAgICAgICAgLy8gY29tcHV0ZSB0aGUgc2xvd2x5LXZhcnlpbmcgbm9ybWFsIHZlY3RvciBmb3IgZWFjaCBzZWdtZW50IG9uIHRoZSBjdXJ2ZVxuICAgICAgICBmb3IgKGxldCBpID0gMTsgaSA8IHRhbmdlbnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBub3JtYWxzW2ldID0gbm9ybWFsc1tpIC0gMV0uY2xvbmUoKTtcbiAgICAgICAgICAgIGJpbm9ybWFsc1tpXSA9IG5ldyBWZWMzKCk7XG5cbiAgICAgICAgICAgIHRlbXBWZWMzLmNyb3NzKHRhbmdlbnRzW2kgLSAxXSwgdGFuZ2VudHNbaV0pO1xuICAgICAgICAgICAgY29uc3QgY3Jvc3NMZW4gPSB0ZW1wVmVjMy5sZW4oKTtcblxuICAgICAgICAgICAgaWYgKGNyb3NzTGVuID4gTnVtYmVyLkVQU0lMT04pIHtcbiAgICAgICAgICAgICAgICB0ZW1wVmVjMy5zY2FsZSgxIC8gY3Jvc3NMZW4pOyAvLyBub21hbGl6ZVxuICAgICAgICAgICAgICAgIGNvbnN0IGNvc1RoZXRhID0gY2xhbXAodGFuZ2VudHNbaSAtIDFdLmRvdCh0YW5nZW50c1tpXSksIC0xLCAxKTsgLy8gY2xhbXAgZm9yIGZsb2F0aW5nIHB0IGVycm9yc1xuICAgICAgICAgICAgICAgIGNvbnN0IHNpblRoZXRhID0gY2xhbXAoY3Jvc3NMZW4sIC0xLCAxKTtcblxuICAgICAgICAgICAgICAgIG1hdDRmcm9tUm90YXRpb25TaW5Db3ModGVtcE1hdDQsIHRlbXBWZWMzLCBzaW5UaGV0YSwgY29zVGhldGEpO1xuICAgICAgICAgICAgICAgIG5vcm1hbHNbaV0uYXBwbHlNYXRyaXg0KHRlbXBNYXQ0KTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgYmlub3JtYWxzW2ldLmNyb3NzKHRhbmdlbnRzW2ldLCBub3JtYWxzW2ldKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIGFkZCB0aWx0IHR3aXN0aW5nXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGlsdHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIHJvdGF0ZU5vcm1hbEJpbm9ybWFsKHRvUmFkaWFuKHRpbHRzW2ldKSwgbm9ybWFsc1tpXSwgYmlub3JtYWxzW2ldKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIGlmIHRoZSBjdXJ2ZSBpcyBjbG9zZWQsIHBvc3Rwcm9jZXNzIHRoZSB2ZWN0b3JzIHNvIHRoZSBmaXJzdCBhbmQgbGFzdCBub3JtYWwgdmVjdG9ycyBhcmUgdGhlIHNhbWVcbiAgICAgICAgaWYgKGNsb3NlZCA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgY29uc3Qgbm9ybWFsTGFzdCA9IG5vcm1hbHNbbm9ybWFscy5sZW5ndGggLSAxXTtcbiAgICAgICAgICAgIGxldCBzdGVwID0gTWF0aC5hY29zKGNsYW1wKG5vcm1hbHNbMF0uZG90KG5vcm1hbExhc3QpLCAtMSwgMSkpIC8gKG5vcm1hbHMubGVuZ3RoIC0gMSk7XG5cbiAgICAgICAgICAgIGlmICh0YW5nZW50c1swXS5kb3QodGVtcFZlYzMuY3Jvc3Mobm9ybWFsc1swXSwgbm9ybWFsTGFzdCkpID4gMCkge1xuICAgICAgICAgICAgICAgIHN0ZXAgPSAtc3RlcDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDE7IGkgPCBub3JtYWxzLmxlbmd0aCAtIDE7IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGFuZ2xlID0gc3RlcCAqIGk7XG4gICAgICAgICAgICAgICAgcm90YXRlTm9ybWFsQmlub3JtYWwoYW5nbGUsIG5vcm1hbHNbaV0sIGJpbm9ybWFsc1tpXSk7XG4gICAgICAgICAgICAgICAgdGlsdHNbaV0gKz0gdG9EZWdyZWVzKGFuZ2xlKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgbm9ybWFsc1tub3JtYWxzLmxlbmd0aCAtIDFdID0gbm9ybWFsc1swXS5jbG9uZSgpO1xuICAgICAgICAgICAgYmlub3JtYWxzW2Jpbm9ybWFscy5sZW5ndGggLSAxXSA9IGJpbm9ybWFsc1swXS5jbG9uZSgpO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHsgdGFuZ2VudHMsIG5vcm1hbHMsIGJpbm9ybWFscywgdGlsdHMgfTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBHZW9tZXRyeSB9IGZyb20gJy4uL2NvcmUvR2VvbWV0cnkuanMnO1xuaW1wb3J0IHsgVmVjMyB9IGZyb20gJy4uL21hdGgvVmVjMy5qcyc7XG5pbXBvcnQgeyBWZWMyIH0gZnJvbSAnLi4vbWF0aC9WZWMyLmpzJztcblxuLy8gaGVscGVyIHZhcmlhYmxlc1xuY29uc3QgdmVydGV4ID0gLyogQF9fUFVSRV9fICovIG5ldyBWZWMzKCk7XG5jb25zdCBub3JtYWwgPSAvKiBAX19QVVJFX18gKi8gbmV3IFZlYzMoKTtcbmNvbnN0IHV2ID0gLyogQF9fUFVSRV9fICovIG5ldyBWZWMyKCk7XG5jb25zdCBwb2ludCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgVmVjMygpO1xuXG5leHBvcnQgY2xhc3MgVHViZSBleHRlbmRzIEdlb21ldHJ5IHtcbiAgICBjb25zdHJ1Y3RvcihnbCwgeyBwYXRoLCByYWRpdXMgPSAxLCB0dWJ1bGFyU2VnbWVudHMgPSA2NCwgcmFkaWFsU2VnbWVudHMgPSA4LCBjbG9zZWQgPSBmYWxzZSwgYXR0cmlidXRlcyA9IHt9IH0gPSB7fSkge1xuICAgICAgICBzdXBlcihnbCwgYXR0cmlidXRlcyk7XG5cbiAgICAgICAgdGhpcy5wYXRoID0gcGF0aDtcbiAgICAgICAgdGhpcy5yYWRpdXMgPSByYWRpdXM7XG4gICAgICAgIHRoaXMudHVidWxhclNlZ21lbnRzID0gdHVidWxhclNlZ21lbnRzO1xuICAgICAgICB0aGlzLnJhZGlhbFNlZ21lbnRzID0gcmFkaWFsU2VnbWVudHM7XG4gICAgICAgIHRoaXMuY2xvc2VkID0gY2xvc2VkO1xuXG4gICAgICAgIHRoaXMuZnJlbmV0RnJhbWVzID0gcGF0aC5jb21wdXRlRnJlbmV0RnJhbWVzKHR1YnVsYXJTZWdtZW50cywgY2xvc2VkKTtcblxuICAgICAgICBjb25zdCBudW1WZXJ0aWNlcyA9ICh0dWJ1bGFyU2VnbWVudHMgKyAxKSAqIChyYWRpYWxTZWdtZW50cyArIDEpO1xuICAgICAgICBjb25zdCBudW1JbmRpY2VzID0gdHVidWxhclNlZ21lbnRzICogcmFkaWFsU2VnbWVudHMgKiA2O1xuICAgICAgICB0aGlzLnBvc2l0aW9ucyA9IG5ldyBGbG9hdDMyQXJyYXkobnVtVmVydGljZXMgKiAzKTtcbiAgICAgICAgdGhpcy5ub3JtYWxzID0gbmV3IEZsb2F0MzJBcnJheShudW1WZXJ0aWNlcyAqIDMpO1xuICAgICAgICB0aGlzLnV2cyA9IG5ldyBGbG9hdDMyQXJyYXkobnVtVmVydGljZXMgKiAyKTtcbiAgICAgICAgdGhpcy5pbmRpY2VzID0gbnVtVmVydGljZXMgPiA2NTUzNiA/IG5ldyBVaW50MzJBcnJheShudW1JbmRpY2VzKSA6IG5ldyBVaW50MTZBcnJheShudW1JbmRpY2VzKTtcblxuICAgICAgICAvLyBjcmVhdGUgYnVmZmVyIGRhdGFcbiAgICAgICAgdGhpcy5fZ2VuZXJhdGVBdHRyaWJ1dGVzKCk7XG4gICAgICAgIHRoaXMuX2dlbmVyYXRlSW5kaWNlcygpO1xuXG4gICAgICAgIHRoaXMuYWRkQXR0cmlidXRlKCdwb3NpdGlvbicsIHsgc2l6ZTogMywgZGF0YTogdGhpcy5wb3NpdGlvbnMgfSk7XG4gICAgICAgIHRoaXMuYWRkQXR0cmlidXRlKCdub3JtYWwnLCB7IHNpemU6IDMsIGRhdGE6IHRoaXMubm9ybWFscyB9KTtcbiAgICAgICAgdGhpcy5hZGRBdHRyaWJ1dGUoJ3V2JywgeyBzaXplOiAyLCBkYXRhOiB0aGlzLnV2cyB9KTtcbiAgICAgICAgdGhpcy5zZXRJbmRleCh7IGRhdGE6IHRoaXMuaW5kaWNlcyB9KTtcbiAgICB9XG5cbiAgICBfZ2VuZXJhdGVBdHRyaWJ1dGVzKCkge1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8PSB0aGlzLnR1YnVsYXJTZWdtZW50czsgaSsrKSB7XG4gICAgICAgICAgICBsZXQgY2kgPSBpO1xuICAgICAgICAgICAgaWYgKGkgPT09IHRoaXMudHVidWxhclNlZ21lbnRzKSB7XG4gICAgICAgICAgICAgICAgLy8gaWYgdGhlIGdlb21ldHJ5IGlzIG5vdCBjbG9zZWQsIGdlbmVyYXRlIHRoZSBsYXN0IHJvdyBvZiB2ZXJ0aWNlcyBhbmQgbm9ybWFsc1xuICAgICAgICAgICAgICAgIC8vIGF0IHRoZSByZWd1bGFyIHBvc2l0aW9uIG9uIHRoZSBnaXZlbiBwYXRoXG4gICAgICAgICAgICAgICAgLy8gaWYgdGhlIGdlb21ldHJ5IGlzIGNsb3NlZCwgZHVwbGljYXRlIHRoZSBmaXJzdCByb3cgb2YgdmVydGljZXMgYW5kIG5vcm1hbHMgKHV2cyB3aWxsIGRpZmZlcilcbiAgICAgICAgICAgICAgICBjaSA9IHRoaXMuY2xvc2VkID8gMCA6IHRoaXMudHVidWxhclNlZ21lbnRzO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB0aGlzLnBhdGguZ2V0UG9pbnRBdChjaSAvIHRoaXMudHVidWxhclNlZ21lbnRzLCBwb2ludCk7XG4gICAgICAgICAgICAvLyByZXRyaWV2ZSBjb3JyZXNwb25kaW5nIG5vcm1hbCBhbmQgYmlub3JtYWxcbiAgICAgICAgICAgIGNvbnN0IE4gPSB0aGlzLmZyZW5ldEZyYW1lcy5ub3JtYWxzW2NpXTtcbiAgICAgICAgICAgIGNvbnN0IEIgPSB0aGlzLmZyZW5ldEZyYW1lcy5iaW5vcm1hbHNbY2ldO1xuXG4gICAgICAgICAgICAvLyBnZW5lcmF0ZSBub3JtYWxzIGFuZCB2ZXJ0aWNlcyBmb3IgdGhlIGN1cnJlbnQgc2VnbWVudFxuICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPD0gdGhpcy5yYWRpYWxTZWdtZW50czsgaisrKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgdiA9IChqIC8gdGhpcy5yYWRpYWxTZWdtZW50cykgKiBNYXRoLlBJICogMjtcbiAgICAgICAgICAgICAgICBjb25zdCBzaW4gPSBNYXRoLnNpbih2KTtcbiAgICAgICAgICAgICAgICBjb25zdCBjb3MgPSAtTWF0aC5jb3Modik7XG5cbiAgICAgICAgICAgICAgICBjb25zdCBpZHggPSBpICogKHRoaXMucmFkaWFsU2VnbWVudHMgKyAxKSArIGo7XG5cbiAgICAgICAgICAgICAgICAvLyBub3JtYWxcbiAgICAgICAgICAgICAgICBub3JtYWwueCA9IGNvcyAqIE4ueCArIHNpbiAqIEIueDtcbiAgICAgICAgICAgICAgICBub3JtYWwueSA9IGNvcyAqIE4ueSArIHNpbiAqIEIueTtcbiAgICAgICAgICAgICAgICBub3JtYWwueiA9IGNvcyAqIE4ueiArIHNpbiAqIEIuejtcbiAgICAgICAgICAgICAgICAvLyBub3JtYWwubm9ybWFsaXplKCk7IC8vID8/P1xuICAgICAgICAgICAgICAgIHRoaXMubm9ybWFscy5zZXQobm9ybWFsLCBpZHggKiAzKTtcblxuICAgICAgICAgICAgICAgIC8vIHZlcnRleFxuICAgICAgICAgICAgICAgIHZlcnRleC54ID0gcG9pbnQueCArIHRoaXMucmFkaXVzICogbm9ybWFsLng7XG4gICAgICAgICAgICAgICAgdmVydGV4LnkgPSBwb2ludC55ICsgdGhpcy5yYWRpdXMgKiBub3JtYWwueTtcbiAgICAgICAgICAgICAgICB2ZXJ0ZXgueiA9IHBvaW50LnogKyB0aGlzLnJhZGl1cyAqIG5vcm1hbC56O1xuICAgICAgICAgICAgICAgIHRoaXMucG9zaXRpb25zLnNldCh2ZXJ0ZXgsIGlkeCAqIDMpO1xuXG4gICAgICAgICAgICAgICAgLy8gdXZcbiAgICAgICAgICAgICAgICB1di54ID0gaSAvIHRoaXMudHVidWxhclNlZ21lbnRzO1xuICAgICAgICAgICAgICAgIHV2LnkgPSBqIC8gdGhpcy5yYWRpYWxTZWdtZW50cztcbiAgICAgICAgICAgICAgICB0aGlzLnV2cy5zZXQodXYsIGlkeCAqIDIpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgX2dlbmVyYXRlSW5kaWNlcygpIHtcbiAgICAgICAgZm9yIChsZXQgaiA9IDE7IGogPD0gdGhpcy50dWJ1bGFyU2VnbWVudHM7IGorKykge1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDE7IGkgPD0gdGhpcy5yYWRpYWxTZWdtZW50czsgaSsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgYSA9ICh0aGlzLnJhZGlhbFNlZ21lbnRzICsgMSkgKiAoaiAtIDEpICsgKGkgLSAxKTtcbiAgICAgICAgICAgICAgICBjb25zdCBiID0gKHRoaXMucmFkaWFsU2VnbWVudHMgKyAxKSAqIGogKyAoaSAtIDEpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGMgPSAodGhpcy5yYWRpYWxTZWdtZW50cyArIDEpICogaiArIGk7XG4gICAgICAgICAgICAgICAgY29uc3QgZCA9ICh0aGlzLnJhZGlhbFNlZ21lbnRzICsgMSkgKiAoaiAtIDEpICsgaTtcblxuICAgICAgICAgICAgICAgIGNvbnN0IGlkeCA9IChqIC0gMSkgKiB0aGlzLnJhZGlhbFNlZ21lbnRzICsgKGkgLSAxKTtcbiAgICAgICAgICAgICAgICB0aGlzLmluZGljZXMuc2V0KFthLCBiLCBkLCBiLCBjLCBkXSwgaWR4ICogNik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCJpbXBvcnQgeyBQcm9ncmFtIH0gZnJvbSAnLi4vY29yZS9Qcm9ncmFtLmpzJztcbmltcG9ydCB7IE1lc2ggfSBmcm9tICcuLi9jb3JlL01lc2guanMnO1xuaW1wb3J0IHsgUmVuZGVyVGFyZ2V0IH0gZnJvbSAnLi4vY29yZS9SZW5kZXJUYXJnZXQuanMnO1xuaW1wb3J0IHsgVHJpYW5nbGUgfSBmcm9tICcuL1RyaWFuZ2xlLmpzJztcblxuZXhwb3J0IGNsYXNzIFBvc3Qge1xuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBnbCxcbiAgICAgICAge1xuICAgICAgICAgICAgd2lkdGgsXG4gICAgICAgICAgICBoZWlnaHQsXG4gICAgICAgICAgICBkcHIsXG4gICAgICAgICAgICB3cmFwUyA9IGdsLkNMQU1QX1RPX0VER0UsXG4gICAgICAgICAgICB3cmFwVCA9IGdsLkNMQU1QX1RPX0VER0UsXG4gICAgICAgICAgICBtaW5GaWx0ZXIgPSBnbC5MSU5FQVIsXG4gICAgICAgICAgICBtYWdGaWx0ZXIgPSBnbC5MSU5FQVIsXG4gICAgICAgICAgICBnZW9tZXRyeSA9IG5ldyBUcmlhbmdsZShnbCksXG4gICAgICAgICAgICB0YXJnZXRPbmx5ID0gbnVsbCxcbiAgICAgICAgICAgIGRlcHRoID0gdHJ1ZSxcbiAgICAgICAgfSA9IHt9XG4gICAgKSB7XG4gICAgICAgIHRoaXMuZ2wgPSBnbDtcblxuICAgICAgICB0aGlzLnBhc3NlcyA9IFtdO1xuXG4gICAgICAgIHRoaXMuZ2VvbWV0cnkgPSBnZW9tZXRyeTtcblxuICAgICAgICB0aGlzLnVuaWZvcm0gPSB7IHZhbHVlOiBudWxsIH07XG4gICAgICAgIHRoaXMudGFyZ2V0T25seSA9IHRhcmdldE9ubHk7XG5cbiAgICAgICAgaWYgKGRwcikgdGhpcy5kcHIgPSBkcHI7XG4gICAgICAgIGlmICh3aWR0aCkgdGhpcy53aWR0aCA9IHdpZHRoO1xuICAgICAgICBpZiAoaGVpZ2h0KSB0aGlzLmhlaWdodCA9IGhlaWdodDtcblxuICAgICAgICBkcHIgPSB0aGlzLmRwciB8fCB0aGlzLmdsLnJlbmRlcmVyLmRwcjtcbiAgICAgICAgdGhpcy5yZXNvbHV0aW9uV2lkdGggPSBNYXRoLmZsb29yKHRoaXMud2lkdGggfHwgdGhpcy5nbC5yZW5kZXJlci53aWR0aCAqIGRwcik7XG4gICAgICAgIHRoaXMucmVzb2x1dGlvbkhlaWdodCA9IE1hdGguZmxvb3IodGhpcy5oZWlnaHQgfHwgdGhpcy5nbC5yZW5kZXJlci5oZWlnaHQgKiBkcHIpO1xuXG4gICAgICAgIGxldCBvcHRpb25zID0ge1xuICAgICAgICAgICAgZHByOiB0aGlzLmRwcixcbiAgICAgICAgICAgIHdpZHRoOiB0aGlzLnJlc29sdXRpb25XaWR0aCxcbiAgICAgICAgICAgIGhlaWdodDogdGhpcy5yZXNvbHV0aW9uSGVpZ2h0LFxuICAgICAgICAgICAgd3JhcFMsXG4gICAgICAgICAgICB3cmFwVCxcbiAgICAgICAgICAgIG1pbkZpbHRlcixcbiAgICAgICAgICAgIG1hZ0ZpbHRlcixcbiAgICAgICAgICAgIGRlcHRoLFxuICAgICAgICB9O1xuXG4gICAgICAgIGNvbnN0IGZibyA9ICh0aGlzLmZibyA9IHtcbiAgICAgICAgICAgIHJlYWQ6IG5ldyBSZW5kZXJUYXJnZXQodGhpcy5nbCwgb3B0aW9ucyksXG4gICAgICAgICAgICB3cml0ZTogbmV3IFJlbmRlclRhcmdldCh0aGlzLmdsLCBvcHRpb25zKSxcbiAgICAgICAgICAgIHN3YXA6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBsZXQgdGVtcCA9IGZiby5yZWFkO1xuICAgICAgICAgICAgICAgIGZiby5yZWFkID0gZmJvLndyaXRlO1xuICAgICAgICAgICAgICAgIGZiby53cml0ZSA9IHRlbXA7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBhZGRQYXNzKHsgdmVydGV4ID0gZGVmYXVsdFZlcnRleCwgZnJhZ21lbnQgPSBkZWZhdWx0RnJhZ21lbnQsIHVuaWZvcm1zID0ge30sIHRleHR1cmVVbmlmb3JtID0gJ3RNYXAnLCBlbmFibGVkID0gdHJ1ZSB9ID0ge30pIHtcbiAgICAgICAgdW5pZm9ybXNbdGV4dHVyZVVuaWZvcm1dID0geyB2YWx1ZTogdGhpcy5mYm8ucmVhZC50ZXh0dXJlIH07XG5cbiAgICAgICAgY29uc3QgcHJvZ3JhbSA9IG5ldyBQcm9ncmFtKHRoaXMuZ2wsIHsgdmVydGV4LCBmcmFnbWVudCwgdW5pZm9ybXMgfSk7XG4gICAgICAgIGNvbnN0IG1lc2ggPSBuZXcgTWVzaCh0aGlzLmdsLCB7IGdlb21ldHJ5OiB0aGlzLmdlb21ldHJ5LCBwcm9ncmFtIH0pO1xuXG4gICAgICAgIGNvbnN0IHBhc3MgPSB7XG4gICAgICAgICAgICBtZXNoLFxuICAgICAgICAgICAgcHJvZ3JhbSxcbiAgICAgICAgICAgIHVuaWZvcm1zLFxuICAgICAgICAgICAgZW5hYmxlZCxcbiAgICAgICAgICAgIHRleHR1cmVVbmlmb3JtLFxuICAgICAgICB9O1xuXG4gICAgICAgIHRoaXMucGFzc2VzLnB1c2gocGFzcyk7XG4gICAgICAgIHJldHVybiBwYXNzO1xuICAgIH1cblxuICAgIHJlc2l6ZSh7IHdpZHRoLCBoZWlnaHQsIGRwciB9ID0ge30pIHtcbiAgICAgICAgaWYgKGRwcikgdGhpcy5kcHIgPSBkcHI7XG4gICAgICAgIGlmICh3aWR0aCkgdGhpcy53aWR0aCA9IHdpZHRoO1xuICAgICAgICBpZiAoaGVpZ2h0KSB0aGlzLmhlaWdodCA9IGhlaWdodDtcblxuICAgICAgICBkcHIgPSB0aGlzLmRwciB8fCB0aGlzLmdsLnJlbmRlcmVyLmRwcjtcbiAgICAgICAgdGhpcy5yZXNvbHV0aW9uV2lkdGggPSBNYXRoLmZsb29yKHRoaXMud2lkdGggfHwgdGhpcy5nbC5yZW5kZXJlci53aWR0aCAqIGRwcik7XG4gICAgICAgIHRoaXMucmVzb2x1dGlvbkhlaWdodCA9IE1hdGguZmxvb3IodGhpcy5oZWlnaHQgfHwgdGhpcy5nbC5yZW5kZXJlci5oZWlnaHQgKiBkcHIpO1xuXG4gICAgICAgIHRoaXMuZmJvLnJlYWQuc2V0U2l6ZSh0aGlzLnJlc29sdXRpb25XaWR0aCwgdGhpcy5yZXNvbHV0aW9uSGVpZ2h0KTtcbiAgICAgICAgdGhpcy5mYm8ud3JpdGUuc2V0U2l6ZSh0aGlzLnJlc29sdXRpb25XaWR0aCwgdGhpcy5yZXNvbHV0aW9uSGVpZ2h0KTtcbiAgICB9XG5cbiAgICAvLyBVc2VzIHNhbWUgYXJndW1lbnRzIGFzIHJlbmRlcmVyLnJlbmRlciwgd2l0aCBhZGRpdGlvbiBvZiBvcHRpb25hbCB0ZXh0dXJlIHBhc3NlZCBpbiB0byBhdm9pZCBzY2VuZSByZW5kZXJcbiAgICByZW5kZXIoeyBzY2VuZSwgY2FtZXJhLCB0ZXh0dXJlLCB0YXJnZXQgPSBudWxsLCB1cGRhdGUgPSB0cnVlLCBzb3J0ID0gdHJ1ZSwgZnJ1c3R1bUN1bGwgPSB0cnVlLCBiZWZvcmVQb3N0Q2FsbGJhY2tzIH0pIHtcbiAgICAgICAgY29uc3QgZW5hYmxlZFBhc3NlcyA9IHRoaXMucGFzc2VzLmZpbHRlcigocGFzcykgPT4gcGFzcy5lbmFibGVkKTtcblxuICAgICAgICBpZiAoIXRleHR1cmUpIHtcbiAgICAgICAgICAgIHRoaXMuZ2wucmVuZGVyZXIucmVuZGVyKHtcbiAgICAgICAgICAgICAgICBzY2VuZSxcbiAgICAgICAgICAgICAgICBjYW1lcmEsXG4gICAgICAgICAgICAgICAgdGFyZ2V0OiBlbmFibGVkUGFzc2VzLmxlbmd0aCB8fCAoIXRhcmdldCAmJiB0aGlzLnRhcmdldE9ubHkpID8gdGhpcy5mYm8ud3JpdGUgOiB0YXJnZXQsXG4gICAgICAgICAgICAgICAgdXBkYXRlLFxuICAgICAgICAgICAgICAgIHNvcnQsXG4gICAgICAgICAgICAgICAgZnJ1c3R1bUN1bGwsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuZmJvLnN3YXAoKTtcblxuICAgICAgICAgICAgLy8gQ2FsbGJhY2sgYWZ0ZXIgcmVuZGVyaW5nIHNjZW5lLCBidXQgYmVmb3JlIHBvc3QgZWZmZWN0c1xuICAgICAgICAgICAgaWYgKGJlZm9yZVBvc3RDYWxsYmFja3MpIGJlZm9yZVBvc3RDYWxsYmFja3MuZm9yRWFjaCgoZikgPT4gZiAmJiBmKCkpO1xuICAgICAgICB9XG5cbiAgICAgICAgZW5hYmxlZFBhc3Nlcy5mb3JFYWNoKChwYXNzLCBpKSA9PiB7XG4gICAgICAgICAgICBwYXNzLm1lc2gucHJvZ3JhbS51bmlmb3Jtc1twYXNzLnRleHR1cmVVbmlmb3JtXS52YWx1ZSA9ICFpICYmIHRleHR1cmUgPyB0ZXh0dXJlIDogdGhpcy5mYm8ucmVhZC50ZXh0dXJlO1xuICAgICAgICAgICAgdGhpcy5nbC5yZW5kZXJlci5yZW5kZXIoe1xuICAgICAgICAgICAgICAgIHNjZW5lOiBwYXNzLm1lc2gsXG4gICAgICAgICAgICAgICAgdGFyZ2V0OiBpID09PSBlbmFibGVkUGFzc2VzLmxlbmd0aCAtIDEgJiYgKHRhcmdldCB8fCAhdGhpcy50YXJnZXRPbmx5KSA/IHRhcmdldCA6IHRoaXMuZmJvLndyaXRlLFxuICAgICAgICAgICAgICAgIGNsZWFyOiB0cnVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0aGlzLmZiby5zd2FwKCk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHRoaXMudW5pZm9ybS52YWx1ZSA9IHRoaXMuZmJvLnJlYWQudGV4dHVyZTtcbiAgICB9XG59XG5cbmNvbnN0IGRlZmF1bHRWZXJ0ZXggPSAvKiBnbHNsICovIGBcbiAgICBhdHRyaWJ1dGUgdmVjMiB1djtcbiAgICBhdHRyaWJ1dGUgdmVjMiBwb3NpdGlvbjtcblxuICAgIHZhcnlpbmcgdmVjMiB2VXY7XG5cbiAgICB2b2lkIG1haW4oKSB7XG4gICAgICAgIHZVdiA9IHV2O1xuICAgICAgICBnbF9Qb3NpdGlvbiA9IHZlYzQocG9zaXRpb24sIDAsIDEpO1xuICAgIH1cbmA7XG5cbmNvbnN0IGRlZmF1bHRGcmFnbWVudCA9IC8qIGdsc2wgKi8gYFxuICAgIHByZWNpc2lvbiBoaWdocCBmbG9hdDtcblxuICAgIHVuaWZvcm0gc2FtcGxlcjJEIHRNYXA7XG4gICAgdmFyeWluZyB2ZWMyIHZVdjtcblxuICAgIHZvaWQgbWFpbigpIHtcbiAgICAgICAgZ2xfRnJhZ0NvbG9yID0gdGV4dHVyZTJEKHRNYXAsIHZVdik7XG4gICAgfVxuYDtcbiIsImltcG9ydCB7IFZlYzMgfSBmcm9tICcuLi9tYXRoL1ZlYzMuanMnO1xuaW1wb3J0IHsgUXVhdCB9IGZyb20gJy4uL21hdGgvUXVhdC5qcyc7XG5cbmNvbnN0IHByZXZQb3MgPSAvKiBAX19QVVJFX18gKi8gbmV3IFZlYzMoKTtcbmNvbnN0IHByZXZSb3QgPSAvKiBAX19QVVJFX18gKi8gbmV3IFF1YXQoKTtcbmNvbnN0IHByZXZTY2wgPSAvKiBAX19QVVJFX18gKi8gbmV3IFZlYzMoKTtcblxuY29uc3QgbmV4dFBvcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgVmVjMygpO1xuY29uc3QgbmV4dFJvdCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgUXVhdCgpO1xuY29uc3QgbmV4dFNjbCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgVmVjMygpO1xuXG5leHBvcnQgY2xhc3MgQW5pbWF0aW9uIHtcbiAgICBjb25zdHJ1Y3Rvcih7IG9iamVjdHMsIGRhdGEgfSkge1xuICAgICAgICB0aGlzLm9iamVjdHMgPSBvYmplY3RzO1xuICAgICAgICB0aGlzLmRhdGEgPSBkYXRhO1xuICAgICAgICB0aGlzLmVsYXBzZWQgPSAwO1xuICAgICAgICB0aGlzLndlaWdodCA9IDE7XG4gICAgICAgIHRoaXMuZHVyYXRpb24gPSBkYXRhLmZyYW1lcy5sZW5ndGggLSAxO1xuICAgIH1cblxuICAgIHVwZGF0ZSh0b3RhbFdlaWdodCA9IDEsIGlzU2V0KSB7XG4gICAgICAgIGNvbnN0IHdlaWdodCA9IGlzU2V0ID8gMSA6IHRoaXMud2VpZ2h0IC8gdG90YWxXZWlnaHQ7XG4gICAgICAgIGNvbnN0IGVsYXBzZWQgPSB0aGlzLmVsYXBzZWQgJSB0aGlzLmR1cmF0aW9uO1xuXG4gICAgICAgIGNvbnN0IGZsb29yRnJhbWUgPSBNYXRoLmZsb29yKGVsYXBzZWQpO1xuICAgICAgICBjb25zdCBibGVuZCA9IGVsYXBzZWQgLSBmbG9vckZyYW1lO1xuICAgICAgICBjb25zdCBwcmV2S2V5ID0gdGhpcy5kYXRhLmZyYW1lc1tmbG9vckZyYW1lXTtcbiAgICAgICAgY29uc3QgbmV4dEtleSA9IHRoaXMuZGF0YS5mcmFtZXNbKGZsb29yRnJhbWUgKyAxKSAlIHRoaXMuZHVyYXRpb25dO1xuXG4gICAgICAgIHRoaXMub2JqZWN0cy5mb3JFYWNoKChvYmplY3QsIGkpID0+IHtcbiAgICAgICAgICAgIHByZXZQb3MuZnJvbUFycmF5KHByZXZLZXkucG9zaXRpb24sIGkgKiAzKTtcbiAgICAgICAgICAgIHByZXZSb3QuZnJvbUFycmF5KHByZXZLZXkucXVhdGVybmlvbiwgaSAqIDQpO1xuICAgICAgICAgICAgcHJldlNjbC5mcm9tQXJyYXkocHJldktleS5zY2FsZSwgaSAqIDMpO1xuXG4gICAgICAgICAgICBuZXh0UG9zLmZyb21BcnJheShuZXh0S2V5LnBvc2l0aW9uLCBpICogMyk7XG4gICAgICAgICAgICBuZXh0Um90LmZyb21BcnJheShuZXh0S2V5LnF1YXRlcm5pb24sIGkgKiA0KTtcbiAgICAgICAgICAgIG5leHRTY2wuZnJvbUFycmF5KG5leHRLZXkuc2NhbGUsIGkgKiAzKTtcblxuICAgICAgICAgICAgcHJldlBvcy5sZXJwKG5leHRQb3MsIGJsZW5kKTtcbiAgICAgICAgICAgIHByZXZSb3Quc2xlcnAobmV4dFJvdCwgYmxlbmQpO1xuICAgICAgICAgICAgcHJldlNjbC5sZXJwKG5leHRTY2wsIGJsZW5kKTtcblxuICAgICAgICAgICAgb2JqZWN0LnBvc2l0aW9uLmxlcnAocHJldlBvcywgd2VpZ2h0KTtcbiAgICAgICAgICAgIG9iamVjdC5xdWF0ZXJuaW9uLnNsZXJwKHByZXZSb3QsIHdlaWdodCk7XG4gICAgICAgICAgICBvYmplY3Quc2NhbGUubGVycChwcmV2U2NsLCB3ZWlnaHQpO1xuICAgICAgICB9KTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBNZXNoIH0gZnJvbSAnLi4vY29yZS9NZXNoLmpzJztcbmltcG9ydCB7IFRyYW5zZm9ybSB9IGZyb20gJy4uL2NvcmUvVHJhbnNmb3JtLmpzJztcbmltcG9ydCB7IE1hdDQgfSBmcm9tICcuLi9tYXRoL01hdDQuanMnO1xuaW1wb3J0IHsgVGV4dHVyZSB9IGZyb20gJy4uL2NvcmUvVGV4dHVyZS5qcyc7XG5pbXBvcnQgeyBBbmltYXRpb24gfSBmcm9tICcuL0FuaW1hdGlvbi5qcyc7XG5cbmNvbnN0IHRlbXBNYXQ0ID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXQ0KCk7XG5cbmV4cG9ydCBjbGFzcyBTa2luIGV4dGVuZHMgTWVzaCB7XG4gICAgY29uc3RydWN0b3IoZ2wsIHsgcmlnLCBnZW9tZXRyeSwgcHJvZ3JhbSwgbW9kZSA9IGdsLlRSSUFOR0xFUyB9ID0ge30pIHtcbiAgICAgICAgc3VwZXIoZ2wsIHsgZ2VvbWV0cnksIHByb2dyYW0sIG1vZGUgfSk7XG5cbiAgICAgICAgdGhpcy5jcmVhdGVCb25lcyhyaWcpO1xuICAgICAgICB0aGlzLmNyZWF0ZUJvbmVUZXh0dXJlKCk7XG4gICAgICAgIHRoaXMuYW5pbWF0aW9ucyA9IFtdO1xuXG4gICAgICAgIE9iamVjdC5hc3NpZ24odGhpcy5wcm9ncmFtLnVuaWZvcm1zLCB7XG4gICAgICAgICAgICBib25lVGV4dHVyZTogeyB2YWx1ZTogdGhpcy5ib25lVGV4dHVyZSB9LFxuICAgICAgICAgICAgYm9uZVRleHR1cmVTaXplOiB7IHZhbHVlOiB0aGlzLmJvbmVUZXh0dXJlU2l6ZSB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBjcmVhdGVCb25lcyhyaWcpIHtcbiAgICAgICAgLy8gQ3JlYXRlIHJvb3Qgc28gdGhhdCBjYW4gc2ltcGx5IHVwZGF0ZSB3b3JsZCBtYXRyaXggb2Ygd2hvbGUgc2tlbGV0b25cbiAgICAgICAgdGhpcy5yb290ID0gbmV3IFRyYW5zZm9ybSgpO1xuXG4gICAgICAgIC8vIENyZWF0ZSBib25lc1xuICAgICAgICB0aGlzLmJvbmVzID0gW107XG4gICAgICAgIGlmICghcmlnLmJvbmVzIHx8ICFyaWcuYm9uZXMubGVuZ3RoKSByZXR1cm47XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcmlnLmJvbmVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBib25lID0gbmV3IFRyYW5zZm9ybSgpO1xuXG4gICAgICAgICAgICAvLyBTZXQgaW5pdGlhbCB2YWx1ZXMgKGJpbmQgcG9zZSlcbiAgICAgICAgICAgIGJvbmUucG9zaXRpb24uZnJvbUFycmF5KHJpZy5iaW5kUG9zZS5wb3NpdGlvbiwgaSAqIDMpO1xuICAgICAgICAgICAgYm9uZS5xdWF0ZXJuaW9uLmZyb21BcnJheShyaWcuYmluZFBvc2UucXVhdGVybmlvbiwgaSAqIDQpO1xuICAgICAgICAgICAgYm9uZS5zY2FsZS5mcm9tQXJyYXkocmlnLmJpbmRQb3NlLnNjYWxlLCBpICogMyk7XG5cbiAgICAgICAgICAgIHRoaXMuYm9uZXMucHVzaChib25lKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIE9uY2UgY3JlYXRlZCwgc2V0IHRoZSBoaWVyYXJjaHlcbiAgICAgICAgcmlnLmJvbmVzLmZvckVhY2goKGRhdGEsIGkpID0+IHtcbiAgICAgICAgICAgIHRoaXMuYm9uZXNbaV0ubmFtZSA9IGRhdGEubmFtZTtcbiAgICAgICAgICAgIGlmIChkYXRhLnBhcmVudCA9PT0gLTEpIHJldHVybiB0aGlzLmJvbmVzW2ldLnNldFBhcmVudCh0aGlzLnJvb3QpO1xuICAgICAgICAgICAgdGhpcy5ib25lc1tpXS5zZXRQYXJlbnQodGhpcy5ib25lc1tkYXRhLnBhcmVudF0pO1xuICAgICAgICB9KTtcblxuICAgICAgICAvLyBUaGVuIHVwZGF0ZSB0byBjYWxjdWxhdGUgd29ybGQgbWF0cmljZXNcbiAgICAgICAgdGhpcy5yb290LnVwZGF0ZU1hdHJpeFdvcmxkKHRydWUpO1xuXG4gICAgICAgIC8vIFN0b3JlIGludmVyc2Ugb2YgYmluZCBwb3NlIHRvIGNhbGN1bGF0ZSBkaWZmZXJlbmNlc1xuICAgICAgICB0aGlzLmJvbmVzLmZvckVhY2goKGJvbmUpID0+IHtcbiAgICAgICAgICAgIGJvbmUuYmluZEludmVyc2UgPSBuZXcgTWF0NCguLi5ib25lLndvcmxkTWF0cml4KS5pbnZlcnNlKCk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIGNyZWF0ZUJvbmVUZXh0dXJlKCkge1xuICAgICAgICBpZiAoIXRoaXMuYm9uZXMubGVuZ3RoKSByZXR1cm47XG4gICAgICAgIGNvbnN0IHNpemUgPSBNYXRoLm1heCg0LCBNYXRoLnBvdygyLCBNYXRoLmNlaWwoTWF0aC5sb2coTWF0aC5zcXJ0KHRoaXMuYm9uZXMubGVuZ3RoICogNCkpIC8gTWF0aC5MTjIpKSk7XG4gICAgICAgIHRoaXMuYm9uZU1hdHJpY2VzID0gbmV3IEZsb2F0MzJBcnJheShzaXplICogc2l6ZSAqIDQpO1xuICAgICAgICB0aGlzLmJvbmVUZXh0dXJlU2l6ZSA9IHNpemU7XG4gICAgICAgIHRoaXMuYm9uZVRleHR1cmUgPSBuZXcgVGV4dHVyZSh0aGlzLmdsLCB7XG4gICAgICAgICAgICBpbWFnZTogdGhpcy5ib25lTWF0cmljZXMsXG4gICAgICAgICAgICBnZW5lcmF0ZU1pcG1hcHM6IGZhbHNlLFxuICAgICAgICAgICAgdHlwZTogdGhpcy5nbC5GTE9BVCxcbiAgICAgICAgICAgIGludGVybmFsRm9ybWF0OiB0aGlzLmdsLnJlbmRlcmVyLmlzV2ViZ2wyID8gdGhpcy5nbC5SR0JBMzJGIDogdGhpcy5nbC5SR0JBLFxuICAgICAgICAgICAgbWluRmlsdGVyOiB0aGlzLmdsLk5FQVJFU1QsXG4gICAgICAgICAgICBtYWdGaWx0ZXI6IHRoaXMuZ2wuTkVBUkVTVCxcbiAgICAgICAgICAgIGZsaXBZOiBmYWxzZSxcbiAgICAgICAgICAgIHdpZHRoOiBzaXplLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBhZGRBbmltYXRpb24oZGF0YSkge1xuICAgICAgICBjb25zdCBhbmltYXRpb24gPSBuZXcgQW5pbWF0aW9uKHsgb2JqZWN0czogdGhpcy5ib25lcywgZGF0YSB9KTtcbiAgICAgICAgdGhpcy5hbmltYXRpb25zLnB1c2goYW5pbWF0aW9uKTtcbiAgICAgICAgcmV0dXJuIGFuaW1hdGlvbjtcbiAgICB9XG5cbiAgICB1cGRhdGUoKSB7XG4gICAgICAgIC8vIENhbGN1bGF0ZSBjb21iaW5lZCBhbmltYXRpb24gd2VpZ2h0XG4gICAgICAgIGxldCB0b3RhbCA9IDA7XG4gICAgICAgIHRoaXMuYW5pbWF0aW9ucy5mb3JFYWNoKChhbmltYXRpb24pID0+ICh0b3RhbCArPSBhbmltYXRpb24ud2VpZ2h0KSk7XG5cbiAgICAgICAgdGhpcy5hbmltYXRpb25zLmZvckVhY2goKGFuaW1hdGlvbiwgaSkgPT4ge1xuICAgICAgICAgICAgLy8gZm9yY2UgZmlyc3QgYW5pbWF0aW9uIHRvIHNldCBpbiBvcmRlciB0byByZXNldCBmcmFtZVxuICAgICAgICAgICAgYW5pbWF0aW9uLnVwZGF0ZSh0b3RhbCwgaSA9PT0gMCk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIGRyYXcoeyBjYW1lcmEgfSA9IHt9KSB7XG4gICAgICAgIC8vIFVwZGF0ZSB3b3JsZCBtYXRyaWNlcyBtYW51YWxseSwgYXMgbm90IHBhcnQgb2Ygc2NlbmUgZ3JhcGhcbiAgICAgICAgdGhpcy5yb290LnVwZGF0ZU1hdHJpeFdvcmxkKHRydWUpO1xuXG4gICAgICAgIC8vIFVwZGF0ZSBib25lIHRleHR1cmVcbiAgICAgICAgdGhpcy5ib25lcy5mb3JFYWNoKChib25lLCBpKSA9PiB7XG4gICAgICAgICAgICAvLyBGaW5kIGRpZmZlcmVuY2UgYmV0d2VlbiBjdXJyZW50IGFuZCBiaW5kIHBvc2VcbiAgICAgICAgICAgIHRlbXBNYXQ0Lm11bHRpcGx5KGJvbmUud29ybGRNYXRyaXgsIGJvbmUuYmluZEludmVyc2UpO1xuICAgICAgICAgICAgdGhpcy5ib25lTWF0cmljZXMuc2V0KHRlbXBNYXQ0LCBpICogMTYpO1xuICAgICAgICB9KTtcbiAgICAgICAgaWYgKHRoaXMuYm9uZVRleHR1cmUpIHRoaXMuYm9uZVRleHR1cmUubmVlZHNVcGRhdGUgPSB0cnVlO1xuXG4gICAgICAgIHN1cGVyLmRyYXcoeyBjYW1lcmEgfSk7XG4gICAgfVxufVxuIiwiZXhwb3J0IGZ1bmN0aW9uIFRleHQoe1xuICAgIGZvbnQsXG4gICAgdGV4dCxcbiAgICB3aWR0aCA9IEluZmluaXR5LFxuICAgIGFsaWduID0gJ2xlZnQnLFxuICAgIHNpemUgPSAxLFxuICAgIGxldHRlclNwYWNpbmcgPSAwLFxuICAgIGxpbmVIZWlnaHQgPSAxLjQsXG4gICAgd29yZFNwYWNpbmcgPSAwLFxuICAgIHdvcmRCcmVhayA9IGZhbHNlLFxufSkge1xuICAgIGNvbnN0IF90aGlzID0gdGhpcztcbiAgICBsZXQgZ2x5cGhzLCBidWZmZXJzO1xuICAgIGxldCBmb250SGVpZ2h0LCBiYXNlbGluZSwgc2NhbGU7XG5cbiAgICBjb25zdCBuZXdsaW5lID0gL1xcbi87XG4gICAgY29uc3Qgd2hpdGVzcGFjZSA9IC9cXHMvO1xuXG4gICAge1xuICAgICAgICBwYXJzZUZvbnQoKTtcbiAgICAgICAgY3JlYXRlR2VvbWV0cnkoKTtcbiAgICB9XG5cbiAgICBmdW5jdGlvbiBwYXJzZUZvbnQoKSB7XG4gICAgICAgIGdseXBocyA9IHt9O1xuICAgICAgICBmb250LmNoYXJzLmZvckVhY2goKGQpID0+IChnbHlwaHNbZC5jaGFyXSA9IGQpKTtcbiAgICB9XG5cbiAgICBmdW5jdGlvbiBjcmVhdGVHZW9tZXRyeSgpIHtcbiAgICAgICAgZm9udEhlaWdodCA9IGZvbnQuY29tbW9uLmxpbmVIZWlnaHQ7XG4gICAgICAgIGJhc2VsaW5lID0gZm9udC5jb21tb24uYmFzZTtcblxuICAgICAgICAvLyBVc2UgYmFzZWxpbmUgc28gdGhhdCBhY3R1YWwgdGV4dCBoZWlnaHQgaXMgYXMgY2xvc2UgdG8gJ3NpemUnIHZhbHVlIGFzIHBvc3NpYmxlXG4gICAgICAgIHNjYWxlID0gc2l6ZSAvIGJhc2VsaW5lO1xuXG4gICAgICAgIC8vIFN0cmlwIHNwYWNlcyBhbmQgbmV3bGluZXMgdG8gZ2V0IGFjdHVhbCBjaGFyYWN0ZXIgbGVuZ3RoIGZvciBidWZmZXJzXG4gICAgICAgIGxldCBjaGFycyA9IHRleHQucmVwbGFjZSgvWyBcXG5dL2csICcnKTtcbiAgICAgICAgbGV0IG51bUNoYXJzID0gY2hhcnMubGVuZ3RoO1xuXG4gICAgICAgIC8vIENyZWF0ZSBvdXRwdXQgYnVmZmVyc1xuICAgICAgICBidWZmZXJzID0ge1xuICAgICAgICAgICAgcG9zaXRpb246IG5ldyBGbG9hdDMyQXJyYXkobnVtQ2hhcnMgKiA0ICogMyksXG4gICAgICAgICAgICB1djogbmV3IEZsb2F0MzJBcnJheShudW1DaGFycyAqIDQgKiAyKSxcbiAgICAgICAgICAgIGlkOiBuZXcgRmxvYXQzMkFycmF5KG51bUNoYXJzICogNCksXG4gICAgICAgICAgICBpbmRleDogbmV3IFVpbnQxNkFycmF5KG51bUNoYXJzICogNiksXG4gICAgICAgIH07XG5cbiAgICAgICAgLy8gU2V0IHZhbHVlcyBmb3IgYnVmZmVycyB0aGF0IGRvbid0IHJlcXVpcmUgY2FsY3VsYXRpb25cbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBudW1DaGFyczsgaSsrKSB7XG4gICAgICAgICAgICBidWZmZXJzLmlkLnNldChbaSwgaSwgaSwgaV0sIGkgKiA0KTtcbiAgICAgICAgICAgIGJ1ZmZlcnMuaW5kZXguc2V0KFtpICogNCwgaSAqIDQgKyAyLCBpICogNCArIDEsIGkgKiA0ICsgMSwgaSAqIDQgKyAyLCBpICogNCArIDNdLCBpICogNik7XG4gICAgICAgIH1cblxuICAgICAgICBsYXlvdXQoKTtcbiAgICB9XG5cbiAgICBmdW5jdGlvbiBsYXlvdXQoKSB7XG4gICAgICAgIGNvbnN0IGxpbmVzID0gW107XG5cbiAgICAgICAgbGV0IGN1cnNvciA9IDA7XG5cbiAgICAgICAgbGV0IHdvcmRDdXJzb3IgPSAwO1xuICAgICAgICBsZXQgd29yZFdpZHRoID0gMDtcbiAgICAgICAgbGV0IGxpbmUgPSBuZXdMaW5lKCk7XG5cbiAgICAgICAgZnVuY3Rpb24gbmV3TGluZSgpIHtcbiAgICAgICAgICAgIGNvbnN0IGxpbmUgPSB7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDAsXG4gICAgICAgICAgICAgICAgZ2x5cGhzOiBbXSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBsaW5lcy5wdXNoKGxpbmUpO1xuICAgICAgICAgICAgd29yZEN1cnNvciA9IGN1cnNvcjtcbiAgICAgICAgICAgIHdvcmRXaWR0aCA9IDA7XG4gICAgICAgICAgICByZXR1cm4gbGluZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGxldCBtYXhUaW1lcyA9IDEwMDtcbiAgICAgICAgbGV0IGNvdW50ID0gMDtcbiAgICAgICAgd2hpbGUgKGN1cnNvciA8IHRleHQubGVuZ3RoICYmIGNvdW50IDwgbWF4VGltZXMpIHtcbiAgICAgICAgICAgIGNvdW50Kys7XG5cbiAgICAgICAgICAgIGNvbnN0IGNoYXIgPSB0ZXh0W2N1cnNvcl07XG5cbiAgICAgICAgICAgIC8vIFNraXAgd2hpdGVzcGFjZSBhdCBzdGFydCBvZiBsaW5lXG4gICAgICAgICAgICBpZiAoIWxpbmUud2lkdGggJiYgd2hpdGVzcGFjZS50ZXN0KGNoYXIpKSB7XG4gICAgICAgICAgICAgICAgY3Vyc29yKys7XG4gICAgICAgICAgICAgICAgd29yZEN1cnNvciA9IGN1cnNvcjtcbiAgICAgICAgICAgICAgICB3b3JkV2lkdGggPSAwO1xuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBJZiBuZXdsaW5lIGNoYXIsIHNraXAgdG8gbmV4dCBsaW5lXG4gICAgICAgICAgICBpZiAobmV3bGluZS50ZXN0KGNoYXIpKSB7XG4gICAgICAgICAgICAgICAgY3Vyc29yKys7XG4gICAgICAgICAgICAgICAgbGluZSA9IG5ld0xpbmUoKTtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY29uc3QgZ2x5cGggPSBnbHlwaHNbY2hhcl0gfHwgZ2x5cGhzWycgJ107XG5cbiAgICAgICAgICAgIC8vIEZpbmQgYW55IGFwcGxpY2FibGUga2VybiBwYWlyc1xuICAgICAgICAgICAgaWYgKGxpbmUuZ2x5cGhzLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHByZXZHbHlwaCA9IGxpbmUuZ2x5cGhzW2xpbmUuZ2x5cGhzLmxlbmd0aCAtIDFdWzBdO1xuICAgICAgICAgICAgICAgIGxldCBrZXJuID0gZ2V0S2VyblBhaXJPZmZzZXQoZ2x5cGguaWQsIHByZXZHbHlwaC5pZCkgKiBzY2FsZTtcbiAgICAgICAgICAgICAgICBsaW5lLndpZHRoICs9IGtlcm47XG4gICAgICAgICAgICAgICAgd29yZFdpZHRoICs9IGtlcm47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIGFkZCBjaGFyIHRvIGxpbmVcbiAgICAgICAgICAgIGxpbmUuZ2x5cGhzLnB1c2goW2dseXBoLCBsaW5lLndpZHRoXSk7XG5cbiAgICAgICAgICAgIC8vIGNhbGN1bGF0ZSBhZHZhbmNlIGZvciBuZXh0IGdseXBoXG4gICAgICAgICAgICBsZXQgYWR2YW5jZSA9IDA7XG5cbiAgICAgICAgICAgIC8vIElmIHdoaXRlc3BhY2UsIHVwZGF0ZSBsb2NhdGlvbiBvZiBjdXJyZW50IHdvcmQgZm9yIGxpbmUgYnJlYWtzXG4gICAgICAgICAgICBpZiAod2hpdGVzcGFjZS50ZXN0KGNoYXIpKSB7XG4gICAgICAgICAgICAgICAgd29yZEN1cnNvciA9IGN1cnNvcjtcbiAgICAgICAgICAgICAgICB3b3JkV2lkdGggPSAwO1xuXG4gICAgICAgICAgICAgICAgLy8gQWRkIHdvcmRzcGFjaW5nXG4gICAgICAgICAgICAgICAgYWR2YW5jZSArPSB3b3JkU3BhY2luZyAqIHNpemU7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIEFkZCBsZXR0ZXJzcGFjaW5nXG4gICAgICAgICAgICAgICAgYWR2YW5jZSArPSBsZXR0ZXJTcGFjaW5nICogc2l6ZTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgYWR2YW5jZSArPSBnbHlwaC54YWR2YW5jZSAqIHNjYWxlO1xuXG4gICAgICAgICAgICBsaW5lLndpZHRoICs9IGFkdmFuY2U7XG4gICAgICAgICAgICB3b3JkV2lkdGggKz0gYWR2YW5jZTtcblxuICAgICAgICAgICAgLy8gSWYgd2lkdGggZGVmaW5lZFxuICAgICAgICAgICAgaWYgKGxpbmUud2lkdGggPiB3aWR0aCkge1xuICAgICAgICAgICAgICAgIC8vIElmIGNhbiBicmVhayB3b3JkcywgdW5kbyBsYXRlc3QgZ2x5cGggaWYgbGluZSBub3QgZW1wdHkgYW5kIGNyZWF0ZSBuZXcgbGluZVxuICAgICAgICAgICAgICAgIGlmICh3b3JkQnJlYWsgJiYgbGluZS5nbHlwaHMubGVuZ3RoID4gMSkge1xuICAgICAgICAgICAgICAgICAgICBsaW5lLndpZHRoIC09IGFkdmFuY2U7XG4gICAgICAgICAgICAgICAgICAgIGxpbmUuZ2x5cGhzLnBvcCgpO1xuICAgICAgICAgICAgICAgICAgICBsaW5lID0gbmV3TGluZSgpO1xuICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcblxuICAgICAgICAgICAgICAgICAgICAvLyBJZiBub3QgZmlyc3Qgd29yZCwgdW5kbyBjdXJyZW50IHdvcmQgYW5kIGN1cnNvciBhbmQgY3JlYXRlIG5ldyBsaW5lXG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICghd29yZEJyZWFrICYmIHdvcmRXaWR0aCAhPT0gbGluZS53aWR0aCkge1xuICAgICAgICAgICAgICAgICAgICBsZXQgbnVtR2x5cGhzID0gY3Vyc29yIC0gd29yZEN1cnNvciArIDE7XG4gICAgICAgICAgICAgICAgICAgIGxpbmUuZ2x5cGhzLnNwbGljZSgtbnVtR2x5cGhzLCBudW1HbHlwaHMpO1xuICAgICAgICAgICAgICAgICAgICBjdXJzb3IgPSB3b3JkQ3Vyc29yO1xuICAgICAgICAgICAgICAgICAgICBsaW5lLndpZHRoIC09IHdvcmRXaWR0aDtcbiAgICAgICAgICAgICAgICAgICAgbGluZSA9IG5ld0xpbmUoKTtcbiAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBjdXJzb3IrKztcbiAgICAgICAgICAgIC8vIFJlc2V0IGluZmluaXRlIGxvb3AgY2F0Y2hcbiAgICAgICAgICAgIGNvdW50ID0gMDtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFJlbW92ZSBsYXN0IGxpbmUgaWYgZW1wdHlcbiAgICAgICAgaWYgKCFsaW5lLndpZHRoKSBsaW5lcy5wb3AoKTtcblxuICAgICAgICBwb3B1bGF0ZUJ1ZmZlcnMobGluZXMpO1xuICAgIH1cblxuICAgIGZ1bmN0aW9uIHBvcHVsYXRlQnVmZmVycyhsaW5lcykge1xuICAgICAgICBjb25zdCB0ZXhXID0gZm9udC5jb21tb24uc2NhbGVXO1xuICAgICAgICBjb25zdCB0ZXhIID0gZm9udC5jb21tb24uc2NhbGVIO1xuXG4gICAgICAgIC8vIEZvciBhbGwgZm9udHMgdGVzdGVkLCBhIGxpdHRsZSBvZmZzZXQgd2FzIG5lZWRlZCB0byBiZSByaWdodCBvbiB0aGUgYmFzZWxpbmUsIGhlbmNlIDAuMDcuXG4gICAgICAgIGxldCB5ID0gMC4wNyAqIHNpemU7XG4gICAgICAgIGxldCBqID0gMDtcblxuICAgICAgICBmb3IgKGxldCBsaW5lSW5kZXggPSAwOyBsaW5lSW5kZXggPCBsaW5lcy5sZW5ndGg7IGxpbmVJbmRleCsrKSB7XG4gICAgICAgICAgICBsZXQgbGluZSA9IGxpbmVzW2xpbmVJbmRleF07XG5cbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGluZS5nbHlwaHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBnbHlwaCA9IGxpbmUuZ2x5cGhzW2ldWzBdO1xuICAgICAgICAgICAgICAgIGxldCB4ID0gbGluZS5nbHlwaHNbaV1bMV07XG5cbiAgICAgICAgICAgICAgICBpZiAoYWxpZ24gPT09ICdjZW50ZXInKSB7XG4gICAgICAgICAgICAgICAgICAgIHggLT0gbGluZS53aWR0aCAqIDAuNTtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGFsaWduID09PSAncmlnaHQnKSB7XG4gICAgICAgICAgICAgICAgICAgIHggLT0gbGluZS53aWR0aDtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAvLyBJZiBzcGFjZSwgZG9uJ3QgYWRkIHRvIGdlb21ldHJ5XG4gICAgICAgICAgICAgICAgaWYgKHdoaXRlc3BhY2UudGVzdChnbHlwaC5jaGFyKSkgY29udGludWU7XG5cbiAgICAgICAgICAgICAgICAvLyBBcHBseSBjaGFyIHNwcml0ZSBvZmZzZXRzXG4gICAgICAgICAgICAgICAgeCArPSBnbHlwaC54b2Zmc2V0ICogc2NhbGU7XG4gICAgICAgICAgICAgICAgeSAtPSBnbHlwaC55b2Zmc2V0ICogc2NhbGU7XG5cbiAgICAgICAgICAgICAgICAvLyBlYWNoIGxldHRlciBpcyBhIHF1YWQuIGF4aXMgYm90dG9tIGxlZnRcbiAgICAgICAgICAgICAgICBsZXQgdyA9IGdseXBoLndpZHRoICogc2NhbGU7XG4gICAgICAgICAgICAgICAgbGV0IGggPSBnbHlwaC5oZWlnaHQgKiBzY2FsZTtcbiAgICAgICAgICAgICAgICBidWZmZXJzLnBvc2l0aW9uLnNldChbeCwgeSAtIGgsIDAsIHgsIHksIDAsIHggKyB3LCB5IC0gaCwgMCwgeCArIHcsIHksIDBdLCBqICogNCAqIDMpO1xuXG4gICAgICAgICAgICAgICAgbGV0IHUgPSBnbHlwaC54IC8gdGV4VztcbiAgICAgICAgICAgICAgICBsZXQgdXcgPSBnbHlwaC53aWR0aCAvIHRleFc7XG4gICAgICAgICAgICAgICAgbGV0IHYgPSAxLjAgLSBnbHlwaC55IC8gdGV4SDtcbiAgICAgICAgICAgICAgICBsZXQgdmggPSBnbHlwaC5oZWlnaHQgLyB0ZXhIO1xuICAgICAgICAgICAgICAgIGJ1ZmZlcnMudXYuc2V0KFt1LCB2IC0gdmgsIHUsIHYsIHUgKyB1dywgdiAtIHZoLCB1ICsgdXcsIHZdLCBqICogNCAqIDIpO1xuXG4gICAgICAgICAgICAgICAgLy8gUmVzZXQgY3Vyc29yIHRvIGJhc2VsaW5lXG4gICAgICAgICAgICAgICAgeSArPSBnbHlwaC55b2Zmc2V0ICogc2NhbGU7XG5cbiAgICAgICAgICAgICAgICBqKys7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHkgLT0gc2l6ZSAqIGxpbmVIZWlnaHQ7XG4gICAgICAgIH1cblxuICAgICAgICBfdGhpcy5idWZmZXJzID0gYnVmZmVycztcbiAgICAgICAgX3RoaXMubnVtTGluZXMgPSBsaW5lcy5sZW5ndGg7XG4gICAgICAgIF90aGlzLmhlaWdodCA9IF90aGlzLm51bUxpbmVzICogc2l6ZSAqIGxpbmVIZWlnaHQ7XG4gICAgICAgIF90aGlzLndpZHRoID0gTWF0aC5tYXgoLi4ubGluZXMubWFwKChsaW5lKSA9PiBsaW5lLndpZHRoKSk7XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gZ2V0S2VyblBhaXJPZmZzZXQoaWQxLCBpZDIpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBmb250Lmtlcm5pbmdzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBsZXQgayA9IGZvbnQua2VybmluZ3NbaV07XG4gICAgICAgICAgICBpZiAoay5maXJzdCA8IGlkMSkgY29udGludWU7XG4gICAgICAgICAgICBpZiAoay5zZWNvbmQgPCBpZDIpIGNvbnRpbnVlO1xuICAgICAgICAgICAgaWYgKGsuZmlyc3QgPiBpZDEpIHJldHVybiAwO1xuICAgICAgICAgICAgaWYgKGsuZmlyc3QgPT09IGlkMSAmJiBrLnNlY29uZCA+IGlkMikgcmV0dXJuIDA7XG4gICAgICAgICAgICByZXR1cm4gay5hbW91bnQ7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIDA7XG4gICAgfVxuXG4gICAgLy8gVXBkYXRlIGJ1ZmZlcnMgdG8gbGF5b3V0IHdpdGggbmV3IGxheW91dFxuICAgIHRoaXMucmVzaXplID0gZnVuY3Rpb24gKG9wdGlvbnMpIHtcbiAgICAgICAgKHsgd2lkdGggfSA9IG9wdGlvbnMpO1xuICAgICAgICBsYXlvdXQoKTtcbiAgICB9O1xuXG4gICAgLy8gQ29tcGxldGVseSBjaGFuZ2UgdGV4dCAobGlrZSBjcmVhdGluZyBuZXcgVGV4dClcbiAgICB0aGlzLnVwZGF0ZSA9IGZ1bmN0aW9uIChvcHRpb25zKSB7XG4gICAgICAgICh7IHRleHQgfSA9IG9wdGlvbnMpO1xuICAgICAgICBjcmVhdGVHZW9tZXRyeSgpO1xuICAgIH07XG59XG4iLCJpbXBvcnQgeyBQcm9ncmFtIH0gZnJvbSAnLi4vY29yZS9Qcm9ncmFtLmpzJztcblxuY29uc3QgdmVydGV4ID0gLyogZ2xzbCAqLyBgXG4gICAgcHJlY2lzaW9uIGhpZ2hwIGZsb2F0O1xuICAgIHByZWNpc2lvbiBoaWdocCBpbnQ7XG5cbiAgICBhdHRyaWJ1dGUgdmVjMyBwb3NpdGlvbjtcbiAgICBhdHRyaWJ1dGUgdmVjMyBub3JtYWw7XG5cbiAgICB1bmlmb3JtIG1hdDMgbm9ybWFsTWF0cml4O1xuICAgIHVuaWZvcm0gbWF0NCBtb2RlbFZpZXdNYXRyaXg7XG4gICAgdW5pZm9ybSBtYXQ0IHByb2plY3Rpb25NYXRyaXg7XG5cbiAgICB2YXJ5aW5nIHZlYzMgdk5vcm1hbDtcblxuICAgIHZvaWQgbWFpbigpIHtcbiAgICAgICAgdk5vcm1hbCA9IG5vcm1hbGl6ZShub3JtYWxNYXRyaXggKiBub3JtYWwpO1xuICAgICAgICBnbF9Qb3NpdGlvbiA9IHByb2plY3Rpb25NYXRyaXggKiBtb2RlbFZpZXdNYXRyaXggKiB2ZWM0KHBvc2l0aW9uLCAxLjApO1xuICAgIH1cbmA7XG5cbmNvbnN0IGZyYWdtZW50ID0gLyogZ2xzbCAqLyBgXG4gICAgcHJlY2lzaW9uIGhpZ2hwIGZsb2F0O1xuICAgIHByZWNpc2lvbiBoaWdocCBpbnQ7XG5cbiAgICB2YXJ5aW5nIHZlYzMgdk5vcm1hbDtcblxuICAgIHZvaWQgbWFpbigpIHtcbiAgICAgICAgZ2xfRnJhZ0NvbG9yLnJnYiA9IG5vcm1hbGl6ZSh2Tm9ybWFsKTtcbiAgICAgICAgZ2xfRnJhZ0NvbG9yLmEgPSAxLjA7XG4gICAgfVxuYDtcblxuZXhwb3J0IGZ1bmN0aW9uIE5vcm1hbFByb2dyYW0oZ2wpIHtcbiAgICByZXR1cm4gbmV3IFByb2dyYW0oZ2wsIHtcbiAgICAgICAgdmVydGV4OiB2ZXJ0ZXgsXG4gICAgICAgIGZyYWdtZW50OiBmcmFnbWVudCxcbiAgICAgICAgY3VsbEZhY2U6IGZhbHNlLFxuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgUmVuZGVyVGFyZ2V0IH0gZnJvbSAnLi4vY29yZS9SZW5kZXJUYXJnZXQuanMnO1xuaW1wb3J0IHsgUHJvZ3JhbSB9IGZyb20gJy4uL2NvcmUvUHJvZ3JhbS5qcyc7XG5pbXBvcnQgeyBNZXNoIH0gZnJvbSAnLi4vY29yZS9NZXNoLmpzJztcbmltcG9ydCB7IFZlYzIgfSBmcm9tICcuLi9tYXRoL1ZlYzIuanMnO1xuaW1wb3J0IHsgVHJpYW5nbGUgfSBmcm9tICcuL1RyaWFuZ2xlLmpzJztcblxuZXhwb3J0IGNsYXNzIEZsb3dtYXAge1xuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBnbCxcbiAgICAgICAge1xuICAgICAgICAgICAgc2l6ZSA9IDEyOCwgLy8gZGVmYXVsdCBzaXplIG9mIHRoZSByZW5kZXIgdGFyZ2V0c1xuICAgICAgICAgICAgZmFsbG9mZiA9IDAuMywgLy8gc2l6ZSBvZiB0aGUgc3RhbXAsIHBlcmNlbnRhZ2Ugb2YgdGhlIHNpemVcbiAgICAgICAgICAgIGFscGhhID0gMSwgLy8gb3BhY2l0eSBvZiB0aGUgc3RhbXBcbiAgICAgICAgICAgIGRpc3NpcGF0aW9uID0gMC45OCwgLy8gYWZmZWN0cyB0aGUgc3BlZWQgdGhhdCB0aGUgc3RhbXAgZmFkZXMuIENsb3NlciB0byAxIGlzIHNsb3dlclxuICAgICAgICAgICAgdHlwZSwgLy8gUGFzcyBpbiBnbC5GTE9BVCB0byBmb3JjZSBpdCwgZGVmYXVsdHMgdG8gZ2wuSEFMRl9GTE9BVFxuICAgICAgICB9ID0ge31cbiAgICApIHtcbiAgICAgICAgY29uc3QgX3RoaXMgPSB0aGlzO1xuICAgICAgICB0aGlzLmdsID0gZ2w7XG5cbiAgICAgICAgLy8gb3V0cHV0IHVuaWZvcm0gY29udGFpbmluZyByZW5kZXIgdGFyZ2V0IHRleHR1cmVzXG4gICAgICAgIHRoaXMudW5pZm9ybSA9IHsgdmFsdWU6IG51bGwgfTtcblxuICAgICAgICB0aGlzLm1hc2sgPSB7XG4gICAgICAgICAgICByZWFkOiBudWxsLFxuICAgICAgICAgICAgd3JpdGU6IG51bGwsXG5cbiAgICAgICAgICAgIC8vIEhlbHBlciBmdW5jdGlvbiB0byBwaW5nIHBvbmcgdGhlIHJlbmRlciB0YXJnZXRzIGFuZCB1cGRhdGUgdGhlIHVuaWZvcm1cbiAgICAgICAgICAgIHN3YXA6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBsZXQgdGVtcCA9IF90aGlzLm1hc2sucmVhZDtcbiAgICAgICAgICAgICAgICBfdGhpcy5tYXNrLnJlYWQgPSBfdGhpcy5tYXNrLndyaXRlO1xuICAgICAgICAgICAgICAgIF90aGlzLm1hc2sud3JpdGUgPSB0ZW1wO1xuICAgICAgICAgICAgICAgIF90aGlzLnVuaWZvcm0udmFsdWUgPSBfdGhpcy5tYXNrLnJlYWQudGV4dHVyZTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH07XG5cbiAgICAgICAge1xuICAgICAgICAgICAgY3JlYXRlRkJPcygpO1xuXG4gICAgICAgICAgICB0aGlzLmFzcGVjdCA9IDE7XG4gICAgICAgICAgICB0aGlzLm1vdXNlID0gbmV3IFZlYzIoKTtcbiAgICAgICAgICAgIHRoaXMudmVsb2NpdHkgPSBuZXcgVmVjMigpO1xuXG4gICAgICAgICAgICB0aGlzLm1lc2ggPSBpbml0UHJvZ3JhbSgpO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gY3JlYXRlRkJPcygpIHtcbiAgICAgICAgICAgIC8vIFJlcXVlc3RlZCB0eXBlIG5vdCBzdXBwb3J0ZWQsIGZhbGwgYmFjayB0byBoYWxmIGZsb2F0XG4gICAgICAgICAgICBpZiAoIXR5cGUpIHR5cGUgPSBnbC5IQUxGX0ZMT0FUIHx8IGdsLnJlbmRlcmVyLmV4dGVuc2lvbnNbJ09FU190ZXh0dXJlX2hhbGZfZmxvYXQnXS5IQUxGX0ZMT0FUX09FUztcblxuICAgICAgICAgICAgbGV0IG1pbkZpbHRlciA9ICgoKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKGdsLnJlbmRlcmVyLmlzV2ViZ2wyKSByZXR1cm4gZ2wuTElORUFSO1xuICAgICAgICAgICAgICAgIGlmIChnbC5yZW5kZXJlci5leHRlbnNpb25zW2BPRVNfdGV4dHVyZV8ke3R5cGUgPT09IGdsLkZMT0FUID8gJycgOiAnaGFsZl8nfWZsb2F0X2xpbmVhcmBdKSByZXR1cm4gZ2wuTElORUFSO1xuICAgICAgICAgICAgICAgIHJldHVybiBnbC5ORUFSRVNUO1xuICAgICAgICAgICAgfSkoKTtcblxuICAgICAgICAgICAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICAgICAgICAgICAgICB3aWR0aDogc2l6ZSxcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IHNpemUsXG4gICAgICAgICAgICAgICAgdHlwZSxcbiAgICAgICAgICAgICAgICBmb3JtYXQ6IGdsLlJHQkEsXG4gICAgICAgICAgICAgICAgaW50ZXJuYWxGb3JtYXQ6IGdsLnJlbmRlcmVyLmlzV2ViZ2wyID8gKHR5cGUgPT09IGdsLkZMT0FUID8gZ2wuUkdCQTMyRiA6IGdsLlJHQkExNkYpIDogZ2wuUkdCQSxcbiAgICAgICAgICAgICAgICBtaW5GaWx0ZXIsXG4gICAgICAgICAgICAgICAgZGVwdGg6IGZhbHNlLFxuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgX3RoaXMubWFzay5yZWFkID0gbmV3IFJlbmRlclRhcmdldChnbCwgb3B0aW9ucyk7XG4gICAgICAgICAgICBfdGhpcy5tYXNrLndyaXRlID0gbmV3IFJlbmRlclRhcmdldChnbCwgb3B0aW9ucyk7XG4gICAgICAgICAgICBfdGhpcy5tYXNrLnN3YXAoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIGluaXRQcm9ncmFtKCkge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBNZXNoKGdsLCB7XG4gICAgICAgICAgICAgICAgLy8gVHJpYW5nbGUgdGhhdCBpbmNsdWRlcyAtMSB0byAxIHJhbmdlIGZvciAncG9zaXRpb24nLCBhbmQgMCB0byAxIHJhbmdlIGZvciAndXYnLlxuICAgICAgICAgICAgICAgIGdlb21ldHJ5OiBuZXcgVHJpYW5nbGUoZ2wpLFxuXG4gICAgICAgICAgICAgICAgcHJvZ3JhbTogbmV3IFByb2dyYW0oZ2wsIHtcbiAgICAgICAgICAgICAgICAgICAgdmVydGV4LFxuICAgICAgICAgICAgICAgICAgICBmcmFnbWVudCxcbiAgICAgICAgICAgICAgICAgICAgdW5pZm9ybXM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRNYXA6IF90aGlzLnVuaWZvcm0sXG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHVGYWxsb2ZmOiB7IHZhbHVlOiBmYWxsb2ZmICogMC41IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB1QWxwaGE6IHsgdmFsdWU6IGFscGhhIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB1RGlzc2lwYXRpb246IHsgdmFsdWU6IGRpc3NpcGF0aW9uIH0sXG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFVzZXIgbmVlZHMgdG8gdXBkYXRlIHRoZXNlXG4gICAgICAgICAgICAgICAgICAgICAgICB1QXNwZWN0OiB7IHZhbHVlOiAxIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB1TW91c2U6IHsgdmFsdWU6IF90aGlzLm1vdXNlIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB1VmVsb2NpdHk6IHsgdmFsdWU6IF90aGlzLnZlbG9jaXR5IH0sXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIGRlcHRoVGVzdDogZmFsc2UsXG4gICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHVwZGF0ZSgpIHtcbiAgICAgICAgdGhpcy5tZXNoLnByb2dyYW0udW5pZm9ybXMudUFzcGVjdC52YWx1ZSA9IHRoaXMuYXNwZWN0O1xuXG4gICAgICAgIHRoaXMuZ2wucmVuZGVyZXIucmVuZGVyKHtcbiAgICAgICAgICAgIHNjZW5lOiB0aGlzLm1lc2gsXG4gICAgICAgICAgICB0YXJnZXQ6IHRoaXMubWFzay53cml0ZSxcbiAgICAgICAgICAgIGNsZWFyOiBmYWxzZSxcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMubWFzay5zd2FwKCk7XG4gICAgfVxufVxuXG5jb25zdCB2ZXJ0ZXggPSAvKiBnbHNsICovIGBcbiAgICBhdHRyaWJ1dGUgdmVjMiB1djtcbiAgICBhdHRyaWJ1dGUgdmVjMiBwb3NpdGlvbjtcblxuICAgIHZhcnlpbmcgdmVjMiB2VXY7XG5cbiAgICB2b2lkIG1haW4oKSB7XG4gICAgICAgIHZVdiA9IHV2O1xuICAgICAgICBnbF9Qb3NpdGlvbiA9IHZlYzQocG9zaXRpb24sIDAsIDEpO1xuICAgIH1cbmA7XG5cbmNvbnN0IGZyYWdtZW50ID0gLyogZ2xzbCAqLyBgXG4gICAgcHJlY2lzaW9uIGhpZ2hwIGZsb2F0O1xuXG4gICAgdW5pZm9ybSBzYW1wbGVyMkQgdE1hcDtcblxuICAgIHVuaWZvcm0gZmxvYXQgdUZhbGxvZmY7XG4gICAgdW5pZm9ybSBmbG9hdCB1QWxwaGE7XG4gICAgdW5pZm9ybSBmbG9hdCB1RGlzc2lwYXRpb247XG4gICAgXG4gICAgdW5pZm9ybSBmbG9hdCB1QXNwZWN0O1xuICAgIHVuaWZvcm0gdmVjMiB1TW91c2U7XG4gICAgdW5pZm9ybSB2ZWMyIHVWZWxvY2l0eTtcblxuICAgIHZhcnlpbmcgdmVjMiB2VXY7XG5cbiAgICB2b2lkIG1haW4oKSB7XG4gICAgICAgIHZlYzQgY29sb3IgPSB0ZXh0dXJlMkQodE1hcCwgdlV2KSAqIHVEaXNzaXBhdGlvbjtcblxuICAgICAgICB2ZWMyIGN1cnNvciA9IHZVdiAtIHVNb3VzZTtcbiAgICAgICAgY3Vyc29yLnggKj0gdUFzcGVjdDtcblxuICAgICAgICB2ZWMzIHN0YW1wID0gdmVjMyh1VmVsb2NpdHkgKiB2ZWMyKDEsIC0xKSwgMS4wIC0gcG93KDEuMCAtIG1pbigxLjAsIGxlbmd0aCh1VmVsb2NpdHkpKSwgMy4wKSk7XG4gICAgICAgIGZsb2F0IGZhbGxvZmYgPSBzbW9vdGhzdGVwKHVGYWxsb2ZmLCAwLjAsIGxlbmd0aChjdXJzb3IpKSAqIHVBbHBoYTtcblxuICAgICAgICBjb2xvci5yZ2IgPSBtaXgoY29sb3IucmdiLCBzdGFtcCwgdmVjMyhmYWxsb2ZmKSk7XG5cbiAgICAgICAgZ2xfRnJhZ0NvbG9yID0gY29sb3I7XG4gICAgfVxuYDtcbiIsImltcG9ydCB7IFByb2dyYW0gfSBmcm9tICcuLi9jb3JlL1Byb2dyYW0uanMnO1xuaW1wb3J0IHsgTWVzaCB9IGZyb20gJy4uL2NvcmUvTWVzaC5qcyc7XG5pbXBvcnQgeyBUZXh0dXJlIH0gZnJvbSAnLi4vY29yZS9UZXh0dXJlLmpzJztcbmltcG9ydCB7IFJlbmRlclRhcmdldCB9IGZyb20gJy4uL2NvcmUvUmVuZGVyVGFyZ2V0LmpzJztcbmltcG9ydCB7IFRyaWFuZ2xlIH0gZnJvbSAnLi9UcmlhbmdsZS5qcyc7XG5cbmV4cG9ydCBjbGFzcyBHUEdQVSB7XG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIGdsLFxuICAgICAgICB7XG4gICAgICAgICAgICAvLyBBbHdheXMgcGFzcyBpbiBhcnJheSBvZiB2ZWM0cyAoUkdCQSB2YWx1ZXMgd2l0aGluIHRleHR1cmUpXG4gICAgICAgICAgICBkYXRhID0gbmV3IEZsb2F0MzJBcnJheSgxNiksXG4gICAgICAgICAgICBnZW9tZXRyeSA9IG5ldyBUcmlhbmdsZShnbCksXG4gICAgICAgICAgICB0eXBlLCAvLyBQYXNzIGluIGdsLkZMT0FUIHRvIGZvcmNlIGl0LCBkZWZhdWx0cyB0byBnbC5IQUxGX0ZMT0FUXG4gICAgICAgIH1cbiAgICApIHtcbiAgICAgICAgdGhpcy5nbCA9IGdsO1xuICAgICAgICBjb25zdCBpbml0aWFsRGF0YSA9IGRhdGE7XG4gICAgICAgIHRoaXMucGFzc2VzID0gW107XG4gICAgICAgIHRoaXMuZ2VvbWV0cnkgPSBnZW9tZXRyeTtcbiAgICAgICAgdGhpcy5kYXRhTGVuZ3RoID0gaW5pdGlhbERhdGEubGVuZ3RoIC8gNDtcblxuICAgICAgICAvLyBXaW5kb3dzIGFuZCBpT1Mgb25seSBsaWtlIHBvd2VyIG9mIDIgdGV4dHVyZXNcbiAgICAgICAgLy8gRmluZCBzbWFsbGVzdCBQTzIgdGhhdCBmaXRzIGRhdGFcbiAgICAgICAgdGhpcy5zaXplID0gTWF0aC5wb3coMiwgTWF0aC5jZWlsKE1hdGgubG9nKE1hdGguY2VpbChNYXRoLnNxcnQodGhpcy5kYXRhTGVuZ3RoKSkpIC8gTWF0aC5MTjIpKTtcblxuICAgICAgICAvLyBDcmVhdGUgY29vcmRzIGZvciBvdXRwdXQgdGV4dHVyZVxuICAgICAgICB0aGlzLmNvb3JkcyA9IG5ldyBGbG9hdDMyQXJyYXkodGhpcy5kYXRhTGVuZ3RoICogMik7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5kYXRhTGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IHggPSAoaSAlIHRoaXMuc2l6ZSkgLyB0aGlzLnNpemU7IC8vIHRvIGFkZCAwLjUgdG8gYmUgY2VudGVyIHBpeGVsID9cbiAgICAgICAgICAgIGNvbnN0IHkgPSBNYXRoLmZsb29yKGkgLyB0aGlzLnNpemUpIC8gdGhpcy5zaXplO1xuICAgICAgICAgICAgdGhpcy5jb29yZHMuc2V0KFt4LCB5XSwgaSAqIDIpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gVXNlIG9yaWdpbmFsIGRhdGEgaWYgYWxyZWFkeSBjb3JyZWN0IGxlbmd0aCBvZiBQTzIgdGV4dHVyZSwgZWxzZSBjb3B5IHRvIG5ldyBhcnJheSBvZiBjb3JyZWN0IGxlbmd0aFxuICAgICAgICBjb25zdCBmbG9hdEFycmF5ID0gKCgpID0+IHtcbiAgICAgICAgICAgIGlmIChpbml0aWFsRGF0YS5sZW5ndGggPT09IHRoaXMuc2l6ZSAqIHRoaXMuc2l6ZSAqIDQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gaW5pdGlhbERhdGE7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGNvbnN0IGEgPSBuZXcgRmxvYXQzMkFycmF5KHRoaXMuc2l6ZSAqIHRoaXMuc2l6ZSAqIDQpO1xuICAgICAgICAgICAgICAgIGEuc2V0KGluaXRpYWxEYXRhKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gYTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSkoKTtcblxuICAgICAgICAvLyBDcmVhdGUgb3V0cHV0IHRleHR1cmUgdW5pZm9ybSB1c2luZyBpbnB1dCBmbG9hdCB0ZXh0dXJlIHdpdGggaW5pdGlhbCBkYXRhXG4gICAgICAgIHRoaXMudW5pZm9ybSA9IHtcbiAgICAgICAgICAgIHZhbHVlOiBuZXcgVGV4dHVyZShnbCwge1xuICAgICAgICAgICAgICAgIGltYWdlOiBmbG9hdEFycmF5LFxuICAgICAgICAgICAgICAgIHRhcmdldDogZ2wuVEVYVFVSRV8yRCxcbiAgICAgICAgICAgICAgICB0eXBlOiBnbC5GTE9BVCxcbiAgICAgICAgICAgICAgICBmb3JtYXQ6IGdsLlJHQkEsXG4gICAgICAgICAgICAgICAgaW50ZXJuYWxGb3JtYXQ6IGdsLnJlbmRlcmVyLmlzV2ViZ2wyID8gZ2wuUkdCQTMyRiA6IGdsLlJHQkEsXG4gICAgICAgICAgICAgICAgd3JhcFM6IGdsLkNMQU1QX1RPX0VER0UsXG4gICAgICAgICAgICAgICAgd3JhcFQ6IGdsLkNMQU1QX1RPX0VER0UsXG4gICAgICAgICAgICAgICAgZ2VuZXJhdGVNaXBtYXBzOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBtaW5GaWx0ZXI6IGdsLk5FQVJFU1QsXG4gICAgICAgICAgICAgICAgbWFnRmlsdGVyOiBnbC5ORUFSRVNULFxuICAgICAgICAgICAgICAgIHdpZHRoOiB0aGlzLnNpemUsXG4gICAgICAgICAgICAgICAgZmxpcFk6IGZhbHNlLFxuICAgICAgICAgICAgfSksXG4gICAgICAgIH07XG5cbiAgICAgICAgLy8gQ3JlYXRlIEZCT3NcbiAgICAgICAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICAgICAgICAgIHdpZHRoOiB0aGlzLnNpemUsXG4gICAgICAgICAgICBoZWlnaHQ6IHRoaXMuc2l6ZSxcbiAgICAgICAgICAgIHR5cGU6IHR5cGUgfHwgZ2wuSEFMRl9GTE9BVCB8fCBnbC5yZW5kZXJlci5leHRlbnNpb25zWydPRVNfdGV4dHVyZV9oYWxmX2Zsb2F0J10uSEFMRl9GTE9BVF9PRVMsXG4gICAgICAgICAgICBmb3JtYXQ6IGdsLlJHQkEsXG4gICAgICAgICAgICBpbnRlcm5hbEZvcm1hdDogZ2wucmVuZGVyZXIuaXNXZWJnbDIgPyAodHlwZSA9PT0gZ2wuRkxPQVQgPyBnbC5SR0JBMzJGIDogZ2wuUkdCQTE2RikgOiBnbC5SR0JBLFxuICAgICAgICAgICAgbWluRmlsdGVyOiBnbC5ORUFSRVNULFxuICAgICAgICAgICAgZGVwdGg6IGZhbHNlLFxuICAgICAgICAgICAgdW5wYWNrQWxpZ25tZW50OiAxLFxuICAgICAgICB9O1xuXG4gICAgICAgIHRoaXMuZmJvID0ge1xuICAgICAgICAgICAgcmVhZDogbmV3IFJlbmRlclRhcmdldChnbCwgb3B0aW9ucyksXG4gICAgICAgICAgICB3cml0ZTogbmV3IFJlbmRlclRhcmdldChnbCwgb3B0aW9ucyksXG4gICAgICAgICAgICBzd2FwOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgbGV0IHRlbXAgPSB0aGlzLmZiby5yZWFkO1xuICAgICAgICAgICAgICAgIHRoaXMuZmJvLnJlYWQgPSB0aGlzLmZiby53cml0ZTtcbiAgICAgICAgICAgICAgICB0aGlzLmZiby53cml0ZSA9IHRlbXA7XG4gICAgICAgICAgICAgICAgdGhpcy51bmlmb3JtLnZhbHVlID0gdGhpcy5mYm8ucmVhZC50ZXh0dXJlO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfTtcbiAgICB9XG5cbiAgICBhZGRQYXNzKHsgdmVydGV4ID0gZGVmYXVsdFZlcnRleCwgZnJhZ21lbnQgPSBkZWZhdWx0RnJhZ21lbnQsIHVuaWZvcm1zID0ge30sIHRleHR1cmVVbmlmb3JtID0gJ3RNYXAnLCBlbmFibGVkID0gdHJ1ZSB9ID0ge30pIHtcbiAgICAgICAgdW5pZm9ybXNbdGV4dHVyZVVuaWZvcm1dID0gdGhpcy51bmlmb3JtO1xuICAgICAgICBjb25zdCBwcm9ncmFtID0gbmV3IFByb2dyYW0odGhpcy5nbCwgeyB2ZXJ0ZXgsIGZyYWdtZW50LCB1bmlmb3JtcyB9KTtcbiAgICAgICAgY29uc3QgbWVzaCA9IG5ldyBNZXNoKHRoaXMuZ2wsIHsgZ2VvbWV0cnk6IHRoaXMuZ2VvbWV0cnksIHByb2dyYW0gfSk7XG5cbiAgICAgICAgY29uc3QgcGFzcyA9IHtcbiAgICAgICAgICAgIG1lc2gsXG4gICAgICAgICAgICBwcm9ncmFtLFxuICAgICAgICAgICAgdW5pZm9ybXMsXG4gICAgICAgICAgICBlbmFibGVkLFxuICAgICAgICAgICAgdGV4dHVyZVVuaWZvcm0sXG4gICAgICAgIH07XG5cbiAgICAgICAgdGhpcy5wYXNzZXMucHVzaChwYXNzKTtcbiAgICAgICAgcmV0dXJuIHBhc3M7XG4gICAgfVxuXG4gICAgcmVuZGVyKCkge1xuICAgICAgICBjb25zdCBlbmFibGVkUGFzc2VzID0gdGhpcy5wYXNzZXMuZmlsdGVyKChwYXNzKSA9PiBwYXNzLmVuYWJsZWQpO1xuXG4gICAgICAgIGVuYWJsZWRQYXNzZXMuZm9yRWFjaCgocGFzcywgaSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5nbC5yZW5kZXJlci5yZW5kZXIoe1xuICAgICAgICAgICAgICAgIHNjZW5lOiBwYXNzLm1lc2gsXG4gICAgICAgICAgICAgICAgdGFyZ2V0OiB0aGlzLmZiby53cml0ZSxcbiAgICAgICAgICAgICAgICBjbGVhcjogZmFsc2UsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuZmJvLnN3YXAoKTtcbiAgICAgICAgfSk7XG4gICAgfVxufVxuXG5jb25zdCBkZWZhdWx0VmVydGV4ID0gLyogZ2xzbCAqLyBgXG4gICAgYXR0cmlidXRlIHZlYzIgdXY7XG4gICAgYXR0cmlidXRlIHZlYzIgcG9zaXRpb247XG5cbiAgICB2YXJ5aW5nIHZlYzIgdlV2O1xuXG4gICAgdm9pZCBtYWluKCkge1xuICAgICAgICB2VXYgPSB1djtcbiAgICAgICAgZ2xfUG9zaXRpb24gPSB2ZWM0KHBvc2l0aW9uLCAwLCAxKTtcbiAgICB9XG5gO1xuXG5jb25zdCBkZWZhdWx0RnJhZ21lbnQgPSAvKiBnbHNsICovIGBcbiAgICBwcmVjaXNpb24gaGlnaHAgZmxvYXQ7XG5cbiAgICB1bmlmb3JtIHNhbXBsZXIyRCB0TWFwO1xuICAgIHZhcnlpbmcgdmVjMiB2VXY7XG5cbiAgICB2b2lkIG1haW4oKSB7XG4gICAgICAgIGdsX0ZyYWdDb2xvciA9IHRleHR1cmUyRCh0TWFwLCB2VXYpO1xuICAgIH1cbmA7XG4iLCJpbXBvcnQgeyBHZW9tZXRyeSB9IGZyb20gJy4uL2NvcmUvR2VvbWV0cnkuanMnO1xuaW1wb3J0IHsgUHJvZ3JhbSB9IGZyb20gJy4uL2NvcmUvUHJvZ3JhbS5qcyc7XG5pbXBvcnQgeyBNZXNoIH0gZnJvbSAnLi4vY29yZS9NZXNoLmpzJztcbmltcG9ydCB7IFZlYzIgfSBmcm9tICcuLi9tYXRoL1ZlYzIuanMnO1xuaW1wb3J0IHsgVmVjMyB9IGZyb20gJy4uL21hdGgvVmVjMy5qcyc7XG5pbXBvcnQgeyBDb2xvciB9IGZyb20gJy4uL21hdGgvQ29sb3IuanMnO1xuXG5jb25zdCB0bXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IFZlYzMoKTtcblxuZXhwb3J0IGNsYXNzIFBvbHlsaW5lIHtcbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgZ2wsXG4gICAgICAgIHtcbiAgICAgICAgICAgIHBvaW50cywgLy8gQXJyYXkgb2YgVmVjM3NcbiAgICAgICAgICAgIHZlcnRleCA9IGRlZmF1bHRWZXJ0ZXgsXG4gICAgICAgICAgICBmcmFnbWVudCA9IGRlZmF1bHRGcmFnbWVudCxcbiAgICAgICAgICAgIHVuaWZvcm1zID0ge30sXG4gICAgICAgICAgICBhdHRyaWJ1dGVzID0ge30sIC8vIEZvciBwYXNzaW5nIGluIGN1c3RvbSBhdHRyaWJzXG4gICAgICAgIH1cbiAgICApIHtcbiAgICAgICAgdGhpcy5nbCA9IGdsO1xuICAgICAgICB0aGlzLnBvaW50cyA9IHBvaW50cztcbiAgICAgICAgdGhpcy5jb3VudCA9IHBvaW50cy5sZW5ndGg7XG5cbiAgICAgICAgLy8gQ3JlYXRlIGJ1ZmZlcnNcbiAgICAgICAgdGhpcy5wb3NpdGlvbiA9IG5ldyBGbG9hdDMyQXJyYXkodGhpcy5jb3VudCAqIDMgKiAyKTtcbiAgICAgICAgdGhpcy5wcmV2ID0gbmV3IEZsb2F0MzJBcnJheSh0aGlzLmNvdW50ICogMyAqIDIpO1xuICAgICAgICB0aGlzLm5leHQgPSBuZXcgRmxvYXQzMkFycmF5KHRoaXMuY291bnQgKiAzICogMik7XG4gICAgICAgIGNvbnN0IHNpZGUgPSBuZXcgRmxvYXQzMkFycmF5KHRoaXMuY291bnQgKiAxICogMik7XG4gICAgICAgIGNvbnN0IHV2ID0gbmV3IEZsb2F0MzJBcnJheSh0aGlzLmNvdW50ICogMiAqIDIpO1xuICAgICAgICBjb25zdCBpbmRleCA9IG5ldyBVaW50MTZBcnJheSgodGhpcy5jb3VudCAtIDEpICogMyAqIDIpO1xuXG4gICAgICAgIC8vIFNldCBzdGF0aWMgYnVmZmVyc1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuY291bnQ7IGkrKykge1xuICAgICAgICAgICAgc2lkZS5zZXQoWy0xLCAxXSwgaSAqIDIpO1xuICAgICAgICAgICAgY29uc3QgdiA9IGkgLyAodGhpcy5jb3VudCAtIDEpO1xuICAgICAgICAgICAgdXYuc2V0KFswLCB2LCAxLCB2XSwgaSAqIDQpO1xuXG4gICAgICAgICAgICBpZiAoaSA9PT0gdGhpcy5jb3VudCAtIDEpIGNvbnRpbnVlO1xuICAgICAgICAgICAgY29uc3QgaW5kID0gaSAqIDI7XG4gICAgICAgICAgICBpbmRleC5zZXQoW2luZCArIDAsIGluZCArIDEsIGluZCArIDJdLCAoaW5kICsgMCkgKiAzKTtcbiAgICAgICAgICAgIGluZGV4LnNldChbaW5kICsgMiwgaW5kICsgMSwgaW5kICsgM10sIChpbmQgKyAxKSAqIDMpO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgZ2VvbWV0cnkgPSAodGhpcy5nZW9tZXRyeSA9IG5ldyBHZW9tZXRyeShcbiAgICAgICAgICAgIGdsLFxuICAgICAgICAgICAgT2JqZWN0LmFzc2lnbihhdHRyaWJ1dGVzLCB7XG4gICAgICAgICAgICAgICAgcG9zaXRpb246IHsgc2l6ZTogMywgZGF0YTogdGhpcy5wb3NpdGlvbiB9LFxuICAgICAgICAgICAgICAgIHByZXY6IHsgc2l6ZTogMywgZGF0YTogdGhpcy5wcmV2IH0sXG4gICAgICAgICAgICAgICAgbmV4dDogeyBzaXplOiAzLCBkYXRhOiB0aGlzLm5leHQgfSxcbiAgICAgICAgICAgICAgICBzaWRlOiB7IHNpemU6IDEsIGRhdGE6IHNpZGUgfSxcbiAgICAgICAgICAgICAgICB1djogeyBzaXplOiAyLCBkYXRhOiB1diB9LFxuICAgICAgICAgICAgICAgIGluZGV4OiB7IHNpemU6IDEsIGRhdGE6IGluZGV4IH0sXG4gICAgICAgICAgICB9KVxuICAgICAgICApKTtcblxuICAgICAgICAvLyBQb3B1bGF0ZSBkeW5hbWljIGJ1ZmZlcnNcbiAgICAgICAgdGhpcy51cGRhdGVHZW9tZXRyeSgpO1xuXG4gICAgICAgIGlmICghdW5pZm9ybXMudVJlc29sdXRpb24pIHRoaXMucmVzb2x1dGlvbiA9IHVuaWZvcm1zLnVSZXNvbHV0aW9uID0geyB2YWx1ZTogbmV3IFZlYzIoKSB9O1xuICAgICAgICBpZiAoIXVuaWZvcm1zLnVEUFIpIHRoaXMuZHByID0gdW5pZm9ybXMudURQUiA9IHsgdmFsdWU6IDEgfTtcbiAgICAgICAgaWYgKCF1bmlmb3Jtcy51VGhpY2tuZXNzKSB0aGlzLnRoaWNrbmVzcyA9IHVuaWZvcm1zLnVUaGlja25lc3MgPSB7IHZhbHVlOiAxIH07XG4gICAgICAgIGlmICghdW5pZm9ybXMudUNvbG9yKSB0aGlzLmNvbG9yID0gdW5pZm9ybXMudUNvbG9yID0geyB2YWx1ZTogbmV3IENvbG9yKCcjMDAwJykgfTtcbiAgICAgICAgaWYgKCF1bmlmb3Jtcy51TWl0ZXIpIHRoaXMubWl0ZXIgPSB1bmlmb3Jtcy51TWl0ZXIgPSB7IHZhbHVlOiAxIH07XG5cbiAgICAgICAgLy8gU2V0IHNpemUgdW5pZm9ybXMnIHZhbHVlc1xuICAgICAgICB0aGlzLnJlc2l6ZSgpO1xuXG4gICAgICAgIGNvbnN0IHByb2dyYW0gPSAodGhpcy5wcm9ncmFtID0gbmV3IFByb2dyYW0oZ2wsIHtcbiAgICAgICAgICAgIHZlcnRleCxcbiAgICAgICAgICAgIGZyYWdtZW50LFxuICAgICAgICAgICAgdW5pZm9ybXMsXG4gICAgICAgIH0pKTtcblxuICAgICAgICB0aGlzLm1lc2ggPSBuZXcgTWVzaChnbCwgeyBnZW9tZXRyeSwgcHJvZ3JhbSB9KTtcbiAgICB9XG5cbiAgICB1cGRhdGVHZW9tZXRyeSgpIHtcbiAgICAgICAgdGhpcy5wb2ludHMuZm9yRWFjaCgocCwgaSkgPT4ge1xuICAgICAgICAgICAgcC50b0FycmF5KHRoaXMucG9zaXRpb24sIGkgKiAzICogMik7XG4gICAgICAgICAgICBwLnRvQXJyYXkodGhpcy5wb3NpdGlvbiwgaSAqIDMgKiAyICsgMyk7XG5cbiAgICAgICAgICAgIGlmICghaSkge1xuICAgICAgICAgICAgICAgIC8vIElmIGZpcnN0IHBvaW50LCBjYWxjdWxhdGUgcHJldiB1c2luZyB0aGUgZGlzdGFuY2UgdG8gMm5kIHBvaW50XG4gICAgICAgICAgICAgICAgdG1wLmNvcHkocClcbiAgICAgICAgICAgICAgICAgICAgLnN1Yih0aGlzLnBvaW50c1tpICsgMV0pXG4gICAgICAgICAgICAgICAgICAgIC5hZGQocCk7XG4gICAgICAgICAgICAgICAgdG1wLnRvQXJyYXkodGhpcy5wcmV2LCBpICogMyAqIDIpO1xuICAgICAgICAgICAgICAgIHRtcC50b0FycmF5KHRoaXMucHJldiwgaSAqIDMgKiAyICsgMyk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHAudG9BcnJheSh0aGlzLm5leHQsIChpIC0gMSkgKiAzICogMik7XG4gICAgICAgICAgICAgICAgcC50b0FycmF5KHRoaXMubmV4dCwgKGkgLSAxKSAqIDMgKiAyICsgMyk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChpID09PSB0aGlzLnBvaW50cy5sZW5ndGggLSAxKSB7XG4gICAgICAgICAgICAgICAgLy8gSWYgbGFzdCBwb2ludCwgY2FsY3VsYXRlIG5leHQgdXNpbmcgZGlzdGFuY2UgdG8gMm5kIGxhc3QgcG9pbnRcbiAgICAgICAgICAgICAgICB0bXAuY29weShwKVxuICAgICAgICAgICAgICAgICAgICAuc3ViKHRoaXMucG9pbnRzW2kgLSAxXSlcbiAgICAgICAgICAgICAgICAgICAgLmFkZChwKTtcbiAgICAgICAgICAgICAgICB0bXAudG9BcnJheSh0aGlzLm5leHQsIGkgKiAzICogMik7XG4gICAgICAgICAgICAgICAgdG1wLnRvQXJyYXkodGhpcy5uZXh0LCBpICogMyAqIDIgKyAzKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcC50b0FycmF5KHRoaXMucHJldiwgKGkgKyAxKSAqIDMgKiAyKTtcbiAgICAgICAgICAgICAgICBwLnRvQXJyYXkodGhpcy5wcmV2LCAoaSArIDEpICogMyAqIDIgKyAzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG5cbiAgICAgICAgdGhpcy5nZW9tZXRyeS5hdHRyaWJ1dGVzLnBvc2l0aW9uLm5lZWRzVXBkYXRlID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5nZW9tZXRyeS5hdHRyaWJ1dGVzLnByZXYubmVlZHNVcGRhdGUgPSB0cnVlO1xuICAgICAgICB0aGlzLmdlb21ldHJ5LmF0dHJpYnV0ZXMubmV4dC5uZWVkc1VwZGF0ZSA9IHRydWU7XG4gICAgfVxuXG4gICAgLy8gT25seSBuZWVkIHRvIGNhbGwgaWYgbm90IGhhbmRsaW5nIHJlc29sdXRpb24gdW5pZm9ybXMgbWFudWFsbHlcbiAgICByZXNpemUoKSB7XG4gICAgICAgIC8vIFVwZGF0ZSBhdXRvbWF0aWMgdW5pZm9ybXMgaWYgbm90IG92ZXJyaWRkZW5cbiAgICAgICAgaWYgKHRoaXMucmVzb2x1dGlvbikgdGhpcy5yZXNvbHV0aW9uLnZhbHVlLnNldCh0aGlzLmdsLmNhbnZhcy53aWR0aCwgdGhpcy5nbC5jYW52YXMuaGVpZ2h0KTtcbiAgICAgICAgaWYgKHRoaXMuZHByKSB0aGlzLmRwci52YWx1ZSA9IHRoaXMuZ2wucmVuZGVyZXIuZHByO1xuICAgIH1cbn1cblxuY29uc3QgZGVmYXVsdFZlcnRleCA9IC8qIGdsc2wgKi8gYFxuICAgIHByZWNpc2lvbiBoaWdocCBmbG9hdDtcblxuICAgIGF0dHJpYnV0ZSB2ZWMzIHBvc2l0aW9uO1xuICAgIGF0dHJpYnV0ZSB2ZWMzIG5leHQ7XG4gICAgYXR0cmlidXRlIHZlYzMgcHJldjtcbiAgICBhdHRyaWJ1dGUgdmVjMiB1djtcbiAgICBhdHRyaWJ1dGUgZmxvYXQgc2lkZTtcblxuICAgIHVuaWZvcm0gbWF0NCBtb2RlbFZpZXdNYXRyaXg7XG4gICAgdW5pZm9ybSBtYXQ0IHByb2plY3Rpb25NYXRyaXg7XG4gICAgdW5pZm9ybSB2ZWMyIHVSZXNvbHV0aW9uO1xuICAgIHVuaWZvcm0gZmxvYXQgdURQUjtcbiAgICB1bmlmb3JtIGZsb2F0IHVUaGlja25lc3M7XG4gICAgdW5pZm9ybSBmbG9hdCB1TWl0ZXI7XG5cbiAgICB2YXJ5aW5nIHZlYzIgdlV2O1xuXG4gICAgdmVjNCBnZXRQb3NpdGlvbigpIHtcbiAgICAgICAgbWF0NCBtdnAgPSBwcm9qZWN0aW9uTWF0cml4ICogbW9kZWxWaWV3TWF0cml4O1xuICAgICAgICB2ZWM0IGN1cnJlbnQgPSBtdnAgKiB2ZWM0KHBvc2l0aW9uLCAxKTtcbiAgICAgICAgdmVjNCBuZXh0UG9zID0gbXZwICogdmVjNChuZXh0LCAxKTtcbiAgICAgICAgdmVjNCBwcmV2UG9zID0gbXZwICogdmVjNChwcmV2LCAxKTtcblxuICAgICAgICB2ZWMyIGFzcGVjdCA9IHZlYzIodVJlc29sdXRpb24ueCAvIHVSZXNvbHV0aW9uLnksIDEpOyAgICBcbiAgICAgICAgdmVjMiBjdXJyZW50U2NyZWVuID0gY3VycmVudC54eSAvIGN1cnJlbnQudyAqIGFzcGVjdDtcbiAgICAgICAgdmVjMiBuZXh0U2NyZWVuID0gbmV4dFBvcy54eSAvIG5leHRQb3MudyAqIGFzcGVjdDtcbiAgICAgICAgdmVjMiBwcmV2U2NyZWVuID0gcHJldlBvcy54eSAvIHByZXZQb3MudyAqIGFzcGVjdDtcbiAgICBcbiAgICAgICAgdmVjMiBkaXIxID0gbm9ybWFsaXplKGN1cnJlbnRTY3JlZW4gLSBwcmV2U2NyZWVuKTtcbiAgICAgICAgdmVjMiBkaXIyID0gbm9ybWFsaXplKG5leHRTY3JlZW4gLSBjdXJyZW50U2NyZWVuKTtcbiAgICAgICAgdmVjMiBkaXIgPSBub3JtYWxpemUoZGlyMSArIGRpcjIpO1xuICAgIFxuICAgICAgICB2ZWMyIG5vcm1hbCA9IHZlYzIoLWRpci55LCBkaXIueCk7XG4gICAgICAgIG5vcm1hbCAvPSBtaXgoMS4wLCBtYXgoMC4zLCBkb3Qobm9ybWFsLCB2ZWMyKC1kaXIxLnksIGRpcjEueCkpKSwgdU1pdGVyKTtcbiAgICAgICAgbm9ybWFsIC89IGFzcGVjdDtcblxuICAgICAgICBmbG9hdCBwaXhlbFdpZHRoUmF0aW8gPSAxLjAgLyAodVJlc29sdXRpb24ueSAvIHVEUFIpO1xuICAgICAgICBmbG9hdCBwaXhlbFdpZHRoID0gY3VycmVudC53ICogcGl4ZWxXaWR0aFJhdGlvO1xuICAgICAgICBub3JtYWwgKj0gcGl4ZWxXaWR0aCAqIHVUaGlja25lc3M7XG4gICAgICAgIGN1cnJlbnQueHkgLT0gbm9ybWFsICogc2lkZTtcbiAgICBcbiAgICAgICAgcmV0dXJuIGN1cnJlbnQ7XG4gICAgfVxuXG4gICAgdm9pZCBtYWluKCkge1xuICAgICAgICB2VXYgPSB1djtcbiAgICAgICAgZ2xfUG9zaXRpb24gPSBnZXRQb3NpdGlvbigpO1xuICAgIH1cbmA7XG5cbmNvbnN0IGRlZmF1bHRGcmFnbWVudCA9IC8qIGdsc2wgKi8gYFxuICAgIHByZWNpc2lvbiBoaWdocCBmbG9hdDtcblxuICAgIHVuaWZvcm0gdmVjMyB1Q29sb3I7XG4gICAgXG4gICAgdmFyeWluZyB2ZWMyIHZVdjtcblxuICAgIHZvaWQgbWFpbigpIHtcbiAgICAgICAgZ2xfRnJhZ0NvbG9yLnJnYiA9IHVDb2xvcjtcbiAgICAgICAgZ2xfRnJhZ0NvbG9yLmEgPSAxLjA7XG4gICAgfVxuYDtcbiIsImltcG9ydCB7IENhbWVyYSB9IGZyb20gJy4uL2NvcmUvQ2FtZXJhLmpzJztcbmltcG9ydCB7IFByb2dyYW0gfSBmcm9tICcuLi9jb3JlL1Byb2dyYW0uanMnO1xuaW1wb3J0IHsgUmVuZGVyVGFyZ2V0IH0gZnJvbSAnLi4vY29yZS9SZW5kZXJUYXJnZXQuanMnO1xuXG5leHBvcnQgY2xhc3MgU2hhZG93IHtcbiAgICBjb25zdHJ1Y3RvcihnbCwgeyBsaWdodCA9IG5ldyBDYW1lcmEoZ2wpLCB3aWR0aCA9IDEwMjQsIGhlaWdodCA9IHdpZHRoIH0pIHtcbiAgICAgICAgdGhpcy5nbCA9IGdsO1xuXG4gICAgICAgIHRoaXMubGlnaHQgPSBsaWdodDtcblxuICAgICAgICB0aGlzLnRhcmdldCA9IG5ldyBSZW5kZXJUYXJnZXQoZ2wsIHsgd2lkdGgsIGhlaWdodCB9KTtcbiAgICAgICAgdGhpcy50YXJnZXRVbmlmb3JtID0geyB2YWx1ZTogdGhpcy50YXJnZXQudGV4dHVyZSB9O1xuXG4gICAgICAgIHRoaXMuZGVwdGhQcm9ncmFtID0gbmV3IFByb2dyYW0oZ2wsIHtcbiAgICAgICAgICAgIHZlcnRleDogZGVmYXVsdFZlcnRleCxcbiAgICAgICAgICAgIGZyYWdtZW50OiBkZWZhdWx0RnJhZ21lbnQsXG4gICAgICAgICAgICBjdWxsRmFjZTogZmFsc2UsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIHRoaXMuY2FzdE1lc2hlcyA9IFtdO1xuICAgIH1cblxuICAgIGFkZCh7XG4gICAgICAgIG1lc2gsXG4gICAgICAgIHJlY2VpdmUgPSB0cnVlLFxuICAgICAgICBjYXN0ID0gdHJ1ZSxcbiAgICAgICAgdmVydGV4ID0gZGVmYXVsdFZlcnRleCxcbiAgICAgICAgZnJhZ21lbnQgPSBkZWZhdWx0RnJhZ21lbnQsXG4gICAgICAgIHVuaWZvcm1Qcm9qZWN0aW9uID0gJ3NoYWRvd1Byb2plY3Rpb25NYXRyaXgnLFxuICAgICAgICB1bmlmb3JtVmlldyA9ICdzaGFkb3dWaWV3TWF0cml4JyxcbiAgICAgICAgdW5pZm9ybVRleHR1cmUgPSAndFNoYWRvdycsXG4gICAgfSkge1xuICAgICAgICAvLyBBZGQgdW5pZm9ybXMgdG8gZXhpc3RpbmcgcHJvZ3JhbVxuICAgICAgICBpZiAocmVjZWl2ZSAmJiAhbWVzaC5wcm9ncmFtLnVuaWZvcm1zW3VuaWZvcm1Qcm9qZWN0aW9uXSkge1xuICAgICAgICAgICAgbWVzaC5wcm9ncmFtLnVuaWZvcm1zW3VuaWZvcm1Qcm9qZWN0aW9uXSA9IHsgdmFsdWU6IHRoaXMubGlnaHQucHJvamVjdGlvbk1hdHJpeCB9O1xuICAgICAgICAgICAgbWVzaC5wcm9ncmFtLnVuaWZvcm1zW3VuaWZvcm1WaWV3XSA9IHsgdmFsdWU6IHRoaXMubGlnaHQudmlld01hdHJpeCB9O1xuICAgICAgICAgICAgbWVzaC5wcm9ncmFtLnVuaWZvcm1zW3VuaWZvcm1UZXh0dXJlXSA9IHRoaXMudGFyZ2V0VW5pZm9ybTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICghY2FzdCkgcmV0dXJuO1xuICAgICAgICB0aGlzLmNhc3RNZXNoZXMucHVzaChtZXNoKTtcblxuICAgICAgICAvLyBTdG9yZSBwcm9ncmFtIGZvciB3aGVuIHN3aXRjaGluZyBiZXR3ZWVuIGRlcHRoIG92ZXJyaWRlXG4gICAgICAgIG1lc2guY29sb3JQcm9ncmFtID0gbWVzaC5wcm9ncmFtO1xuXG4gICAgICAgIC8vIENoZWNrIGlmIGRlcHRoIHByb2dyYW0gYWxyZWFkeSBhdHRhY2hlZFxuICAgICAgICBpZiAobWVzaC5kZXB0aFByb2dyYW0pIHJldHVybjtcblxuICAgICAgICAvLyBVc2UgZ2xvYmFsIGRlcHRoIG92ZXJyaWRlIGlmIG5vdGhpbmcgY3VzdG9tIHBhc3NlZCBpblxuICAgICAgICBpZiAodmVydGV4ID09PSBkZWZhdWx0VmVydGV4ICYmIGZyYWdtZW50ID09PSBkZWZhdWx0RnJhZ21lbnQpIHtcbiAgICAgICAgICAgIG1lc2guZGVwdGhQcm9ncmFtID0gdGhpcy5kZXB0aFByb2dyYW07XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICAvLyBDcmVhdGUgY3VzdG9tIG92ZXJyaWRlIHByb2dyYW1cbiAgICAgICAgbWVzaC5kZXB0aFByb2dyYW0gPSBuZXcgUHJvZ3JhbSh0aGlzLmdsLCB7XG4gICAgICAgICAgICB2ZXJ0ZXgsXG4gICAgICAgICAgICBmcmFnbWVudCxcbiAgICAgICAgICAgIGN1bGxGYWNlOiBmYWxzZSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgc2V0U2l6ZSh7IHdpZHRoID0gMTAyNCwgaGVpZ2h0ID0gd2lkdGggfSkge1xuICAgICAgICB0aGlzLnRhcmdldCA9IG5ldyBSZW5kZXJUYXJnZXQodGhpcy5nbCwgeyB3aWR0aCwgaGVpZ2h0IH0pO1xuICAgICAgICB0aGlzLnRhcmdldFVuaWZvcm0udmFsdWUgPSB0aGlzLnRhcmdldC50ZXh0dXJlO1xuICAgIH1cblxuICAgIHJlbmRlcih7IHNjZW5lIH0pIHtcbiAgICAgICAgLy8gRm9yIGRlcHRoIHJlbmRlciwgcmVwbGFjZSBwcm9ncmFtIHdpdGggZGVwdGggb3ZlcnJpZGUuXG4gICAgICAgIC8vIEhpZGUgbWVzaGVzIG5vdCBjYXN0aW5nIHNoYWRvd3MuXG4gICAgICAgIHNjZW5lLnRyYXZlcnNlKChub2RlKSA9PiB7XG4gICAgICAgICAgICBpZiAoIW5vZGUuZHJhdykgcmV0dXJuO1xuICAgICAgICAgICAgaWYgKCEhfnRoaXMuY2FzdE1lc2hlcy5pbmRleE9mKG5vZGUpKSB7XG4gICAgICAgICAgICAgICAgbm9kZS5wcm9ncmFtID0gbm9kZS5kZXB0aFByb2dyYW07XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIG5vZGUuaXNGb3JjZVZpc2liaWxpdHkgPSBub2RlLnZpc2libGU7XG4gICAgICAgICAgICAgICAgbm9kZS52aXNpYmxlID0gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8vIFJlbmRlciB0aGUgZGVwdGggc2hhZG93IG1hcCB1c2luZyB0aGUgbGlnaHQgYXMgdGhlIGNhbWVyYVxuICAgICAgICB0aGlzLmdsLnJlbmRlcmVyLnJlbmRlcih7XG4gICAgICAgICAgICBzY2VuZSxcbiAgICAgICAgICAgIGNhbWVyYTogdGhpcy5saWdodCxcbiAgICAgICAgICAgIHRhcmdldDogdGhpcy50YXJnZXQsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8vIFRoZW4gc3dpdGNoIHRoZSBwcm9ncmFtIGJhY2sgdG8gdGhlIG5vcm1hbCBvbmVcbiAgICAgICAgc2NlbmUudHJhdmVyc2UoKG5vZGUpID0+IHtcbiAgICAgICAgICAgIGlmICghbm9kZS5kcmF3KSByZXR1cm47XG4gICAgICAgICAgICBpZiAoISF+dGhpcy5jYXN0TWVzaGVzLmluZGV4T2Yobm9kZSkpIHtcbiAgICAgICAgICAgICAgICBub2RlLnByb2dyYW0gPSBub2RlLmNvbG9yUHJvZ3JhbTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgbm9kZS52aXNpYmxlID0gbm9kZS5pc0ZvcmNlVmlzaWJpbGl0eTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxufVxuXG5jb25zdCBkZWZhdWx0VmVydGV4ID0gLyogZ2xzbCAqLyBgXG4gICAgYXR0cmlidXRlIHZlYzMgcG9zaXRpb247XG4gICAgYXR0cmlidXRlIHZlYzIgdXY7XG5cbiAgICB1bmlmb3JtIG1hdDQgbW9kZWxWaWV3TWF0cml4O1xuICAgIHVuaWZvcm0gbWF0NCBwcm9qZWN0aW9uTWF0cml4O1xuXG4gICAgdm9pZCBtYWluKCkge1xuICAgICAgICBnbF9Qb3NpdGlvbiA9IHByb2plY3Rpb25NYXRyaXggKiBtb2RlbFZpZXdNYXRyaXggKiB2ZWM0KHBvc2l0aW9uLCAxLjApO1xuICAgIH1cbmA7XG5cbmNvbnN0IGRlZmF1bHRGcmFnbWVudCA9IC8qIGdsc2wgKi8gYFxuICAgIHByZWNpc2lvbiBoaWdocCBmbG9hdDtcblxuICAgIHZlYzQgcGFja1JHQkEgKGZsb2F0IHYpIHtcbiAgICAgICAgdmVjNCBwYWNrID0gZnJhY3QodmVjNCgxLjAsIDI1NS4wLCA2NTAyNS4wLCAxNjU4MTM3NS4wKSAqIHYpO1xuICAgICAgICBwYWNrIC09IHBhY2sueXp3dyAqIHZlYzIoMS4wIC8gMjU1LjAsIDAuMCkueHh4eTtcbiAgICAgICAgcmV0dXJuIHBhY2s7XG4gICAgfVxuXG4gICAgdm9pZCBtYWluKCkge1xuICAgICAgICBnbF9GcmFnQ29sb3IgPSBwYWNrUkdCQShnbF9GcmFnQ29vcmQueik7XG4gICAgfVxuYDtcbiIsImltcG9ydCB7IFRleHR1cmUgfSBmcm9tICcuLi9jb3JlL1RleHR1cmUuanMnO1xuXG4vLyBUT0RPOiBTdXBwb3J0IGN1YmVtYXBzXG4vLyBHZW5lcmF0ZSB0ZXh0dXJlcyB1c2luZyBodHRwczovL2dpdGh1Yi5jb20vVGltdmFuU2NoZXJwZW56ZWVsL3RleHR1cmUtY29tcHJlc3NvclxuXG5leHBvcnQgY2xhc3MgS1RYVGV4dHVyZSBleHRlbmRzIFRleHR1cmUge1xuICAgIGNvbnN0cnVjdG9yKGdsLCB7IGJ1ZmZlciwgd3JhcFMgPSBnbC5DTEFNUF9UT19FREdFLCB3cmFwVCA9IGdsLkNMQU1QX1RPX0VER0UsIGFuaXNvdHJvcHkgPSAwLCBtaW5GaWx0ZXIsIG1hZ0ZpbHRlciB9ID0ge30pIHtcbiAgICAgICAgc3VwZXIoZ2wsIHtcbiAgICAgICAgICAgIGdlbmVyYXRlTWlwbWFwczogZmFsc2UsXG4gICAgICAgICAgICB3cmFwUyxcbiAgICAgICAgICAgIHdyYXBULFxuICAgICAgICAgICAgYW5pc290cm9weSxcbiAgICAgICAgICAgIG1pbkZpbHRlcixcbiAgICAgICAgICAgIG1hZ0ZpbHRlcixcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKGJ1ZmZlcikgcmV0dXJuIHRoaXMucGFyc2VCdWZmZXIoYnVmZmVyKTtcbiAgICB9XG5cbiAgICBwYXJzZUJ1ZmZlcihidWZmZXIpIHtcbiAgICAgICAgY29uc3Qga3R4ID0gbmV3IEtocm9ub3NUZXh0dXJlQ29udGFpbmVyKGJ1ZmZlcik7XG4gICAgICAgIGt0eC5taXBtYXBzLmlzQ29tcHJlc3NlZFRleHR1cmUgPSB0cnVlO1xuXG4gICAgICAgIC8vIFVwZGF0ZSB0ZXh0dXJlXG4gICAgICAgIHRoaXMuaW1hZ2UgPSBrdHgubWlwbWFwcztcbiAgICAgICAgdGhpcy5pbnRlcm5hbEZvcm1hdCA9IGt0eC5nbEludGVybmFsRm9ybWF0O1xuICAgICAgICBpZiAoa3R4Lm51bWJlck9mTWlwbWFwTGV2ZWxzID4gMSkge1xuICAgICAgICAgICAgaWYgKHRoaXMubWluRmlsdGVyID09PSB0aGlzLmdsLkxJTkVBUikgdGhpcy5taW5GaWx0ZXIgPSB0aGlzLmdsLk5FQVJFU1RfTUlQTUFQX0xJTkVBUjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGlmICh0aGlzLm1pbkZpbHRlciA9PT0gdGhpcy5nbC5ORUFSRVNUX01JUE1BUF9MSU5FQVIpIHRoaXMubWluRmlsdGVyID0gdGhpcy5nbC5MSU5FQVI7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBUT0RPOiBzdXBwb3J0IGN1YmUgbWFwc1xuICAgICAgICAvLyBrdHgubnVtYmVyT2ZGYWNlc1xuICAgIH1cbn1cblxuZnVuY3Rpb24gS2hyb25vc1RleHR1cmVDb250YWluZXIoYnVmZmVyKSB7XG4gICAgY29uc3QgaWRDaGVjayA9IFsweGFiLCAweDRiLCAweDU0LCAweDU4LCAweDIwLCAweDMxLCAweDMxLCAweGJiLCAweDBkLCAweDBhLCAweDFhLCAweDBhXTtcbiAgICBjb25zdCBpZCA9IG5ldyBVaW50OEFycmF5KGJ1ZmZlciwgMCwgMTIpO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaWQubGVuZ3RoOyBpKyspIGlmIChpZFtpXSAhPT0gaWRDaGVja1tpXSkgcmV0dXJuIGNvbnNvbGUuZXJyb3IoJ0ZpbGUgbWlzc2luZyBLVFggaWRlbnRpZmllcicpO1xuXG4gICAgLy8gVE9ETzogSXMgdGhpcyBhbHdheXMgND8gVGVzdGVkOiBbYW5kcm9pZCwgbWFjb3NdXG4gICAgY29uc3Qgc2l6ZSA9IFVpbnQzMkFycmF5LkJZVEVTX1BFUl9FTEVNRU5UO1xuICAgIGNvbnN0IGhlYWQgPSBuZXcgRGF0YVZpZXcoYnVmZmVyLCAxMiwgMTMgKiBzaXplKTtcbiAgICBjb25zdCBsaXR0bGVFbmRpYW4gPSBoZWFkLmdldFVpbnQzMigwLCB0cnVlKSA9PT0gMHgwNDAzMDIwMTtcbiAgICBjb25zdCBnbFR5cGUgPSBoZWFkLmdldFVpbnQzMigxICogc2l6ZSwgbGl0dGxlRW5kaWFuKTtcbiAgICBpZiAoZ2xUeXBlICE9PSAwKSByZXR1cm4gY29uc29sZS53YXJuKCdvbmx5IGNvbXByZXNzZWQgZm9ybWF0cyBjdXJyZW50bHkgc3VwcG9ydGVkJyk7XG4gICAgdGhpcy5nbEludGVybmFsRm9ybWF0ID0gaGVhZC5nZXRVaW50MzIoNCAqIHNpemUsIGxpdHRsZUVuZGlhbik7XG4gICAgbGV0IHdpZHRoID0gaGVhZC5nZXRVaW50MzIoNiAqIHNpemUsIGxpdHRsZUVuZGlhbik7XG4gICAgbGV0IGhlaWdodCA9IGhlYWQuZ2V0VWludDMyKDcgKiBzaXplLCBsaXR0bGVFbmRpYW4pO1xuICAgIHRoaXMubnVtYmVyT2ZGYWNlcyA9IGhlYWQuZ2V0VWludDMyKDEwICogc2l6ZSwgbGl0dGxlRW5kaWFuKTtcbiAgICB0aGlzLm51bWJlck9mTWlwbWFwTGV2ZWxzID0gTWF0aC5tYXgoMSwgaGVhZC5nZXRVaW50MzIoMTEgKiBzaXplLCBsaXR0bGVFbmRpYW4pKTtcbiAgICBjb25zdCBieXRlc09mS2V5VmFsdWVEYXRhID0gaGVhZC5nZXRVaW50MzIoMTIgKiBzaXplLCBsaXR0bGVFbmRpYW4pO1xuXG4gICAgdGhpcy5taXBtYXBzID0gW107XG4gICAgbGV0IG9mZnNldCA9IDEyICsgMTMgKiA0ICsgYnl0ZXNPZktleVZhbHVlRGF0YTtcbiAgICBmb3IgKGxldCBsZXZlbCA9IDA7IGxldmVsIDwgdGhpcy5udW1iZXJPZk1pcG1hcExldmVsczsgbGV2ZWwrKykge1xuICAgICAgICBjb25zdCBsZXZlbFNpemUgPSBuZXcgSW50MzJBcnJheShidWZmZXIsIG9mZnNldCwgMSlbMF07IC8vIHNpemUgcGVyIGZhY2UsIHNpbmNlIG5vdCBzdXBwb3J0aW5nIGFycmF5IGN1YmVtYXBzXG4gICAgICAgIG9mZnNldCArPSA0OyAvLyBsZXZlbFNpemUgZmllbGRcbiAgICAgICAgZm9yIChsZXQgZmFjZSA9IDA7IGZhY2UgPCB0aGlzLm51bWJlck9mRmFjZXM7IGZhY2UrKykge1xuICAgICAgICAgICAgY29uc3QgZGF0YSA9IG5ldyBVaW50OEFycmF5KGJ1ZmZlciwgb2Zmc2V0LCBsZXZlbFNpemUpO1xuICAgICAgICAgICAgdGhpcy5taXBtYXBzLnB1c2goeyBkYXRhLCB3aWR0aCwgaGVpZ2h0IH0pO1xuICAgICAgICAgICAgb2Zmc2V0ICs9IGxldmVsU2l6ZTtcbiAgICAgICAgICAgIG9mZnNldCArPSAzIC0gKChsZXZlbFNpemUgKyAzKSAlIDQpOyAvLyBhZGQgcGFkZGluZyBmb3Igb2RkIHNpemVkIGltYWdlXG4gICAgICAgIH1cbiAgICAgICAgd2lkdGggPSB3aWR0aCA+PiAxO1xuICAgICAgICBoZWlnaHQgPSBoZWlnaHQgPj4gMTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBUZXh0dXJlIH0gZnJvbSAnLi4vY29yZS9UZXh0dXJlLmpzJztcbmltcG9ydCB7IEtUWFRleHR1cmUgfSBmcm9tICcuL0tUWFRleHR1cmUuanMnO1xuXG4vLyBGb3IgY29tcHJlc3NlZCB0ZXh0dXJlcywgZ2VuZXJhdGUgdXNpbmcgaHR0cHM6Ly9naXRodWIuY29tL1RpbXZhblNjaGVycGVuemVlbC90ZXh0dXJlLWNvbXByZXNzb3JcblxubGV0IGNhY2hlID0ge307XG5jb25zdCBzdXBwb3J0ZWRFeHRlbnNpb25zID0gW107XG5cbmV4cG9ydCBjbGFzcyBUZXh0dXJlTG9hZGVyIHtcbiAgICBzdGF0aWMgbG9hZChcbiAgICAgICAgZ2wsXG4gICAgICAgIHtcbiAgICAgICAgICAgIHNyYywgLy8gc3RyaW5nIG9yIG9iamVjdCBvZiBleHRlbnNpb246c3JjIGtleS12YWx1ZXNcbiAgICAgICAgICAgIC8vIHtcbiAgICAgICAgICAgIC8vICAgICBwdnJ0YzogJy4uLmt0eCcsXG4gICAgICAgICAgICAvLyAgICAgczN0YzogJy4uLmt0eCcsXG4gICAgICAgICAgICAvLyAgICAgZXRjOiAnLi4ua3R4JyxcbiAgICAgICAgICAgIC8vICAgICBldGMxOiAnLi4ua3R4JyxcbiAgICAgICAgICAgIC8vICAgICBhc3RjOiAnLi4ua3R4JyxcbiAgICAgICAgICAgIC8vICAgICB3ZWJwOiAnLi4ud2VicCcsXG4gICAgICAgICAgICAvLyAgICAganBnOiAnLi4uanBnJyxcbiAgICAgICAgICAgIC8vICAgICBwbmc6ICcuLi5wbmcnLFxuICAgICAgICAgICAgLy8gfVxuXG4gICAgICAgICAgICAvLyBPbmx5IHByb3BzIHJlbGV2YW50IHRvIEtUWFRleHR1cmVcbiAgICAgICAgICAgIHdyYXBTID0gZ2wuQ0xBTVBfVE9fRURHRSxcbiAgICAgICAgICAgIHdyYXBUID0gZ2wuQ0xBTVBfVE9fRURHRSxcbiAgICAgICAgICAgIGFuaXNvdHJvcHkgPSAwLFxuXG4gICAgICAgICAgICAvLyBGb3IgcmVndWxhciBpbWFnZXNcbiAgICAgICAgICAgIGZvcm1hdCA9IGdsLlJHQkEsXG4gICAgICAgICAgICBpbnRlcm5hbEZvcm1hdCA9IGZvcm1hdCxcbiAgICAgICAgICAgIGdlbmVyYXRlTWlwbWFwcyA9IHRydWUsXG4gICAgICAgICAgICBtaW5GaWx0ZXIgPSBnZW5lcmF0ZU1pcG1hcHMgPyBnbC5ORUFSRVNUX01JUE1BUF9MSU5FQVIgOiBnbC5MSU5FQVIsXG4gICAgICAgICAgICBtYWdGaWx0ZXIgPSBnbC5MSU5FQVIsXG4gICAgICAgICAgICBwcmVtdWx0aXBseUFscGhhID0gZmFsc2UsXG4gICAgICAgICAgICB1bnBhY2tBbGlnbm1lbnQgPSA0LFxuICAgICAgICAgICAgZmxpcFkgPSB0cnVlLFxuICAgICAgICB9ID0ge31cbiAgICApIHtcbiAgICAgICAgY29uc3Qgc3VwcG9ydCA9IHRoaXMuZ2V0U3VwcG9ydGVkRXh0ZW5zaW9ucyhnbCk7XG4gICAgICAgIGxldCBleHQgPSAnbm9uZSc7XG5cbiAgICAgICAgLy8gSWYgc3JjIGlzIHN0cmluZywgZGV0ZXJtaW5lIHdoaWNoIGZvcm1hdCBmcm9tIHRoZSBleHRlbnNpb25cbiAgICAgICAgaWYgKHR5cGVvZiBzcmMgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgICBleHQgPSBzcmMuc3BsaXQoJy4nKS5wb3AoKS5zcGxpdCgnPycpWzBdLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBJZiBzcmMgaXMgb2JqZWN0LCB1c2Ugc3VwcG9ydGVkIGV4dGVuc2lvbnMgYW5kIHByb3ZpZGVkIGxpc3QgdG8gY2hvb3NlIGJlc3Qgb3B0aW9uXG4gICAgICAgIC8vIEdldCBmaXJzdCBzdXBwb3J0ZWQgbWF0Y2gsIHNvIHB1dCBpbiBvcmRlciBvZiBwcmVmZXJlbmNlXG4gICAgICAgIGlmICh0eXBlb2Ygc3JjID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgZm9yIChjb25zdCBwcm9wIGluIHNyYykge1xuICAgICAgICAgICAgICAgIGlmIChzdXBwb3J0LmluY2x1ZGVzKHByb3AudG9Mb3dlckNhc2UoKSkpIHtcbiAgICAgICAgICAgICAgICAgICAgZXh0ID0gcHJvcC50b0xvd2VyQ2FzZSgpO1xuICAgICAgICAgICAgICAgICAgICBzcmMgPSBzcmNbcHJvcF07XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFN0cmluZ2lmeSBwcm9wc1xuICAgICAgICBjb25zdCBjYWNoZUlEID0gc3JjICsgd3JhcFMgKyB3cmFwVCArIGFuaXNvdHJvcHkgKyBmb3JtYXQgKyBpbnRlcm5hbEZvcm1hdCArIGdlbmVyYXRlTWlwbWFwcyArIG1pbkZpbHRlciArIG1hZ0ZpbHRlciArIHByZW11bHRpcGx5QWxwaGEgKyB1bnBhY2tBbGlnbm1lbnQgKyBmbGlwWSArIGdsLnJlbmRlcmVyLmlkO1xuXG4gICAgICAgIC8vIENoZWNrIGNhY2hlIGZvciBleGlzdGluZyB0ZXh0dXJlXG4gICAgICAgIGlmIChjYWNoZVtjYWNoZUlEXSkgcmV0dXJuIGNhY2hlW2NhY2hlSURdO1xuXG4gICAgICAgIGxldCB0ZXh0dXJlO1xuICAgICAgICBzd2l0Y2ggKGV4dCkge1xuICAgICAgICAgICAgY2FzZSAna3R4JzpcbiAgICAgICAgICAgIGNhc2UgJ3B2cnRjJzpcbiAgICAgICAgICAgIGNhc2UgJ3MzdGMnOlxuICAgICAgICAgICAgY2FzZSAnZXRjJzpcbiAgICAgICAgICAgIGNhc2UgJ2V0YzEnOlxuICAgICAgICAgICAgY2FzZSAnYXN0Yyc6XG4gICAgICAgICAgICAgICAgLy8gTG9hZCBjb21wcmVzc2VkIHRleHR1cmUgdXNpbmcgS1RYIGZvcm1hdFxuICAgICAgICAgICAgICAgIHRleHR1cmUgPSBuZXcgS1RYVGV4dHVyZShnbCwge1xuICAgICAgICAgICAgICAgICAgICBzcmMsXG4gICAgICAgICAgICAgICAgICAgIHdyYXBTLFxuICAgICAgICAgICAgICAgICAgICB3cmFwVCxcbiAgICAgICAgICAgICAgICAgICAgYW5pc290cm9weSxcbiAgICAgICAgICAgICAgICAgICAgbWluRmlsdGVyLFxuICAgICAgICAgICAgICAgICAgICBtYWdGaWx0ZXIsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgdGV4dHVyZS5sb2FkZWQgPSB0aGlzLmxvYWRLVFgoc3JjLCB0ZXh0dXJlKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJ3dlYnAnOlxuICAgICAgICAgICAgY2FzZSAnanBnJzpcbiAgICAgICAgICAgIGNhc2UgJ2pwZWcnOlxuICAgICAgICAgICAgY2FzZSAncG5nJzpcbiAgICAgICAgICAgICAgICB0ZXh0dXJlID0gbmV3IFRleHR1cmUoZ2wsIHtcbiAgICAgICAgICAgICAgICAgICAgd3JhcFMsXG4gICAgICAgICAgICAgICAgICAgIHdyYXBULFxuICAgICAgICAgICAgICAgICAgICBhbmlzb3Ryb3B5LFxuICAgICAgICAgICAgICAgICAgICBmb3JtYXQsXG4gICAgICAgICAgICAgICAgICAgIGludGVybmFsRm9ybWF0LFxuICAgICAgICAgICAgICAgICAgICBnZW5lcmF0ZU1pcG1hcHMsXG4gICAgICAgICAgICAgICAgICAgIG1pbkZpbHRlcixcbiAgICAgICAgICAgICAgICAgICAgbWFnRmlsdGVyLFxuICAgICAgICAgICAgICAgICAgICBwcmVtdWx0aXBseUFscGhhLFxuICAgICAgICAgICAgICAgICAgICB1bnBhY2tBbGlnbm1lbnQsXG4gICAgICAgICAgICAgICAgICAgIGZsaXBZLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHRleHR1cmUubG9hZGVkID0gdGhpcy5sb2FkSW1hZ2UoZ2wsIHNyYywgdGV4dHVyZSwgZmxpcFkpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oJ05vIHN1cHBvcnRlZCBmb3JtYXQgc3VwcGxpZWQnKTtcbiAgICAgICAgICAgICAgICB0ZXh0dXJlID0gbmV3IFRleHR1cmUoZ2wpO1xuICAgICAgICB9XG5cbiAgICAgICAgdGV4dHVyZS5leHQgPSBleHQ7XG4gICAgICAgIGNhY2hlW2NhY2hlSURdID0gdGV4dHVyZTtcbiAgICAgICAgcmV0dXJuIHRleHR1cmU7XG4gICAgfVxuXG4gICAgc3RhdGljIGdldFN1cHBvcnRlZEV4dGVuc2lvbnMoZ2wpIHtcbiAgICAgICAgaWYgKHN1cHBvcnRlZEV4dGVuc2lvbnMubGVuZ3RoKSByZXR1cm4gc3VwcG9ydGVkRXh0ZW5zaW9ucztcblxuICAgICAgICBjb25zdCBleHRlbnNpb25zID0ge1xuICAgICAgICAgICAgcHZydGM6IGdsLnJlbmRlcmVyLmdldEV4dGVuc2lvbignV0VCR0xfY29tcHJlc3NlZF90ZXh0dXJlX3B2cnRjJykgfHwgZ2wucmVuZGVyZXIuZ2V0RXh0ZW5zaW9uKCdXRUJLSVRfV0VCR0xfY29tcHJlc3NlZF90ZXh0dXJlX3B2cnRjJyksXG4gICAgICAgICAgICBzM3RjOiBnbC5yZW5kZXJlci5nZXRFeHRlbnNpb24oJ1dFQkdMX2NvbXByZXNzZWRfdGV4dHVyZV9zM3RjJyksXG4gICAgICAgICAgICAvLyBldGM6IGdsLnJlbmRlcmVyLmdldEV4dGVuc2lvbignV0VCR0xfY29tcHJlc3NlZF90ZXh0dXJlX2V0YycpLFxuICAgICAgICAgICAgZXRjMTogZ2wucmVuZGVyZXIuZ2V0RXh0ZW5zaW9uKCdXRUJHTF9jb21wcmVzc2VkX3RleHR1cmVfZXRjMScpLFxuICAgICAgICAgICAgYXN0YzogZ2wucmVuZGVyZXIuZ2V0RXh0ZW5zaW9uKCdXRUJHTF9jb21wcmVzc2VkX3RleHR1cmVfYXN0YycpLFxuICAgICAgICAgICAgYmM3OiBnbC5yZW5kZXJlci5nZXRFeHRlbnNpb24oJ0VYVF90ZXh0dXJlX2NvbXByZXNzaW9uX2JwdGMnKSxcbiAgICAgICAgfTtcblxuICAgICAgICBmb3IgKGNvbnN0IGV4dCBpbiBleHRlbnNpb25zKSBpZiAoZXh0ZW5zaW9uc1tleHRdKSBzdXBwb3J0ZWRFeHRlbnNpb25zLnB1c2goZXh0KTtcblxuICAgICAgICAvLyBGb3JtYXRzIHN1cHBvcnRlZCBieSBhbGxcbiAgICAgICAgc3VwcG9ydGVkRXh0ZW5zaW9ucy5wdXNoKCdwbmcnLCAnanBnJywgJ3dlYnAnKTtcblxuICAgICAgICByZXR1cm4gc3VwcG9ydGVkRXh0ZW5zaW9ucztcbiAgICB9XG5cbiAgICBzdGF0aWMgbG9hZEtUWChzcmMsIHRleHR1cmUpIHtcbiAgICAgICAgcmV0dXJuIGZldGNoKHNyYylcbiAgICAgICAgICAgIC50aGVuKChyZXMpID0+IHJlcy5hcnJheUJ1ZmZlcigpKVxuICAgICAgICAgICAgLnRoZW4oKGJ1ZmZlcikgPT4gdGV4dHVyZS5wYXJzZUJ1ZmZlcihidWZmZXIpKTtcbiAgICB9XG5cbiAgICBzdGF0aWMgbG9hZEltYWdlKGdsLCBzcmMsIHRleHR1cmUsIGZsaXBZKSB7XG4gICAgICAgIHJldHVybiBkZWNvZGVJbWFnZShzcmMsIGZsaXBZKS50aGVuKChpbWdCbXApID0+IHtcbiAgICAgICAgICAgIC8vIENhdGNoIG5vbiBQT1QgdGV4dHVyZXMgZm9yIFdlYkdMMSBhbmQgdXBkYXRlIHBhcmFtcyB0byBhdm9pZCBlcnJvcnNcbiAgICAgICAgICAgIGlmICghZ2wucmVuZGVyZXIuaXNXZWJnbDIgJiYgKCFwb3dlck9mVHdvKGltZ0JtcC53aWR0aCkgfHwgIXBvd2VyT2ZUd28oaW1nQm1wLmhlaWdodCkpKSB7XG4gICAgICAgICAgICAgICAgaWYgKHRleHR1cmUuZ2VuZXJhdGVNaXBtYXBzKSB0ZXh0dXJlLmdlbmVyYXRlTWlwbWFwcyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIGlmICh0ZXh0dXJlLm1pbkZpbHRlciA9PT0gZ2wuTkVBUkVTVF9NSVBNQVBfTElORUFSKSB0ZXh0dXJlLm1pbkZpbHRlciA9IGdsLkxJTkVBUjtcbiAgICAgICAgICAgICAgICBpZiAodGV4dHVyZS53cmFwUyA9PT0gZ2wuUkVQRUFUKSB0ZXh0dXJlLndyYXBTID0gdGV4dHVyZS53cmFwVCA9IGdsLkNMQU1QX1RPX0VER0U7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHRleHR1cmUuaW1hZ2UgPSBpbWdCbXA7XG5cbiAgICAgICAgICAgIC8vIEZvciBjcmVhdGVJbWFnZUJpdG1hcCwgY2xvc2Ugb25jZSB1cGxvYWRlZFxuICAgICAgICAgICAgdGV4dHVyZS5vblVwZGF0ZSA9ICgpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoaW1nQm1wLmNsb3NlKSBpbWdCbXAuY2xvc2UoKTtcbiAgICAgICAgICAgICAgICB0ZXh0dXJlLm9uVXBkYXRlID0gbnVsbDtcbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIHJldHVybiBpbWdCbXA7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIHN0YXRpYyBjbGVhckNhY2hlKCkge1xuICAgICAgICBjYWNoZSA9IHt9O1xuICAgIH1cbn1cblxuZnVuY3Rpb24gcG93ZXJPZlR3byh2YWx1ZSkge1xuICAgIC8vICh3aWR0aCAmICh3aWR0aCAtIDEpKSAhPT0gMFxuICAgIHJldHVybiBNYXRoLmxvZzIodmFsdWUpICUgMSA9PT0gMDtcbn1cblxuZnVuY3Rpb24gZGVjb2RlSW1hZ2Uoc3JjLCBmbGlwWSkge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgIGlmIChpc0NyZWF0ZUltYWdlQml0bWFwKCkpIHtcbiAgICAgICAgICAgIGZldGNoKHNyYywgeyBtb2RlOiAnY29ycycgfSlcbiAgICAgICAgICAgICAgICAudGhlbigocikgPT4gci5ibG9iKCkpXG4gICAgICAgICAgICAgICAgLnRoZW4oKGIpID0+IGNyZWF0ZUltYWdlQml0bWFwKGIsIHsgaW1hZ2VPcmllbnRhdGlvbjogZmxpcFkgPyAnZmxpcFknIDogJ25vbmUnLCBwcmVtdWx0aXBseUFscGhhOiAnbm9uZScgfSkpXG4gICAgICAgICAgICAgICAgLnRoZW4ocmVzb2x2ZSlcbiAgICAgICAgICAgICAgICAuY2F0Y2goKGVycikgPT4gcmVqZWN0KGVycikpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgaW1nID0gbmV3IEltYWdlKCk7XG5cbiAgICAgICAgICAgIGltZy5jcm9zc09yaWdpbiA9ICcnO1xuICAgICAgICAgICAgaW1nLnNyYyA9IHNyYztcbiAgICAgICAgICAgIGltZy5vbmVycm9yID0gKHsgdHlwZSB9KSA9PiByZWplY3QoYCR7dHlwZX06IExvYWRpbmcgaW1hZ2VgKTtcbiAgICAgICAgICAgIGltZy5vbmxvYWQgPSAoKSA9PiByZXNvbHZlKGltZyk7XG4gICAgICAgIH1cbiAgICB9KTtcbn1cblxuZnVuY3Rpb24gaXNDcmVhdGVJbWFnZUJpdG1hcCgpIHtcbiAgICBjb25zdCBpc0Nocm9tZSA9IG5hdmlnYXRvci51c2VyQWdlbnQudG9Mb3dlckNhc2UoKS5pbmNsdWRlcygnY2hyb21lJyk7XG4gICAgaWYgKCFpc0Nocm9tZSkgcmV0dXJuIGZhbHNlO1xuICAgIHRyeSB7XG4gICAgICAgIGNyZWF0ZUltYWdlQml0bWFwO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbn1cbiIsImltcG9ydCB7IFZlYzMgfSBmcm9tICcuLi9tYXRoL1ZlYzMuanMnO1xuaW1wb3J0IHsgUXVhdCB9IGZyb20gJy4uL21hdGgvUXVhdC5qcyc7XG5cbmNvbnN0IHRtcFZlYzNBID0gLyogQF9fUFVSRV9fICovIG5ldyBWZWMzKCk7XG5jb25zdCB0bXBWZWMzQiA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgVmVjMygpO1xuY29uc3QgdG1wVmVjM0MgPSAvKiBAX19QVVJFX18gKi8gbmV3IFZlYzMoKTtcbmNvbnN0IHRtcFZlYzNEID0gLyogQF9fUFVSRV9fICovIG5ldyBWZWMzKCk7XG5cbmNvbnN0IHRtcFF1YXRBID0gLyogQF9fUFVSRV9fICovIG5ldyBRdWF0KCk7XG5jb25zdCB0bXBRdWF0QiA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgUXVhdCgpO1xuY29uc3QgdG1wUXVhdEMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFF1YXQoKTtcbmNvbnN0IHRtcFF1YXREID0gLyogQF9fUFVSRV9fICovIG5ldyBRdWF0KCk7XG5cbmV4cG9ydCBjbGFzcyBHTFRGQW5pbWF0aW9uIHtcbiAgICBjb25zdHJ1Y3RvcihkYXRhLCB3ZWlnaHQgPSAxKSB7XG4gICAgICAgIHRoaXMuZGF0YSA9IGRhdGE7XG4gICAgICAgIHRoaXMuZWxhcHNlZCA9IDA7XG4gICAgICAgIHRoaXMud2VpZ2h0ID0gd2VpZ2h0O1xuXG4gICAgICAgIC8vIFNldCB0byBmYWxzZSB0byBub3QgYXBwbHkgbW9kdWxvIHRvIGVsYXBzZWQgYWdhaW5zdCBkdXJhdGlvblxuICAgICAgICB0aGlzLmxvb3AgPSB0cnVlO1xuXG4gICAgICAgIC8vIEZpbmQgc3RhcnRpbmcgdGltZSBhcyBleHBvcnRzIGZyb20gYmxlbmRlciAocGVyaGFwcyBvdGhlcnMgdG9vKSBkb24ndCBhbHdheXMgc3RhcnQgZnJvbSAwXG4gICAgICAgIHRoaXMuc3RhcnRUaW1lID0gZGF0YS5yZWR1Y2UoKGEsIHsgdGltZXMgfSkgPT4gTWF0aC5taW4oYSwgdGltZXNbMF0pLCBJbmZpbml0eSk7XG4gICAgICAgIC8vIEdldCBsYXJnZXN0IGZpbmFsIHRpbWUgaW4gYWxsIGNoYW5uZWxzIHRvIGNhbGN1bGF0ZSBkdXJhdGlvblxuICAgICAgICB0aGlzLmVuZFRpbWUgPSBkYXRhLnJlZHVjZSgoYSwgeyB0aW1lcyB9KSA9PiBNYXRoLm1heChhLCB0aW1lc1t0aW1lcy5sZW5ndGggLSAxXSksIDApO1xuICAgICAgICB0aGlzLmR1cmF0aW9uID0gdGhpcy5lbmRUaW1lIC0gdGhpcy5zdGFydFRpbWU7XG4gICAgfVxuXG4gICAgdXBkYXRlKHRvdGFsV2VpZ2h0ID0gMSwgaXNTZXQpIHtcbiAgICAgICAgY29uc3Qgd2VpZ2h0ID0gaXNTZXQgPyAxIDogdGhpcy53ZWlnaHQgLyB0b3RhbFdlaWdodDtcbiAgICAgICAgY29uc3QgZWxhcHNlZCA9ICF0aGlzLmR1cmF0aW9uXG4gICAgICAgICAgICA/IDBcbiAgICAgICAgICAgIDogKHRoaXMubG9vcCA/IHRoaXMuZWxhcHNlZCAlIHRoaXMuZHVyYXRpb24gOiBNYXRoLm1pbih0aGlzLmVsYXBzZWQsIHRoaXMuZHVyYXRpb24gLSAwLjAwMSkpICsgdGhpcy5zdGFydFRpbWU7XG5cbiAgICAgICAgdGhpcy5kYXRhLmZvckVhY2goKHsgbm9kZSwgdHJhbnNmb3JtLCBpbnRlcnBvbGF0aW9uLCB0aW1lcywgdmFsdWVzIH0pID0+IHtcbiAgICAgICAgICAgIGlmICghdGhpcy5kdXJhdGlvbikge1xuICAgICAgICAgICAgICAgIGxldCB2YWwgPSB0bXBWZWMzQTtcbiAgICAgICAgICAgICAgICBsZXQgc2l6ZSA9IDM7XG4gICAgICAgICAgICAgICAgaWYgKHRyYW5zZm9ybSA9PT0gJ3F1YXRlcm5pb24nKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhbCA9IHRtcFF1YXRBO1xuICAgICAgICAgICAgICAgICAgICBzaXplID0gNDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdmFsLmZyb21BcnJheSh2YWx1ZXMsIDApO1xuICAgICAgICAgICAgICAgIGlmIChzaXplID09PSA0KSBub2RlW3RyYW5zZm9ybV0uc2xlcnAodmFsLCB3ZWlnaHQpO1xuICAgICAgICAgICAgICAgIGVsc2Ugbm9kZVt0cmFuc2Zvcm1dLmxlcnAodmFsLCB3ZWlnaHQpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gR2V0IGluZGV4IG9mIHR3byB0aW1lIHZhbHVlcyBlbGFwc2VkIGlzIGJldHdlZW5cbiAgICAgICAgICAgIGNvbnN0IHByZXZJbmRleCA9XG4gICAgICAgICAgICAgICAgTWF0aC5tYXgoXG4gICAgICAgICAgICAgICAgICAgIDEsXG4gICAgICAgICAgICAgICAgICAgIHRpbWVzLmZpbmRJbmRleCgodCkgPT4gdCA+IGVsYXBzZWQpXG4gICAgICAgICAgICAgICAgKSAtIDE7XG4gICAgICAgICAgICBjb25zdCBuZXh0SW5kZXggPSBwcmV2SW5kZXggKyAxO1xuXG4gICAgICAgICAgICAvLyBHZXQgbGluZWFyIGJsZW5kL2FscGhhIGJldHdlZW4gdGhlIHR3b1xuICAgICAgICAgICAgbGV0IGFscGhhID0gKGVsYXBzZWQgLSB0aW1lc1twcmV2SW5kZXhdKSAvICh0aW1lc1tuZXh0SW5kZXhdIC0gdGltZXNbcHJldkluZGV4XSk7XG4gICAgICAgICAgICBpZiAoaW50ZXJwb2xhdGlvbiA9PT0gJ1NURVAnKSBhbHBoYSA9IDA7XG5cbiAgICAgICAgICAgIGxldCBwcmV2VmFsID0gdG1wVmVjM0E7XG4gICAgICAgICAgICBsZXQgcHJldlRhbiA9IHRtcFZlYzNCO1xuICAgICAgICAgICAgbGV0IG5leHRUYW4gPSB0bXBWZWMzQztcbiAgICAgICAgICAgIGxldCBuZXh0VmFsID0gdG1wVmVjM0Q7XG4gICAgICAgICAgICBsZXQgc2l6ZSA9IDM7XG5cbiAgICAgICAgICAgIGlmICh0cmFuc2Zvcm0gPT09ICdxdWF0ZXJuaW9uJykge1xuICAgICAgICAgICAgICAgIHByZXZWYWwgPSB0bXBRdWF0QTtcbiAgICAgICAgICAgICAgICBwcmV2VGFuID0gdG1wUXVhdEI7XG4gICAgICAgICAgICAgICAgbmV4dFRhbiA9IHRtcFF1YXRDO1xuICAgICAgICAgICAgICAgIG5leHRWYWwgPSB0bXBRdWF0RDtcbiAgICAgICAgICAgICAgICBzaXplID0gNDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKGludGVycG9sYXRpb24gPT09ICdDVUJJQ1NQTElORScpIHtcbiAgICAgICAgICAgICAgICAvLyBHZXQgdGhlIHByZXYgYW5kIG5leHQgdmFsdWVzIGZyb20gdGhlIGluZGljZXNcbiAgICAgICAgICAgICAgICBwcmV2VmFsLmZyb21BcnJheSh2YWx1ZXMsIHByZXZJbmRleCAqIHNpemUgKiAzICsgc2l6ZSAqIDEpO1xuICAgICAgICAgICAgICAgIHByZXZUYW4uZnJvbUFycmF5KHZhbHVlcywgcHJldkluZGV4ICogc2l6ZSAqIDMgKyBzaXplICogMik7XG4gICAgICAgICAgICAgICAgbmV4dFRhbi5mcm9tQXJyYXkodmFsdWVzLCBuZXh0SW5kZXggKiBzaXplICogMyArIHNpemUgKiAwKTtcbiAgICAgICAgICAgICAgICBuZXh0VmFsLmZyb21BcnJheSh2YWx1ZXMsIG5leHRJbmRleCAqIHNpemUgKiAzICsgc2l6ZSAqIDEpO1xuXG4gICAgICAgICAgICAgICAgLy8gaW50ZXJwb2xhdGUgZm9yIGZpbmFsIHZhbHVlXG4gICAgICAgICAgICAgICAgcHJldlZhbCA9IHRoaXMuY3ViaWNTcGxpbmVJbnRlcnBvbGF0ZShhbHBoYSwgcHJldlZhbCwgcHJldlRhbiwgbmV4dFRhbiwgbmV4dFZhbCk7XG4gICAgICAgICAgICAgICAgaWYgKHNpemUgPT09IDQpIHByZXZWYWwubm9ybWFsaXplKCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIEdldCB0aGUgcHJldiBhbmQgbmV4dCB2YWx1ZXMgZnJvbSB0aGUgaW5kaWNlc1xuICAgICAgICAgICAgICAgIHByZXZWYWwuZnJvbUFycmF5KHZhbHVlcywgcHJldkluZGV4ICogc2l6ZSk7XG4gICAgICAgICAgICAgICAgbmV4dFZhbC5mcm9tQXJyYXkodmFsdWVzLCBuZXh0SW5kZXggKiBzaXplKTtcblxuICAgICAgICAgICAgICAgIC8vIGludGVycG9sYXRlIGZvciBmaW5hbCB2YWx1ZVxuICAgICAgICAgICAgICAgIGlmIChzaXplID09PSA0KSBwcmV2VmFsLnNsZXJwKG5leHRWYWwsIGFscGhhKTtcbiAgICAgICAgICAgICAgICBlbHNlIHByZXZWYWwubGVycChuZXh0VmFsLCBhbHBoYSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIGludGVycG9sYXRlIGJldHdlZW4gbXVsdGlwbGUgcG9zc2libGUgYW5pbWF0aW9uc1xuICAgICAgICAgICAgaWYgKHNpemUgPT09IDQpIG5vZGVbdHJhbnNmb3JtXS5zbGVycChwcmV2VmFsLCB3ZWlnaHQpO1xuICAgICAgICAgICAgZWxzZSBub2RlW3RyYW5zZm9ybV0ubGVycChwcmV2VmFsLCB3ZWlnaHQpO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBjdWJpY1NwbGluZUludGVycG9sYXRlKHQsIHByZXZWYWwsIHByZXZUYW4sIG5leHRUYW4sIG5leHRWYWwpIHtcbiAgICAgICAgY29uc3QgdDIgPSB0ICogdDtcbiAgICAgICAgY29uc3QgdDMgPSB0MiAqIHQ7XG5cbiAgICAgICAgY29uc3QgczIgPSAzICogdDIgLSAyICogdDM7XG4gICAgICAgIGNvbnN0IHMzID0gdDMgLSB0MjtcbiAgICAgICAgY29uc3QgczAgPSAxIC0gczI7XG4gICAgICAgIGNvbnN0IHMxID0gczMgLSB0MiArIHQ7XG5cbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwcmV2VmFsLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBwcmV2VmFsW2ldID0gczAgKiBwcmV2VmFsW2ldICsgczEgKiAoMSAtIHQpICogcHJldlRhbltpXSArIHMyICogbmV4dFZhbFtpXSArIHMzICogdCAqIG5leHRUYW5baV07XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gcHJldlZhbDtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBNZXNoIH0gZnJvbSAnLi4vY29yZS9NZXNoLmpzJztcbmltcG9ydCB7IE1hdDQgfSBmcm9tICcuLi9tYXRoL01hdDQuanMnO1xuaW1wb3J0IHsgVGV4dHVyZSB9IGZyb20gJy4uL2NvcmUvVGV4dHVyZS5qcyc7XG5cbmNvbnN0IHRlbXBNYXQ0ID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXQ0KCk7XG5jb25zdCBpZGVudGl0eSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWF0NCgpO1xuXG5leHBvcnQgY2xhc3MgR0xURlNraW4gZXh0ZW5kcyBNZXNoIHtcbiAgICBjb25zdHJ1Y3RvcihnbCwgeyBza2VsZXRvbiwgZ2VvbWV0cnksIHByb2dyYW0sIG1vZGUgPSBnbC5UUklBTkdMRVMgfSA9IHt9KSB7XG4gICAgICAgIHN1cGVyKGdsLCB7IGdlb21ldHJ5LCBwcm9ncmFtLCBtb2RlIH0pO1xuICAgICAgICB0aGlzLnNrZWxldG9uID0gc2tlbGV0b247XG4gICAgICAgIHRoaXMucHJvZ3JhbSA9IHByb2dyYW07XG4gICAgICAgIHRoaXMuY3JlYXRlQm9uZVRleHR1cmUoKTtcbiAgICB9XG5cbiAgICBjcmVhdGVCb25lVGV4dHVyZSgpIHtcbiAgICAgICAgaWYgKCF0aGlzLnNrZWxldG9uLmpvaW50cy5sZW5ndGgpIHJldHVybjtcbiAgICAgICAgY29uc3Qgc2l6ZSA9IE1hdGgubWF4KDQsIE1hdGgucG93KDIsIE1hdGguY2VpbChNYXRoLmxvZyhNYXRoLnNxcnQodGhpcy5za2VsZXRvbi5qb2ludHMubGVuZ3RoICogNCkpIC8gTWF0aC5MTjIpKSk7XG4gICAgICAgIHRoaXMuYm9uZU1hdHJpY2VzID0gbmV3IEZsb2F0MzJBcnJheShzaXplICogc2l6ZSAqIDQpO1xuICAgICAgICB0aGlzLmJvbmVUZXh0dXJlU2l6ZSA9IHNpemU7XG4gICAgICAgIHRoaXMuYm9uZVRleHR1cmUgPSBuZXcgVGV4dHVyZSh0aGlzLmdsLCB7XG4gICAgICAgICAgICBpbWFnZTogdGhpcy5ib25lTWF0cmljZXMsXG4gICAgICAgICAgICBnZW5lcmF0ZU1pcG1hcHM6IGZhbHNlLFxuICAgICAgICAgICAgdHlwZTogdGhpcy5nbC5GTE9BVCxcbiAgICAgICAgICAgIGludGVybmFsRm9ybWF0OiB0aGlzLmdsLnJlbmRlcmVyLmlzV2ViZ2wyID8gdGhpcy5nbC5SR0JBMzJGIDogdGhpcy5nbC5SR0JBLFxuICAgICAgICAgICAgbWluRmlsdGVyOiB0aGlzLmdsLk5FQVJFU1QsXG4gICAgICAgICAgICBtYWdGaWx0ZXI6IHRoaXMuZ2wuTkVBUkVTVCxcbiAgICAgICAgICAgIGZsaXBZOiBmYWxzZSxcbiAgICAgICAgICAgIHdpZHRoOiBzaXplLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICB1cGRhdGVVbmlmb3JtcygpIHtcbiAgICAgICAgLy8gVXBkYXRlIGJvbmUgdGV4dHVyZVxuICAgICAgICB0aGlzLnNrZWxldG9uLmpvaW50cy5mb3JFYWNoKChib25lLCBpKSA9PiB7XG4gICAgICAgICAgICAvLyBGaW5kIGRpZmZlcmVuY2UgYmV0d2VlbiBjdXJyZW50IGFuZCBiaW5kIHBvc2VcbiAgICAgICAgICAgIHRlbXBNYXQ0Lm11bHRpcGx5KGJvbmUud29ybGRNYXRyaXgsIGJvbmUuYmluZEludmVyc2UpO1xuICAgICAgICAgICAgdGhpcy5ib25lTWF0cmljZXMuc2V0KHRlbXBNYXQ0LCBpICogMTYpO1xuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5ib25lVGV4dHVyZS5uZWVkc1VwZGF0ZSA9IHRydWU7XG4gICAgICAgIC8vIFJlc2V0IGZvciBwcm9ncmFtcyBzaGFyZWQgYmV0d2VlbiBtdWx0aXBsZSBza2luc1xuICAgICAgICB0aGlzLnByb2dyYW0udW5pZm9ybXMuYm9uZVRleHR1cmUudmFsdWUgPSB0aGlzLmJvbmVUZXh0dXJlO1xuICAgICAgICB0aGlzLnByb2dyYW0udW5pZm9ybXMuYm9uZVRleHR1cmVTaXplLnZhbHVlID0gdGhpcy5ib25lVGV4dHVyZVNpemU7XG4gICAgfVxuXG4gICAgZHJhdyh7IGNhbWVyYSB9ID0ge30pIHtcbiAgICAgICAgaWYgKCF0aGlzLnByb2dyYW0udW5pZm9ybXMuYm9uZVRleHR1cmUpIHtcbiAgICAgICAgICAgIE9iamVjdC5hc3NpZ24odGhpcy5wcm9ncmFtLnVuaWZvcm1zLCB7XG4gICAgICAgICAgICAgICAgYm9uZVRleHR1cmU6IHsgdmFsdWU6IHRoaXMuYm9uZVRleHR1cmUgfSxcbiAgICAgICAgICAgICAgICBib25lVGV4dHVyZVNpemU6IHsgdmFsdWU6IHRoaXMuYm9uZVRleHR1cmVTaXplIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMudXBkYXRlVW5pZm9ybXMoKTtcblxuICAgICAgICAvLyBTd2l0Y2ggdGhlIHdvcmxkIG1hdHJpeCB3aXRoIGlkZW50aXR5IHRvIGlnbm9yZSBhbnkgdHJhbnNmb3Jtc1xuICAgICAgICAvLyBvbiB0aGUgbWVzaCBpdHNlbGYgLSBvbmx5IHVzZSBza2VsZXRvbidzIHRyYW5zZm9ybXNcbiAgICAgICAgY29uc3QgX3dvcmxkTWF0cml4ID0gdGhpcy53b3JsZE1hdHJpeDtcbiAgICAgICAgdGhpcy53b3JsZE1hdHJpeCA9IGlkZW50aXR5O1xuXG4gICAgICAgIHN1cGVyLmRyYXcoeyBjYW1lcmEgfSk7XG5cbiAgICAgICAgLy8gU3dpdGNoIGJhY2sgdG8gbGVhdmUgaWRlbnRpdHkgdW50b3VjaGVkXG4gICAgICAgIHRoaXMud29ybGRNYXRyaXggPSBfd29ybGRNYXRyaXg7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgVHJhbnNmb3JtIH0gZnJvbSAnLi4vY29yZS9UcmFuc2Zvcm0uanMnO1xuaW1wb3J0IHsgTWVzaCB9IGZyb20gJy4uL2NvcmUvTWVzaC5qcyc7XG5pbXBvcnQgeyBWZWM0IH0gZnJvbSAnLi4vbWF0aC9WZWM0LmpzJztcblxuZXhwb3J0IGNsYXNzIEluc3RhbmNlZE1lc2ggZXh0ZW5kcyBNZXNoIHtcbiAgICBjb25zdHJ1Y3RvciguLi5hcmdzKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3MpO1xuXG4gICAgICAgIC8vIFNraXAgcmVuZGVyZXIgZnJ1c3R1bSBjdWxsaW5nXG4gICAgICAgIHRoaXMuZnJ1c3R1bUN1bGxlZCA9IGZhbHNlO1xuICAgICAgICB0aGlzLmlzSW5zdGFuY2VkTWVzaCA9IHRydWU7XG4gICAgfVxuXG4gICAgYWRkRnJ1c3R1bUN1bGwoKSB7XG4gICAgICAgIHRoaXMuaW5zdGFuY2VUcmFuc2Zvcm1zID0gbnVsbDtcbiAgICAgICAgdGhpcy5pbnN0YW5jZUxpZ2h0bWFwU2NhbGVPZmZzZXQgPSBudWxsO1xuICAgICAgICB0aGlzLnRvdGFsSW5zdGFuY2VDb3VudCA9IDA7XG4gICAgICAgIHRoaXMuZnJ1c3R1bUN1bGxGdW5jdGlvbiA9IG51bGw7XG4gICAgICAgIHRoaXMuaW5zdGFuY2VSZW5kZXJMaXN0ID0gbnVsbDtcblxuICAgICAgICAvLyBHZXQgaW5zdGFuY2VkIG1lc2hcbiAgICAgICAgaWYgKCF0aGlzLmdlb21ldHJ5LmF0dHJpYnV0ZXMuaW5zdGFuY2VNYXRyaXgpXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGBtZXNoICR7dGhpcy5uYW1lID8gYFwiJHt0aGlzLm5hbWV9XCIgYCA6IGBgfW1pc3NpbmcgaW5zdGFuY2VNYXRyaXggYXR0cmlidXRlOyB1bmFibGUgdG8gZnJ1c3R1bSBjdWxsYCk7XG5cbiAgICAgICAgLy8gTWFrZSBsaXN0IG9mIHRyYW5zZm9ybXMgZnJvbSBpbnN0YW5jZU1hdHJpeFxuICAgICAgICBjb25zdCBtYXRyaXhEYXRhID0gdGhpcy5nZW9tZXRyeS5hdHRyaWJ1dGVzLmluc3RhbmNlTWF0cml4LmRhdGE7XG4gICAgICAgIHRoaXMuaW5zdGFuY2VUcmFuc2Zvcm1zID0gW107XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBqID0gMDsgaSA8IG1hdHJpeERhdGEubGVuZ3RoOyBpICs9IDE2LCBqKyspIHtcbiAgICAgICAgICAgIGNvbnN0IHRyYW5zZm9ybSA9IG5ldyBUcmFuc2Zvcm0oKTtcbiAgICAgICAgICAgIHRyYW5zZm9ybS5pbmRleCA9IGo7XG4gICAgICAgICAgICB0cmFuc2Zvcm0ubWF0cml4LmZyb21BcnJheShtYXRyaXhEYXRhLCBpKTtcbiAgICAgICAgICAgIHRyYW5zZm9ybS5kZWNvbXBvc2UoKTtcbiAgICAgICAgICAgIHRoaXMuaW5zdGFuY2VUcmFuc2Zvcm1zLnB1c2godHJhbnNmb3JtKTtcbiAgICAgICAgICAgIC8vIEFkZCB0cmFuc2Zvcm1zIHRvIHBhcmVudCB0byB1cGRhdGUgd29ybGQgbWF0cmljZXNcbiAgICAgICAgICAgIHRyYW5zZm9ybS5zZXRQYXJlbnQodGhpcy5wYXJlbnQpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMudG90YWxJbnN0YW5jZUNvdW50ID0gdGhpcy5pbnN0YW5jZVRyYW5zZm9ybXMubGVuZ3RoO1xuXG4gICAgICAgIC8vIENoZWNrIGZvciBsaWdodG1hcCBhdHRyaWJ1dGVzIC0gYXR0YWNoIHRvIHRyYW5zZm9ybVxuICAgICAgICBpZiAoISF0aGlzLmdlb21ldHJ5LmF0dHJpYnV0ZXMubGlnaHRtYXBTY2FsZU9mZnNldCkge1xuICAgICAgICAgICAgY29uc3QgbGlnaHRtYXBEYXRhID0gdGhpcy5nZW9tZXRyeS5hdHRyaWJ1dGVzLmxpZ2h0bWFwU2NhbGVPZmZzZXQuZGF0YTtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwLCBqID0gMDsgaSA8IGxpZ2h0bWFwRGF0YS5sZW5ndGg7IGkgKz0gNCwgaisrKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5pbnN0YW5jZVRyYW5zZm9ybXNbal0ubGlnaHRtYXBEYXRhID0gbmV3IFZlYzQoKS5mcm9tQXJyYXkobGlnaHRtYXBEYXRhLCBpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuZnJ1c3R1bUN1bGxGdW5jdGlvbiA9ICh7IGNhbWVyYSB9KSA9PiB7XG4gICAgICAgICAgICAvLyBmcnVzdHVtIGN1bGwgdHJhbnNmb3JtcyBlYWNoIGZyYW1lIC0gcGFzcyB3b3JsZCBtYXRyaXhcbiAgICAgICAgICAgIHRoaXMuaW5zdGFuY2VSZW5kZXJMaXN0ID0gW107XG4gICAgICAgICAgICB0aGlzLmluc3RhbmNlVHJhbnNmb3Jtcy5mb3JFYWNoKCh0cmFuc2Zvcm0pID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoIWNhbWVyYS5mcnVzdHVtSW50ZXJzZWN0c01lc2godGhpcywgdHJhbnNmb3JtLndvcmxkTWF0cml4KSkgcmV0dXJuO1xuICAgICAgICAgICAgICAgIHRoaXMuaW5zdGFuY2VSZW5kZXJMaXN0LnB1c2godHJhbnNmb3JtKTtcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAvLyB1cGRhdGUgaW5zdGFuY2VNYXRyaXggYW5kIGluc3RhbmNlZENvdW50IHdpdGggdmlzaWJsZVxuICAgICAgICAgICAgdGhpcy5pbnN0YW5jZVJlbmRlckxpc3QuZm9yRWFjaCgodHJhbnNmb3JtLCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgdHJhbnNmb3JtLm1hdHJpeC50b0FycmF5KHRoaXMuZ2VvbWV0cnkuYXR0cmlidXRlcy5pbnN0YW5jZU1hdHJpeC5kYXRhLCBpICogMTYpO1xuXG4gICAgICAgICAgICAgICAgLy8gVXBkYXRlIGxpZ2h0bWFwIGF0dHJcbiAgICAgICAgICAgICAgICBpZiAodHJhbnNmb3JtLmxpZ2h0bWFwRGF0YSkge1xuICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm0ubGlnaHRtYXBEYXRhLnRvQXJyYXkodGhpcy5nZW9tZXRyeS5hdHRyaWJ1dGVzLmxpZ2h0bWFwU2NhbGVPZmZzZXQuZGF0YSwgaSAqIDQpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmdlb21ldHJ5LmF0dHJpYnV0ZXMubGlnaHRtYXBTY2FsZU9mZnNldC5uZWVkc1VwZGF0ZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0aGlzLmdlb21ldHJ5Lmluc3RhbmNlZENvdW50ID0gdGhpcy5pbnN0YW5jZVJlbmRlckxpc3QubGVuZ3RoO1xuICAgICAgICAgICAgdGhpcy5nZW9tZXRyeS5hdHRyaWJ1dGVzLmluc3RhbmNlTWF0cml4Lm5lZWRzVXBkYXRlID0gdHJ1ZTtcbiAgICAgICAgfTtcblxuICAgICAgICB0aGlzLm9uQmVmb3JlUmVuZGVyKHRoaXMuZnJ1c3R1bUN1bGxGdW5jdGlvbik7XG4gICAgfVxuXG4gICAgcmVtb3ZlRnJ1c3R1bUN1bGwoKSB7XG4gICAgICAgIHRoaXMub2ZmQmVmb3JlUmVuZGVyKHRoaXMuZnJ1c3R1bUN1bGxGdW5jdGlvbik7XG4gICAgICAgIHRoaXMuZ2VvbWV0cnkuaW5zdGFuY2VkQ291bnQgPSB0aGlzLnRvdGFsSW5zdGFuY2VDb3VudDtcbiAgICAgICAgdGhpcy5pbnN0YW5jZVRyYW5zZm9ybXMuZm9yRWFjaCgodHJhbnNmb3JtLCBpKSA9PiB7XG4gICAgICAgICAgICB0cmFuc2Zvcm0ubWF0cml4LnRvQXJyYXkodGhpcy5nZW9tZXRyeS5hdHRyaWJ1dGVzLmluc3RhbmNlTWF0cml4LmRhdGEsIGkgKiAxNik7XG5cbiAgICAgICAgICAgIC8vIFVwZGF0ZSBsaWdodG1hcCBhdHRyXG4gICAgICAgICAgICBpZiAodHJhbnNmb3JtLmxpZ2h0bWFwRGF0YSkge1xuICAgICAgICAgICAgICAgIHRyYW5zZm9ybS5saWdodG1hcERhdGEudG9BcnJheSh0aGlzLmdlb21ldHJ5LmF0dHJpYnV0ZXMubGlnaHRtYXBTY2FsZU9mZnNldC5kYXRhLCBpICogNCk7XG4gICAgICAgICAgICAgICAgdGhpcy5nZW9tZXRyeS5hdHRyaWJ1dGVzLmxpZ2h0bWFwU2NhbGVPZmZzZXQubmVlZHNVcGRhdGUgPSB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5nZW9tZXRyeS5hdHRyaWJ1dGVzLmluc3RhbmNlTWF0cml4Lm5lZWRzVXBkYXRlID0gdHJ1ZTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBHZW9tZXRyeSB9IGZyb20gJy4uL2NvcmUvR2VvbWV0cnkuanMnO1xuaW1wb3J0IHsgVHJhbnNmb3JtIH0gZnJvbSAnLi4vY29yZS9UcmFuc2Zvcm0uanMnO1xuaW1wb3J0IHsgVGV4dHVyZSB9IGZyb20gJy4uL2NvcmUvVGV4dHVyZS5qcyc7XG5pbXBvcnQgeyBNZXNoIH0gZnJvbSAnLi4vY29yZS9NZXNoLmpzJztcbmltcG9ydCB7IENhbWVyYSB9IGZyb20gJy4uL2NvcmUvQ2FtZXJhLmpzJztcbmltcG9ydCB7IEdMVEZBbmltYXRpb24gfSBmcm9tICcuL0dMVEZBbmltYXRpb24uanMnO1xuaW1wb3J0IHsgR0xURlNraW4gfSBmcm9tICcuL0dMVEZTa2luLmpzJztcbmltcG9ydCB7IE1hdDQgfSBmcm9tICcuLi9tYXRoL01hdDQuanMnO1xuaW1wb3J0IHsgVmVjMyB9IGZyb20gJy4uL21hdGgvVmVjMy5qcyc7XG5pbXBvcnQgeyBOb3JtYWxQcm9ncmFtIH0gZnJvbSAnLi9Ob3JtYWxQcm9ncmFtLmpzJztcbmltcG9ydCB7IEluc3RhbmNlZE1lc2ggfSBmcm9tICcuL0luc3RhbmNlZE1lc2guanMnO1xuXG4vLyBUT0RPXG4vLyBbIF0gTW9ycGggdGFyZ2V0c1xuLy8gWyBdIE1hdGVyaWFsc1xuLy8gWyBdIFNwYXJzZSBhY2Nlc3NvciBwYWNraW5nPyBGb3IgbW9ycGggdGFyZ2V0cyBiYXNpY2FsbHlcbi8vIFsgXSBPcHRpb24gdG8gdHVybiBvZmYgR1BVIGluc3RhbmNpbmc/XG4vLyBbIF0gU3BvdCBsaWdodHNcblxuY29uc3QgVFlQRV9BUlJBWSA9IHtcbiAgICA1MTIwOiBJbnQ4QXJyYXksXG4gICAgNTEyMTogVWludDhBcnJheSxcbiAgICA1MTIyOiBJbnQxNkFycmF5LFxuICAgIDUxMjM6IFVpbnQxNkFycmF5LFxuICAgIDUxMjU6IFVpbnQzMkFycmF5LFxuICAgIDUxMjY6IEZsb2F0MzJBcnJheSxcbiAgICAnaW1hZ2UvanBlZyc6IFVpbnQ4QXJyYXksXG4gICAgJ2ltYWdlL3BuZyc6IFVpbnQ4QXJyYXksXG4gICAgJ2ltYWdlL3dlYnAnOiBVaW50OEFycmF5LFxufTtcblxuY29uc3QgVFlQRV9TSVpFID0ge1xuICAgIFNDQUxBUjogMSxcbiAgICBWRUMyOiAyLFxuICAgIFZFQzM6IDMsXG4gICAgVkVDNDogNCxcbiAgICBNQVQyOiA0LFxuICAgIE1BVDM6IDksXG4gICAgTUFUNDogMTYsXG59O1xuXG5jb25zdCBBVFRSSUJVVEVTID0ge1xuICAgIFBPU0lUSU9OOiAncG9zaXRpb24nLFxuICAgIE5PUk1BTDogJ25vcm1hbCcsXG4gICAgVEFOR0VOVDogJ3RhbmdlbnQnLFxuICAgIFRFWENPT1JEXzA6ICd1dicsXG4gICAgVEVYQ09PUkRfMTogJ3V2MicsXG4gICAgQ09MT1JfMDogJ2NvbG9yJyxcbiAgICBXRUlHSFRTXzA6ICdza2luV2VpZ2h0JyxcbiAgICBKT0lOVFNfMDogJ3NraW5JbmRleCcsXG59O1xuXG5jb25zdCBUUkFOU0ZPUk1TID0ge1xuICAgIHRyYW5zbGF0aW9uOiAncG9zaXRpb24nLFxuICAgIHJvdGF0aW9uOiAncXVhdGVybmlvbicsXG4gICAgc2NhbGU6ICdzY2FsZScsXG59O1xuXG5leHBvcnQgY2xhc3MgR0xURkxvYWRlciB7XG4gICAgc3RhdGljIHNldERyYWNvTWFuYWdlcihtYW5hZ2VyKSB7XG4gICAgICAgIHRoaXMuZHJhY29NYW5hZ2VyID0gbWFuYWdlcjtcbiAgICB9XG5cbiAgICBzdGF0aWMgc2V0QmFzaXNNYW5hZ2VyKG1hbmFnZXIpIHtcbiAgICAgICAgdGhpcy5iYXNpc01hbmFnZXIgPSBtYW5hZ2VyO1xuICAgIH1cblxuICAgIHN0YXRpYyBhc3luYyBsb2FkKGdsLCBzcmMpIHtcbiAgICAgICAgY29uc3QgZGlyID0gc3JjLnNwbGl0KCcvJykuc2xpY2UoMCwgLTEpLmpvaW4oJy8nKSArICcvJztcblxuICAgICAgICAvLyBMb2FkIG1haW4gZGVzY3JpcHRpb24ganNvblxuICAgICAgICBjb25zdCBkZXNjID0gYXdhaXQgdGhpcy5wYXJzZURlc2Moc3JjKTtcblxuICAgICAgICByZXR1cm4gdGhpcy5wYXJzZShnbCwgZGVzYywgZGlyKTtcbiAgICB9XG5cbiAgICBzdGF0aWMgYXN5bmMgcGFyc2UoZ2wsIGRlc2MsIGRpcikge1xuICAgICAgICBpZiAoZGVzYy5hc3NldCA9PT0gdW5kZWZpbmVkIHx8IGRlc2MuYXNzZXQudmVyc2lvblswXSA8IDIpXG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ09ubHkgR0xURiA+PTIuMCBzdXBwb3J0ZWQuIEF0dGVtcHRpbmcgdG8gcGFyc2UuJyk7XG5cbiAgICAgICAgaWYgKGRlc2MuZXh0ZW5zaW9uc1JlcXVpcmVkPy5pbmNsdWRlcygnS0hSX2RyYWNvX21lc2hfY29tcHJlc3Npb24nKSAmJiAhdGhpcy5kcmFjb01hbmFnZXIpXG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ0tIUl9kcmFjb19tZXNoX2NvbXByZXNzaW9uIGV4dGVuc2lvbiByZXF1aXJlZCBidXQgbm8gbWFuYWdlciBzdXBwbGllZC4gVXNlIC5zZXREcmFjb01hbmFnZXIoKScpO1xuXG4gICAgICAgIGlmIChkZXNjLmV4dGVuc2lvbnNSZXF1aXJlZD8uaW5jbHVkZXMoJ0tIUl90ZXh0dXJlX2Jhc2lzdScpICYmICF0aGlzLmJhc2lzTWFuYWdlcilcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignS0hSX3RleHR1cmVfYmFzaXN1IGV4dGVuc2lvbiByZXF1aXJlZCBidXQgbm8gbWFuYWdlciBzdXBwbGllZC4gVXNlIC5zZXRCYXNpc01hbmFnZXIoKScpO1xuXG4gICAgICAgIC8vIExvYWQgYnVmZmVycyBhc3luY1xuICAgICAgICBjb25zdCBidWZmZXJzID0gYXdhaXQgdGhpcy5sb2FkQnVmZmVycyhkZXNjLCBkaXIpO1xuXG4gICAgICAgIC8vIFVuYmluZCBjdXJyZW50IFZBTyBzbyB0aGF0IG5ldyBidWZmZXJzIGRvbid0IGdldCBhZGRlZCB0byBhY3RpdmUgbWVzaFxuICAgICAgICBnbC5yZW5kZXJlci5iaW5kVmVydGV4QXJyYXkobnVsbCk7XG5cbiAgICAgICAgLy8gQ3JlYXRlIGdsIGJ1ZmZlcnMgZnJvbSBidWZmZXJWaWV3c1xuICAgICAgICBjb25zdCBidWZmZXJWaWV3cyA9IHRoaXMucGFyc2VCdWZmZXJWaWV3cyhnbCwgZGVzYywgYnVmZmVycyk7XG5cbiAgICAgICAgLy8gQ3JlYXRlIGltYWdlcyBmcm9tIGVpdGhlciBidWZmZXJWaWV3cyBvciBzZXBhcmF0ZSBpbWFnZSBmaWxlc1xuICAgICAgICBjb25zdCBpbWFnZXMgPSBhd2FpdCB0aGlzLnBhcnNlSW1hZ2VzKGdsLCBkZXNjLCBkaXIsIGJ1ZmZlclZpZXdzKTtcblxuICAgICAgICBjb25zdCB0ZXh0dXJlcyA9IHRoaXMucGFyc2VUZXh0dXJlcyhnbCwgZGVzYywgaW1hZ2VzKTtcblxuICAgICAgICAvLyBKdXN0IHBhc3MgdGhyb3VnaCBtYXRlcmlhbCBkYXRhIGZvciBub3dcbiAgICAgICAgY29uc3QgbWF0ZXJpYWxzID0gdGhpcy5wYXJzZU1hdGVyaWFscyhnbCwgZGVzYywgdGV4dHVyZXMpO1xuXG4gICAgICAgIC8vIEZldGNoIHRoZSBpbnZlcnNlIGJpbmQgbWF0cmljZXMgZm9yIHNrZWxldG9uIGpvaW50c1xuICAgICAgICBjb25zdCBza2lucyA9IHRoaXMucGFyc2VTa2lucyhnbCwgZGVzYywgYnVmZmVyVmlld3MpO1xuXG4gICAgICAgIC8vIENyZWF0ZSBnZW9tZXRyaWVzIGZvciBlYWNoIG1lc2ggcHJpbWl0aXZlXG4gICAgICAgIGNvbnN0IG1lc2hlcyA9IGF3YWl0IHRoaXMucGFyc2VNZXNoZXMoZ2wsIGRlc2MsIGJ1ZmZlclZpZXdzLCBtYXRlcmlhbHMsIHNraW5zKTtcblxuICAgICAgICAvLyBDcmVhdGUgdHJhbnNmb3JtcywgbWVzaGVzIGFuZCBoaWVyYXJjaHlcbiAgICAgICAgY29uc3QgW25vZGVzLCBjYW1lcmFzXSA9IHRoaXMucGFyc2VOb2RlcyhnbCwgZGVzYywgbWVzaGVzLCBza2lucywgaW1hZ2VzKTtcblxuICAgICAgICAvLyBQbGFjZSBub2RlcyBpbiBza2VsZXRvbnNcbiAgICAgICAgdGhpcy5wb3B1bGF0ZVNraW5zKHNraW5zLCBub2Rlcyk7XG5cbiAgICAgICAgLy8gQ3JlYXRlIGFuaW1hdGlvbiBoYW5kbGVyc1xuICAgICAgICBjb25zdCBhbmltYXRpb25zID0gdGhpcy5wYXJzZUFuaW1hdGlvbnMoZ2wsIGRlc2MsIG5vZGVzLCBidWZmZXJWaWV3cyk7XG5cbiAgICAgICAgLy8gR2V0IHRvcCBsZXZlbCBub2RlcyBmb3IgZWFjaCBzY2VuZVxuICAgICAgICBjb25zdCBzY2VuZXMgPSB0aGlzLnBhcnNlU2NlbmVzKGRlc2MsIG5vZGVzKTtcbiAgICAgICAgY29uc3Qgc2NlbmUgPSBzY2VuZXNbZGVzYy5zY2VuZV07XG5cbiAgICAgICAgLy8gQ3JlYXRlIHVuaWZvcm1zIGZvciBzY2VuZSBsaWdodHMgKFRPRE86IGxpZ2h0IGxpbmtpbmc/KVxuICAgICAgICBjb25zdCBsaWdodHMgPSB0aGlzLnBhcnNlTGlnaHRzKGdsLCBkZXNjLCBub2Rlcywgc2NlbmVzKTtcblxuICAgICAgICAvLyBSZW1vdmUgbnVsbCBub2RlcyAoaW5zdGFuY2VkIHRyYW5zZm9ybXMpXG4gICAgICAgIGZvciAobGV0IGkgPSBub2Rlcy5sZW5ndGg7IGkgPj0gMDsgaS0tKSBpZiAoIW5vZGVzW2ldKSBub2Rlcy5zcGxpY2UoaSwgMSk7XG5cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGpzb246IGRlc2MsXG4gICAgICAgICAgICBidWZmZXJzLFxuICAgICAgICAgICAgYnVmZmVyVmlld3MsXG4gICAgICAgICAgICBjYW1lcmFzLFxuICAgICAgICAgICAgaW1hZ2VzLFxuICAgICAgICAgICAgdGV4dHVyZXMsXG4gICAgICAgICAgICBtYXRlcmlhbHMsXG4gICAgICAgICAgICBtZXNoZXMsXG4gICAgICAgICAgICBub2RlcyxcbiAgICAgICAgICAgIGxpZ2h0cyxcbiAgICAgICAgICAgIGFuaW1hdGlvbnMsXG4gICAgICAgICAgICBzY2VuZXMsXG4gICAgICAgICAgICBzY2VuZSxcbiAgICAgICAgfTtcbiAgICB9XG5cbiAgICBzdGF0aWMgcGFyc2VEZXNjKHNyYykge1xuICAgICAgICByZXR1cm4gZmV0Y2goc3JjLCB7IG1vZGU6ICdjb3JzJyB9KVxuICAgICAgICAgICAgLnRoZW4oKHJlcykgPT4gcmVzLmFycmF5QnVmZmVyKCkpXG4gICAgICAgICAgICAudGhlbigoZGF0YSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHRleHREZWNvZGVyID0gbmV3IFRleHREZWNvZGVyKCk7XG4gICAgICAgICAgICAgICAgaWYgKHRleHREZWNvZGVyLmRlY29kZShuZXcgVWludDhBcnJheShkYXRhLCAwLCA0KSkgPT09ICdnbFRGJykge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy51bnBhY2tHTEIoZGF0YSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UodGV4dERlY29kZXIuZGVjb2RlKGRhdGEpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvLyBGcm9tIGh0dHBzOi8vZ2l0aHViLmNvbS9kb25tY2N1cmR5L2dsVEYtVHJhbnNmb3JtL2Jsb2IvZTQxMDhjYy9wYWNrYWdlcy9jb3JlL3NyYy9pby9pby50cyNMMzJcbiAgICBzdGF0aWMgdW5wYWNrR0xCKGdsYikge1xuICAgICAgICAvLyBEZWNvZGUgYW5kIHZlcmlmeSBHTEIgaGVhZGVyXG4gICAgICAgIGNvbnN0IGhlYWRlciA9IG5ldyBVaW50MzJBcnJheShnbGIsIDAsIDMpO1xuICAgICAgICBpZiAoaGVhZGVyWzBdICE9PSAweDQ2NTQ2YzY3KSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgZ2xURiBhc3NldC4nKTtcbiAgICAgICAgfSBlbHNlIGlmIChoZWFkZXJbMV0gIT09IDIpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5zdXBwb3J0ZWQgZ2xURiBiaW5hcnkgdmVyc2lvbiwgXCIke2hlYWRlclsxXX1cIi5gKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBEZWNvZGUgYW5kIHZlcmlmeSBjaHVuayBoZWFkZXJzXG4gICAgICAgIGNvbnN0IGpzb25DaHVua0hlYWRlciA9IG5ldyBVaW50MzJBcnJheShnbGIsIDEyLCAyKTtcbiAgICAgICAgY29uc3QganNvbkJ5dGVPZmZzZXQgPSAyMDtcbiAgICAgICAgY29uc3QganNvbkJ5dGVMZW5ndGggPSBqc29uQ2h1bmtIZWFkZXJbMF07XG4gICAgICAgIGlmIChqc29uQ2h1bmtIZWFkZXJbMV0gIT09IDB4NGU0ZjUzNGEpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignVW5leHBlY3RlZCBHTEIgbGF5b3V0LicpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gRGVjb2RlIEpTT05cbiAgICAgICAgY29uc3QganNvblRleHQgPSBuZXcgVGV4dERlY29kZXIoKS5kZWNvZGUoZ2xiLnNsaWNlKGpzb25CeXRlT2Zmc2V0LCBqc29uQnl0ZU9mZnNldCArIGpzb25CeXRlTGVuZ3RoKSk7XG4gICAgICAgIGNvbnN0IGpzb24gPSBKU09OLnBhcnNlKGpzb25UZXh0KTtcbiAgICAgICAgLy8gSlNPTiBvbmx5XG4gICAgICAgIGlmIChqc29uQnl0ZU9mZnNldCArIGpzb25CeXRlTGVuZ3RoID09PSBnbGIuYnl0ZUxlbmd0aCkgcmV0dXJuIGpzb247XG5cbiAgICAgICAgY29uc3QgYmluYXJ5Q2h1bmtIZWFkZXIgPSBuZXcgVWludDMyQXJyYXkoZ2xiLCBqc29uQnl0ZU9mZnNldCArIGpzb25CeXRlTGVuZ3RoLCAyKTtcbiAgICAgICAgaWYgKGJpbmFyeUNodW5rSGVhZGVyWzFdICE9PSAweDAwNGU0OTQyKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VuZXhwZWN0ZWQgR0xCIGxheW91dC4nKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBEZWNvZGUgY29udGVudFxuICAgICAgICBjb25zdCBiaW5hcnlCeXRlT2Zmc2V0ID0ganNvbkJ5dGVPZmZzZXQgKyBqc29uQnl0ZUxlbmd0aCArIDg7XG4gICAgICAgIGNvbnN0IGJpbmFyeUJ5dGVMZW5ndGggPSBiaW5hcnlDaHVua0hlYWRlclswXTtcbiAgICAgICAgY29uc3QgYmluYXJ5ID0gZ2xiLnNsaWNlKGJpbmFyeUJ5dGVPZmZzZXQsIGJpbmFyeUJ5dGVPZmZzZXQgKyBiaW5hcnlCeXRlTGVuZ3RoKTtcbiAgICAgICAgLy8gQXR0YWNoIGJpbmFyeSB0byBidWZmZXJcbiAgICAgICAganNvbi5idWZmZXJzWzBdLmJpbmFyeSA9IGJpbmFyeTtcbiAgICAgICAgcmV0dXJuIGpzb247XG4gICAgfVxuXG4gICAgLy8gVGhyZWVKUyBHTFRGIExvYWRlciBodHRwczovL2dpdGh1Yi5jb20vbXJkb29iL3RocmVlLmpzL2Jsb2IvbWFzdGVyL2V4YW1wbGVzL2pzL2xvYWRlcnMvR0xURkxvYWRlci5qcyNMMTA4NVxuICAgIHN0YXRpYyByZXNvbHZlVVJJKHVyaSwgZGlyKSB7XG4gICAgICAgIC8vIEludmFsaWQgVVJJXG4gICAgICAgIGlmICh0eXBlb2YgdXJpICE9PSAnc3RyaW5nJyB8fCB1cmkgPT09ICcnKSByZXR1cm4gJyc7XG5cbiAgICAgICAgLy8gSG9zdCBSZWxhdGl2ZSBVUklcbiAgICAgICAgaWYgKC9eaHR0cHM/OlxcL1xcLy9pLnRlc3QoZGlyKSAmJiAvXlxcLy8udGVzdCh1cmkpKSB7XG4gICAgICAgICAgICBkaXIgPSBkaXIucmVwbGFjZSgvKF5odHRwcz86XFwvXFwvW15cXC9dKykuKi9pLCAnJDEnKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIEFic29sdXRlIFVSSSBodHRwOi8vLCBodHRwczovLywgLy9cbiAgICAgICAgaWYgKC9eKGh0dHBzPzopP1xcL1xcLy9pLnRlc3QodXJpKSkgcmV0dXJuIHVyaTtcblxuICAgICAgICAvLyBEYXRhIFVSSVxuICAgICAgICBpZiAoL15kYXRhOi4qLC4qJC9pLnRlc3QodXJpKSkgcmV0dXJuIHVyaTtcblxuICAgICAgICAvLyBCbG9iIFVSSVxuICAgICAgICBpZiAoL15ibG9iOi4qJC9pLnRlc3QodXJpKSkgcmV0dXJuIHVyaTtcblxuICAgICAgICAvLyBSZWxhdGl2ZSBVUklcbiAgICAgICAgcmV0dXJuIGRpciArIHVyaTtcbiAgICB9XG5cbiAgICBzdGF0aWMgbG9hZEJ1ZmZlcnMoZGVzYywgZGlyKSB7XG4gICAgICAgIGlmICghZGVzYy5idWZmZXJzKSByZXR1cm4gbnVsbDtcbiAgICAgICAgcmV0dXJuIFByb21pc2UuYWxsKFxuICAgICAgICAgICAgZGVzYy5idWZmZXJzLm1hcCgoYnVmZmVyKSA9PiB7XG4gICAgICAgICAgICAgICAgLy8gRm9yIEdMQiwgYmluYXJ5IGJ1ZmZlciByZWFkeSB0byBnb1xuICAgICAgICAgICAgICAgIGlmIChidWZmZXIuYmluYXJ5KSByZXR1cm4gYnVmZmVyLmJpbmFyeTtcbiAgICAgICAgICAgICAgICBjb25zdCB1cmkgPSB0aGlzLnJlc29sdmVVUkkoYnVmZmVyLnVyaSwgZGlyKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmV0Y2godXJpLCB7IG1vZGU6ICdjb3JzJyB9KS50aGVuKChyZXMpID0+IHJlcy5hcnJheUJ1ZmZlcigpKTtcbiAgICAgICAgICAgIH0pXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgc3RhdGljIHBhcnNlQnVmZmVyVmlld3MoZ2wsIGRlc2MsIGJ1ZmZlcnMpIHtcbiAgICAgICAgaWYgKCFkZXNjLmJ1ZmZlclZpZXdzKSByZXR1cm4gbnVsbDtcbiAgICAgICAgY29uc3QgYnVmZmVyVmlld3MgPSBkZXNjLmJ1ZmZlclZpZXdzO1xuXG4gICAgICAgIGRlc2MubWVzaGVzICYmXG4gICAgICAgICAgICBkZXNjLm1lc2hlcy5mb3JFYWNoKCh7IHByaW1pdGl2ZXMgfSkgPT4ge1xuICAgICAgICAgICAgICAgIHByaW1pdGl2ZXMuZm9yRWFjaCgoeyBhdHRyaWJ1dGVzLCBpbmRpY2VzLCBleHRlbnNpb25zIH0pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgLy8gRmxhZyBidWZmZXJWaWV3IGFzIGFuIGF0dHJpYnV0ZSwgc28gaXQga25vd3MgdG8gY3JlYXRlIGEgZ2wgYnVmZmVyXG4gICAgICAgICAgICAgICAgICAgIGZvciAoY29uc3QgYXR0ciBpbiBhdHRyaWJ1dGVzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBhY2Nlc3NvciA9IGRlc2MuYWNjZXNzb3JzW2F0dHJpYnV0ZXNbYXR0cl1dO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGFjY2Vzc29yLmJ1ZmZlclZpZXcgPT09IHVuZGVmaW5lZCAmJiAhIWV4dGVuc2lvbnMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBEcmFjbyBleHRlbnNpb24gYnVmZmVyIHZpZXdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXh0ZW5zaW9ucy5LSFJfZHJhY29fbWVzaF9jb21wcmVzc2lvbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3Nvci5idWZmZXJWaWV3ID0gZXh0ZW5zaW9ucy5LSFJfZHJhY29fbWVzaF9jb21wcmVzc2lvbi5idWZmZXJWaWV3O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWZmZXJWaWV3c1thY2Nlc3Nvci5idWZmZXJWaWV3XS5pc0RyYWNvID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBidWZmZXJWaWV3c1thY2Nlc3Nvci5idWZmZXJWaWV3XS5pc0F0dHJpYnV0ZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBpZiAoaW5kaWNlcyAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBhY2Nlc3NvciA9IGRlc2MuYWNjZXNzb3JzW2luZGljZXNdO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGFjY2Vzc29yLmJ1ZmZlclZpZXcgPT09IHVuZGVmaW5lZCAmJiAhIWV4dGVuc2lvbnMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBEcmFjbyBleHRlbnNpb24gYnVmZmVyIHZpZXdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXh0ZW5zaW9ucy5LSFJfZHJhY29fbWVzaF9jb21wcmVzc2lvbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3Nvci5idWZmZXJWaWV3ID0gZXh0ZW5zaW9ucy5LSFJfZHJhY29fbWVzaF9jb21wcmVzc2lvbi5idWZmZXJWaWV3O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWZmZXJWaWV3c1thY2Nlc3Nvci5idWZmZXJWaWV3XS5pc0RyYWNvID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBidWZmZXJWaWV3c1thY2Nlc3Nvci5idWZmZXJWaWV3XS5pc0F0dHJpYnV0ZSA9IHRydWU7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIE1ha2Ugc3VyZSBpbmRpY2VzIGJ1ZmZlclZpZXcgaGF2ZSBhIHRhcmdldCBwcm9wZXJ0eSBmb3IgZ2wgYnVmZmVyIGJpbmRpbmdcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1ZmZlclZpZXdzW2FjY2Vzc29yLmJ1ZmZlclZpZXddLnRhcmdldCA9IGdsLkVMRU1FTlRfQVJSQVlfQlVGRkVSO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAvLyBHZXQgY29tcG9uZW50VHlwZSBvZiBlYWNoIGJ1ZmZlclZpZXcgZnJvbSB0aGUgYWNjZXNzb3JzXG4gICAgICAgIGRlc2MuYWNjZXNzb3JzLmZvckVhY2goKHsgYnVmZmVyVmlldzogYnVmZmVyVmlld0luZGV4LCBjb21wb25lbnRUeXBlIH0pID0+IHtcbiAgICAgICAgICAgIGlmIChidWZmZXJWaWV3SW5kZXggPT09IHVuZGVmaW5lZCkgcmV0dXJuO1xuICAgICAgICAgICAgYnVmZmVyVmlld3NbYnVmZmVyVmlld0luZGV4XS5jb21wb25lbnRUeXBlID0gY29tcG9uZW50VHlwZTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gR2V0IG1pbWV0eXBlIG9mIGJ1ZmZlclZpZXcgZnJvbSBpbWFnZXNcbiAgICAgICAgZGVzYy5pbWFnZXMgJiZcbiAgICAgICAgICAgIGRlc2MuaW1hZ2VzLmZvckVhY2goKHsgdXJpLCBidWZmZXJWaWV3OiBidWZmZXJWaWV3SW5kZXgsIG1pbWVUeXBlIH0pID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoYnVmZmVyVmlld0luZGV4ID09PSB1bmRlZmluZWQpIHJldHVybjtcbiAgICAgICAgICAgICAgICBidWZmZXJWaWV3c1tidWZmZXJWaWV3SW5kZXhdLm1pbWVUeXBlID0gbWltZVR5cGU7XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAvLyBQdXNoIGVhY2ggYnVmZmVyVmlldyB0byB0aGUgR1BVIGFzIGEgc2VwYXJhdGUgYnVmZmVyXG4gICAgICAgIGJ1ZmZlclZpZXdzLmZvckVhY2goXG4gICAgICAgICAgICAoXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBidWZmZXI6IGJ1ZmZlckluZGV4LCAvLyByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICBieXRlT2Zmc2V0ID0gMCwgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgICAgICAgICAgYnl0ZUxlbmd0aCwgLy8gcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgYnl0ZVN0cmlkZSwgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgICAgICAgICAgdGFyZ2V0ID0gZ2wuQVJSQVlfQlVGRkVSLCAvLyBvcHRpb25hbCwgYWRkZWQgYWJvdmUgZm9yIGVsZW1lbnRzXG4gICAgICAgICAgICAgICAgICAgIG5hbWUsIC8vIG9wdGlvbmFsXG4gICAgICAgICAgICAgICAgICAgIGV4dGVuc2lvbnMsIC8vIG9wdGlvbmFsXG4gICAgICAgICAgICAgICAgICAgIGV4dHJhcywgLy8gb3B0aW9uYWxcblxuICAgICAgICAgICAgICAgICAgICBjb21wb25lbnRUeXBlLCAvLyBvcHRpb25hbCwgYWRkZWQgZnJvbSBhY2Nlc3NvciBhYm92ZVxuICAgICAgICAgICAgICAgICAgICBtaW1lVHlwZSwgLy8gb3B0aW9uYWwsIGFkZGVkIGZyb20gaW1hZ2VzIGFib3ZlXG4gICAgICAgICAgICAgICAgICAgIGlzQXR0cmlidXRlLFxuICAgICAgICAgICAgICAgICAgICBpc0RyYWNvLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgaVxuICAgICAgICAgICAgKSA9PiB7XG4gICAgICAgICAgICAgICAgYnVmZmVyVmlld3NbaV0uZGF0YSA9IGJ1ZmZlcnNbYnVmZmVySW5kZXhdLnNsaWNlKGJ5dGVPZmZzZXQsIGJ5dGVPZmZzZXQgKyBieXRlTGVuZ3RoKTtcblxuICAgICAgICAgICAgICAgIGlmICghaXNBdHRyaWJ1dGUgfHwgaXNEcmFjbykgcmV0dXJuO1xuICAgICAgICAgICAgICAgIC8vIENyZWF0ZSBnbCBidWZmZXJzIGZvciB0aGUgYnVmZmVyVmlldywgcHVzaGluZyBpdCB0byB0aGUgR1BVXG4gICAgICAgICAgICAgICAgY29uc3QgYnVmZmVyID0gZ2wuY3JlYXRlQnVmZmVyKCk7XG4gICAgICAgICAgICAgICAgZ2wuYmluZEJ1ZmZlcih0YXJnZXQsIGJ1ZmZlcik7XG4gICAgICAgICAgICAgICAgZ2wucmVuZGVyZXIuc3RhdGUuYm91bmRCdWZmZXIgPSBidWZmZXI7XG4gICAgICAgICAgICAgICAgZ2wuYnVmZmVyRGF0YSh0YXJnZXQsIGJ1ZmZlclZpZXdzW2ldLmRhdGEsIGdsLlNUQVRJQ19EUkFXKTtcbiAgICAgICAgICAgICAgICBidWZmZXJWaWV3c1tpXS5idWZmZXIgPSBidWZmZXI7XG4gICAgICAgICAgICB9XG4gICAgICAgICk7XG5cbiAgICAgICAgcmV0dXJuIGJ1ZmZlclZpZXdzO1xuICAgIH1cblxuICAgIHN0YXRpYyBwYXJzZUltYWdlcyhnbCwgZGVzYywgZGlyLCBidWZmZXJWaWV3cykge1xuICAgICAgICBpZiAoIWRlc2MuaW1hZ2VzKSByZXR1cm4gbnVsbDtcbiAgICAgICAgcmV0dXJuIFByb21pc2UuYWxsKFxuICAgICAgICAgICAgZGVzYy5pbWFnZXMubWFwKGFzeW5jICh7IHVyaSwgYnVmZmVyVmlldzogYnVmZmVyVmlld0luZGV4LCBtaW1lVHlwZSwgbmFtZSB9KSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKG1pbWVUeXBlID09PSAnaW1hZ2Uva3R4MicpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgeyBkYXRhIH0gPSBidWZmZXJWaWV3c1tidWZmZXJWaWV3SW5kZXhdO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBpbWFnZSA9IGF3YWl0IHRoaXMuYmFzaXNNYW5hZ2VyLnBhcnNlVGV4dHVyZShkYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGltYWdlO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vIGpwZyAvIHBuZyAvIHdlYnBcbiAgICAgICAgICAgICAgICBjb25zdCBpbWFnZSA9IG5ldyBJbWFnZSgpO1xuICAgICAgICAgICAgICAgIGltYWdlLm5hbWUgPSBuYW1lO1xuICAgICAgICAgICAgICAgIGlmICh1cmkpIHtcbiAgICAgICAgICAgICAgICAgICAgaW1hZ2Uuc3JjID0gdGhpcy5yZXNvbHZlVVJJKHVyaSwgZGlyKTtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGJ1ZmZlclZpZXdJbmRleCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYnVmZmVyVmlld3NbYnVmZmVyVmlld0luZGV4XTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFtkYXRhXSwgeyB0eXBlOiBtaW1lVHlwZSB9KTtcbiAgICAgICAgICAgICAgICAgICAgaW1hZ2Uuc3JjID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaW1hZ2UucmVhZHkgPSBuZXcgUHJvbWlzZSgocmVzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGltYWdlLm9ubG9hZCA9ICgpID0+IHJlcygpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHJldHVybiBpbWFnZTtcbiAgICAgICAgICAgIH0pXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgc3RhdGljIHBhcnNlVGV4dHVyZXMoZ2wsIGRlc2MsIGltYWdlcykge1xuICAgICAgICBpZiAoIWRlc2MudGV4dHVyZXMpIHJldHVybiBudWxsO1xuICAgICAgICByZXR1cm4gZGVzYy50ZXh0dXJlcy5tYXAoKHRleHR1cmVJbmZvKSA9PiB0aGlzLmNyZWF0ZVRleHR1cmUoZ2wsIGRlc2MsIGltYWdlcywgdGV4dHVyZUluZm8pKTtcbiAgICB9XG5cbiAgICBzdGF0aWMgY3JlYXRlVGV4dHVyZShnbCwgZGVzYywgaW1hZ2VzLCB7IHNhbXBsZXI6IHNhbXBsZXJJbmRleCwgc291cmNlOiBzb3VyY2VJbmRleCwgbmFtZSwgZXh0ZW5zaW9ucywgZXh0cmFzIH0pIHtcbiAgICAgICAgaWYgKHNvdXJjZUluZGV4ID09PSB1bmRlZmluZWQgJiYgISFleHRlbnNpb25zKSB7XG4gICAgICAgICAgICAvLyBXZWJQIGV4dGVuc2lvbiBzb3VyY2UgaW5kZXhcbiAgICAgICAgICAgIGlmIChleHRlbnNpb25zLkVYVF90ZXh0dXJlX3dlYnApIHNvdXJjZUluZGV4ID0gZXh0ZW5zaW9ucy5FWFRfdGV4dHVyZV93ZWJwLnNvdXJjZTtcblxuICAgICAgICAgICAgLy8gQmFzaXMgZXh0ZW5zaW9uIHNvdXJjZSBpbmRleFxuICAgICAgICAgICAgaWYgKGV4dGVuc2lvbnMuS0hSX3RleHR1cmVfYmFzaXN1KSBzb3VyY2VJbmRleCA9IGV4dGVuc2lvbnMuS0hSX3RleHR1cmVfYmFzaXN1LnNvdXJjZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGltYWdlID0gaW1hZ2VzW3NvdXJjZUluZGV4XTtcbiAgICAgICAgaWYgKGltYWdlLnRleHR1cmUpIHJldHVybiBpbWFnZS50ZXh0dXJlO1xuXG4gICAgICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICAgICAgICBmbGlwWTogZmFsc2UsXG4gICAgICAgICAgICB3cmFwUzogZ2wuUkVQRUFULCAvLyBSZXBlYXQgYnkgZGVmYXVsdCwgb3Bwb3NlZCB0byBPR0wncyBjbGFtcCBieSBkZWZhdWx0XG4gICAgICAgICAgICB3cmFwVDogZ2wuUkVQRUFULFxuICAgICAgICB9O1xuICAgICAgICBjb25zdCBzYW1wbGVyID0gc2FtcGxlckluZGV4ICE9PSB1bmRlZmluZWQgPyBkZXNjLnNhbXBsZXJzW3NhbXBsZXJJbmRleF0gOiBudWxsO1xuICAgICAgICBpZiAoc2FtcGxlcikge1xuICAgICAgICAgICAgWydtYWdGaWx0ZXInLCAnbWluRmlsdGVyJywgJ3dyYXBTJywgJ3dyYXBUJ10uZm9yRWFjaCgocHJvcCkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChzYW1wbGVyW3Byb3BdKSBvcHRpb25zW3Byb3BdID0gc2FtcGxlcltwcm9wXTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gRm9yIGNvbXByZXNzZWQgdGV4dHVyZXNcbiAgICAgICAgaWYgKGltYWdlLmlzQmFzaXMpIHtcbiAgICAgICAgICAgIG9wdGlvbnMuaW1hZ2UgPSBpbWFnZTtcbiAgICAgICAgICAgIG9wdGlvbnMuaW50ZXJuYWxGb3JtYXQgPSBpbWFnZS5pbnRlcm5hbEZvcm1hdDtcbiAgICAgICAgICAgIGlmIChpbWFnZS5pc0NvbXByZXNzZWRUZXh0dXJlKSB7XG4gICAgICAgICAgICAgICAgb3B0aW9ucy5nZW5lcmF0ZU1pcG1hcHMgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICBpZiAoaW1hZ2UubGVuZ3RoID4gMSkgdGhpcy5taW5GaWx0ZXIgPSBnbC5ORUFSRVNUX01JUE1BUF9MSU5FQVI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCB0ZXh0dXJlID0gbmV3IFRleHR1cmUoZ2wsIG9wdGlvbnMpO1xuICAgICAgICAgICAgdGV4dHVyZS5uYW1lID0gbmFtZTtcbiAgICAgICAgICAgIGltYWdlLnRleHR1cmUgPSB0ZXh0dXJlO1xuICAgICAgICAgICAgcmV0dXJuIHRleHR1cmU7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB0ZXh0dXJlID0gbmV3IFRleHR1cmUoZ2wsIG9wdGlvbnMpO1xuICAgICAgICB0ZXh0dXJlLm5hbWUgPSBuYW1lO1xuICAgICAgICBpbWFnZS50ZXh0dXJlID0gdGV4dHVyZTtcbiAgICAgICAgaW1hZ2UucmVhZHkudGhlbigoKSA9PiB7XG4gICAgICAgICAgICB0ZXh0dXJlLmltYWdlID0gaW1hZ2U7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHJldHVybiB0ZXh0dXJlO1xuICAgIH1cblxuICAgIHN0YXRpYyBwYXJzZU1hdGVyaWFscyhnbCwgZGVzYywgdGV4dHVyZXMpIHtcbiAgICAgICAgaWYgKCFkZXNjLm1hdGVyaWFscykgcmV0dXJuIG51bGw7XG4gICAgICAgIHJldHVybiBkZXNjLm1hdGVyaWFscy5tYXAoXG4gICAgICAgICAgICAoe1xuICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICAgICAgZXh0ZW5zaW9ucyxcbiAgICAgICAgICAgICAgICBleHRyYXMsXG4gICAgICAgICAgICAgICAgcGJyTWV0YWxsaWNSb3VnaG5lc3MgPSB7fSxcbiAgICAgICAgICAgICAgICBub3JtYWxUZXh0dXJlLFxuICAgICAgICAgICAgICAgIG9jY2x1c2lvblRleHR1cmUsXG4gICAgICAgICAgICAgICAgZW1pc3NpdmVUZXh0dXJlLFxuICAgICAgICAgICAgICAgIGVtaXNzaXZlRmFjdG9yID0gWzAsIDAsIDBdLFxuICAgICAgICAgICAgICAgIGFscGhhTW9kZSA9ICdPUEFRVUUnLFxuICAgICAgICAgICAgICAgIGFscGhhQ3V0b2ZmID0gMC41LFxuICAgICAgICAgICAgICAgIGRvdWJsZVNpZGVkID0gZmFsc2UsXG4gICAgICAgICAgICB9KSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3Qge1xuICAgICAgICAgICAgICAgICAgICBiYXNlQ29sb3JGYWN0b3IgPSBbMSwgMSwgMSwgMV0sXG4gICAgICAgICAgICAgICAgICAgIGJhc2VDb2xvclRleHR1cmUsXG4gICAgICAgICAgICAgICAgICAgIG1ldGFsbGljRmFjdG9yID0gMSxcbiAgICAgICAgICAgICAgICAgICAgcm91Z2huZXNzRmFjdG9yID0gMSxcbiAgICAgICAgICAgICAgICAgICAgbWV0YWxsaWNSb3VnaG5lc3NUZXh0dXJlLFxuICAgICAgICAgICAgICAgICAgICAvLyAgIGV4dGVuc2lvbnMsXG4gICAgICAgICAgICAgICAgICAgIC8vICAgZXh0cmFzLFxuICAgICAgICAgICAgICAgIH0gPSBwYnJNZXRhbGxpY1JvdWdobmVzcztcblxuICAgICAgICAgICAgICAgIGlmIChiYXNlQ29sb3JUZXh0dXJlKSB7XG4gICAgICAgICAgICAgICAgICAgIGJhc2VDb2xvclRleHR1cmUudGV4dHVyZSA9IHRleHR1cmVzW2Jhc2VDb2xvclRleHR1cmUuaW5kZXhdO1xuICAgICAgICAgICAgICAgICAgICAvLyB0ZXhDb29yZFxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAobm9ybWFsVGV4dHVyZSkge1xuICAgICAgICAgICAgICAgICAgICBub3JtYWxUZXh0dXJlLnRleHR1cmUgPSB0ZXh0dXJlc1tub3JtYWxUZXh0dXJlLmluZGV4XTtcbiAgICAgICAgICAgICAgICAgICAgLy8gc2NhbGU6IDFcbiAgICAgICAgICAgICAgICAgICAgLy8gdGV4Q29vcmRcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKG1ldGFsbGljUm91Z2huZXNzVGV4dHVyZSkge1xuICAgICAgICAgICAgICAgICAgICBtZXRhbGxpY1JvdWdobmVzc1RleHR1cmUudGV4dHVyZSA9IHRleHR1cmVzW21ldGFsbGljUm91Z2huZXNzVGV4dHVyZS5pbmRleF07XG4gICAgICAgICAgICAgICAgICAgIC8vIHRleENvb3JkXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChvY2NsdXNpb25UZXh0dXJlKSB7XG4gICAgICAgICAgICAgICAgICAgIG9jY2x1c2lvblRleHR1cmUudGV4dHVyZSA9IHRleHR1cmVzW29jY2x1c2lvblRleHR1cmUuaW5kZXhdO1xuICAgICAgICAgICAgICAgICAgICAvLyBzdHJlbmd0aCAxXG4gICAgICAgICAgICAgICAgICAgIC8vIHRleENvb3JkXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChlbWlzc2l2ZVRleHR1cmUpIHtcbiAgICAgICAgICAgICAgICAgICAgZW1pc3NpdmVUZXh0dXJlLnRleHR1cmUgPSB0ZXh0dXJlc1tlbWlzc2l2ZVRleHR1cmUuaW5kZXhdO1xuICAgICAgICAgICAgICAgICAgICAvLyB0ZXhDb29yZFxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICAgICAgICAgIGV4dGVuc2lvbnMsXG4gICAgICAgICAgICAgICAgICAgIGV4dHJhcyxcbiAgICAgICAgICAgICAgICAgICAgYmFzZUNvbG9yRmFjdG9yLFxuICAgICAgICAgICAgICAgICAgICBiYXNlQ29sb3JUZXh0dXJlLFxuICAgICAgICAgICAgICAgICAgICBtZXRhbGxpY0ZhY3RvcixcbiAgICAgICAgICAgICAgICAgICAgcm91Z2huZXNzRmFjdG9yLFxuICAgICAgICAgICAgICAgICAgICBtZXRhbGxpY1JvdWdobmVzc1RleHR1cmUsXG4gICAgICAgICAgICAgICAgICAgIG5vcm1hbFRleHR1cmUsXG4gICAgICAgICAgICAgICAgICAgIG9jY2x1c2lvblRleHR1cmUsXG4gICAgICAgICAgICAgICAgICAgIGVtaXNzaXZlVGV4dHVyZSxcbiAgICAgICAgICAgICAgICAgICAgZW1pc3NpdmVGYWN0b3IsXG4gICAgICAgICAgICAgICAgICAgIGFscGhhTW9kZSxcbiAgICAgICAgICAgICAgICAgICAgYWxwaGFDdXRvZmYsXG4gICAgICAgICAgICAgICAgICAgIGRvdWJsZVNpZGVkLFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9XG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgc3RhdGljIHBhcnNlU2tpbnMoZ2wsIGRlc2MsIGJ1ZmZlclZpZXdzKSB7XG4gICAgICAgIGlmICghZGVzYy5za2lucykgcmV0dXJuIG51bGw7XG4gICAgICAgIHJldHVybiBkZXNjLnNraW5zLm1hcChcbiAgICAgICAgICAgICh7XG4gICAgICAgICAgICAgICAgaW52ZXJzZUJpbmRNYXRyaWNlcywgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgICAgICBza2VsZXRvbiwgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgICAgICBqb2ludHMsIC8vIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgLy8gbmFtZSxcbiAgICAgICAgICAgICAgICAvLyBleHRlbnNpb25zLFxuICAgICAgICAgICAgICAgIC8vIGV4dHJhcyxcbiAgICAgICAgICAgIH0pID0+IHtcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICBpbnZlcnNlQmluZE1hdHJpY2VzOiB0aGlzLnBhcnNlQWNjZXNzb3IoaW52ZXJzZUJpbmRNYXRyaWNlcywgZGVzYywgYnVmZmVyVmlld3MpLFxuICAgICAgICAgICAgICAgICAgICBza2VsZXRvbixcbiAgICAgICAgICAgICAgICAgICAgam9pbnRzLFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9XG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgc3RhdGljIHBhcnNlTWVzaGVzKGdsLCBkZXNjLCBidWZmZXJWaWV3cywgbWF0ZXJpYWxzLCBza2lucykge1xuICAgICAgICBpZiAoIWRlc2MubWVzaGVzKSByZXR1cm4gbnVsbDtcbiAgICAgICAgcmV0dXJuIFByb21pc2UuYWxsKFxuICAgICAgICAgICAgZGVzYy5tZXNoZXMubWFwKFxuICAgICAgICAgICAgICAgIGFzeW5jIChcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgcHJpbWl0aXZlcywgLy8gcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgICAgIHdlaWdodHMsIC8vIG9wdGlvbmFsXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lLCAvLyBvcHRpb25hbFxuICAgICAgICAgICAgICAgICAgICAgICAgZXh0ZW5zaW9ucywgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4dHJhcyA9IHt9LCAvLyBvcHRpb25hbCAtIHdpbGwgZ2V0IG1lcmdlZCB3aXRoIG5vZGUgZXh0cmFzXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIG1lc2hJbmRleFxuICAgICAgICAgICAgICAgICkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAvLyBUT0RPOiB3ZWlnaHRzIHN0dWZmP1xuICAgICAgICAgICAgICAgICAgICAvLyBQYXJzZSB0aHJvdWdoIG5vZGVzIHRvIHNlZSBob3cgbWFueSBpbnN0YW5jZXMgdGhlcmUgYXJlIGFuZCBpZiB0aGVyZSBpcyBhIHNraW4gYXR0YWNoZWRcbiAgICAgICAgICAgICAgICAgICAgLy8gSWYgbXVsdGlwbGUgaW5zdGFuY2VzIG9mIGEgc2tpbiwgbmVlZCB0byBjcmVhdGUgZWFjaFxuICAgICAgICAgICAgICAgICAgICBsZXQgbnVtSW5zdGFuY2VzID0gMDtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHNraW5JbmRpY2VzID0gW107XG4gICAgICAgICAgICAgICAgICAgIGxldCBpc0xpZ2h0bWFwID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgIGRlc2Mubm9kZXMgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlc2Mubm9kZXMuZm9yRWFjaCgoeyBtZXNoLCBza2luLCBleHRyYXMgfSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChtZXNoID09PSBtZXNoSW5kZXgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbnVtSW5zdGFuY2VzKys7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChza2luICE9PSB1bmRlZmluZWQpIHNraW5JbmRpY2VzLnB1c2goc2tpbik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChleHRyYXMgJiYgZXh0cmFzLmxpZ2h0bWFwX3NjYWxlX29mZnNldCkgaXNMaWdodG1hcCA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBpc1NraW4gPSAhIXNraW5JbmRpY2VzLmxlbmd0aDtcblxuICAgICAgICAgICAgICAgICAgICAvLyBGb3Igc2tpbnMsIHJldHVybiBhcnJheSBvZiBza2luIG1lc2hlcyB0byBhY2NvdW50IGZvciBtdWx0aXBsZSBpbnN0YW5jZXNcbiAgICAgICAgICAgICAgICAgICAgaWYgKGlzU2tpbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgcHJpbWl0aXZlcyA9IGF3YWl0IFByb21pc2UuYWxsKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNraW5JbmRpY2VzLm1hcChhc3luYyAoc2tpbkluZGV4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoYXdhaXQgdGhpcy5wYXJzZVByaW1pdGl2ZXMoZ2wsIHByaW1pdGl2ZXMsIGRlc2MsIGJ1ZmZlclZpZXdzLCBtYXRlcmlhbHMsIDEsIGlzTGlnaHRtYXApKS5tYXAoKHsgZ2VvbWV0cnksIHByb2dyYW0sIG1vZGUgfSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbWVzaCA9IG5ldyBHTFRGU2tpbihnbCwgeyBza2VsZXRvbjogc2tpbnNbc2tpbkluZGV4XSwgZ2VvbWV0cnksIHByb2dyYW0sIG1vZGUgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNoLm5hbWUgPSBuYW1lO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzaC5leHRyYXMgPSBleHRyYXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXh0ZW5zaW9ucykgbWVzaC5leHRlbnNpb25zID0gZXh0ZW5zaW9ucztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFRPRE86IHN1cHBvcnQgc2tpbiBmcnVzdHVtIGN1bGxpbmdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc2guZnJ1c3R1bUN1bGxlZCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG1lc2g7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gRm9yIHJldHJpZXZhbCB0byBhZGQgdG8gbm9kZVxuICAgICAgICAgICAgICAgICAgICAgICAgcHJpbWl0aXZlcy5pbnN0YW5jZUNvdW50ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHByaW1pdGl2ZXMubnVtSW5zdGFuY2VzID0gbnVtSW5zdGFuY2VzO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgcHJpbWl0aXZlcyA9IChhd2FpdCB0aGlzLnBhcnNlUHJpbWl0aXZlcyhnbCwgcHJpbWl0aXZlcywgZGVzYywgYnVmZmVyVmlld3MsIG1hdGVyaWFscywgbnVtSW5zdGFuY2VzLCBpc0xpZ2h0bWFwKSkubWFwKCh7IGdlb21ldHJ5LCBwcm9ncmFtLCBtb2RlIH0pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBJbnN0YW5jZWRNZXNoIGNsYXNzIGhhcyBjdXN0b20gZnJ1c3R1bSBjdWxsaW5nIGZvciBpbnN0YW5jZXNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBtZXNoQ29uc3RydWN0b3IgPSBnZW9tZXRyeS5hdHRyaWJ1dGVzLmluc3RhbmNlTWF0cml4ID8gSW5zdGFuY2VkTWVzaCA6IE1lc2g7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbWVzaCA9IG5ldyBtZXNoQ29uc3RydWN0b3IoZ2wsIHsgZ2VvbWV0cnksIHByb2dyYW0sIG1vZGUgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzaC5uYW1lID0gbmFtZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNoLmV4dHJhcyA9IGV4dHJhcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXh0ZW5zaW9ucykgbWVzaC5leHRlbnNpb25zID0gZXh0ZW5zaW9ucztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBUYWcgbWVzaCBzbyB0aGF0IG5vZGVzIGNhbiBhZGQgdGhlaXIgdHJhbnNmb3JtcyB0byB0aGUgaW5zdGFuY2UgYXR0cmlidXRlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzaC5udW1JbnN0YW5jZXMgPSBudW1JbnN0YW5jZXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG1lc2g7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBwcmltaXRpdmVzLFxuICAgICAgICAgICAgICAgICAgICAgICAgd2VpZ2h0cyxcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgKVxuICAgICAgICApO1xuICAgIH1cblxuICAgIHN0YXRpYyBwYXJzZVByaW1pdGl2ZXMoZ2wsIHByaW1pdGl2ZXMsIGRlc2MsIGJ1ZmZlclZpZXdzLCBtYXRlcmlhbHMsIG51bUluc3RhbmNlcywgaXNMaWdodG1hcCkge1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5hbGwoXG4gICAgICAgICAgICBwcmltaXRpdmVzLm1hcChcbiAgICAgICAgICAgICAgICBhc3luYyAoe1xuICAgICAgICAgICAgICAgICAgICBhdHRyaWJ1dGVzLCAvLyByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICBpbmRpY2VzLCAvLyBvcHRpb25hbFxuICAgICAgICAgICAgICAgICAgICBtYXRlcmlhbDogbWF0ZXJpYWxJbmRleCwgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgICAgICAgICAgbW9kZSA9IDQsIC8vIG9wdGlvbmFsXG4gICAgICAgICAgICAgICAgICAgIHRhcmdldHMsIC8vIG9wdGlvbmFsXG4gICAgICAgICAgICAgICAgICAgIGV4dGVuc2lvbnMsIC8vIG9wdGlvbmFsXG4gICAgICAgICAgICAgICAgICAgIGV4dHJhcywgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgICAgICB9KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIC8vIFRPRE86IG1hdGVyaWFsc1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwcm9ncmFtID0gbmV3IE5vcm1hbFByb2dyYW0oZ2wpO1xuICAgICAgICAgICAgICAgICAgICBpZiAobWF0ZXJpYWxJbmRleCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBwcm9ncmFtLmdsdGZNYXRlcmlhbCA9IG1hdGVyaWFsc1ttYXRlcmlhbEluZGV4XTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGdlb21ldHJ5ID0gbmV3IEdlb21ldHJ5KGdsKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGV4dHJhcykgZ2VvbWV0cnkuZXh0cmFzID0gZXh0cmFzO1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXh0ZW5zaW9ucykgZ2VvbWV0cnkuZXh0ZW5zaW9ucyA9IGV4dGVuc2lvbnM7XG5cbiAgICAgICAgICAgICAgICAgICAgLy8gRm9yIGNvbXByZXNzZWQgZ2VvbWV0cnkgZGF0YVxuICAgICAgICAgICAgICAgICAgICBpZiAoZXh0ZW5zaW9ucyAmJiBleHRlbnNpb25zLktIUl9kcmFjb19tZXNoX2NvbXByZXNzaW9uKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBidWZmZXJWaWV3SW5kZXggPSBleHRlbnNpb25zLktIUl9kcmFjb19tZXNoX2NvbXByZXNzaW9uLmJ1ZmZlclZpZXc7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBnbHRmQXR0cmlidXRlTWFwID0gZXh0ZW5zaW9ucy5LSFJfZHJhY29fbWVzaF9jb21wcmVzc2lvbi5hdHRyaWJ1dGVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYXR0cmlidXRlTWFwID0ge307XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBhdHRyaWJ1dGVUeXBlTWFwID0ge307XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBhdHRyaWJ1dGVUeXBlTmFtZU1hcCA9IHt9O1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYXR0cmlidXRlTm9ybWFsaXplZE1hcCA9IHt9O1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGF0dHIgaW4gYXR0cmlidXRlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGFjY2Vzc29yID0gZGVzYy5hY2Nlc3NvcnNbYXR0cmlidXRlc1thdHRyXV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYXR0cmlidXRlTmFtZSA9IEFUVFJJQlVURVNbYXR0cl07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXR0cmlidXRlTWFwW2F0dHJpYnV0ZU5hbWVdID0gZ2x0ZkF0dHJpYnV0ZU1hcFthdHRyXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyaWJ1dGVUeXBlTWFwW2F0dHJpYnV0ZU5hbWVdID0gYWNjZXNzb3IuY29tcG9uZW50VHlwZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyaWJ1dGVUeXBlTmFtZU1hcFthdHRyaWJ1dGVOYW1lXSA9IFRZUEVfQVJSQVlbYWNjZXNzb3IuY29tcG9uZW50VHlwZV0ubmFtZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdHRyaWJ1dGVOb3JtYWxpemVkTWFwW2F0dHJpYnV0ZU5hbWVdID0gYWNjZXNzb3Iubm9ybWFsaXplZCA9PT0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgeyBkYXRhIH0gPSBidWZmZXJWaWV3c1tidWZmZXJWaWV3SW5kZXhdO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZ2VvbWV0cnlEYXRhID0gYXdhaXQgdGhpcy5kcmFjb01hbmFnZXIuZGVjb2RlR2VvbWV0cnkoZGF0YSwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJpYnV0ZUlkczogYXR0cmlidXRlTWFwLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJpYnV0ZVR5cGVzOiBhdHRyaWJ1dGVUeXBlTmFtZU1hcCxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBBZGQgZWFjaCBhdHRyaWJ1dGUgcmVzdWx0XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGdlb21ldHJ5RGF0YS5hdHRyaWJ1dGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gZ2VvbWV0cnlEYXRhLmF0dHJpYnV0ZXNbaV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbmFtZSA9IHJlc3VsdC5uYW1lO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGRhdGEgPSByZXN1bHQuYXJyYXk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc2l6ZSA9IHJlc3VsdC5pdGVtU2l6ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB0eXBlID0gYXR0cmlidXRlVHlwZU1hcFtuYW1lXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBub3JtYWxpemVkID0gYXR0cmlidXRlTm9ybWFsaXplZE1hcFtuYW1lXTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIENyZWF0ZSBnbCBidWZmZXJzIGZvciB0aGUgYXR0cmlidXRlIGRhdGEsIHB1c2hpbmcgaXQgdG8gdGhlIEdQVVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGJ1ZmZlciA9IGdsLmNyZWF0ZUJ1ZmZlcigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdsLmJpbmRCdWZmZXIoZ2wuQVJSQVlfQlVGRkVSLCBidWZmZXIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdsLnJlbmRlcmVyLnN0YXRlLmJvdW5kQnVmZmVyID0gYnVmZmVyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdsLmJ1ZmZlckRhdGEoZ2wuQVJSQVlfQlVGRkVSLCBkYXRhLCBnbC5TVEFUSUNfRFJBVyk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBnZW9tZXRyeS5hZGRBdHRyaWJ1dGUobmFtZSwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBub3JtYWxpemVkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWZmZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIEFkZCBpbmRleCBhdHRyaWJ1dGUgaWYgZm91bmRcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChnZW9tZXRyeURhdGEuaW5kZXgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBkYXRhID0gZ2VvbWV0cnlEYXRhLmluZGV4LmFycmF5O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHNpemUgPSBnZW9tZXRyeURhdGEuaW5kZXguaXRlbVNpemU7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBDcmVhdGUgZ2wgYnVmZmVycyBmb3IgdGhlIGluZGV4IGF0dHJpYnV0ZSBkYXRhLCBwdXNoaW5nIGl0IHRvIHRoZSBHUFVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBidWZmZXIgPSBnbC5jcmVhdGVCdWZmZXIoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBnbC5iaW5kQnVmZmVyKGdsLkVMRU1FTlRfQVJSQVlfQlVGRkVSLCBidWZmZXIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdsLnJlbmRlcmVyLnN0YXRlLmJvdW5kQnVmZmVyID0gYnVmZmVyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdsLmJ1ZmZlckRhdGEoZ2wuRUxFTUVOVF9BUlJBWV9CVUZGRVIsIGRhdGEsIGdsLlNUQVRJQ19EUkFXKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdlb21ldHJ5LmFkZEF0dHJpYnV0ZSgnaW5kZXgnLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IDUxMjUsIC8vIFVpbnQzMkFycmF5XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5vcm1hbGl6ZWQ6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWZmZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBBZGQgZWFjaCBhdHRyaWJ1dGUgZm91bmQgaW4gcHJpbWl0aXZlXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGF0dHIgaW4gYXR0cmlidXRlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdlb21ldHJ5LmFkZEF0dHJpYnV0ZShBVFRSSUJVVEVTW2F0dHJdLCB0aGlzLnBhcnNlQWNjZXNzb3IoYXR0cmlidXRlc1thdHRyXSwgZGVzYywgYnVmZmVyVmlld3MpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gQWRkIGluZGV4IGF0dHJpYnV0ZSBpZiBmb3VuZFxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGluZGljZXMgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdlb21ldHJ5LmFkZEF0dHJpYnV0ZSgnaW5kZXgnLCB0aGlzLnBhcnNlQWNjZXNzb3IoaW5kaWNlcywgZGVzYywgYnVmZmVyVmlld3MpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIC8vIEFkZCBpbnN0YW5jZWQgdHJhbnNmb3JtIGF0dHJpYnV0ZSBpZiBtdWx0aXBsZSBpbnN0YW5jZXNcbiAgICAgICAgICAgICAgICAgICAgLy8gSWdub3JlIGlmIHNraW4gYXMgd2UgZG9uJ3Qgc3VwcG9ydCBpbnN0YW5jZWQgc2tpbnMgb3V0IG9mIHRoZSBib3hcbiAgICAgICAgICAgICAgICAgICAgaWYgKG51bUluc3RhbmNlcyA+IDEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGdlb21ldHJ5LmFkZEF0dHJpYnV0ZSgnaW5zdGFuY2VNYXRyaXgnLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5zdGFuY2VkOiAxLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU6IDE2LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE6IG5ldyBGbG9hdDMyQXJyYXkobnVtSW5zdGFuY2VzICogMTYpLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAvLyBBbHdheXMgc3VwcGx5IGxpZ2h0bWFwU2NhbGVPZmZzZXQgYXMgYW4gaW5zdGFuY2VkIGF0dHJpYnV0ZVxuICAgICAgICAgICAgICAgICAgICAvLyBJbnN0YW5jZWQgc2tpbiBsaWdodG1hcHMgbm90IHN1cHBvcnRlZFxuICAgICAgICAgICAgICAgICAgICBpZiAoaXNMaWdodG1hcCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZ2VvbWV0cnkuYWRkQXR0cmlidXRlKCdsaWdodG1hcFNjYWxlT2Zmc2V0Jywge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluc3RhbmNlZDogMSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplOiA0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE6IG5ldyBGbG9hdDMyQXJyYXkobnVtSW5zdGFuY2VzICogNCksXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBnZW9tZXRyeSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb2dyYW0sXG4gICAgICAgICAgICAgICAgICAgICAgICBtb2RlLFxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIClcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBzdGF0aWMgcGFyc2VBY2Nlc3NvcihpbmRleCwgZGVzYywgYnVmZmVyVmlld3MpIHtcbiAgICAgICAgLy8gVE9ETzogaW5pdCBtaXNzaW5nIGJ1ZmZlclZpZXcgd2l0aCAwc1xuICAgICAgICAvLyBUT0RPOiBzdXBwb3J0IHNwYXJzZVxuXG4gICAgICAgIGNvbnN0IHtcbiAgICAgICAgICAgIGJ1ZmZlclZpZXc6IGJ1ZmZlclZpZXdJbmRleCwgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgIGJ5dGVPZmZzZXQgPSAwLCAvLyBvcHRpb25hbFxuICAgICAgICAgICAgY29tcG9uZW50VHlwZSwgLy8gcmVxdWlyZWRcbiAgICAgICAgICAgIG5vcm1hbGl6ZWQgPSBmYWxzZSwgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgIGNvdW50LCAvLyByZXF1aXJlZFxuICAgICAgICAgICAgdHlwZSwgLy8gcmVxdWlyZWRcbiAgICAgICAgICAgIG1pbiwgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgIG1heCwgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgIHNwYXJzZSwgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgIC8vIG5hbWUsIC8vIG9wdGlvbmFsXG4gICAgICAgICAgICAvLyBleHRlbnNpb25zLCAvLyBvcHRpb25hbFxuICAgICAgICAgICAgLy8gZXh0cmFzLCAvLyBvcHRpb25hbFxuICAgICAgICB9ID0gZGVzYy5hY2Nlc3NvcnNbaW5kZXhdO1xuXG4gICAgICAgIGNvbnN0IHtcbiAgICAgICAgICAgIGRhdGEsIC8vIGF0dGFjaGVkIGluIHBhcnNlQnVmZmVyVmlld3NcbiAgICAgICAgICAgIGJ1ZmZlciwgLy8gcmVwbGFjZWQgdG8gYmUgdGhlIGFjdHVhbCBHTCBidWZmZXJcbiAgICAgICAgICAgIGJ5dGVPZmZzZXQ6IGJ1ZmZlckJ5dGVPZmZzZXQgPSAwLFxuICAgICAgICAgICAgLy8gYnl0ZUxlbmd0aCwgLy8gYXBwbGllZCBpbiBwYXJzZUJ1ZmZlclZpZXdzXG4gICAgICAgICAgICBieXRlU3RyaWRlID0gMCxcbiAgICAgICAgICAgIHRhcmdldCxcbiAgICAgICAgICAgIC8vIG5hbWUsXG4gICAgICAgICAgICAvLyBleHRlbnNpb25zLFxuICAgICAgICAgICAgLy8gZXh0cmFzLFxuICAgICAgICB9ID0gYnVmZmVyVmlld3NbYnVmZmVyVmlld0luZGV4XTtcblxuICAgICAgICBjb25zdCBzaXplID0gVFlQRV9TSVpFW3R5cGVdO1xuXG4gICAgICAgIC8vIFBhcnNlIGRhdGEgZnJvbSBqb2luZWQgYnVmZmVyc1xuICAgICAgICBjb25zdCBUeXBlQXJyYXkgPSBUWVBFX0FSUkFZW2NvbXBvbmVudFR5cGVdO1xuICAgICAgICBjb25zdCBlbGVtZW50Qnl0ZXMgPSBUeXBlQXJyYXkuQllURVNfUEVSX0VMRU1FTlQ7XG4gICAgICAgIGNvbnN0IGNvbXBvbmVudFN0cmlkZSA9IGJ5dGVTdHJpZGUgLyBlbGVtZW50Qnl0ZXM7XG4gICAgICAgIGNvbnN0IGlzSW50ZXJsZWF2ZWQgPSAhIWJ5dGVTdHJpZGUgJiYgY29tcG9uZW50U3RyaWRlICE9PSBzaXplO1xuXG4gICAgICAgIGxldCBmaWx0ZXJlZERhdGE7XG5cbiAgICAgICAgLy8gQ29udmVydCBkYXRhIHRvIHR5cGVkIGFycmF5IGZvciB2YXJpb3VzIHVzZXMgKGJvdW5kaW5nIGJveGVzLCByYXljYXN0aW5nLCBhbmltYXRpb24sIG1lcmdpbmcgZXRjKVxuICAgICAgICBpZiAoaXNJbnRlcmxlYXZlZCkge1xuICAgICAgICAgICAgLy8gRmlyc3QgY29udmVydCBlbnRpcmUgYnVmZmVyIHRvIHR5cGVcbiAgICAgICAgICAgIGNvbnN0IHR5cGVkRGF0YSA9IG5ldyBUeXBlQXJyYXkoZGF0YSwgYnl0ZU9mZnNldCk7XG4gICAgICAgICAgICAvLyBUT0RPOiBhZGQgbGVuZ3RoIHRvIG5vdCBjb3B5IGVudGlyZSBidWZmZXIgaWYgY2FuIGhlbHAgaXRcbiAgICAgICAgICAgIC8vIGNvbnN0IHR5cGVkRGF0YSA9IG5ldyBUeXBlQXJyYXkoZGF0YSwgYnl0ZU9mZnNldCwgKGNvdW50IC0gMSkgKiBjb21wb25lbnRTdHJpZGUpXG5cbiAgICAgICAgICAgIC8vIENyZWF0ZSBvdXRwdXQgd2l0aCBsZW5ndGhcbiAgICAgICAgICAgIGZpbHRlcmVkRGF0YSA9IG5ldyBUeXBlQXJyYXkoY291bnQgKiBzaXplKTtcblxuICAgICAgICAgICAgLy8gQWRkIGVsZW1lbnQgYnkgZWxlbWVudFxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb3VudDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgc3RhcnQgPSBjb21wb25lbnRTdHJpZGUgKiBpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGVuZCA9IHN0YXJ0ICsgc2l6ZTtcbiAgICAgICAgICAgICAgICBmaWx0ZXJlZERhdGEuc2V0KHR5cGVkRGF0YS5zbGljZShzdGFydCwgZW5kKSwgaSAqIHNpemUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gU2ltcGx5IGEgc2xpY2VcbiAgICAgICAgICAgIGZpbHRlcmVkRGF0YSA9IG5ldyBUeXBlQXJyYXkoZGF0YSwgYnl0ZU9mZnNldCwgY291bnQgKiBzaXplKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFJldHVybiBhdHRyaWJ1dGUgZGF0YVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgZGF0YTogZmlsdGVyZWREYXRhLFxuICAgICAgICAgICAgc2l6ZSxcbiAgICAgICAgICAgIHR5cGU6IGNvbXBvbmVudFR5cGUsXG4gICAgICAgICAgICBub3JtYWxpemVkLFxuICAgICAgICAgICAgYnVmZmVyLFxuICAgICAgICAgICAgc3RyaWRlOiBieXRlU3RyaWRlLFxuICAgICAgICAgICAgb2Zmc2V0OiBieXRlT2Zmc2V0LFxuICAgICAgICAgICAgY291bnQsXG4gICAgICAgICAgICBtaW4sXG4gICAgICAgICAgICBtYXgsXG4gICAgICAgIH07XG4gICAgfVxuXG4gICAgc3RhdGljIHBhcnNlTm9kZXMoZ2wsIGRlc2MsIG1lc2hlcywgc2tpbnMsIGltYWdlcykge1xuICAgICAgICBpZiAoIWRlc2Mubm9kZXMpIHJldHVybiBudWxsO1xuICAgICAgICBjb25zdCBjYW1lcmFzID0gW107XG4gICAgICAgIGNvbnN0IG5vZGVzID0gZGVzYy5ub2Rlcy5tYXAoXG4gICAgICAgICAgICAoe1xuICAgICAgICAgICAgICAgIGNhbWVyYSwgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgICAgICBjaGlsZHJlbiwgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgICAgICBza2luOiBza2luSW5kZXgsIC8vIG9wdGlvbmFsXG4gICAgICAgICAgICAgICAgbWF0cml4LCAvLyBvcHRpb25hbFxuICAgICAgICAgICAgICAgIG1lc2g6IG1lc2hJbmRleCwgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgICAgICByb3RhdGlvbiwgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgICAgICBzY2FsZSwgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgICAgICB0cmFuc2xhdGlvbiwgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgICAgICB3ZWlnaHRzLCAvLyBvcHRpb25hbFxuICAgICAgICAgICAgICAgIG5hbWUsIC8vIG9wdGlvbmFsXG4gICAgICAgICAgICAgICAgZXh0ZW5zaW9ucywgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgICAgICBleHRyYXMsIC8vIG9wdGlvbmFsXG4gICAgICAgICAgICB9KSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgaXNDYW1lcmEgPSBjYW1lcmEgIT09IHVuZGVmaW5lZDtcblxuICAgICAgICAgICAgICAgIGNvbnN0IG5vZGUgPSBpc0NhbWVyYSA/IG5ldyBDYW1lcmEoZ2wpIDogbmV3IFRyYW5zZm9ybSgpO1xuXG4gICAgICAgICAgICAgICAgaWYgKGlzQ2FtZXJhKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIE5PVEU6IGNob3NlIHRvIHVzZSBub2RlJ3MgbmFtZSBhbmQgZXh0cmFzL2V4dGVuc2lvbnMgb3ZlciBjYW1lcmFcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY2FtZXJhT3B0cyA9IGRlc2MuY2FtZXJhc1tjYW1lcmFdO1xuICAgICAgICAgICAgICAgICAgICBpZiAoY2FtZXJhT3B0cy50eXBlID09PSAncGVyc3BlY3RpdmUnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB7IHlmb3Y6IGZvdiwgem5lYXI6IG5lYXIsIHpmYXI6IGZhciB9ID0gY2FtZXJhT3B0cy5wZXJzcGVjdGl2ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5vZGUucGVyc3BlY3RpdmUoeyBmb3Y6IGZvdiAqICgxODAgLyBNYXRoLlBJKSwgbmVhciwgZmFyIH0pO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgeyB4bWFnLCB5bWFnLCB6bmVhcjogbmVhciwgemZhcjogZmFyIH0gPSBjYW1lcmFPcHRzLm9ydGhvZ3JhcGhpYztcbiAgICAgICAgICAgICAgICAgICAgICAgIG5vZGUub3J0aG9ncmFwaGljKHsgbmVhciwgZmFyLCBsZWZ0OiAteG1hZywgcmlnaHQ6IHhtYWcsIHRvcDogLXltYWcsIGJvdHRvbTogeW1hZyB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjYW1lcmFzLnB1c2gobm9kZSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgaWYgKG5hbWUpIG5vZGUubmFtZSA9IG5hbWU7XG4gICAgICAgICAgICAgICAgaWYgKGV4dHJhcykgbm9kZS5leHRyYXMgPSBleHRyYXM7XG4gICAgICAgICAgICAgICAgaWYgKGV4dGVuc2lvbnMpIG5vZGUuZXh0ZW5zaW9ucyA9IGV4dGVuc2lvbnM7XG5cbiAgICAgICAgICAgICAgICAvLyBOZWVkIHRvIGF0dGFjaCB0byBub2RlIGFzIG1heSBoYXZlIHNhbWUgbWF0ZXJpYWwgYnV0IGRpZmZlcmVudCBsaWdodG1hcFxuICAgICAgICAgICAgICAgIGlmIChleHRyYXMgJiYgZXh0cmFzLmxpZ2h0bWFwVGV4dHVyZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgIGV4dHJhcy5saWdodG1hcFRleHR1cmUudGV4dHVyZSA9IHRoaXMuY3JlYXRlVGV4dHVyZShnbCwgZGVzYywgaW1hZ2VzLCB7IHNvdXJjZTogZXh0cmFzLmxpZ2h0bWFwVGV4dHVyZS5pbmRleCB9KTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAvLyBBcHBseSB0cmFuc2Zvcm1hdGlvbnNcbiAgICAgICAgICAgICAgICBpZiAobWF0cml4KSB7XG4gICAgICAgICAgICAgICAgICAgIG5vZGUubWF0cml4LmNvcHkobWF0cml4KTtcbiAgICAgICAgICAgICAgICAgICAgbm9kZS5kZWNvbXBvc2UoKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBpZiAocm90YXRpb24pIG5vZGUucXVhdGVybmlvbi5jb3B5KHJvdGF0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHNjYWxlKSBub2RlLnNjYWxlLmNvcHkoc2NhbGUpO1xuICAgICAgICAgICAgICAgICAgICBpZiAodHJhbnNsYXRpb24pIG5vZGUucG9zaXRpb24uY29weSh0cmFuc2xhdGlvbik7XG4gICAgICAgICAgICAgICAgICAgIG5vZGUudXBkYXRlTWF0cml4KCk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLy8gRmxhZ3MgZm9yIGF2b2lkaW5nIGR1cGxpY2F0ZSB0cmFuc2Zvcm1zIGFuZCByZW1vdmluZyB1bnVzZWQgaW5zdGFuY2Ugbm9kZXNcbiAgICAgICAgICAgICAgICBsZXQgaXNJbnN0YW5jZWQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICBsZXQgaXNGaXJzdEluc3RhbmNlID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICBsZXQgaXNJbnN0YW5jZWRNYXRyaXggPSBmYWxzZTtcbiAgICAgICAgICAgICAgICBsZXQgaXNTa2luID0gc2tpbkluZGV4ICE9PSB1bmRlZmluZWQ7XG5cbiAgICAgICAgICAgICAgICAvLyBBZGQgbWVzaCBpZiBpbmNsdWRlZFxuICAgICAgICAgICAgICAgIGlmIChtZXNoSW5kZXggIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoaXNTa2luKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNoZXNbbWVzaEluZGV4XS5wcmltaXRpdmVzW21lc2hlc1ttZXNoSW5kZXhdLnByaW1pdGl2ZXMuaW5zdGFuY2VDb3VudF0uZm9yRWFjaCgobWVzaCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChleHRyYXMpIE9iamVjdC5hc3NpZ24obWVzaC5leHRyYXMsIGV4dHJhcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzaC5zZXRQYXJlbnQobm9kZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc2hlc1ttZXNoSW5kZXhdLnByaW1pdGl2ZXMuaW5zdGFuY2VDb3VudCsrO1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gUmVtb3ZlIHByb3BlcnRpZXMgb25jZSBhbGwgaW5zdGFuY2VzIGFkZGVkXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAobWVzaGVzW21lc2hJbmRleF0ucHJpbWl0aXZlcy5pbnN0YW5jZUNvdW50ID09PSBtZXNoZXNbbWVzaEluZGV4XS5wcmltaXRpdmVzLm51bUluc3RhbmNlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZSBtZXNoZXNbbWVzaEluZGV4XS5wcmltaXRpdmVzLm51bUluc3RhbmNlcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxldGUgbWVzaGVzW21lc2hJbmRleF0ucHJpbWl0aXZlcy5pbnN0YW5jZUNvdW50O1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgbWVzaGVzW21lc2hJbmRleF0ucHJpbWl0aXZlcy5mb3JFYWNoKChtZXNoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGV4dHJhcykgT2JqZWN0LmFzc2lnbihtZXNoLmV4dHJhcywgZXh0cmFzKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEluc3RhbmNlZCBtZXNoIG1pZ2h0IG9ubHkgaGF2ZSAxXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG1lc2guZ2VvbWV0cnkuaXNJbnN0YW5jZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNJbnN0YW5jZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIW1lc2guaW5zdGFuY2VDb3VudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzaC5pbnN0YW5jZUNvdW50ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRmlyc3RJbnN0YW5jZSA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChtZXNoLmdlb21ldHJ5LmF0dHJpYnV0ZXMuaW5zdGFuY2VNYXRyaXgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzSW5zdGFuY2VkTWF0cml4ID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5vZGUubWF0cml4LnRvQXJyYXkobWVzaC5nZW9tZXRyeS5hdHRyaWJ1dGVzLmluc3RhbmNlTWF0cml4LmRhdGEsIG1lc2guaW5zdGFuY2VDb3VudCAqIDE2KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChtZXNoLmdlb21ldHJ5LmF0dHJpYnV0ZXMubGlnaHRtYXBTY2FsZU9mZnNldCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzaC5nZW9tZXRyeS5hdHRyaWJ1dGVzLmxpZ2h0bWFwU2NhbGVPZmZzZXQuZGF0YS5zZXQoZXh0cmFzLmxpZ2h0bWFwX3NjYWxlX29mZnNldCwgbWVzaC5pbnN0YW5jZUNvdW50ICogNCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNoLmluc3RhbmNlQ291bnQrKztcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAobWVzaC5pbnN0YW5jZUNvdW50ID09PSBtZXNoLm51bUluc3RhbmNlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gUmVtb3ZlIHByb3BlcnRpZXMgb25jZSBhbGwgaW5zdGFuY2VzIGFkZGVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxldGUgbWVzaC5udW1JbnN0YW5jZXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxldGUgbWVzaC5pbnN0YW5jZUNvdW50O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gRmxhZyBhdHRyaWJ1dGUgYXMgZGlydHlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChtZXNoLmdlb21ldHJ5LmF0dHJpYnV0ZXMuaW5zdGFuY2VNYXRyaXgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNoLmdlb21ldHJ5LmF0dHJpYnV0ZXMuaW5zdGFuY2VNYXRyaXgubmVlZHNVcGRhdGUgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG1lc2guZ2VvbWV0cnkuYXR0cmlidXRlcy5saWdodG1hcFNjYWxlT2Zmc2V0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzaC5nZW9tZXRyeS5hdHRyaWJ1dGVzLmxpZ2h0bWFwU2NhbGVPZmZzZXQubmVlZHNVcGRhdGUgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gRm9yIGluc3RhbmNlcywgb25seSB0aGUgZmlyc3Qgbm9kZSB3aWxsIGFjdHVhbGx5IGhhdmUgdGhlIG1lc2hcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNJbnN0YW5jZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGlzRmlyc3RJbnN0YW5jZSkgbWVzaC5zZXRQYXJlbnQobm9kZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzaC5zZXRQYXJlbnQobm9kZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAvLyBSZXNldCBub2RlIGlmIGluc3RhbmNlZCB0byBub3QgZHVwbGljYXRlIHRyYW5zZm9ybXNcbiAgICAgICAgICAgICAgICBpZiAoaXNJbnN0YW5jZWRNYXRyaXgpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gUmVtb3ZlIHVudXNlZCBub2RlcyBqdXN0IHByb3ZpZGluZyBhbiBpbnN0YW5jZSB0cmFuc2Zvcm1cbiAgICAgICAgICAgICAgICAgICAgaWYgKCFpc0ZpcnN0SW5zdGFuY2UpIHJldHVybiBudWxsO1xuICAgICAgICAgICAgICAgICAgICAvLyBBdm9pZCBkdXBsaWNhdGUgdHJhbnNmb3JtIGZvciBub2RlIGNvbnRhaW5pbmcgdGhlIGluc3RhbmNlZCBtZXNoXG4gICAgICAgICAgICAgICAgICAgIG5vZGUubWF0cml4LmlkZW50aXR5KCk7XG4gICAgICAgICAgICAgICAgICAgIG5vZGUuZGVjb21wb3NlKCk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgcmV0dXJuIG5vZGU7XG4gICAgICAgICAgICB9XG4gICAgICAgICk7XG5cbiAgICAgICAgZGVzYy5ub2Rlcy5mb3JFYWNoKCh7IGNoaWxkcmVuID0gW10gfSwgaSkgPT4ge1xuICAgICAgICAgICAgLy8gU2V0IGhpZXJhcmNoeSBub3cgYWxsIG5vZGVzIGNyZWF0ZWRcbiAgICAgICAgICAgIGNoaWxkcmVuLmZvckVhY2goKGNoaWxkSW5kZXgpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoIW5vZGVzW2NoaWxkSW5kZXhdKSByZXR1cm47XG4gICAgICAgICAgICAgICAgbm9kZXNbY2hpbGRJbmRleF0uc2V0UGFyZW50KG5vZGVzW2ldKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcblxuICAgICAgICAvLyBBZGQgZnJ1c3R1bSBjdWxsaW5nIGZvciBpbnN0YW5jZXMgbm93IHRoYXQgaW5zdGFuY2VNYXRyaXggYXR0cmlidXRlIGlzIHBvcHVsYXRlZFxuICAgICAgICBtZXNoZXMuZm9yRWFjaCgoeyBwcmltaXRpdmVzIH0sIGkpID0+IHtcbiAgICAgICAgICAgIHByaW1pdGl2ZXMuZm9yRWFjaCgocHJpbWl0aXZlLCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHByaW1pdGl2ZS5pc0luc3RhbmNlZE1lc2gpIHByaW1pdGl2ZS5hZGRGcnVzdHVtQ3VsbCgpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHJldHVybiBbbm9kZXMsIGNhbWVyYXNdO1xuICAgIH1cblxuICAgIHN0YXRpYyBwb3B1bGF0ZVNraW5zKHNraW5zLCBub2Rlcykge1xuICAgICAgICBpZiAoIXNraW5zKSByZXR1cm47XG4gICAgICAgIHNraW5zLmZvckVhY2goKHNraW4pID0+IHtcbiAgICAgICAgICAgIHNraW4uam9pbnRzID0gc2tpbi5qb2ludHMubWFwKChpLCBpbmRleCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGpvaW50ID0gbm9kZXNbaV07XG4gICAgICAgICAgICAgICAgam9pbnQuc2tpbiA9IHNraW47XG4gICAgICAgICAgICAgICAgam9pbnQuYmluZEludmVyc2UgPSBuZXcgTWF0NCguLi5za2luLmludmVyc2VCaW5kTWF0cmljZXMuZGF0YS5zbGljZShpbmRleCAqIDE2LCAoaW5kZXggKyAxKSAqIDE2KSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGpvaW50O1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAoc2tpbi5za2VsZXRvbikgc2tpbi5za2VsZXRvbiA9IG5vZGVzW3NraW4uc2tlbGV0b25dO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBzdGF0aWMgcGFyc2VBbmltYXRpb25zKGdsLCBkZXNjLCBub2RlcywgYnVmZmVyVmlld3MpIHtcbiAgICAgICAgaWYgKCFkZXNjLmFuaW1hdGlvbnMpIHJldHVybiBudWxsO1xuICAgICAgICByZXR1cm4gZGVzYy5hbmltYXRpb25zLm1hcChcbiAgICAgICAgICAgIChcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGNoYW5uZWxzLCAvLyByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICBzYW1wbGVycywgLy8gcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgbmFtZSwgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgICAgICAgICAgLy8gZXh0ZW5zaW9ucywgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgICAgICAgICAgLy8gZXh0cmFzLCAgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGFuaW1hdGlvbkluZGV4XG4gICAgICAgICAgICApID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBkYXRhID0gY2hhbm5lbHMubWFwKFxuICAgICAgICAgICAgICAgICAgICAoe1xuICAgICAgICAgICAgICAgICAgICAgICAgc2FtcGxlcjogc2FtcGxlckluZGV4LCAvLyByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0LCAvLyByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZXh0ZW5zaW9ucywgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGV4dHJhcywgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgICAgICAgICAgfSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlucHV0OiBpbnB1dEluZGV4LCAvLyByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGludGVycG9sYXRpb24gPSAnTElORUFSJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvdXRwdXQ6IG91dHB1dEluZGV4LCAvLyByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGV4dGVuc2lvbnMsIC8vIG9wdGlvbmFsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZXh0cmFzLCAvLyBvcHRpb25hbFxuICAgICAgICAgICAgICAgICAgICAgICAgfSA9IHNhbXBsZXJzW3NhbXBsZXJJbmRleF07XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBub2RlOiBub2RlSW5kZXgsIC8vIG9wdGlvbmFsIC0gVE9ETzogd2hlbiBpcyBpdCBub3QgaW5jbHVkZWQ/XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGF0aCwgLy8gcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBleHRlbnNpb25zLCAvLyBvcHRpb25hbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGV4dHJhcywgLy8gb3B0aW9uYWxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gPSB0YXJnZXQ7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG5vZGUgPSBub2Rlc1tub2RlSW5kZXhdO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdHJhbnNmb3JtID0gVFJBTlNGT1JNU1twYXRoXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRpbWVzID0gdGhpcy5wYXJzZUFjY2Vzc29yKGlucHV0SW5kZXgsIGRlc2MsIGJ1ZmZlclZpZXdzKS5kYXRhO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsdWVzID0gdGhpcy5wYXJzZUFjY2Vzc29yKG91dHB1dEluZGV4LCBkZXNjLCBidWZmZXJWaWV3cykuZGF0YTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gU3RvcmUgcmVmZXJlbmNlIG9uIG5vZGUgZm9yIGN5Y2xpY2FsIHJldHJpZXZhbFxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFub2RlLmFuaW1hdGlvbnMpIG5vZGUuYW5pbWF0aW9ucyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFub2RlLmFuaW1hdGlvbnMuaW5jbHVkZXMoYW5pbWF0aW9uSW5kZXgpKSBub2RlLmFuaW1hdGlvbnMucHVzaChhbmltYXRpb25JbmRleCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbm9kZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW50ZXJwb2xhdGlvbixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aW1lcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZXMsXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICAgICAgICAgIGFuaW1hdGlvbjogbmV3IEdMVEZBbmltYXRpb24oZGF0YSksXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBzdGF0aWMgcGFyc2VTY2VuZXMoZGVzYywgbm9kZXMpIHtcbiAgICAgICAgaWYgKCFkZXNjLnNjZW5lcykgcmV0dXJuIG51bGw7XG4gICAgICAgIHJldHVybiBkZXNjLnNjZW5lcy5tYXAoXG4gICAgICAgICAgICAoe1xuICAgICAgICAgICAgICAgIG5vZGVzOiBub2Rlc0luZGljZXMgPSBbXSxcbiAgICAgICAgICAgICAgICBuYW1lLCAvLyBvcHRpb25hbFxuICAgICAgICAgICAgICAgIGV4dGVuc2lvbnMsXG4gICAgICAgICAgICAgICAgZXh0cmFzLFxuICAgICAgICAgICAgfSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHNjZW5lID0gbm9kZXNJbmRpY2VzLnJlZHVjZSgobWFwLCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIC8vIERvbid0IGFkZCBudWxsIG5vZGVzIChpbnN0YW5jZWQgdHJhbnNmb3JtcylcbiAgICAgICAgICAgICAgICAgICAgaWYgKG5vZGVzW2ldKSBtYXAucHVzaChub2Rlc1tpXSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBtYXA7XG4gICAgICAgICAgICAgICAgfSwgW10pO1xuICAgICAgICAgICAgICAgIHNjZW5lLmV4dHJhcyA9IGV4dHJhcztcbiAgICAgICAgICAgICAgICByZXR1cm4gc2NlbmU7XG4gICAgICAgICAgICB9XG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgc3RhdGljIHBhcnNlTGlnaHRzKGdsLCBkZXNjLCBub2Rlcywgc2NlbmVzKSB7XG4gICAgICAgIGNvbnN0IGxpZ2h0cyA9IHtcbiAgICAgICAgICAgIGRpcmVjdGlvbmFsOiBbXSxcbiAgICAgICAgICAgIHBvaW50OiBbXSxcbiAgICAgICAgICAgIHNwb3Q6IFtdLFxuICAgICAgICB9O1xuXG4gICAgICAgIC8vIFVwZGF0ZSBtYXRyaWNlcyBvbiByb290IG5vZGVzXG4gICAgICAgIHNjZW5lcy5mb3JFYWNoKChzY2VuZSkgPT4gc2NlbmUuZm9yRWFjaCgobm9kZSkgPT4gbm9kZS51cGRhdGVNYXRyaXhXb3JsZCgpKSk7XG5cbiAgICAgICAgLy8gVXNlcyBLSFJfbGlnaHRzX3B1bmN0dWFsIGV4dGVuc2lvblxuICAgICAgICBjb25zdCBsaWdodHNEZXNjQXJyYXkgPSBkZXNjLmV4dGVuc2lvbnM/LktIUl9saWdodHNfcHVuY3R1YWw/LmxpZ2h0cyB8fCBbXTtcblxuICAgICAgICAvLyBOZWVkIG5vZGVzIGZvciB0cmFuc2Zvcm1zXG4gICAgICAgIG5vZGVzLmZvckVhY2goKG5vZGUpID0+IHtcbiAgICAgICAgICAgIGlmICghbm9kZT8uZXh0ZW5zaW9ucz8uS0hSX2xpZ2h0c19wdW5jdHVhbCkgcmV0dXJuO1xuICAgICAgICAgICAgY29uc3QgbGlnaHRJbmRleCA9IG5vZGUuZXh0ZW5zaW9ucy5LSFJfbGlnaHRzX3B1bmN0dWFsLmxpZ2h0O1xuICAgICAgICAgICAgY29uc3QgbGlnaHREZXNjID0gbGlnaHRzRGVzY0FycmF5W2xpZ2h0SW5kZXhdO1xuICAgICAgICAgICAgY29uc3QgbGlnaHQgPSB7XG4gICAgICAgICAgICAgICAgbmFtZTogbGlnaHREZXNjLm5hbWUgfHwgJycsXG4gICAgICAgICAgICAgICAgY29sb3I6IHsgdmFsdWU6IG5ldyBWZWMzKCkuc2V0KGxpZ2h0RGVzYy5jb2xvciB8fCAxKSB9LFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIC8vIEFwcGx5IGludGVuc2l0eSBkaXJlY3RseSB0byBjb2xvclxuICAgICAgICAgICAgaWYgKGxpZ2h0RGVzYy5pbnRlbnNpdHkgIT09IHVuZGVmaW5lZCkgbGlnaHQuY29sb3IudmFsdWUubXVsdGlwbHkobGlnaHREZXNjLmludGVuc2l0eSk7XG5cbiAgICAgICAgICAgIHN3aXRjaCAobGlnaHREZXNjLnR5cGUpIHtcbiAgICAgICAgICAgICAgICBjYXNlICdkaXJlY3Rpb25hbCc6XG4gICAgICAgICAgICAgICAgICAgIGxpZ2h0LmRpcmVjdGlvbiA9IHsgdmFsdWU6IG5ldyBWZWMzKDAsIDAsIDEpLnRyYW5zZm9ybURpcmVjdGlvbihub2RlLndvcmxkTWF0cml4KSB9O1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlICdwb2ludCc6XG4gICAgICAgICAgICAgICAgICAgIGxpZ2h0LnBvc2l0aW9uID0geyB2YWx1ZTogbmV3IFZlYzMoKS5hcHBseU1hdHJpeDQobm9kZS53b3JsZE1hdHJpeCkgfTtcbiAgICAgICAgICAgICAgICAgICAgbGlnaHQuZGlzdGFuY2UgPSB7IHZhbHVlOiBsaWdodERlc2MucmFuZ2UgfTtcbiAgICAgICAgICAgICAgICAgICAgbGlnaHQuZGVjYXkgPSB7IHZhbHVlOiAyIH07XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgJ3Nwb3QnOlxuICAgICAgICAgICAgICAgICAgICAvLyBUT0RPOiBzdXBwb3J0IHNwb3QgdW5pZm9ybXNcbiAgICAgICAgICAgICAgICAgICAgT2JqZWN0LmFzc2lnbihsaWdodCwgbGlnaHREZXNjKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGxpZ2h0c1tsaWdodERlc2MudHlwZV0ucHVzaChsaWdodCk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHJldHVybiBsaWdodHM7XG4gICAgfVxufVxuIiwibGV0IGlkID0gMDtcblxuZXhwb3J0IGNsYXNzIERyYWNvTWFuYWdlciB7XG4gICAgY29uc3RydWN0b3Iod29ya2VyU3JjKSB7XG4gICAgICAgIHRoaXMub25NZXNzYWdlID0gdGhpcy5vbk1lc3NhZ2UuYmluZCh0aGlzKTtcbiAgICAgICAgdGhpcy5xdWV1ZSA9IG5ldyBNYXAoKTtcbiAgICAgICAgdGhpcy5pbml0V29ya2VyKHdvcmtlclNyYyk7XG4gICAgfVxuXG4gICAgaW5pdFdvcmtlcih3b3JrZXJTcmMpIHtcbiAgICAgICAgdGhpcy53b3JrZXIgPSBuZXcgV29ya2VyKHdvcmtlclNyYyk7XG4gICAgICAgIHRoaXMud29ya2VyLm9ubWVzc2FnZSA9IHRoaXMub25NZXNzYWdlO1xuICAgIH1cblxuICAgIG9uTWVzc2FnZSh7IGRhdGEgfSkge1xuICAgICAgICBjb25zdCB7IGlkLCBlcnJvciwgZ2VvbWV0cnkgfSA9IGRhdGE7XG4gICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IsIGlkKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBnZW9tZXRyeVJlc29sdmUgPSB0aGlzLnF1ZXVlLmdldChpZCk7XG4gICAgICAgIHRoaXMucXVldWUuZGVsZXRlKGlkKTtcbiAgICAgICAgZ2VvbWV0cnlSZXNvbHZlKGdlb21ldHJ5KTtcbiAgICB9XG5cbiAgICBkZWNvZGVHZW9tZXRyeShidWZmZXIsIGNvbmZpZykge1xuICAgICAgICBpZCsrO1xuICAgICAgICB0aGlzLndvcmtlci5wb3N0TWVzc2FnZSh7XG4gICAgICAgICAgICBpZCxcbiAgICAgICAgICAgIGJ1ZmZlcixcbiAgICAgICAgICAgIGNvbmZpZyxcbiAgICAgICAgfSk7XG4gICAgICAgIGxldCBnZW9tZXRyeVJlc29sdmU7XG4gICAgICAgIGNvbnN0IHByb21pc2UgPSBuZXcgUHJvbWlzZSgocmVzKSA9PiAoZ2VvbWV0cnlSZXNvbHZlID0gcmVzKSk7XG4gICAgICAgIHRoaXMucXVldWUuc2V0KGlkLCBnZW9tZXRyeVJlc29sdmUpO1xuICAgICAgICByZXR1cm4gcHJvbWlzZTtcbiAgICB9XG59XG4iLCJsZXQgc3VwcG9ydGVkRm9ybWF0O1xubGV0IGlkID0gMDtcblxuZXhwb3J0IGNsYXNzIEJhc2lzTWFuYWdlciB7XG4gICAgY29uc3RydWN0b3Iod29ya2VyU3JjLCBnbCkge1xuICAgICAgICBpZiAoIXN1cHBvcnRlZEZvcm1hdCkgc3VwcG9ydGVkRm9ybWF0ID0gdGhpcy5nZXRTdXBwb3J0ZWRGb3JtYXQoZ2wpO1xuICAgICAgICB0aGlzLm9uTWVzc2FnZSA9IHRoaXMub25NZXNzYWdlLmJpbmQodGhpcyk7XG4gICAgICAgIHRoaXMucXVldWUgPSBuZXcgTWFwKCk7XG4gICAgICAgIHRoaXMuaW5pdFdvcmtlcih3b3JrZXJTcmMpO1xuICAgIH1cblxuICAgIGdldFN1cHBvcnRlZEZvcm1hdChnbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpLmdldENvbnRleHQoJ3dlYmdsJykpIHtcbiAgICAgICAgLyogaWYgKCEhZ2wuZ2V0RXh0ZW5zaW9uKCdXRUJHTF9jb21wcmVzc2VkX3RleHR1cmVfZXRjJykpIHtcbiAgICAgICAgICAgIHJldHVybiAnZXRjMic7XG4gICAgICAgIH0gZWxzZSAgKi9cbiAgICAgICAgaWYgKCEhZ2wuZ2V0RXh0ZW5zaW9uKCdXRUJHTF9jb21wcmVzc2VkX3RleHR1cmVfYXN0YycpKSB7XG4gICAgICAgICAgICByZXR1cm4gJ2FzdGMnO1xuICAgICAgICB9IGVsc2UgaWYgKCEhZ2wuZ2V0RXh0ZW5zaW9uKCdFWFRfdGV4dHVyZV9jb21wcmVzc2lvbl9icHRjJykpIHtcbiAgICAgICAgICAgIHJldHVybiAnYnB0Yyc7XG4gICAgICAgIH0gZWxzZSBpZiAoISFnbC5nZXRFeHRlbnNpb24oJ1dFQkdMX2NvbXByZXNzZWRfdGV4dHVyZV9zM3RjJykpIHtcbiAgICAgICAgICAgIHJldHVybiAnczN0Yyc7XG4gICAgICAgIH0gZWxzZSBpZiAoISFnbC5nZXRFeHRlbnNpb24oJ1dFQkdMX2NvbXByZXNzZWRfdGV4dHVyZV9ldGMxJykpIHtcbiAgICAgICAgICAgIHJldHVybiAnZXRjMSc7XG4gICAgICAgIH0gZWxzZSBpZiAoISFnbC5nZXRFeHRlbnNpb24oJ1dFQkdMX2NvbXByZXNzZWRfdGV4dHVyZV9wdnJ0YycpIHx8ICEhZ2wuZ2V0RXh0ZW5zaW9uKCdXRUJLSVRfV0VCR0xfY29tcHJlc3NlZF90ZXh0dXJlX3B2cnRjJykpIHtcbiAgICAgICAgICAgIHJldHVybiAncHZydGMnO1xuICAgICAgICAgICAgLy8gfSBlbHNlIGlmICghIWdsLmdldEV4dGVuc2lvbignV0VCR0xfY29tcHJlc3NlZF90ZXh0dXJlX2F0YycpKSB7XG4gICAgICAgICAgICAvLyAgICAgcmV0dXJuICdhdGMnO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAnbm9uZSc7XG4gICAgfVxuXG4gICAgaW5pdFdvcmtlcih3b3JrZXJTcmMpIHtcbiAgICAgICAgdGhpcy53b3JrZXIgPSBuZXcgV29ya2VyKHdvcmtlclNyYyk7XG4gICAgICAgIHRoaXMud29ya2VyLm9ubWVzc2FnZSA9IHRoaXMub25NZXNzYWdlO1xuICAgIH1cblxuICAgIG9uTWVzc2FnZSh7IGRhdGEgfSkge1xuICAgICAgICBjb25zdCB7IGlkLCBlcnJvciwgaW1hZ2UgfSA9IGRhdGE7XG4gICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IsIGlkKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB0ZXh0dXJlUmVzb2x2ZSA9IHRoaXMucXVldWUuZ2V0KGlkKTtcbiAgICAgICAgdGhpcy5xdWV1ZS5kZWxldGUoaWQpO1xuICAgICAgICBpbWFnZS5pc0Jhc2lzID0gdHJ1ZTtcbiAgICAgICAgdGV4dHVyZVJlc29sdmUoaW1hZ2UpO1xuICAgIH1cblxuICAgIHBhcnNlVGV4dHVyZShidWZmZXIpIHtcbiAgICAgICAgaWQrKztcbiAgICAgICAgdGhpcy53b3JrZXIucG9zdE1lc3NhZ2Uoe1xuICAgICAgICAgICAgaWQsXG4gICAgICAgICAgICBidWZmZXIsXG4gICAgICAgICAgICBzdXBwb3J0ZWRGb3JtYXQsXG4gICAgICAgIH0pO1xuICAgICAgICBsZXQgdGV4dHVyZVJlc29sdmU7XG4gICAgICAgIGNvbnN0IHByb21pc2UgPSBuZXcgUHJvbWlzZSgocmVzKSA9PiAodGV4dHVyZVJlc29sdmUgPSByZXMpKTtcbiAgICAgICAgdGhpcy5xdWV1ZS5zZXQoaWQsIHRleHR1cmVSZXNvbHZlKTtcbiAgICAgICAgcmV0dXJuIHByb21pc2U7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgTWVzaCB9IGZyb20gJy4uL2NvcmUvTWVzaC5qcyc7XG5pbXBvcnQgeyBQcm9ncmFtIH0gZnJvbSAnLi4vY29yZS9Qcm9ncmFtLmpzJztcbmltcG9ydCB7IEdlb21ldHJ5IH0gZnJvbSAnLi4vY29yZS9HZW9tZXRyeS5qcyc7XG5pbXBvcnQgeyBDb2xvciB9IGZyb20gJy4uL21hdGgvQ29sb3IuanMnO1xuXG5leHBvcnQgY2xhc3MgV2lyZU1lc2ggZXh0ZW5kcyBNZXNoIHtcbiAgICBjb25zdHJ1Y3RvcihnbCwgeyBnZW9tZXRyeSwgd2lyZUNvbG9yID0gbmV3IENvbG9yKDAsIDAuNzUsIDAuNSksIC4uLm1lc2hQcm9wcyB9ID0ge30pIHtcbiAgICAgICAgY29uc3Qgd2lyZVByb2dyYW0gPSBuZXcgUHJvZ3JhbShnbCwge1xuICAgICAgICAgICAgdmVydGV4LFxuICAgICAgICAgICAgZnJhZ21lbnQsXG4gICAgICAgICAgICB1bmlmb3JtczogeyB3aXJlQ29sb3I6IHsgdmFsdWU6IHdpcmVDb2xvciB9IH0sXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGNvbnN0IHBvc2l0aW9uQXJyYXkgPSBnZW9tZXRyeS5hdHRyaWJ1dGVzLnBvc2l0aW9uLmRhdGE7XG4gICAgICAgIGNvbnN0IGluZGljZXMgPSBbXTtcbiAgICAgICAgY29uc3QgaGFzaFNldCA9IG5ldyBTZXQoKTtcblxuICAgICAgICBmdW5jdGlvbiBhZGRVbmlxdWVJbmRpY2VzKGlkeCkge1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpZHgubGVuZ3RoOyBpICs9IDIpIHtcbiAgICAgICAgICAgICAgICBpZiAoaXNVbmlxdWVFZGdlUG9zaXRpb24oaWR4W2ldICogMywgaWR4W2kgKyAxXSAqIDMsIHBvc2l0aW9uQXJyYXksIGhhc2hTZXQpKSB7XG4gICAgICAgICAgICAgICAgICAgIGluZGljZXMucHVzaChpZHhbaV0sIGlkeFtpICsgMV0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChnZW9tZXRyeS5hdHRyaWJ1dGVzLmluZGV4KSB7XG4gICAgICAgICAgICBjb25zdCBpZGF0YSA9IGdlb21ldHJ5LmF0dHJpYnV0ZXMuaW5kZXguZGF0YTtcblxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpZGF0YS5sZW5ndGg7IGkgKz0gMykge1xuICAgICAgICAgICAgICAgIC8vIEZvciBldmVyeSB0cmlhbmdsZSwgbWFrZSB0aHJlZSBsaW5lIHBhaXJzIChzdGFydCwgZW5kKVxuICAgICAgICAgICAgICAgIC8vIHByZXR0aWVyLWlnbm9yZVxuICAgICAgICAgICAgICAgIGFkZFVuaXF1ZUluZGljZXMoW1xuICAgICAgICAgICAgICAgICAgICBpZGF0YVtpXSwgaWRhdGFbaSArIDFdLFxuICAgICAgICAgICAgICAgICAgICBpZGF0YVtpICsgMV0sIGlkYXRhW2kgKyAyXSxcbiAgICAgICAgICAgICAgICAgICAgaWRhdGFbaSArIDJdLCBpZGF0YVtpXVxuICAgICAgICAgICAgICAgIF0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgbnVtVmVydGljZXMgPSBNYXRoLmZsb29yKHBvc2l0aW9uQXJyYXkubGVuZ3RoIC8gMyk7XG5cbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbnVtVmVydGljZXM7IGkgKz0gMykge1xuICAgICAgICAgICAgICAgIGFkZFVuaXF1ZUluZGljZXMoW2ksIGkgKyAxLCBpICsgMSwgaSArIDIsIGkgKyAyLCBpXSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBpbmRpY2VzVHlwZWQgPSBpbmRpY2VzLmxlbmd0aCA+IDY1NTM2ID8gbmV3IFVpbnQzMkFycmF5KGluZGljZXMpIDogbmV3IFVpbnQxNkFycmF5KGluZGljZXMpO1xuICAgICAgICBjb25zdCB3aXJlR2VvbWV0cnkgPSBuZXcgR2VvbWV0cnkoZ2wsIHtcbiAgICAgICAgICAgIHBvc2l0aW9uOiB7IC4uLmdlb21ldHJ5LmF0dHJpYnV0ZXMucG9zaXRpb24gfSxcbiAgICAgICAgICAgIGluZGV4OiB7IGRhdGE6IGluZGljZXNUeXBlZCB9LFxuICAgICAgICB9KTtcblxuICAgICAgICBzdXBlcihnbCwgeyAuLi5tZXNoUHJvcHMsIG1vZGU6IGdsLkxJTkVTLCBnZW9tZXRyeTogd2lyZUdlb21ldHJ5LCBwcm9ncmFtOiB3aXJlUHJvZ3JhbSB9KTtcbiAgICB9XG59XG5cbi8vIGZyb20gaHR0cHM6Ly9naXRodWIuY29tL21yZG9vYi90aHJlZS5qcy9ibG9iLzBjMjZiYjRiYjgyMjAxMjY0NDdjODM3MzE1NGFjMDQ1NTg4NDQxZGUvc3JjL2dlb21ldHJpZXMvV2lyZWZyYW1lR2VvbWV0cnkuanMjTDExNlxuZnVuY3Rpb24gaXNVbmlxdWVFZGdlUG9zaXRpb24oc3RhcnQsIGVuZCwgcG9zLCBoYXNoU2V0KSB7XG4gICAgLy8gcHJldHRpZXItaWdub3JlXG4gICAgY29uc3QgaGFzaDEgPSBbXG4gICAgICAgIHBvc1tzdGFydF0sIHBvc1tzdGFydCArIDFdLCBwb3Nbc3RhcnQgKyAyXSxcbiAgICAgICAgcG9zW2VuZF0sIHBvc1tlbmQgKyAxXSwgcG9zW2VuZCArIDJdXG4gICAgXS5qb2luKCcjJyk7XG5cbiAgICAvLyBjb2luY2lkZW50IGVkZ2VcbiAgICAvLyBwcmV0dGllci1pZ25vcmVcbiAgICBjb25zdCBoYXNoMiA9IFtcbiAgICAgICAgcG9zW2VuZF0sIHBvc1tlbmQgKyAxXSwgcG9zW2VuZCArIDJdLFxuICAgICAgICBwb3Nbc3RhcnRdLCBwb3Nbc3RhcnQgKyAxXSwgcG9zW3N0YXJ0ICsgMl1cbiAgICBdLmpvaW4oJyMnKTtcblxuICAgIGNvbnN0IG9sZFNpemUgPSBoYXNoU2V0LnNpemU7XG4gICAgaGFzaFNldC5hZGQoaGFzaDEpO1xuICAgIGhhc2hTZXQuYWRkKGhhc2gyKTtcbiAgICByZXR1cm4gaGFzaFNldC5zaXplIC0gb2xkU2l6ZSA9PT0gMjtcbn1cblxuY29uc3QgdmVydGV4ID0gLyogZ2xzbCAqLyBgXG5hdHRyaWJ1dGUgdmVjMyBwb3NpdGlvbjtcbnVuaWZvcm0gbWF0NCBtb2RlbFZpZXdNYXRyaXg7XG51bmlmb3JtIG1hdDQgcHJvamVjdGlvbk1hdHJpeDtcblxudm9pZCBtYWluKCkgeyAgICBcbiAgICBnbF9Qb3NpdGlvbiA9IHByb2plY3Rpb25NYXRyaXggKiBtb2RlbFZpZXdNYXRyaXggKiB2ZWM0KHBvc2l0aW9uLCAxLjApO1xufVxuYDtcblxuY29uc3QgZnJhZ21lbnQgPSAvKiBnbHNsICovIGBcbnByZWNpc2lvbiBoaWdocCBmbG9hdDtcbnVuaWZvcm0gdmVjMyB3aXJlQ29sb3I7XG5cbnZvaWQgbWFpbigpIHsgICAgXG4gICAgZ2xfRnJhZ0NvbG9yID0gdmVjNCh3aXJlQ29sb3IsIDEuMCk7XG59XG5gO1xuIiwiaW1wb3J0IHsgTWVzaCB9IGZyb20gJy4uLy4uL2NvcmUvTWVzaC5qcyc7XG5pbXBvcnQgeyBQcm9ncmFtIH0gZnJvbSAnLi4vLi4vY29yZS9Qcm9ncmFtLmpzJztcbmltcG9ydCB7IEdlb21ldHJ5IH0gZnJvbSAnLi4vLi4vY29yZS9HZW9tZXRyeS5qcyc7XG5pbXBvcnQgeyBWZWMzIH0gZnJvbSAnLi4vLi4vbWF0aC9WZWMzLmpzJztcblxuZXhwb3J0IGNsYXNzIEF4ZXNIZWxwZXIgZXh0ZW5kcyBNZXNoIHtcbiAgICBjb25zdHJ1Y3RvcihcbiAgICAgICAgZ2wsXG4gICAgICAgIHtcbiAgICAgICAgICAgIHNpemUgPSAxLFxuICAgICAgICAgICAgc3ltbWV0cmljID0gZmFsc2UsXG4gICAgICAgICAgICB4Q29sb3IgPSBuZXcgVmVjMygwLjk2LCAwLjIxLCAwLjMyKSxcbiAgICAgICAgICAgIHlDb2xvciA9IG5ldyBWZWMzKDAuNDQsIDAuNjQsIDAuMTEpLFxuICAgICAgICAgICAgekNvbG9yID0gbmV3IFZlYzMoMC4xOCwgMC41MiwgMC44OSksXG4gICAgICAgICAgICAuLi5tZXNoUHJvcHNcbiAgICAgICAgfSA9IHt9XG4gICAgKSB7XG4gICAgICAgIGNvbnN0IGEgPSBzeW1tZXRyaWMgPyAtc2l6ZSA6IDA7XG4gICAgICAgIGNvbnN0IGIgPSBzaXplO1xuXG4gICAgICAgIC8vIHByZXR0aWVyLWlnbm9yZVxuICAgICAgICBjb25zdCB2ZXJ0aWNlcyA9IG5ldyBGbG9hdDMyQXJyYXkoW1xuXHRcdFx0YSwgMCwgMCwgIGIsIDAsIDAsXG5cdFx0XHQwLCBhLCAwLCAgMCwgYiwgMCxcblx0XHRcdDAsIDAsIGEsICAwLCAwLCBiXG5cdFx0XSk7XG5cbiAgICAgICAgLy8gcHJldHRpZXItaWdub3JlXG4gICAgICAgIGNvbnN0IGNvbG9ycyA9IG5ldyBGbG9hdDMyQXJyYXkoW1xuXHRcdFx0Li4ueENvbG9yLCAgLi4ueENvbG9yLFxuXHRcdFx0Li4ueUNvbG9yLCAgLi4ueUNvbG9yLFxuXHRcdFx0Li4uekNvbG9yLCAgLi4uekNvbG9yXG5cdFx0XSk7XG5cbiAgICAgICAgY29uc3QgZ2VvbWV0cnkgPSBuZXcgR2VvbWV0cnkoZ2wsIHtcbiAgICAgICAgICAgIHBvc2l0aW9uOiB7IHNpemU6IDMsIGRhdGE6IHZlcnRpY2VzIH0sXG4gICAgICAgICAgICBjb2xvcjogeyBzaXplOiAzLCBkYXRhOiBjb2xvcnMgfSxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY29uc3QgcHJvZ3JhbSA9IG5ldyBQcm9ncmFtKGdsLCB7IHZlcnRleCwgZnJhZ21lbnQgfSk7XG5cbiAgICAgICAgc3VwZXIoZ2wsIHsgLi4ubWVzaFByb3BzLCBtb2RlOiBnbC5MSU5FUywgZ2VvbWV0cnksIHByb2dyYW0gfSk7XG4gICAgfVxufVxuXG5jb25zdCB2ZXJ0ZXggPSAvKiBnbHNsICovIGBcbmF0dHJpYnV0ZSB2ZWMzIHBvc2l0aW9uO1xuYXR0cmlidXRlIHZlYzMgY29sb3I7XG51bmlmb3JtIG1hdDQgbW9kZWxWaWV3TWF0cml4O1xudW5pZm9ybSBtYXQ0IHByb2plY3Rpb25NYXRyaXg7XG5cbnZhcnlpbmcgdmVjMyB2Q29sb3I7XG5cbnZvaWQgbWFpbigpIHsgICAgXG4gICAgdkNvbG9yID0gY29sb3I7XG4gICAgZ2xfUG9zaXRpb24gPSBwcm9qZWN0aW9uTWF0cml4ICogbW9kZWxWaWV3TWF0cml4ICogdmVjNChwb3NpdGlvbiwgMS4wKTtcbn1cbmA7XG5cbmNvbnN0IGZyYWdtZW50ID0gLyogZ2xzbCAqLyBgXG5wcmVjaXNpb24gaGlnaHAgZmxvYXQ7XG52YXJ5aW5nIHZlYzMgdkNvbG9yO1xuXG52b2lkIG1haW4oKSB7ICAgIFxuICAgIGdsX0ZyYWdDb2xvciA9IHZlYzQodkNvbG9yLCAxLjApO1xufVxuYDtcbiIsImltcG9ydCB7IE1lc2ggfSBmcm9tICcuLi8uLi9jb3JlL01lc2guanMnO1xuaW1wb3J0IHsgUHJvZ3JhbSB9IGZyb20gJy4uLy4uL2NvcmUvUHJvZ3JhbS5qcyc7XG5pbXBvcnQgeyBHZW9tZXRyeSB9IGZyb20gJy4uLy4uL2NvcmUvR2VvbWV0cnkuanMnO1xuaW1wb3J0IHsgVmVjMyB9IGZyb20gJy4uLy4uL21hdGgvVmVjMy5qcyc7XG5cbmV4cG9ydCBjbGFzcyBHcmlkSGVscGVyIGV4dGVuZHMgTWVzaCB7XG4gICAgY29uc3RydWN0b3IoZ2wsIHsgc2l6ZSA9IDEwLCBkaXZpc2lvbnMgPSAxMCwgY29sb3IgPSBuZXcgVmVjMygwLjc1LCAwLjc1LCAwLjc1KSwgLi4ubWVzaFByb3BzIH0gPSB7fSkge1xuICAgICAgICBjb25zdCBudW1WZXJ0aWNlcyA9IChzaXplICsgMSkgKiAyICogMjtcbiAgICAgICAgY29uc3QgdmVydGljZXMgPSBuZXcgRmxvYXQzMkFycmF5KG51bVZlcnRpY2VzICogMyk7XG5cbiAgICAgICAgY29uc3QgaHMgPSBzaXplIC8gMjtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPD0gZGl2aXNpb25zOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IHQgPSBpIC8gZGl2aXNpb25zO1xuICAgICAgICAgICAgY29uc3QgbyA9IHQgKiBzaXplIC0gaHM7XG5cbiAgICAgICAgICAgIHZlcnRpY2VzLnNldChbbywgMCwgLWhzLCBvLCAwLCBoc10sIGkgKiAxMik7XG4gICAgICAgICAgICB2ZXJ0aWNlcy5zZXQoWy1ocywgMCwgbywgaHMsIDAsIG9dLCBpICogMTIgKyA2KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGdlb21ldHJ5ID0gbmV3IEdlb21ldHJ5KGdsLCB7XG4gICAgICAgICAgICBwb3NpdGlvbjogeyBzaXplOiAzLCBkYXRhOiB2ZXJ0aWNlcyB9LFxuICAgICAgICB9KTtcblxuICAgICAgICBjb25zdCBwcm9ncmFtID0gbmV3IFByb2dyYW0oZ2wsIHtcbiAgICAgICAgICAgIHZlcnRleCxcbiAgICAgICAgICAgIGZyYWdtZW50LFxuICAgICAgICAgICAgdW5pZm9ybXM6IHtcbiAgICAgICAgICAgICAgICBjb2xvcjogeyB2YWx1ZTogY29sb3IgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICBzdXBlcihnbCwgeyAuLi5tZXNoUHJvcHMsIG1vZGU6IGdsLkxJTkVTLCBnZW9tZXRyeSwgcHJvZ3JhbSB9KTtcbiAgICB9XG59XG5cbmNvbnN0IHZlcnRleCA9IC8qIGdsc2wgKi8gYFxuYXR0cmlidXRlIHZlYzMgcG9zaXRpb247XG51bmlmb3JtIG1hdDQgbW9kZWxWaWV3TWF0cml4O1xudW5pZm9ybSBtYXQ0IHByb2plY3Rpb25NYXRyaXg7XG5cbnZvaWQgbWFpbigpIHsgICAgXG4gICAgZ2xfUG9zaXRpb24gPSBwcm9qZWN0aW9uTWF0cml4ICogbW9kZWxWaWV3TWF0cml4ICogdmVjNChwb3NpdGlvbiwgMS4wKTtcbn1cbmA7XG5cbmNvbnN0IGZyYWdtZW50ID0gLyogZ2xzbCAqLyBgXG5wcmVjaXNpb24gaGlnaHAgZmxvYXQ7XG51bmlmb3JtIHZlYzMgY29sb3I7XG5cbnZvaWQgbWFpbigpIHsgICAgXG4gICAgZ2xfRnJhZ0NvbG9yID0gdmVjNChjb2xvciwgMS4wKTtcbn1cbmA7XG4iLCJpbXBvcnQgeyBNZXNoIH0gZnJvbSAnLi4vLi4vY29yZS9NZXNoLmpzJztcbmltcG9ydCB7IFByb2dyYW0gfSBmcm9tICcuLi8uLi9jb3JlL1Byb2dyYW0uanMnO1xuaW1wb3J0IHsgR2VvbWV0cnkgfSBmcm9tICcuLi8uLi9jb3JlL0dlb21ldHJ5LmpzJztcbmltcG9ydCB7IFZlYzMgfSBmcm9tICcuLi8uLi9tYXRoL1ZlYzMuanMnO1xuaW1wb3J0IHsgTWF0MyB9IGZyb20gJy4uLy4uL21hdGgvTWF0My5qcyc7XG5cbmV4cG9ydCBjbGFzcyBWZXJ0ZXhOb3JtYWxzSGVscGVyIGV4dGVuZHMgTWVzaCB7XG4gICAgY29uc3RydWN0b3Iob2JqZWN0LCB7IHNpemUgPSAwLjEsIGNvbG9yID0gbmV3IFZlYzMoMC44NiwgMC4xNiwgMC44NiksIC4uLm1lc2hQcm9wcyB9ID0ge30pIHtcbiAgICAgICAgY29uc3QgZ2wgPSBvYmplY3QuZ2w7XG4gICAgICAgIGNvbnN0IG5Ob3JtYWxzID0gb2JqZWN0Lmdlb21ldHJ5LmF0dHJpYnV0ZXMubm9ybWFsLmNvdW50O1xuICAgICAgICBjb25zdCBwb3NpdGlvbnNBcnJheSA9IG5ldyBGbG9hdDMyQXJyYXkobk5vcm1hbHMgKiAyICogMyk7XG4gICAgICAgIGNvbnN0IG5vcm1hbHNBcnJheSA9IG5ldyBGbG9hdDMyQXJyYXkobk5vcm1hbHMgKiAyICogMyk7XG4gICAgICAgIGNvbnN0IHNpemVBcnJheSA9IG5ldyBGbG9hdDMyQXJyYXkobk5vcm1hbHMgKiAyKTtcblxuICAgICAgICBjb25zdCBub3JtYWxEYXRhID0gb2JqZWN0Lmdlb21ldHJ5LmF0dHJpYnV0ZXMubm9ybWFsLmRhdGE7XG4gICAgICAgIGNvbnN0IHBvc2l0aW9uRGF0YSA9IG9iamVjdC5nZW9tZXRyeS5hdHRyaWJ1dGVzLnBvc2l0aW9uLmRhdGE7XG4gICAgICAgIGNvbnN0IHNpemVEYXRhID0gbmV3IEZsb2F0MzJBcnJheShbMCwgc2l6ZV0pO1xuXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbk5vcm1hbHM7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgaTYgPSBpICogNjtcbiAgICAgICAgICAgIGNvbnN0IGkzID0gaSAqIDM7XG5cbiAgICAgICAgICAgIC8vIGR1cGxpY2F0ZSBwb3NpdGlvbiBhbmQgbm9ybWFsIGZvciBsaW5lIHN0YXJ0IGFuZCBlbmQgcG9pbnRcbiAgICAgICAgICAgIGNvbnN0IHBTdWIgPSBwb3NpdGlvbkRhdGEuc3ViYXJyYXkoaTMsIGkzICsgMyk7XG4gICAgICAgICAgICBwb3NpdGlvbnNBcnJheS5zZXQocFN1YiwgaTYpO1xuICAgICAgICAgICAgcG9zaXRpb25zQXJyYXkuc2V0KHBTdWIsIGk2ICsgMyk7XG5cbiAgICAgICAgICAgIGNvbnN0IG5TdWIgPSBub3JtYWxEYXRhLnN1YmFycmF5KGkzLCBpMyArIDMpO1xuICAgICAgICAgICAgbm9ybWFsc0FycmF5LnNldChuU3ViLCBpNik7XG4gICAgICAgICAgICBub3JtYWxzQXJyYXkuc2V0KG5TdWIsIGk2ICsgMyk7XG5cbiAgICAgICAgICAgIHNpemVBcnJheS5zZXQoc2l6ZURhdGEsIGkgKiAyKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGdlb21ldHJ5ID0gbmV3IEdlb21ldHJ5KGdsLCB7XG4gICAgICAgICAgICBwb3NpdGlvbjogeyBzaXplOiAzLCBkYXRhOiBwb3NpdGlvbnNBcnJheSB9LFxuICAgICAgICAgICAgbm9ybWFsOiB7IHNpemU6IDMsIGRhdGE6IG5vcm1hbHNBcnJheSB9LFxuICAgICAgICAgICAgc2l6ZTogeyBzaXplOiAxLCBkYXRhOiBzaXplQXJyYXkgfSxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY29uc3QgcHJvZ3JhbSA9IG5ldyBQcm9ncmFtKGdsLCB7XG4gICAgICAgICAgICB2ZXJ0ZXgsXG4gICAgICAgICAgICBmcmFnbWVudCxcbiAgICAgICAgICAgIHVuaWZvcm1zOiB7XG4gICAgICAgICAgICAgICAgY29sb3I6IHsgdmFsdWU6IGNvbG9yIH0sXG4gICAgICAgICAgICAgICAgd29ybGROb3JtYWxNYXRyaXg6IHsgdmFsdWU6IG5ldyBNYXQzKCkgfSxcbiAgICAgICAgICAgICAgICBvYmplY3RXb3JsZE1hdHJpeDogeyB2YWx1ZTogb2JqZWN0LndvcmxkTWF0cml4IH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcblxuICAgICAgICBzdXBlcihnbCwgeyAuLi5tZXNoUHJvcHMsIG1vZGU6IGdsLkxJTkVTLCBnZW9tZXRyeSwgcHJvZ3JhbSB9KTtcblxuICAgICAgICB0aGlzLm9iamVjdCA9IG9iamVjdDtcbiAgICB9XG5cbiAgICBkcmF3KGFyZykge1xuICAgICAgICB0aGlzLnByb2dyYW0udW5pZm9ybXMud29ybGROb3JtYWxNYXRyaXgudmFsdWUuZ2V0Tm9ybWFsTWF0cml4KHRoaXMub2JqZWN0LndvcmxkTWF0cml4KTtcbiAgICAgICAgc3VwZXIuZHJhdyhhcmcpO1xuICAgIH1cbn1cblxuY29uc3QgdmVydGV4ID0gLyogZ2xzbCAqLyBgXG5hdHRyaWJ1dGUgdmVjMyBwb3NpdGlvbjtcbmF0dHJpYnV0ZSB2ZWMzIG5vcm1hbDtcbmF0dHJpYnV0ZSBmbG9hdCBzaXplO1xuXG51bmlmb3JtIG1hdDQgdmlld01hdHJpeDtcbnVuaWZvcm0gbWF0NCBwcm9qZWN0aW9uTWF0cml4O1xudW5pZm9ybSBtYXQ0IG9iamVjdFdvcmxkTWF0cml4O1xudW5pZm9ybSBtYXQzIHdvcmxkTm9ybWFsTWF0cml4O1xuXG52b2lkIG1haW4oKSB7XG4gICAgdmVjMyBuID0gbm9ybWFsaXplKHdvcmxkTm9ybWFsTWF0cml4ICogbm9ybWFsKSAqIHNpemU7XG4gICAgdmVjMyBwID0gKG9iamVjdFdvcmxkTWF0cml4ICogdmVjNChwb3NpdGlvbiwgMS4wKSkueHl6O1xuICAgIGdsX1Bvc2l0aW9uID0gcHJvamVjdGlvbk1hdHJpeCAqIHZpZXdNYXRyaXggKiB2ZWM0KHAgKyBuLCAxLjApO1xufVxuYDtcblxuY29uc3QgZnJhZ21lbnQgPSAvKiBnbHNsICovIGBcbnByZWNpc2lvbiBoaWdocCBmbG9hdDtcbnVuaWZvcm0gdmVjMyBjb2xvcjtcblxudm9pZCBtYWluKCkgeyAgICBcbiAgICBnbF9GcmFnQ29sb3IgPSB2ZWM0KGNvbG9yLCAxLjApO1xufVxuYDtcbiIsImltcG9ydCB7IE1lc2ggfSBmcm9tICcuLi8uLi9jb3JlL01lc2guanMnO1xuaW1wb3J0IHsgUHJvZ3JhbSB9IGZyb20gJy4uLy4uL2NvcmUvUHJvZ3JhbS5qcyc7XG5pbXBvcnQgeyBHZW9tZXRyeSB9IGZyb20gJy4uLy4uL2NvcmUvR2VvbWV0cnkuanMnO1xuaW1wb3J0IHsgVmVjMyB9IGZyb20gJy4uLy4uL21hdGgvVmVjMy5qcyc7XG5pbXBvcnQgeyBNYXQzIH0gZnJvbSAnLi4vLi4vbWF0aC9NYXQzLmpzJztcblxuY29uc3QgdkEgPSAvKiBAX19QVVJFX18gKi8gbmV3IFZlYzMoKTtcbmNvbnN0IHZCID0gLyogQF9fUFVSRV9fICovIG5ldyBWZWMzKCk7XG5jb25zdCB2QyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgVmVjMygpO1xuY29uc3QgdkNlbnRlciA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgVmVjMygpO1xuY29uc3Qgdk5vcm1hbCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgVmVjMygpO1xuXG5leHBvcnQgY2xhc3MgRmFjZU5vcm1hbHNIZWxwZXIgZXh0ZW5kcyBNZXNoIHtcbiAgICBjb25zdHJ1Y3RvcihvYmplY3QsIHsgc2l6ZSA9IDAuMSwgY29sb3IgPSBuZXcgVmVjMygwLjE1LCAwLjg2LCAwLjg2KSwgLi4ubWVzaFByb3BzIH0gPSB7fSkge1xuICAgICAgICBjb25zdCBnbCA9IG9iamVjdC5nbDtcblxuICAgICAgICBjb25zdCBwb3NpdGlvbkRhdGEgPSBvYmplY3QuZ2VvbWV0cnkuYXR0cmlidXRlcy5wb3NpdGlvbi5kYXRhO1xuICAgICAgICBjb25zdCBzaXplRGF0YSA9IG5ldyBGbG9hdDMyQXJyYXkoWzAsIHNpemVdKTtcblxuICAgICAgICBjb25zdCBpbmRleEF0dHIgPSBvYmplY3QuZ2VvbWV0cnkuYXR0cmlidXRlcy5pbmRleDtcbiAgICAgICAgY29uc3QgZ2V0SW5kZXggPSBpbmRleEF0dHIgPyAoaSkgPT4gaW5kZXhBdHRyLmRhdGFbaV0gOiAoaSkgPT4gaTtcbiAgICAgICAgY29uc3QgbnVtVmVydGljZXMgPSBpbmRleEF0dHIgPyBpbmRleEF0dHIuZGF0YS5sZW5ndGggOiBNYXRoLmZsb29yKHBvc2l0aW9uRGF0YS5sZW5ndGggLyAzKTtcblxuICAgICAgICBjb25zdCBuTm9ybWFscyA9IE1hdGguZmxvb3IobnVtVmVydGljZXMgLyAzKTtcbiAgICAgICAgY29uc3QgcG9zaXRpb25zQXJyYXkgPSBuZXcgRmxvYXQzMkFycmF5KG5Ob3JtYWxzICogMiAqIDMpO1xuICAgICAgICBjb25zdCBub3JtYWxzQXJyYXkgPSBuZXcgRmxvYXQzMkFycmF5KG5Ob3JtYWxzICogMiAqIDMpO1xuICAgICAgICBjb25zdCBzaXplQXJyYXkgPSBuZXcgRmxvYXQzMkFycmF5KG5Ob3JtYWxzICogMik7XG5cbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBudW1WZXJ0aWNlczsgaSArPSAzKSB7XG4gICAgICAgICAgICB2QS5mcm9tQXJyYXkocG9zaXRpb25EYXRhLCBnZXRJbmRleChpICsgMCkgKiAzKTtcbiAgICAgICAgICAgIHZCLmZyb21BcnJheShwb3NpdGlvbkRhdGEsIGdldEluZGV4KGkgKyAxKSAqIDMpO1xuICAgICAgICAgICAgdkMuZnJvbUFycmF5KHBvc2l0aW9uRGF0YSwgZ2V0SW5kZXgoaSArIDIpICogMyk7XG5cbiAgICAgICAgICAgIHZDZW50ZXJcbiAgICAgICAgICAgICAgICAuYWRkKHZBLCB2QilcbiAgICAgICAgICAgICAgICAuYWRkKHZDKVxuICAgICAgICAgICAgICAgIC5tdWx0aXBseSgxIC8gMyk7XG5cbiAgICAgICAgICAgIHZBLnN1Yih2QSwgdkIpO1xuICAgICAgICAgICAgdkMuc3ViKHZDLCB2Qik7XG4gICAgICAgICAgICB2Tm9ybWFsLmNyb3NzKHZDLCB2QSkubm9ybWFsaXplKCk7XG5cbiAgICAgICAgICAgIC8vIGR1cGxpY2F0ZSBwb3NpdGlvbiBhbmQgbm9ybWFsIGZvciBsaW5lIHN0YXJ0IGFuZCBlbmQgcG9pbnRcbiAgICAgICAgICAgIGNvbnN0IGkyID0gaSAqIDI7XG4gICAgICAgICAgICBwb3NpdGlvbnNBcnJheS5zZXQodkNlbnRlciwgaTIpO1xuICAgICAgICAgICAgcG9zaXRpb25zQXJyYXkuc2V0KHZDZW50ZXIsIGkyICsgMyk7XG5cbiAgICAgICAgICAgIG5vcm1hbHNBcnJheS5zZXQodk5vcm1hbCwgaTIpO1xuICAgICAgICAgICAgbm9ybWFsc0FycmF5LnNldCh2Tm9ybWFsLCBpMiArIDMpO1xuICAgICAgICAgICAgc2l6ZUFycmF5LnNldChzaXplRGF0YSwgKGkgLyAzKSAqIDIpO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgZ2VvbWV0cnkgPSBuZXcgR2VvbWV0cnkoZ2wsIHtcbiAgICAgICAgICAgIHBvc2l0aW9uOiB7IHNpemU6IDMsIGRhdGE6IHBvc2l0aW9uc0FycmF5IH0sXG4gICAgICAgICAgICBub3JtYWw6IHsgc2l6ZTogMywgZGF0YTogbm9ybWFsc0FycmF5IH0sXG4gICAgICAgICAgICBzaXplOiB7IHNpemU6IDEsIGRhdGE6IHNpemVBcnJheSB9LFxuICAgICAgICB9KTtcblxuICAgICAgICBjb25zdCBwcm9ncmFtID0gbmV3IFByb2dyYW0oZ2wsIHtcbiAgICAgICAgICAgIHZlcnRleCxcbiAgICAgICAgICAgIGZyYWdtZW50LFxuICAgICAgICAgICAgdW5pZm9ybXM6IHtcbiAgICAgICAgICAgICAgICBjb2xvcjogeyB2YWx1ZTogY29sb3IgfSxcbiAgICAgICAgICAgICAgICB3b3JsZE5vcm1hbE1hdHJpeDogeyB2YWx1ZTogbmV3IE1hdDMoKSB9LFxuICAgICAgICAgICAgICAgIG9iamVjdFdvcmxkTWF0cml4OiB7IHZhbHVlOiBvYmplY3Qud29ybGRNYXRyaXggfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuXG4gICAgICAgIHN1cGVyKGdsLCB7IC4uLm1lc2hQcm9wcywgbW9kZTogZ2wuTElORVMsIGdlb21ldHJ5LCBwcm9ncmFtIH0pO1xuXG4gICAgICAgIHRoaXMub2JqZWN0ID0gb2JqZWN0O1xuICAgIH1cblxuICAgIGRyYXcoYXJnKSB7XG4gICAgICAgIHRoaXMucHJvZ3JhbS51bmlmb3Jtcy53b3JsZE5vcm1hbE1hdHJpeC52YWx1ZS5nZXROb3JtYWxNYXRyaXgodGhpcy5vYmplY3Qud29ybGRNYXRyaXgpO1xuICAgICAgICBzdXBlci5kcmF3KGFyZyk7XG4gICAgfVxufVxuXG5jb25zdCB2ZXJ0ZXggPSAvKiBnbHNsICovIGBcbmF0dHJpYnV0ZSB2ZWMzIHBvc2l0aW9uO1xuYXR0cmlidXRlIHZlYzMgbm9ybWFsO1xuYXR0cmlidXRlIGZsb2F0IHNpemU7XG5cbnVuaWZvcm0gbWF0NCB2aWV3TWF0cml4O1xudW5pZm9ybSBtYXQ0IHByb2plY3Rpb25NYXRyaXg7XG51bmlmb3JtIG1hdDQgb2JqZWN0V29ybGRNYXRyaXg7XG51bmlmb3JtIG1hdDMgd29ybGROb3JtYWxNYXRyaXg7XG5cbnZvaWQgbWFpbigpIHtcbiAgICB2ZWMzIG4gPSBub3JtYWxpemUod29ybGROb3JtYWxNYXRyaXggKiBub3JtYWwpICogc2l6ZTtcbiAgICB2ZWMzIHAgPSAob2JqZWN0V29ybGRNYXRyaXggKiB2ZWM0KHBvc2l0aW9uLCAxLjApKS54eXo7XG4gICAgZ2xfUG9zaXRpb24gPSBwcm9qZWN0aW9uTWF0cml4ICogdmlld01hdHJpeCAqIHZlYzQocCArIG4sIDEuMCk7XG59XG5gO1xuXG5jb25zdCBmcmFnbWVudCA9IC8qIGdsc2wgKi8gYFxucHJlY2lzaW9uIGhpZ2hwIGZsb2F0O1xudW5pZm9ybSB2ZWMzIGNvbG9yO1xuXG52b2lkIG1haW4oKSB7ICAgIFxuICAgIGdsX0ZyYWdDb2xvciA9IHZlYzQoY29sb3IsIDEuMCk7XG59XG5gO1xuIiwiaW1wb3J0IHsgVGV4dHVyZSB9IGZyb20gJy4uL2NvcmUvVGV4dHVyZS5qcyc7XG5cbmV4cG9ydCBjbGFzcyBUZXh0dXJlM0QgZXh0ZW5kcyBUZXh0dXJlIHtcbiAgICBjb25zdHJ1Y3RvcihnbCwgYXJncykge1xuICAgICAgICBzdXBlcihnbCwge1xuICAgICAgICAgICAgLi4uYXJncyxcbiAgICAgICAgICAgIHRhcmdldDogZ2wuVEVYVFVSRV8zRCxcbiAgICAgICAgICAgIHdpZHRoOiBhcmdzLndpZHRoID8gYXJncy53aWR0aCA6IDIsXG4gICAgICAgICAgICBoZWlnaHQ6IGFyZ3MuaGVpZ2h0ID8gYXJncy5oZWlnaHQgOiAyLFxuICAgICAgICB9KTtcblxuICAgICAgICBjb25zdCBpbWFnZSA9IG5ldyBJbWFnZSgpO1xuICAgICAgICBpbWFnZS5jcm9zc09yaWdpbiA9ICcqJztcbiAgICAgICAgaW1hZ2Uuc3JjID0gYXJncy5zcmM7XG5cbiAgICAgICAgaW1hZ2Uub25sb2FkID0gKCkgPT4ge1xuICAgICAgICAgICAgbGV0IGNhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpO1xuICAgICAgICAgICAgY2FudmFzLndpZHRoID0gaW1hZ2Uud2lkdGg7XG4gICAgICAgICAgICBjYW52YXMuaGVpZ2h0ID0gaW1hZ2UuaGVpZ2h0O1xuXG4gICAgICAgICAgICBsZXQgY3R4ID0gY2FudmFzLmdldENvbnRleHQoJzJkJyk7XG4gICAgICAgICAgICBjdHguc2NhbGUoMSwgLTEpO1xuICAgICAgICAgICAgY3R4LnRyYW5zbGF0ZSgwLCAtaW1hZ2UuaGVpZ2h0KTtcbiAgICAgICAgICAgIGN0eC5kcmF3SW1hZ2UoaW1hZ2UsIDAsIDApO1xuICAgICAgICAgICAgY29uc3QgaW1hZ2VEYXRhID0gY3R4LmdldEltYWdlRGF0YSgwLCAwLCBpbWFnZS53aWR0aCwgaW1hZ2UuaGVpZ2h0KS5kYXRhO1xuXG4gICAgICAgICAgICBjYW52YXMgPSBudWxsO1xuICAgICAgICAgICAgY3R4ID0gbnVsbDtcbiAgICAgICAgICAgIGxldCBlbGVtZW50Q291bnQ7XG5cbiAgICAgICAgICAgIHN3aXRjaCAodGhpcy5mb3JtYXQpIHtcbiAgICAgICAgICAgICAgICBjYXNlIGdsLlJFRDpcbiAgICAgICAgICAgICAgICAgICAgZWxlbWVudENvdW50ID0gMTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSBnbC5SRzpcbiAgICAgICAgICAgICAgICAgICAgZWxlbWVudENvdW50ID0gMjtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSBnbC5SR0I6XG4gICAgICAgICAgICAgICAgICAgIGVsZW1lbnRDb3VudCA9IDM7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIGVsZW1lbnRDb3VudCA9IDQ7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBjb25zdCBkYXRhQ291bnQgPSB0aGlzLndpZHRoICogdGhpcy5oZWlnaHQgKiB0aGlzLmxlbmd0aCAqIGVsZW1lbnRDb3VudDtcbiAgICAgICAgICAgIGNvbnN0IGRhdGEgPSB0aGlzLnR5cGUgPT09IGdsLlVOU0lHTkVEX0JZVEUgPyBuZXcgVWludDhBcnJheShkYXRhQ291bnQpIDogbmV3IEZsb2F0MzJBcnJheShkYXRhQ291bnQpO1xuXG4gICAgICAgICAgICBsZXQgZGF0YUl0ZXJhdG9yID0gMDtcblxuICAgICAgICAgICAgZm9yIChsZXQgeiA9IDA7IHogPCB0aGlzLmxlbmd0aDsgeisrKSB7XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgeSA9IDA7IHkgPCB0aGlzLmhlaWdodDsgeSsrKSB7XG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IHggPSAwOyB4IDwgdGhpcy53aWR0aDsgeCsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgek9mZnNldFggPSAoeiAlIGFyZ3MudGlsZUNvdW50WCkgKiB0aGlzLndpZHRoO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHpPZmZzZXRZID0gTWF0aC5mbG9vcih6IC8gYXJncy50aWxlQ291bnRYKSAqICh0aGlzLndpZHRoICogdGhpcy5oZWlnaHQgKiBhcmdzLnRpbGVDb3VudFgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGluZGV4ID0geCArIHpPZmZzZXRYICsgKHkgKiBpbWFnZS53aWR0aCArIHpPZmZzZXRZKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgciA9IGltYWdlRGF0YVtpbmRleCAqIDRdO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZyA9IGltYWdlRGF0YVtpbmRleCAqIDQgKyAxXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGIgPSBpbWFnZURhdGFbaW5kZXggKiA0ICsgMl07XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBhID0gaW1hZ2VEYXRhW2luZGV4ICogNCArIDNdO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgdGV4ZWwgPSBbciwgZywgYiwgYV07XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZWxlbWVudENvdW50OyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy50eXBlID09PSB0aGlzLmdsLlVOU0lHTkVEX0JZVEUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YVtkYXRhSXRlcmF0b3IrK10gPSB0ZXhlbFtpXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhW2RhdGFJdGVyYXRvcisrXSA9IHRleGVsW2ldIC8gMjU1O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdGhpcy5pbWFnZSA9IGRhdGE7XG4gICAgICAgICAgICB0aGlzLm5lZWRzVXBkYXRlID0gdHJ1ZTtcbiAgICAgICAgfTtcbiAgICB9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFRQSxTQUFnQkEsU0FBTyxHQUFHO0NBQ3RCLElBQUksSUFBSSxFQUFFO0NBQ1YsSUFBSSxJQUFJLEVBQUU7Q0FDVixJQUFJLElBQUksRUFBRTtDQUNWLE9BQU8sS0FBSyxLQUFLLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDO0FBQzFDOzs7Ozs7OztBQVNBLFNBQWdCQyxPQUFLLEtBQUssR0FBRztDQUN6QixJQUFJLEtBQUssRUFBRTtDQUNYLElBQUksS0FBSyxFQUFFO0NBQ1gsSUFBSSxLQUFLLEVBQUU7Q0FDWCxPQUFPO0FBQ1g7Ozs7Ozs7Ozs7QUFXQSxTQUFnQkMsTUFBSSxLQUFLLEdBQUcsR0FBRyxHQUFHO0NBQzlCLElBQUksS0FBSztDQUNULElBQUksS0FBSztDQUNULElBQUksS0FBSztDQUNULE9BQU87QUFDWDs7Ozs7Ozs7O0FBVUEsU0FBZ0JDLE1BQUksS0FBSyxHQUFHLEdBQUc7Q0FDM0IsSUFBSSxLQUFLLEVBQUUsS0FBSyxFQUFFO0NBQ2xCLElBQUksS0FBSyxFQUFFLEtBQUssRUFBRTtDQUNsQixJQUFJLEtBQUssRUFBRSxLQUFLLEVBQUU7Q0FDbEIsT0FBTztBQUNYOzs7Ozs7Ozs7QUFVQSxTQUFnQkMsV0FBUyxLQUFLLEdBQUcsR0FBRztDQUNoQyxJQUFJLEtBQUssRUFBRSxLQUFLLEVBQUU7Q0FDbEIsSUFBSSxLQUFLLEVBQUUsS0FBSyxFQUFFO0NBQ2xCLElBQUksS0FBSyxFQUFFLEtBQUssRUFBRTtDQUNsQixPQUFPO0FBQ1g7Ozs7Ozs7OztBQVVBLFNBQWdCQyxXQUFTLEtBQUssR0FBRyxHQUFHO0NBQ2hDLElBQUksS0FBSyxFQUFFLEtBQUssRUFBRTtDQUNsQixJQUFJLEtBQUssRUFBRSxLQUFLLEVBQUU7Q0FDbEIsSUFBSSxLQUFLLEVBQUUsS0FBSyxFQUFFO0NBQ2xCLE9BQU87QUFDWDs7Ozs7Ozs7O0FBVUEsU0FBZ0JDLFNBQU8sS0FBSyxHQUFHLEdBQUc7Q0FDOUIsSUFBSSxLQUFLLEVBQUUsS0FBSyxFQUFFO0NBQ2xCLElBQUksS0FBSyxFQUFFLEtBQUssRUFBRTtDQUNsQixJQUFJLEtBQUssRUFBRSxLQUFLLEVBQUU7Q0FDbEIsT0FBTztBQUNYOzs7Ozs7Ozs7QUFVQSxTQUFnQkMsUUFBTSxLQUFLLEdBQUcsR0FBRztDQUM3QixJQUFJLEtBQUssRUFBRSxLQUFLO0NBQ2hCLElBQUksS0FBSyxFQUFFLEtBQUs7Q0FDaEIsSUFBSSxLQUFLLEVBQUUsS0FBSztDQUNoQixPQUFPO0FBQ1g7Ozs7Ozs7O0FBU0EsU0FBZ0JDLFdBQVMsR0FBRyxHQUFHO0NBQzNCLElBQUksSUFBSSxFQUFFLEtBQUssRUFBRTtDQUNqQixJQUFJLElBQUksRUFBRSxLQUFLLEVBQUU7Q0FDakIsSUFBSSxJQUFJLEVBQUUsS0FBSyxFQUFFO0NBQ2pCLE9BQU8sS0FBSyxLQUFLLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDO0FBQzFDOzs7Ozs7OztBQVNBLFNBQWdCQyxrQkFBZ0IsR0FBRyxHQUFHO0NBQ2xDLElBQUksSUFBSSxFQUFFLEtBQUssRUFBRTtDQUNqQixJQUFJLElBQUksRUFBRSxLQUFLLEVBQUU7Q0FDakIsSUFBSSxJQUFJLEVBQUUsS0FBSyxFQUFFO0NBQ2pCLE9BQU8sSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJO0FBQy9COzs7Ozs7O0FBUUEsU0FBZ0JDLGdCQUFjLEdBQUc7Q0FDN0IsSUFBSSxJQUFJLEVBQUU7Q0FDVixJQUFJLElBQUksRUFBRTtDQUNWLElBQUksSUFBSSxFQUFFO0NBQ1YsT0FBTyxJQUFJLElBQUksSUFBSSxJQUFJLElBQUk7QUFDL0I7Ozs7Ozs7O0FBU0EsU0FBZ0JDLFNBQU8sS0FBSyxHQUFHO0NBQzNCLElBQUksS0FBSyxDQUFDLEVBQUU7Q0FDWixJQUFJLEtBQUssQ0FBQyxFQUFFO0NBQ1osSUFBSSxLQUFLLENBQUMsRUFBRTtDQUNaLE9BQU87QUFDWDs7Ozs7Ozs7QUFTQSxTQUFnQkMsVUFBUSxLQUFLLEdBQUc7Q0FDNUIsSUFBSSxLQUFLLElBQU0sRUFBRTtDQUNqQixJQUFJLEtBQUssSUFBTSxFQUFFO0NBQ2pCLElBQUksS0FBSyxJQUFNLEVBQUU7Q0FDakIsT0FBTztBQUNYOzs7Ozs7OztBQVNBLFNBQWdCQyxZQUFVLEtBQUssR0FBRztDQUM5QixJQUFJLElBQUksRUFBRTtDQUNWLElBQUksSUFBSSxFQUFFO0NBQ1YsSUFBSSxJQUFJLEVBQUU7Q0FDVixJQUFJLE1BQU0sSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJO0NBQzlCLElBQUksTUFBTSxHQUVOLE1BQU0sSUFBSSxLQUFLLEtBQUssR0FBRztDQUUzQixJQUFJLEtBQUssRUFBRSxLQUFLO0NBQ2hCLElBQUksS0FBSyxFQUFFLEtBQUs7Q0FDaEIsSUFBSSxLQUFLLEVBQUUsS0FBSztDQUNoQixPQUFPO0FBQ1g7Ozs7Ozs7O0FBU0EsU0FBZ0JDLE1BQUksR0FBRyxHQUFHO0NBQ3RCLE9BQU8sRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFO0FBQ2hEOzs7Ozs7Ozs7QUFVQSxTQUFnQkMsUUFBTSxLQUFLLEdBQUcsR0FBRztDQUM3QixJQUFJLEtBQUssRUFBRSxJQUNQLEtBQUssRUFBRSxJQUNQLEtBQUssRUFBRTtDQUNYLElBQUksS0FBSyxFQUFFLElBQ1AsS0FBSyxFQUFFLElBQ1AsS0FBSyxFQUFFO0NBRVgsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLO0NBQ3hCLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSztDQUN4QixJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUs7Q0FDeEIsT0FBTztBQUNYOzs7Ozs7Ozs7O0FBV0EsU0FBZ0JDLE9BQUssS0FBSyxHQUFHLEdBQUcsR0FBRztDQUMvQixJQUFJLEtBQUssRUFBRTtDQUNYLElBQUksS0FBSyxFQUFFO0NBQ1gsSUFBSSxLQUFLLEVBQUU7Q0FDWCxJQUFJLEtBQUssS0FBSyxLQUFLLEVBQUUsS0FBSztDQUMxQixJQUFJLEtBQUssS0FBSyxLQUFLLEVBQUUsS0FBSztDQUMxQixJQUFJLEtBQUssS0FBSyxLQUFLLEVBQUUsS0FBSztDQUMxQixPQUFPO0FBQ1g7Ozs7Ozs7Ozs7O0FBWUEsU0FBZ0JDLGFBQVcsS0FBSyxHQUFHLEdBQUcsT0FBTyxJQUFJO0NBQzdDLE1BQU0sTUFBTSxLQUFLLElBQUksQ0FBQyxRQUFRLEVBQUU7Q0FDaEMsSUFBSSxLQUFLLEVBQUU7Q0FDWCxJQUFJLEtBQUssRUFBRTtDQUNYLElBQUksS0FBSyxFQUFFO0NBRVgsSUFBSSxLQUFLLEVBQUUsTUFBTSxLQUFLLEVBQUUsTUFBTTtDQUM5QixJQUFJLEtBQUssRUFBRSxNQUFNLEtBQUssRUFBRSxNQUFNO0NBQzlCLElBQUksS0FBSyxFQUFFLE1BQU0sS0FBSyxFQUFFLE1BQU07Q0FDOUIsT0FBTztBQUNYOzs7Ozs7Ozs7O0FBV0EsU0FBZ0JDLGdCQUFjLEtBQUssR0FBRyxHQUFHO0NBQ3JDLElBQUksSUFBSSxFQUFFLElBQ04sSUFBSSxFQUFFLElBQ04sSUFBSSxFQUFFO0NBQ1YsSUFBSSxJQUFJLEVBQUUsS0FBSyxJQUFJLEVBQUUsS0FBSyxJQUFJLEVBQUUsTUFBTSxJQUFJLEVBQUU7Q0FDNUMsSUFBSSxLQUFLO0NBQ1QsSUFBSSxNQUFNLEVBQUUsS0FBSyxJQUFJLEVBQUUsS0FBSyxJQUFJLEVBQUUsS0FBSyxJQUFJLEVBQUUsT0FBTztDQUNwRCxJQUFJLE1BQU0sRUFBRSxLQUFLLElBQUksRUFBRSxLQUFLLElBQUksRUFBRSxLQUFLLElBQUksRUFBRSxPQUFPO0NBQ3BELElBQUksTUFBTSxFQUFFLEtBQUssSUFBSSxFQUFFLEtBQUssSUFBSSxFQUFFLE1BQU0sSUFBSSxFQUFFLE9BQU87Q0FDckQsT0FBTztBQUNYOzs7OztBQU1BLFNBQWdCLGdCQUFnQixLQUFLLEdBQUcsR0FBRztDQUN2QyxJQUFJLElBQUksRUFBRSxJQUNOLElBQUksRUFBRSxJQUNOLElBQUksRUFBRTtDQUNWLElBQUksSUFBSSxFQUFFLEtBQUssSUFBSSxFQUFFLEtBQUssSUFBSSxFQUFFLE1BQU0sSUFBSSxFQUFFO0NBQzVDLElBQUksS0FBSztDQUNULElBQUksTUFBTSxFQUFFLEtBQUssSUFBSSxFQUFFLEtBQUssSUFBSSxFQUFFLEtBQUssS0FBSztDQUM1QyxJQUFJLE1BQU0sRUFBRSxLQUFLLElBQUksRUFBRSxLQUFLLElBQUksRUFBRSxLQUFLLEtBQUs7Q0FDNUMsSUFBSSxNQUFNLEVBQUUsS0FBSyxJQUFJLEVBQUUsS0FBSyxJQUFJLEVBQUUsTUFBTSxLQUFLO0NBQzdDLE9BQU87QUFDWDs7Ozs7Ozs7O0FBVUEsU0FBZ0JDLGdCQUFjLEtBQUssR0FBRyxHQUFHO0NBQ3JDLElBQUksSUFBSSxFQUFFLElBQ04sSUFBSSxFQUFFLElBQ04sSUFBSSxFQUFFO0NBQ1YsSUFBSSxLQUFLLElBQUksRUFBRSxLQUFLLElBQUksRUFBRSxLQUFLLElBQUksRUFBRTtDQUNyQyxJQUFJLEtBQUssSUFBSSxFQUFFLEtBQUssSUFBSSxFQUFFLEtBQUssSUFBSSxFQUFFO0NBQ3JDLElBQUksS0FBSyxJQUFJLEVBQUUsS0FBSyxJQUFJLEVBQUUsS0FBSyxJQUFJLEVBQUU7Q0FDckMsT0FBTztBQUNYOzs7Ozs7Ozs7QUFVQSxTQUFnQixjQUFjLEtBQUssR0FBRyxHQUFHO0NBR3JDLElBQUksSUFBSSxFQUFFLElBQ04sSUFBSSxFQUFFLElBQ04sSUFBSSxFQUFFO0NBQ1YsSUFBSSxLQUFLLEVBQUUsSUFDUCxLQUFLLEVBQUUsSUFDUCxLQUFLLEVBQUUsSUFDUCxLQUFLLEVBQUU7Q0FFWCxJQUFJLE1BQU0sS0FBSyxJQUFJLEtBQUs7Q0FDeEIsSUFBSSxNQUFNLEtBQUssSUFBSSxLQUFLO0NBQ3hCLElBQUksTUFBTSxLQUFLLElBQUksS0FBSztDQUV4QixJQUFJLE9BQU8sS0FBSyxNQUFNLEtBQUs7Q0FDM0IsSUFBSSxPQUFPLEtBQUssTUFBTSxLQUFLO0NBQzNCLElBQUksT0FBTyxLQUFLLE1BQU0sS0FBSztDQUUzQixJQUFJLEtBQUssS0FBSztDQUNkLE9BQU87Q0FDUCxPQUFPO0NBQ1AsT0FBTztDQUVQLFFBQVE7Q0FDUixRQUFRO0NBQ1IsUUFBUTtDQUVSLElBQUksS0FBSyxJQUFJLE1BQU07Q0FDbkIsSUFBSSxLQUFLLElBQUksTUFBTTtDQUNuQixJQUFJLEtBQUssSUFBSSxNQUFNO0NBQ25CLE9BQU87QUFDWDs7Ozs7OztBQVFBLElBQWEsU0FBUyxXQUFZO0NBQzlCLE1BQU0sUUFBUTtFQUFDO0VBQUc7RUFBRztDQUFDO0NBQ3RCLE1BQU0sUUFBUTtFQUFDO0VBQUc7RUFBRztDQUFDO0NBRXRCLE9BQU8sU0FBVSxHQUFHLEdBQUc7RUFDbkIsT0FBSyxPQUFPLENBQUM7RUFDYixPQUFLLE9BQU8sQ0FBQztFQUViLFlBQVUsT0FBTyxLQUFLO0VBQ3RCLFlBQVUsT0FBTyxLQUFLO0VBRXRCLElBQUksU0FBU0wsTUFBSSxPQUFPLEtBQUs7RUFFN0IsSUFBSSxTQUFTLEdBQ1QsT0FBTztPQUNKLElBQUksU0FBUyxJQUNoQixPQUFPLEtBQUs7T0FFWixPQUFPLEtBQUssS0FBSyxNQUFNO0NBRS9CO0FBQ0osRUFBQSxDQUFHOzs7Ozs7OztBQVNILFNBQWdCTSxjQUFZLEdBQUcsR0FBRztDQUM5QixPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRTtBQUN4RDs7O0FDbGFBLElBQWEsT0FBYixNQUFhLGFBQWEsTUFBTTtDQUM1QixZQUFZLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxHQUFHO0VBQzdCLE1BQU0sR0FBRyxHQUFHLENBQUM7RUFDYixPQUFPO0NBQ1g7Q0FFQSxJQUFJLElBQUk7RUFDSixPQUFPLEtBQUs7Q0FDaEI7Q0FFQSxJQUFJLElBQUk7RUFDSixPQUFPLEtBQUs7Q0FDaEI7Q0FFQSxJQUFJLElBQUk7RUFDSixPQUFPLEtBQUs7Q0FDaEI7Q0FFQSxJQUFJLEVBQUUsR0FBRztFQUNMLEtBQUssS0FBSztDQUNkO0NBRUEsSUFBSSxFQUFFLEdBQUc7RUFDTCxLQUFLLEtBQUs7Q0FDZDtDQUVBLElBQUksRUFBRSxHQUFHO0VBQ0wsS0FBSyxLQUFLO0NBQ2Q7Q0FFQSxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksR0FBRztFQUNqQixJQUFJLEVBQUUsUUFBUSxPQUFPLEtBQUssS0FBSyxDQUFDO0VBQ2hDLE1BQWEsTUFBTSxHQUFHLEdBQUcsQ0FBQztFQUMxQixPQUFPO0NBQ1g7Q0FFQSxLQUFLLEdBQUc7RUFDSixPQUFjLE1BQU0sQ0FBQztFQUNyQixPQUFPO0NBQ1g7Q0FFQSxJQUFJLElBQUksSUFBSTtFQUNSLElBQUksSUFBSSxNQUFhLE1BQU0sSUFBSSxFQUFFO09BQzVCLE1BQWEsTUFBTSxNQUFNLEVBQUU7RUFDaEMsT0FBTztDQUNYO0NBRUEsSUFBSSxJQUFJLElBQUk7RUFDUixJQUFJLElBQUksV0FBa0IsTUFBTSxJQUFJLEVBQUU7T0FDakMsV0FBa0IsTUFBTSxNQUFNLEVBQUU7RUFDckMsT0FBTztDQUNYO0NBRUEsU0FBUyxHQUFHO0VBQ1IsSUFBSSxFQUFFLFFBQVEsV0FBa0IsTUFBTSxNQUFNLENBQUM7T0FDeEMsUUFBZSxNQUFNLE1BQU0sQ0FBQztFQUNqQyxPQUFPO0NBQ1g7Q0FFQSxPQUFPLEdBQUc7RUFDTixJQUFJLEVBQUUsUUFBUSxTQUFnQixNQUFNLE1BQU0sQ0FBQztPQUN0QyxRQUFlLE1BQU0sTUFBTSxJQUFJLENBQUM7RUFDckMsT0FBTztDQUNYO0NBRUEsUUFBUSxJQUFJLE1BQU07RUFDZCxVQUFpQixNQUFNLENBQUM7RUFDeEIsT0FBTztDQUNYO0NBR0EsTUFBTTtFQUNGLE9BQU9DLFNBQWdCLElBQUk7Q0FDL0I7Q0FFQSxTQUFTLEdBQUc7RUFDUixJQUFJLEdBQUcsT0FBT0MsV0FBa0IsTUFBTSxDQUFDO09BQ2xDLE9BQU9ELFNBQWdCLElBQUk7Q0FDcEM7Q0FFQSxhQUFhO0VBQ1QsT0FBT0UsZ0JBQXVCLElBQUk7Q0FDdEM7Q0FFQSxnQkFBZ0IsR0FBRztFQUNmLElBQUksR0FBRyxPQUFPQyxrQkFBeUIsTUFBTSxDQUFDO09BQ3pDLE9BQU9ELGdCQUF1QixJQUFJO0NBQzNDO0NBRUEsT0FBTyxJQUFJLE1BQU07RUFDYixTQUFnQixNQUFNLENBQUM7RUFDdkIsT0FBTztDQUNYO0NBRUEsTUFBTSxJQUFJLElBQUk7RUFDVixJQUFJLElBQUksUUFBZSxNQUFNLElBQUksRUFBRTtPQUM5QixRQUFlLE1BQU0sTUFBTSxFQUFFO0VBQ2xDLE9BQU87Q0FDWDtDQUVBLE1BQU0sR0FBRztFQUNMLFFBQWUsTUFBTSxNQUFNLENBQUM7RUFDNUIsT0FBTztDQUNYO0NBRUEsWUFBWTtFQUNSLFlBQW1CLE1BQU0sSUFBSTtFQUM3QixPQUFPO0NBQ1g7Q0FFQSxJQUFJLEdBQUc7RUFDSCxPQUFPRSxNQUFhLE1BQU0sQ0FBQztDQUMvQjtDQUVBLE9BQU8sR0FBRztFQUNOLE9BQU9DLGNBQXFCLE1BQU0sQ0FBQztDQUN2QztDQUVBLGFBQWEsTUFBTTtFQUNmLGdCQUF1QixNQUFNLE1BQU0sSUFBSTtFQUN2QyxPQUFPO0NBQ1g7Q0FFQSxhQUFhLE1BQU07RUFDZixnQkFBdUIsTUFBTSxNQUFNLElBQUk7RUFDdkMsT0FBTztDQUNYO0NBRUEsbUJBQW1CLE1BQU07RUFDckIsZ0JBQXlCLE1BQU0sTUFBTSxJQUFJO0VBQ3pDLE9BQU87Q0FDWDtDQUVBLGdCQUFnQixHQUFHO0VBQ2YsY0FBdUIsTUFBTSxNQUFNLENBQUM7RUFDcEMsT0FBTztDQUNYO0NBRUEsTUFBTSxHQUFHO0VBQ0wsT0FBT0MsTUFBZSxNQUFNLENBQUM7Q0FDakM7Q0FFQSxLQUFLLEdBQUcsR0FBRztFQUNQLE9BQWMsTUFBTSxNQUFNLEdBQUcsQ0FBQztFQUM5QixPQUFPO0NBQ1g7Q0FFQSxXQUFXLEdBQUcsT0FBTyxJQUFJO0VBQ3JCLGFBQW9CLE1BQU0sTUFBTSxHQUFHLE9BQU8sRUFBRTtFQUM1QyxPQUFPO0NBQ1g7Q0FFQSxRQUFRO0VBQ0osT0FBTyxJQUFJLEtBQUssS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLEVBQUU7Q0FDN0M7Q0FFQSxVQUFVLEdBQUcsSUFBSSxHQUFHO0VBQ2hCLEtBQUssS0FBSyxFQUFFO0VBQ1osS0FBSyxLQUFLLEVBQUUsSUFBSTtFQUNoQixLQUFLLEtBQUssRUFBRSxJQUFJO0VBQ2hCLE9BQU87Q0FDWDtDQUVBLFFBQVEsSUFBSSxDQUFDLEdBQUcsSUFBSSxHQUFHO0VBQ25CLEVBQUUsS0FBSyxLQUFLO0VBQ1osRUFBRSxJQUFJLEtBQUssS0FBSztFQUNoQixFQUFFLElBQUksS0FBSyxLQUFLO0VBQ2hCLE9BQU87Q0FDWDtDQUVBLG1CQUFtQixNQUFNO0VBQ3JCLE1BQU0sSUFBSSxLQUFLO0VBQ2YsTUFBTSxJQUFJLEtBQUs7RUFDZixNQUFNLElBQUksS0FBSztFQUVmLEtBQUssS0FBSyxLQUFLLEtBQUssSUFBSSxLQUFLLEtBQUssSUFBSSxLQUFLLEtBQUs7RUFDaEQsS0FBSyxLQUFLLEtBQUssS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJLEtBQUssS0FBSztFQUNoRCxLQUFLLEtBQUssS0FBSyxLQUFLLElBQUksS0FBSyxLQUFLLElBQUksS0FBSyxNQUFNO0VBRWpELE9BQU8sS0FBSyxVQUFVO0NBQzFCO0FBQ0o7OztBQ25LQSxJQUFNQyw2QkFBMkIsSUFBSSxLQUFLO0FBRTFDLElBQUlDLE9BQUs7QUFDVCxJQUFJLFVBQVU7QUFHZCxJQUFJLGlCQUFpQjtBQUVyQixJQUFhLFdBQWIsTUFBc0I7Q0FDbEIsWUFBWSxJQUFJLGFBQWEsQ0FBQyxHQUFHO0VBQzdCLElBQUksQ0FBQyxHQUFHLFFBQVEsUUFBUSxNQUFNLDZDQUE2QztFQUMzRSxLQUFLLEtBQUs7RUFDVixLQUFLLGFBQWE7RUFDbEIsS0FBSyxLQUFLO0VBR1YsS0FBSyxPQUFPLENBQUM7RUFFYixLQUFLLFlBQVk7R0FBRSxPQUFPO0dBQUcsT0FBTztFQUFFO0VBQ3RDLEtBQUssaUJBQWlCO0VBR3RCLEtBQUssR0FBRyxTQUFTLGdCQUFnQixJQUFJO0VBQ3JDLEtBQUssR0FBRyxTQUFTLGtCQUFrQjtFQUduQyxLQUFLLFVBQVUsS0FBSyxHQUFHLFNBQVM7RUFHaEMsS0FBSyxJQUFJLE9BQU8sWUFDWixLQUFLLGFBQWEsS0FBSyxXQUFXLElBQUk7Q0FFOUM7Q0FFQSxhQUFhLEtBQUssTUFBTTtFQUNwQixLQUFLLFdBQVcsT0FBTztFQUd2QixLQUFLLEtBQUs7RUFDVixLQUFLLE9BQU8sS0FBSyxRQUFRO0VBQ3pCLEtBQUssT0FDRCxLQUFLLFNBQ0osS0FBSyxLQUFLLGdCQUFnQixlQUNyQixLQUFLLEdBQUcsUUFDUixLQUFLLEtBQUssZ0JBQWdCLGNBQzFCLEtBQUssR0FBRyxpQkFDUixLQUFLLEdBQUc7RUFDbEIsS0FBSyxTQUFTLFFBQVEsVUFBVSxLQUFLLEdBQUcsdUJBQXVCLEtBQUssR0FBRztFQUN2RSxLQUFLLGFBQWEsS0FBSyxjQUFjO0VBQ3JDLEtBQUssU0FBUyxLQUFLLFVBQVU7RUFDN0IsS0FBSyxTQUFTLEtBQUssVUFBVTtFQUM3QixLQUFLLFFBQVEsS0FBSyxVQUFVLEtBQUssU0FBUyxLQUFLLEtBQUssYUFBYSxLQUFLLFNBQVMsS0FBSyxLQUFLLFNBQVMsS0FBSztFQUN2RyxLQUFLLFVBQVUsS0FBSyxhQUFhO0VBQ2pDLEtBQUssY0FBYztFQUNuQixLQUFLLFFBQVEsS0FBSyxTQUFTLEtBQUssR0FBRztFQUVuQyxJQUFJLENBQUMsS0FBSyxRQUVOLEtBQUssZ0JBQWdCLElBQUk7RUFJN0IsSUFBSSxLQUFLLFNBQVM7R0FDZCxLQUFLLGNBQWM7R0FDbkIsSUFBSSxLQUFLLGtCQUFrQixLQUFLLG1CQUFtQixLQUFLLFFBQVEsS0FBSyxTQUFTO0lBQzFFLFFBQVEsS0FBSyw2REFBNkQ7SUFDMUUsT0FBUSxLQUFLLGlCQUFpQixLQUFLLElBQUksS0FBSyxnQkFBZ0IsS0FBSyxRQUFRLEtBQUssT0FBTztHQUN6RjtHQUNBLEtBQUssaUJBQWlCLEtBQUssUUFBUSxLQUFLO0VBQzVDLE9BQU8sSUFBSSxRQUFRLFNBQ2YsS0FBSyxVQUFVLFFBQVEsS0FBSztPQUN6QixJQUFJLENBQUMsS0FBSyxXQUFXLE9BQ3hCLEtBQUssVUFBVSxRQUFRLEtBQUssSUFBSSxLQUFLLFVBQVUsT0FBTyxLQUFLLEtBQUs7Q0FFeEU7Q0FFQSxnQkFBZ0IsTUFBTTtFQUNsQixNQUFNLGNBQWMsQ0FBQyxLQUFLO0VBQzFCLElBQUksYUFBYSxLQUFLLFNBQVMsS0FBSyxHQUFHLGFBQWE7RUFDcEQsSUFBSSxLQUFLLFFBQVEsZ0JBQWdCLEtBQUssUUFBUTtHQUMxQyxLQUFLLEdBQUcsV0FBVyxLQUFLLFFBQVEsS0FBSyxNQUFNO0dBQzNDLEtBQUssUUFBUSxjQUFjLEtBQUs7RUFDcEM7RUFDQSxJQUFJLGFBQ0EsS0FBSyxHQUFHLFdBQVcsS0FBSyxRQUFRLEtBQUssTUFBTSxLQUFLLEtBQUs7T0FFckQsS0FBSyxHQUFHLGNBQWMsS0FBSyxRQUFRLEdBQUcsS0FBSyxJQUFJO0VBRW5ELEtBQUssY0FBYztDQUN2QjtDQUVBLFNBQVMsT0FBTztFQUNaLEtBQUssYUFBYSxTQUFTLEtBQUs7Q0FDcEM7Q0FFQSxhQUFhLE9BQU8sT0FBTztFQUN2QixLQUFLLFVBQVUsUUFBUTtFQUN2QixLQUFLLFVBQVUsUUFBUTtDQUMzQjtDQUVBLGtCQUFrQixPQUFPO0VBQ3JCLEtBQUssaUJBQWlCO0NBQzFCO0NBRUEsVUFBVSxTQUFTO0VBQ2YsS0FBSyxLQUFLLFFBQVEsa0JBQWtCLEtBQUssR0FBRyxTQUFTLGtCQUFrQjtFQUN2RSxLQUFLLEdBQUcsU0FBUyxnQkFBZ0IsS0FBSyxLQUFLLFFBQVEsZUFBZTtFQUNsRSxLQUFLLGVBQWUsT0FBTztDQUMvQjtDQUVBLGVBQWUsU0FBUztFQUVwQixRQUFRLG1CQUFtQixTQUFTLFVBQVUsRUFBRSxNQUFNLFdBQVc7R0FFN0QsSUFBSSxDQUFDLEtBQUssV0FBVyxPQUFPO0lBQ3hCLFFBQVEsS0FBSyxvQkFBb0IsS0FBSyxvQkFBb0I7SUFDMUQ7R0FDSjtHQUVBLE1BQU0sT0FBTyxLQUFLLFdBQVc7R0FFN0IsS0FBSyxHQUFHLFdBQVcsS0FBSyxRQUFRLEtBQUssTUFBTTtHQUMzQyxLQUFLLFFBQVEsY0FBYyxLQUFLO0dBR2hDLElBQUksU0FBUztHQUNiLElBQUksU0FBUyxPQUFPLFNBQVM7R0FDN0IsSUFBSSxTQUFTLE9BQU8sU0FBUztHQUM3QixJQUFJLFNBQVMsT0FBTyxTQUFTO0dBRTdCLE1BQU0sT0FBTyxLQUFLLE9BQU87R0FDekIsTUFBTSxTQUFTLFdBQVcsSUFBSSxJQUFJLFNBQVMsU0FBUztHQUNwRCxNQUFNLFNBQVMsV0FBVyxJQUFJLElBQUksU0FBUztHQUUzQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxLQUFLO0lBQzdCLEtBQUssR0FBRyxvQkFBb0IsV0FBVyxHQUFHLE1BQU0sS0FBSyxNQUFNLEtBQUssWUFBWSxLQUFLLFNBQVMsUUFBUSxLQUFLLFNBQVMsSUFBSSxNQUFNO0lBQzFILEtBQUssR0FBRyx3QkFBd0IsV0FBVyxDQUFDO0lBSTVDLEtBQUssR0FBRyxTQUFTLG9CQUFvQixXQUFXLEdBQUcsS0FBSyxPQUFPO0dBQ25FO0VBQ0osQ0FBQztFQUdELElBQUksS0FBSyxXQUFXLE9BQU8sS0FBSyxHQUFHLFdBQVcsS0FBSyxHQUFHLHNCQUFzQixLQUFLLFdBQVcsTUFBTSxNQUFNO0NBQzVHO0NBRUEsS0FBSyxFQUFFLFNBQVMsT0FBTyxLQUFLLEdBQUcsYUFBYTtFQUN4QyxJQUFJLEtBQUssR0FBRyxTQUFTLG9CQUFvQixHQUFHLEtBQUssR0FBRyxHQUFHLFFBQVEsa0JBQWtCO0dBQzdFLElBQUksQ0FBQyxLQUFLLEtBQUssUUFBUSxpQkFBaUIsS0FBSyxVQUFVLE9BQU87R0FDOUQsS0FBSyxHQUFHLFNBQVMsZ0JBQWdCLEtBQUssS0FBSyxRQUFRLGVBQWU7R0FDbEUsS0FBSyxHQUFHLFNBQVMsa0JBQWtCLEdBQUcsS0FBSyxHQUFHLEdBQUcsUUFBUTtFQUM3RDtFQUdBLFFBQVEsbUJBQW1CLFNBQVMsVUFBVSxFQUFFLFdBQVc7R0FDdkQsTUFBTSxPQUFPLEtBQUssV0FBVztHQUM3QixJQUFJLEtBQUssYUFBYSxLQUFLLGdCQUFnQixJQUFJO0VBQ25ELENBQUM7RUFHRCxJQUFJLHVCQUF1QjtFQUMzQixJQUFJLEtBQUssV0FBVyxPQUFPLFNBQVMsS0FBSyxHQUFHLGNBQWMsdUJBQXVCO0VBRWpGLElBQUksS0FBSyxhQUFhO0dBQ2xCLElBQUksS0FBSyxXQUFXLE9BQ2hCLEtBQUssR0FBRyxTQUFTLHNCQUNiLE1BQ0EsS0FBSyxVQUFVLE9BQ2YsS0FBSyxXQUFXLE1BQU0sTUFDdEIsS0FBSyxXQUFXLE1BQU0sU0FBUyxLQUFLLFVBQVUsUUFBUSxzQkFDdEQsS0FBSyxjQUNUO1FBRUEsS0FBSyxHQUFHLFNBQVMsb0JBQW9CLE1BQU0sS0FBSyxVQUFVLE9BQU8sS0FBSyxVQUFVLE9BQU8sS0FBSyxjQUFjO0VBRWxILE9BQ0ksSUFBSSxLQUFLLFdBQVcsT0FDaEIsS0FBSyxHQUFHLGFBQ0osTUFDQSxLQUFLLFVBQVUsT0FDZixLQUFLLFdBQVcsTUFBTSxNQUN0QixLQUFLLFdBQVcsTUFBTSxTQUFTLEtBQUssVUFBVSxRQUFRLG9CQUMxRDtPQUVBLEtBQUssR0FBRyxXQUFXLE1BQU0sS0FBSyxVQUFVLE9BQU8sS0FBSyxVQUFVLEtBQUs7Q0FHL0U7Q0FFQSxjQUFjO0VBRVYsTUFBTSxPQUFPLEtBQUssV0FBVztFQUU3QixJQUFJLEtBQUssTUFBTSxPQUFPO0VBQ3RCLElBQUksZ0JBQWdCO0VBQ3BCLFFBQVEsS0FBSyxpREFBaUQ7RUFDOUQsT0FBUSxpQkFBaUI7Q0FDN0I7Q0FFQSxtQkFBbUIsTUFBTTtFQUNyQixJQUFJLENBQUMsTUFBTSxPQUFPLEtBQUssWUFBWTtFQUNuQyxNQUFNLFFBQVEsS0FBSztFQUduQixNQUFNLFNBQVMsS0FBSztFQUVwQixJQUFJLENBQUMsS0FBSyxRQUNOLEtBQUssU0FBUztHQUNWLEtBQUssSUFBSSxLQUFLO0dBQ2QsS0FBSyxJQUFJLEtBQUs7R0FDZCxRQUFRLElBQUksS0FBSztHQUNqQixPQUFPLElBQUksS0FBSztHQUNoQixRQUFRO0VBQ1o7RUFHSixNQUFNLE1BQU0sS0FBSyxPQUFPO0VBQ3hCLE1BQU0sTUFBTSxLQUFLLE9BQU87RUFDeEIsTUFBTSxTQUFTLEtBQUssT0FBTztFQUMzQixNQUFNLFFBQVEsS0FBSyxPQUFPO0VBRTFCLElBQUksSUFBSSxRQUFTO0VBQ2pCLElBQUksSUFBSSxTQUFTO0VBR2pCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsSUFBSSxHQUFHLEtBQUssUUFBUTtHQUNsRCxNQUFNLElBQUksTUFBTTtHQUNoQixNQUFNLElBQUksTUFBTSxJQUFJO0dBQ3BCLE1BQU0sSUFBSSxNQUFNLElBQUk7R0FFcEIsSUFBSSxJQUFJLEtBQUssSUFBSSxHQUFHLElBQUksQ0FBQztHQUN6QixJQUFJLElBQUksS0FBSyxJQUFJLEdBQUcsSUFBSSxDQUFDO0dBQ3pCLElBQUksSUFBSSxLQUFLLElBQUksR0FBRyxJQUFJLENBQUM7R0FFekIsSUFBSSxJQUFJLEtBQUssSUFBSSxHQUFHLElBQUksQ0FBQztHQUN6QixJQUFJLElBQUksS0FBSyxJQUFJLEdBQUcsSUFBSSxDQUFDO0dBQ3pCLElBQUksSUFBSSxLQUFLLElBQUksR0FBRyxJQUFJLENBQUM7RUFDN0I7RUFFQSxNQUFNLElBQUksS0FBSyxHQUFHO0VBQ2xCLE9BQU8sSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQztDQUNqQztDQUVBLHNCQUFzQixNQUFNO0VBQ3hCLElBQUksQ0FBQyxNQUFNLE9BQU8sS0FBSyxZQUFZO0VBQ25DLE1BQU0sUUFBUSxLQUFLO0VBR25CLE1BQU0sU0FBUyxLQUFLO0VBRXBCLElBQUksQ0FBQyxLQUFLLFFBQVEsS0FBSyxtQkFBbUIsSUFBSTtFQUU5QyxJQUFJLGNBQWM7RUFDbEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxJQUFJLEdBQUcsS0FBSyxRQUFRO0dBQ2xELFdBQVMsVUFBVSxPQUFPLENBQUM7R0FDM0IsY0FBYyxLQUFLLElBQUksYUFBYSxLQUFLLE9BQU8sT0FBTyxnQkFBZ0JELFVBQVEsQ0FBQztFQUNwRjtFQUVBLEtBQUssT0FBTyxTQUFTLEtBQUssS0FBSyxXQUFXO0NBQzlDO0NBRUEsU0FBUztFQUNMLEtBQUssSUFBSSxPQUFPLEtBQUssTUFBTTtHQUN2QixLQUFLLEdBQUcsU0FBUyxrQkFBa0IsS0FBSyxLQUFLLElBQUk7R0FDakQsT0FBTyxLQUFLLEtBQUs7RUFDckI7RUFDQSxLQUFLLElBQUksT0FBTyxLQUFLLFlBQVk7R0FDN0IsS0FBSyxHQUFHLGFBQWEsS0FBSyxXQUFXLElBQUksQ0FBQyxNQUFNO0dBQ2hELE9BQU8sS0FBSyxXQUFXO0VBQzNCO0NBQ0o7QUFDSjs7O0FDalNBLElBQUlFLE9BQUs7QUFHVCxJQUFNLGdCQUFnQixDQUFDO0FBRXZCLElBQWEsVUFBYixNQUFxQjtDQUNqQixZQUNJLElBQ0EsRUFDSSxRQUNBLFVBQ0EsV0FBVyxDQUFDLEdBRVosY0FBYyxPQUNkLFdBQVcsR0FBRyxNQUNkLFlBQVksR0FBRyxLQUNmLFlBQVksTUFDWixhQUFhLE1BQ2IsWUFBWSxHQUFHLFdBQ2YsQ0FBQyxHQUNQO0VBQ0UsSUFBSSxDQUFDLEdBQUcsUUFBUSxRQUFRLE1BQU0sNENBQTRDO0VBQzFFLEtBQUssS0FBSztFQUNWLEtBQUssV0FBVztFQUNoQixLQUFLLEtBQUs7RUFFVixJQUFJLENBQUMsUUFBUSxRQUFRLEtBQUssNEJBQTRCO0VBQ3RELElBQUksQ0FBQyxVQUFVLFFBQVEsS0FBSyw4QkFBOEI7RUFHMUQsS0FBSyxjQUFjO0VBQ25CLEtBQUssV0FBVztFQUNoQixLQUFLLFlBQVk7RUFDakIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssYUFBYTtFQUNsQixLQUFLLFlBQVk7RUFDakIsS0FBSyxZQUFZLENBQUM7RUFDbEIsS0FBSyxnQkFBZ0IsQ0FBQztFQUN0QixLQUFLLGNBQWMsQ0FBQztFQUNwQixLQUFLLFlBQVksQ0FBQztFQUdsQixJQUFJLEtBQUssZUFBZSxDQUFDLEtBQUssVUFBVSxLQUFLO0dBQ3pDLElBQUksS0FBSyxHQUFHLFNBQVMsb0JBQW9CLEtBQUssYUFBYSxLQUFLLEdBQUcsS0FBSyxLQUFLLEdBQUcsbUJBQW1CO1FBQzlGLEtBQUssYUFBYSxLQUFLLEdBQUcsV0FBVyxLQUFLLEdBQUcsbUJBQW1CO0VBQ3pFO0VBR0EsS0FBSyxlQUFlLEdBQUcsYUFBYSxHQUFHLGFBQWE7RUFDcEQsS0FBSyxpQkFBaUIsR0FBRyxhQUFhLEdBQUcsZUFBZTtFQUN4RCxLQUFLLFVBQVUsR0FBRyxjQUFjO0VBQ2hDLEdBQUcsYUFBYSxLQUFLLFNBQVMsS0FBSyxZQUFZO0VBQy9DLEdBQUcsYUFBYSxLQUFLLFNBQVMsS0FBSyxjQUFjO0VBR2pELEtBQUssV0FBVztHQUFFO0dBQVE7RUFBUyxDQUFDO0NBQ3hDO0NBRUEsV0FBVyxFQUFFLFFBQVEsWUFBWTtFQUM3QixJQUFJLFFBQVE7R0FFUixLQUFLLEdBQUcsYUFBYSxLQUFLLGNBQWMsTUFBTTtHQUM5QyxLQUFLLEdBQUcsY0FBYyxLQUFLLFlBQVk7R0FDdkMsSUFBSSxLQUFLLEdBQUcsaUJBQWlCLEtBQUssWUFBWSxNQUFNLElBQ2hELFFBQVEsS0FBSyxHQUFHLEtBQUssR0FBRyxpQkFBaUIsS0FBSyxZQUFZLEVBQUUsbUJBQW1CLGVBQWUsTUFBTSxHQUFHO0VBRS9HO0VBRUEsSUFBSSxVQUFVO0dBRVYsS0FBSyxHQUFHLGFBQWEsS0FBSyxnQkFBZ0IsUUFBUTtHQUNsRCxLQUFLLEdBQUcsY0FBYyxLQUFLLGNBQWM7R0FDekMsSUFBSSxLQUFLLEdBQUcsaUJBQWlCLEtBQUssY0FBYyxNQUFNLElBQ2xELFFBQVEsS0FBSyxHQUFHLEtBQUssR0FBRyxpQkFBaUIsS0FBSyxjQUFjLEVBQUUscUJBQXFCLGVBQWUsUUFBUSxHQUFHO0VBRXJIO0VBR0EsS0FBSyxHQUFHLFlBQVksS0FBSyxPQUFPO0VBQ2hDLElBQUksQ0FBQyxLQUFLLEdBQUcsb0JBQW9CLEtBQUssU0FBUyxLQUFLLEdBQUcsV0FBVyxHQUM5RCxPQUFPLFFBQVEsS0FBSyxLQUFLLEdBQUcsa0JBQWtCLEtBQUssT0FBTyxDQUFDO0VBSS9ELEtBQUssbUNBQW1CLElBQUksSUFBSTtFQUNoQyxJQUFJLGNBQWMsS0FBSyxHQUFHLG9CQUFvQixLQUFLLFNBQVMsS0FBSyxHQUFHLGVBQWU7RUFDbkYsS0FBSyxJQUFJLFNBQVMsR0FBRyxTQUFTLGFBQWEsVUFBVTtHQUNqRCxJQUFJLFVBQVUsS0FBSyxHQUFHLGlCQUFpQixLQUFLLFNBQVMsTUFBTTtHQUMzRCxLQUFLLGlCQUFpQixJQUFJLFNBQVMsS0FBSyxHQUFHLG1CQUFtQixLQUFLLFNBQVMsUUFBUSxJQUFJLENBQUM7R0FHekYsTUFBTSxRQUFRLFFBQVEsS0FBSyxNQUFNLFFBQVE7R0FFekMsUUFBUSxjQUFjLE1BQU07R0FDNUIsUUFBUSxpQkFBaUIsTUFBTSxNQUFNLENBQUM7RUFDMUM7RUFHQSxLQUFLLHFDQUFxQixJQUFJLElBQUk7RUFDbEMsTUFBTSxZQUFZLENBQUM7RUFDbkIsTUFBTSxhQUFhLEtBQUssR0FBRyxvQkFBb0IsS0FBSyxTQUFTLEtBQUssR0FBRyxpQkFBaUI7RUFDdEYsS0FBSyxJQUFJLFNBQVMsR0FBRyxTQUFTLFlBQVksVUFBVTtHQUNoRCxNQUFNLFlBQVksS0FBSyxHQUFHLGdCQUFnQixLQUFLLFNBQVMsTUFBTTtHQUM5RCxNQUFNLFdBQVcsS0FBSyxHQUFHLGtCQUFrQixLQUFLLFNBQVMsVUFBVSxJQUFJO0dBRXZFLElBQUksYUFBYSxJQUFJO0dBQ3JCLFVBQVUsWUFBWSxVQUFVO0dBQ2hDLEtBQUssbUJBQW1CLElBQUksV0FBVyxRQUFRO0VBQ25EO0VBQ0EsS0FBSyxpQkFBaUIsVUFBVSxLQUFLLEVBQUU7Q0FDM0M7Q0FFQSxhQUFhLEtBQUssS0FBSyxVQUFVLFVBQVU7RUFDdkMsS0FBSyxVQUFVLE1BQU07RUFDckIsS0FBSyxVQUFVLE1BQU07RUFDckIsS0FBSyxVQUFVLFdBQVc7RUFDMUIsS0FBSyxVQUFVLFdBQVc7RUFDMUIsSUFBSSxLQUFLLEtBQUssY0FBYztDQUNoQztDQUVBLGlCQUFpQixTQUFTLFdBQVc7RUFDakMsS0FBSyxjQUFjLFVBQVU7RUFDN0IsS0FBSyxjQUFjLFlBQVk7Q0FDbkM7Q0FFQSxlQUFlLE1BQU0sS0FBSyxNQUFNO0VBQzVCLEtBQUssYUFBYTtFQUNsQixLQUFLLFlBQVksT0FBTztFQUN4QixLQUFLLFlBQVksTUFBTTtFQUN2QixLQUFLLFlBQVksT0FBTztDQUM1QjtDQUVBLGFBQWEsYUFBYSxXQUFXLFdBQVc7RUFDNUMsS0FBSyxVQUFVLGNBQWM7RUFDN0IsS0FBSyxVQUFVLFlBQVk7RUFDM0IsS0FBSyxVQUFVLFlBQVk7Q0FDL0I7Q0FFQSxhQUFhO0VBQ1QsSUFBSSxLQUFLLFdBQVcsS0FBSyxHQUFHLFNBQVMsT0FBTyxLQUFLLEdBQUcsVUFBVTtPQUN6RCxLQUFLLEdBQUcsU0FBUyxRQUFRLEtBQUssR0FBRyxVQUFVO0VBRWhELElBQUksS0FBSyxVQUFVLEtBQUssR0FBRyxTQUFTLE9BQU8sS0FBSyxHQUFHLFNBQVM7T0FDdkQsS0FBSyxHQUFHLFNBQVMsUUFBUSxLQUFLLEdBQUcsU0FBUztFQUUvQyxJQUFJLEtBQUssVUFBVSxLQUFLLEtBQUssR0FBRyxTQUFTLE9BQU8sS0FBSyxHQUFHLEtBQUs7T0FDeEQsS0FBSyxHQUFHLFNBQVMsUUFBUSxLQUFLLEdBQUcsS0FBSztFQUUzQyxJQUFJLEtBQUssVUFBVSxLQUFLLEdBQUcsU0FBUyxZQUFZLEtBQUssUUFBUTtFQUM3RCxLQUFLLEdBQUcsU0FBUyxhQUFhLEtBQUssU0FBUztFQUM1QyxLQUFLLEdBQUcsU0FBUyxhQUFhLEtBQUssVUFBVTtFQUM3QyxLQUFLLEdBQUcsU0FBUyxhQUFhLEtBQUssU0FBUztFQUM1QyxJQUFJLEtBQUssVUFBVSxLQUFLLEtBQUssR0FBRyxTQUFTLGFBQWEsS0FBSyxVQUFVLEtBQUssS0FBSyxVQUFVLEtBQUssS0FBSyxVQUFVLFVBQVUsS0FBSyxVQUFVLFFBQVE7RUFDOUksS0FBSyxHQUFHLFNBQVMsaUJBQWlCLEtBQUssY0FBYyxTQUFTLEtBQUssY0FBYyxTQUFTO0VBRTFGLElBQUcsS0FBSyxZQUFZLFFBQVEsS0FBSyxVQUFVLGFBQWEsS0FBSyxHQUFHLFNBQVMsT0FBTyxLQUFLLEdBQUcsWUFBWTtPQUMzRixLQUFLLEdBQUcsU0FBUyxRQUFRLEtBQUssR0FBRyxZQUFZO0VBRXRELEtBQUssR0FBRyxTQUFTLGVBQWUsS0FBSyxZQUFZLE1BQU0sS0FBSyxZQUFZLEtBQUssS0FBSyxZQUFZLElBQUk7RUFDbEcsS0FBSyxHQUFHLFNBQVMsYUFBYSxLQUFLLFVBQVUsYUFBYSxLQUFLLFVBQVUsV0FBVyxLQUFLLFVBQVUsU0FBUztDQUVoSDtDQUVBLElBQUksRUFBRSxZQUFZLFVBQVUsQ0FBQyxHQUFHO0VBQzVCLElBQUksY0FBYztFQUlsQixJQUFJLEVBSGtCLEtBQUssR0FBRyxTQUFTLE1BQU0sbUJBQW1CLEtBQUssS0FHakQ7R0FDaEIsS0FBSyxHQUFHLFdBQVcsS0FBSyxPQUFPO0dBQy9CLEtBQUssR0FBRyxTQUFTLE1BQU0saUJBQWlCLEtBQUs7RUFDakQ7RUFHQSxLQUFLLGlCQUFpQixTQUFTLFVBQVUsa0JBQWtCO0dBQ3ZELElBQUksVUFBVSxLQUFLLFNBQVMsY0FBYztHQUUxQyxLQUFLLE1BQU0sYUFBYSxjQUFjLGdCQUFnQjtJQUNsRCxJQUFJLENBQUMsU0FBUztJQUVkLElBQUksYUFBYSxTQUNiLFVBQVUsUUFBUTtTQUNmLElBQUksTUFBTSxRQUFRLFFBQVEsS0FBSyxHQUNsQztTQUNHO0tBQ0gsVUFBVSxLQUFBO0tBQ1Y7SUFDSjtHQUNKO0dBRUEsSUFBSSxDQUFDLFNBQ0QsT0FBTyxLQUFLLGtCQUFrQixjQUFjLEtBQUssdUJBQXVCO0dBRzVFLElBQUksV0FBVyxRQUFRLFVBQVUsS0FBQSxHQUM3QixPQUFPLEtBQUssR0FBRyxjQUFjLEtBQUssc0NBQXNDO0dBRzVFLElBQUksUUFBUSxNQUFNLFNBQVM7SUFDdkIsY0FBYyxjQUFjO0lBRzVCLFFBQVEsTUFBTSxPQUFPLFdBQVc7SUFDaEMsT0FBTyxXQUFXLEtBQUssSUFBSSxjQUFjLE1BQU0sVUFBVSxXQUFXO0dBQ3hFO0dBR0EsSUFBSSxRQUFRLE1BQU0sVUFBVSxRQUFRLE1BQU0sRUFBRSxDQUFDLFNBQVM7SUFDbEQsTUFBTSxlQUFlLENBQUM7SUFDdEIsUUFBUSxNQUFNLFNBQVMsVUFBVTtLQUM3QixjQUFjLGNBQWM7S0FDNUIsTUFBTSxPQUFPLFdBQVc7S0FDeEIsYUFBYSxLQUFLLFdBQVc7SUFDakMsQ0FBQztJQUVELE9BQU8sV0FBVyxLQUFLLElBQUksY0FBYyxNQUFNLFVBQVUsWUFBWTtHQUN6RTtHQUVBLFdBQVcsS0FBSyxJQUFJLGNBQWMsTUFBTSxVQUFVLFFBQVEsS0FBSztFQUNuRSxDQUFDO0VBRUQsS0FBSyxXQUFXO0VBQ2hCLElBQUksV0FBVyxLQUFLLEdBQUcsU0FBUyxhQUFhLEtBQUssY0FBYyxLQUFLLEdBQUcsTUFBTSxLQUFLLEdBQUcsS0FBSyxLQUFLLEdBQUcsR0FBRztDQUMxRztDQUVBLFNBQVM7RUFDTCxLQUFLLEdBQUcsY0FBYyxLQUFLLE9BQU87Q0FDdEM7QUFDSjtBQUVBLFNBQVMsV0FBVyxJQUFJLE1BQU0sVUFBVSxPQUFPO0NBQzNDLFFBQVEsTUFBTSxTQUFTLFFBQVEsS0FBSyxJQUFJO0NBQ3hDLE1BQU0sV0FBVyxHQUFHLFNBQVMsTUFBTSxpQkFBaUIsSUFBSSxRQUFRO0NBR2hFLElBQUksTUFBTSxRQUFRO0VBQ2QsSUFBSSxhQUFhLEtBQUEsS0FBYSxTQUFTLFdBQVcsTUFBTSxRQUVwRCxHQUFHLFNBQVMsTUFBTSxpQkFBaUIsSUFBSSxVQUFVLE1BQU0sTUFBTSxDQUFDLENBQUM7T0FDNUQ7R0FDSCxJQUFJLFlBQVksVUFBVSxLQUFLLEdBQUc7R0FHbEMsU0FBUyxNQUFNLFNBQVMsSUFBSSxLQUFLLElBQUksU0FBUyxVQUFVLEtBQUs7R0FDN0QsR0FBRyxTQUFTLE1BQU0saUJBQWlCLElBQUksVUFBVSxRQUFRO0VBQzdEO0NBQ0osT0FBTztFQUNILElBQUksYUFBYSxPQUFPO0VBQ3hCLEdBQUcsU0FBUyxNQUFNLGlCQUFpQixJQUFJLFVBQVUsS0FBSztDQUMxRDtDQUVBLFFBQVEsTUFBUjtFQUNJLEtBQUssTUFDRCxPQUFPLE1BQU0sU0FBUyxHQUFHLFdBQVcsVUFBVSxLQUFLLElBQUksR0FBRyxVQUFVLFVBQVUsS0FBSztFQUN2RixLQUFLLE9BQ0QsT0FBTyxHQUFHLFdBQVcsVUFBVSxLQUFLO0VBQ3hDLEtBQUssT0FDRCxPQUFPLEdBQUcsV0FBVyxVQUFVLEtBQUs7RUFDeEMsS0FBSyxPQUNELE9BQU8sR0FBRyxXQUFXLFVBQVUsS0FBSztFQUN4QyxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUssT0FDRCxPQUFPLE1BQU0sU0FBUyxHQUFHLFdBQVcsVUFBVSxLQUFLLElBQUksR0FBRyxVQUFVLFVBQVUsS0FBSztFQUN2RixLQUFLO0VBQ0wsS0FBSyxPQUNELE9BQU8sR0FBRyxXQUFXLFVBQVUsS0FBSztFQUN4QyxLQUFLO0VBQ0wsS0FBSyxPQUNELE9BQU8sR0FBRyxXQUFXLFVBQVUsS0FBSztFQUN4QyxLQUFLO0VBQ0wsS0FBSyxPQUNELE9BQU8sR0FBRyxXQUFXLFVBQVUsS0FBSztFQUN4QyxLQUFLLE9BQ0QsT0FBTyxHQUFHLGlCQUFpQixVQUFVLE9BQU8sS0FBSztFQUNyRCxLQUFLLE9BQ0QsT0FBTyxHQUFHLGlCQUFpQixVQUFVLE9BQU8sS0FBSztFQUNyRCxLQUFLLE9BQ0QsT0FBTyxHQUFHLGlCQUFpQixVQUFVLE9BQU8sS0FBSztDQUN6RDtBQUNKO0FBRUEsU0FBUyxlQUFlLFFBQVE7Q0FDNUIsSUFBSSxRQUFRLE9BQU8sTUFBTSxJQUFJO0NBQzdCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FDOUIsTUFBTSxLQUFLLElBQUksSUFBSSxPQUFPLE1BQU07Q0FFcEMsT0FBTyxNQUFNLEtBQUssSUFBSTtBQUMxQjtBQUVBLFNBQVMsUUFBUSxHQUFHO0NBQ2hCLE1BQU0sV0FBVyxFQUFFO0NBQ25CLE1BQU0sV0FBVyxFQUFFLEVBQUUsQ0FBQztDQUN0QixJQUFJLGFBQWEsS0FBQSxHQUFXLE9BQU87Q0FDbkMsTUFBTSxTQUFTLFdBQVc7Q0FDMUIsSUFBSSxRQUFRLGNBQWM7Q0FDMUIsSUFBSSxDQUFDLE9BQU8sY0FBYyxVQUFVLFFBQVEsSUFBSSxhQUFhLE1BQU07Q0FDbkUsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsS0FBSyxNQUFNLElBQUksRUFBRSxJQUFJLElBQUksUUFBUTtDQUMvRCxPQUFPO0FBQ1g7QUFFQSxTQUFTLFlBQVksR0FBRyxHQUFHO0NBQ3ZCLElBQUksRUFBRSxXQUFXLEVBQUUsUUFBUSxPQUFPO0NBQ2xDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsSUFBSSxHQUFHLEtBQ2pDLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxPQUFPO0NBRTlCLE9BQU87QUFDWDtBQUVBLFNBQVMsU0FBUyxHQUFHLEdBQUc7Q0FDcEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxJQUFJLEdBQUcsS0FDakMsRUFBRSxLQUFLLEVBQUU7QUFFakI7QUFFQSxJQUFJLFlBQVk7QUFDaEIsU0FBUyxLQUFLLFNBQVM7Q0FDbkIsSUFBSSxZQUFZLEtBQUs7Q0FDckIsUUFBUSxLQUFLLE9BQU87Q0FDcEI7Q0FDQSxJQUFJLFlBQVksS0FBSyxRQUFRLEtBQUssaURBQWlEO0FBQ3ZGOzs7QUM1VEEsSUFBTUMsNkJBQTJCLElBQUksS0FBSztBQUMxQyxJQUFJQyxPQUFLO0FBRVQsSUFBYSxXQUFiLE1BQXNCO0NBQ2xCLFlBQVksRUFDUixTQUFTLFNBQVMsY0FBYyxRQUFRLEdBQ3hDLFFBQVEsS0FDUixTQUFTLEtBQ1QsTUFBTSxHQUNOLFFBQVEsT0FDUixRQUFRLE1BQ1IsVUFBVSxPQUNWLFlBQVksT0FDWixxQkFBcUIsT0FDckIsd0JBQXdCLE9BQ3hCLGtCQUFrQixXQUNsQixZQUFZLE1BQ1osUUFBUSxNQUNSLENBQUMsR0FBRztFQUNKLE1BQU0sYUFBYTtHQUFFO0dBQU87R0FBTztHQUFTO0dBQVc7R0FBb0I7R0FBdUI7RUFBZ0I7RUFDbEgsS0FBSyxNQUFNO0VBQ1gsS0FBSyxRQUFRO0VBQ2IsS0FBSyxRQUFRO0VBQ2IsS0FBSyxRQUFRO0VBQ2IsS0FBSyxVQUFVO0VBQ2YsS0FBSyxxQkFBcUI7RUFDMUIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssS0FBSztFQUdWLElBQUksVUFBVSxHQUFHLEtBQUssS0FBSyxPQUFPLFdBQVcsVUFBVSxVQUFVO0VBQ2pFLEtBQUssV0FBVyxDQUFDLENBQUMsS0FBSztFQUN2QixJQUFJLENBQUMsS0FBSyxJQUFJLEtBQUssS0FBSyxPQUFPLFdBQVcsU0FBUyxVQUFVO0VBQzdELElBQUksQ0FBQyxLQUFLLElBQUksUUFBUSxNQUFNLGdDQUFnQztFQUc1RCxLQUFLLEdBQUcsV0FBVztFQUduQixLQUFLLFFBQVEsT0FBTyxNQUFNO0VBRzFCLEtBQUssUUFBUSxDQUFDO0VBQ2QsS0FBSyxNQUFNLFlBQVk7R0FBRSxLQUFLLEtBQUssR0FBRztHQUFLLEtBQUssS0FBSyxHQUFHO0VBQUs7RUFDN0QsS0FBSyxNQUFNLGdCQUFnQixFQUFFLFNBQVMsS0FBSyxHQUFHLFNBQVM7RUFDdkQsS0FBSyxNQUFNLFdBQVc7RUFDdEIsS0FBSyxNQUFNLFlBQVksS0FBSyxHQUFHO0VBQy9CLEtBQUssTUFBTSxZQUFZO0VBQ3ZCLEtBQUssTUFBTSxZQUFZLEtBQUssR0FBRztFQUMvQixLQUFLLE1BQU0sbUJBQW1CO0VBQzlCLEtBQUssTUFBTSxRQUFRO0VBQ25CLEtBQUssTUFBTSxrQkFBa0I7RUFDN0IsS0FBSyxNQUFNLGNBQWM7RUFDekIsS0FBSyxNQUFNLFdBQVc7R0FBRSxHQUFHO0dBQUcsR0FBRztHQUFHLE9BQU87R0FBTSxRQUFRO0VBQUs7RUFDOUQsS0FBSyxNQUFNLGVBQWUsQ0FBQztFQUMzQixLQUFLLE1BQU0sb0JBQW9CO0VBQy9CLEtBQUssTUFBTSxjQUFjO0VBQ3pCLEtBQUssTUFBTSxtQ0FBbUIsSUFBSSxJQUFJO0VBQ3RDLEtBQUssTUFBTSxpQkFBaUI7RUFHNUIsS0FBSyxhQUFhLENBQUM7RUFHbkIsSUFBSSxLQUFLLFVBQVU7R0FDZixLQUFLLGFBQWEsd0JBQXdCO0dBQzFDLEtBQUssYUFBYSwwQkFBMEI7RUFDaEQsT0FBTztHQUNILEtBQUssYUFBYSxtQkFBbUI7R0FDckMsS0FBSyxhQUFhLDBCQUEwQjtHQUM1QyxLQUFLLGFBQWEsd0JBQXdCO0dBQzFDLEtBQUssYUFBYSwrQkFBK0I7R0FDakQsS0FBSyxhQUFhLHdCQUF3QjtHQUMxQyxLQUFLLGFBQWEsMEJBQTBCO0dBQzVDLEtBQUssYUFBYSxVQUFVO0dBQzVCLEtBQUssYUFBYSxxQkFBcUI7R0FDdkMsS0FBSyxhQUFhLG9CQUFvQjtFQUMxQztFQUNBLEtBQUssYUFBYSwrQkFBK0I7RUFDakQsS0FBSyxhQUFhLDhCQUE4QjtFQUNoRCxLQUFLLGFBQWEsK0JBQStCO0VBQ2pELEtBQUssYUFBYSwrQkFBK0I7RUFDakQsS0FBSyxhQUFhLGdDQUFnQztFQUNsRCxLQUFLLGFBQWEsdUNBQXVDO0VBR3pELEtBQUssc0JBQXNCLEtBQUssYUFBYSwwQkFBMEIsdUJBQXVCLDBCQUEwQjtFQUN4SCxLQUFLLHNCQUFzQixLQUFLLGFBQWEsMEJBQTBCLHVCQUF1QiwwQkFBMEI7RUFDeEgsS0FBSyx3QkFBd0IsS0FBSyxhQUFhLDBCQUEwQix5QkFBeUIsNEJBQTRCO0VBQzlILEtBQUssb0JBQW9CLEtBQUssYUFBYSwyQkFBMkIscUJBQXFCLHNCQUFzQjtFQUNqSCxLQUFLLGtCQUFrQixLQUFLLGFBQWEsMkJBQTJCLG1CQUFtQixvQkFBb0I7RUFDM0csS0FBSyxvQkFBb0IsS0FBSyxhQUFhLDJCQUEyQixxQkFBcUIsc0JBQXNCO0VBQ2pILEtBQUssY0FBYyxLQUFLLGFBQWEsc0JBQXNCLGVBQWUsa0JBQWtCO0VBRzVGLEtBQUssYUFBYSxDQUFDO0VBQ25CLEtBQUssV0FBVyxrQkFBa0IsS0FBSyxHQUFHLGFBQWEsS0FBSyxHQUFHLGdDQUFnQztFQUMvRixLQUFLLFdBQVcsZ0JBQWdCLEtBQUssYUFBYSxnQ0FBZ0MsSUFDNUUsS0FBSyxHQUFHLGFBQWEsS0FBSyxhQUFhLGdDQUFnQyxDQUFDLENBQUMsOEJBQThCLElBQ3ZHO0NBQ1Y7Q0FFQSxRQUFRLE9BQU8sUUFBUTtFQUNuQixLQUFLLFFBQVE7RUFDYixLQUFLLFNBQVM7RUFFZCxLQUFLLEdBQUcsT0FBTyxRQUFRLFFBQVEsS0FBSztFQUNwQyxLQUFLLEdBQUcsT0FBTyxTQUFTLFNBQVMsS0FBSztFQUV0QyxJQUFJLENBQUMsS0FBSyxHQUFHLE9BQU8sT0FBTztFQUMzQixPQUFPLE9BQU8sS0FBSyxHQUFHLE9BQU8sT0FBTztHQUNoQyxPQUFPLFFBQVE7R0FDZixRQUFRLFNBQVM7RUFDckIsQ0FBQztDQUNMO0NBRUEsWUFBWSxPQUFPLFFBQVEsSUFBSSxHQUFHLElBQUksR0FBRztFQUNyQyxJQUFJLEtBQUssTUFBTSxTQUFTLFVBQVUsU0FBUyxLQUFLLE1BQU0sU0FBUyxXQUFXLFFBQVE7RUFDbEYsS0FBSyxNQUFNLFNBQVMsUUFBUTtFQUM1QixLQUFLLE1BQU0sU0FBUyxTQUFTO0VBQzdCLEtBQUssTUFBTSxTQUFTLElBQUk7RUFDeEIsS0FBSyxNQUFNLFNBQVMsSUFBSTtFQUN4QixLQUFLLEdBQUcsU0FBUyxHQUFHLEdBQUcsT0FBTyxNQUFNO0NBQ3hDO0NBRUEsV0FBVyxPQUFPLFFBQVEsSUFBSSxHQUFHLElBQUksR0FBRztFQUNwQyxLQUFLLEdBQUcsUUFBUSxHQUFHLEdBQUcsT0FBTyxNQUFNO0NBQ3ZDO0NBRUEsT0FBTyxJQUFJO0VBQ1AsSUFBSSxLQUFLLE1BQU0sUUFBUSxNQUFNO0VBQzdCLEtBQUssR0FBRyxPQUFPLEVBQUU7RUFDakIsS0FBSyxNQUFNLE1BQU07Q0FDckI7Q0FFQSxRQUFRLElBQUk7RUFDUixJQUFJLEtBQUssTUFBTSxRQUFRLE9BQU87RUFDOUIsS0FBSyxHQUFHLFFBQVEsRUFBRTtFQUNsQixLQUFLLE1BQU0sTUFBTTtDQUNyQjtDQUVBLGFBQWEsS0FBSyxLQUFLLFVBQVUsVUFBVTtFQUN2QyxJQUNJLEtBQUssTUFBTSxVQUFVLFFBQVEsT0FDN0IsS0FBSyxNQUFNLFVBQVUsUUFBUSxPQUM3QixLQUFLLE1BQU0sVUFBVSxhQUFhLFlBQ2xDLEtBQUssTUFBTSxVQUFVLGFBQWEsVUFFbEM7RUFDSixLQUFLLE1BQU0sVUFBVSxNQUFNO0VBQzNCLEtBQUssTUFBTSxVQUFVLE1BQU07RUFDM0IsS0FBSyxNQUFNLFVBQVUsV0FBVztFQUNoQyxLQUFLLE1BQU0sVUFBVSxXQUFXO0VBQ2hDLElBQUksYUFBYSxLQUFBLEdBQVcsS0FBSyxHQUFHLGtCQUFrQixLQUFLLEtBQUssVUFBVSxRQUFRO09BQzdFLEtBQUssR0FBRyxVQUFVLEtBQUssR0FBRztDQUNuQztDQUVBLGlCQUFpQixTQUFTLFdBQVc7RUFDakMsVUFBVSxXQUFXLEtBQUssR0FBRztFQUM3QixJQUFJLEtBQUssTUFBTSxjQUFjLFlBQVksV0FBVyxLQUFLLE1BQU0sY0FBYyxjQUFjLFdBQVc7RUFDdEcsS0FBSyxNQUFNLGNBQWMsVUFBVTtFQUNuQyxLQUFLLE1BQU0sY0FBYyxZQUFZO0VBQ3JDLElBQUksY0FBYyxLQUFBLEdBQVcsS0FBSyxHQUFHLHNCQUFzQixTQUFTLFNBQVM7T0FDeEUsS0FBSyxHQUFHLGNBQWMsT0FBTztDQUN0QztDQUVBLFlBQVksT0FBTztFQUNmLElBQUksS0FBSyxNQUFNLGFBQWEsT0FBTztFQUNuQyxLQUFLLE1BQU0sV0FBVztFQUN0QixLQUFLLEdBQUcsU0FBUyxLQUFLO0NBQzFCO0NBRUEsYUFBYSxPQUFPO0VBQ2hCLElBQUksS0FBSyxNQUFNLGNBQWMsT0FBTztFQUNwQyxLQUFLLE1BQU0sWUFBWTtFQUN2QixLQUFLLEdBQUcsVUFBVSxLQUFLO0NBQzNCO0NBRUEsYUFBYSxPQUFPO0VBQ2hCLElBQUksS0FBSyxNQUFNLGNBQWMsT0FBTztFQUNwQyxLQUFLLE1BQU0sWUFBWTtFQUN2QixLQUFLLEdBQUcsVUFBVSxLQUFLO0NBQzNCO0NBRUEsYUFBYSxPQUFPO0VBQ2hCLElBQUksS0FBSyxNQUFNLGNBQWMsT0FBTztFQUNwQyxLQUFLLE1BQU0sWUFBWTtFQUN2QixLQUFLLEdBQUcsVUFBVSxLQUFLO0NBQzNCO0NBRUEsZUFBZSxPQUFPO0VBQ2xCLElBQUcsS0FBSyxNQUFNLGdCQUFnQixPQUFPO0VBQ3JDLEtBQUssTUFBTSxjQUFjO0VBQ3pCLEtBQUssR0FBRyxZQUFZLEtBQUs7Q0FDN0I7Q0FFQSxlQUFlLE1BQU0sS0FBSyxNQUFNO0VBRTVCLElBQUksS0FBSyxNQUFNLGdCQUFnQixRQUMxQixLQUFLLE1BQU0sZUFBZSxPQUMxQixLQUFLLE1BQU0sb0JBQW9CLE1BQ2xDO0VBRUYsS0FBSyxNQUFNLGNBQWMsUUFBUSxLQUFLLEdBQUc7RUFDekMsS0FBSyxNQUFNLGFBQWEsT0FBTztFQUMvQixLQUFLLE1BQU0sa0JBQWtCLFFBQVE7RUFFckMsS0FBSyxHQUFHLFlBQVksUUFBUSxLQUFLLEdBQUcsUUFBUSxPQUFPLEdBQUcsUUFBUSxDQUFDO0NBQ25FO0NBRUEsYUFBYSxhQUFhLFdBQVcsV0FBVztFQUU1QyxJQUFHLEtBQUssTUFBTSxnQkFBZ0IsZUFDMUIsS0FBSyxNQUFNLHFCQUFxQixhQUNoQyxLQUFLLE1BQU0scUJBQXFCLFdBQ2xDO0VBRUYsS0FBSyxNQUFNLGNBQWM7RUFDekIsS0FBSyxNQUFNLG1CQUFtQjtFQUM5QixLQUFLLE1BQU0sbUJBQW1CO0VBRTlCLEtBQUssR0FBRyxVQUFVLGFBQWEsV0FBVyxTQUFTO0NBRXZEO0NBRUEsY0FBYyxPQUFPO0VBQ2pCLElBQUksS0FBSyxNQUFNLHNCQUFzQixPQUFPO0VBQzVDLEtBQUssTUFBTSxvQkFBb0I7RUFDL0IsS0FBSyxHQUFHLGNBQWMsS0FBSyxHQUFHLFdBQVcsS0FBSztDQUNsRDtDQUVBLGdCQUFnQixFQUFFLFNBQVMsS0FBSyxHQUFHLGFBQWEsU0FBUyxTQUFTLENBQUMsR0FBRztFQUNsRSxJQUFJLEtBQUssTUFBTSxnQkFBZ0IsUUFBUTtFQUN2QyxLQUFLLE1BQU0sY0FBYztFQUN6QixLQUFLLEdBQUcsZ0JBQWdCLFFBQVEsTUFBTTtDQUMxQztDQUVBLGFBQWEsV0FBVyxZQUFZLFNBQVM7RUFFekMsSUFBSSxjQUFjLEtBQUssR0FBRyxhQUFhLE9BQU8sS0FBSyxHQUFHLFdBQVcsQ0FBQyxLQUFLLEtBQUssRUFBRTtFQUc5RSxJQUFJLENBQUMsS0FBSyxXQUFXLFlBQ2pCLEtBQUssV0FBVyxhQUFhLEtBQUssR0FBRyxhQUFhLFNBQVM7RUFJL0QsSUFBSSxDQUFDLFlBQVksT0FBTyxLQUFLLFdBQVc7RUFHeEMsSUFBSSxDQUFDLEtBQUssV0FBVyxZQUFZLE9BQU87RUFHeEMsT0FBTyxLQUFLLFdBQVcsVUFBVSxDQUFDLFFBQVEsQ0FBQyxLQUFLLEtBQUssV0FBVyxVQUFVO0NBQzlFO0NBRUEsV0FBVyxHQUFHLEdBQUc7RUFDYixJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsYUFDcEIsT0FBTyxFQUFFLGNBQWMsRUFBRTtPQUN0QixJQUFJLEVBQUUsUUFBUSxPQUFPLEVBQUUsUUFBUSxJQUNsQyxPQUFPLEVBQUUsUUFBUSxLQUFLLEVBQUUsUUFBUTtPQUM3QixJQUFJLEVBQUUsV0FBVyxFQUFFLFFBQ3RCLE9BQU8sRUFBRSxTQUFTLEVBQUU7T0FFcEIsT0FBTyxFQUFFLEtBQUssRUFBRTtDQUV4QjtDQUVBLGdCQUFnQixHQUFHLEdBQUc7RUFDbEIsSUFBSSxFQUFFLGdCQUFnQixFQUFFLGFBQ3BCLE9BQU8sRUFBRSxjQUFjLEVBQUU7RUFFN0IsSUFBSSxFQUFFLFdBQVcsRUFBRSxRQUNmLE9BQU8sRUFBRSxTQUFTLEVBQUU7T0FFcEIsT0FBTyxFQUFFLEtBQUssRUFBRTtDQUV4QjtDQUVBLE9BQU8sR0FBRyxHQUFHO0VBQ1QsSUFBSSxFQUFFLGdCQUFnQixFQUFFLGFBQ3BCLE9BQU8sRUFBRSxjQUFjLEVBQUU7T0FDdEIsSUFBSSxFQUFFLFFBQVEsT0FBTyxFQUFFLFFBQVEsSUFDbEMsT0FBTyxFQUFFLFFBQVEsS0FBSyxFQUFFLFFBQVE7T0FFaEMsT0FBTyxFQUFFLEtBQUssRUFBRTtDQUV4QjtDQUVBLGNBQWMsRUFBRSxPQUFPLFFBQVEsYUFBYSxRQUFRO0VBQ2hELElBQUksYUFBYSxDQUFDO0VBRWxCLElBQUksVUFBVSxhQUFhLE9BQU8sY0FBYztFQUdoRCxNQUFNLFVBQVUsU0FBUztHQUNyQixJQUFJLENBQUMsS0FBSyxTQUFTLE9BQU87R0FDMUIsSUFBSSxDQUFDLEtBQUssTUFBTTtHQUVoQixJQUFJLGVBQWUsS0FBSyxpQkFBaUIsUUFDakM7UUFBQSxDQUFDLE9BQU8sc0JBQXNCLElBQUksR0FBRztHQUFBO0dBRzdDLFdBQVcsS0FBSyxJQUFJO0VBQ3hCLENBQUM7RUFFRCxJQUFJLE1BQU07R0FDTixNQUFNLFNBQVMsQ0FBQztHQUNoQixNQUFNLGNBQWMsQ0FBQztHQUNyQixNQUFNLEtBQUssQ0FBQztHQUVaLFdBQVcsU0FBUyxTQUFTO0lBRXpCLElBQUksQ0FBQyxLQUFLLFFBQVEsYUFDZCxPQUFPLEtBQUssSUFBSTtTQUNiLElBQUksS0FBSyxRQUFRLFdBQ3BCLFlBQVksS0FBSyxJQUFJO1NBRXJCLEdBQUcsS0FBSyxJQUFJO0lBR2hCLEtBQUssU0FBUztJQUdkLElBQUksS0FBSyxnQkFBZ0IsS0FBSyxDQUFDLEtBQUssUUFBUSxhQUFhLENBQUMsUUFBUTtJQUdsRSxLQUFLLFlBQVksZUFBZUQsVUFBUTtJQUN4QyxXQUFTLGFBQWEsT0FBTyxvQkFBb0I7SUFDakQsS0FBSyxTQUFTQSxXQUFTO0dBQzNCLENBQUM7R0FFRCxPQUFPLEtBQUssS0FBSyxVQUFVO0dBQzNCLFlBQVksS0FBSyxLQUFLLGVBQWU7R0FDckMsR0FBRyxLQUFLLEtBQUssTUFBTTtHQUVuQixhQUFhLE9BQU8sT0FBTyxhQUFhLEVBQUU7RUFDOUM7RUFFQSxPQUFPO0NBQ1g7Q0FFQSxPQUFPLEVBQUUsT0FBTyxRQUFRLFNBQVMsTUFBTSxTQUFTLE1BQU0sT0FBTyxNQUFNLGNBQWMsTUFBTSxTQUFTO0VBQzVGLElBQUksV0FBVyxNQUFNO0dBRWpCLEtBQUssZ0JBQWdCO0dBQ3JCLEtBQUssWUFBWSxLQUFLLFFBQVEsS0FBSyxLQUFLLEtBQUssU0FBUyxLQUFLLEdBQUc7RUFDbEUsT0FBTztHQUVILEtBQUssZ0JBQWdCLE1BQU07R0FDM0IsS0FBSyxZQUFZLE9BQU8sT0FBTyxPQUFPLE1BQU07RUFDaEQ7RUFFQSxJQUFJLFNBQVUsS0FBSyxhQUFhLFVBQVUsT0FBUTtHQUU5QyxJQUFJLEtBQUssVUFBVSxDQUFDLFVBQVUsT0FBTyxRQUFRO0lBQ3pDLEtBQUssT0FBTyxLQUFLLEdBQUcsVUFBVTtJQUM5QixLQUFLLGFBQWEsSUFBSTtHQUMxQjtHQUdBLElBQUcsS0FBSyxXQUFZLENBQUMsVUFBVSxPQUFPLFNBQVU7SUFDNUMsS0FBSyxPQUFPLEtBQUssR0FBRyxZQUFZO0lBQ2hDLEtBQUssZUFBZSxHQUFJO0dBQzVCO0dBRUEsS0FBSyxHQUFHLE9BQ0gsS0FBSyxRQUFRLEtBQUssR0FBRyxtQkFBbUIsTUFDcEMsS0FBSyxRQUFRLEtBQUssR0FBRyxtQkFBbUIsTUFDeEMsS0FBSyxVQUFVLEtBQUssR0FBRyxxQkFBcUIsRUFDckQ7RUFDSjtFQUdBLElBQUksUUFBUSxNQUFNLGtCQUFrQjtFQUdwQyxJQUFJLFFBQVEsT0FBTyxrQkFBa0I7RUFLckMsS0FGd0IsY0FBYztHQUFFO0dBQU87R0FBUTtHQUFhO0VBQUssQ0FFaEUsQ0FBQyxDQUFDLFNBQVMsU0FBUztHQUN6QixLQUFLLEtBQUssRUFBRSxPQUFPLENBQUM7RUFDeEIsQ0FBQztDQUNMO0FBQ0o7Ozs7Ozs7Ozs7QUNyWUEsU0FBZ0JFLE9BQUssS0FBSyxHQUFHO0NBQ3pCLElBQUksS0FBSyxFQUFFO0NBQ1gsSUFBSSxLQUFLLEVBQUU7Q0FDWCxJQUFJLEtBQUssRUFBRTtDQUNYLElBQUksS0FBSyxFQUFFO0NBQ1gsT0FBTztBQUNYOzs7Ozs7Ozs7OztBQVlBLFNBQWdCQyxNQUFJLEtBQUssR0FBRyxHQUFHLEdBQUcsR0FBRztDQUNqQyxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxPQUFPO0FBQ1g7Ozs7Ozs7OztBQTBCQSxTQUFnQkMsUUFBTSxLQUFLLEdBQUcsR0FBRztDQUM3QixJQUFJLEtBQUssRUFBRSxLQUFLO0NBQ2hCLElBQUksS0FBSyxFQUFFLEtBQUs7Q0FDaEIsSUFBSSxLQUFLLEVBQUUsS0FBSztDQUNoQixJQUFJLEtBQUssRUFBRSxLQUFLO0NBQ2hCLE9BQU87QUFDWDs7Ozs7Ozs7QUF1QkEsU0FBZ0JDLFlBQVUsS0FBSyxHQUFHO0NBQzlCLElBQUksSUFBSSxFQUFFO0NBQ1YsSUFBSSxJQUFJLEVBQUU7Q0FDVixJQUFJLElBQUksRUFBRTtDQUNWLElBQUksSUFBSSxFQUFFO0NBQ1YsSUFBSSxNQUFNLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUk7Q0FDdEMsSUFBSSxNQUFNLEdBQ04sTUFBTSxJQUFJLEtBQUssS0FBSyxHQUFHO0NBRTNCLElBQUksS0FBSyxJQUFJO0NBQ2IsSUFBSSxLQUFLLElBQUk7Q0FDYixJQUFJLEtBQUssSUFBSTtDQUNiLElBQUksS0FBSyxJQUFJO0NBQ2IsT0FBTztBQUNYOzs7Ozs7OztBQVNBLFNBQWdCQyxNQUFJLEdBQUcsR0FBRztDQUN0QixPQUFPLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFO0FBQzlEOzs7Ozs7Ozs7QUN6R0EsU0FBZ0JDLFdBQVMsS0FBSztDQUMxQixJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxPQUFPO0FBQ1g7Ozs7Ozs7Ozs7QUFXQSxTQUFnQixhQUFhLEtBQUssTUFBTSxLQUFLO0NBQ3pDLE1BQU0sTUFBTTtDQUNaLElBQUksSUFBSSxLQUFLLElBQUksR0FBRztDQUNwQixJQUFJLEtBQUssSUFBSSxLQUFLO0NBQ2xCLElBQUksS0FBSyxJQUFJLEtBQUs7Q0FDbEIsSUFBSSxLQUFLLElBQUksS0FBSztDQUNsQixJQUFJLEtBQUssS0FBSyxJQUFJLEdBQUc7Q0FDckIsT0FBTztBQUNYOzs7Ozs7Ozs7QUFVQSxTQUFnQkMsV0FBUyxLQUFLLEdBQUcsR0FBRztDQUNoQyxJQUFJLEtBQUssRUFBRSxJQUNQLEtBQUssRUFBRSxJQUNQLEtBQUssRUFBRSxJQUNQLEtBQUssRUFBRTtDQUNYLElBQUksS0FBSyxFQUFFLElBQ1AsS0FBSyxFQUFFLElBQ1AsS0FBSyxFQUFFLElBQ1AsS0FBSyxFQUFFO0NBRVgsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUs7Q0FDNUMsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUs7Q0FDNUMsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUs7Q0FDNUMsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUs7Q0FDNUMsT0FBTztBQUNYOzs7Ozs7Ozs7QUFVQSxTQUFnQixRQUFRLEtBQUssR0FBRyxLQUFLO0NBQ2pDLE9BQU87Q0FFUCxJQUFJLEtBQUssRUFBRSxJQUNQLEtBQUssRUFBRSxJQUNQLEtBQUssRUFBRSxJQUNQLEtBQUssRUFBRTtDQUNYLElBQUksS0FBSyxLQUFLLElBQUksR0FBRyxHQUNqQixLQUFLLEtBQUssSUFBSSxHQUFHO0NBRXJCLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSztDQUN4QixJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUs7Q0FDeEIsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLO0NBQ3hCLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSztDQUN4QixPQUFPO0FBQ1g7Ozs7Ozs7OztBQVVBLFNBQWdCLFFBQVEsS0FBSyxHQUFHLEtBQUs7Q0FDakMsT0FBTztDQUVQLElBQUksS0FBSyxFQUFFLElBQ1AsS0FBSyxFQUFFLElBQ1AsS0FBSyxFQUFFLElBQ1AsS0FBSyxFQUFFO0NBQ1gsSUFBSSxLQUFLLEtBQUssSUFBSSxHQUFHLEdBQ2pCLEtBQUssS0FBSyxJQUFJLEdBQUc7Q0FFckIsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLO0NBQ3hCLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSztDQUN4QixJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUs7Q0FDeEIsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLO0NBQ3hCLE9BQU87QUFDWDs7Ozs7Ozs7O0FBVUEsU0FBZ0IsUUFBUSxLQUFLLEdBQUcsS0FBSztDQUNqQyxPQUFPO0NBRVAsSUFBSSxLQUFLLEVBQUUsSUFDUCxLQUFLLEVBQUUsSUFDUCxLQUFLLEVBQUUsSUFDUCxLQUFLLEVBQUU7Q0FDWCxJQUFJLEtBQUssS0FBSyxJQUFJLEdBQUcsR0FDakIsS0FBSyxLQUFLLElBQUksR0FBRztDQUVyQixJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUs7Q0FDeEIsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLO0NBQ3hCLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSztDQUN4QixJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUs7Q0FDeEIsT0FBTztBQUNYOzs7Ozs7Ozs7O0FBV0EsU0FBZ0IsTUFBTSxLQUFLLEdBQUcsR0FBRyxHQUFHO0NBR2hDLElBQUksS0FBSyxFQUFFLElBQ1AsS0FBSyxFQUFFLElBQ1AsS0FBSyxFQUFFLElBQ1AsS0FBSyxFQUFFO0NBQ1gsSUFBSSxLQUFLLEVBQUUsSUFDUCxLQUFLLEVBQUUsSUFDUCxLQUFLLEVBQUUsSUFDUCxLQUFLLEVBQUU7Q0FFWCxJQUFJLE9BQU8sT0FBTyxPQUFPLFFBQVE7Q0FHakMsUUFBUSxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLO0NBRTNDLElBQUksUUFBUSxHQUFLO0VBQ2IsUUFBUSxDQUFDO0VBQ1QsS0FBSyxDQUFDO0VBQ04sS0FBSyxDQUFDO0VBQ04sS0FBSyxDQUFDO0VBQ04sS0FBSyxDQUFDO0NBQ1Y7Q0FFQSxJQUFJLElBQU0sUUFBUSxNQUFVO0VBRXhCLFFBQVEsS0FBSyxLQUFLLEtBQUs7RUFDdkIsUUFBUSxLQUFLLElBQUksS0FBSztFQUN0QixTQUFTLEtBQUssS0FBSyxJQUFNLEtBQUssS0FBSyxJQUFJO0VBQ3ZDLFNBQVMsS0FBSyxJQUFJLElBQUksS0FBSyxJQUFJO0NBQ25DLE9BQU87RUFHSCxTQUFTLElBQU07RUFDZixTQUFTO0NBQ2I7Q0FFQSxJQUFJLEtBQUssU0FBUyxLQUFLLFNBQVM7Q0FDaEMsSUFBSSxLQUFLLFNBQVMsS0FBSyxTQUFTO0NBQ2hDLElBQUksS0FBSyxTQUFTLEtBQUssU0FBUztDQUNoQyxJQUFJLEtBQUssU0FBUyxLQUFLLFNBQVM7Q0FFaEMsT0FBTztBQUNYOzs7Ozs7OztBQVNBLFNBQWdCQyxTQUFPLEtBQUssR0FBRztDQUMzQixJQUFJLEtBQUssRUFBRSxJQUNQLEtBQUssRUFBRSxJQUNQLEtBQUssRUFBRSxJQUNQLEtBQUssRUFBRTtDQUNYLElBQUksTUFBTSxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLO0NBQzdDLElBQUksU0FBUyxNQUFNLElBQU0sTUFBTTtDQUkvQixJQUFJLEtBQUssQ0FBQyxLQUFLO0NBQ2YsSUFBSSxLQUFLLENBQUMsS0FBSztDQUNmLElBQUksS0FBSyxDQUFDLEtBQUs7Q0FDZixJQUFJLEtBQUssS0FBSztDQUNkLE9BQU87QUFDWDs7Ozs7Ozs7O0FBVUEsU0FBZ0IsVUFBVSxLQUFLLEdBQUc7Q0FDOUIsSUFBSSxLQUFLLENBQUMsRUFBRTtDQUNaLElBQUksS0FBSyxDQUFDLEVBQUU7Q0FDWixJQUFJLEtBQUssQ0FBQyxFQUFFO0NBQ1osSUFBSSxLQUFLLEVBQUU7Q0FDWCxPQUFPO0FBQ1g7Ozs7Ozs7Ozs7OztBQWFBLFNBQWdCLFNBQVMsS0FBSyxHQUFHO0NBRzdCLElBQUksU0FBUyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUU7Q0FDN0IsSUFBSTtDQUVKLElBQUksU0FBUyxHQUFLO0VBRWQsUUFBUSxLQUFLLEtBQUssU0FBUyxDQUFHO0VBQzlCLElBQUksS0FBSyxLQUFNO0VBQ2YsUUFBUSxLQUFNO0VBQ2QsSUFBSSxNQUFNLEVBQUUsS0FBSyxFQUFFLE1BQU07RUFDekIsSUFBSSxNQUFNLEVBQUUsS0FBSyxFQUFFLE1BQU07RUFDekIsSUFBSSxNQUFNLEVBQUUsS0FBSyxFQUFFLE1BQU07Q0FDN0IsT0FBTztFQUVILElBQUksSUFBSTtFQUNSLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxJQUFJO0VBQ3JCLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxJQUFJLElBQUksSUFBSTtFQUM3QixJQUFJLEtBQUssSUFBSSxLQUFLO0VBQ2xCLElBQUksS0FBSyxJQUFJLEtBQUs7RUFFbEIsUUFBUSxLQUFLLEtBQUssRUFBRSxJQUFJLElBQUksS0FBSyxFQUFFLElBQUksSUFBSSxLQUFLLEVBQUUsSUFBSSxJQUFJLEtBQUssQ0FBRztFQUNsRSxJQUFJLEtBQUssS0FBTTtFQUNmLFFBQVEsS0FBTTtFQUNkLElBQUksTUFBTSxFQUFFLElBQUksSUFBSSxLQUFLLEVBQUUsSUFBSSxJQUFJLE1BQU07RUFDekMsSUFBSSxNQUFNLEVBQUUsSUFBSSxJQUFJLEtBQUssRUFBRSxJQUFJLElBQUksTUFBTTtFQUN6QyxJQUFJLE1BQU0sRUFBRSxJQUFJLElBQUksS0FBSyxFQUFFLElBQUksSUFBSSxNQUFNO0NBQzdDO0NBRUEsT0FBTztBQUNYOzs7Ozs7Ozs7O0FBV0EsU0FBZ0IsVUFBVSxLQUFLLE9BQU8sUUFBUSxPQUFPO0NBQ2pELElBQUksS0FBSyxLQUFLLElBQUksTUFBTSxLQUFLLEVBQUc7Q0FDaEMsSUFBSSxLQUFLLEtBQUssSUFBSSxNQUFNLEtBQUssRUFBRztDQUNoQyxJQUFJLEtBQUssS0FBSyxJQUFJLE1BQU0sS0FBSyxFQUFHO0NBQ2hDLElBQUksS0FBSyxLQUFLLElBQUksTUFBTSxLQUFLLEVBQUc7Q0FDaEMsSUFBSSxLQUFLLEtBQUssSUFBSSxNQUFNLEtBQUssRUFBRztDQUNoQyxJQUFJLEtBQUssS0FBSyxJQUFJLE1BQU0sS0FBSyxFQUFHO0NBRWhDLElBQUksVUFBVSxPQUFPO0VBQ2pCLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUs7RUFDbEMsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSztFQUNsQyxJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLO0VBQ2xDLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUs7Q0FDdEMsT0FBTyxJQUFJLFVBQVUsT0FBTztFQUN4QixJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLO0VBQ2xDLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUs7RUFDbEMsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSztFQUNsQyxJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLO0NBQ3RDLE9BQU8sSUFBSSxVQUFVLE9BQU87RUFDeEIsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSztFQUNsQyxJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLO0VBQ2xDLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUs7RUFDbEMsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSztDQUN0QyxPQUFPLElBQUksVUFBVSxPQUFPO0VBQ3hCLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUs7RUFDbEMsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSztFQUNsQyxJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLO0VBQ2xDLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUs7Q0FDdEMsT0FBTyxJQUFJLFVBQVUsT0FBTztFQUN4QixJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLO0VBQ2xDLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUs7RUFDbEMsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSztFQUNsQyxJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLO0NBQ3RDLE9BQU8sSUFBSSxVQUFVLE9BQU87RUFDeEIsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSztFQUNsQyxJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLO0VBQ2xDLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUs7RUFDbEMsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSztDQUN0QztDQUVBLE9BQU87QUFDWDs7Ozs7Ozs7O0FBVUEsSUFBYUMsU0FBT0M7Ozs7Ozs7Ozs7OztBQWFwQixJQUFhQyxRQUFNQzs7Ozs7Ozs7O0FBZ0NuQixJQUFhQyxRQUFNQzs7Ozs7Ozs7O0FBOEJuQixJQUFhQyxjQUFZQzs7O0FDdlp6QixJQUFhLE9BQWIsY0FBMEIsTUFBTTtDQUM1QixZQUFZLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksR0FBRztFQUNwQyxNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUM7RUFDaEIsS0FBSyxpQkFBaUIsQ0FBQztFQUd2QixLQUFLLFVBQVU7RUFHZixNQUFNLGVBQWU7R0FBQztHQUFLO0dBQUs7R0FBSztFQUFHO0VBQ3hDLE9BQU8sSUFBSSxNQUFNLE1BQU0sRUFDbkIsSUFBSSxRQUFRLFVBQVU7R0FDbEIsTUFBTSxVQUFVLFFBQVEsSUFBSSxHQUFHLFNBQVM7R0FDeEMsSUFBSSxXQUFXLGFBQWEsU0FBUyxRQUFRLEdBQUcsT0FBTyxTQUFTO0dBQ2hFLE9BQU87RUFDWCxFQUNKLENBQUM7Q0FDTDtDQUVBLElBQUksSUFBSTtFQUNKLE9BQU8sS0FBSztDQUNoQjtDQUVBLElBQUksSUFBSTtFQUNKLE9BQU8sS0FBSztDQUNoQjtDQUVBLElBQUksSUFBSTtFQUNKLE9BQU8sS0FBSztDQUNoQjtDQUVBLElBQUksSUFBSTtFQUNKLE9BQU8sS0FBSztDQUNoQjtDQUVBLElBQUksRUFBRSxHQUFHO0VBQ0wsS0FBSyxRQUFRLEtBQUs7RUFDbEIsS0FBSyxTQUFTO0NBQ2xCO0NBRUEsSUFBSSxFQUFFLEdBQUc7RUFDTCxLQUFLLFFBQVEsS0FBSztFQUNsQixLQUFLLFNBQVM7Q0FDbEI7Q0FFQSxJQUFJLEVBQUUsR0FBRztFQUNMLEtBQUssUUFBUSxLQUFLO0VBQ2xCLEtBQUssU0FBUztDQUNsQjtDQUVBLElBQUksRUFBRSxHQUFHO0VBQ0wsS0FBSyxRQUFRLEtBQUs7RUFDbEIsS0FBSyxTQUFTO0NBQ2xCO0NBRUEsV0FBVztFQUNQLFdBQWtCLEtBQUssT0FBTztFQUM5QixLQUFLLFNBQVM7RUFDZCxPQUFPO0NBQ1g7Q0FFQSxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUc7RUFDWixJQUFJLEVBQUUsUUFBUSxPQUFPLEtBQUssS0FBSyxDQUFDO0VBQ2hDLE1BQWEsS0FBSyxTQUFTLEdBQUcsR0FBRyxHQUFHLENBQUM7RUFDckMsS0FBSyxTQUFTO0VBQ2QsT0FBTztDQUNYO0NBRUEsUUFBUSxHQUFHO0VBQ1AsUUFBaUIsS0FBSyxTQUFTLEtBQUssU0FBUyxDQUFDO0VBQzlDLEtBQUssU0FBUztFQUNkLE9BQU87Q0FDWDtDQUVBLFFBQVEsR0FBRztFQUNQLFFBQWlCLEtBQUssU0FBUyxLQUFLLFNBQVMsQ0FBQztFQUM5QyxLQUFLLFNBQVM7RUFDZCxPQUFPO0NBQ1g7Q0FFQSxRQUFRLEdBQUc7RUFDUCxRQUFpQixLQUFLLFNBQVMsS0FBSyxTQUFTLENBQUM7RUFDOUMsS0FBSyxTQUFTO0VBQ2QsT0FBTztDQUNYO0NBRUEsUUFBUSxJQUFJLEtBQUssU0FBUztFQUN0QixTQUFnQixLQUFLLFNBQVMsQ0FBQztFQUMvQixLQUFLLFNBQVM7RUFDZCxPQUFPO0NBQ1g7Q0FFQSxVQUFVLElBQUksS0FBSyxTQUFTO0VBQ3hCLFVBQW1CLEtBQUssU0FBUyxDQUFDO0VBQ2xDLEtBQUssU0FBUztFQUNkLE9BQU87Q0FDWDtDQUVBLEtBQUssR0FBRztFQUNKLE9BQWMsS0FBSyxTQUFTLENBQUM7RUFDN0IsS0FBSyxTQUFTO0VBQ2QsT0FBTztDQUNYO0NBRUEsVUFBVSxJQUFJLEtBQUssU0FBUztFQUN4QixZQUFtQixLQUFLLFNBQVMsQ0FBQztFQUNsQyxLQUFLLFNBQVM7RUFDZCxPQUFPO0NBQ1g7Q0FFQSxTQUFTLElBQUksSUFBSTtFQUNiLElBQUksSUFDQSxXQUFrQixLQUFLLFNBQVMsSUFBSSxFQUFFO09BRXRDLFdBQWtCLEtBQUssU0FBUyxLQUFLLFNBQVMsRUFBRTtFQUVwRCxLQUFLLFNBQVM7RUFDZCxPQUFPO0NBQ1g7Q0FFQSxJQUFJLEdBQUc7RUFDSCxPQUFPQyxNQUFhLEtBQUssU0FBUyxDQUFDO0NBQ3ZDO0NBRUEsWUFBWSxTQUFTO0VBQ2pCLFNBQWtCLEtBQUssU0FBUyxPQUFPO0VBQ3ZDLEtBQUssU0FBUztFQUNkLE9BQU87Q0FDWDtDQUVBLFVBQVUsT0FBTyxZQUFZO0VBQ3pCLFVBQW1CLEtBQUssU0FBUyxPQUFPLE1BQU0sS0FBSztFQUVuRCxJQUFJLENBQUMsWUFBWSxLQUFLLFNBQVM7RUFDL0IsT0FBTztDQUNYO0NBRUEsY0FBYyxNQUFNLEdBQUc7RUFDbkIsYUFBc0IsS0FBSyxTQUFTLE1BQU0sQ0FBQztFQUMzQyxLQUFLLFNBQVM7RUFDZCxPQUFPO0NBQ1g7Q0FFQSxNQUFNLEdBQUcsR0FBRztFQUNSLE1BQWUsS0FBSyxTQUFTLEtBQUssU0FBUyxHQUFHLENBQUM7RUFDL0MsS0FBSyxTQUFTO0VBQ2QsT0FBTztDQUNYO0NBRUEsVUFBVSxHQUFHLElBQUksR0FBRztFQUNoQixLQUFLLFFBQVEsS0FBSyxFQUFFO0VBQ3BCLEtBQUssUUFBUSxLQUFLLEVBQUUsSUFBSTtFQUN4QixLQUFLLFFBQVEsS0FBSyxFQUFFLElBQUk7RUFDeEIsS0FBSyxRQUFRLEtBQUssRUFBRSxJQUFJO0VBQ3hCLEtBQUssU0FBUztFQUNkLE9BQU87Q0FDWDtDQUVBLFFBQVEsSUFBSSxDQUFDLEdBQUcsSUFBSSxHQUFHO0VBQ25CLEVBQUUsS0FBSyxLQUFLO0VBQ1osRUFBRSxJQUFJLEtBQUssS0FBSztFQUNoQixFQUFFLElBQUksS0FBSyxLQUFLO0VBQ2hCLEVBQUUsSUFBSSxLQUFLLEtBQUs7RUFDaEIsT0FBTztDQUNYO0FBQ0o7OztBQ3JLQSxJQUFNLFVBQVU7Ozs7Ozs7O0FBU2hCLFNBQWdCQyxPQUFLLEtBQUssR0FBRztDQUN6QixJQUFJLEtBQUssRUFBRTtDQUNYLElBQUksS0FBSyxFQUFFO0NBQ1gsSUFBSSxLQUFLLEVBQUU7Q0FDWCxJQUFJLEtBQUssRUFBRTtDQUNYLElBQUksS0FBSyxFQUFFO0NBQ1gsSUFBSSxLQUFLLEVBQUU7Q0FDWCxJQUFJLEtBQUssRUFBRTtDQUNYLElBQUksS0FBSyxFQUFFO0NBQ1gsSUFBSSxLQUFLLEVBQUU7Q0FDWCxJQUFJLEtBQUssRUFBRTtDQUNYLElBQUksTUFBTSxFQUFFO0NBQ1osSUFBSSxNQUFNLEVBQUU7Q0FDWixJQUFJLE1BQU0sRUFBRTtDQUNaLElBQUksTUFBTSxFQUFFO0NBQ1osSUFBSSxNQUFNLEVBQUU7Q0FDWixJQUFJLE1BQU0sRUFBRTtDQUNaLE9BQU87QUFDWDs7Ozs7OztBQVFBLFNBQWdCQyxNQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSztDQUNyRyxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLE1BQU07Q0FDVixJQUFJLE1BQU07Q0FDVixJQUFJLE1BQU07Q0FDVixJQUFJLE1BQU07Q0FDVixJQUFJLE1BQU07Q0FDVixJQUFJLE1BQU07Q0FDVixPQUFPO0FBQ1g7Ozs7Ozs7QUFRQSxTQUFnQkMsV0FBUyxLQUFLO0NBQzFCLElBQUksS0FBSztDQUNULElBQUksS0FBSztDQUNULElBQUksS0FBSztDQUNULElBQUksS0FBSztDQUNULElBQUksS0FBSztDQUNULElBQUksS0FBSztDQUNULElBQUksS0FBSztDQUNULElBQUksS0FBSztDQUNULElBQUksS0FBSztDQUNULElBQUksS0FBSztDQUNULElBQUksTUFBTTtDQUNWLElBQUksTUFBTTtDQUNWLElBQUksTUFBTTtDQUNWLElBQUksTUFBTTtDQUNWLElBQUksTUFBTTtDQUNWLElBQUksTUFBTTtDQUNWLE9BQU87QUFDWDs7Ozs7Ozs7QUE0REEsU0FBZ0JDLFNBQU8sS0FBSyxHQUFHO0NBQzNCLElBQUksTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFO0NBQ1osSUFBSSxNQUFNLEVBQUUsSUFDUixNQUFNLEVBQUUsSUFDUixNQUFNLEVBQUUsSUFDUixNQUFNLEVBQUU7Q0FDWixJQUFJLE1BQU0sRUFBRSxJQUNSLE1BQU0sRUFBRSxJQUNSLE1BQU0sRUFBRSxLQUNSLE1BQU0sRUFBRTtDQUNaLElBQUksTUFBTSxFQUFFLEtBQ1IsTUFBTSxFQUFFLEtBQ1IsTUFBTSxFQUFFLEtBQ1IsTUFBTSxFQUFFO0NBRVosSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNO0NBQzVCLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUM1QixJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU07Q0FDNUIsSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNO0NBQzVCLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUM1QixJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU07Q0FDNUIsSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNO0NBQzVCLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUM1QixJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU07Q0FDNUIsSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNO0NBQzVCLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUM1QixJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU07Q0FHNUIsSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUU1RSxJQUFJLENBQUMsS0FDRCxPQUFPO0NBRVgsTUFBTSxJQUFNO0NBRVosSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxPQUFPO0NBQy9DLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sT0FBTztDQUMvQyxJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE9BQU87Q0FDL0MsSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxPQUFPO0NBQy9DLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sT0FBTztDQUMvQyxJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE9BQU87Q0FDL0MsSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxPQUFPO0NBQy9DLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sT0FBTztDQUMvQyxJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE9BQU87Q0FDL0MsSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxPQUFPO0NBQy9DLElBQUksT0FBTyxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sT0FBTztDQUNoRCxJQUFJLE9BQU8sTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE9BQU87Q0FDaEQsSUFBSSxPQUFPLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxPQUFPO0NBQ2hELElBQUksT0FBTyxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sT0FBTztDQUNoRCxJQUFJLE9BQU8sTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE9BQU87Q0FDaEQsSUFBSSxPQUFPLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxPQUFPO0NBRWhELE9BQU87QUFDWDs7Ozs7OztBQVFBLFNBQWdCLFlBQVksR0FBRztDQUMzQixJQUFJLE1BQU0sRUFBRSxJQUNSLE1BQU0sRUFBRSxJQUNSLE1BQU0sRUFBRSxJQUNSLE1BQU0sRUFBRTtDQUNaLElBQUksTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFO0NBQ1osSUFBSSxNQUFNLEVBQUUsSUFDUixNQUFNLEVBQUUsSUFDUixNQUFNLEVBQUUsS0FDUixNQUFNLEVBQUU7Q0FDWixJQUFJLE1BQU0sRUFBRSxLQUNSLE1BQU0sRUFBRSxLQUNSLE1BQU0sRUFBRSxLQUNSLE1BQU0sRUFBRTtDQUVaLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUM1QixJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU07Q0FDNUIsSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNO0NBQzVCLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUM1QixJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU07Q0FDNUIsSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNO0NBQzVCLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUM1QixJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU07Q0FDNUIsSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNO0NBQzVCLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUM1QixJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU07Q0FJNUIsT0FBTyxPQUhHLE1BQU0sTUFBTSxNQUFNLE9BR1QsTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU07QUFDN0U7Ozs7Ozs7OztBQVVBLFNBQWdCQyxXQUFTLEtBQUssR0FBRyxHQUFHO0NBQ2hDLElBQUksTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFO0NBQ1osSUFBSSxNQUFNLEVBQUUsSUFDUixNQUFNLEVBQUUsSUFDUixNQUFNLEVBQUUsSUFDUixNQUFNLEVBQUU7Q0FDWixJQUFJLE1BQU0sRUFBRSxJQUNSLE1BQU0sRUFBRSxJQUNSLE1BQU0sRUFBRSxLQUNSLE1BQU0sRUFBRTtDQUNaLElBQUksTUFBTSxFQUFFLEtBQ1IsTUFBTSxFQUFFLEtBQ1IsTUFBTSxFQUFFLEtBQ1IsTUFBTSxFQUFFO0NBR1osSUFBSSxLQUFLLEVBQUUsSUFDUCxLQUFLLEVBQUUsSUFDUCxLQUFLLEVBQUUsSUFDUCxLQUFLLEVBQUU7Q0FDWCxJQUFJLEtBQUssS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSztDQUMvQyxJQUFJLEtBQUssS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSztDQUMvQyxJQUFJLEtBQUssS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSztDQUMvQyxJQUFJLEtBQUssS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSztDQUUvQyxLQUFLLEVBQUU7Q0FDUCxLQUFLLEVBQUU7Q0FDUCxLQUFLLEVBQUU7Q0FDUCxLQUFLLEVBQUU7Q0FDUCxJQUFJLEtBQUssS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSztDQUMvQyxJQUFJLEtBQUssS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSztDQUMvQyxJQUFJLEtBQUssS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSztDQUMvQyxJQUFJLEtBQUssS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSztDQUUvQyxLQUFLLEVBQUU7Q0FDUCxLQUFLLEVBQUU7Q0FDUCxLQUFLLEVBQUU7Q0FDUCxLQUFLLEVBQUU7Q0FDUCxJQUFJLEtBQUssS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSztDQUMvQyxJQUFJLEtBQUssS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSztDQUMvQyxJQUFJLE1BQU0sS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSztDQUNoRCxJQUFJLE1BQU0sS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSztDQUVoRCxLQUFLLEVBQUU7Q0FDUCxLQUFLLEVBQUU7Q0FDUCxLQUFLLEVBQUU7Q0FDUCxLQUFLLEVBQUU7Q0FDUCxJQUFJLE1BQU0sS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSztDQUNoRCxJQUFJLE1BQU0sS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSztDQUNoRCxJQUFJLE1BQU0sS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSztDQUNoRCxJQUFJLE1BQU0sS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSztDQUNoRCxPQUFPO0FBQ1g7Ozs7Ozs7OztBQVVBLFNBQWdCQyxZQUFVLEtBQUssR0FBRyxHQUFHO0NBQ2pDLElBQUksSUFBSSxFQUFFLElBQ04sSUFBSSxFQUFFLElBQ04sSUFBSSxFQUFFO0NBQ1YsSUFBSSxLQUFLLEtBQUssS0FBSztDQUNuQixJQUFJLEtBQUssS0FBSyxLQUFLO0NBQ25CLElBQUksS0FBSyxLQUFLLEtBQUs7Q0FFbkIsSUFBSSxNQUFNLEtBQUs7RUFDWCxJQUFJLE1BQU0sRUFBRSxLQUFLLElBQUksRUFBRSxLQUFLLElBQUksRUFBRSxLQUFLLElBQUksRUFBRTtFQUM3QyxJQUFJLE1BQU0sRUFBRSxLQUFLLElBQUksRUFBRSxLQUFLLElBQUksRUFBRSxLQUFLLElBQUksRUFBRTtFQUM3QyxJQUFJLE1BQU0sRUFBRSxLQUFLLElBQUksRUFBRSxLQUFLLElBQUksRUFBRSxNQUFNLElBQUksRUFBRTtFQUM5QyxJQUFJLE1BQU0sRUFBRSxLQUFLLElBQUksRUFBRSxLQUFLLElBQUksRUFBRSxNQUFNLElBQUksRUFBRTtDQUNsRCxPQUFPO0VBQ0gsTUFBTSxFQUFFO0VBQ1IsTUFBTSxFQUFFO0VBQ1IsTUFBTSxFQUFFO0VBQ1IsTUFBTSxFQUFFO0VBQ1IsTUFBTSxFQUFFO0VBQ1IsTUFBTSxFQUFFO0VBQ1IsTUFBTSxFQUFFO0VBQ1IsTUFBTSxFQUFFO0VBQ1IsTUFBTSxFQUFFO0VBQ1IsTUFBTSxFQUFFO0VBQ1IsTUFBTSxFQUFFO0VBQ1IsTUFBTSxFQUFFO0VBRVIsSUFBSSxLQUFLO0VBQ1QsSUFBSSxLQUFLO0VBQ1QsSUFBSSxLQUFLO0VBQ1QsSUFBSSxLQUFLO0VBQ1QsSUFBSSxLQUFLO0VBQ1QsSUFBSSxLQUFLO0VBQ1QsSUFBSSxLQUFLO0VBQ1QsSUFBSSxLQUFLO0VBQ1QsSUFBSSxLQUFLO0VBQ1QsSUFBSSxLQUFLO0VBQ1QsSUFBSSxNQUFNO0VBQ1YsSUFBSSxNQUFNO0VBRVYsSUFBSSxNQUFNLE1BQU0sSUFBSSxNQUFNLElBQUksTUFBTSxJQUFJLEVBQUU7RUFDMUMsSUFBSSxNQUFNLE1BQU0sSUFBSSxNQUFNLElBQUksTUFBTSxJQUFJLEVBQUU7RUFDMUMsSUFBSSxNQUFNLE1BQU0sSUFBSSxNQUFNLElBQUksTUFBTSxJQUFJLEVBQUU7RUFDMUMsSUFBSSxNQUFNLE1BQU0sSUFBSSxNQUFNLElBQUksTUFBTSxJQUFJLEVBQUU7Q0FDOUM7Q0FFQSxPQUFPO0FBQ1g7Ozs7Ozs7OztBQVVBLFNBQWdCQyxRQUFNLEtBQUssR0FBRyxHQUFHO0NBQzdCLElBQUksSUFBSSxFQUFFLElBQ04sSUFBSSxFQUFFLElBQ04sSUFBSSxFQUFFO0NBRVYsSUFBSSxLQUFLLEVBQUUsS0FBSztDQUNoQixJQUFJLEtBQUssRUFBRSxLQUFLO0NBQ2hCLElBQUksS0FBSyxFQUFFLEtBQUs7Q0FDaEIsSUFBSSxLQUFLLEVBQUUsS0FBSztDQUNoQixJQUFJLEtBQUssRUFBRSxLQUFLO0NBQ2hCLElBQUksS0FBSyxFQUFFLEtBQUs7Q0FDaEIsSUFBSSxLQUFLLEVBQUUsS0FBSztDQUNoQixJQUFJLEtBQUssRUFBRSxLQUFLO0NBQ2hCLElBQUksS0FBSyxFQUFFLEtBQUs7Q0FDaEIsSUFBSSxLQUFLLEVBQUUsS0FBSztDQUNoQixJQUFJLE1BQU0sRUFBRSxNQUFNO0NBQ2xCLElBQUksTUFBTSxFQUFFLE1BQU07Q0FDbEIsSUFBSSxNQUFNLEVBQUU7Q0FDWixJQUFJLE1BQU0sRUFBRTtDQUNaLElBQUksTUFBTSxFQUFFO0NBQ1osSUFBSSxNQUFNLEVBQUU7Q0FDWixPQUFPO0FBQ1g7Ozs7Ozs7Ozs7QUFXQSxTQUFnQkMsU0FBTyxLQUFLLEdBQUcsS0FBSyxNQUFNO0NBQ3RDLElBQUksSUFBSSxLQUFLLElBQ1QsSUFBSSxLQUFLLElBQ1QsSUFBSSxLQUFLO0NBQ2IsSUFBSSxNQUFNLEtBQUssTUFBTSxHQUFHLEdBQUcsQ0FBQztDQUM1QixJQUFJLEdBQUcsR0FBRztDQUNWLElBQUksS0FBSyxLQUFLLEtBQUs7Q0FDbkIsSUFBSSxLQUFLLEtBQUssS0FBSztDQUNuQixJQUFJLEtBQUssS0FBSyxLQUFLO0NBQ25CLElBQUksS0FBSyxLQUFLO0NBQ2QsSUFBSSxLQUFLLEtBQUs7Q0FDZCxJQUFJLEtBQUssS0FBSztDQUVkLElBQUksS0FBSyxJQUFJLEdBQUcsSUFBSSxTQUNoQixPQUFPO0NBR1gsTUFBTSxJQUFJO0NBQ1YsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBRUwsSUFBSSxLQUFLLElBQUksR0FBRztDQUNoQixJQUFJLEtBQUssSUFBSSxHQUFHO0NBQ2hCLElBQUksSUFBSTtDQUVSLE1BQU0sRUFBRTtDQUNSLE1BQU0sRUFBRTtDQUNSLE1BQU0sRUFBRTtDQUNSLE1BQU0sRUFBRTtDQUNSLE1BQU0sRUFBRTtDQUNSLE1BQU0sRUFBRTtDQUNSLE1BQU0sRUFBRTtDQUNSLE1BQU0sRUFBRTtDQUNSLE1BQU0sRUFBRTtDQUNSLE1BQU0sRUFBRTtDQUNSLE1BQU0sRUFBRTtDQUNSLE1BQU0sRUFBRTtDQUdSLE1BQU0sSUFBSSxJQUFJLElBQUk7Q0FDbEIsTUFBTSxJQUFJLElBQUksSUFBSSxJQUFJO0NBQ3RCLE1BQU0sSUFBSSxJQUFJLElBQUksSUFBSTtDQUN0QixNQUFNLElBQUksSUFBSSxJQUFJLElBQUk7Q0FDdEIsTUFBTSxJQUFJLElBQUksSUFBSTtDQUNsQixNQUFNLElBQUksSUFBSSxJQUFJLElBQUk7Q0FDdEIsTUFBTSxJQUFJLElBQUksSUFBSSxJQUFJO0NBQ3RCLE1BQU0sSUFBSSxJQUFJLElBQUksSUFBSTtDQUN0QixNQUFNLElBQUksSUFBSSxJQUFJO0NBR2xCLElBQUksS0FBSyxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU07Q0FDdkMsSUFBSSxLQUFLLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUN2QyxJQUFJLEtBQUssTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNO0NBQ3ZDLElBQUksS0FBSyxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU07Q0FDdkMsSUFBSSxLQUFLLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUN2QyxJQUFJLEtBQUssTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNO0NBQ3ZDLElBQUksS0FBSyxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU07Q0FDdkMsSUFBSSxLQUFLLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUN2QyxJQUFJLEtBQUssTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNO0NBQ3ZDLElBQUksS0FBSyxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU07Q0FDdkMsSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUN4QyxJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNO0NBRXhDLElBQUksTUFBTSxLQUFLO0VBRVgsSUFBSSxNQUFNLEVBQUU7RUFDWixJQUFJLE1BQU0sRUFBRTtFQUNaLElBQUksTUFBTSxFQUFFO0VBQ1osSUFBSSxNQUFNLEVBQUU7Q0FDaEI7Q0FDQSxPQUFPO0FBQ1g7Ozs7Ozs7Ozs7QUFXQSxTQUFnQixlQUFlLEtBQUssS0FBSztDQUNyQyxJQUFJLEtBQUssSUFBSTtDQUNiLElBQUksS0FBSyxJQUFJO0NBQ2IsSUFBSSxLQUFLLElBQUk7Q0FFYixPQUFPO0FBQ1g7Ozs7Ozs7Ozs7O0FBWUEsU0FBZ0IsV0FBVyxLQUFLLEtBQUs7Q0FDakMsSUFBSSxNQUFNLElBQUk7Q0FDZCxJQUFJLE1BQU0sSUFBSTtDQUNkLElBQUksTUFBTSxJQUFJO0NBQ2QsSUFBSSxNQUFNLElBQUk7Q0FDZCxJQUFJLE1BQU0sSUFBSTtDQUNkLElBQUksTUFBTSxJQUFJO0NBQ2QsSUFBSSxNQUFNLElBQUk7Q0FDZCxJQUFJLE1BQU0sSUFBSTtDQUNkLElBQUksTUFBTSxJQUFJO0NBRWQsSUFBSSxLQUFLLEtBQUssTUFBTSxLQUFLLEtBQUssR0FBRztDQUNqQyxJQUFJLEtBQUssS0FBSyxNQUFNLEtBQUssS0FBSyxHQUFHO0NBQ2pDLElBQUksS0FBSyxLQUFLLE1BQU0sS0FBSyxLQUFLLEdBQUc7Q0FFakMsT0FBTztBQUNYO0FBRUEsU0FBZ0Isa0JBQWtCLEtBQUs7Q0FDbkMsSUFBSSxNQUFNLElBQUk7Q0FDZCxJQUFJLE1BQU0sSUFBSTtDQUNkLElBQUksTUFBTSxJQUFJO0NBQ2QsSUFBSSxNQUFNLElBQUk7Q0FDZCxJQUFJLE1BQU0sSUFBSTtDQUNkLElBQUksTUFBTSxJQUFJO0NBQ2QsSUFBSSxNQUFNLElBQUk7Q0FDZCxJQUFJLE1BQU0sSUFBSTtDQUNkLElBQUksTUFBTSxJQUFJO0NBRWQsTUFBTSxJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUN4QyxNQUFNLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNO0NBQ3hDLE1BQU0sSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU07Q0FFeEMsT0FBTyxLQUFLLEtBQUssS0FBSyxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUM7QUFDdEM7Ozs7Ozs7Ozs7QUFXQSxJQUFhLGVBQWUsV0FBWTtDQUNwQyxNQUFNLE9BQU87RUFBQztFQUFHO0VBQUc7Q0FBQztDQUVyQixPQUFPLFNBQVUsS0FBSyxLQUFLO0VBQ3ZCLElBQUksVUFBVTtFQUNkLFdBQVcsU0FBUyxHQUFHO0VBRXZCLElBQUksTUFBTSxJQUFJLFFBQVE7RUFDdEIsSUFBSSxNQUFNLElBQUksUUFBUTtFQUN0QixJQUFJLE1BQU0sSUFBSSxRQUFRO0VBRXRCLElBQUksT0FBTyxJQUFJLEtBQUs7RUFDcEIsSUFBSSxPQUFPLElBQUksS0FBSztFQUNwQixJQUFJLE9BQU8sSUFBSSxLQUFLO0VBQ3BCLElBQUksT0FBTyxJQUFJLEtBQUs7RUFDcEIsSUFBSSxPQUFPLElBQUksS0FBSztFQUNwQixJQUFJLE9BQU8sSUFBSSxLQUFLO0VBQ3BCLElBQUksT0FBTyxJQUFJLEtBQUs7RUFDcEIsSUFBSSxPQUFPLElBQUksS0FBSztFQUNwQixJQUFJLE9BQU8sSUFBSSxNQUFNO0VBRXJCLElBQUksUUFBUSxPQUFPLE9BQU87RUFDMUIsSUFBSSxJQUFJO0VBRVIsSUFBSSxRQUFRLEdBQUc7R0FDWCxJQUFJLEtBQUssS0FBSyxRQUFRLENBQUcsSUFBSTtHQUM3QixJQUFJLEtBQUssTUFBTztHQUNoQixJQUFJLE1BQU0sT0FBTyxRQUFRO0dBQ3pCLElBQUksTUFBTSxPQUFPLFFBQVE7R0FDekIsSUFBSSxNQUFNLE9BQU8sUUFBUTtFQUM3QixPQUFPLElBQUksT0FBTyxRQUFRLE9BQU8sTUFBTTtHQUNuQyxJQUFJLEtBQUssS0FBSyxJQUFNLE9BQU8sT0FBTyxJQUFJLElBQUk7R0FDMUMsSUFBSSxNQUFNLE9BQU8sUUFBUTtHQUN6QixJQUFJLEtBQUssTUFBTztHQUNoQixJQUFJLE1BQU0sT0FBTyxRQUFRO0dBQ3pCLElBQUksTUFBTSxPQUFPLFFBQVE7RUFDN0IsT0FBTyxJQUFJLE9BQU8sTUFBTTtHQUNwQixJQUFJLEtBQUssS0FBSyxJQUFNLE9BQU8sT0FBTyxJQUFJLElBQUk7R0FDMUMsSUFBSSxNQUFNLE9BQU8sUUFBUTtHQUN6QixJQUFJLE1BQU0sT0FBTyxRQUFRO0dBQ3pCLElBQUksS0FBSyxNQUFPO0dBQ2hCLElBQUksTUFBTSxPQUFPLFFBQVE7RUFDN0IsT0FBTztHQUNILElBQUksS0FBSyxLQUFLLElBQU0sT0FBTyxPQUFPLElBQUksSUFBSTtHQUMxQyxJQUFJLE1BQU0sT0FBTyxRQUFRO0dBQ3pCLElBQUksTUFBTSxPQUFPLFFBQVE7R0FDekIsSUFBSSxNQUFNLE9BQU8sUUFBUTtHQUN6QixJQUFJLEtBQUssTUFBTztFQUNwQjtFQUVBLE9BQU87Q0FDWDtBQUNKLEVBQUEsQ0FBRzs7Ozs7Ozs7Ozs7Ozs7O0FBZ0JILFNBQWdCLFVBQVUsUUFBUSxhQUFhLGdCQUFnQixVQUFVO0NBQ3JFLElBQUksS0FBS0MsU0FBWTtFQUFDLE9BQU87RUFBSSxPQUFPO0VBQUksT0FBTztDQUFFLENBQUM7Q0FDdEQsTUFBTSxLQUFLQSxTQUFZO0VBQUMsT0FBTztFQUFJLE9BQU87RUFBSSxPQUFPO0NBQUUsQ0FBQztDQUN4RCxNQUFNLEtBQUtBLFNBQVk7RUFBQyxPQUFPO0VBQUksT0FBTztFQUFJLE9BQU87Q0FBRyxDQUFDO0NBSXpELElBRFksWUFBWSxNQUNsQixJQUFJLEdBQUcsS0FBSyxDQUFDO0NBRW5CLGVBQWUsS0FBSyxPQUFPO0NBQzNCLGVBQWUsS0FBSyxPQUFPO0NBQzNCLGVBQWUsS0FBSyxPQUFPO0NBRzNCLE1BQU0sTUFBTSxPQUFPLE1BQU07Q0FFekIsTUFBTSxRQUFRLElBQUk7Q0FDbEIsTUFBTSxRQUFRLElBQUk7Q0FDbEIsTUFBTSxRQUFRLElBQUk7Q0FFbEIsSUFBSSxNQUFNO0NBQ1YsSUFBSSxNQUFNO0NBQ1YsSUFBSSxNQUFNO0NBRVYsSUFBSSxNQUFNO0NBQ1YsSUFBSSxNQUFNO0NBQ1YsSUFBSSxNQUFNO0NBRVYsSUFBSSxNQUFNO0NBQ1YsSUFBSSxNQUFNO0NBQ1YsSUFBSSxPQUFPO0NBRVgsWUFBWSxhQUFhLEdBQUc7Q0FFNUIsU0FBUyxLQUFLO0NBQ2QsU0FBUyxLQUFLO0NBQ2QsU0FBUyxLQUFLO0FBQ2xCOzs7Ozs7Ozs7Ozs7Ozs7O0FBaUJBLFNBQWdCLFFBQVEsUUFBUSxhQUFhLGdCQUFnQixVQUFVO0NBQ25FLE1BQU0sS0FBSztDQUVYLE1BQU0sSUFBSSxZQUFZLElBQ2xCLElBQUksWUFBWSxJQUNoQixJQUFJLFlBQVksSUFDaEIsSUFBSSxZQUFZO0NBQ3BCLE1BQU0sS0FBSyxJQUFJLEdBQ1gsS0FBSyxJQUFJLEdBQ1QsS0FBSyxJQUFJO0NBQ2IsTUFBTSxLQUFLLElBQUksSUFDWCxLQUFLLElBQUksSUFDVCxLQUFLLElBQUk7Q0FDYixNQUFNLEtBQUssSUFBSSxJQUNYLEtBQUssSUFBSSxJQUNULEtBQUssSUFBSTtDQUNiLE1BQU0sS0FBSyxJQUFJLElBQ1gsS0FBSyxJQUFJLElBQ1QsS0FBSyxJQUFJO0NBRWIsTUFBTSxLQUFLLFNBQVMsSUFDaEIsS0FBSyxTQUFTLElBQ2QsS0FBSyxTQUFTO0NBRWxCLEdBQUcsTUFBTSxLQUFLLEtBQUssT0FBTztDQUMxQixHQUFHLE1BQU0sS0FBSyxNQUFNO0NBQ3BCLEdBQUcsTUFBTSxLQUFLLE1BQU07Q0FDcEIsR0FBRyxLQUFLO0NBRVIsR0FBRyxNQUFNLEtBQUssTUFBTTtDQUNwQixHQUFHLE1BQU0sS0FBSyxLQUFLLE9BQU87Q0FDMUIsR0FBRyxNQUFNLEtBQUssTUFBTTtDQUNwQixHQUFHLEtBQUs7Q0FFUixHQUFHLE1BQU0sS0FBSyxNQUFNO0NBQ3BCLEdBQUcsTUFBTSxLQUFLLE1BQU07Q0FDcEIsR0FBRyxPQUFPLEtBQUssS0FBSyxPQUFPO0NBQzNCLEdBQUcsTUFBTTtDQUVULEdBQUcsTUFBTSxlQUFlO0NBQ3hCLEdBQUcsTUFBTSxlQUFlO0NBQ3hCLEdBQUcsTUFBTSxlQUFlO0NBQ3hCLEdBQUcsTUFBTTtDQUVULE9BQU87QUFDWDs7Ozs7Ozs7O0FBc0VBLFNBQWdCQyxXQUFTLEtBQUssR0FBRztDQUM3QixJQUFJLElBQUksRUFBRSxJQUNOLElBQUksRUFBRSxJQUNOLElBQUksRUFBRSxJQUNOLElBQUksRUFBRTtDQUNWLElBQUksS0FBSyxJQUFJO0NBQ2IsSUFBSSxLQUFLLElBQUk7Q0FDYixJQUFJLEtBQUssSUFBSTtDQUViLElBQUksS0FBSyxJQUFJO0NBQ2IsSUFBSSxLQUFLLElBQUk7Q0FDYixJQUFJLEtBQUssSUFBSTtDQUNiLElBQUksS0FBSyxJQUFJO0NBQ2IsSUFBSSxLQUFLLElBQUk7Q0FDYixJQUFJLEtBQUssSUFBSTtDQUNiLElBQUksS0FBSyxJQUFJO0NBQ2IsSUFBSSxLQUFLLElBQUk7Q0FDYixJQUFJLEtBQUssSUFBSTtDQUViLElBQUksS0FBSyxJQUFJLEtBQUs7Q0FDbEIsSUFBSSxLQUFLLEtBQUs7Q0FDZCxJQUFJLEtBQUssS0FBSztDQUNkLElBQUksS0FBSztDQUVULElBQUksS0FBSyxLQUFLO0NBQ2QsSUFBSSxLQUFLLElBQUksS0FBSztDQUNsQixJQUFJLEtBQUssS0FBSztDQUNkLElBQUksS0FBSztDQUVULElBQUksS0FBSyxLQUFLO0NBQ2QsSUFBSSxLQUFLLEtBQUs7Q0FDZCxJQUFJLE1BQU0sSUFBSSxLQUFLO0NBQ25CLElBQUksTUFBTTtDQUVWLElBQUksTUFBTTtDQUNWLElBQUksTUFBTTtDQUNWLElBQUksTUFBTTtDQUNWLElBQUksTUFBTTtDQUVWLE9BQU87QUFDWDs7Ozs7Ozs7Ozs7QUFZQSxTQUFnQixZQUFZLEtBQUssTUFBTSxRQUFRLE1BQU0sS0FBSztDQUN0RCxJQUFJLElBQUksSUFBTSxLQUFLLElBQUksT0FBTyxDQUFDO0NBQy9CLElBQUksS0FBSyxLQUFLLE9BQU87Q0FDckIsSUFBSSxLQUFLLElBQUk7Q0FDYixJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLE9BQU8sTUFBTSxRQUFRO0NBQ3pCLElBQUksTUFBTTtDQUNWLElBQUksTUFBTTtDQUNWLElBQUksTUFBTTtDQUNWLElBQUksTUFBTSxJQUFJLE1BQU0sT0FBTztDQUMzQixJQUFJLE1BQU07Q0FDVixPQUFPO0FBQ1g7Ozs7Ozs7Ozs7Ozs7QUFjQSxTQUFnQixNQUFNLEtBQUssTUFBTSxPQUFPLFFBQVEsS0FBSyxNQUFNLEtBQUs7Q0FDNUQsSUFBSSxLQUFLLEtBQUssT0FBTztDQUNyQixJQUFJLEtBQUssS0FBSyxTQUFTO0NBQ3ZCLElBQUksS0FBSyxLQUFLLE9BQU87Q0FDckIsSUFBSSxLQUFLLEtBQUs7Q0FDZCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUssS0FBSztDQUNkLElBQUksS0FBSztDQUNULElBQUksS0FBSztDQUNULElBQUksS0FBSztDQUNULElBQUksS0FBSztDQUNULElBQUksTUFBTSxJQUFJO0NBQ2QsSUFBSSxNQUFNO0NBQ1YsSUFBSSxPQUFPLE9BQU8sU0FBUztDQUMzQixJQUFJLE9BQU8sTUFBTSxVQUFVO0NBQzNCLElBQUksT0FBTyxNQUFNLFFBQVE7Q0FDekIsSUFBSSxNQUFNO0NBQ1YsT0FBTztBQUNYOzs7Ozs7Ozs7O0FBV0EsU0FBZ0IsU0FBUyxLQUFLLEtBQUssUUFBUSxJQUFJO0NBQzNDLElBQUksT0FBTyxJQUFJLElBQ1gsT0FBTyxJQUFJLElBQ1gsT0FBTyxJQUFJLElBQ1gsTUFBTSxHQUFHLElBQ1QsTUFBTSxHQUFHLElBQ1QsTUFBTSxHQUFHO0NBRWIsSUFBSSxLQUFLLE9BQU8sT0FBTyxJQUNuQixLQUFLLE9BQU8sT0FBTyxJQUNuQixLQUFLLE9BQU8sT0FBTztDQUV2QixJQUFJLE1BQU0sS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLO0NBQ25DLElBQUksUUFBUSxHQUVSLEtBQUs7TUFDRjtFQUNILE1BQU0sSUFBSSxLQUFLLEtBQUssR0FBRztFQUN2QixNQUFNO0VBQ04sTUFBTTtFQUNOLE1BQU07Q0FDVjtDQUVBLElBQUksS0FBSyxNQUFNLEtBQUssTUFBTSxJQUN0QixLQUFLLE1BQU0sS0FBSyxNQUFNLElBQ3RCLEtBQUssTUFBTSxLQUFLLE1BQU07Q0FFMUIsTUFBTSxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUs7Q0FDL0IsSUFBSSxRQUFRLEdBQUc7RUFFWCxJQUFJLEtBQ0EsT0FBTztPQUNKLElBQUksS0FDUCxPQUFPO09BRVAsT0FBTztFQUVYLEtBQU0sTUFBTSxLQUFLLE1BQU0sSUFBTSxLQUFLLE1BQU0sS0FBSyxNQUFNLElBQU0sS0FBSyxNQUFNLEtBQUssTUFBTTtFQUUvRSxNQUFNLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSztDQUNuQztDQUVBLE1BQU0sSUFBSSxLQUFLLEtBQUssR0FBRztDQUN2QixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FFTixJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUs7Q0FDeEIsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLO0NBQ3hCLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSztDQUN4QixJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLE1BQU07Q0FDVixJQUFJLE1BQU07Q0FDVixJQUFJLE1BQU07Q0FDVixJQUFJLE1BQU07Q0FDVixJQUFJLE1BQU07Q0FDVixJQUFJLE1BQU07Q0FDVixPQUFPO0FBQ1g7Ozs7Ozs7OztBQVVBLFNBQWdCQyxNQUFJLEtBQUssR0FBRyxHQUFHO0NBQzNCLElBQUksS0FBSyxFQUFFLEtBQUssRUFBRTtDQUNsQixJQUFJLEtBQUssRUFBRSxLQUFLLEVBQUU7Q0FDbEIsSUFBSSxLQUFLLEVBQUUsS0FBSyxFQUFFO0NBQ2xCLElBQUksS0FBSyxFQUFFLEtBQUssRUFBRTtDQUNsQixJQUFJLEtBQUssRUFBRSxLQUFLLEVBQUU7Q0FDbEIsSUFBSSxLQUFLLEVBQUUsS0FBSyxFQUFFO0NBQ2xCLElBQUksS0FBSyxFQUFFLEtBQUssRUFBRTtDQUNsQixJQUFJLEtBQUssRUFBRSxLQUFLLEVBQUU7Q0FDbEIsSUFBSSxLQUFLLEVBQUUsS0FBSyxFQUFFO0NBQ2xCLElBQUksS0FBSyxFQUFFLEtBQUssRUFBRTtDQUNsQixJQUFJLE1BQU0sRUFBRSxNQUFNLEVBQUU7Q0FDcEIsSUFBSSxNQUFNLEVBQUUsTUFBTSxFQUFFO0NBQ3BCLElBQUksTUFBTSxFQUFFLE1BQU0sRUFBRTtDQUNwQixJQUFJLE1BQU0sRUFBRSxNQUFNLEVBQUU7Q0FDcEIsSUFBSSxNQUFNLEVBQUUsTUFBTSxFQUFFO0NBQ3BCLElBQUksTUFBTSxFQUFFLE1BQU0sRUFBRTtDQUNwQixPQUFPO0FBQ1g7Ozs7Ozs7OztBQVVBLFNBQWdCQyxXQUFTLEtBQUssR0FBRyxHQUFHO0NBQ2hDLElBQUksS0FBSyxFQUFFLEtBQUssRUFBRTtDQUNsQixJQUFJLEtBQUssRUFBRSxLQUFLLEVBQUU7Q0FDbEIsSUFBSSxLQUFLLEVBQUUsS0FBSyxFQUFFO0NBQ2xCLElBQUksS0FBSyxFQUFFLEtBQUssRUFBRTtDQUNsQixJQUFJLEtBQUssRUFBRSxLQUFLLEVBQUU7Q0FDbEIsSUFBSSxLQUFLLEVBQUUsS0FBSyxFQUFFO0NBQ2xCLElBQUksS0FBSyxFQUFFLEtBQUssRUFBRTtDQUNsQixJQUFJLEtBQUssRUFBRSxLQUFLLEVBQUU7Q0FDbEIsSUFBSSxLQUFLLEVBQUUsS0FBSyxFQUFFO0NBQ2xCLElBQUksS0FBSyxFQUFFLEtBQUssRUFBRTtDQUNsQixJQUFJLE1BQU0sRUFBRSxNQUFNLEVBQUU7Q0FDcEIsSUFBSSxNQUFNLEVBQUUsTUFBTSxFQUFFO0NBQ3BCLElBQUksTUFBTSxFQUFFLE1BQU0sRUFBRTtDQUNwQixJQUFJLE1BQU0sRUFBRSxNQUFNLEVBQUU7Q0FDcEIsSUFBSSxNQUFNLEVBQUUsTUFBTSxFQUFFO0NBQ3BCLElBQUksTUFBTSxFQUFFLE1BQU0sRUFBRTtDQUNwQixPQUFPO0FBQ1g7Ozs7Ozs7OztBQVVBLFNBQWdCLGVBQWUsS0FBSyxHQUFHLEdBQUc7Q0FDdEMsSUFBSSxLQUFLLEVBQUUsS0FBSztDQUNoQixJQUFJLEtBQUssRUFBRSxLQUFLO0NBQ2hCLElBQUksS0FBSyxFQUFFLEtBQUs7Q0FDaEIsSUFBSSxLQUFLLEVBQUUsS0FBSztDQUNoQixJQUFJLEtBQUssRUFBRSxLQUFLO0NBQ2hCLElBQUksS0FBSyxFQUFFLEtBQUs7Q0FDaEIsSUFBSSxLQUFLLEVBQUUsS0FBSztDQUNoQixJQUFJLEtBQUssRUFBRSxLQUFLO0NBQ2hCLElBQUksS0FBSyxFQUFFLEtBQUs7Q0FDaEIsSUFBSSxLQUFLLEVBQUUsS0FBSztDQUNoQixJQUFJLE1BQU0sRUFBRSxNQUFNO0NBQ2xCLElBQUksTUFBTSxFQUFFLE1BQU07Q0FDbEIsSUFBSSxNQUFNLEVBQUUsTUFBTTtDQUNsQixJQUFJLE1BQU0sRUFBRSxNQUFNO0NBQ2xCLElBQUksTUFBTSxFQUFFLE1BQU07Q0FDbEIsSUFBSSxNQUFNLEVBQUUsTUFBTTtDQUNsQixPQUFPO0FBQ1g7OztBQzNoQ0EsSUFBYSxPQUFiLGNBQTBCLE1BQU07Q0FDNUIsWUFDSSxNQUFNLEdBQ04sTUFBTSxHQUNOLE1BQU0sR0FDTixNQUFNLEdBQ04sTUFBTSxHQUNOLE1BQU0sR0FDTixNQUFNLEdBQ04sTUFBTSxHQUNOLE1BQU0sR0FDTixNQUFNLEdBQ04sTUFBTSxHQUNOLE1BQU0sR0FDTixNQUFNLEdBQ04sTUFBTSxHQUNOLE1BQU0sR0FDTixNQUFNLEdBQ1I7RUFDRSxNQUFNLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEdBQUc7RUFDcEYsT0FBTztDQUNYO0NBRUEsSUFBSSxJQUFJO0VBQ0osT0FBTyxLQUFLO0NBQ2hCO0NBRUEsSUFBSSxJQUFJO0VBQ0osT0FBTyxLQUFLO0NBQ2hCO0NBRUEsSUFBSSxJQUFJO0VBQ0osT0FBTyxLQUFLO0NBQ2hCO0NBRUEsSUFBSSxJQUFJO0VBQ0osT0FBTyxLQUFLO0NBQ2hCO0NBRUEsSUFBSSxFQUFFLEdBQUc7RUFDTCxLQUFLLE1BQU07Q0FDZjtDQUVBLElBQUksRUFBRSxHQUFHO0VBQ0wsS0FBSyxNQUFNO0NBQ2Y7Q0FFQSxJQUFJLEVBQUUsR0FBRztFQUNMLEtBQUssTUFBTTtDQUNmO0NBRUEsSUFBSSxFQUFFLEdBQUc7RUFDTCxLQUFLLE1BQU07Q0FDZjtDQUVBLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSztFQUNoRixJQUFJLElBQUksUUFBUSxPQUFPLEtBQUssS0FBSyxHQUFHO0VBQ3BDLE1BQWEsTUFBTSxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxHQUFHO0VBQ2pHLE9BQU87Q0FDWDtDQUVBLFVBQVUsR0FBRyxJQUFJLE1BQU07RUFDbkIsWUFBbUIsTUFBTSxHQUFHLENBQUM7RUFDN0IsT0FBTztDQUNYO0NBRUEsT0FBTyxHQUFHLE1BQU0sSUFBSSxNQUFNO0VBQ3RCLFNBQWdCLE1BQU0sR0FBRyxHQUFHLElBQUk7RUFDaEMsT0FBTztDQUNYO0NBRUEsTUFBTSxHQUFHLElBQUksTUFBTTtFQUNmLFFBQWUsTUFBTSxHQUFHLE9BQU8sTUFBTSxXQUFXO0dBQUM7R0FBRztHQUFHO0VBQUMsSUFBSSxDQUFDO0VBQzdELE9BQU87Q0FDWDtDQUVBLElBQUksSUFBSSxJQUFJO0VBQ1IsSUFBSSxJQUFJLE1BQWEsTUFBTSxJQUFJLEVBQUU7T0FDNUIsTUFBYSxNQUFNLE1BQU0sRUFBRTtFQUNoQyxPQUFPO0NBQ1g7Q0FFQSxJQUFJLElBQUksSUFBSTtFQUNSLElBQUksSUFBSSxXQUFrQixNQUFNLElBQUksRUFBRTtPQUNqQyxXQUFrQixNQUFNLE1BQU0sRUFBRTtFQUNyQyxPQUFPO0NBQ1g7Q0FFQSxTQUFTLElBQUksSUFBSTtFQUNiLElBQUksQ0FBQyxHQUFHLFFBQ0osZUFBd0IsTUFBTSxNQUFNLEVBQUU7T0FDbkMsSUFBSSxJQUNQLFdBQWtCLE1BQU0sSUFBSSxFQUFFO09BRTlCLFdBQWtCLE1BQU0sTUFBTSxFQUFFO0VBRXBDLE9BQU87Q0FDWDtDQUVBLFdBQVc7RUFDUCxXQUFrQixJQUFJO0VBQ3RCLE9BQU87Q0FDWDtDQUVBLEtBQUssR0FBRztFQUNKLE9BQWMsTUFBTSxDQUFDO0VBQ3JCLE9BQU87Q0FDWDtDQUVBLGdCQUFnQixFQUFFLEtBQUssUUFBUSxNQUFNLFFBQVEsQ0FBQyxHQUFHO0VBQzdDLFlBQXFCLE1BQU0sS0FBSyxRQUFRLE1BQU0sR0FBRztFQUNqRCxPQUFPO0NBQ1g7Q0FFQSxlQUFlLEVBQUUsTUFBTSxPQUFPLFFBQVEsS0FBSyxNQUFNLE9BQU87RUFDcEQsTUFBZSxNQUFNLE1BQU0sT0FBTyxRQUFRLEtBQUssTUFBTSxHQUFHO0VBQ3hELE9BQU87Q0FDWDtDQUVBLGVBQWUsR0FBRztFQUNkLFdBQWtCLE1BQU0sQ0FBQztFQUN6QixPQUFPO0NBQ1g7Q0FFQSxZQUFZLEdBQUc7RUFDWCxLQUFLLElBQUksRUFBRTtFQUNYLEtBQUssSUFBSSxFQUFFO0VBQ1gsS0FBSyxJQUFJLEVBQUU7RUFDWCxPQUFPO0NBQ1g7Q0FFQSxRQUFRLElBQUksTUFBTTtFQUNkLFNBQWdCLE1BQU0sQ0FBQztFQUN2QixPQUFPO0NBQ1g7Q0FFQSxRQUFRLEdBQUcsS0FBSyxPQUFPO0VBQ25CLFFBQWlCLE1BQU0sR0FBRyxLQUFLLEtBQUs7RUFDcEMsT0FBTztDQUNYO0NBRUEsVUFBVSxHQUFHLEtBQUssT0FBTztFQUNyQixVQUFtQixNQUFNLEdBQUcsS0FBSyxLQUFLO0VBQ3RDLE9BQU87Q0FDWDtDQUVBLFlBQVksR0FBRztFQUNYLFlBQXFCLEdBQUcsSUFBSTtFQUM1QixPQUFPO0NBQ1g7Q0FFQSxlQUFlLEtBQUs7RUFDaEIsZUFBd0IsS0FBSyxJQUFJO0VBQ2pDLE9BQU87Q0FDWDtDQUVBLFdBQVcsT0FBTztFQUNkLFdBQW9CLE9BQU8sSUFBSTtFQUMvQixPQUFPO0NBQ1g7Q0FFQSxvQkFBb0I7RUFDaEIsT0FBT0Msa0JBQTJCLElBQUk7Q0FDMUM7Q0FFQSxPQUFPLEtBQUssUUFBUSxJQUFJO0VBQ3BCLFNBQWtCLE1BQU0sS0FBSyxRQUFRLEVBQUU7RUFDdkMsT0FBTztDQUNYO0NBRUEsY0FBYztFQUNWLE9BQU9DLFlBQXFCLElBQUk7Q0FDcEM7Q0FFQSxVQUFVLEdBQUcsSUFBSSxHQUFHO0VBQ2hCLEtBQUssS0FBSyxFQUFFO0VBQ1osS0FBSyxLQUFLLEVBQUUsSUFBSTtFQUNoQixLQUFLLEtBQUssRUFBRSxJQUFJO0VBQ2hCLEtBQUssS0FBSyxFQUFFLElBQUk7RUFDaEIsS0FBSyxLQUFLLEVBQUUsSUFBSTtFQUNoQixLQUFLLEtBQUssRUFBRSxJQUFJO0VBQ2hCLEtBQUssS0FBSyxFQUFFLElBQUk7RUFDaEIsS0FBSyxLQUFLLEVBQUUsSUFBSTtFQUNoQixLQUFLLEtBQUssRUFBRSxJQUFJO0VBQ2hCLEtBQUssS0FBSyxFQUFFLElBQUk7RUFDaEIsS0FBSyxNQUFNLEVBQUUsSUFBSTtFQUNqQixLQUFLLE1BQU0sRUFBRSxJQUFJO0VBQ2pCLEtBQUssTUFBTSxFQUFFLElBQUk7RUFDakIsS0FBSyxNQUFNLEVBQUUsSUFBSTtFQUNqQixLQUFLLE1BQU0sRUFBRSxJQUFJO0VBQ2pCLEtBQUssTUFBTSxFQUFFLElBQUk7RUFDakIsT0FBTztDQUNYO0NBRUEsUUFBUSxJQUFJLENBQUMsR0FBRyxJQUFJLEdBQUc7RUFDbkIsRUFBRSxLQUFLLEtBQUs7RUFDWixFQUFFLElBQUksS0FBSyxLQUFLO0VBQ2hCLEVBQUUsSUFBSSxLQUFLLEtBQUs7RUFDaEIsRUFBRSxJQUFJLEtBQUssS0FBSztFQUNoQixFQUFFLElBQUksS0FBSyxLQUFLO0VBQ2hCLEVBQUUsSUFBSSxLQUFLLEtBQUs7RUFDaEIsRUFBRSxJQUFJLEtBQUssS0FBSztFQUNoQixFQUFFLElBQUksS0FBSyxLQUFLO0VBQ2hCLEVBQUUsSUFBSSxLQUFLLEtBQUs7RUFDaEIsRUFBRSxJQUFJLEtBQUssS0FBSztFQUNoQixFQUFFLElBQUksTUFBTSxLQUFLO0VBQ2pCLEVBQUUsSUFBSSxNQUFNLEtBQUs7RUFDakIsRUFBRSxJQUFJLE1BQU0sS0FBSztFQUNqQixFQUFFLElBQUksTUFBTSxLQUFLO0VBQ2pCLEVBQUUsSUFBSSxNQUFNLEtBQUs7RUFDakIsRUFBRSxJQUFJLE1BQU0sS0FBSztFQUNqQixPQUFPO0NBQ1g7QUFDSjs7O0FDdE5BLFNBQWdCLG1CQUFtQixLQUFLLEdBQUcsUUFBUSxPQUFPO0NBQ3RELElBQUksVUFBVSxPQUFPO0VBQ2pCLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSyxJQUFJLEtBQUssSUFBSSxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQztFQUNsRCxJQUFJLEtBQUssSUFBSSxFQUFFLEVBQUUsSUFBSSxRQUFTO0dBQzFCLElBQUksS0FBSyxLQUFLLE1BQU0sQ0FBQyxFQUFFLElBQUksRUFBRSxHQUFHO0dBQ2hDLElBQUksS0FBSyxLQUFLLE1BQU0sQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFO0VBQ25DLE9BQU87R0FDSCxJQUFJLEtBQUssS0FBSyxNQUFNLEVBQUUsSUFBSSxFQUFFLEVBQUU7R0FDOUIsSUFBSSxLQUFLO0VBQ2I7Q0FDSixPQUFPLElBQUksVUFBVSxPQUFPO0VBQ3hCLElBQUksS0FBSyxLQUFLLEtBQUssQ0FBQyxLQUFLLElBQUksS0FBSyxJQUFJLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDO0VBQ25ELElBQUksS0FBSyxJQUFJLEVBQUUsRUFBRSxJQUFJLFFBQVM7R0FDMUIsSUFBSSxLQUFLLEtBQUssTUFBTSxFQUFFLElBQUksRUFBRSxHQUFHO0dBQy9CLElBQUksS0FBSyxLQUFLLE1BQU0sRUFBRSxJQUFJLEVBQUUsRUFBRTtFQUNsQyxPQUFPO0dBQ0gsSUFBSSxLQUFLLEtBQUssTUFBTSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUU7R0FDL0IsSUFBSSxLQUFLO0VBQ2I7Q0FDSixPQUFPLElBQUksVUFBVSxPQUFPO0VBQ3hCLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSyxJQUFJLEtBQUssSUFBSSxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQztFQUNsRCxJQUFJLEtBQUssSUFBSSxFQUFFLEVBQUUsSUFBSSxRQUFTO0dBQzFCLElBQUksS0FBSyxLQUFLLE1BQU0sQ0FBQyxFQUFFLElBQUksRUFBRSxHQUFHO0dBQ2hDLElBQUksS0FBSyxLQUFLLE1BQU0sQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFO0VBQ25DLE9BQU87R0FDSCxJQUFJLEtBQUs7R0FDVCxJQUFJLEtBQUssS0FBSyxNQUFNLEVBQUUsSUFBSSxFQUFFLEVBQUU7RUFDbEM7Q0FDSixPQUFPLElBQUksVUFBVSxPQUFPO0VBQ3hCLElBQUksS0FBSyxLQUFLLEtBQUssQ0FBQyxLQUFLLElBQUksS0FBSyxJQUFJLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDO0VBQ25ELElBQUksS0FBSyxJQUFJLEVBQUUsRUFBRSxJQUFJLFFBQVM7R0FDMUIsSUFBSSxLQUFLLEtBQUssTUFBTSxFQUFFLElBQUksRUFBRSxHQUFHO0dBQy9CLElBQUksS0FBSyxLQUFLLE1BQU0sRUFBRSxJQUFJLEVBQUUsRUFBRTtFQUNsQyxPQUFPO0dBQ0gsSUFBSSxLQUFLO0dBQ1QsSUFBSSxLQUFLLEtBQUssTUFBTSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUU7RUFDbkM7Q0FDSixPQUFPLElBQUksVUFBVSxPQUFPO0VBQ3hCLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSyxJQUFJLEtBQUssSUFBSSxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQztFQUNsRCxJQUFJLEtBQUssSUFBSSxFQUFFLEVBQUUsSUFBSSxRQUFTO0dBQzFCLElBQUksS0FBSyxLQUFLLE1BQU0sQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFO0dBQy9CLElBQUksS0FBSyxLQUFLLE1BQU0sQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFO0VBQ25DLE9BQU87R0FDSCxJQUFJLEtBQUs7R0FDVCxJQUFJLEtBQUssS0FBSyxNQUFNLEVBQUUsSUFBSSxFQUFFLEdBQUc7RUFDbkM7Q0FDSixPQUFPLElBQUksVUFBVSxPQUFPO0VBQ3hCLElBQUksS0FBSyxLQUFLLEtBQUssQ0FBQyxLQUFLLElBQUksS0FBSyxJQUFJLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDO0VBQ25ELElBQUksS0FBSyxJQUFJLEVBQUUsRUFBRSxJQUFJLFFBQVM7R0FDMUIsSUFBSSxLQUFLLEtBQUssTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFO0dBQzlCLElBQUksS0FBSyxLQUFLLE1BQU0sRUFBRSxJQUFJLEVBQUUsRUFBRTtFQUNsQyxPQUFPO0dBQ0gsSUFBSSxLQUFLLEtBQUssTUFBTSxDQUFDLEVBQUUsSUFBSSxFQUFFLEdBQUc7R0FDaEMsSUFBSSxLQUFLO0VBQ2I7Q0FDSjtDQUVBLE9BQU87QUFDWDs7O0FDeERBLElBQU0sMEJBQTBCLElBQUksS0FBSztBQUV6QyxJQUFhLFFBQWIsY0FBMkIsTUFBTTtDQUM3QixZQUFZLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxHQUFHLFFBQVEsT0FBTztFQUM1QyxNQUFNLEdBQUcsR0FBRyxDQUFDO0VBQ2IsS0FBSyxRQUFRO0VBQ2IsS0FBSyxpQkFBaUIsQ0FBQztFQUd2QixLQUFLLFVBQVU7RUFHZixNQUFNLGVBQWU7R0FBQztHQUFLO0dBQUs7RUFBRztFQUNuQyxPQUFPLElBQUksTUFBTSxNQUFNLEVBQ25CLElBQUksUUFBUSxVQUFVO0dBQ2xCLE1BQU0sVUFBVSxRQUFRLElBQUksR0FBRyxTQUFTO0dBQ3hDLElBQUksV0FBVyxhQUFhLFNBQVMsUUFBUSxHQUFHLE9BQU8sU0FBUztHQUNoRSxPQUFPO0VBQ1gsRUFDSixDQUFDO0NBQ0w7Q0FFQSxJQUFJLElBQUk7RUFDSixPQUFPLEtBQUs7Q0FDaEI7Q0FFQSxJQUFJLElBQUk7RUFDSixPQUFPLEtBQUs7Q0FDaEI7Q0FFQSxJQUFJLElBQUk7RUFDSixPQUFPLEtBQUs7Q0FDaEI7Q0FFQSxJQUFJLEVBQUUsR0FBRztFQUNMLEtBQUssUUFBUSxLQUFLO0VBQ2xCLEtBQUssU0FBUztDQUNsQjtDQUVBLElBQUksRUFBRSxHQUFHO0VBQ0wsS0FBSyxRQUFRLEtBQUs7RUFDbEIsS0FBSyxTQUFTO0NBQ2xCO0NBRUEsSUFBSSxFQUFFLEdBQUc7RUFDTCxLQUFLLFFBQVEsS0FBSztFQUNsQixLQUFLLFNBQVM7Q0FDbEI7Q0FFQSxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksR0FBRztFQUNqQixJQUFJLEVBQUUsUUFBUSxPQUFPLEtBQUssS0FBSyxDQUFDO0VBQ2hDLEtBQUssUUFBUSxLQUFLO0VBQ2xCLEtBQUssUUFBUSxLQUFLO0VBQ2xCLEtBQUssUUFBUSxLQUFLO0VBQ2xCLEtBQUssU0FBUztFQUNkLE9BQU87Q0FDWDtDQUVBLEtBQUssR0FBRztFQUNKLEtBQUssUUFBUSxLQUFLLEVBQUU7RUFDcEIsS0FBSyxRQUFRLEtBQUssRUFBRTtFQUNwQixLQUFLLFFBQVEsS0FBSyxFQUFFO0VBQ3BCLEtBQUssU0FBUztFQUNkLE9BQU87Q0FDWDtDQUVBLFFBQVEsT0FBTztFQUNYLEtBQUssUUFBUSxRQUFRO0VBQ3JCLEtBQUssU0FBUztFQUNkLE9BQU87Q0FDWDtDQUVBLG1CQUFtQixHQUFHLFFBQVEsS0FBSyxPQUFPO0VBQ3RDLG1CQUE2QixLQUFLLFNBQVMsR0FBRyxLQUFLO0VBQ25ELEtBQUssU0FBUztFQUNkLE9BQU87Q0FDWDtDQUVBLGVBQWUsR0FBRyxRQUFRLEtBQUssT0FBTyxZQUFZO0VBQzlDLFFBQVEsZUFBZSxDQUFDO0VBQ3hCLEtBQUssUUFBUSxtQkFBbUIsU0FBUyxLQUFLO0VBRTlDLElBQUksQ0FBQyxZQUFZLEtBQUssU0FBUztFQUMvQixPQUFPO0NBQ1g7Q0FFQSxVQUFVLEdBQUcsSUFBSSxHQUFHO0VBQ2hCLEtBQUssUUFBUSxLQUFLLEVBQUU7RUFDcEIsS0FBSyxRQUFRLEtBQUssRUFBRSxJQUFJO0VBQ3hCLEtBQUssUUFBUSxLQUFLLEVBQUUsSUFBSTtFQUN4QixPQUFPO0NBQ1g7Q0FFQSxRQUFRLElBQUksQ0FBQyxHQUFHLElBQUksR0FBRztFQUNuQixFQUFFLEtBQUssS0FBSztFQUNaLEVBQUUsSUFBSSxLQUFLLEtBQUs7RUFDaEIsRUFBRSxJQUFJLEtBQUssS0FBSztFQUNoQixPQUFPO0NBQ1g7QUFDSjs7O0FDakdBLElBQWEsWUFBYixNQUF1QjtDQUNuQixjQUFjO0VBQ1YsS0FBSyxTQUFTO0VBQ2QsS0FBSyxXQUFXLENBQUM7RUFDakIsS0FBSyxVQUFVO0VBRWYsS0FBSyxTQUFTLElBQUksS0FBSztFQUN2QixLQUFLLGNBQWMsSUFBSSxLQUFLO0VBQzVCLEtBQUssbUJBQW1CO0VBQ3hCLEtBQUsseUJBQXlCO0VBRTlCLEtBQUssV0FBVyxJQUFJLEtBQUs7RUFDekIsS0FBSyxhQUFhLElBQUksS0FBSztFQUMzQixLQUFLLFFBQVEsSUFBSSxLQUFLLENBQUM7RUFDdkIsS0FBSyxXQUFXLElBQUksTUFBTTtFQUMxQixLQUFLLEtBQUssSUFBSSxLQUFLLEdBQUcsR0FBRyxDQUFDO0VBRTFCLEtBQUssU0FBUyxRQUFRLGlCQUFpQixLQUFLLFdBQVcsVUFBVSxLQUFLLFVBQVUsSUFBSTtFQUNwRixLQUFLLFdBQVcsUUFBUSxpQkFBaUIsS0FBSyxTQUFTLGVBQWUsS0FBSyxZQUFZLEtBQUEsR0FBVyxJQUFJO0NBQzFHO0NBRUEsVUFBVSxRQUFRLGVBQWUsTUFBTTtFQUNuQyxJQUFJLEtBQUssVUFBVSxXQUFXLEtBQUssUUFBUSxLQUFLLE9BQU8sWUFBWSxNQUFNLEtBQUs7RUFDOUUsS0FBSyxTQUFTO0VBQ2QsSUFBSSxnQkFBZ0IsUUFBUSxPQUFPLFNBQVMsTUFBTSxLQUFLO0NBQzNEO0NBRUEsU0FBUyxPQUFPLGNBQWMsTUFBTTtFQUNoQyxJQUFJLENBQUMsQ0FBQyxLQUFLLFNBQVMsUUFBUSxLQUFLLEdBQUcsS0FBSyxTQUFTLEtBQUssS0FBSztFQUM1RCxJQUFJLGFBQWEsTUFBTSxVQUFVLE1BQU0sS0FBSztDQUNoRDtDQUVBLFlBQVksT0FBTyxjQUFjLE1BQU07RUFDbkMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsUUFBUSxLQUFLLEdBQUcsS0FBSyxTQUFTLE9BQU8sS0FBSyxTQUFTLFFBQVEsS0FBSyxHQUFHLENBQUM7RUFDekYsSUFBSSxhQUFhLE1BQU0sVUFBVSxNQUFNLEtBQUs7Q0FDaEQ7Q0FFQSxrQkFBa0IsT0FBTztFQUNyQixJQUFJLEtBQUssa0JBQWtCLEtBQUssYUFBYTtFQUM3QyxJQUFJLEtBQUssMEJBQTBCLE9BQU87R0FDdEMsSUFBSSxLQUFLLFdBQVcsTUFBTSxLQUFLLFlBQVksS0FBSyxLQUFLLE1BQU07UUFDdEQsS0FBSyxZQUFZLFNBQVMsS0FBSyxPQUFPLGFBQWEsS0FBSyxNQUFNO0dBQ25FLEtBQUsseUJBQXlCO0dBQzlCLFFBQVE7RUFDWjtFQUVBLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFNBQVMsUUFBUSxJQUFJLEdBQUcsS0FDN0MsS0FBSyxTQUFTLEVBQUUsQ0FBQyxrQkFBa0IsS0FBSztDQUVoRDtDQUVBLGVBQWU7RUFDWCxLQUFLLE9BQU8sUUFBUSxLQUFLLFlBQVksS0FBSyxVQUFVLEtBQUssS0FBSztFQUM5RCxLQUFLLHlCQUF5QjtDQUNsQztDQUVBLFNBQVMsVUFBVTtFQUVmLElBQUksU0FBUyxJQUFJLEdBQUc7RUFDcEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssU0FBUyxRQUFRLElBQUksR0FBRyxLQUM3QyxLQUFLLFNBQVMsRUFBRSxDQUFDLFNBQVMsUUFBUTtDQUUxQztDQUVBLFlBQVk7RUFDUixLQUFLLE9BQU8sVUFBVSxLQUFLLFdBQVcsU0FBUyxLQUFLLFVBQVUsS0FBSyxLQUFLO0VBQ3hFLEtBQUssU0FBUyxlQUFlLEtBQUssVUFBVTtDQUNoRDtDQUVBLE9BQU8sUUFBUSxTQUFTLE9BQU87RUFDM0IsSUFBSSxRQUFRLEtBQUssT0FBTyxPQUFPLEtBQUssVUFBVSxRQUFRLEtBQUssRUFBRTtPQUN4RCxLQUFLLE9BQU8sT0FBTyxRQUFRLEtBQUssVUFBVSxLQUFLLEVBQUU7RUFDdEQsS0FBSyxPQUFPLFlBQVksS0FBSyxXQUFXLE9BQU87RUFDL0MsS0FBSyxTQUFTLGVBQWUsS0FBSyxVQUFVO0NBQ2hEO0FBQ0o7OztBQzVFQSxJQUFNQyw2QkFBMkIsSUFBSSxLQUFLO0FBQzFDLElBQU1DLDhCQUE0QixJQUFJLEtBQUs7QUFDM0MsSUFBTUMsOEJBQTRCLElBQUksS0FBSztBQUUzQyxJQUFhLFNBQWIsY0FBNEIsVUFBVTtDQUNsQyxZQUFZLElBQUksRUFBRSxPQUFPLElBQUssTUFBTSxLQUFLLE1BQU0sSUFBSSxTQUFTLEdBQUcsTUFBTSxPQUFPLFFBQVEsS0FBSyxPQUFPLE1BQU0sQ0FBQyxHQUFHO0VBQ3RHLE1BQU07RUFFTixPQUFPLE9BQU8sTUFBTTtHQUFFO0dBQU07R0FBSztHQUFLO0dBQVE7R0FBTTtHQUFPO0dBQVE7R0FBSztFQUFLLENBQUM7RUFFOUUsS0FBSyxtQkFBbUIsSUFBSSxLQUFLO0VBQ2pDLEtBQUssYUFBYSxJQUFJLEtBQUs7RUFDM0IsS0FBSyx1QkFBdUIsSUFBSSxLQUFLO0VBQ3JDLEtBQUssZ0JBQWdCLElBQUksS0FBSztFQUc5QixLQUFLLE9BQU8sUUFBUSxRQUFRLGlCQUFpQjtFQUU3QyxJQUFJLEtBQUssU0FBUyxnQkFBZ0IsS0FBSyxhQUFhO09BQy9DLEtBQUssWUFBWTtDQUMxQjtDQUVBLFlBQVksRUFBRSxPQUFPLEtBQUssTUFBTSxNQUFNLEtBQUssS0FBSyxNQUFNLEtBQUssS0FBSyxTQUFTLEtBQUssV0FBVyxDQUFDLEdBQUc7RUFDekYsT0FBTyxPQUFPLE1BQU07R0FBRTtHQUFNO0dBQUs7R0FBSztFQUFPLENBQUM7RUFDOUMsS0FBSyxpQkFBaUIsZ0JBQWdCO0dBQUUsS0FBSyxPQUFPLEtBQUssS0FBSztHQUFNO0dBQVE7R0FBTTtFQUFJLENBQUM7RUFDdkYsS0FBSyxPQUFPO0VBQ1osT0FBTztDQUNYO0NBRUEsYUFBYSxFQUNULE9BQU8sS0FBSyxNQUNaLE1BQU0sS0FBSyxLQUNYLE9BQU8sS0FBSyxRQUFRLElBQ3BCLFFBQVEsS0FBSyxTQUFTLEdBQ3RCLFNBQVMsS0FBSyxVQUFVLElBQ3hCLE1BQU0sS0FBSyxPQUFPLEdBQ2xCLE9BQU8sS0FBSyxTQUNaLENBQUMsR0FBRztFQUNKLE9BQU8sT0FBTyxNQUFNO0dBQUU7R0FBTTtHQUFLO0dBQU07R0FBTztHQUFRO0dBQUs7RUFBSyxDQUFDO0VBQ2pFLFFBQVE7RUFDUixTQUFTO0VBQ1QsVUFBVTtFQUNWLE9BQU87RUFDUCxLQUFLLGlCQUFpQixlQUFlO0dBQUU7R0FBTTtHQUFPO0dBQVE7R0FBSztHQUFNO0VBQUksQ0FBQztFQUM1RSxLQUFLLE9BQU87RUFDWixPQUFPO0NBQ1g7Q0FFQSxvQkFBb0I7RUFDaEIsTUFBTSxrQkFBa0I7RUFDeEIsS0FBSyxXQUFXLFFBQVEsS0FBSyxXQUFXO0VBQ3hDLEtBQUssWUFBWSxlQUFlLEtBQUssYUFBYTtFQUdsRCxLQUFLLHFCQUFxQixTQUFTLEtBQUssa0JBQWtCLEtBQUssVUFBVTtFQUN6RSxPQUFPO0NBQ1g7Q0FFQSx5QkFBeUI7RUFDckIsSUFBSSxLQUFLLFNBQVMsZUFDZCxPQUFPLEtBQUssWUFBWTtPQUV4QixPQUFPLEtBQUssYUFBYTtDQUVqQztDQUVBLE9BQU8sUUFBUTtFQUNYLE1BQU0sT0FBTyxRQUFRLElBQUk7RUFDekIsT0FBTztDQUNYO0NBR0EsUUFBUSxHQUFHO0VBQ1AsRUFBRSxhQUFhLEtBQUssVUFBVTtFQUM5QixFQUFFLGFBQWEsS0FBSyxnQkFBZ0I7RUFDcEMsT0FBTztDQUNYO0NBR0EsVUFBVSxHQUFHO0VBQ1QsRUFBRSxhQUFhRixXQUFTLFFBQVEsS0FBSyxnQkFBZ0IsQ0FBQztFQUN0RCxFQUFFLGFBQWEsS0FBSyxXQUFXO0VBQy9CLE9BQU87Q0FDWDtDQUVBLGdCQUFnQjtFQUNaLElBQUksQ0FBQyxLQUFLLFNBQ04sS0FBSyxVQUFVO0dBQUMsSUFBSSxLQUFLO0dBQUcsSUFBSSxLQUFLO0dBQUcsSUFBSSxLQUFLO0dBQUcsSUFBSSxLQUFLO0dBQUcsSUFBSSxLQUFLO0dBQUcsSUFBSSxLQUFLO0VBQUM7RUFHMUYsTUFBTSxJQUFJLEtBQUs7RUFDZixLQUFLLFFBQVEsRUFBRSxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFdBQVcsRUFBRSxNQUFNLEVBQUU7RUFDakYsS0FBSyxRQUFRLEVBQUUsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxFQUFFLENBQUMsQ0FBQyxXQUFXLEVBQUUsTUFBTSxFQUFFO0VBQ2pGLEtBQUssUUFBUSxFQUFFLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsRUFBRSxDQUFDLENBQUMsV0FBVyxFQUFFLE1BQU0sRUFBRTtFQUNqRixLQUFLLFFBQVEsRUFBRSxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFdBQVcsRUFBRSxNQUFNLEVBQUU7RUFDakYsS0FBSyxRQUFRLEVBQUUsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxXQUFXLEVBQUUsTUFBTSxFQUFFO0VBQ2xGLEtBQUssUUFBUSxFQUFFLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsV0FBVyxFQUFFLE1BQU0sRUFBRTtFQUVsRixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLO0dBQ3hCLE1BQU0sU0FBUyxJQUFNLEtBQUssUUFBUSxFQUFFLENBQUMsU0FBUztHQUM5QyxLQUFLLFFBQVEsRUFBRSxDQUFDLFNBQVMsTUFBTTtHQUMvQixLQUFLLFFBQVEsRUFBRSxDQUFDLFlBQVk7RUFDaEM7Q0FDSjtDQUVBLHNCQUFzQixNQUFNLGNBQWMsS0FBSyxhQUFhO0VBRXhELElBQUksQ0FBQyxLQUFLLFNBQVMsV0FBVyxVQUFVLE9BQU87RUFFL0MsSUFBSSxDQUFDLEtBQUssU0FBUyxVQUFVLEtBQUssU0FBUyxPQUFPLFdBQVcsVUFBVSxLQUFLLFNBQVMsc0JBQXNCO0VBRTNHLElBQUksQ0FBQyxLQUFLLFNBQVMsUUFBUSxPQUFPO0VBRWxDLE1BQU0sU0FBU0M7RUFDZixPQUFPLEtBQUssS0FBSyxTQUFTLE9BQU8sTUFBTTtFQUN2QyxPQUFPLGFBQWEsV0FBVztFQUUvQixNQUFNLFNBQVMsS0FBSyxTQUFTLE9BQU8sU0FBUyxZQUFZLGtCQUFrQjtFQUUzRSxPQUFPLEtBQUssd0JBQXdCLFFBQVEsTUFBTTtDQUN0RDtDQUVBLHdCQUF3QixRQUFRLFFBQVE7RUFDcEMsTUFBTSxTQUFTQztFQUVmLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7R0FDeEIsTUFBTSxRQUFRLEtBQUssUUFBUTtHQUUzQixJQURpQixPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsSUFBSSxNQUFNLElBQUksTUFBTSxXQUN6QyxDQUFDLFFBQVEsT0FBTztFQUNuQztFQUNBLE9BQU87Q0FDWDtBQUNKOzs7Ozs7Ozs7O0FDL0hBLFNBQWdCLFNBQVMsS0FBSyxHQUFHO0NBQzdCLElBQUksS0FBSyxFQUFFO0NBQ1gsSUFBSSxLQUFLLEVBQUU7Q0FDWCxJQUFJLEtBQUssRUFBRTtDQUNYLElBQUksS0FBSyxFQUFFO0NBQ1gsSUFBSSxLQUFLLEVBQUU7Q0FDWCxJQUFJLEtBQUssRUFBRTtDQUNYLElBQUksS0FBSyxFQUFFO0NBQ1gsSUFBSSxLQUFLLEVBQUU7Q0FDWCxJQUFJLEtBQUssRUFBRTtDQUNYLE9BQU87QUFDWDs7Ozs7Ozs7O0FBVUEsU0FBZ0IsU0FBUyxLQUFLLEdBQUc7Q0FDN0IsSUFBSSxJQUFJLEVBQUUsSUFDTixJQUFJLEVBQUUsSUFDTixJQUFJLEVBQUUsSUFDTixJQUFJLEVBQUU7Q0FDVixJQUFJLEtBQUssSUFBSTtDQUNiLElBQUksS0FBSyxJQUFJO0NBQ2IsSUFBSSxLQUFLLElBQUk7Q0FFYixJQUFJLEtBQUssSUFBSTtDQUNiLElBQUksS0FBSyxJQUFJO0NBQ2IsSUFBSSxLQUFLLElBQUk7Q0FDYixJQUFJLEtBQUssSUFBSTtDQUNiLElBQUksS0FBSyxJQUFJO0NBQ2IsSUFBSSxLQUFLLElBQUk7Q0FDYixJQUFJLEtBQUssSUFBSTtDQUNiLElBQUksS0FBSyxJQUFJO0NBQ2IsSUFBSSxLQUFLLElBQUk7Q0FFYixJQUFJLEtBQUssSUFBSSxLQUFLO0NBQ2xCLElBQUksS0FBSyxLQUFLO0NBQ2QsSUFBSSxLQUFLLEtBQUs7Q0FFZCxJQUFJLEtBQUssS0FBSztDQUNkLElBQUksS0FBSyxJQUFJLEtBQUs7Q0FDbEIsSUFBSSxLQUFLLEtBQUs7Q0FFZCxJQUFJLEtBQUssS0FBSztDQUNkLElBQUksS0FBSyxLQUFLO0NBQ2QsSUFBSSxLQUFLLElBQUksS0FBSztDQUVsQixPQUFPO0FBQ1g7Ozs7Ozs7O0FBU0EsU0FBZ0JDLE9BQUssS0FBSyxHQUFHO0NBQ3pCLElBQUksS0FBSyxFQUFFO0NBQ1gsSUFBSSxLQUFLLEVBQUU7Q0FDWCxJQUFJLEtBQUssRUFBRTtDQUNYLElBQUksS0FBSyxFQUFFO0NBQ1gsSUFBSSxLQUFLLEVBQUU7Q0FDWCxJQUFJLEtBQUssRUFBRTtDQUNYLElBQUksS0FBSyxFQUFFO0NBQ1gsSUFBSSxLQUFLLEVBQUU7Q0FDWCxJQUFJLEtBQUssRUFBRTtDQUNYLE9BQU87QUFDWDs7Ozs7OztBQVFBLFNBQWdCQyxNQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUs7Q0FDbEUsSUFBSSxLQUFLO0NBQ1QsSUFBSSxLQUFLO0NBQ1QsSUFBSSxLQUFLO0NBQ1QsSUFBSSxLQUFLO0NBQ1QsSUFBSSxLQUFLO0NBQ1QsSUFBSSxLQUFLO0NBQ1QsSUFBSSxLQUFLO0NBQ1QsSUFBSSxLQUFLO0NBQ1QsSUFBSSxLQUFLO0NBQ1QsT0FBTztBQUNYOzs7Ozs7O0FBUUEsU0FBZ0JDLFdBQVMsS0FBSztDQUMxQixJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUs7Q0FDVCxPQUFPO0FBQ1g7Ozs7Ozs7O0FBMkNBLFNBQWdCLE9BQU8sS0FBSyxHQUFHO0NBQzNCLElBQUksTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFO0NBQ1osSUFBSSxNQUFNLEVBQUUsSUFDUixNQUFNLEVBQUUsSUFDUixNQUFNLEVBQUU7Q0FDWixJQUFJLE1BQU0sRUFBRSxJQUNSLE1BQU0sRUFBRSxJQUNSLE1BQU0sRUFBRTtDQUVaLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUM1QixJQUFJLE1BQU0sQ0FBQyxNQUFNLE1BQU0sTUFBTTtDQUM3QixJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU07Q0FHNUIsSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUV4QyxJQUFJLENBQUMsS0FDRCxPQUFPO0NBRVgsTUFBTSxJQUFNO0NBRVosSUFBSSxLQUFLLE1BQU07Q0FDZixJQUFJLE1BQU0sQ0FBQyxNQUFNLE1BQU0sTUFBTSxPQUFPO0NBQ3BDLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTSxPQUFPO0NBQ25DLElBQUksS0FBSyxNQUFNO0NBQ2YsSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNLE9BQU87Q0FDbkMsSUFBSSxNQUFNLENBQUMsTUFBTSxNQUFNLE1BQU0sT0FBTztDQUNwQyxJQUFJLEtBQUssTUFBTTtDQUNmLElBQUksTUFBTSxDQUFDLE1BQU0sTUFBTSxNQUFNLE9BQU87Q0FDcEMsSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNLE9BQU87Q0FDbkMsT0FBTztBQUNYOzs7Ozs7Ozs7QUE4QkEsU0FBZ0JDLFdBQVMsS0FBSyxHQUFHLEdBQUc7Q0FDaEMsSUFBSSxNQUFNLEVBQUUsSUFDUixNQUFNLEVBQUUsSUFDUixNQUFNLEVBQUU7Q0FDWixJQUFJLE1BQU0sRUFBRSxJQUNSLE1BQU0sRUFBRSxJQUNSLE1BQU0sRUFBRTtDQUNaLElBQUksTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFO0NBRVosSUFBSSxNQUFNLEVBQUUsSUFDUixNQUFNLEVBQUUsSUFDUixNQUFNLEVBQUU7Q0FDWixJQUFJLE1BQU0sRUFBRSxJQUNSLE1BQU0sRUFBRSxJQUNSLE1BQU0sRUFBRTtDQUNaLElBQUksTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFO0NBRVosSUFBSSxLQUFLLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUN2QyxJQUFJLEtBQUssTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNO0NBQ3ZDLElBQUksS0FBSyxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU07Q0FFdkMsSUFBSSxLQUFLLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUN2QyxJQUFJLEtBQUssTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNO0NBQ3ZDLElBQUksS0FBSyxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU07Q0FFdkMsSUFBSSxLQUFLLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUN2QyxJQUFJLEtBQUssTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNO0NBQ3ZDLElBQUksS0FBSyxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU07Q0FDdkMsT0FBTztBQUNYOzs7Ozs7Ozs7QUFVQSxTQUFnQixVQUFVLEtBQUssR0FBRyxHQUFHO0NBQ2pDLElBQUksTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsSUFBSSxFQUFFLElBQ04sSUFBSSxFQUFFO0NBRVYsSUFBSSxLQUFLO0NBQ1QsSUFBSSxLQUFLO0NBQ1QsSUFBSSxLQUFLO0NBRVQsSUFBSSxLQUFLO0NBQ1QsSUFBSSxLQUFLO0NBQ1QsSUFBSSxLQUFLO0NBRVQsSUFBSSxLQUFLLElBQUksTUFBTSxJQUFJLE1BQU07Q0FDN0IsSUFBSSxLQUFLLElBQUksTUFBTSxJQUFJLE1BQU07Q0FDN0IsSUFBSSxLQUFLLElBQUksTUFBTSxJQUFJLE1BQU07Q0FDN0IsT0FBTztBQUNYOzs7Ozs7Ozs7QUFVQSxTQUFnQixPQUFPLEtBQUssR0FBRyxLQUFLO0NBQ2hDLElBQUksTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsSUFBSSxLQUFLLElBQUksR0FBRyxHQUNoQixJQUFJLEtBQUssSUFBSSxHQUFHO0NBRXBCLElBQUksS0FBSyxJQUFJLE1BQU0sSUFBSTtDQUN2QixJQUFJLEtBQUssSUFBSSxNQUFNLElBQUk7Q0FDdkIsSUFBSSxLQUFLLElBQUksTUFBTSxJQUFJO0NBRXZCLElBQUksS0FBSyxJQUFJLE1BQU0sSUFBSTtDQUN2QixJQUFJLEtBQUssSUFBSSxNQUFNLElBQUk7Q0FDdkIsSUFBSSxLQUFLLElBQUksTUFBTSxJQUFJO0NBRXZCLElBQUksS0FBSztDQUNULElBQUksS0FBSztDQUNULElBQUksS0FBSztDQUNULE9BQU87QUFDWDs7Ozs7Ozs7O0FBVUEsU0FBZ0JDLFFBQU0sS0FBSyxHQUFHLEdBQUc7Q0FDN0IsSUFBSSxJQUFJLEVBQUUsSUFDTixJQUFJLEVBQUU7Q0FFVixJQUFJLEtBQUssSUFBSSxFQUFFO0NBQ2YsSUFBSSxLQUFLLElBQUksRUFBRTtDQUNmLElBQUksS0FBSyxJQUFJLEVBQUU7Q0FFZixJQUFJLEtBQUssSUFBSSxFQUFFO0NBQ2YsSUFBSSxLQUFLLElBQUksRUFBRTtDQUNmLElBQUksS0FBSyxJQUFJLEVBQUU7Q0FFZixJQUFJLEtBQUssRUFBRTtDQUNYLElBQUksS0FBSyxFQUFFO0NBQ1gsSUFBSSxLQUFLLEVBQUU7Q0FDWCxPQUFPO0FBQ1g7Ozs7Ozs7OztBQVVBLFNBQWdCLGVBQWUsS0FBSyxHQUFHO0NBQ25DLElBQUksTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFLElBQ1IsTUFBTSxFQUFFO0NBQ1osSUFBSSxNQUFNLEVBQUUsSUFDUixNQUFNLEVBQUUsSUFDUixNQUFNLEVBQUUsSUFDUixNQUFNLEVBQUU7Q0FDWixJQUFJLE1BQU0sRUFBRSxJQUNSLE1BQU0sRUFBRSxJQUNSLE1BQU0sRUFBRSxLQUNSLE1BQU0sRUFBRTtDQUNaLElBQUksTUFBTSxFQUFFLEtBQ1IsTUFBTSxFQUFFLEtBQ1IsTUFBTSxFQUFFLEtBQ1IsTUFBTSxFQUFFO0NBRVosSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNO0NBQzVCLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUM1QixJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU07Q0FDNUIsSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNO0NBQzVCLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUM1QixJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU07Q0FDNUIsSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNO0NBQzVCLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUM1QixJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU07Q0FDNUIsSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNO0NBQzVCLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUM1QixJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU07Q0FHNUIsSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTTtDQUU1RSxJQUFJLENBQUMsS0FDRCxPQUFPO0NBRVgsTUFBTSxJQUFNO0NBRVosSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxPQUFPO0NBQy9DLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sT0FBTztDQUMvQyxJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE9BQU87Q0FFL0MsSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxPQUFPO0NBQy9DLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sT0FBTztDQUMvQyxJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE9BQU87Q0FFL0MsSUFBSSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxPQUFPO0NBQy9DLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sT0FBTztDQUMvQyxJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE9BQU87Q0FFL0MsT0FBTztBQUNYOzs7QUMvWkEsSUFBYSxPQUFiLGNBQTBCLE1BQU07Q0FDNUIsWUFBWSxNQUFNLEdBQUcsTUFBTSxHQUFHLE1BQU0sR0FBRyxNQUFNLEdBQUcsTUFBTSxHQUFHLE1BQU0sR0FBRyxNQUFNLEdBQUcsTUFBTSxHQUFHLE1BQU0sR0FBRztFQUN6RixNQUFNLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxHQUFHO0VBQ2pELE9BQU87Q0FDWDtDQUVBLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUs7RUFDN0MsSUFBSSxJQUFJLFFBQVEsT0FBTyxLQUFLLEtBQUssR0FBRztFQUNwQyxNQUFhLE1BQU0sS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEdBQUc7RUFDOUQsT0FBTztDQUNYO0NBRUEsVUFBVSxHQUFHLElBQUksTUFBTTtFQUNuQixVQUFtQixNQUFNLEdBQUcsQ0FBQztFQUM3QixPQUFPO0NBQ1g7Q0FFQSxPQUFPLEdBQUcsSUFBSSxNQUFNO0VBQ2hCLE9BQWdCLE1BQU0sR0FBRyxDQUFDO0VBQzFCLE9BQU87Q0FDWDtDQUVBLE1BQU0sR0FBRyxJQUFJLE1BQU07RUFDZixRQUFlLE1BQU0sR0FBRyxDQUFDO0VBQ3pCLE9BQU87Q0FDWDtDQUVBLFNBQVMsSUFBSSxJQUFJO0VBQ2IsSUFBSSxJQUNBLFdBQWtCLE1BQU0sSUFBSSxFQUFFO09BRTlCLFdBQWtCLE1BQU0sTUFBTSxFQUFFO0VBRXBDLE9BQU87Q0FDWDtDQUVBLFdBQVc7RUFDUCxXQUFrQixJQUFJO0VBQ3RCLE9BQU87Q0FDWDtDQUVBLEtBQUssR0FBRztFQUNKLE9BQWMsTUFBTSxDQUFDO0VBQ3JCLE9BQU87Q0FDWDtDQUVBLFlBQVksR0FBRztFQUNYLFNBQWtCLE1BQU0sQ0FBQztFQUN6QixPQUFPO0NBQ1g7Q0FFQSxlQUFlLEdBQUc7RUFDZCxTQUFrQixNQUFNLENBQUM7RUFDekIsT0FBTztDQUNYO0NBRUEsVUFBVSxPQUFPLE9BQU8sT0FBTztFQUMzQixLQUFLLElBQUksTUFBTSxJQUFJLE1BQU0sSUFBSSxNQUFNLElBQUksTUFBTSxJQUFJLE1BQU0sSUFBSSxNQUFNLElBQUksTUFBTSxJQUFJLE1BQU0sSUFBSSxNQUFNLEVBQUU7RUFDakcsT0FBTztDQUNYO0NBRUEsUUFBUSxJQUFJLE1BQU07RUFDZCxPQUFnQixNQUFNLENBQUM7RUFDdkIsT0FBTztDQUNYO0NBRUEsZ0JBQWdCLEdBQUc7RUFDZixlQUF3QixNQUFNLENBQUM7RUFDL0IsT0FBTztDQUNYO0FBQ0o7OztBQ3BFQSxJQUFJQyxPQUFLO0FBRVQsSUFBYSxPQUFiLGNBQTBCLFVBQVU7Q0FDaEMsWUFBWSxJQUFJLEVBQUUsVUFBVSxTQUFTLE9BQU8sR0FBRyxXQUFXLGdCQUFnQixNQUFNLGNBQWMsTUFBTSxDQUFDLEdBQUc7RUFDcEcsTUFBTTtFQUNOLElBQUksQ0FBQyxHQUFHLFFBQVEsUUFBUSxNQUFNLHlDQUF5QztFQUN2RSxLQUFLLEtBQUs7RUFDVixLQUFLLEtBQUs7RUFDVixLQUFLLFdBQVc7RUFDaEIsS0FBSyxVQUFVO0VBQ2YsS0FBSyxPQUFPO0VBR1osS0FBSyxnQkFBZ0I7RUFHckIsS0FBSyxjQUFjO0VBQ25CLEtBQUssa0JBQWtCLElBQUksS0FBSztFQUNoQyxLQUFLLGVBQWUsSUFBSSxLQUFLO0VBQzdCLEtBQUssd0JBQXdCLENBQUM7RUFDOUIsS0FBSyx1QkFBdUIsQ0FBQztDQUNqQztDQUVBLGVBQWUsR0FBRztFQUNkLEtBQUssc0JBQXNCLEtBQUssQ0FBQztFQUNqQyxPQUFPO0NBQ1g7Q0FFQSxjQUFjLEdBQUc7RUFDYixLQUFLLHFCQUFxQixLQUFLLENBQUM7RUFDaEMsT0FBTztDQUNYO0NBRUEsS0FBSyxFQUFFLFdBQVcsQ0FBQyxHQUFHO0VBQ2xCLElBQUksUUFBUTtHQUVSLElBQUksQ0FBQyxLQUFLLFFBQVEsU0FBUyxhQUN2QixPQUFPLE9BQU8sS0FBSyxRQUFRLFVBQVU7SUFDakMsYUFBYSxFQUFFLE9BQU8sS0FBSztJQUMzQixZQUFZLEVBQUUsT0FBTyxLQUFLO0lBQzFCLGlCQUFpQixFQUFFLE9BQU8sS0FBSztJQUMvQixjQUFjLEVBQUUsT0FBTyxLQUFLO0lBQzVCLGtCQUFrQixFQUFFLE9BQU8sS0FBSztJQUNoQyxnQkFBZ0IsRUFBRSxPQUFPLEtBQUs7R0FDbEMsQ0FBQztHQUlMLEtBQUssUUFBUSxTQUFTLGlCQUFpQixRQUFRLE9BQU87R0FDdEQsS0FBSyxRQUFRLFNBQVMsZUFBZSxRQUFRLE9BQU87R0FDcEQsS0FBSyxRQUFRLFNBQVMsV0FBVyxRQUFRLE9BQU87R0FDaEQsS0FBSyxnQkFBZ0IsU0FBUyxPQUFPLFlBQVksS0FBSyxXQUFXO0dBQ2pFLEtBQUssYUFBYSxnQkFBZ0IsS0FBSyxlQUFlO0dBQ3RELEtBQUssUUFBUSxTQUFTLFlBQVksUUFBUSxLQUFLO0dBQy9DLEtBQUssUUFBUSxTQUFTLGdCQUFnQixRQUFRLEtBQUs7R0FDbkQsS0FBSyxRQUFRLFNBQVMsYUFBYSxRQUFRLEtBQUs7RUFDcEQ7RUFDQSxLQUFLLHNCQUFzQixTQUFTLE1BQU0sS0FBSyxFQUFFO0dBQUUsTUFBTTtHQUFNO0VBQU8sQ0FBQyxDQUFDO0VBR3hFLElBQUksWUFBWSxLQUFLLFFBQVEsWUFBWSxLQUFLLFlBQVksWUFBWSxJQUFJO0VBQzFFLEtBQUssUUFBUSxJQUFJLEVBQUUsVUFBVSxDQUFDO0VBQzlCLEtBQUssU0FBUyxLQUFLO0dBQUUsTUFBTSxLQUFLO0dBQU0sU0FBUyxLQUFLO0VBQVEsQ0FBQztFQUM3RCxLQUFLLHFCQUFxQixTQUFTLE1BQU0sS0FBSyxFQUFFO0dBQUUsTUFBTTtHQUFNO0VBQU8sQ0FBQyxDQUFDO0NBQzNFO0FBQ0o7OztBQ2hFQSxJQUFNLDZCQUFhLElBQUksV0FBVyxDQUFDO0FBRW5DLFNBQVMsV0FBVyxPQUFPO0NBQ3ZCLFFBQVEsUUFBUyxRQUFRLE9BQVE7QUFDckM7QUFFQSxJQUFJLEtBQUs7QUFFVCxJQUFhLFVBQWIsTUFBcUI7Q0FDakIsWUFDSSxJQUNBLEVBQ0ksT0FDQSxTQUFTLEdBQUcsWUFDWixPQUFPLEdBQUcsZUFDVixTQUFTLEdBQUcsTUFDWixpQkFBaUIsUUFDakIsUUFBUSxHQUFHLGVBQ1gsUUFBUSxHQUFHLGVBQ1gsUUFBUSxHQUFHLGVBQ1gsa0JBQWtCLFlBQVksR0FBRyxjQUFjLEdBQUcsbUJBQ2xELFlBQVksa0JBQWtCLEdBQUcsd0JBQXdCLEdBQUcsUUFDNUQsWUFBWSxHQUFHLFFBQ2YsbUJBQW1CLE9BQ25CLGtCQUFrQixHQUNsQixRQUFRLFdBQVcsR0FBRyxjQUFjLEdBQUcsY0FBYyxPQUFPLE9BQzVELGFBQWEsR0FDYixRQUFRLEdBQ1IsT0FDQSxTQUFTLE9BQ1QsU0FBUyxNQUNULENBQUMsR0FDUDtFQUNFLEtBQUssS0FBSztFQUNWLEtBQUssS0FBSztFQUVWLEtBQUssUUFBUTtFQUNiLEtBQUssU0FBUztFQUNkLEtBQUssT0FBTztFQUNaLEtBQUssU0FBUztFQUNkLEtBQUssaUJBQWlCO0VBQ3RCLEtBQUssWUFBWTtFQUNqQixLQUFLLFlBQVk7RUFDakIsS0FBSyxRQUFRO0VBQ2IsS0FBSyxRQUFRO0VBQ2IsS0FBSyxRQUFRO0VBQ2IsS0FBSyxrQkFBa0I7RUFDdkIsS0FBSyxtQkFBbUI7RUFDeEIsS0FBSyxrQkFBa0I7RUFDdkIsS0FBSyxRQUFRO0VBQ2IsS0FBSyxhQUFhLEtBQUssSUFBSSxZQUFZLEtBQUssR0FBRyxTQUFTLFdBQVcsYUFBYTtFQUNoRixLQUFLLFFBQVE7RUFDYixLQUFLLFFBQVE7RUFDYixLQUFLLFNBQVM7RUFDZCxLQUFLLFNBQVM7RUFDZCxLQUFLLFVBQVUsS0FBSyxHQUFHLGNBQWM7RUFFckMsS0FBSyxRQUFRLEVBQ1QsT0FBTyxLQUNYO0VBR0EsS0FBSyxVQUFVLEtBQUssR0FBRyxTQUFTO0VBR2hDLEtBQUssUUFBUSxDQUFDO0VBQ2QsS0FBSyxNQUFNLFlBQVksS0FBSyxHQUFHO0VBQy9CLEtBQUssTUFBTSxZQUFZLEtBQUssR0FBRztFQUMvQixLQUFLLE1BQU0sUUFBUSxLQUFLLEdBQUc7RUFDM0IsS0FBSyxNQUFNLFFBQVEsS0FBSyxHQUFHO0VBQzNCLEtBQUssTUFBTSxhQUFhO0NBQzVCO0NBRUEsT0FBTztFQUVILElBQUksS0FBSyxRQUFRLGFBQWEsS0FBSyxRQUFRLHVCQUF1QixLQUFLLElBQUk7RUFDM0UsS0FBSyxHQUFHLFlBQVksS0FBSyxRQUFRLEtBQUssT0FBTztFQUM3QyxLQUFLLFFBQVEsYUFBYSxLQUFLLFFBQVEscUJBQXFCLEtBQUs7Q0FDckU7Q0FFQSxPQUFPLGNBQWMsR0FBRztFQUNwQixNQUFNLGNBQWMsRUFBRSxLQUFLLFVBQVUsS0FBSyxNQUFNLFNBQVMsQ0FBQyxLQUFLO0VBRy9ELElBQUksZUFBZSxLQUFLLFFBQVEsYUFBYSxpQkFBaUIsS0FBSyxJQUFJO0dBRW5FLEtBQUssR0FBRyxTQUFTLGNBQWMsV0FBVztHQUMxQyxLQUFLLEtBQUs7RUFDZDtFQUVBLElBQUksQ0FBQyxhQUFhO0VBQ2xCLEtBQUssY0FBYztFQUVuQixJQUFJLEtBQUssVUFBVSxLQUFLLFFBQVEsT0FBTztHQUNuQyxLQUFLLEdBQUcsWUFBWSxLQUFLLEdBQUcscUJBQXFCLEtBQUssS0FBSztHQUMzRCxLQUFLLFFBQVEsUUFBUSxLQUFLO0VBQzlCO0VBRUEsSUFBSSxLQUFLLHFCQUFxQixLQUFLLFFBQVEsa0JBQWtCO0dBQ3pELEtBQUssR0FBRyxZQUFZLEtBQUssR0FBRyxnQ0FBZ0MsS0FBSyxnQkFBZ0I7R0FDakYsS0FBSyxRQUFRLG1CQUFtQixLQUFLO0VBQ3pDO0VBRUEsSUFBSSxLQUFLLG9CQUFvQixLQUFLLFFBQVEsaUJBQWlCO0dBQ3ZELEtBQUssR0FBRyxZQUFZLEtBQUssR0FBRyxrQkFBa0IsS0FBSyxlQUFlO0dBQ2xFLEtBQUssUUFBUSxrQkFBa0IsS0FBSztFQUN4QztFQUVBLElBQUksS0FBSyxjQUFjLEtBQUssTUFBTSxXQUFXO0dBQ3pDLEtBQUssR0FBRyxjQUFjLEtBQUssUUFBUSxLQUFLLEdBQUcsb0JBQW9CLEtBQUssU0FBUztHQUM3RSxLQUFLLE1BQU0sWUFBWSxLQUFLO0VBQ2hDO0VBRUEsSUFBSSxLQUFLLGNBQWMsS0FBSyxNQUFNLFdBQVc7R0FDekMsS0FBSyxHQUFHLGNBQWMsS0FBSyxRQUFRLEtBQUssR0FBRyxvQkFBb0IsS0FBSyxTQUFTO0dBQzdFLEtBQUssTUFBTSxZQUFZLEtBQUs7RUFDaEM7RUFFQSxJQUFJLEtBQUssVUFBVSxLQUFLLE1BQU0sT0FBTztHQUNqQyxLQUFLLEdBQUcsY0FBYyxLQUFLLFFBQVEsS0FBSyxHQUFHLGdCQUFnQixLQUFLLEtBQUs7R0FDckUsS0FBSyxNQUFNLFFBQVEsS0FBSztFQUM1QjtFQUVBLElBQUksS0FBSyxVQUFVLEtBQUssTUFBTSxPQUFPO0dBQ2pDLEtBQUssR0FBRyxjQUFjLEtBQUssUUFBUSxLQUFLLEdBQUcsZ0JBQWdCLEtBQUssS0FBSztHQUNyRSxLQUFLLE1BQU0sUUFBUSxLQUFLO0VBQzVCO0VBRUEsSUFBSSxLQUFLLFVBQVUsS0FBSyxNQUFNLE9BQU87R0FDakMsS0FBSyxHQUFHLGNBQWMsS0FBSyxRQUFRLEtBQUssR0FBRyxnQkFBZ0IsS0FBSyxLQUFLO0dBQ3JFLEtBQUssTUFBTSxRQUFRLEtBQUs7RUFDNUI7RUFFQSxJQUFJLEtBQUssY0FBYyxLQUFLLGVBQWUsS0FBSyxNQUFNLFlBQVk7R0FDOUQsS0FBSyxHQUFHLGNBQWMsS0FBSyxRQUFRLEtBQUssR0FBRyxTQUFTLGFBQWEsZ0NBQWdDLENBQUMsQ0FBQyw0QkFBNEIsS0FBSyxVQUFVO0dBQzlJLEtBQUssTUFBTSxhQUFhLEtBQUs7RUFDakM7RUFFQSxJQUFJLEtBQUssT0FBTztHQUNaLElBQUksS0FBSyxNQUFNLE9BQU87SUFDbEIsS0FBSyxRQUFRLEtBQUssTUFBTTtJQUN4QixLQUFLLFNBQVMsS0FBSyxNQUFNO0dBQzdCO0dBRUEsSUFBSSxLQUFLLFdBQVcsS0FBSyxHQUFHLGtCQUV4QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxLQUNuQixLQUFLLEdBQUcsV0FBVyxLQUFLLEdBQUcsOEJBQThCLEdBQUcsS0FBSyxPQUFPLEtBQUssZ0JBQWdCLEtBQUssUUFBUSxLQUFLLE1BQU0sS0FBSyxNQUFNLEVBQUU7UUFFbkksSUFBSSxZQUFZLE9BQU8sS0FBSyxLQUFLLEdBQUc7SUFFdkMsSUFBSSxLQUFLLFdBQVcsS0FBSyxHQUFHLFlBQ3hCLEtBQUssR0FBRyxXQUFXLEtBQUssUUFBUSxLQUFLLE9BQU8sS0FBSyxnQkFBZ0IsS0FBSyxPQUFPLEtBQUssUUFBUSxHQUFHLEtBQUssUUFBUSxLQUFLLE1BQU0sS0FBSyxLQUFLO1NBQzVILElBQUksS0FBSyxXQUFXLEtBQUssR0FBRyxvQkFBb0IsS0FBSyxXQUFXLEtBQUssR0FBRyxZQUMzRSxLQUFLLEdBQUcsV0FBVyxLQUFLLFFBQVEsS0FBSyxPQUFPLEtBQUssZ0JBQWdCLEtBQUssT0FBTyxLQUFLLFFBQVEsS0FBSyxRQUFRLEdBQUcsS0FBSyxRQUFRLEtBQUssTUFBTSxLQUFLLEtBQUs7R0FFcEosT0FBTyxJQUFJLEtBQUssTUFBTSxxQkFFbEIsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLEtBQUssTUFBTSxRQUFRLFNBQzNDLEtBQUssR0FBRyxxQkFBcUIsS0FBSyxRQUFRLE9BQU8sS0FBSyxnQkFBZ0IsS0FBSyxNQUFNLE1BQU0sQ0FBQyxPQUFPLEtBQUssTUFBTSxNQUFNLENBQUMsUUFBUSxHQUFHLEtBQUssTUFBTSxNQUFNLENBQUMsSUFBSTtRQUl0SixJQUFJLEtBQUssV0FBVyxLQUFLLEdBQUcsWUFDeEIsS0FBSyxHQUFHLFdBQVcsS0FBSyxRQUFRLEtBQUssT0FBTyxLQUFLLGdCQUFnQixLQUFLLFFBQVEsS0FBSyxNQUFNLEtBQUssS0FBSztRQUVuRyxLQUFLLEdBQUcsV0FBVyxLQUFLLFFBQVEsS0FBSyxPQUFPLEtBQUssZ0JBQWdCLEtBQUssT0FBTyxLQUFLLFFBQVEsS0FBSyxRQUFRLEdBQUcsS0FBSyxRQUFRLEtBQUssTUFBTSxLQUFLLEtBQUs7R0FJcEosSUFBSSxLQUFLLGlCQUFpQjtJQUV0QixJQUFJLENBQUMsS0FBSyxHQUFHLFNBQVMsYUFBYSxDQUFDLFdBQVcsS0FBSyxNQUFNLEtBQUssS0FBSyxDQUFDLFdBQVcsS0FBSyxNQUFNLE1BQU0sSUFBSTtLQUNqRyxLQUFLLGtCQUFrQjtLQUN2QixLQUFLLFFBQVEsS0FBSyxRQUFRLEtBQUssR0FBRztLQUNsQyxLQUFLLFlBQVksS0FBSyxHQUFHO0lBQzdCLE9BQ0ksS0FBSyxHQUFHLGVBQWUsS0FBSyxNQUFNO0dBRTFDO0dBR0EsS0FBSyxZQUFZLEtBQUssU0FBUztFQUNuQyxPQUNJLElBQUksS0FBSyxXQUFXLEtBQUssR0FBRyxrQkFFeEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsS0FDbkIsS0FBSyxHQUFHLFdBQVcsS0FBSyxHQUFHLDhCQUE4QixHQUFHLEdBQUcsS0FBSyxHQUFHLE1BQU0sR0FBRyxHQUFHLEdBQUcsS0FBSyxHQUFHLE1BQU0sS0FBSyxHQUFHLGVBQWUsVUFBVTtPQUV0SSxJQUFJLEtBQUssT0FBTztHQUVuQixJQUFJLEtBQUssV0FBVyxLQUFLLEdBQUcsWUFDeEIsS0FBSyxHQUFHLFdBQVcsS0FBSyxRQUFRLEtBQUssT0FBTyxLQUFLLGdCQUFnQixLQUFLLE9BQU8sS0FBSyxRQUFRLEdBQUcsS0FBSyxRQUFRLEtBQUssTUFBTSxJQUFJO1FBRXpILEtBQUssR0FBRyxXQUFXLEtBQUssUUFBUSxLQUFLLE9BQU8sS0FBSyxnQkFBZ0IsS0FBSyxPQUFPLEtBQUssUUFBUSxLQUFLLFFBQVEsR0FBRyxLQUFLLFFBQVEsS0FBSyxNQUFNLElBQUk7RUFFOUksT0FFSSxLQUFLLEdBQUcsV0FBVyxLQUFLLFFBQVEsR0FBRyxLQUFLLEdBQUcsTUFBTSxHQUFHLEdBQUcsR0FBRyxLQUFLLEdBQUcsTUFBTSxLQUFLLEdBQUcsZUFBZSxVQUFVO0VBR2pILEtBQUssTUFBTSxRQUFRLEtBQUs7Q0FDNUI7QUFDSjs7O0FDOU1BLElBQWEsZUFBYixNQUEwQjtDQUN0QixZQUNJLElBQ0EsRUFDSSxRQUFRLEdBQUcsT0FBTyxPQUNsQixTQUFTLEdBQUcsT0FBTyxRQUNuQixTQUFTLEdBQUcsYUFDWixRQUFRLEdBQ1IsUUFBUSxNQUNSLFVBQVUsT0FDVixlQUFlLE9BQ2YsUUFBUSxHQUFHLGVBQ1gsUUFBUSxHQUFHLGVBQ1gsUUFBUSxHQUFHLGVBQ1gsWUFBWSxHQUFHLFFBQ2YsWUFBWSxXQUNaLE9BQU8sR0FBRyxlQUNWLFNBQVMsR0FBRyxNQUNaLGlCQUFpQixRQUNqQixpQkFDQSxxQkFDQSxDQUFDLEdBQ1A7RUFDRSxLQUFLLEtBQUs7RUFDVixLQUFLLFFBQVE7RUFDYixLQUFLLFNBQVM7RUFDZCxLQUFLLFFBQVE7RUFDYixLQUFLLFVBQVU7RUFDZixLQUFLLFNBQVMsS0FBSyxHQUFHLGtCQUFrQjtFQUN4QyxLQUFLLFNBQVM7RUFDZCxLQUFLLEdBQUcsU0FBUyxnQkFBZ0IsSUFBSTtFQUVyQyxLQUFLLFdBQVcsQ0FBQztFQUNqQixNQUFNLGNBQWMsQ0FBQztFQUdyQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxLQUFLO0dBQzVCLEtBQUssU0FBUyxLQUNWLElBQUksUUFBUSxJQUFJO0lBQ1o7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsT0FBTztJQUNQLGlCQUFpQjtHQUNyQixDQUFDLENBQ0w7R0FDQSxLQUFLLFNBQVMsRUFBRSxDQUFDLE9BQU87R0FDeEIsS0FBSyxHQUFHLHFCQUFxQixLQUFLLFFBQVEsS0FBSyxHQUFHLG9CQUFvQixHQUFHLEtBQUssR0FBRyxZQUFZLEtBQUssU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFhO0dBQ3BJLFlBQVksS0FBSyxLQUFLLEdBQUcsb0JBQW9CLENBQUM7RUFDbEQ7RUFHQSxJQUFJLFlBQVksU0FBUyxHQUFHLEtBQUssR0FBRyxTQUFTLFlBQVksV0FBVztFQUdwRSxLQUFLLFVBQVUsS0FBSyxTQUFTO0VBRzdCLElBQUksaUJBQWlCLEtBQUssR0FBRyxTQUFTLFlBQVksS0FBSyxHQUFHLFNBQVMsYUFBYSxxQkFBcUIsSUFBSTtHQUNyRyxLQUFLLGVBQWUsSUFBSSxRQUFRLElBQUk7SUFDaEM7SUFDQTtJQUNBLFdBQVcsS0FBSyxHQUFHO0lBQ25CLFdBQVcsS0FBSyxHQUFHO0lBQ25CLFFBQVEsS0FBSyxVQUFVLEtBQUssR0FBRyxnQkFBZ0IsS0FBSyxHQUFHO0lBQ3ZELGdCQUFnQixHQUFHLFNBQVMsV0FBWSxLQUFLLFVBQVUsS0FBSyxHQUFHLG1CQUFtQixLQUFLLEdBQUcsb0JBQXFCLEtBQUssR0FBRztJQUN2SCxNQUFNLEtBQUssVUFBVSxLQUFLLEdBQUcsb0JBQW9CLEtBQUssR0FBRztHQUM3RCxDQUFDO0dBQ0QsS0FBSyxhQUFhLE9BQU87R0FDekIsS0FBSyxHQUFHLHFCQUFxQixLQUFLLFFBQVEsS0FBSyxVQUFVLEtBQUssR0FBRywyQkFBMkIsS0FBSyxHQUFHLGtCQUFrQixLQUFLLEdBQUcsWUFBWSxLQUFLLGFBQWEsU0FBUyxDQUFhO0VBQ3RMLE9BQU87R0FFSCxJQUFJLFNBQVMsQ0FBQyxTQUFTO0lBQ25CLEtBQUssY0FBYyxLQUFLLEdBQUcsbUJBQW1CO0lBQzlDLEtBQUssR0FBRyxpQkFBaUIsS0FBSyxHQUFHLGNBQWMsS0FBSyxXQUFXO0lBQy9ELEtBQUssR0FBRyxvQkFBb0IsS0FBSyxHQUFHLGNBQWMsS0FBSyxHQUFHLG1CQUFtQixPQUFPLE1BQU07SUFDMUYsS0FBSyxHQUFHLHdCQUF3QixLQUFLLFFBQVEsS0FBSyxHQUFHLGtCQUFrQixLQUFLLEdBQUcsY0FBYyxLQUFLLFdBQVc7R0FDakg7R0FFQSxJQUFJLFdBQVcsQ0FBQyxPQUFPO0lBQ25CLEtBQUssZ0JBQWdCLEtBQUssR0FBRyxtQkFBbUI7SUFDaEQsS0FBSyxHQUFHLGlCQUFpQixLQUFLLEdBQUcsY0FBYyxLQUFLLGFBQWE7SUFDakUsS0FBSyxHQUFHLG9CQUFvQixLQUFLLEdBQUcsY0FBYyxLQUFLLEdBQUcsZ0JBQWdCLE9BQU8sTUFBTTtJQUN2RixLQUFLLEdBQUcsd0JBQXdCLEtBQUssUUFBUSxLQUFLLEdBQUcsb0JBQW9CLEtBQUssR0FBRyxjQUFjLEtBQUssYUFBYTtHQUNySDtHQUVBLElBQUksU0FBUyxTQUFTO0lBQ2xCLEtBQUsscUJBQXFCLEtBQUssR0FBRyxtQkFBbUI7SUFDckQsS0FBSyxHQUFHLGlCQUFpQixLQUFLLEdBQUcsY0FBYyxLQUFLLGtCQUFrQjtJQUN0RSxLQUFLLEdBQUcsb0JBQW9CLEtBQUssR0FBRyxjQUFjLEtBQUssR0FBRyxlQUFlLE9BQU8sTUFBTTtJQUN0RixLQUFLLEdBQUcsd0JBQXdCLEtBQUssUUFBUSxLQUFLLEdBQUcsMEJBQTBCLEtBQUssR0FBRyxjQUFjLEtBQUssa0JBQWtCO0dBQ2hJO0VBQ0o7RUFFQSxLQUFLLEdBQUcsU0FBUyxnQkFBZ0IsRUFBRSxRQUFRLEtBQUssT0FBTyxDQUFDO0NBQzVEO0NBRUEsUUFBUSxPQUFPLFFBQVE7RUFDbkIsSUFBSSxLQUFLLFVBQVUsU0FBUyxLQUFLLFdBQVcsUUFBUTtFQUVwRCxLQUFLLFFBQVE7RUFDYixLQUFLLFNBQVM7RUFDZCxLQUFLLEdBQUcsU0FBUyxnQkFBZ0IsSUFBSTtFQUVyQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxTQUFTLFFBQVEsS0FBSztHQUMzQyxLQUFLLFNBQVMsRUFBRSxDQUFDLFFBQVE7R0FDekIsS0FBSyxTQUFTLEVBQUUsQ0FBQyxTQUFTO0dBQzFCLEtBQUssU0FBUyxFQUFFLENBQUMsY0FBYztHQUMvQixLQUFLLFNBQVMsRUFBRSxDQUFDLE9BQU87R0FDeEIsS0FBSyxHQUFHLHFCQUFxQixLQUFLLFFBQVEsS0FBSyxHQUFHLG9CQUFvQixHQUFHLEtBQUssR0FBRyxZQUFZLEtBQUssU0FBUyxFQUFFLENBQUMsU0FBUyxDQUFhO0VBQ3hJO0VBRUEsSUFBSSxLQUFLLGNBQWM7R0FDbkIsS0FBSyxhQUFhLFFBQVE7R0FDMUIsS0FBSyxhQUFhLFNBQVM7R0FDM0IsS0FBSyxhQUFhLGNBQWM7R0FDaEMsS0FBSyxhQUFhLE9BQU87R0FDekIsS0FBSyxHQUFHLHFCQUFxQixLQUFLLFFBQVEsS0FBSyxHQUFHLGtCQUFrQixLQUFLLEdBQUcsWUFBWSxLQUFLLGFBQWEsU0FBUyxDQUFhO0VBQ3BJLE9BQU87R0FDSCxJQUFJLEtBQUssYUFBYTtJQUNsQixLQUFLLEdBQUcsaUJBQWlCLEtBQUssR0FBRyxjQUFjLEtBQUssV0FBVztJQUMvRCxLQUFLLEdBQUcsb0JBQW9CLEtBQUssR0FBRyxjQUFjLEtBQUssR0FBRyxtQkFBbUIsT0FBTyxNQUFNO0dBQzlGO0dBRUEsSUFBSSxLQUFLLGVBQWU7SUFDcEIsS0FBSyxHQUFHLGlCQUFpQixLQUFLLEdBQUcsY0FBYyxLQUFLLGFBQWE7SUFDakUsS0FBSyxHQUFHLG9CQUFvQixLQUFLLEdBQUcsY0FBYyxLQUFLLEdBQUcsZ0JBQWdCLE9BQU8sTUFBTTtHQUMzRjtHQUVBLElBQUksS0FBSyxvQkFBb0I7SUFDekIsS0FBSyxHQUFHLGlCQUFpQixLQUFLLEdBQUcsY0FBYyxLQUFLLGtCQUFrQjtJQUN0RSxLQUFLLEdBQUcsb0JBQW9CLEtBQUssR0FBRyxjQUFjLEtBQUssR0FBRyxlQUFlLE9BQU8sTUFBTTtHQUMxRjtFQUNKO0VBRUEsS0FBSyxHQUFHLFNBQVMsZ0JBQWdCLEVBQUUsUUFBUSxLQUFLLE9BQU8sQ0FBQztDQUM1RDtBQUNKOzs7QUNwSkEsSUFBTSxRQUFRO0NBQ1YsT0FBTztDQUNQLE9BQU87Q0FDUCxLQUFLO0NBQ0wsT0FBTztDQUNQLE1BQU07Q0FDTixTQUFTO0NBQ1QsTUFBTTtDQUNOLFFBQVE7Q0FDUixRQUFRO0FBQ1o7QUFFQSxTQUFnQixTQUFTLEtBQUs7Q0FDMUIsSUFBSSxJQUFJLFdBQVcsR0FBRyxNQUFNLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLElBQUk7Q0FDdEYsTUFBTSxNQUFNLDRDQUE0QyxLQUFLLEdBQUc7Q0FDaEUsSUFBSSxDQUFDLEtBQUssUUFBUSxLQUFLLGdDQUFnQyxJQUFJLGVBQWU7Q0FDMUUsT0FBTztFQUFDLFNBQVMsSUFBSSxJQUFJLEVBQUUsSUFBSTtFQUFLLFNBQVMsSUFBSSxJQUFJLEVBQUUsSUFBSTtFQUFLLFNBQVMsSUFBSSxJQUFJLEVBQUUsSUFBSTtDQUFHO0FBQzlGO0FBRUEsU0FBZ0IsWUFBWSxLQUFLO0NBQzdCLE1BQU0sU0FBUyxHQUFHO0NBQ2xCLE9BQU87R0FBRyxPQUFPLEtBQU0sT0FBTztHQUFPLE9BQU8sSUFBSyxPQUFPO0dBQU0sTUFBTSxPQUFPO0NBQUc7QUFDbEY7QUFFQSxTQUFnQixXQUFXLE9BQU87Q0FFOUIsSUFBSSxVQUFVLEtBQUEsR0FBVyxPQUFPO0VBQUM7RUFBRztFQUFHO0NBQUM7Q0FHeEMsSUFBSSxVQUFVLFdBQVcsR0FBRyxPQUFPO0NBR25DLElBQUksQ0FBQyxNQUFNLEtBQUssR0FBRyxPQUFPLFlBQVksS0FBSztDQUczQyxJQUFJLE1BQU0sT0FBTyxLQUFLLE9BQU8sU0FBUyxLQUFLO0NBRzNDLElBQUksTUFBTSxNQUFNLFlBQVksSUFBSSxPQUFPLFNBQVMsTUFBTSxNQUFNLFlBQVksRUFBRTtDQUUxRSxRQUFRLEtBQUssNkJBQTZCO0NBQzFDLE9BQU87RUFBQztFQUFHO0VBQUc7Q0FBQztBQUNuQjs7O0FDOUJBLElBQWEsUUFBYixjQUEyQixNQUFNO0NBQzdCLFlBQVksT0FBTztFQUNmLElBQUksTUFBTSxRQUFRLEtBQUssR0FBRyxPQUFPLE1BQU0sR0FBRyxLQUFLO0VBQy9DLE9BQU8sTUFBTSxHQUFHQyxXQUFxQixHQUFHLFNBQVMsQ0FBQztDQUN0RDtDQUVBLElBQUksSUFBSTtFQUNKLE9BQU8sS0FBSztDQUNoQjtDQUVBLElBQUksSUFBSTtFQUNKLE9BQU8sS0FBSztDQUNoQjtDQUVBLElBQUksSUFBSTtFQUNKLE9BQU8sS0FBSztDQUNoQjtDQUVBLElBQUksRUFBRSxHQUFHO0VBQ0wsS0FBSyxLQUFLO0NBQ2Q7Q0FFQSxJQUFJLEVBQUUsR0FBRztFQUNMLEtBQUssS0FBSztDQUNkO0NBRUEsSUFBSSxFQUFFLEdBQUc7RUFDTCxLQUFLLEtBQUs7Q0FDZDtDQUVBLElBQUksT0FBTztFQUNQLElBQUksTUFBTSxRQUFRLEtBQUssR0FBRyxPQUFPLEtBQUssS0FBSyxLQUFLO0VBQ2hELE9BQU8sS0FBSyxLQUFLQSxXQUFxQixHQUFHLFNBQVMsQ0FBQztDQUN2RDtDQUVBLEtBQUssR0FBRztFQUNKLEtBQUssS0FBSyxFQUFFO0VBQ1osS0FBSyxLQUFLLEVBQUU7RUFDWixLQUFLLEtBQUssRUFBRTtFQUNaLE9BQU87Q0FDWDtBQUNKOzs7Ozs7Ozs7O0FDNUNBLFNBQWdCLEtBQUssS0FBSyxHQUFHO0NBQ3pCLElBQUksS0FBSyxFQUFFO0NBQ1gsSUFBSSxLQUFLLEVBQUU7Q0FDWCxPQUFPO0FBQ1g7Ozs7Ozs7OztBQVVBLFNBQWdCLElBQUksS0FBSyxHQUFHLEdBQUc7Q0FDM0IsSUFBSSxLQUFLO0NBQ1QsSUFBSSxLQUFLO0NBQ1QsT0FBTztBQUNYOzs7Ozs7Ozs7QUFVQSxTQUFnQixJQUFJLEtBQUssR0FBRyxHQUFHO0NBQzNCLElBQUksS0FBSyxFQUFFLEtBQUssRUFBRTtDQUNsQixJQUFJLEtBQUssRUFBRSxLQUFLLEVBQUU7Q0FDbEIsT0FBTztBQUNYOzs7Ozs7Ozs7QUFVQSxTQUFnQixTQUFTLEtBQUssR0FBRyxHQUFHO0NBQ2hDLElBQUksS0FBSyxFQUFFLEtBQUssRUFBRTtDQUNsQixJQUFJLEtBQUssRUFBRSxLQUFLLEVBQUU7Q0FDbEIsT0FBTztBQUNYOzs7Ozs7Ozs7QUFVQSxTQUFnQixTQUFTLEtBQUssR0FBRyxHQUFHO0NBQ2hDLElBQUksS0FBSyxFQUFFLEtBQUssRUFBRTtDQUNsQixJQUFJLEtBQUssRUFBRSxLQUFLLEVBQUU7Q0FDbEIsT0FBTztBQUNYOzs7Ozs7Ozs7QUFVQSxTQUFnQixPQUFPLEtBQUssR0FBRyxHQUFHO0NBQzlCLElBQUksS0FBSyxFQUFFLEtBQUssRUFBRTtDQUNsQixJQUFJLEtBQUssRUFBRSxLQUFLLEVBQUU7Q0FDbEIsT0FBTztBQUNYOzs7Ozs7Ozs7QUFVQSxTQUFnQixNQUFNLEtBQUssR0FBRyxHQUFHO0NBQzdCLElBQUksS0FBSyxFQUFFLEtBQUs7Q0FDaEIsSUFBSSxLQUFLLEVBQUUsS0FBSztDQUNoQixPQUFPO0FBQ1g7Ozs7Ozs7O0FBU0EsU0FBZ0IsU0FBUyxHQUFHLEdBQUc7Q0FDM0IsSUFBSSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQ2IsSUFBSSxFQUFFLEtBQUssRUFBRTtDQUNqQixPQUFPLEtBQUssS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDO0FBQ2xDOzs7Ozs7OztBQVNBLFNBQWdCLGdCQUFnQixHQUFHLEdBQUc7Q0FDbEMsSUFBSSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQ2IsSUFBSSxFQUFFLEtBQUssRUFBRTtDQUNqQixPQUFPLElBQUksSUFBSSxJQUFJO0FBQ3ZCOzs7Ozs7O0FBUUEsU0FBZ0IsT0FBTyxHQUFHO0NBQ3RCLElBQUksSUFBSSxFQUFFLElBQ04sSUFBSSxFQUFFO0NBQ1YsT0FBTyxLQUFLLEtBQUssSUFBSSxJQUFJLElBQUksQ0FBQztBQUNsQzs7Ozs7OztBQVFBLFNBQWdCLGNBQWMsR0FBRztDQUM3QixJQUFJLElBQUksRUFBRSxJQUNOLElBQUksRUFBRTtDQUNWLE9BQU8sSUFBSSxJQUFJLElBQUk7QUFDdkI7Ozs7Ozs7O0FBU0EsU0FBZ0IsT0FBTyxLQUFLLEdBQUc7Q0FDM0IsSUFBSSxLQUFLLENBQUMsRUFBRTtDQUNaLElBQUksS0FBSyxDQUFDLEVBQUU7Q0FDWixPQUFPO0FBQ1g7Ozs7Ozs7O0FBU0EsU0FBZ0IsUUFBUSxLQUFLLEdBQUc7Q0FDNUIsSUFBSSxLQUFLLElBQU0sRUFBRTtDQUNqQixJQUFJLEtBQUssSUFBTSxFQUFFO0NBQ2pCLE9BQU87QUFDWDs7Ozs7Ozs7QUFTQSxTQUFnQixVQUFVLEtBQUssR0FBRztDQUM5QixJQUFJLElBQUksRUFBRSxJQUNOLElBQUksRUFBRTtDQUNWLElBQUksTUFBTSxJQUFJLElBQUksSUFBSTtDQUN0QixJQUFJLE1BQU0sR0FFTixNQUFNLElBQUksS0FBSyxLQUFLLEdBQUc7Q0FFM0IsSUFBSSxLQUFLLEVBQUUsS0FBSztDQUNoQixJQUFJLEtBQUssRUFBRSxLQUFLO0NBQ2hCLE9BQU87QUFDWDs7Ozs7Ozs7QUFTQSxTQUFnQixJQUFJLEdBQUcsR0FBRztDQUN0QixPQUFPLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUU7QUFDbEM7Ozs7Ozs7OztBQVVBLFNBQWdCLE1BQU0sR0FBRyxHQUFHO0NBQ3hCLE9BQU8sRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRTtBQUNsQzs7Ozs7Ozs7OztBQVdBLFNBQWdCLEtBQUssS0FBSyxHQUFHLEdBQUcsR0FBRztDQUMvQixJQUFJLEtBQUssRUFBRSxJQUNQLEtBQUssRUFBRTtDQUNYLElBQUksS0FBSyxLQUFLLEtBQUssRUFBRSxLQUFLO0NBQzFCLElBQUksS0FBSyxLQUFLLEtBQUssRUFBRSxLQUFLO0NBQzFCLE9BQU87QUFDWDs7Ozs7Ozs7Ozs7QUFZQSxTQUFnQixXQUFXLEtBQUssR0FBRyxHQUFHLE9BQU8sSUFBSTtDQUM3QyxNQUFNLE1BQU0sS0FBSyxJQUFJLENBQUMsUUFBUSxFQUFFO0NBQ2hDLElBQUksS0FBSyxFQUFFO0NBQ1gsSUFBSSxLQUFLLEVBQUU7Q0FFWCxJQUFJLEtBQUssRUFBRSxNQUFNLEtBQUssRUFBRSxNQUFNO0NBQzlCLElBQUksS0FBSyxFQUFFLE1BQU0sS0FBSyxFQUFFLE1BQU07Q0FDOUIsT0FBTztBQUNYOzs7Ozs7Ozs7O0FBMkNBLFNBQWdCLGNBQWMsS0FBSyxHQUFHLEdBQUc7Q0FDckMsSUFBSSxJQUFJLEVBQUUsSUFDTixJQUFJLEVBQUU7Q0FDVixJQUFJLEtBQUssRUFBRSxLQUFLLElBQUksRUFBRSxLQUFLLElBQUksRUFBRTtDQUNqQyxJQUFJLEtBQUssRUFBRSxLQUFLLElBQUksRUFBRSxLQUFLLElBQUksRUFBRTtDQUNqQyxPQUFPO0FBQ1g7Ozs7Ozs7Ozs7O0FBWUEsU0FBZ0IsY0FBYyxLQUFLLEdBQUcsR0FBRztDQUNyQyxJQUFJLElBQUksRUFBRTtDQUNWLElBQUksSUFBSSxFQUFFO0NBQ1YsSUFBSSxLQUFLLEVBQUUsS0FBSyxJQUFJLEVBQUUsS0FBSyxJQUFJLEVBQUU7Q0FDakMsSUFBSSxLQUFLLEVBQUUsS0FBSyxJQUFJLEVBQUUsS0FBSyxJQUFJLEVBQUU7Q0FDakMsT0FBTztBQUNYOzs7Ozs7OztBQVNBLFNBQWdCLFlBQVksR0FBRyxHQUFHO0NBQzlCLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRTtBQUN2Qzs7O0FDelVBLElBQWEsT0FBYixNQUFhLGFBQWEsTUFBTTtDQUM1QixZQUFZLElBQUksR0FBRyxJQUFJLEdBQUc7RUFDdEIsTUFBTSxHQUFHLENBQUM7RUFDVixPQUFPO0NBQ1g7Q0FFQSxJQUFJLElBQUk7RUFDSixPQUFPLEtBQUs7Q0FDaEI7Q0FFQSxJQUFJLElBQUk7RUFDSixPQUFPLEtBQUs7Q0FDaEI7Q0FFQSxJQUFJLEVBQUUsR0FBRztFQUNMLEtBQUssS0FBSztDQUNkO0NBRUEsSUFBSSxFQUFFLEdBQUc7RUFDTCxLQUFLLEtBQUs7Q0FDZDtDQUVBLElBQUksR0FBRyxJQUFJLEdBQUc7RUFDVixJQUFJLEVBQUUsUUFBUSxPQUFPLEtBQUssS0FBSyxDQUFDO0VBQ2hDLElBQWEsTUFBTSxHQUFHLENBQUM7RUFDdkIsT0FBTztDQUNYO0NBRUEsS0FBSyxHQUFHO0VBQ0osS0FBYyxNQUFNLENBQUM7RUFDckIsT0FBTztDQUNYO0NBRUEsSUFBSSxJQUFJLElBQUk7RUFDUixJQUFJLElBQUksSUFBYSxNQUFNLElBQUksRUFBRTtPQUM1QixJQUFhLE1BQU0sTUFBTSxFQUFFO0VBQ2hDLE9BQU87Q0FDWDtDQUVBLElBQUksSUFBSSxJQUFJO0VBQ1IsSUFBSSxJQUFJLFNBQWtCLE1BQU0sSUFBSSxFQUFFO09BQ2pDLFNBQWtCLE1BQU0sTUFBTSxFQUFFO0VBQ3JDLE9BQU87Q0FDWDtDQUVBLFNBQVMsR0FBRztFQUNSLElBQUksRUFBRSxRQUFRLFNBQWtCLE1BQU0sTUFBTSxDQUFDO09BQ3hDLE1BQWUsTUFBTSxNQUFNLENBQUM7RUFDakMsT0FBTztDQUNYO0NBRUEsT0FBTyxHQUFHO0VBQ04sSUFBSSxFQUFFLFFBQVEsT0FBZ0IsTUFBTSxNQUFNLENBQUM7T0FDdEMsTUFBZSxNQUFNLE1BQU0sSUFBSSxDQUFDO0VBQ3JDLE9BQU87Q0FDWDtDQUVBLFFBQVEsSUFBSSxNQUFNO0VBQ2QsUUFBaUIsTUFBTSxDQUFDO0VBQ3hCLE9BQU87Q0FDWDtDQUdBLE1BQU07RUFDRixPQUFPQyxPQUFnQixJQUFJO0NBQy9CO0NBRUEsU0FBUyxHQUFHO0VBQ1IsSUFBSSxHQUFHLE9BQU9DLFNBQWtCLE1BQU0sQ0FBQztPQUNsQyxPQUFPRCxPQUFnQixJQUFJO0NBQ3BDO0NBRUEsYUFBYTtFQUNULE9BQU8sS0FBSyxnQkFBZ0I7Q0FDaEM7Q0FFQSxnQkFBZ0IsR0FBRztFQUNmLElBQUksR0FBRyxPQUFPRSxnQkFBeUIsTUFBTSxDQUFDO09BQ3pDLE9BQU9DLGNBQXVCLElBQUk7Q0FDM0M7Q0FFQSxPQUFPLElBQUksTUFBTTtFQUNiLE9BQWdCLE1BQU0sQ0FBQztFQUN2QixPQUFPO0NBQ1g7Q0FFQSxNQUFNLElBQUksSUFBSTtFQUNWLElBQUksSUFBSSxPQUFPQyxNQUFlLElBQUksRUFBRTtFQUNwQyxPQUFPQSxNQUFlLE1BQU0sRUFBRTtDQUNsQztDQUVBLE1BQU0sR0FBRztFQUNMLE1BQWUsTUFBTSxNQUFNLENBQUM7RUFDNUIsT0FBTztDQUNYO0NBRUEsWUFBWTtFQUNSLFVBQW1CLE1BQU0sSUFBSTtFQUM3QixPQUFPO0NBQ1g7Q0FFQSxJQUFJLEdBQUc7RUFDSCxPQUFPQyxJQUFhLE1BQU0sQ0FBQztDQUMvQjtDQUVBLE9BQU8sR0FBRztFQUNOLE9BQU9DLFlBQXFCLE1BQU0sQ0FBQztDQUN2QztDQUVBLGFBQWEsTUFBTTtFQUNmLGNBQXVCLE1BQU0sTUFBTSxJQUFJO0VBQ3ZDLE9BQU87Q0FDWDtDQUVBLGFBQWEsTUFBTTtFQUNmLGNBQXVCLE1BQU0sTUFBTSxJQUFJO0VBQ3ZDLE9BQU87Q0FDWDtDQUVBLEtBQUssR0FBRyxHQUFHO0VBQ1AsS0FBYyxNQUFNLE1BQU0sR0FBRyxDQUFDO0VBQzlCLE9BQU87Q0FDWDtDQUVBLFdBQVcsR0FBRyxPQUFPLElBQUk7RUFDckIsV0FBb0IsTUFBTSxNQUFNLEdBQUcsT0FBTyxFQUFFO0VBQzVDLE9BQU87Q0FDWDtDQUVBLFFBQVE7RUFDSixPQUFPLElBQUksS0FBSyxLQUFLLElBQUksS0FBSyxFQUFFO0NBQ3BDO0NBRUEsVUFBVSxHQUFHLElBQUksR0FBRztFQUNoQixLQUFLLEtBQUssRUFBRTtFQUNaLEtBQUssS0FBSyxFQUFFLElBQUk7RUFDaEIsT0FBTztDQUNYO0NBRUEsUUFBUSxJQUFJLENBQUMsR0FBRyxJQUFJLEdBQUc7RUFDbkIsRUFBRSxLQUFLLEtBQUs7RUFDWixFQUFFLElBQUksS0FBSyxLQUFLO0VBQ2hCLE9BQU87Q0FDWDtBQUNKOzs7QUNoSkEsSUFBYSxPQUFiLGNBQTBCLE1BQU07Q0FDNUIsWUFBWSxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLEdBQUc7RUFDcEMsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDO0VBQ2hCLE9BQU87Q0FDWDtDQUVBLElBQUksSUFBSTtFQUNKLE9BQU8sS0FBSztDQUNoQjtDQUVBLElBQUksSUFBSTtFQUNKLE9BQU8sS0FBSztDQUNoQjtDQUVBLElBQUksSUFBSTtFQUNKLE9BQU8sS0FBSztDQUNoQjtDQUVBLElBQUksSUFBSTtFQUNKLE9BQU8sS0FBSztDQUNoQjtDQUVBLElBQUksRUFBRSxHQUFHO0VBQ0wsS0FBSyxLQUFLO0NBQ2Q7Q0FFQSxJQUFJLEVBQUUsR0FBRztFQUNMLEtBQUssS0FBSztDQUNkO0NBRUEsSUFBSSxFQUFFLEdBQUc7RUFDTCxLQUFLLEtBQUs7Q0FDZDtDQUVBLElBQUksRUFBRSxHQUFHO0VBQ0wsS0FBSyxLQUFLO0NBQ2Q7Q0FFQSxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLEdBQUc7RUFDeEIsSUFBSSxFQUFFLFFBQVEsT0FBTyxLQUFLLEtBQUssQ0FBQztFQUNoQyxNQUFhLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQztFQUM3QixPQUFPO0NBQ1g7Q0FFQSxLQUFLLEdBQUc7RUFDSixPQUFjLE1BQU0sQ0FBQztFQUNyQixPQUFPO0NBQ1g7Q0FFQSxZQUFZO0VBQ1IsWUFBbUIsTUFBTSxJQUFJO0VBQzdCLE9BQU87Q0FDWDtDQUVBLFNBQVMsR0FBRztFQUNSLFFBQWUsTUFBTSxNQUFNLENBQUM7RUFDNUIsT0FBTztDQUNYO0NBRUEsSUFBSSxHQUFHO0VBQ0gsT0FBT0MsTUFBYSxNQUFNLENBQUM7Q0FDL0I7Q0FFQSxVQUFVLEdBQUcsSUFBSSxHQUFHO0VBQ2hCLEtBQUssS0FBSyxFQUFFO0VBQ1osS0FBSyxLQUFLLEVBQUUsSUFBSTtFQUNoQixLQUFLLEtBQUssRUFBRSxJQUFJO0VBQ2hCLEtBQUssS0FBSyxFQUFFLElBQUk7RUFDaEIsT0FBTztDQUNYO0NBRUEsUUFBUSxJQUFJLENBQUMsR0FBRyxJQUFJLEdBQUc7RUFDbkIsRUFBRSxLQUFLLEtBQUs7RUFDWixFQUFFLElBQUksS0FBSyxLQUFLO0VBQ2hCLEVBQUUsSUFBSSxLQUFLLEtBQUs7RUFDaEIsRUFBRSxJQUFJLEtBQUssS0FBSztFQUNoQixPQUFPO0NBQ1g7QUFDSjs7O0FDOUVBLElBQWEsUUFBYixNQUFhLGNBQWMsU0FBUztDQUNoQyxZQUFZLElBQUksRUFBRSxRQUFRLEdBQUcsU0FBUyxHQUFHLGdCQUFnQixHQUFHLGlCQUFpQixHQUFHLGFBQWEsQ0FBQyxNQUFNLENBQUMsR0FBRztFQUNwRyxNQUFNLFFBQVE7RUFDZCxNQUFNLFFBQVE7RUFHZCxNQUFNLE9BQU8sUUFBUSxNQUFNLFFBQVE7RUFDbkMsTUFBTSxhQUFhLFFBQVEsUUFBUTtFQUduQyxNQUFNLFdBQVcsSUFBSSxhQUFhLE1BQU0sQ0FBQztFQUN6QyxNQUFNLFNBQVMsSUFBSSxhQUFhLE1BQU0sQ0FBQztFQUN2QyxNQUFNLEtBQUssSUFBSSxhQUFhLE1BQU0sQ0FBQztFQUNuQyxNQUFNLFFBQVEsYUFBYSxRQUFRLElBQUksWUFBWSxVQUFVLElBQUksSUFBSSxZQUFZLFVBQVU7RUFFM0YsTUFBTSxXQUFXLFVBQVUsUUFBUSxJQUFJLE9BQU8sT0FBTyxRQUFRLEdBQUcsT0FBTyxLQUFLO0VBRTVFLE9BQU8sT0FBTyxZQUFZO0dBQ3RCLFVBQVU7SUFBRSxNQUFNO0lBQUcsTUFBTTtHQUFTO0dBQ3BDLFFBQVE7SUFBRSxNQUFNO0lBQUcsTUFBTTtHQUFPO0dBQ2hDLElBQUk7SUFBRSxNQUFNO0lBQUcsTUFBTTtHQUFHO0dBQ3hCLE9BQU8sRUFBRSxNQUFNLE1BQU07RUFDekIsQ0FBQztFQUVELE1BQU0sSUFBSSxVQUFVO0NBQ3hCO0NBRUEsT0FBTyxXQUFXLFVBQVUsUUFBUSxJQUFJLE9BQU8sT0FBTyxRQUFRLE9BQU8sT0FBTyxPQUFPLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxHQUFHLE9BQU8sR0FBRyxPQUFPLElBQUksSUFBSSxHQUFHLEtBQUssR0FBRztFQUN4SSxNQUFNLEtBQUs7RUFDWCxNQUFNLE9BQU8sUUFBUTtFQUNyQixNQUFNLE9BQU8sU0FBUztFQUV0QixLQUFLLElBQUksS0FBSyxHQUFHLE1BQU0sT0FBTyxNQUFNO0dBQ2hDLElBQUksSUFBSSxLQUFLLE9BQU8sU0FBUztHQUM3QixLQUFLLElBQUksS0FBSyxHQUFHLE1BQU0sT0FBTyxNQUFNLEtBQUs7SUFDckMsSUFBSSxJQUFJLEtBQUssT0FBTyxRQUFRO0lBRTVCLFNBQVMsSUFBSSxJQUFJLEtBQUssSUFBSTtJQUMxQixTQUFTLElBQUksSUFBSSxLQUFLLElBQUk7SUFDMUIsU0FBUyxJQUFJLElBQUksS0FBSyxRQUFRO0lBRTlCLE9BQU8sSUFBSSxJQUFJLEtBQUs7SUFDcEIsT0FBTyxJQUFJLElBQUksS0FBSztJQUNwQixPQUFPLElBQUksSUFBSSxLQUFLLFNBQVMsSUFBSSxJQUFJO0lBRXJDLEdBQUcsSUFBSSxLQUFLLEtBQUs7SUFDakIsR0FBRyxJQUFJLElBQUksS0FBSyxJQUFJLEtBQUs7SUFFekIsSUFBSSxPQUFPLFNBQVMsT0FBTyxPQUFPO0lBQ2xDLElBQUksSUFBSSxLQUFLLEtBQUssTUFBTSxRQUFRO0lBQ2hDLElBQUksSUFBSSxLQUFLLE1BQU0sS0FBSyxNQUFNLFFBQVE7SUFDdEMsSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLE1BQU0sUUFBUSxLQUFLO0lBQzNDLElBQUksSUFBSSxLQUFLLEtBQUssTUFBTSxRQUFRLEtBQUs7SUFFckMsTUFBTSxLQUFLLEtBQUs7SUFDaEIsTUFBTSxLQUFLLElBQUksS0FBSztJQUNwQixNQUFNLEtBQUssSUFBSSxLQUFLO0lBQ3BCLE1BQU0sS0FBSyxJQUFJLEtBQUs7SUFDcEIsTUFBTSxLQUFLLElBQUksS0FBSztJQUNwQixNQUFNLEtBQUssSUFBSSxLQUFLO0lBQ3BCO0dBQ0o7RUFDSjtDQUNKO0FBQ0o7OztBQy9EQSxJQUFhLE1BQWIsY0FBeUIsU0FBUztDQUM5QixZQUFZLElBQUksRUFBRSxRQUFRLEdBQUcsU0FBUyxHQUFHLFFBQVEsR0FBRyxnQkFBZ0IsR0FBRyxpQkFBaUIsR0FBRyxnQkFBZ0IsR0FBRyxhQUFhLENBQUMsTUFBTSxDQUFDLEdBQUc7RUFDbEksTUFBTSxRQUFRO0VBQ2QsTUFBTSxRQUFRO0VBQ2QsTUFBTSxRQUFRO0VBRWQsTUFBTSxPQUFPLFFBQVEsTUFBTSxRQUFRLEtBQUssS0FBSyxRQUFRLE1BQU0sUUFBUSxLQUFLLEtBQUssUUFBUSxNQUFNLFFBQVEsS0FBSztFQUN4RyxNQUFNLGNBQWMsUUFBUSxRQUFRLElBQUksUUFBUSxRQUFRLElBQUksUUFBUSxRQUFRLEtBQUs7RUFFakYsTUFBTSxXQUFXLElBQUksYUFBYSxNQUFNLENBQUM7RUFDekMsTUFBTSxTQUFTLElBQUksYUFBYSxNQUFNLENBQUM7RUFDdkMsTUFBTSxLQUFLLElBQUksYUFBYSxNQUFNLENBQUM7RUFDbkMsTUFBTSxRQUFRLE1BQU0sUUFBUSxJQUFJLFlBQVksVUFBVSxJQUFJLElBQUksWUFBWSxVQUFVO0VBRXBGLElBQUksSUFBSTtFQUNSLElBQUksS0FBSztFQUdULE1BQU0sV0FBVyxVQUFVLFFBQVEsSUFBSSxPQUFPLE9BQU8sUUFBUSxPQUFPLE9BQU8sT0FBTyxHQUFHLEdBQUcsR0FBRyxJQUFJLElBQUksR0FBRyxFQUFFO0VBQ3hHLE1BQU0sUUFBUSxNQUFNLFFBQVE7RUFDNUIsTUFBTSxRQUFRO0VBRWQsTUFBTSxXQUFXLFVBQVUsUUFBUSxJQUFJLE9BQU8sT0FBTyxRQUFRLENBQUMsT0FBTyxPQUFPLE9BQU8sR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLEdBQUcsRUFBRTtFQUN4RyxNQUFNLFFBQVEsTUFBTSxRQUFRO0VBQzVCLE1BQU0sUUFBUTtFQUdkLE1BQU0sV0FBVyxVQUFVLFFBQVEsSUFBSSxPQUFPLE9BQU8sT0FBTyxRQUFRLE9BQU8sT0FBTyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFO0VBQ3RHLE1BQU0sUUFBUSxNQUFNLFFBQVE7RUFDNUIsTUFBTSxRQUFRO0VBRWQsTUFBTSxXQUFXLFVBQVUsUUFBUSxJQUFJLE9BQU8sT0FBTyxPQUFPLENBQUMsUUFBUSxPQUFPLE9BQU8sR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLEdBQUcsRUFBRTtFQUN4RyxNQUFNLFFBQVEsTUFBTSxRQUFRO0VBQzVCLE1BQU0sUUFBUTtFQUdkLE1BQU0sV0FBVyxVQUFVLFFBQVEsSUFBSSxPQUFPLE9BQU8sUUFBUSxDQUFDLE9BQU8sT0FBTyxPQUFPLEdBQUcsR0FBRyxHQUFHLElBQUksSUFBSSxHQUFHLEVBQUU7RUFDekcsTUFBTSxRQUFRLE1BQU0sUUFBUTtFQUM1QixNQUFNLFFBQVE7RUFFZCxNQUFNLFdBQVcsVUFBVSxRQUFRLElBQUksT0FBTyxPQUFPLFFBQVEsT0FBTyxPQUFPLE9BQU8sR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLEdBQUcsRUFBRTtFQUV2RyxPQUFPLE9BQU8sWUFBWTtHQUN0QixVQUFVO0lBQUUsTUFBTTtJQUFHLE1BQU07R0FBUztHQUNwQyxRQUFRO0lBQUUsTUFBTTtJQUFHLE1BQU07R0FBTztHQUNoQyxJQUFJO0lBQUUsTUFBTTtJQUFHLE1BQU07R0FBRztHQUN4QixPQUFPLEVBQUUsTUFBTSxNQUFNO0VBQ3pCLENBQUM7RUFFRCxNQUFNLElBQUksVUFBVTtDQUN4QjtBQUNKOzs7QUNuREEsSUFBYSxTQUFiLGNBQTRCLFNBQVM7Q0FDakMsWUFDSSxJQUNBLEVBQ0ksU0FBUyxJQUNULGdCQUFnQixJQUNoQixpQkFBaUIsS0FBSyxLQUFLLGdCQUFnQixFQUFHLEdBQzlDLFdBQVcsR0FDWCxZQUFZLEtBQUssS0FBSyxHQUN0QixhQUFhLEdBQ2IsY0FBYyxLQUFLLElBQ25CLGFBQWEsQ0FBQyxNQUNkLENBQUMsR0FDUDtFQUNFLE1BQU0sUUFBUTtFQUNkLE1BQU0sUUFBUTtFQUNkLE1BQU0sU0FBUztFQUNmLE1BQU0sVUFBVTtFQUNoQixNQUFNLFNBQVM7RUFDZixNQUFNLFVBQVU7RUFFaEIsTUFBTSxPQUFPLFFBQVEsTUFBTSxRQUFRO0VBQ25DLE1BQU0sYUFBYSxRQUFRLFFBQVE7RUFFbkMsTUFBTSxXQUFXLElBQUksYUFBYSxNQUFNLENBQUM7RUFDekMsTUFBTSxTQUFTLElBQUksYUFBYSxNQUFNLENBQUM7RUFDdkMsTUFBTSxLQUFLLElBQUksYUFBYSxNQUFNLENBQUM7RUFDbkMsTUFBTSxRQUFRLE1BQU0sUUFBUSxJQUFJLFlBQVksVUFBVSxJQUFJLElBQUksWUFBWSxVQUFVO0VBRXBGLElBQUksSUFBSTtFQUNSLElBQUksS0FBSztFQUNULElBQUksS0FBSztFQUNULElBQUksS0FBSyxTQUFTO0VBQ2xCLE1BQU0sT0FBTyxDQUFDO0VBRWQsSUFBSSxJQUFJLElBQUksS0FBSztFQUVqQixLQUFLLElBQUksS0FBSyxHQUFHLE1BQU0sT0FBTyxNQUFNO0dBQ2hDLElBQUksT0FBTyxDQUFDO0dBQ1osSUFBSSxJQUFJLEtBQUs7R0FDYixLQUFLLElBQUksS0FBSyxHQUFHLE1BQU0sT0FBTyxNQUFNLEtBQUs7SUFDckMsSUFBSSxJQUFJLEtBQUs7SUFDYixJQUFJLElBQUksQ0FBQyxTQUFTLEtBQUssSUFBSSxTQUFTLElBQUksT0FBTyxJQUFJLEtBQUssSUFBSSxTQUFTLElBQUksT0FBTztJQUNoRixJQUFJLElBQUksU0FBUyxLQUFLLElBQUksU0FBUyxJQUFJLE9BQU87SUFDOUMsSUFBSSxJQUFJLFNBQVMsS0FBSyxJQUFJLFNBQVMsSUFBSSxPQUFPLElBQUksS0FBSyxJQUFJLFNBQVMsSUFBSSxPQUFPO0lBRS9FLFNBQVMsSUFBSSxLQUFLO0lBQ2xCLFNBQVMsSUFBSSxJQUFJLEtBQUs7SUFDdEIsU0FBUyxJQUFJLElBQUksS0FBSztJQUV0QixFQUFFLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLFVBQVU7SUFDekIsT0FBTyxJQUFJLEtBQUssRUFBRTtJQUNsQixPQUFPLElBQUksSUFBSSxLQUFLLEVBQUU7SUFDdEIsT0FBTyxJQUFJLElBQUksS0FBSyxFQUFFO0lBRXRCLEdBQUcsSUFBSSxLQUFLO0lBQ1osR0FBRyxJQUFJLElBQUksS0FBSyxJQUFJO0lBRXBCLEtBQUssS0FBSyxJQUFJO0dBQ2xCO0dBRUEsS0FBSyxLQUFLLElBQUk7RUFDbEI7RUFFQSxLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssT0FBTyxNQUN6QixLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssT0FBTyxNQUFNO0dBQy9CLElBQUksSUFBSSxLQUFLLEdBQUcsQ0FBQyxLQUFLO0dBQ3RCLElBQUksSUFBSSxLQUFLLEdBQUcsQ0FBQztHQUNqQixJQUFJLElBQUksS0FBSyxLQUFLLEVBQUUsQ0FBQztHQUNyQixJQUFJLElBQUksS0FBSyxLQUFLLEVBQUUsQ0FBQyxLQUFLO0dBRTFCLElBQUksT0FBTyxLQUFLLFNBQVMsR0FBRztJQUN4QixNQUFNLEtBQUssS0FBSztJQUNoQixNQUFNLEtBQUssSUFBSSxLQUFLO0lBQ3BCLE1BQU0sS0FBSyxJQUFJLEtBQUs7SUFDcEI7R0FDSjtHQUNBLElBQUksT0FBTyxRQUFRLEtBQUssS0FBSyxLQUFLLElBQUk7SUFDbEMsTUFBTSxLQUFLLEtBQUs7SUFDaEIsTUFBTSxLQUFLLElBQUksS0FBSztJQUNwQixNQUFNLEtBQUssSUFBSSxLQUFLO0lBQ3BCO0dBQ0o7RUFDSjtFQUdKLE9BQU8sT0FBTyxZQUFZO0dBQ3RCLFVBQVU7SUFBRSxNQUFNO0lBQUcsTUFBTTtHQUFTO0dBQ3BDLFFBQVE7SUFBRSxNQUFNO0lBQUcsTUFBTTtHQUFPO0dBQ2hDLElBQUk7SUFBRSxNQUFNO0lBQUcsTUFBTTtHQUFHO0dBQ3hCLE9BQU8sRUFBRSxNQUFNLE1BQU07RUFDekIsQ0FBQztFQUVELE1BQU0sSUFBSSxVQUFVO0NBQ3hCO0FBQ0o7OztBQy9GQSxJQUFhLFdBQWIsY0FBOEIsU0FBUztDQUNuQyxZQUNJLElBQ0EsRUFDSSxZQUFZLElBQ1osZUFBZSxJQUNmLFNBQVMsR0FDVCxpQkFBaUIsR0FDakIsaUJBQWlCLEdBQ2pCLFlBQVksT0FDWixhQUFhLEdBQ2IsY0FBYyxLQUFLLEtBQUssR0FDeEIsYUFBYSxDQUFDLE1BQ2QsQ0FBQyxHQUNQO0VBQ0UsTUFBTSxRQUFRO0VBQ2QsTUFBTSxRQUFRO0VBQ2QsTUFBTSxTQUFTO0VBQ2YsTUFBTSxVQUFVO0VBRWhCLE1BQU0sVUFBVSxZQUFZLElBQUksZ0JBQWdCLFlBQVksSUFBSTtFQUNoRSxNQUFNLE9BQU8sUUFBUSxNQUFNLFFBQVEsSUFBSSxXQUFXO0VBQ2xELE1BQU0sYUFBYSxRQUFRLFFBQVEsSUFBSSxVQUFVLFFBQVE7RUFFekQsTUFBTSxXQUFXLElBQUksYUFBYSxNQUFNLENBQUM7RUFDekMsTUFBTSxTQUFTLElBQUksYUFBYSxNQUFNLENBQUM7RUFDdkMsTUFBTSxLQUFLLElBQUksYUFBYSxNQUFNLENBQUM7RUFDbkMsTUFBTSxRQUFRLE1BQU0sUUFBUSxJQUFJLFlBQVksVUFBVSxJQUFJLElBQUksWUFBWSxVQUFVO0VBRXBGLElBQUksSUFBSTtFQUNSLElBQUksS0FBSztFQUNULE1BQU0sYUFBYSxDQUFDO0VBRXBCLFVBQVU7RUFDVixJQUFJLENBQUMsV0FBVztHQUNaLElBQUksV0FBVyxPQUFPLElBQUk7R0FDMUIsSUFBSSxjQUFjLE9BQU8sS0FBSztFQUNsQztFQUVBLFNBQVMsWUFBWTtHQUNqQixJQUFJLEdBQUc7R0FDUCxNQUFNLElBQUksSUFBSSxLQUFLO0dBQ25CLE1BQU0sU0FBUyxlQUFlLGFBQWE7R0FFM0MsS0FBSyxJQUFJLEdBQUcsS0FBSyxPQUFPLEtBQUs7SUFDekIsTUFBTSxXQUFXLENBQUM7SUFDbEIsTUFBTSxJQUFJLElBQUk7SUFFZCxNQUFNLElBQUksS0FBSyxlQUFlLGFBQWE7SUFDM0MsS0FBSyxJQUFJLEdBQUcsS0FBSyxPQUFPLEtBQUs7S0FDekIsTUFBTSxJQUFJLElBQUk7S0FDZCxNQUFNLFFBQVEsSUFBSSxVQUFVO0tBQzVCLE1BQU0sV0FBVyxLQUFLLElBQUksS0FBSztLQUMvQixNQUFNLFdBQVcsS0FBSyxJQUFJLEtBQUs7S0FFL0IsU0FBUyxJQUFJO01BQUMsSUFBSTtPQUFXLEtBQU0sS0FBSztNQUFRLElBQUk7S0FBUSxHQUFHLElBQUksQ0FBQztLQUNwRSxFQUFFLElBQUksVUFBVSxPQUFPLFFBQVEsQ0FBQyxDQUFDLFVBQVU7S0FDM0MsT0FBTyxJQUFJO01BQUMsRUFBRTtNQUFHLEVBQUU7TUFBRyxFQUFFO0tBQUMsR0FBRyxJQUFJLENBQUM7S0FDakMsR0FBRyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUM7S0FDeEIsU0FBUyxLQUFLLEdBQUc7SUFDckI7SUFDQSxXQUFXLEtBQUssUUFBUTtHQUM1QjtHQUVBLEtBQUssSUFBSSxHQUFHLElBQUksT0FBTyxLQUNuQixLQUFLLElBQUksR0FBRyxJQUFJLE9BQU8sS0FBSztJQUN4QixNQUFNLElBQUksV0FBVyxFQUFFLENBQUM7SUFDeEIsTUFBTSxJQUFJLFdBQVcsSUFBSSxFQUFFLENBQUM7SUFDNUIsTUFBTSxJQUFJLFdBQVcsSUFBSSxFQUFFLENBQUMsSUFBSTtJQUNoQyxNQUFNLElBQUksV0FBVyxFQUFFLENBQUMsSUFBSTtJQUU1QixNQUFNLElBQUk7S0FBQztLQUFHO0tBQUc7S0FBRztLQUFHO0tBQUc7SUFBQyxHQUFHLEtBQUssQ0FBQztJQUNwQyxNQUFNO0dBQ1Y7RUFFUjtFQUVBLFNBQVMsT0FBTyxPQUFPO0dBQ25CLElBQUk7R0FDSixNQUFNLElBQUksVUFBVSxPQUFPLFlBQVk7R0FDdkMsTUFBTSxPQUFPLFVBQVUsT0FBTyxJQUFJO0dBRWxDLE1BQU0sY0FBYztHQUNwQixTQUFTLElBQUk7SUFBQztJQUFHLEtBQU0sU0FBUztJQUFNO0dBQUMsR0FBRyxJQUFJLENBQUM7R0FDL0MsT0FBTyxJQUFJO0lBQUM7SUFBRztJQUFNO0dBQUMsR0FBRyxJQUFJLENBQUM7R0FDOUIsR0FBRyxJQUFJLENBQUMsSUFBSyxFQUFHLEdBQUcsSUFBSSxDQUFDO0dBQ3hCO0dBRUEsS0FBSyxJQUFJLEdBQUcsS0FBSyxPQUFPLEtBQUs7SUFFekIsTUFBTSxRQURJLElBQUksUUFDSSxVQUFVO0lBQzVCLE1BQU0sV0FBVyxLQUFLLElBQUksS0FBSztJQUMvQixNQUFNLFdBQVcsS0FBSyxJQUFJLEtBQUs7SUFFL0IsU0FBUyxJQUFJO0tBQUMsSUFBSTtLQUFVLEtBQU0sU0FBUztLQUFNLElBQUk7SUFBUSxHQUFHLElBQUksQ0FBQztJQUNyRSxPQUFPLElBQUk7S0FBQztLQUFHO0tBQU07SUFBQyxHQUFHLElBQUksQ0FBQztJQUM5QixHQUFHLElBQUksQ0FBQyxXQUFXLEtBQU0sSUFBSyxXQUFXLEtBQU0sT0FBTyxFQUFHLEdBQUcsSUFBSSxDQUFDO0lBQ2pFO0dBQ0o7R0FFQSxLQUFLLElBQUksR0FBRyxJQUFJLE9BQU8sS0FBSztJQUN4QixNQUFNLElBQUksY0FBYyxJQUFJO0lBQzVCLElBQUksT0FDQSxNQUFNLElBQUk7S0FBQztLQUFHLElBQUk7S0FBRztJQUFXLEdBQUcsS0FBSyxDQUFDO1NBRXpDLE1BQU0sSUFBSTtLQUFDLElBQUk7S0FBRztLQUFHO0lBQVcsR0FBRyxLQUFLLENBQUM7SUFFN0M7R0FDSjtFQUNKO0VBRUEsT0FBTyxPQUFPLFlBQVk7R0FDdEIsVUFBVTtJQUFFLE1BQU07SUFBRyxNQUFNO0dBQVM7R0FDcEMsUUFBUTtJQUFFLE1BQU07SUFBRyxNQUFNO0dBQU87R0FDaEMsSUFBSTtJQUFFLE1BQU07SUFBRyxNQUFNO0dBQUc7R0FDeEIsT0FBTyxFQUFFLE1BQU0sTUFBTTtFQUN6QixDQUFDO0VBRUQsTUFBTSxJQUFJLFVBQVU7Q0FDeEI7QUFDSjs7O0FDekhBLElBQWEsV0FBYixjQUE4QixTQUFTO0NBQ25DLFlBQVksSUFBSSxFQUFFLGFBQWEsQ0FBQyxNQUFNLENBQUMsR0FBRztFQUN0QyxPQUFPLE9BQU8sWUFBWTtHQUN0QixVQUFVO0lBQUUsTUFBTTtJQUFHLE1BQU0sSUFBSSxhQUFhO0tBQUM7S0FBSTtLQUFJO0tBQUc7S0FBSTtLQUFJO0lBQUMsQ0FBQztHQUFFO0dBQ3BFLElBQUk7SUFBRSxNQUFNO0lBQUcsTUFBTSxJQUFJLGFBQWE7S0FBQztLQUFHO0tBQUc7S0FBRztLQUFHO0tBQUc7SUFBQyxDQUFDO0dBQUU7RUFDOUQsQ0FBQztFQUVELE1BQU0sSUFBSSxVQUFVO0NBQ3hCO0FBQ0o7OztBQ05BLElBQWEsUUFBYixjQUEyQixTQUFTO0NBQ2hDLFlBQVksSUFBSSxFQUFFLFNBQVMsSUFBSyxPQUFPLElBQUssaUJBQWlCLEdBQUcsa0JBQWtCLEdBQUcsTUFBTSxLQUFLLEtBQUssR0FBRyxhQUFhLENBQUMsTUFBTSxDQUFDLEdBQUc7RUFDNUgsTUFBTSxPQUFPLGlCQUFpQixNQUFNLGtCQUFrQjtFQUN0RCxNQUFNLGFBQWEsaUJBQWlCLGtCQUFrQjtFQUV0RCxNQUFNLFdBQVcsSUFBSSxhQUFhLE1BQU0sQ0FBQztFQUN6QyxNQUFNLFVBQVUsSUFBSSxhQUFhLE1BQU0sQ0FBQztFQUN4QyxNQUFNLE1BQU0sSUFBSSxhQUFhLE1BQU0sQ0FBQztFQUNwQyxNQUFNLFVBQVUsTUFBTSxRQUFRLElBQUksWUFBWSxVQUFVLElBQUksSUFBSSxZQUFZLFVBQVU7RUFFdEYsTUFBTSxTQUFTLElBQUksS0FBSztFQUN4QixNQUFNLFNBQVMsSUFBSSxLQUFLO0VBQ3hCLE1BQU0sU0FBUyxJQUFJLEtBQUs7RUFHeEIsSUFBSSxNQUFNO0VBQ1YsS0FBSyxJQUFJLElBQUksR0FBRyxLQUFLLGdCQUFnQixLQUNqQyxLQUFLLElBQUksSUFBSSxHQUFHLEtBQUssaUJBQWlCLEtBQUssT0FBTztHQUM5QyxNQUFNLElBQUssSUFBSSxrQkFBbUI7R0FDbEMsTUFBTSxJQUFLLElBQUksaUJBQWtCLEtBQUssS0FBSztHQUczQyxPQUFPLEtBQUssU0FBUyxPQUFPLEtBQUssSUFBSSxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUM7R0FDckQsT0FBTyxLQUFLLFNBQVMsT0FBTyxLQUFLLElBQUksQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDO0dBQ3JELE9BQU8sSUFBSSxPQUFPLEtBQUssSUFBSSxDQUFDO0dBRTVCLFNBQVMsSUFBSTtJQUFDLE9BQU87SUFBRyxPQUFPO0lBQUcsT0FBTztHQUFDLEdBQUcsTUFBTSxDQUFDO0dBR3BELE9BQU8sSUFBSSxTQUFTLEtBQUssSUFBSSxDQUFDO0dBQzlCLE9BQU8sSUFBSSxTQUFTLEtBQUssSUFBSSxDQUFDO0dBQzlCLE9BQU8sSUFBSSxRQUFRLE1BQU0sQ0FBQyxDQUFDLFVBQVU7R0FFckMsUUFBUSxJQUFJO0lBQUMsT0FBTztJQUFHLE9BQU87SUFBRyxPQUFPO0dBQUMsR0FBRyxNQUFNLENBQUM7R0FHbkQsSUFBSSxJQUFJLENBQUMsSUFBSSxpQkFBaUIsSUFBSSxjQUFjLEdBQUcsTUFBTSxDQUFDO0VBQzlEO0VBSUosTUFBTTtFQUNOLEtBQUssSUFBSSxJQUFJLEdBQUcsS0FBSyxnQkFBZ0IsS0FDakMsS0FBSyxJQUFJLElBQUksR0FBRyxLQUFLLGlCQUFpQixLQUFLLE9BQU87R0FFOUMsTUFBTSxLQUFLLGtCQUFrQixLQUFLLElBQUksSUFBSTtHQUMxQyxNQUFNLEtBQUssa0JBQWtCLE1BQU0sSUFBSSxLQUFLLElBQUk7R0FDaEQsTUFBTSxLQUFLLGtCQUFrQixNQUFNLElBQUksS0FBSztHQUM1QyxNQUFNLEtBQUssa0JBQWtCLEtBQUssSUFBSTtHQUd0QyxRQUFRLElBQUk7SUFBQztJQUFHO0lBQUc7SUFBRztJQUFHO0lBQUc7R0FBQyxHQUFHLE1BQU0sQ0FBQztFQUMzQztFQUdKLE9BQU8sT0FBTyxZQUFZO0dBQ3RCLFVBQVU7SUFBRSxNQUFNO0lBQUcsTUFBTTtHQUFTO0dBQ3BDLFFBQVE7SUFBRSxNQUFNO0lBQUcsTUFBTTtHQUFRO0dBQ2pDLElBQUk7SUFBRSxNQUFNO0lBQUcsTUFBTTtHQUFJO0dBQ3pCLE9BQU8sRUFBRSxNQUFNLFFBQVE7RUFDM0IsQ0FBQztFQUVELE1BQU0sSUFBSSxVQUFVO0NBQ3hCO0FBQ0o7OztBQzdEQSxJQUFNLFFBQVE7Q0FBRSxNQUFNO0NBQUksUUFBUTtDQUFHLE9BQU87Q0FBRyxLQUFLO0NBQUcsV0FBVztBQUFFO0FBQ3BFLElBQU1DLDZCQUEyQixJQUFJLEtBQUs7QUFDMUMsSUFBTUMsOEJBQTRCLElBQUksS0FBSztBQUMzQyxJQUFNQyw4QkFBNEIsSUFBSSxLQUFLO0FBRTNDLFNBQWdCLE1BQ1osUUFDQSxFQUNJLFVBQVUsVUFDVixVQUFVLE1BQ1YsU0FBUyxJQUFJLEtBQUssR0FDbEIsT0FBTyxLQUNQLFVBQVUsS0FDVixlQUFlLE1BQ2YsY0FBYyxJQUNkLGFBQWEsT0FDYixrQkFBa0IsR0FDbEIsYUFBYSxNQUNiLFlBQVksR0FDWixZQUFZLFNBQ1osWUFBWSxNQUNaLFdBQVcsSUFDWCxnQkFBZ0IsR0FDaEIsZ0JBQWdCLEtBQUssSUFDckIsa0JBQWtCLFdBQ2xCLGtCQUFrQixVQUNsQixjQUFjLEdBQ2QsY0FBYyxhQUNkLENBQUMsR0FDUDtDQUNFLEtBQUssVUFBVTtDQUNmLEtBQUssU0FBUztDQUNkLEtBQUssWUFBWTtDQUdqQixPQUFPLFFBQVE7Q0FDZixVQUFVLFdBQVc7Q0FFckIsS0FBSyxjQUFjO0NBQ25CLEtBQUssY0FBYztDQUduQixNQUFNLGlCQUFpQjtFQUFFLFFBQVE7RUFBRyxLQUFLO0VBQUcsT0FBTztDQUFFO0NBQ3JELE1BQU0sa0JBQWtCO0VBQUUsUUFBUTtFQUFHLEtBQUs7RUFBRyxPQUFPO0NBQUU7Q0FDdEQsTUFBTSxZQUFZO0VBQUUsUUFBUTtFQUFHLEtBQUs7RUFBRyxPQUFPO0NBQUU7Q0FDaEQsTUFBTSxXQUFXLElBQUksS0FBSztDQUcxQixNQUFNLFNBQVMsSUFBSSxLQUFLO0NBQ3hCLE9BQU8sS0FBSyxPQUFPLFFBQVEsQ0FBQyxDQUFDLElBQUksS0FBSyxNQUFNO0NBQzVDLFVBQVUsU0FBUyxnQkFBZ0IsU0FBUyxPQUFPLFNBQVM7Q0FDNUQsVUFBVSxRQUFRLGdCQUFnQixRQUFRLEtBQUssTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDO0NBQ3ZFLFVBQVUsTUFBTSxnQkFBZ0IsTUFBTSxLQUFLLEtBQUssS0FBSyxJQUFJLEtBQUssSUFBSSxPQUFPLElBQUksZ0JBQWdCLFFBQVEsRUFBRSxHQUFHLENBQUMsQ0FBQztDQUU1RyxLQUFLLFNBQVM7Q0FFZCxLQUFLLGVBQWU7RUFDaEIsSUFBSSxZQUNBLGlCQUFpQjtFQUlyQixnQkFBZ0IsVUFBVSxlQUFlO0VBQ3pDLGdCQUFnQixTQUFTLGVBQWU7RUFDeEMsZ0JBQWdCLE9BQU8sZUFBZTtFQUd0QyxnQkFBZ0IsUUFBUSxLQUFLLElBQUksaUJBQWlCLEtBQUssSUFBSSxpQkFBaUIsZ0JBQWdCLEtBQUssQ0FBQztFQUNsRyxnQkFBZ0IsTUFBTSxLQUFLLElBQUksZUFBZSxLQUFLLElBQUksZUFBZSxnQkFBZ0IsR0FBRyxDQUFDO0VBQzFGLGdCQUFnQixTQUFTLEtBQUssSUFBSSxLQUFLLGFBQWEsS0FBSyxJQUFJLEtBQUssYUFBYSxnQkFBZ0IsTUFBTSxDQUFDO0VBR3RHLFVBQVUsUUFBUSxnQkFBZ0IsTUFBTSxVQUFVLE9BQU87RUFDekQsVUFBVSxVQUFVLGdCQUFnQixRQUFRLFVBQVUsU0FBUztFQUMvRCxVQUFVLFdBQVcsZ0JBQWdCLFNBQVMsVUFBVSxVQUFVO0VBR2xFLEtBQUssT0FBTyxJQUFJLFFBQVE7RUFHeEIsSUFBSSxlQUFlLFVBQVUsU0FBUyxLQUFLLElBQUksS0FBSyxJQUFJLE1BQVUsVUFBVSxHQUFHLENBQUM7RUFDaEYsT0FBTyxJQUFJLGVBQWUsS0FBSyxJQUFJLFVBQVUsS0FBSztFQUNsRCxPQUFPLElBQUksVUFBVSxTQUFTLEtBQUssSUFBSSxVQUFVLEdBQUc7RUFDcEQsT0FBTyxJQUFJLGVBQWUsS0FBSyxJQUFJLFVBQVUsS0FBSztFQUdsRCxPQUFPLFNBQVMsS0FBSyxLQUFLLE1BQU0sQ0FBQyxDQUFDLElBQUksTUFBTTtFQUM1QyxPQUFPLE9BQU8sS0FBSyxNQUFNO0VBR3pCLGVBQWUsU0FBUztFQUN4QixlQUFlLE9BQU87RUFDdEIsU0FBUyxTQUFTLE9BQU87RUFHekIsZUFBZSxTQUFTO0NBQzVCO0NBR0EsS0FBSyxzQkFBc0I7RUFDdkIsT0FBTyxLQUFLLE9BQU8sUUFBUSxDQUFDLENBQUMsSUFBSSxLQUFLLE1BQU07RUFDNUMsVUFBVSxTQUFTLGdCQUFnQixTQUFTLE9BQU8sU0FBUztFQUM1RCxVQUFVLFFBQVEsZ0JBQWdCLFFBQVEsS0FBSyxNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUM7RUFDdkUsVUFBVSxNQUFNLGdCQUFnQixNQUFNLEtBQUssS0FBSyxLQUFLLElBQUksS0FBSyxJQUFJLE9BQU8sSUFBSSxnQkFBZ0IsUUFBUSxFQUFFLEdBQUcsQ0FBQyxDQUFDO0VBQzVHLE9BQU8sT0FBTyxLQUFLLE1BQU07Q0FDN0I7Q0FLQSxNQUFNLGNBQWMsSUFBSSxLQUFLO0NBQzdCLE1BQU0sV0FBVyxJQUFJLEtBQUs7Q0FDMUIsTUFBTSxhQUFhLElBQUksS0FBSztDQUU1QixJQUFJLFFBQVEsTUFBTTtDQUNsQixLQUFLLGVBQWU7RUFBRSxPQUFPO0VBQUcsTUFBTTtFQUFHLEtBQUs7Q0FBRTtDQUVoRCxTQUFTLGVBQWU7RUFDcEIsT0FBTyxLQUFLLElBQUksS0FBTSxTQUFTO0NBQ25DO0NBRUEsU0FBUyxRQUFRLFVBQVUsR0FBRztFQUMxQixXQUFTLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEVBQUU7RUFDN0IsV0FBUyxTQUFTLENBQUMsUUFBUTtFQUMzQixTQUFTLElBQUlGLFVBQVE7Q0FDekI7Q0FFQSxTQUFTLE1BQU0sVUFBVSxHQUFHO0VBQ3hCLFdBQVMsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsRUFBRTtFQUM3QixXQUFTLFNBQVMsUUFBUTtFQUMxQixTQUFTLElBQUlBLFVBQVE7Q0FDekI7Q0FFQSxNQUFNLE9BQU8sUUFBUSxXQUFXO0VBQzVCLElBQUksS0FBSyxZQUFZLFdBQVcsU0FBUyxPQUFPO0VBQ2hELFdBQVMsS0FBSyxPQUFPLFFBQVEsQ0FBQyxDQUFDLElBQUksS0FBSyxNQUFNO0VBQzlDLElBQUksaUJBQWlCQSxXQUFTLFNBQVM7RUFDdkMsa0JBQWtCLEtBQUssS0FBTyxPQUFPLE9BQU8sTUFBTSxJQUFLLEtBQUssS0FBTSxHQUFLO0VBQ3ZFLFFBQVMsSUFBSSxTQUFTLGlCQUFrQixHQUFHLGNBQWMsT0FBTyxNQUFNO0VBQ3RFLE1BQU8sSUFBSSxTQUFTLGlCQUFrQixHQUFHLGNBQWMsT0FBTyxNQUFNO0NBQ3hFO0NBRUEsTUFBTSxTQUFTLGVBQWU7RUFDMUIsSUFBSSxLQUFLLGNBQWMsU0FBUyxlQUFlLFVBQVU7T0FDcEQ7R0FDRCxPQUFPLE9BQU87R0FDZCxJQUFJLE9BQU8sU0FBUyxnQkFBZ0IsT0FBTyxhQUFhO1FBQ25ELE9BQU8sWUFBWTtFQUM1QjtDQUNKO0NBRUEsU0FBUyxtQkFBbUI7RUFDeEIsTUFBTSxRQUFVLElBQUksS0FBSyxLQUFNLEtBQUssS0FBTTtFQUMxQyxlQUFlLFNBQVM7Q0FDNUI7Q0FFQSxTQUFTLGlCQUFpQixHQUFHLEdBQUc7RUFDNUIsWUFBVSxJQUFJLEdBQUcsQ0FBQztFQUNsQixZQUFVLElBQUlDLGFBQVcsV0FBVyxDQUFDLENBQUMsU0FBUyxXQUFXO0VBQzFELElBQUksS0FBSyxZQUFZLFdBQVcsU0FBUyxPQUFPO0VBQ2hELGVBQWUsU0FBVSxJQUFJLEtBQUssS0FBS0MsWUFBVSxJQUFLLEdBQUc7RUFDekQsZUFBZSxPQUFRLElBQUksS0FBSyxLQUFLQSxZQUFVLElBQUssR0FBRztFQUN2RCxZQUFZLEtBQUtELFdBQVM7Q0FDOUI7Q0FFQSxTQUFTLHFCQUFxQixHQUFHO0VBQzdCLFlBQVUsSUFBSSxFQUFFLFNBQVMsRUFBRSxPQUFPO0VBQ2xDLFlBQVUsSUFBSUEsYUFBVyxVQUFVO0VBQ25DLElBQUlDLFlBQVUsSUFBSSxHQUNkLE1BQU0sYUFBYSxDQUFDO09BQ2pCLElBQUlBLFlBQVUsSUFBSSxHQUNyQixNQUFNLElBQUksYUFBYSxDQUFDO0VBRTVCLFdBQVcsS0FBS0QsV0FBUztDQUM3QjtDQUVBLFNBQVMsY0FBYyxHQUFHLEdBQUc7RUFDekIsWUFBVSxJQUFJLEdBQUcsQ0FBQztFQUNsQixZQUFVLElBQUlBLGFBQVcsUUFBUSxDQUFDLENBQUMsU0FBUyxRQUFRO0VBQ3BELElBQUlDLFlBQVUsR0FBR0EsWUFBVSxDQUFDO0VBQzVCLFNBQVMsS0FBS0QsV0FBUztDQUMzQjtDQUVBLFNBQVMseUJBQXlCLEdBQUc7RUFDakMsSUFBSSxZQUFZO0dBQ1osSUFBSSxLQUFLLEVBQUUsUUFBUSxFQUFFLENBQUMsUUFBUSxFQUFFLFFBQVEsRUFBRSxDQUFDO0dBQzNDLElBQUksS0FBSyxFQUFFLFFBQVEsRUFBRSxDQUFDLFFBQVEsRUFBRSxRQUFRLEVBQUUsQ0FBQztHQUMzQyxJQUFJLFdBQVcsS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEVBQUU7R0FDMUMsV0FBVyxJQUFJLEdBQUcsUUFBUTtFQUM5QjtFQUVBLElBQUksV0FBVztHQUNYLElBQUksSUFBSSxNQUFPLEVBQUUsUUFBUSxFQUFFLENBQUMsUUFBUSxFQUFFLFFBQVEsRUFBRSxDQUFDO0dBQ2pELElBQUksSUFBSSxNQUFPLEVBQUUsUUFBUSxFQUFFLENBQUMsUUFBUSxFQUFFLFFBQVEsRUFBRSxDQUFDO0dBQ2pELFNBQVMsSUFBSSxHQUFHLENBQUM7RUFDckI7Q0FDSjtDQUVBLFNBQVMsd0JBQXdCLEdBQUc7RUFDaEMsSUFBSSxZQUFZO0dBQ1osSUFBSSxLQUFLLEVBQUUsUUFBUSxFQUFFLENBQUMsUUFBUSxFQUFFLFFBQVEsRUFBRSxDQUFDO0dBQzNDLElBQUksS0FBSyxFQUFFLFFBQVEsRUFBRSxDQUFDLFFBQVEsRUFBRSxRQUFRLEVBQUUsQ0FBQztHQUMzQyxJQUFJLFdBQVcsS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEVBQUU7R0FDMUMsWUFBVSxJQUFJLEdBQUcsUUFBUTtHQUN6QixZQUFVLElBQUksR0FBRyxLQUFLLElBQUlBLFlBQVUsSUFBSSxXQUFXLEdBQUcsU0FBUyxDQUFDO0dBQ2hFLE1BQU1DLFlBQVUsQ0FBQztHQUNqQixXQUFXLEtBQUtELFdBQVM7RUFDN0I7RUFFQSxJQUFJLFdBR0EsY0FGUSxNQUFPLEVBQUUsUUFBUSxFQUFFLENBQUMsUUFBUSxFQUFFLFFBQVEsRUFBRSxDQUFDLFFBQ3pDLE1BQU8sRUFBRSxRQUFRLEVBQUUsQ0FBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLENBQUMsTUFDL0I7Q0FFMUI7Q0FFQSxNQUFNLGVBQWUsTUFBTTtFQUN2QixJQUFJLENBQUMsS0FBSyxTQUFTO0VBRW5CLFFBQVEsRUFBRSxRQUFWO0dBQ0ksS0FBSyxLQUFLLGFBQWE7SUFDbkIsSUFBSSxpQkFBaUIsT0FBTztJQUM1QixZQUFZLElBQUksRUFBRSxTQUFTLEVBQUUsT0FBTztJQUNwQyxRQUFRLE1BQU07SUFDZDtHQUNKLEtBQUssS0FBSyxhQUFhO0lBQ25CLElBQUksZUFBZSxPQUFPO0lBQzFCLFdBQVcsSUFBSSxFQUFFLFNBQVMsRUFBRSxPQUFPO0lBQ25DLFFBQVEsTUFBTTtJQUNkO0dBQ0osS0FBSyxLQUFLLGFBQWE7SUFDbkIsSUFBSSxjQUFjLE9BQU87SUFDekIsU0FBUyxJQUFJLEVBQUUsU0FBUyxFQUFFLE9BQU87SUFDakMsUUFBUSxNQUFNO0VBRXRCO0VBRUEsSUFBSSxVQUFVLE1BQU0sTUFBTTtHQUN0QixPQUFPLGlCQUFpQixhQUFhLGFBQWEsS0FBSztHQUN2RCxPQUFPLGlCQUFpQixXQUFXLFdBQVcsS0FBSztFQUN2RDtDQUNKO0NBRUEsTUFBTSxlQUFlLE1BQU07RUFDdkIsSUFBSSxDQUFDLEtBQUssU0FBUztFQUVuQixRQUFRLE9BQVI7R0FDSSxLQUFLLE1BQU07SUFDUCxJQUFJLGlCQUFpQixPQUFPO0lBQzVCLGlCQUFpQixFQUFFLFNBQVMsRUFBRSxPQUFPO0lBQ3JDO0dBQ0osS0FBSyxNQUFNO0lBQ1AsSUFBSSxlQUFlLE9BQU87SUFDMUIscUJBQXFCLENBQUM7SUFDdEI7R0FDSixLQUFLLE1BQU07SUFDUCxJQUFJLGNBQWMsT0FBTztJQUN6QixjQUFjLEVBQUUsU0FBUyxFQUFFLE9BQU87RUFFMUM7Q0FDSjtDQUVBLE1BQU0sa0JBQWtCO0VBQ3BCLE9BQU8sb0JBQW9CLGFBQWEsYUFBYSxLQUFLO0VBQzFELE9BQU8sb0JBQW9CLFdBQVcsV0FBVyxLQUFLO0VBQ3RELFFBQVEsTUFBTTtDQUNsQjtDQUVBLE1BQU0sZ0JBQWdCLE1BQU07RUFDeEIsSUFBSSxDQUFDLEtBQUssV0FBVyxDQUFDLGNBQWUsVUFBVSxNQUFNLFFBQVEsVUFBVSxNQUFNLFFBQVM7RUFDdEYsRUFBRSxnQkFBZ0I7RUFDbEIsRUFBRSxlQUFlO0VBRWpCLElBQUksRUFBRSxTQUFTLEdBQ1gsTUFBTSxJQUFJLGFBQWEsQ0FBQztPQUNyQixJQUFJLEVBQUUsU0FBUyxHQUNsQixNQUFNLGFBQWEsQ0FBQztDQUU1QjtDQUVBLE1BQU0sZ0JBQWdCLE1BQU07RUFDeEIsSUFBSSxDQUFDLEtBQUssU0FBUztFQUNuQixFQUFFLGVBQWU7RUFFakIsUUFBUSxFQUFFLFFBQVEsUUFBbEI7R0FDSSxLQUFLO0lBQ0QsSUFBSSxpQkFBaUIsT0FBTztJQUM1QixZQUFZLElBQUksRUFBRSxRQUFRLEVBQUUsQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLENBQUMsS0FBSztJQUN0RCxRQUFRLE1BQU07SUFDZDtHQUNKLEtBQUs7SUFDRCxJQUFJLGVBQWUsU0FBUyxjQUFjLE9BQU87SUFDakQseUJBQXlCLENBQUM7SUFDMUIsUUFBUSxNQUFNO0lBQ2Q7R0FDSixTQUNJLFFBQVEsTUFBTTtFQUN0QjtDQUNKO0NBRUEsTUFBTSxlQUFlLE1BQU07RUFDdkIsSUFBSSxDQUFDLEtBQUssU0FBUztFQUNuQixFQUFFLGVBQWU7RUFDakIsRUFBRSxnQkFBZ0I7RUFFbEIsUUFBUSxFQUFFLFFBQVEsUUFBbEI7R0FDSSxLQUFLO0lBQ0QsSUFBSSxpQkFBaUIsT0FBTztJQUM1QixpQkFBaUIsRUFBRSxRQUFRLEVBQUUsQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLENBQUMsS0FBSztJQUN2RDtHQUNKLEtBQUs7SUFDRCxJQUFJLGVBQWUsU0FBUyxjQUFjLE9BQU87SUFDakQsd0JBQXdCLENBQUM7SUFDekI7R0FDSixTQUNJLFFBQVEsTUFBTTtFQUN0QjtDQUNKO0NBRUEsTUFBTSxtQkFBbUI7RUFDckIsSUFBSSxDQUFDLEtBQUssU0FBUztFQUNuQixRQUFRLE1BQU07Q0FDbEI7Q0FFQSxNQUFNLGlCQUFpQixNQUFNO0VBQ3pCLElBQUksQ0FBQyxLQUFLLFNBQVM7RUFDbkIsRUFBRSxlQUFlO0NBQ3JCO0NBRUEsU0FBUyxjQUFjO0VBQ25CLFFBQVEsaUJBQWlCLGVBQWUsZUFBZSxLQUFLO0VBQzVELFFBQVEsaUJBQWlCLGFBQWEsYUFBYSxLQUFLO0VBQ3hELFFBQVEsaUJBQWlCLFNBQVMsY0FBYyxFQUFFLFNBQVMsTUFBTSxDQUFDO0VBQ2xFLFFBQVEsaUJBQWlCLGNBQWMsY0FBYyxFQUFFLFNBQVMsTUFBTSxDQUFDO0VBQ3ZFLFFBQVEsaUJBQWlCLFlBQVksWUFBWSxLQUFLO0VBQ3RELFFBQVEsaUJBQWlCLGFBQWEsYUFBYSxFQUFFLFNBQVMsTUFBTSxDQUFDO0NBQ3pFO0NBRUEsS0FBSyxTQUFTLFdBQVk7RUFDdEIsUUFBUSxvQkFBb0IsZUFBZSxhQUFhO0VBQ3hELFFBQVEsb0JBQW9CLGFBQWEsV0FBVztFQUNwRCxRQUFRLG9CQUFvQixTQUFTLFlBQVk7RUFDakQsUUFBUSxvQkFBb0IsY0FBYyxZQUFZO0VBQ3RELFFBQVEsb0JBQW9CLFlBQVksVUFBVTtFQUNsRCxRQUFRLG9CQUFvQixhQUFhLFdBQVc7RUFDcEQsT0FBTyxvQkFBb0IsYUFBYSxXQUFXO0VBQ25ELE9BQU8sb0JBQW9CLFdBQVcsU0FBUztDQUNuRDtDQUVBLFlBQVk7QUFDaEI7OztBQy9WQSxJQUFNLDRCQUE0QixJQUFJLEtBQUs7QUFDM0MsSUFBTSw0QkFBNEIsSUFBSSxLQUFLO0FBQzNDLElBQU0sNEJBQTRCLElBQUksS0FBSztBQUUzQyxJQUFNLDRCQUE0QixJQUFJLEtBQUs7QUFDM0MsSUFBTSw0QkFBNEIsSUFBSSxLQUFLO0FBQzNDLElBQU0sNEJBQTRCLElBQUksS0FBSztBQUMzQyxJQUFNLDRCQUE0QixJQUFJLEtBQUs7QUFDM0MsSUFBTSw0QkFBNEIsSUFBSSxLQUFLO0FBQzNDLElBQU0sNEJBQTRCLElBQUksS0FBSztBQUMzQyxJQUFNLDRCQUE0QixJQUFJLEtBQUs7QUFDM0MsSUFBTSw0QkFBNEIsSUFBSSxLQUFLO0FBQzNDLElBQU0sNEJBQTRCLElBQUksS0FBSztBQUMzQyxJQUFNLDRCQUE0QixJQUFJLEtBQUs7QUFDM0MsSUFBTSw0QkFBNEIsSUFBSSxLQUFLO0FBRTNDLElBQU1FLDZCQUEyQixJQUFJLEtBQUs7QUFFMUMsSUFBYSxVQUFiLE1BQXFCO0NBQ2pCLGNBQWM7RUFDVixLQUFLLFNBQVMsSUFBSSxLQUFLO0VBQ3ZCLEtBQUssWUFBWSxJQUFJLEtBQUs7Q0FDOUI7Q0FHQSxVQUFVLFFBQVEsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHO0VBQzlCLElBQUksT0FBTyxTQUFTLGdCQUFnQjtHQUdoQyxNQUFNLEVBQUUsTUFBTSxPQUFPLFFBQVEsS0FBSyxTQUFTO0dBQzNDLE1BQU0sSUFBSSxPQUFPLFFBQVMsUUFBUSxRQUFRLFFBQVMsTUFBTSxLQUFLLEtBQU07R0FDcEUsTUFBTSxJQUFJLFNBQVMsUUFBUyxNQUFNLFVBQVUsUUFBUyxNQUFNLEtBQUssS0FBTTtHQUN0RSxLQUFLLE9BQU8sSUFBSSxHQUFHLEdBQUcsQ0FBQztHQUN2QixLQUFLLE9BQU8sYUFBYSxPQUFPLFdBQVc7R0FJM0MsS0FBSyxVQUFVLElBQUksQ0FBQyxPQUFPLFlBQVk7R0FDdkMsS0FBSyxVQUFVLElBQUksQ0FBQyxPQUFPLFlBQVk7R0FDdkMsS0FBSyxVQUFVLElBQUksQ0FBQyxPQUFPLFlBQVk7RUFDM0MsT0FBTztHQUVILE9BQU8sWUFBWSxlQUFlLEtBQUssTUFBTTtHQUc3QyxLQUFLLFVBQVUsSUFBSSxNQUFNLElBQUksTUFBTSxJQUFJLEVBQUc7R0FDMUMsT0FBTyxVQUFVLEtBQUssU0FBUztHQUMvQixLQUFLLFVBQVUsSUFBSSxLQUFLLE1BQU0sQ0FBQyxDQUFDLFVBQVU7RUFDOUM7Q0FDSjtDQUVBLGdCQUFnQixRQUFRLEVBQUUsYUFBYSxTQUFTLENBQUMsTUFBTSxDQUFDLEdBQUc7RUFDdkQsSUFBSSxDQUFDLE1BQU0sUUFBUSxNQUFNLEdBQUcsU0FBUyxDQUFDLE1BQU07RUFFNUMsTUFBTSxlQUFlQTtFQUNyQixNQUFNLFNBQVM7RUFDZixNQUFNLFlBQVk7RUFFbEIsTUFBTSxPQUFPO0VBQ2IsS0FBSyxTQUFTO0VBRWQsT0FBTyxTQUFTLFNBQVM7R0FFckIsSUFBSSxDQUFDLEtBQUssU0FBUyxVQUFVLEtBQUssU0FBUyxPQUFPLFdBQVcsVUFBVSxLQUFLLFNBQVMsc0JBQXNCO0dBQzNHLE1BQU0sU0FBUyxLQUFLLFNBQVM7R0FDN0IsYUFBYSxRQUFRLEtBQUssV0FBVztHQUdyQyxJQUFJO0dBQ0osSUFBSSxhQUFhO0lBQ2IsVUFBVSxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUMsbUJBQW1CLFlBQVk7SUFDOUQsbUJBQW1CLGNBQWMsVUFBVSxJQUFJO0dBQ25EO0dBR0EsT0FBTyxLQUFLLEtBQUssTUFBTSxDQUFDLENBQUMsYUFBYSxZQUFZO0dBQ2xELFVBQVUsS0FBSyxLQUFLLFNBQVMsQ0FBQyxDQUFDLG1CQUFtQixZQUFZO0dBRzlELElBQUksYUFDSTtRQUFBLE9BQU8sU0FBUyxPQUFPLE1BQU0sSUFBSSxPQUFPLFNBQVMsa0JBQWtCO0dBQUE7R0FHM0UsSUFBSSxnQkFBZ0I7R0FHcEIsSUFBSSxLQUFLLFNBQVMsWUFBWSxVQUN0QjtRQUFBLE9BQU8sU0FBUyxPQUFPLE1BQU0sSUFBSSxPQUFPLFFBQVE7S0FDaEQsZ0JBQWdCLEtBQUssZ0JBQWdCLFFBQVEsUUFBUSxTQUFTO0tBQzlELElBQUksQ0FBQyxlQUFlO0lBQ3hCO1VBRUEsSUFDSSxPQUFPLElBQUksT0FBTyxJQUFJLEtBQ3RCLE9BQU8sSUFBSSxPQUFPLElBQUksS0FDdEIsT0FBTyxJQUFJLE9BQU8sSUFBSSxLQUN0QixPQUFPLElBQUksT0FBTyxJQUFJLEtBQ3RCLE9BQU8sSUFBSSxPQUFPLElBQUksS0FDdEIsT0FBTyxJQUFJLE9BQU8sSUFBSSxHQUN4QjtJQUNFLGdCQUFnQixLQUFLLGFBQWEsUUFBUSxRQUFRLFNBQVM7SUFDM0QsSUFBSSxDQUFDLGVBQWU7R0FDeEI7R0FHSixJQUFJLGVBQWUsZ0JBQWdCLGtCQUFrQjtHQUdyRCxJQUFJLENBQUMsS0FBSyxLQUFLLEtBQUssTUFBTTtJQUFFLFlBQVksSUFBSSxLQUFLO0lBQUcsT0FBTyxJQUFJLEtBQUs7R0FBRTtHQUV0RSxLQUFLLElBQUksV0FBVyxLQUFLLFNBQVMsQ0FBQyxDQUFDLFNBQVMsYUFBYSxDQUFDLENBQUMsSUFBSSxNQUFNO0dBQ3RFLEtBQUssSUFBSSxNQUFNLEtBQUssS0FBSyxJQUFJLFVBQVUsQ0FBQyxDQUFDLGFBQWEsS0FBSyxXQUFXO0dBQ3RFLEtBQUssSUFBSSxXQUFXLEtBQUssSUFBSSxNQUFNLFNBQVMsS0FBSyxNQUFNO0dBRXZELEtBQUssS0FBSyxJQUFJO0VBQ2xCLENBQUM7RUFFRCxLQUFLLE1BQU0sR0FBRyxNQUFNLEVBQUUsSUFBSSxXQUFXLEVBQUUsSUFBSSxRQUFRO0VBQ25ELE9BQU87Q0FDWDtDQUVBLGdCQUFnQixRQUFRLEVBQUUsV0FBVyxNQUFNLGFBQWEsWUFBWSxNQUFNLGdCQUFnQixNQUFNLFNBQVMsQ0FBQyxNQUFNLENBQUMsR0FBRztFQUVoSCxNQUFNLE9BQU8sS0FBSyxnQkFBZ0IsUUFBUTtHQUFFO0dBQWE7RUFBTyxDQUFDO0VBQ2pFLElBQUksQ0FBQyxLQUFLLFFBQVEsT0FBTztFQUV6QixNQUFNLGVBQWVBO0VBQ3JCLE1BQU0sU0FBUztFQUNmLE1BQU0sWUFBWTtFQUNsQixNQUFNLElBQUk7RUFDVixNQUFNLElBQUk7RUFDVixNQUFNLElBQUk7RUFDVixNQUFNLG9CQUFvQjtFQUMxQixNQUFNLGFBQWE7RUFDbkIsTUFBTSxZQUFZO0VBQ2xCLE1BQU0sTUFBTTtFQUNaLE1BQU0sTUFBTTtFQUNaLE1BQU0sTUFBTTtFQUVaLEtBQUssSUFBSSxJQUFJLEtBQUssU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO0dBQ3ZDLE1BQU0sT0FBTyxLQUFLO0dBQ2xCLGFBQWEsUUFBUSxLQUFLLFdBQVc7R0FHckMsSUFBSTtHQUNKLElBQUksYUFBYTtJQUNiLFVBQVUsS0FBSyxLQUFLLFNBQVMsQ0FBQyxDQUFDLG1CQUFtQixZQUFZO0lBQzlELG1CQUFtQixjQUFjLFVBQVUsSUFBSTtHQUNuRDtHQUdBLE9BQU8sS0FBSyxLQUFLLE1BQU0sQ0FBQyxDQUFDLGFBQWEsWUFBWTtHQUNsRCxVQUFVLEtBQUssS0FBSyxTQUFTLENBQUMsQ0FBQyxtQkFBbUIsWUFBWTtHQUU5RCxJQUFJLGdCQUFnQjtHQUNwQixJQUFJLFVBQVUsVUFBVTtHQUV4QixNQUFNLFdBQVcsS0FBSztHQUN0QixNQUFNLGFBQWEsU0FBUztHQUM1QixNQUFNLFFBQVEsV0FBVztHQUN6QixNQUFNLFdBQVcsV0FBVztHQUU1QixNQUFNLFFBQVEsS0FBSyxJQUFJLEdBQUcsU0FBUyxVQUFVLEtBQUs7R0FDbEQsTUFBTSxNQUFNLEtBQUssSUFBSSxRQUFRLE1BQU0sUUFBUSxTQUFTLE9BQU8sU0FBUyxVQUFVLFFBQVEsU0FBUyxVQUFVLEtBQUs7R0FHOUcsTUFBTSxTQUFTLFNBQVM7R0FFeEIsS0FBSyxJQUFJLElBQUksT0FBTyxJQUFJLEtBQUssS0FBSyxHQUFHO0lBRWpDLE1BQU0sS0FBSyxRQUFRLE1BQU0sS0FBSyxLQUFLO0lBQ25DLE1BQU0sS0FBSyxRQUFRLE1BQU0sS0FBSyxJQUFJLEtBQUssSUFBSTtJQUMzQyxNQUFNLEtBQUssUUFBUSxNQUFNLEtBQUssSUFBSSxLQUFLLElBQUk7SUFFM0MsRUFBRSxVQUFVLFNBQVMsTUFBTSxLQUFLLE1BQU07SUFDdEMsRUFBRSxVQUFVLFNBQVMsTUFBTSxLQUFLLE1BQU07SUFDdEMsRUFBRSxVQUFVLFNBQVMsTUFBTSxLQUFLLE1BQU07SUFFdEMsTUFBTSxXQUFXLEtBQUssa0JBQWtCLEdBQUcsR0FBRyxHQUFHLFVBQVUsUUFBUSxXQUFXLFVBQVU7SUFDeEYsSUFBSSxDQUFDLFVBQVU7SUFHZixJQUFJLGVBQWUsV0FBVyxrQkFBa0I7SUFFaEQsSUFBSSxDQUFDLGlCQUFpQixXQUFXLGVBQWU7S0FDNUMsZ0JBQWdCO0tBQ2hCLFdBQVc7S0FDWCxXQUFXO0tBQ1gsV0FBVztLQUNYLGtCQUFrQixLQUFLLFVBQVU7SUFDckM7R0FDSjtHQUVBLElBQUksQ0FBQyxlQUFlLEtBQUssT0FBTyxHQUFHLENBQUM7R0FHcEMsS0FBSyxJQUFJLFdBQVcsS0FBSyxTQUFTLENBQUMsQ0FBQyxTQUFTLGFBQWEsQ0FBQyxDQUFDLElBQUksTUFBTTtHQUN0RSxLQUFLLElBQUksTUFBTSxLQUFLLEtBQUssSUFBSSxVQUFVLENBQUMsQ0FBQyxhQUFhLEtBQUssV0FBVztHQUN0RSxLQUFLLElBQUksV0FBVyxLQUFLLElBQUksTUFBTSxTQUFTLEtBQUssTUFBTTtHQUd2RCxJQUFJLENBQUMsS0FBSyxJQUFJLFlBQVk7SUFDdEIsS0FBSyxJQUFJLGtCQUFrQixJQUFJLEtBQUs7SUFDcEMsS0FBSyxJQUFJLGFBQWEsSUFBSSxLQUFLO0lBQy9CLEtBQUssSUFBSSxLQUFLLElBQUksS0FBSztJQUN2QixLQUFLLElBQUksY0FBYyxJQUFJLEtBQUs7SUFDaEMsS0FBSyxJQUFJLFNBQVMsSUFBSSxLQUFLO0dBQy9CO0dBR0EsS0FBSyxJQUFJLGdCQUFnQixLQUFLLGlCQUFpQjtHQUMvQyxLQUFLLElBQUksV0FBVyxLQUFLLEtBQUssSUFBSSxlQUFlLENBQUMsQ0FBQyxtQkFBbUIsS0FBSyxXQUFXO0dBR3RGLElBQUksYUFBYSxlQUFlO0lBRTVCLEVBQUUsVUFBVSxTQUFTLE1BQU0sV0FBVyxDQUFDO0lBQ3ZDLEVBQUUsVUFBVSxTQUFTLE1BQU0sV0FBVyxDQUFDO0lBQ3ZDLEVBQUUsVUFBVSxTQUFTLE1BQU0sV0FBVyxDQUFDO0lBQ3ZDLEtBQUssYUFBYSxLQUFLLElBQUksWUFBWSxHQUFHLEdBQUcsR0FBRyxTQUFTO0dBQzdEO0dBRUEsSUFBSSxhQUFhLFdBQVcsSUFBSTtJQUM1QixJQUFJLFVBQVUsV0FBVyxHQUFHLE1BQU0sV0FBVyxDQUFDO0lBQzlDLElBQUksVUFBVSxXQUFXLEdBQUcsTUFBTSxXQUFXLENBQUM7SUFDOUMsSUFBSSxVQUFVLFdBQVcsR0FBRyxNQUFNLFdBQVcsQ0FBQztJQUM5QyxLQUFLLElBQUksR0FBRyxJQUNSLElBQUksSUFBSSxVQUFVLElBQUksSUFBSSxJQUFJLFVBQVUsSUFBSSxJQUFJLElBQUksVUFBVSxHQUM5RCxJQUFJLElBQUksVUFBVSxJQUFJLElBQUksSUFBSSxVQUFVLElBQUksSUFBSSxJQUFJLFVBQVUsQ0FDbEU7R0FDSjtHQUVBLElBQUksaUJBQWlCLFdBQVcsUUFBUTtJQUNwQyxFQUFFLFVBQVUsV0FBVyxPQUFPLE1BQU0sV0FBVyxDQUFDO0lBQ2hELEVBQUUsVUFBVSxXQUFXLE9BQU8sTUFBTSxXQUFXLENBQUM7SUFDaEQsRUFBRSxVQUFVLFdBQVcsT0FBTyxNQUFNLFdBQVcsQ0FBQztJQUNoRCxLQUFLLElBQUksWUFBWSxJQUNqQixFQUFFLElBQUksVUFBVSxJQUFJLEVBQUUsSUFBSSxVQUFVLElBQUksRUFBRSxJQUFJLFVBQVUsR0FDeEQsRUFBRSxJQUFJLFVBQVUsSUFBSSxFQUFFLElBQUksVUFBVSxJQUFJLEVBQUUsSUFBSSxVQUFVLEdBQ3hELEVBQUUsSUFBSSxVQUFVLElBQUksRUFBRSxJQUFJLFVBQVUsSUFBSSxFQUFFLElBQUksVUFBVSxDQUM1RDtJQUVBLEtBQUssSUFBSSxPQUFPLEtBQUssS0FBSyxJQUFJLFdBQVcsQ0FBQyxDQUFDLG1CQUFtQixLQUFLLFdBQVc7R0FDbEY7RUFDSjtFQUVBLEtBQUssTUFBTSxHQUFHLE1BQU0sRUFBRSxJQUFJLFdBQVcsRUFBRSxJQUFJLFFBQVE7RUFDbkQsT0FBTztDQUNYO0NBRUEsZUFBZSxPQUFPLFNBQVMsS0FBSyxRQUFRLFlBQVksS0FBSyxXQUFXO0VBQ3BFLE1BQU0sUUFBUTtFQUNkLE1BQU0sSUFBSSxNQUFNLFFBQVEsTUFBTTtFQUU5QixNQUFNLElBQUksTUFBTSxJQUFJLE1BQU0sTUFBTTtFQUNoQyxNQUFNLElBQUksVUFBVSxJQUFJLE1BQU0sTUFBTTtFQUVwQyxJQUFJLEtBQUssR0FBRyxPQUFPO0VBQ25CLE1BQU0sUUFBUSxJQUFJO0VBQ2xCLElBQUksU0FBUyxHQUFHLE9BQU87RUFDdkIsT0FBTyxPQUFPLElBQUksVUFBVSxNQUFNLEtBQUssQ0FBQztDQUM1QztDQUVBLGdCQUFnQixRQUFRLFNBQVMsS0FBSyxRQUFRLFlBQVksS0FBSyxXQUFXO0VBQ3RFLE1BQU0sTUFBTTtFQUNaLElBQUksSUFBSSxPQUFPLFFBQVEsTUFBTTtFQUM3QixNQUFNLE1BQU0sSUFBSSxJQUFJLFNBQVM7RUFDN0IsTUFBTSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTTtFQUNoQyxNQUFNLFVBQVUsT0FBTyxTQUFTLE9BQU87RUFDdkMsSUFBSSxLQUFLLFNBQVMsT0FBTztFQUN6QixNQUFNLE1BQU0sS0FBSyxLQUFLLFVBQVUsRUFBRTtFQUNsQyxNQUFNLEtBQUssTUFBTTtFQUNqQixNQUFNLEtBQUssTUFBTTtFQUNqQixJQUFJLEtBQUssS0FBSyxLQUFLLEdBQUcsT0FBTztFQUM3QixJQUFJLEtBQUssR0FBRyxPQUFPO0VBQ25CLE9BQU87Q0FDWDtDQUdBLGFBQWEsS0FBSyxTQUFTLEtBQUssUUFBUSxZQUFZLEtBQUssV0FBVztFQUNoRSxJQUFJLE1BQU0sTUFBTSxPQUFPLE9BQU8sT0FBTztFQUNyQyxNQUFNLFVBQVUsSUFBSSxVQUFVO0VBQzlCLE1BQU0sVUFBVSxJQUFJLFVBQVU7RUFDOUIsTUFBTSxVQUFVLElBQUksVUFBVTtFQUM5QixNQUFNLE1BQU0sSUFBSTtFQUNoQixNQUFNLE1BQU0sSUFBSTtFQUNoQixTQUFTLFdBQVcsSUFBSSxJQUFJLElBQUksSUFBSSxLQUFLLE9BQU8sS0FBSztFQUNyRCxTQUFTLFdBQVcsSUFBSSxJQUFJLElBQUksSUFBSSxLQUFLLE9BQU8sS0FBSztFQUNyRCxVQUFVLFdBQVcsSUFBSSxJQUFJLElBQUksSUFBSSxLQUFLLE9BQU8sS0FBSztFQUN0RCxVQUFVLFdBQVcsSUFBSSxJQUFJLElBQUksSUFBSSxLQUFLLE9BQU8sS0FBSztFQUN0RCxJQUFJLE9BQU8sU0FBUyxRQUFRLE1BQU0sT0FBTztFQUN6QyxJQUFJLFFBQVEsTUFBTSxPQUFPO0VBQ3pCLElBQUksUUFBUSxNQUFNLE9BQU87RUFDekIsVUFBVSxXQUFXLElBQUksSUFBSSxJQUFJLElBQUksS0FBSyxPQUFPLEtBQUs7RUFDdEQsVUFBVSxXQUFXLElBQUksSUFBSSxJQUFJLElBQUksS0FBSyxPQUFPLEtBQUs7RUFDdEQsSUFBSSxPQUFPLFNBQVMsUUFBUSxNQUFNLE9BQU87RUFDekMsSUFBSSxRQUFRLE1BQU0sT0FBTztFQUN6QixJQUFJLFFBQVEsTUFBTSxPQUFPO0VBQ3pCLElBQUksT0FBTyxHQUFHLE9BQU87RUFDckIsT0FBTyxRQUFRLElBQUksT0FBTztDQUM5QjtDQUVBLGtCQUFrQixHQUFHLEdBQUcsR0FBRyxrQkFBa0IsTUFBTSxTQUFTLEtBQUssUUFBUSxZQUFZLEtBQUssV0FBVyxTQUFTLFdBQVc7RUFHckgsTUFBTSxRQUFRO0VBQ2QsTUFBTSxRQUFRO0VBQ2QsTUFBTSxPQUFPO0VBQ2IsTUFBTSxJQUFJLEdBQUcsQ0FBQztFQUNkLE1BQU0sSUFBSSxHQUFHLENBQUM7RUFDZCxPQUFPLE1BQU0sT0FBTyxLQUFLO0VBQ3pCLElBQUksTUFBTSxVQUFVLElBQUksTUFBTTtFQUM5QixJQUFJLENBQUMsS0FBSyxPQUFPO0VBQ2pCLElBQUk7RUFDSixJQUFJLE1BQU0sR0FBRztHQUNULElBQUksaUJBQWlCLE9BQU87R0FDNUIsT0FBTztFQUNYLE9BQU87R0FDSCxPQUFPO0dBQ1AsTUFBTSxDQUFDO0VBQ1g7RUFDQSxLQUFLLElBQUksUUFBUSxDQUFDO0VBQ2xCLElBQUksU0FBUyxPQUFPLFVBQVUsSUFBSSxNQUFNLE1BQU0sTUFBTSxLQUFLLENBQUM7RUFDMUQsSUFBSSxTQUFTLEdBQUcsT0FBTztFQUN2QixJQUFJLFNBQVMsT0FBTyxVQUFVLElBQUksTUFBTSxNQUFNLElBQUksQ0FBQztFQUNuRCxJQUFJLFNBQVMsR0FBRyxPQUFPO0VBQ3ZCLElBQUksU0FBUyxTQUFTLEtBQUssT0FBTztFQUNsQyxJQUFJLE1BQU0sQ0FBQyxPQUFPLEtBQUssSUFBSSxNQUFNO0VBQ2pDLElBQUksTUFBTSxHQUFHLE9BQU87RUFDcEIsT0FBTyxNQUFNO0NBQ2pCO0NBRUEsYUFBYSxPQUFPLEdBQUcsR0FBRyxHQUFHLFNBQVMsV0FBVztFQUk3QyxNQUFNLEtBQUs7RUFDWCxNQUFNLEtBQUs7RUFDWCxNQUFNLEtBQUs7RUFDWCxHQUFHLElBQUksR0FBRyxDQUFDO0VBQ1gsR0FBRyxJQUFJLEdBQUcsQ0FBQztFQUNYLEdBQUcsSUFBSSxPQUFPLENBQUM7RUFDZixNQUFNLFFBQVEsR0FBRyxJQUFJLEVBQUU7RUFDdkIsTUFBTSxRQUFRLEdBQUcsSUFBSSxFQUFFO0VBQ3ZCLE1BQU0sUUFBUSxHQUFHLElBQUksRUFBRTtFQUN2QixNQUFNLFFBQVEsR0FBRyxJQUFJLEVBQUU7RUFDdkIsTUFBTSxRQUFRLEdBQUcsSUFBSSxFQUFFO0VBQ3ZCLE1BQU0sUUFBUSxRQUFRLFFBQVEsUUFBUTtFQUN0QyxJQUFJLFVBQVUsR0FBRyxPQUFPLE9BQU8sSUFBSSxJQUFJLElBQUksRUFBRTtFQUM3QyxNQUFNLFdBQVcsSUFBSTtFQUNyQixNQUFNLEtBQUssUUFBUSxRQUFRLFFBQVEsU0FBUztFQUM1QyxNQUFNLEtBQUssUUFBUSxRQUFRLFFBQVEsU0FBUztFQUM1QyxPQUFPLE9BQU8sSUFBSSxJQUFJLElBQUksR0FBRyxHQUFHLENBQUM7Q0FDckM7QUFDSjs7O0FDdldBLElBQU0sYUFBYTtBQUNuQixJQUFNLGNBQWM7QUFDcEIsSUFBTSxrQkFBa0I7QUFHeEIsSUFBTSxzQkFBc0IsSUFBSSxLQUFLO0FBQ2pDLElBQUEsc0JBQXNCLElBQUksS0FBSztBQUMvQixJQUFBLHNCQUFzQixJQUFJLEtBQUs7QUFDL0IsSUFBQSxzQkFBc0IsSUFBSSxLQUFLOzs7Ozs7O0FBUW5DLFNBQVMsYUFBYSxRQUFRLEdBQUcsSUFBSSxNQUFPLElBQUksTUFBTztDQUNuRCxJQUFJLElBQUksR0FDSixJQUFJLElBQUksT0FBTyxJQUFJLE9BQU8sRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLE9BQU8sRUFBRTtNQUVwRCxJQUFJLElBQUksT0FBTyxJQUFJLElBQUksT0FBTyxJQUFJLEVBQUUsQ0FBQyxDQUNoQyxNQUFNLENBQUMsQ0FBQyxDQUNSLElBQUksT0FBTyxFQUFFO0NBRXRCLElBQUksSUFBSSxPQUFPLFNBQVMsR0FBRztFQUN2QixNQUFNLE9BQU8sT0FBTyxTQUFTO0VBQzdCLElBQUksSUFBSSxPQUFPLE9BQU8sSUFBSSxPQUFPLEtBQUssQ0FBQyxDQUNsQyxNQUFNLENBQUMsQ0FBQyxDQUNSLElBQUksT0FBTyxLQUFLO0NBQ3pCLE9BQ0ksSUFBSSxJQUFJLE9BQU8sSUFBSSxPQUFPLElBQUksRUFBRSxDQUFDLENBQzVCLE1BQU0sQ0FBQyxDQUFDLENBQ1IsSUFBSSxPQUFPLElBQUksRUFBRTtDQUUxQixPQUFPLENBQUMsSUFBSSxNQUFNLEdBQUcsSUFBSSxNQUFNLENBQUM7QUFDcEM7QUFFQSxTQUFTLHdCQUF3QixHQUFHLElBQUksSUFBSSxJQUFJO0NBQzVDLE1BQU0sSUFBSSxJQUFJO0NBQ2QsSUFBSSxLQUFLLEVBQUUsQ0FBQyxDQUFDLE1BQU0sS0FBSyxDQUFDO0NBQ3pCLElBQUksS0FBSyxFQUFFLENBQUMsQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDO0NBQzVCLElBQUksS0FBSyxFQUFFLENBQUMsQ0FBQyxNQUFNLEtBQUssQ0FBQztDQUN6QixNQUFNLE1BQU0sSUFBSSxLQUFLO0NBQ3JCLElBQUksSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDLElBQUksR0FBRztDQUN6QixPQUFPO0FBQ1g7QUFFQSxTQUFTLG9CQUFvQixHQUFHLElBQUksSUFBSSxJQUFJLElBQUk7Q0FDNUMsTUFBTSxJQUFJLElBQUk7Q0FDZCxJQUFJLEtBQUssRUFBRSxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUM7Q0FDekIsSUFBSSxLQUFLLEVBQUUsQ0FBQyxDQUFDLE1BQU0sSUFBSSxLQUFLLElBQUksQ0FBQztDQUNqQyxJQUFJLEtBQUssRUFBRSxDQUFDLENBQUMsTUFBTSxJQUFJLElBQUksS0FBSyxDQUFDO0NBQ2pDLElBQUksS0FBSyxFQUFFLENBQUMsQ0FBQyxNQUFNLEtBQUssQ0FBQztDQUN6QixNQUFNLE1BQU0sSUFBSSxLQUFLO0NBQ3JCLElBQUksSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsSUFBSSxHQUFHO0NBQ2xDLE9BQU87QUFDWDtBQUVBLElBQWEsUUFBYixNQUFhLE1BQU07Q0FDZixZQUFZLEVBQUUsU0FBUztFQUFDLElBQUksS0FBSyxHQUFHLEdBQUcsQ0FBQztFQUFHLElBQUksS0FBSyxHQUFHLEdBQUcsQ0FBQztFQUFHLElBQUksS0FBSyxHQUFHLEdBQUcsQ0FBQztFQUFHLElBQUksS0FBSyxHQUFHLEdBQUcsQ0FBQztDQUFDLEdBQUcsWUFBWSxJQUFJLE9BQU8sZUFBZSxDQUFDLEdBQUc7RUFDM0ksS0FBSyxTQUFTO0VBQ2QsS0FBSyxZQUFZO0VBQ2pCLEtBQUssT0FBTztDQUNoQjtDQUVBLDBCQUEwQixZQUFZLEtBQUssV0FBVztFQUNsRCxNQUFNLFNBQVMsQ0FBQztFQUNoQixNQUFNLFFBQVEsS0FBSyxPQUFPO0VBRTFCLElBQUksUUFBUSxHQUFHO0dBQ1gsUUFBUSxLQUFLLDZCQUE2QjtHQUMxQyxPQUFPLENBQUM7RUFDWjtFQUVBLE1BQU0sS0FBSyxLQUFLLE9BQU87RUFDdkIsSUFBSSxLQUFLLEtBQUssT0FBTyxJQUNqQixLQUFLLEtBQUssT0FBTztFQUVyQixLQUFLLElBQUksSUFBSSxHQUFHLEtBQUssV0FBVyxLQUFLO0dBQ2pDLE1BQU0sSUFBSSx3QkFBd0IsSUFBSSxXQUFXLElBQUksSUFBSSxFQUFFO0dBQzNELE9BQU8sS0FBSyxDQUFDO0VBQ2pCO0VBRUEsSUFBSSxTQUFTO0VBQ2IsT0FBTyxRQUFRLFNBQVMsR0FBRztHQUN2QixHQUFHLEtBQUssRUFBRTtHQUNWLEtBQUssR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRTtHQUN2QixLQUFLLEtBQUssT0FBTztHQUNqQixLQUFLLElBQUksSUFBSSxHQUFHLEtBQUssV0FBVyxLQUFLO0lBQ2pDLE1BQU0sSUFBSSx3QkFBd0IsSUFBSSxXQUFXLElBQUksSUFBSSxFQUFFO0lBQzNELE9BQU8sS0FBSyxDQUFDO0dBQ2pCO0dBQ0E7RUFDSjtFQUVBLE9BQU87Q0FDWDtDQUVBLHNCQUFzQixZQUFZLEtBQUssV0FBVztFQUM5QyxNQUFNLFNBQVMsQ0FBQztFQUNoQixNQUFNLFFBQVEsS0FBSyxPQUFPO0VBRTFCLElBQUksUUFBUSxHQUFHO0dBQ1gsUUFBUSxLQUFLLDZCQUE2QjtHQUMxQyxPQUFPLENBQUM7RUFDWjtFQUVBLElBQUksS0FBSyxLQUFLLE9BQU8sSUFDakIsS0FBSyxLQUFLLE9BQU8sSUFDakIsS0FBSyxLQUFLLE9BQU8sSUFDakIsS0FBSyxLQUFLLE9BQU87RUFFckIsS0FBSyxJQUFJLElBQUksR0FBRyxLQUFLLFdBQVcsS0FBSztHQUNqQyxNQUFNLElBQUksb0JBQW9CLElBQUksV0FBVyxJQUFJLElBQUksSUFBSSxFQUFFO0dBQzNELE9BQU8sS0FBSyxDQUFDO0VBQ2pCO0VBRUEsSUFBSSxTQUFTO0VBQ2IsT0FBTyxRQUFRLFNBQVMsR0FBRztHQUN2QixHQUFHLEtBQUssRUFBRTtHQUNWLEtBQUssR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRTtHQUN2QixLQUFLLEtBQUssT0FBTztHQUNqQixLQUFLLEtBQUssT0FBTyxTQUFTO0dBQzFCLEtBQUssSUFBSSxJQUFJLEdBQUcsS0FBSyxXQUFXLEtBQUs7SUFDakMsTUFBTSxJQUFJLG9CQUFvQixJQUFJLFdBQVcsSUFBSSxJQUFJLElBQUksRUFBRTtJQUMzRCxPQUFPLEtBQUssQ0FBQztHQUNqQjtHQUNBLFVBQVU7RUFDZDtFQUVBLE9BQU87Q0FDWDtDQUVBLHFCQUFxQixZQUFZLEtBQUssV0FBVyxJQUFJLE1BQU8sSUFBSSxNQUFPO0VBQ25FLE1BQU0sU0FBUyxDQUFDO0VBR2hCLElBRmMsS0FBSyxPQUFPLFVBRWIsR0FDVCxPQUFPLEtBQUs7RUFHaEIsSUFBSTtFQUNKLEtBQUssT0FBTyxTQUFTLEdBQUcsTUFBTTtHQUMxQixJQUFJLE1BQU0sR0FDTixLQUFLO1FBQ0Y7SUFDSCxNQUFNLENBQUMsSUFBSSxNQUFNLGFBQWEsS0FBSyxRQUFRLElBQUksR0FBRyxHQUFHLENBQUM7SUFDdEQsTUFBTSxJQUFJLElBQUksTUFBTTtLQUNoQixRQUFRO01BQUM7TUFBSTtNQUFJO01BQUk7S0FBQztLQUN0QixNQUFNO0lBQ1YsQ0FBQztJQUNELE9BQU8sSUFBSTtJQUNYLE9BQU8sS0FBSyxHQUFHLEVBQUUsVUFBVSxTQUFTLENBQUM7SUFDckMsS0FBSztHQUNUO0VBQ0osQ0FBQztFQUVELE9BQU87Q0FDWDtDQUVBLFVBQVUsWUFBWSxLQUFLLFdBQVcsSUFBSSxNQUFPLElBQUksTUFBTztFQUN4RCxNQUFNLE9BQU8sS0FBSztFQUVsQixJQUFJLFNBQVMsaUJBQ1QsT0FBTyxLQUFLLDBCQUEwQixTQUFTO0VBR25ELElBQUksU0FBUyxhQUNULE9BQU8sS0FBSyxzQkFBc0IsU0FBUztFQUcvQyxJQUFJLFNBQVMsWUFDVCxPQUFPLEtBQUsscUJBQXFCLFdBQVcsR0FBRyxDQUFDO0VBR3BELE9BQU8sS0FBSztDQUNoQjtBQUNKO0FBRUEsTUFBTSxhQUFhO0FBQ25CLE1BQU0sY0FBYztBQUNwQixNQUFNLGtCQUFrQjs7Ozs7OztBQ25MeEIsSUFBcUIsY0FBckIsTUFBaUM7Q0FDN0IsY0FBYztFQUNWLEtBQUssT0FBTztFQUNaLEtBQUssWUFBWTtFQUNqQixLQUFLLFVBQVU7Q0FDbkI7Ozs7O0NBTUEsWUFBWTtFQUNSLElBQUksS0FBSyxPQUFPLEdBQ1osS0FBSyxhQUFhO0VBR3RCLE9BQU8sS0FBSztDQUNoQjs7Ozs7O0NBT0EsVUFBVSxHQUFHO0VBQ1QsT0FBTyxLQUFLLGFBQWEsSUFBSSxLQUFLLEtBQUssVUFBVTtDQUNyRDs7Ozs7Q0FNQSxRQUFRO0VBQ0osT0FBTyxJQUFJLEtBQUssWUFBWSxDQUFDLENBQUMsS0FBSyxJQUFJO0NBQzNDOzs7Ozs7Q0FPQSxLQUFLLFFBQVE7RUFDVCxLQUFLLE9BQU8sT0FBTztFQUNuQixLQUFLLFlBQVksT0FBTztFQUN4QixLQUFLLFVBQVUsT0FBTztFQUN0QixPQUFPO0NBQ1g7QUFDSjs7O0FDakRBLElBQWEsV0FBVztDQUNwQjtDQUE2QztDQUE0QztDQUN6RjtDQUE0QztDQUE2QztDQUN6RjtDQUE2QztDQUE0QztDQUN6RjtDQUE0QztDQUE2QztDQUN6RjtDQUE2QztDQUE0QztDQUN6RjtDQUE0QztDQUE2QztDQUN6RjtDQUE2QztDQUE0QztDQUN6RjtDQUE0QztDQUE2QztBQUM3RjtBQUdBLElBQWEsV0FBVztDQUNwQjtDQUE0QztDQUE0QztDQUN4RjtDQUE0QztDQUEyQztDQUN2RjtDQUE0QztDQUE0QztDQUN4RjtDQUE0QztDQUE0QztDQUN4RjtDQUEyQztDQUEyQztDQUN0RjtDQUE0QztDQUE0QztDQUN4RjtDQUE0QztDQUE0QztDQUN4RjtDQUE0QztDQUE0QztBQUM1Rjs7Ozs7O0FBT0EsSUFBYSxZQUFZLE1BQU8sSUFBSSxLQUFLLEtBQU07Ozs7OztBQU8vQyxJQUFhLGFBQWEsTUFBTyxNQUFNLElBQUssS0FBSztBQUVqRCxJQUFhLFNBQVMsS0FBSyxLQUFLLFFBQVEsS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJLEtBQUssR0FBRyxDQUFDOzs7Ozs7Ozs7O0FBWXhFLFNBQWdCLHVCQUF1QixLQUFLLE1BQU0sS0FBSyxLQUFLO0NBQ3hELE1BQU0sSUFBSSxLQUFLO0NBQ2YsTUFBTSxJQUFJLEtBQUs7Q0FDZixNQUFNLElBQUksS0FBSztDQUNmLE1BQU0sSUFBSSxJQUFJO0NBRWQsSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJO0NBQ3JCLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJO0NBQ3pCLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJO0NBQ3pCLElBQUksS0FBSztDQUNULElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJO0NBQ3pCLElBQUksS0FBSyxJQUFJLElBQUksSUFBSTtDQUNyQixJQUFJLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSTtDQUN6QixJQUFJLEtBQUs7Q0FDVCxJQUFJLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSTtDQUN6QixJQUFJLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSTtDQUN6QixJQUFJLE1BQU0sSUFBSSxJQUFJLElBQUk7Q0FDdEIsSUFBSSxNQUFNO0NBQ1YsSUFBSSxNQUFNO0NBQ1YsSUFBSSxNQUFNO0NBQ1YsSUFBSSxNQUFNO0NBQ1YsSUFBSSxNQUFNO0NBQ1YsT0FBTztBQUNYOzs7Ozs7Ozs7OztBQVlBLFNBQWdCLHFCQUFxQixPQUFPLE1BQU0sUUFBUSxVQUFVLE1BQU0sWUFBWSxRQUFRO0NBQzFGLE1BQU0sSUFBSSxLQUFLLElBQUksS0FBSztDQUN4QixNQUFNLElBQUksS0FBSyxJQUFJLEtBQUs7Q0FFeEIsTUFBTSxLQUFLLElBQUksS0FBSyxJQUFJLElBQUksT0FBTztDQUNuQyxNQUFNLEtBQUssSUFBSSxLQUFLLElBQUksSUFBSSxPQUFPO0NBQ25DLE1BQU0sS0FBSyxJQUFJLEtBQUssSUFBSSxJQUFJLE9BQU87Q0FFbkMsTUFBTSxLQUFLLElBQUksT0FBTyxJQUFJLElBQUksS0FBSztDQUNuQyxNQUFNLEtBQUssSUFBSSxPQUFPLElBQUksSUFBSSxLQUFLO0NBQ25DLE1BQU0sS0FBSyxJQUFJLE9BQU8sSUFBSSxJQUFJLEtBQUs7Q0FFbkMsUUFBUSxJQUFJLElBQUksSUFBSSxFQUFFO0NBQ3RCLFVBQVUsSUFBSSxJQUFJLElBQUksRUFBRTtBQUM1Qjs7O0FDaEdBLElBQU1DLDZCQUEyQixJQUFJLEtBQUs7QUFFMUMsU0FBUyxZQUFZLEdBQUcsSUFBSSxJQUFJLElBQUksSUFBSTtDQUNwQyxNQUFNLElBQUksSUFBSTtDQUVkLE9BQ0ssSUFBSSxJQUFJLElBQUksS0FDWixJQUFJLElBQUksSUFBSSxJQUFJLEtBQ2hCLElBQUksSUFBSSxJQUFJLElBQUksS0FDaEIsSUFBSSxJQUFJLElBQUk7QUFFckI7QUFFQSxTQUFTLGlCQUFpQixHQUFHLElBQUksSUFBSSxJQUFJLElBQUk7Q0FDekMsTUFBTSxJQUFJLElBQUk7Q0FFZCxPQUNLLElBQUksSUFBSSxLQUFLLEtBQUssTUFDbEIsSUFBSSxJQUFJLEtBQUssS0FBSyxNQUNsQixJQUFJLElBQUksS0FBSyxLQUFLO0FBRTNCO0FBRUEsSUFBcUIscUJBQXJCLGNBQWdELFlBQVk7Q0FDeEQsWUFBWSxJQUFJLElBQUksSUFBSSxJQUFJLFlBQVksR0FBRyxVQUFVLEdBQUc7RUFDcEQsTUFBTTtFQUNOLEtBQUssS0FBSztFQUNWLEtBQUssS0FBSztFQUNWLEtBQUssS0FBSztFQUNWLEtBQUssS0FBSztFQUVWLEtBQUssWUFBWTtFQUNqQixLQUFLLFVBQVU7RUFFZixLQUFLLE9BQU87Q0FDaEI7Ozs7Q0FLQSxlQUFlO0VBRVgsTUFBTSxJQUFJO0VBQ1YsTUFBTSxNQUFNLFNBQVM7RUFFckIsSUFBSSxNQUFNO0VBQ1YsS0FBSyxJQUFJLElBQUksR0FBRyxHQUFHLElBQUksS0FBSyxLQUFLO0dBQzdCLElBQUksSUFBSSxTQUFTLEtBQUs7R0FDdEIsT0FBTyxTQUFTLEtBQUssS0FBSyxnQkFBZ0IsR0FBR0EsVUFBUSxDQUFDLENBQUMsSUFBSTtFQUMvRDtFQUVBLEtBQUssT0FBTyxJQUFJO0NBQ3BCOzs7Ozs7O0NBUUEsV0FBVyxHQUFHLE1BQU0sSUFBSSxLQUFLLEdBQUc7RUFDNUIsSUFBSSxJQUFJLFlBQVksR0FBRyxLQUFLLEdBQUcsR0FBRyxLQUFLLEdBQUcsR0FBRyxLQUFLLEdBQUcsR0FBRyxLQUFLLEdBQUcsQ0FBQztFQUNqRSxJQUFJLElBQUksWUFBWSxHQUFHLEtBQUssR0FBRyxHQUFHLEtBQUssR0FBRyxHQUFHLEtBQUssR0FBRyxHQUFHLEtBQUssR0FBRyxDQUFDO0VBQ2pFLElBQUksSUFBSSxZQUFZLEdBQUcsS0FBSyxHQUFHLEdBQUcsS0FBSyxHQUFHLEdBQUcsS0FBSyxHQUFHLEdBQUcsS0FBSyxHQUFHLENBQUM7RUFDakUsT0FBTztDQUNYO0NBRUEsZ0JBQWdCLEdBQUcsTUFBTSxJQUFJLEtBQUssR0FBRztFQUNqQyxJQUFJLElBQUksaUJBQWlCLEdBQUcsS0FBSyxHQUFHLEdBQUcsS0FBSyxHQUFHLEdBQUcsS0FBSyxHQUFHLEdBQUcsS0FBSyxHQUFHLENBQUM7RUFDdEUsSUFBSSxJQUFJLGlCQUFpQixHQUFHLEtBQUssR0FBRyxHQUFHLEtBQUssR0FBRyxHQUFHLEtBQUssR0FBRyxHQUFHLEtBQUssR0FBRyxDQUFDO0VBQ3RFLElBQUksSUFBSSxpQkFBaUIsR0FBRyxLQUFLLEdBQUcsR0FBRyxLQUFLLEdBQUcsR0FBRyxLQUFLLEdBQUcsR0FBRyxLQUFLLEdBQUcsQ0FBQztFQUN0RSxPQUFPO0NBQ1g7Ozs7Ozs7Q0FRQSxhQUFhLEdBQUcsTUFBTSxJQUFJLEtBQUssR0FBRztFQUM5QixPQUFPLEtBQUssZ0JBQWdCLEdBQUcsR0FBRyxDQUFDLENBQUMsVUFBVTtDQUNsRDtDQUVBLFlBQVk7RUFDUixPQUFPLEtBQUs7Q0FDaEI7QUFDSjs7O0FDdkZBLElBQU1DLDZCQUEyQixJQUFJLEtBQUs7QUFFMUMsU0FBUyxnQkFBZ0IsR0FBRyxJQUFJLElBQUksSUFBSTtDQUNwQyxNQUFNLElBQUksSUFBSTtDQUNkLE9BQU8sSUFBSSxJQUFJLEtBQUssSUFBSSxJQUFJLElBQUksS0FBSyxJQUFJLElBQUk7QUFDakQ7QUFFQSxTQUFTLHFCQUFxQixHQUFHLElBQUksSUFBSSxJQUFJO0NBRXpDLE9BQU8sS0FERyxJQUFJLE1BQ0UsS0FBSyxNQUFNLElBQUksS0FBSyxLQUFLO0FBQzdDO0FBRUEsSUFBcUIseUJBQXJCLGNBQW9ELFlBQVk7Q0FDNUQsWUFBWSxJQUFJLElBQUksSUFBSSxZQUFZLEdBQUcsVUFBVSxHQUFHO0VBQ2hELE1BQU07RUFDTixLQUFLLEtBQUs7RUFDVixLQUFLLEtBQUs7RUFDVixLQUFLLEtBQUs7RUFFVixLQUFLLFlBQVk7RUFDakIsS0FBSyxVQUFVO0VBRWYsS0FBSyxPQUFPO0NBQ2hCOzs7O0NBS0EsZUFBZTtFQUVYLE1BQU0sSUFBSTtFQUNWLE1BQU0sTUFBTSxTQUFTO0VBRXJCLElBQUksTUFBTTtFQUNWLEtBQUssSUFBSSxJQUFJLEdBQUcsR0FBRyxJQUFJLEtBQUssS0FBSztHQUM3QixJQUFJLElBQUksU0FBUyxLQUFLO0dBQ3RCLE9BQU8sU0FBUyxLQUFLLEtBQUssZ0JBQWdCLEdBQUdBLFVBQVEsQ0FBQyxDQUFDLElBQUk7RUFDL0Q7RUFFQSxLQUFLLE9BQU8sSUFBSTtDQUNwQjs7Ozs7OztDQVFBLFdBQVcsR0FBRyxNQUFNLElBQUksS0FBSyxHQUFHO0VBQzVCLElBQUksSUFBSSxnQkFBZ0IsR0FBRyxLQUFLLEdBQUcsR0FBRyxLQUFLLEdBQUcsR0FBRyxLQUFLLEdBQUcsQ0FBQztFQUMxRCxJQUFJLElBQUksZ0JBQWdCLEdBQUcsS0FBSyxHQUFHLEdBQUcsS0FBSyxHQUFHLEdBQUcsS0FBSyxHQUFHLENBQUM7RUFDMUQsSUFBSSxJQUFJLGdCQUFnQixHQUFHLEtBQUssR0FBRyxHQUFHLEtBQUssR0FBRyxHQUFHLEtBQUssR0FBRyxDQUFDO0VBQzFELE9BQU87Q0FDWDtDQUVBLGdCQUFnQixHQUFHLE1BQU0sSUFBSSxLQUFLLEdBQUc7RUFDakMsSUFBSSxJQUFJLHFCQUFxQixHQUFHLEtBQUssR0FBRyxHQUFHLEtBQUssR0FBRyxHQUFHLEtBQUssR0FBRyxDQUFDO0VBQy9ELElBQUksSUFBSSxxQkFBcUIsR0FBRyxLQUFLLEdBQUcsR0FBRyxLQUFLLEdBQUcsR0FBRyxLQUFLLEdBQUcsQ0FBQztFQUMvRCxJQUFJLElBQUkscUJBQXFCLEdBQUcsS0FBSyxHQUFHLEdBQUcsS0FBSyxHQUFHLEdBQUcsS0FBSyxHQUFHLENBQUM7RUFDL0QsT0FBTztDQUNYOzs7Ozs7O0NBUUEsYUFBYSxHQUFHLE1BQU0sSUFBSSxLQUFLLEdBQUc7RUFDOUIsT0FBTyxLQUFLLGdCQUFnQixHQUFHLEdBQUcsQ0FBQyxDQUFDLFVBQVU7Q0FDbEQ7Q0FFQSxZQUFZO0VBQ1IsT0FBTyxLQUFLO0NBQ2hCO0FBQ0o7OztBQzNFQSxJQUFNQyw2QkFBMkIsSUFBSSxLQUFLO0FBRTFDLElBQXFCLGNBQXJCLGNBQXlDLFlBQVk7Q0FDakQsWUFBWSxJQUFJLElBQUksWUFBWSxHQUFHLFVBQVUsR0FBRztFQUM1QyxNQUFNO0VBQ04sS0FBSyxLQUFLO0VBQ1YsS0FBSyxLQUFLO0VBRVYsS0FBSyxZQUFZO0VBQ2pCLEtBQUssVUFBVTtFQUVmLEtBQUssT0FBTztDQUNoQjs7OztDQUtBLGVBQWU7RUFDWCxLQUFLLE9BQU9BLFdBQVMsSUFBSSxLQUFLLElBQUksS0FBSyxFQUFFLENBQUMsQ0FBQyxJQUFJO0NBQ25EOzs7Ozs7O0NBUUEsV0FBVyxHQUFHLE1BQU0sSUFBSSxLQUFLLEdBQUc7RUFDNUIsT0FBTSxLQUFLLEtBQUssSUFBSSxLQUFLLElBQUksQ0FBQztFQUM5QixPQUFPO0NBQ1g7Ozs7Ozs7Q0FRQSxhQUFhLEdBQUcsTUFBTSxJQUFJLEtBQUssR0FBRztFQUM5QixPQUFPLElBQUksSUFBSSxLQUFLLElBQUksS0FBSyxFQUFFLENBQUMsQ0FBQyxVQUFVO0NBQy9DO0NBRUEsWUFBWTtFQUNSLE9BQU8sS0FBSztDQUNoQjtBQUNKOzs7QUMxQ0EsSUFBTSwyQkFBMkIsSUFBSSxLQUFLO0FBQzFDLElBQU1DLDZCQUEyQixJQUFJLEtBQUs7QUFFMUMsU0FBUyxvQkFBb0IsVUFBVSxTQUFTO0NBQzVDLElBQUksS0FBSyxhQUFhLE1BQU0sTUFBTSxJQUFJLE1BQU0sT0FBTztBQUN2RDtBQUVBLElBQWEsT0FBYixNQUFrQjtDQUNkLGNBQWM7RUFDVixLQUFLLFlBQVksQ0FBQztFQUNsQixLQUFLLGlCQUFpQjtFQUN0QixLQUFLLGVBQWU7RUFDcEIsS0FBSyxhQUFhO0VBQ2xCLEtBQUssWUFBWTtFQUVqQixLQUFLLG1CQUFtQixvQkFBb0IsS0FBSyxNQUFNLGNBQWMsbUVBQW1FO0VBRXhJLEtBQUssZUFBZTtDQUN4QjtDQUVBLE9BQU8sR0FBRyxPQUFPLEdBQUc7RUFDaEIsS0FBSyxlQUFlO0VBQ3BCLEtBQUssYUFBYTtFQUNsQixLQUFLLFlBQVk7Q0FDckI7Q0FFQSxjQUFjLEtBQUssS0FBSyxHQUFHLE9BQU8sR0FBRztFQUNqQyxLQUFLLGlCQUFpQjtFQUN0QixNQUFNLE1BQU0sSUFBSSxtQkFBbUIsS0FBSyxZQUFZLEtBQUssS0FBSyxHQUFHLEtBQUssV0FBVyxJQUFJO0VBQ3JGLEtBQUssV0FBVyxHQUFHO0VBQ25CLE9BQU87Q0FDWDtDQUVBLGlCQUFpQixJQUFJLEdBQUcsT0FBTyxHQUFHO0VBQzlCLEtBQUssaUJBQWlCO0VBQ3RCLE1BQU0sTUFBTSxJQUFJLHVCQUF1QixLQUFLLFlBQVksSUFBSSxHQUFHLEtBQUssV0FBVyxJQUFJO0VBQ25GLEtBQUssV0FBVyxHQUFHO0VBQ25CLE9BQU87Q0FDWDtDQUVBLE9BQU8sR0FBRyxPQUFPLEdBQUc7RUFDaEIsS0FBSyxpQkFBaUI7RUFDdEIsTUFBTSxNQUFNLElBQUksWUFBWSxLQUFLLFlBQVksR0FBRyxLQUFLLFdBQVcsSUFBSTtFQUNwRSxLQUFLLFdBQVcsR0FBRztFQUNuQixPQUFPO0NBQ1g7Q0FFQSxXQUFXLFNBQVM7RUFDaEIsS0FBSyxlQUFlO0VBQ3BCLEtBQUssYUFBYSxRQUFRLFVBQVU7RUFDcEMsS0FBSyxZQUFZLFFBQVE7RUFDekIsS0FBSyxVQUFVLEtBQUssT0FBTztFQUMzQixPQUFPO0NBQ1g7Q0FFQSxjQUFjO0VBQ1YsT0FBTyxLQUFLO0NBQ2hCO0NBRUEsZUFBZTtFQUNYLE1BQU0sSUFBSSxLQUFLLFVBQVU7RUFDekIsS0FBSyxpQkFBaUIsSUFBSSxNQUFNLENBQUM7RUFFakMsSUFBSSxTQUFTO0VBQ2IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztHQUN4QixLQUFLLGVBQWUsS0FBSztHQUN6QixVQUFVLEtBQUssVUFBVSxFQUFFLENBQUMsVUFBVTtFQUMxQztFQUVBLEtBQUssZUFBZTtDQUN4QjtDQUVBLFlBQVk7RUFDUixJQUFJLEtBQUssZUFBZSxHQUNwQixLQUFLLGFBQWE7RUFHdEIsT0FBTyxLQUFLO0NBQ2hCOzs7Ozs7Q0FPQSx5QkFBeUIsS0FBSztFQUMxQixNQUFNLGNBQWMsS0FBSyxVQUFVO0VBRW5DLElBQUksT0FBTyxHQUNQLE9BQU8sQ0FBQyxHQUFHLENBQUM7RUFHaEIsSUFBSSxPQUFPLGFBQ1AsT0FBTyxDQUFDLEtBQUssVUFBVSxTQUFTLEdBQUcsQ0FBQztFQUd4QyxJQUFJLFFBQVE7RUFDWixJQUFJLE1BQU0sS0FBSyxlQUFlLFNBQVM7RUFDdkMsSUFBSSxRQUFRO0VBQ1osSUFBSTtFQUVKLE9BQU8sU0FBUyxLQUFLO0dBQ2pCLE1BQU0sS0FBSyxNQUFNLFFBQVEsT0FBTyxDQUFDO0dBRWpDLElBQUksUUFBUSxLQUFLLFFBQVEsS0FBSyxlQUFlLFNBQVMsS0FBTSxPQUFPLEtBQUssZUFBZSxRQUFRLE1BQU0sS0FBSyxlQUFlLE1BQU0sSUFBSztJQUNoSSxRQUFRO0lBQ1I7R0FDSixPQUFPLElBQUksTUFBTSxLQUFLLGVBQWUsTUFDakMsTUFBTSxNQUFNO1FBRVosUUFBUSxNQUFNO0VBRXRCO0VBR0EsTUFBTSxTQURNLEtBQUssVUFBVSxNQUNULENBQUMsVUFBVTtFQUM3QixNQUFNLEtBQUssTUFBTSxLQUFLLGVBQWUsVUFBVTtFQUUvQyxPQUFPLENBQUMsT0FBTyxDQUFDO0NBQ3BCO0NBRUEsaUJBQWlCLEtBQUssTUFBTSxJQUFJLEtBQUssR0FBRztFQUNwQyxNQUFNLENBQUMsR0FBRyxLQUFLLEtBQUsseUJBQXlCLEdBQUc7RUFDaEQsT0FBTyxLQUFLLFVBQVUsRUFBRSxDQUFDLFdBQVcsR0FBRyxHQUFHO0NBQzlDO0NBRUEsV0FBVyxHQUFHLE1BQU0sSUFBSSxLQUFLLEdBQUc7RUFDNUIsTUFBTSxjQUFjLEtBQUssVUFBVTtFQUNuQyxPQUFPLEtBQUssaUJBQWlCLElBQUksYUFBYSxHQUFHO0NBQ3JEO0NBRUEsbUJBQW1CLEtBQUssTUFBTSxJQUFJLEtBQUssR0FBRztFQUN0QyxNQUFNLENBQUMsR0FBRyxLQUFLLEtBQUsseUJBQXlCLEdBQUc7RUFDaEQsT0FBTyxLQUFLLFVBQVUsRUFBRSxDQUFDLGFBQWEsR0FBRyxHQUFHO0NBQ2hEO0NBRUEsYUFBYSxHQUFHLE1BQU0sSUFBSSxLQUFLLEdBQUc7RUFDOUIsTUFBTSxjQUFjLEtBQUssVUFBVTtFQUNuQyxPQUFPLEtBQUssbUJBQW1CLElBQUksYUFBYSxHQUFHO0NBQ3ZEO0NBRUEsZ0JBQWdCLEtBQUs7RUFDakIsTUFBTSxDQUFDLEdBQUcsS0FBSyxLQUFLLHlCQUF5QixHQUFHO0VBQ2hELE9BQU8sS0FBSyxVQUFVLEVBQUUsQ0FBQyxVQUFVLENBQUM7Q0FDeEM7Q0FFQSxVQUFVLEdBQUc7RUFDVCxNQUFNLGNBQWMsS0FBSyxVQUFVO0VBQ25DLE9BQU8sS0FBSyxnQkFBZ0IsSUFBSSxXQUFXO0NBQy9DOzs7Ozs7Q0FPQSxVQUFVLFlBQVksSUFBSTtFQUN0QixNQUFNLFNBQVMsSUFBSSxNQUFNLFlBQVksQ0FBQztFQUN0QyxLQUFLLElBQUksSUFBSSxHQUFHLEtBQUssV0FBVyxLQUM1QixPQUFPLEtBQUssS0FBSyxXQUFXLElBQUksU0FBUztFQUU3QyxPQUFPO0NBQ1g7Ozs7Ozs7Q0FRQSxvQkFBb0IsWUFBWSxJQUFJLFNBQVMsT0FBTztFQUNoRCxNQUFNLFdBQVcsSUFBSSxNQUFNLFlBQVksQ0FBQztFQUN4QyxNQUFNLFFBQVEsSUFBSSxNQUFNLFlBQVksQ0FBQztFQUVyQyxNQUFNLGVBQWUsS0FBSyxrQkFBa0IsTUFBTTtFQUdsRCxNQUFNLGNBQWMsS0FBSyxVQUFVO0VBQ25DLEtBQUssSUFBSSxJQUFJLEdBQUcsS0FBSyxXQUFXLEtBQUs7R0FDakMsTUFBTSxDQUFDLElBQUksTUFBTSxLQUFLLHlCQUEwQixjQUFjLElBQUssU0FBUztHQUM1RSxNQUFNLFVBQVUsS0FBSyxVQUFVO0dBQy9CLFNBQVMsS0FBSyxRQUFRLGFBQWEsRUFBRTtHQUNyQyxNQUFNLEtBQUssYUFBYSxRQUFRLFVBQVUsRUFBRSxHQUFHLElBQUksV0FBVyxJQUFJO0VBQ3RFO0VBRUEsTUFBTSxLQUFLLEtBQUssSUFBSSxTQUFTLEVBQUUsQ0FBQyxDQUFDO0VBQ2pDLE1BQU0sS0FBSyxLQUFLLElBQUksU0FBUyxFQUFFLENBQUMsQ0FBQztFQUNqQyxNQUFNLEtBQUssS0FBSyxJQUFJLFNBQVMsRUFBRSxDQUFDLENBQUM7RUFFakMsTUFBTSxTQUFTLElBQUksS0FBSztFQUN4QixJQUFJLEtBQUssTUFBTSxLQUFLLElBQ2hCLE9BQU8sSUFBSSxHQUFHLEdBQUcsQ0FBQztPQUNmLElBQUksS0FBSyxNQUFNLEtBQUssSUFDdkIsT0FBTyxJQUFJLEdBQUcsR0FBRyxDQUFDO09BRWxCLE9BQU8sSUFBSSxHQUFHLEdBQUcsQ0FBQztFQUt0QixNQUFNLFVBQVUsSUFBSSxNQUFNLFlBQVksQ0FBQztFQUN2QyxNQUFNLFlBQVksSUFBSSxNQUFNLFlBQVksQ0FBQztFQUN6QyxRQUFRLEtBQUssSUFBSSxLQUFLO0VBQ3RCLFVBQVUsS0FBSyxJQUFJLEtBQUs7RUFFeEIsU0FBUyxNQUFNLFNBQVMsSUFBSSxNQUFNLENBQUMsQ0FBQyxVQUFVO0VBQzlDLFFBQVEsRUFBRSxDQUFDLE1BQU0sU0FBUyxJQUFJLFFBQVE7RUFDdEMsVUFBVSxFQUFFLENBQUMsTUFBTSxTQUFTLElBQUksUUFBUSxFQUFFO0VBRzFDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSztHQUN0QyxRQUFRLEtBQUssUUFBUSxJQUFJLEVBQUUsQ0FBQyxNQUFNO0dBQ2xDLFVBQVUsS0FBSyxJQUFJLEtBQUs7R0FFeEIsU0FBUyxNQUFNLFNBQVMsSUFBSSxJQUFJLFNBQVMsRUFBRTtHQUMzQyxNQUFNLFdBQVcsU0FBUyxJQUFJO0dBRTlCLElBQUksV0FBVyxPQUFPLFNBQVM7SUFDM0IsU0FBUyxNQUFNLElBQUksUUFBUTtJQUMzQixNQUFNLFdBQVcsTUFBTSxTQUFTLElBQUksRUFBRSxDQUFDLElBQUksU0FBUyxFQUFFLEdBQUcsSUFBSSxDQUFDO0lBRzlELHVCQUF1QkEsWUFBVSxVQUZoQixNQUFNLFVBQVUsSUFBSSxDQUVNLEdBQVUsUUFBUTtJQUM3RCxRQUFRLEVBQUUsQ0FBQyxhQUFhQSxVQUFRO0dBQ3BDO0dBRUEsVUFBVSxFQUFFLENBQUMsTUFBTSxTQUFTLElBQUksUUFBUSxFQUFFO0VBQzlDO0VBR0EsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUM5QixxQkFBcUIsU0FBUyxNQUFNLEVBQUUsR0FBRyxRQUFRLElBQUksVUFBVSxFQUFFO0VBSXJFLElBQUksV0FBVyxNQUFNO0dBQ2pCLE1BQU0sYUFBYSxRQUFRLFFBQVEsU0FBUztHQUM1QyxJQUFJLE9BQU8sS0FBSyxLQUFLLE1BQU0sUUFBUSxFQUFFLENBQUMsSUFBSSxVQUFVLEdBQUcsSUFBSSxDQUFDLENBQUMsS0FBSyxRQUFRLFNBQVM7R0FFbkYsSUFBSSxTQUFTLEVBQUUsQ0FBQyxJQUFJLFNBQVMsTUFBTSxRQUFRLElBQUksVUFBVSxDQUFDLElBQUksR0FDMUQsT0FBTyxDQUFDO0dBR1osS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsU0FBUyxHQUFHLEtBQUs7SUFDekMsTUFBTSxRQUFRLE9BQU87SUFDckIscUJBQXFCLE9BQU8sUUFBUSxJQUFJLFVBQVUsRUFBRTtJQUNwRCxNQUFNLE1BQU0sVUFBVSxLQUFLO0dBQy9CO0dBRUEsUUFBUSxRQUFRLFNBQVMsS0FBSyxRQUFRLEVBQUUsQ0FBQyxNQUFNO0dBQy9DLFVBQVUsVUFBVSxTQUFTLEtBQUssVUFBVSxFQUFFLENBQUMsTUFBTTtFQUN6RDtFQUVBLE9BQU87R0FBRTtHQUFVO0dBQVM7R0FBVztFQUFNO0NBQ2pEO0FBQ0o7OztBQ2pRQSxJQUFNQywyQkFBeUIsSUFBSSxLQUFLO0FBQ3hDLElBQU0seUJBQXlCLElBQUksS0FBSztBQUN4QyxJQUFNLHFCQUFxQixJQUFJLEtBQUs7QUFDcEMsSUFBTSx3QkFBd0IsSUFBSSxLQUFLO0FBRXZDLElBQWEsT0FBYixjQUEwQixTQUFTO0NBQy9CLFlBQVksSUFBSSxFQUFFLE1BQU0sU0FBUyxHQUFHLGtCQUFrQixJQUFJLGlCQUFpQixHQUFHLFNBQVMsT0FBTyxhQUFhLENBQUMsTUFBTSxDQUFDLEdBQUc7RUFDbEgsTUFBTSxJQUFJLFVBQVU7RUFFcEIsS0FBSyxPQUFPO0VBQ1osS0FBSyxTQUFTO0VBQ2QsS0FBSyxrQkFBa0I7RUFDdkIsS0FBSyxpQkFBaUI7RUFDdEIsS0FBSyxTQUFTO0VBRWQsS0FBSyxlQUFlLEtBQUssb0JBQW9CLGlCQUFpQixNQUFNO0VBRXBFLE1BQU0sZUFBZSxrQkFBa0IsTUFBTSxpQkFBaUI7RUFDOUQsTUFBTSxhQUFhLGtCQUFrQixpQkFBaUI7RUFDdEQsS0FBSyxZQUFZLElBQUksYUFBYSxjQUFjLENBQUM7RUFDakQsS0FBSyxVQUFVLElBQUksYUFBYSxjQUFjLENBQUM7RUFDL0MsS0FBSyxNQUFNLElBQUksYUFBYSxjQUFjLENBQUM7RUFDM0MsS0FBSyxVQUFVLGNBQWMsUUFBUSxJQUFJLFlBQVksVUFBVSxJQUFJLElBQUksWUFBWSxVQUFVO0VBRzdGLEtBQUssb0JBQW9CO0VBQ3pCLEtBQUssaUJBQWlCO0VBRXRCLEtBQUssYUFBYSxZQUFZO0dBQUUsTUFBTTtHQUFHLE1BQU0sS0FBSztFQUFVLENBQUM7RUFDL0QsS0FBSyxhQUFhLFVBQVU7R0FBRSxNQUFNO0dBQUcsTUFBTSxLQUFLO0VBQVEsQ0FBQztFQUMzRCxLQUFLLGFBQWEsTUFBTTtHQUFFLE1BQU07R0FBRyxNQUFNLEtBQUs7RUFBSSxDQUFDO0VBQ25ELEtBQUssU0FBUyxFQUFFLE1BQU0sS0FBSyxRQUFRLENBQUM7Q0FDeEM7Q0FFQSxzQkFBc0I7RUFDbEIsS0FBSyxJQUFJLElBQUksR0FBRyxLQUFLLEtBQUssaUJBQWlCLEtBQUs7R0FDNUMsSUFBSSxLQUFLO0dBQ1QsSUFBSSxNQUFNLEtBQUssaUJBSVgsS0FBSyxLQUFLLFNBQVMsSUFBSSxLQUFLO0dBR2hDLEtBQUssS0FBSyxXQUFXLEtBQUssS0FBSyxpQkFBaUIsS0FBSztHQUVyRCxNQUFNLElBQUksS0FBSyxhQUFhLFFBQVE7R0FDcEMsTUFBTSxJQUFJLEtBQUssYUFBYSxVQUFVO0dBR3RDLEtBQUssSUFBSSxJQUFJLEdBQUcsS0FBSyxLQUFLLGdCQUFnQixLQUFLO0lBQzNDLE1BQU0sSUFBSyxJQUFJLEtBQUssaUJBQWtCLEtBQUssS0FBSztJQUNoRCxNQUFNLE1BQU0sS0FBSyxJQUFJLENBQUM7SUFDdEIsTUFBTSxNQUFNLENBQUMsS0FBSyxJQUFJLENBQUM7SUFFdkIsTUFBTSxNQUFNLEtBQUssS0FBSyxpQkFBaUIsS0FBSztJQUc1QyxPQUFPLElBQUksTUFBTSxFQUFFLElBQUksTUFBTSxFQUFFO0lBQy9CLE9BQU8sSUFBSSxNQUFNLEVBQUUsSUFBSSxNQUFNLEVBQUU7SUFDL0IsT0FBTyxJQUFJLE1BQU0sRUFBRSxJQUFJLE1BQU0sRUFBRTtJQUUvQixLQUFLLFFBQVEsSUFBSSxRQUFRLE1BQU0sQ0FBQztJQUdoQyxTQUFPLElBQUksTUFBTSxJQUFJLEtBQUssU0FBUyxPQUFPO0lBQzFDLFNBQU8sSUFBSSxNQUFNLElBQUksS0FBSyxTQUFTLE9BQU87SUFDMUMsU0FBTyxJQUFJLE1BQU0sSUFBSSxLQUFLLFNBQVMsT0FBTztJQUMxQyxLQUFLLFVBQVUsSUFBSUEsVUFBUSxNQUFNLENBQUM7SUFHbEMsR0FBRyxJQUFJLElBQUksS0FBSztJQUNoQixHQUFHLElBQUksSUFBSSxLQUFLO0lBQ2hCLEtBQUssSUFBSSxJQUFJLElBQUksTUFBTSxDQUFDO0dBQzVCO0VBQ0o7Q0FDSjtDQUVBLG1CQUFtQjtFQUNmLEtBQUssSUFBSSxJQUFJLEdBQUcsS0FBSyxLQUFLLGlCQUFpQixLQUN2QyxLQUFLLElBQUksSUFBSSxHQUFHLEtBQUssS0FBSyxnQkFBZ0IsS0FBSztHQUMzQyxNQUFNLEtBQUssS0FBSyxpQkFBaUIsTUFBTSxJQUFJLE1BQU0sSUFBSTtHQUNyRCxNQUFNLEtBQUssS0FBSyxpQkFBaUIsS0FBSyxLQUFLLElBQUk7R0FDL0MsTUFBTSxLQUFLLEtBQUssaUJBQWlCLEtBQUssSUFBSTtHQUMxQyxNQUFNLEtBQUssS0FBSyxpQkFBaUIsTUFBTSxJQUFJLEtBQUs7R0FFaEQsTUFBTSxPQUFPLElBQUksS0FBSyxLQUFLLGtCQUFrQixJQUFJO0dBQ2pELEtBQUssUUFBUSxJQUFJO0lBQUM7SUFBRztJQUFHO0lBQUc7SUFBRztJQUFHO0dBQUMsR0FBRyxNQUFNLENBQUM7RUFDaEQ7Q0FFUjtBQUNKOzs7QUMzRkEsSUFBYSxPQUFiLE1BQWtCO0NBQ2QsWUFDSSxJQUNBLEVBQ0ksT0FDQSxRQUNBLEtBQ0EsUUFBUSxHQUFHLGVBQ1gsUUFBUSxHQUFHLGVBQ1gsWUFBWSxHQUFHLFFBQ2YsWUFBWSxHQUFHLFFBQ2YsV0FBVyxJQUFJLFNBQVMsRUFBRSxHQUMxQixhQUFhLE1BQ2IsUUFBUSxTQUNSLENBQUMsR0FDUDtFQUNFLEtBQUssS0FBSztFQUVWLEtBQUssU0FBUyxDQUFDO0VBRWYsS0FBSyxXQUFXO0VBRWhCLEtBQUssVUFBVSxFQUFFLE9BQU8sS0FBSztFQUM3QixLQUFLLGFBQWE7RUFFbEIsSUFBSSxLQUFLLEtBQUssTUFBTTtFQUNwQixJQUFJLE9BQU8sS0FBSyxRQUFRO0VBQ3hCLElBQUksUUFBUSxLQUFLLFNBQVM7RUFFMUIsTUFBTSxLQUFLLE9BQU8sS0FBSyxHQUFHLFNBQVM7RUFDbkMsS0FBSyxrQkFBa0IsS0FBSyxNQUFNLEtBQUssU0FBUyxLQUFLLEdBQUcsU0FBUyxRQUFRLEdBQUc7RUFDNUUsS0FBSyxtQkFBbUIsS0FBSyxNQUFNLEtBQUssVUFBVSxLQUFLLEdBQUcsU0FBUyxTQUFTLEdBQUc7RUFFL0UsSUFBSSxVQUFVO0dBQ1YsS0FBSyxLQUFLO0dBQ1YsT0FBTyxLQUFLO0dBQ1osUUFBUSxLQUFLO0dBQ2I7R0FDQTtHQUNBO0dBQ0E7R0FDQTtFQUNKO0VBRUEsTUFBTSxNQUFPLEtBQUssTUFBTTtHQUNwQixNQUFNLElBQUksYUFBYSxLQUFLLElBQUksT0FBTztHQUN2QyxPQUFPLElBQUksYUFBYSxLQUFLLElBQUksT0FBTztHQUN4QyxZQUFZO0lBQ1IsSUFBSSxPQUFPLElBQUk7SUFDZixJQUFJLE9BQU8sSUFBSTtJQUNmLElBQUksUUFBUTtHQUNoQjtFQUNKO0NBQ0o7Q0FFQSxRQUFRLEVBQUUsU0FBU0MsaUJBQWUsV0FBV0MsbUJBQWlCLFdBQVcsQ0FBQyxHQUFHLGlCQUFpQixRQUFRLFVBQVUsU0FBUyxDQUFDLEdBQUc7RUFDekgsU0FBUyxrQkFBa0IsRUFBRSxPQUFPLEtBQUssSUFBSSxLQUFLLFFBQVE7RUFFMUQsTUFBTSxVQUFVLElBQUksUUFBUSxLQUFLLElBQUk7R0FBRTtHQUFRO0dBQVU7RUFBUyxDQUFDO0VBR25FLE1BQU0sT0FBTztHQUNULE1BQUEsSUFIYSxLQUFLLEtBQUssSUFBSTtJQUFFLFVBQVUsS0FBSztJQUFVO0dBQVEsQ0FHM0Q7R0FDSDtHQUNBO0dBQ0E7R0FDQTtFQUNKO0VBRUEsS0FBSyxPQUFPLEtBQUssSUFBSTtFQUNyQixPQUFPO0NBQ1g7Q0FFQSxPQUFPLEVBQUUsT0FBTyxRQUFRLFFBQVEsQ0FBQyxHQUFHO0VBQ2hDLElBQUksS0FBSyxLQUFLLE1BQU07RUFDcEIsSUFBSSxPQUFPLEtBQUssUUFBUTtFQUN4QixJQUFJLFFBQVEsS0FBSyxTQUFTO0VBRTFCLE1BQU0sS0FBSyxPQUFPLEtBQUssR0FBRyxTQUFTO0VBQ25DLEtBQUssa0JBQWtCLEtBQUssTUFBTSxLQUFLLFNBQVMsS0FBSyxHQUFHLFNBQVMsUUFBUSxHQUFHO0VBQzVFLEtBQUssbUJBQW1CLEtBQUssTUFBTSxLQUFLLFVBQVUsS0FBSyxHQUFHLFNBQVMsU0FBUyxHQUFHO0VBRS9FLEtBQUssSUFBSSxLQUFLLFFBQVEsS0FBSyxpQkFBaUIsS0FBSyxnQkFBZ0I7RUFDakUsS0FBSyxJQUFJLE1BQU0sUUFBUSxLQUFLLGlCQUFpQixLQUFLLGdCQUFnQjtDQUN0RTtDQUdBLE9BQU8sRUFBRSxPQUFPLFFBQVEsU0FBUyxTQUFTLE1BQU0sU0FBUyxNQUFNLE9BQU8sTUFBTSxjQUFjLE1BQU0sdUJBQXVCO0VBQ25ILE1BQU0sZ0JBQWdCLEtBQUssT0FBTyxRQUFRLFNBQVMsS0FBSyxPQUFPO0VBRS9ELElBQUksQ0FBQyxTQUFTO0dBQ1YsS0FBSyxHQUFHLFNBQVMsT0FBTztJQUNwQjtJQUNBO0lBQ0EsUUFBUSxjQUFjLFVBQVcsQ0FBQyxVQUFVLEtBQUssYUFBYyxLQUFLLElBQUksUUFBUTtJQUNoRjtJQUNBO0lBQ0E7R0FDSixDQUFDO0dBQ0QsS0FBSyxJQUFJLEtBQUs7R0FHZCxJQUFJLHFCQUFxQixvQkFBb0IsU0FBUyxNQUFNLEtBQUssRUFBRSxDQUFDO0VBQ3hFO0VBRUEsY0FBYyxTQUFTLE1BQU0sTUFBTTtHQUMvQixLQUFLLEtBQUssUUFBUSxTQUFTLEtBQUssZUFBZSxDQUFDLFFBQVEsQ0FBQyxLQUFLLFVBQVUsVUFBVSxLQUFLLElBQUksS0FBSztHQUNoRyxLQUFLLEdBQUcsU0FBUyxPQUFPO0lBQ3BCLE9BQU8sS0FBSztJQUNaLFFBQVEsTUFBTSxjQUFjLFNBQVMsTUFBTSxVQUFVLENBQUMsS0FBSyxjQUFjLFNBQVMsS0FBSyxJQUFJO0lBQzNGLE9BQU87R0FDWCxDQUFDO0dBQ0QsS0FBSyxJQUFJLEtBQUs7RUFDbEIsQ0FBQztFQUVELEtBQUssUUFBUSxRQUFRLEtBQUssSUFBSSxLQUFLO0NBQ3ZDO0FBQ0o7QUFFQSxJQUFNRCxrQkFBMkI7Ozs7Ozs7Ozs7O0FBWWpDLElBQU1DLG9CQUE2Qjs7Ozs7Ozs7Ozs7O0FDckluQyxJQUFNLDBCQUEwQixJQUFJLEtBQUs7QUFDekMsSUFBTSwwQkFBMEIsSUFBSSxLQUFLO0FBQ3pDLElBQU0sMEJBQTBCLElBQUksS0FBSztBQUV6QyxJQUFNLDBCQUEwQixJQUFJLEtBQUs7QUFDekMsSUFBTSwwQkFBMEIsSUFBSSxLQUFLO0FBQ3pDLElBQU0sMEJBQTBCLElBQUksS0FBSztBQUV6QyxJQUFhLFlBQWIsTUFBdUI7Q0FDbkIsWUFBWSxFQUFFLFNBQVMsUUFBUTtFQUMzQixLQUFLLFVBQVU7RUFDZixLQUFLLE9BQU87RUFDWixLQUFLLFVBQVU7RUFDZixLQUFLLFNBQVM7RUFDZCxLQUFLLFdBQVcsS0FBSyxPQUFPLFNBQVM7Q0FDekM7Q0FFQSxPQUFPLGNBQWMsR0FBRyxPQUFPO0VBQzNCLE1BQU0sU0FBUyxRQUFRLElBQUksS0FBSyxTQUFTO0VBQ3pDLE1BQU0sVUFBVSxLQUFLLFVBQVUsS0FBSztFQUVwQyxNQUFNLGFBQWEsS0FBSyxNQUFNLE9BQU87RUFDckMsTUFBTSxRQUFRLFVBQVU7RUFDeEIsTUFBTSxVQUFVLEtBQUssS0FBSyxPQUFPO0VBQ2pDLE1BQU0sVUFBVSxLQUFLLEtBQUssUUFBUSxhQUFhLEtBQUssS0FBSztFQUV6RCxLQUFLLFFBQVEsU0FBUyxRQUFRLE1BQU07R0FDaEMsUUFBUSxVQUFVLFFBQVEsVUFBVSxJQUFJLENBQUM7R0FDekMsUUFBUSxVQUFVLFFBQVEsWUFBWSxJQUFJLENBQUM7R0FDM0MsUUFBUSxVQUFVLFFBQVEsT0FBTyxJQUFJLENBQUM7R0FFdEMsUUFBUSxVQUFVLFFBQVEsVUFBVSxJQUFJLENBQUM7R0FDekMsUUFBUSxVQUFVLFFBQVEsWUFBWSxJQUFJLENBQUM7R0FDM0MsUUFBUSxVQUFVLFFBQVEsT0FBTyxJQUFJLENBQUM7R0FFdEMsUUFBUSxLQUFLLFNBQVMsS0FBSztHQUMzQixRQUFRLE1BQU0sU0FBUyxLQUFLO0dBQzVCLFFBQVEsS0FBSyxTQUFTLEtBQUs7R0FFM0IsT0FBTyxTQUFTLEtBQUssU0FBUyxNQUFNO0dBQ3BDLE9BQU8sV0FBVyxNQUFNLFNBQVMsTUFBTTtHQUN2QyxPQUFPLE1BQU0sS0FBSyxTQUFTLE1BQU07RUFDckMsQ0FBQztDQUNMO0FBQ0o7OztBQ3pDQSxJQUFNQyw2QkFBMkIsSUFBSSxLQUFLO0FBRTFDLElBQWEsT0FBYixjQUEwQixLQUFLO0NBQzNCLFlBQVksSUFBSSxFQUFFLEtBQUssVUFBVSxTQUFTLE9BQU8sR0FBRyxjQUFjLENBQUMsR0FBRztFQUNsRSxNQUFNLElBQUk7R0FBRTtHQUFVO0dBQVM7RUFBSyxDQUFDO0VBRXJDLEtBQUssWUFBWSxHQUFHO0VBQ3BCLEtBQUssa0JBQWtCO0VBQ3ZCLEtBQUssYUFBYSxDQUFDO0VBRW5CLE9BQU8sT0FBTyxLQUFLLFFBQVEsVUFBVTtHQUNqQyxhQUFhLEVBQUUsT0FBTyxLQUFLLFlBQVk7R0FDdkMsaUJBQWlCLEVBQUUsT0FBTyxLQUFLLGdCQUFnQjtFQUNuRCxDQUFDO0NBQ0w7Q0FFQSxZQUFZLEtBQUs7RUFFYixLQUFLLE9BQU8sSUFBSSxVQUFVO0VBRzFCLEtBQUssUUFBUSxDQUFDO0VBQ2QsSUFBSSxDQUFDLElBQUksU0FBUyxDQUFDLElBQUksTUFBTSxRQUFRO0VBQ3JDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLE1BQU0sUUFBUSxLQUFLO0dBQ3ZDLE1BQU0sT0FBTyxJQUFJLFVBQVU7R0FHM0IsS0FBSyxTQUFTLFVBQVUsSUFBSSxTQUFTLFVBQVUsSUFBSSxDQUFDO0dBQ3BELEtBQUssV0FBVyxVQUFVLElBQUksU0FBUyxZQUFZLElBQUksQ0FBQztHQUN4RCxLQUFLLE1BQU0sVUFBVSxJQUFJLFNBQVMsT0FBTyxJQUFJLENBQUM7R0FFOUMsS0FBSyxNQUFNLEtBQUssSUFBSTtFQUN4QjtFQUdBLElBQUksTUFBTSxTQUFTLE1BQU0sTUFBTTtHQUMzQixLQUFLLE1BQU0sRUFBRSxDQUFDLE9BQU8sS0FBSztHQUMxQixJQUFJLEtBQUssV0FBVyxJQUFJLE9BQU8sS0FBSyxNQUFNLEVBQUUsQ0FBQyxVQUFVLEtBQUssSUFBSTtHQUNoRSxLQUFLLE1BQU0sRUFBRSxDQUFDLFVBQVUsS0FBSyxNQUFNLEtBQUssT0FBTztFQUNuRCxDQUFDO0VBR0QsS0FBSyxLQUFLLGtCQUFrQixJQUFJO0VBR2hDLEtBQUssTUFBTSxTQUFTLFNBQVM7R0FDekIsS0FBSyxjQUFjLElBQUksS0FBSyxHQUFHLEtBQUssV0FBVyxDQUFDLENBQUMsUUFBUTtFQUM3RCxDQUFDO0NBQ0w7Q0FFQSxvQkFBb0I7RUFDaEIsSUFBSSxDQUFDLEtBQUssTUFBTSxRQUFRO0VBQ3hCLE1BQU0sT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksR0FBRyxLQUFLLEtBQUssS0FBSyxJQUFJLEtBQUssS0FBSyxLQUFLLE1BQU0sU0FBUyxDQUFDLENBQUMsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO0VBQ3RHLEtBQUssZUFBZSxJQUFJLGFBQWEsT0FBTyxPQUFPLENBQUM7RUFDcEQsS0FBSyxrQkFBa0I7RUFDdkIsS0FBSyxjQUFjLElBQUksUUFBUSxLQUFLLElBQUk7R0FDcEMsT0FBTyxLQUFLO0dBQ1osaUJBQWlCO0dBQ2pCLE1BQU0sS0FBSyxHQUFHO0dBQ2QsZ0JBQWdCLEtBQUssR0FBRyxTQUFTLFdBQVcsS0FBSyxHQUFHLFVBQVUsS0FBSyxHQUFHO0dBQ3RFLFdBQVcsS0FBSyxHQUFHO0dBQ25CLFdBQVcsS0FBSyxHQUFHO0dBQ25CLE9BQU87R0FDUCxPQUFPO0VBQ1gsQ0FBQztDQUNMO0NBRUEsYUFBYSxNQUFNO0VBQ2YsTUFBTSxZQUFZLElBQUksVUFBVTtHQUFFLFNBQVMsS0FBSztHQUFPO0VBQUssQ0FBQztFQUM3RCxLQUFLLFdBQVcsS0FBSyxTQUFTO0VBQzlCLE9BQU87Q0FDWDtDQUVBLFNBQVM7RUFFTCxJQUFJLFFBQVE7RUFDWixLQUFLLFdBQVcsU0FBUyxjQUFlLFNBQVMsVUFBVSxNQUFPO0VBRWxFLEtBQUssV0FBVyxTQUFTLFdBQVcsTUFBTTtHQUV0QyxVQUFVLE9BQU8sT0FBTyxNQUFNLENBQUM7RUFDbkMsQ0FBQztDQUNMO0NBRUEsS0FBSyxFQUFFLFdBQVcsQ0FBQyxHQUFHO0VBRWxCLEtBQUssS0FBSyxrQkFBa0IsSUFBSTtFQUdoQyxLQUFLLE1BQU0sU0FBUyxNQUFNLE1BQU07R0FFNUIsV0FBUyxTQUFTLEtBQUssYUFBYSxLQUFLLFdBQVc7R0FDcEQsS0FBSyxhQUFhLElBQUlBLFlBQVUsSUFBSSxFQUFFO0VBQzFDLENBQUM7RUFDRCxJQUFJLEtBQUssYUFBYSxLQUFLLFlBQVksY0FBYztFQUVyRCxNQUFNLEtBQUssRUFBRSxPQUFPLENBQUM7Q0FDekI7QUFDSjs7O0FDeEdBLFNBQWdCLEtBQUssRUFDakIsTUFDQSxNQUNBLFFBQVEsVUFDUixRQUFRLFFBQ1IsT0FBTyxHQUNQLGdCQUFnQixHQUNoQixhQUFhLEtBQ2IsY0FBYyxHQUNkLFlBQVksU0FDYjtDQUNDLE1BQU0sUUFBUTtDQUNkLElBQUksUUFBUSxTQUNJLFVBQVU7Q0FFMUIsTUFBTSxVQUFVO0NBQ2hCLE1BQU0sYUFBYTtDQUdmLFVBQVU7Q0FDVixlQUFlO0NBR25CLFNBQVMsWUFBWTtFQUNqQixTQUFTLENBQUM7RUFDVixLQUFLLE1BQU0sU0FBUyxNQUFPLE9BQU8sRUFBRSxRQUFRLENBQUU7Q0FDbEQ7Q0FFQSxTQUFTLGlCQUFpQjtFQUN0QixLQUFrQixPQUFPO0VBQ3pCLFdBQVcsS0FBSyxPQUFPO0VBR3ZCLFFBQVEsT0FBTztFQUlmLElBQUksV0FEUSxLQUFLLFFBQVEsVUFBVSxFQUNoQixDQUFDLENBQUM7RUFHckIsVUFBVTtHQUNOLFVBQVUsSUFBSSxhQUFhLFdBQVcsSUFBSSxDQUFDO0dBQzNDLElBQUksSUFBSSxhQUFhLFdBQVcsSUFBSSxDQUFDO0dBQ3JDLElBQUksSUFBSSxhQUFhLFdBQVcsQ0FBQztHQUNqQyxPQUFPLElBQUksWUFBWSxXQUFXLENBQUM7RUFDdkM7RUFHQSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksVUFBVSxLQUFLO0dBQy9CLFFBQVEsR0FBRyxJQUFJO0lBQUM7SUFBRztJQUFHO0lBQUc7R0FBQyxHQUFHLElBQUksQ0FBQztHQUNsQyxRQUFRLE1BQU0sSUFBSTtJQUFDLElBQUk7SUFBRyxJQUFJLElBQUk7SUFBRyxJQUFJLElBQUk7SUFBRyxJQUFJLElBQUk7SUFBRyxJQUFJLElBQUk7SUFBRyxJQUFJLElBQUk7R0FBQyxHQUFHLElBQUksQ0FBQztFQUMzRjtFQUVBLE9BQU87Q0FDWDtDQUVBLFNBQVMsU0FBUztFQUNkLE1BQU0sUUFBUSxDQUFDO0VBRWYsSUFBSSxTQUFTO0VBRWIsSUFBSSxhQUFhO0VBQ2pCLElBQUksWUFBWTtFQUNoQixJQUFJLE9BQU8sUUFBUTtFQUVuQixTQUFTLFVBQVU7R0FDZixNQUFNLE9BQU87SUFDVCxPQUFPO0lBQ1AsUUFBUSxDQUFDO0dBQ2I7R0FDQSxNQUFNLEtBQUssSUFBSTtHQUNmLGFBQWE7R0FDYixZQUFZO0dBQ1osT0FBTztFQUNYO0VBRUEsSUFBSSxXQUFXO0VBQ2YsSUFBSSxRQUFRO0VBQ1osT0FBTyxTQUFTLEtBQUssVUFBVSxRQUFRLFVBQVU7R0FDN0M7R0FFQSxNQUFNLE9BQU8sS0FBSztHQUdsQixJQUFJLENBQUMsS0FBSyxTQUFTLFdBQVcsS0FBSyxJQUFJLEdBQUc7SUFDdEM7SUFDQSxhQUFhO0lBQ2IsWUFBWTtJQUNaO0dBQ0o7R0FHQSxJQUFJLFFBQVEsS0FBSyxJQUFJLEdBQUc7SUFDcEI7SUFDQSxPQUFPLFFBQVE7SUFDZjtHQUNKO0dBRUEsTUFBTSxRQUFRLE9BQU8sU0FBUyxPQUFPO0dBR3JDLElBQUksS0FBSyxPQUFPLFFBQVE7SUFDcEIsTUFBTSxZQUFZLEtBQUssT0FBTyxLQUFLLE9BQU8sU0FBUyxFQUFFLENBQUM7SUFDdEQsSUFBSSxPQUFPLGtCQUFrQixNQUFNLElBQUksVUFBVSxFQUFFLElBQUk7SUFDdkQsS0FBSyxTQUFTO0lBQ2QsYUFBYTtHQUNqQjtHQUdBLEtBQUssT0FBTyxLQUFLLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQztHQUdwQyxJQUFJLFVBQVU7R0FHZCxJQUFJLFdBQVcsS0FBSyxJQUFJLEdBQUc7SUFDdkIsYUFBYTtJQUNiLFlBQVk7SUFHWixXQUFXLGNBQWM7R0FDN0IsT0FFSSxXQUFXLGdCQUFnQjtHQUcvQixXQUFXLE1BQU0sV0FBVztHQUU1QixLQUFLLFNBQVM7R0FDZCxhQUFhO0dBR2IsSUFBSSxLQUFLLFFBQVEsT0FBTztJQUVwQixJQUFJLGFBQWEsS0FBSyxPQUFPLFNBQVMsR0FBRztLQUNyQyxLQUFLLFNBQVM7S0FDZCxLQUFLLE9BQU8sSUFBSTtLQUNoQixPQUFPLFFBQVE7S0FDZjtJQUdKLE9BQU8sSUFBSSxDQUFDLGFBQWEsY0FBYyxLQUFLLE9BQU87S0FDL0MsSUFBSSxZQUFZLFNBQVMsYUFBYTtLQUN0QyxLQUFLLE9BQU8sT0FBTyxDQUFDLFdBQVcsU0FBUztLQUN4QyxTQUFTO0tBQ1QsS0FBSyxTQUFTO0tBQ2QsT0FBTyxRQUFRO0tBQ2Y7SUFDSjtHQUNKO0dBRUE7R0FFQSxRQUFRO0VBQ1o7RUFHQSxJQUFJLENBQUMsS0FBSyxPQUFPLE1BQU0sSUFBSTtFQUUzQixnQkFBZ0IsS0FBSztDQUN6QjtDQUVBLFNBQVMsZ0JBQWdCLE9BQU87RUFDNUIsTUFBTSxPQUFPLEtBQUssT0FBTztFQUN6QixNQUFNLE9BQU8sS0FBSyxPQUFPO0VBR3pCLElBQUksSUFBSSxNQUFPO0VBQ2YsSUFBSSxJQUFJO0VBRVIsS0FBSyxJQUFJLFlBQVksR0FBRyxZQUFZLE1BQU0sUUFBUSxhQUFhO0dBQzNELElBQUksT0FBTyxNQUFNO0dBRWpCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLE9BQU8sUUFBUSxLQUFLO0lBQ3pDLE1BQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxDQUFDO0lBQzdCLElBQUksSUFBSSxLQUFLLE9BQU8sRUFBRSxDQUFDO0lBRXZCLElBQUksVUFBVSxVQUNWLEtBQUssS0FBSyxRQUFRO1NBQ2YsSUFBSSxVQUFVLFNBQ2pCLEtBQUssS0FBSztJQUlkLElBQUksV0FBVyxLQUFLLE1BQU0sSUFBSSxHQUFHO0lBR2pDLEtBQUssTUFBTSxVQUFVO0lBQ3JCLEtBQUssTUFBTSxVQUFVO0lBR3JCLElBQUksSUFBSSxNQUFNLFFBQVE7SUFDdEIsSUFBSSxJQUFJLE1BQU0sU0FBUztJQUN2QixRQUFRLFNBQVMsSUFBSTtLQUFDO0tBQUcsSUFBSTtLQUFHO0tBQUc7S0FBRztLQUFHO0tBQUcsSUFBSTtLQUFHLElBQUk7S0FBRztLQUFHLElBQUk7S0FBRztLQUFHO0lBQUMsR0FBRyxJQUFJLElBQUksQ0FBQztJQUVwRixJQUFJLElBQUksTUFBTSxJQUFJO0lBQ2xCLElBQUksS0FBSyxNQUFNLFFBQVE7SUFDdkIsSUFBSSxJQUFJLElBQU0sTUFBTSxJQUFJO0lBQ3hCLElBQUksS0FBSyxNQUFNLFNBQVM7SUFDeEIsUUFBUSxHQUFHLElBQUk7S0FBQztLQUFHLElBQUk7S0FBSTtLQUFHO0tBQUcsSUFBSTtLQUFJLElBQUk7S0FBSSxJQUFJO0tBQUk7SUFBQyxHQUFHLElBQUksSUFBSSxDQUFDO0lBR3RFLEtBQUssTUFBTSxVQUFVO0lBRXJCO0dBQ0o7R0FFQSxLQUFLLE9BQU87RUFDaEI7RUFFQSxNQUFNLFVBQVU7RUFDaEIsTUFBTSxXQUFXLE1BQU07RUFDdkIsTUFBTSxTQUFTLE1BQU0sV0FBVyxPQUFPO0VBQ3ZDLE1BQU0sUUFBUSxLQUFLLElBQUksR0FBRyxNQUFNLEtBQUssU0FBUyxLQUFLLEtBQUssQ0FBQztDQUM3RDtDQUVBLFNBQVMsa0JBQWtCLEtBQUssS0FBSztFQUNqQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxTQUFTLFFBQVEsS0FBSztHQUMzQyxJQUFJLElBQUksS0FBSyxTQUFTO0dBQ3RCLElBQUksRUFBRSxRQUFRLEtBQUs7R0FDbkIsSUFBSSxFQUFFLFNBQVMsS0FBSztHQUNwQixJQUFJLEVBQUUsUUFBUSxLQUFLLE9BQU87R0FDMUIsSUFBSSxFQUFFLFVBQVUsT0FBTyxFQUFFLFNBQVMsS0FBSyxPQUFPO0dBQzlDLE9BQU8sRUFBRTtFQUNiO0VBQ0EsT0FBTztDQUNYO0NBR0EsS0FBSyxTQUFTLFNBQVUsU0FBUztFQUM3QixDQUFDLENBQUUsU0FBVTtFQUNiLE9BQU87Q0FDWDtDQUdBLEtBQUssU0FBUyxTQUFVLFNBQVM7RUFDN0IsQ0FBQyxDQUFFLFFBQVM7RUFDWixlQUFlO0NBQ25CO0FBQ0o7OztBQzdPQSxJQUFNQyxXQUFvQjs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBbUIxQixJQUFNQyxhQUFzQjs7Ozs7Ozs7Ozs7QUFZNUIsU0FBZ0IsY0FBYyxJQUFJO0NBQzlCLE9BQU8sSUFBSSxRQUFRLElBQUk7RUFDbkIsUUFBUUQ7RUFDUixVQUFVQztFQUNWLFVBQVU7Q0FDZCxDQUFDO0FBQ0w7OztBQ2pDQSxJQUFhLFVBQWIsTUFBcUI7Q0FDakIsWUFDSSxJQUNBLEVBQ0ksT0FBTyxLQUNQLFVBQVUsSUFDVixRQUFRLEdBQ1IsY0FBYyxLQUNkLFNBQ0EsQ0FBQyxHQUNQO0VBQ0UsTUFBTSxRQUFRO0VBQ2QsS0FBSyxLQUFLO0VBR1YsS0FBSyxVQUFVLEVBQUUsT0FBTyxLQUFLO0VBRTdCLEtBQUssT0FBTztHQUNSLE1BQU07R0FDTixPQUFPO0dBR1AsWUFBWTtJQUNSLElBQUksT0FBTyxNQUFNLEtBQUs7SUFDdEIsTUFBTSxLQUFLLE9BQU8sTUFBTSxLQUFLO0lBQzdCLE1BQU0sS0FBSyxRQUFRO0lBQ25CLE1BQU0sUUFBUSxRQUFRLE1BQU0sS0FBSyxLQUFLO0dBQzFDO0VBQ0o7RUFHSSxXQUFXO0VBRVgsS0FBSyxTQUFTO0VBQ2QsS0FBSyxRQUFRLElBQUksS0FBSztFQUN0QixLQUFLLFdBQVcsSUFBSSxLQUFLO0VBRXpCLEtBQUssT0FBTyxZQUFZO0VBRzVCLFNBQVMsYUFBYTtHQUVsQixJQUFJLENBQUMsTUFBTSxPQUFPLEdBQUcsY0FBYyxHQUFHLFNBQVMsV0FBVyx5QkFBeUIsQ0FBQztHQUVwRixJQUFJLG1CQUFtQjtJQUNuQixJQUFJLEdBQUcsU0FBUyxVQUFVLE9BQU8sR0FBRztJQUNwQyxJQUFJLEdBQUcsU0FBUyxXQUFXLGVBQWUsU0FBUyxHQUFHLFFBQVEsS0FBSyxRQUFRLGdCQUFnQixPQUFPLEdBQUc7SUFDckcsT0FBTyxHQUFHO0dBQ2QsRUFBQSxDQUFHO0dBRUgsTUFBTSxVQUFVO0lBQ1osT0FBTztJQUNQLFFBQVE7SUFDUjtJQUNBLFFBQVEsR0FBRztJQUNYLGdCQUFnQixHQUFHLFNBQVMsV0FBWSxTQUFTLEdBQUcsUUFBUSxHQUFHLFVBQVUsR0FBRyxVQUFXLEdBQUc7SUFDMUY7SUFDQSxPQUFPO0dBQ1g7R0FFQSxNQUFNLEtBQUssT0FBTyxJQUFJLGFBQWEsSUFBSSxPQUFPO0dBQzlDLE1BQU0sS0FBSyxRQUFRLElBQUksYUFBYSxJQUFJLE9BQU87R0FDL0MsTUFBTSxLQUFLLEtBQUs7RUFDcEI7RUFFQSxTQUFTLGNBQWM7R0FDbkIsT0FBTyxJQUFJLEtBQUssSUFBSTtJQUVoQixVQUFVLElBQUksU0FBUyxFQUFFO0lBRXpCLFNBQVMsSUFBSSxRQUFRLElBQUk7S0FDckIsUUFBQTtLQUNBLFVBQUE7S0FDQSxVQUFVO01BQ04sTUFBTSxNQUFNO01BRVosVUFBVSxFQUFFLE9BQU8sVUFBVSxHQUFJO01BQ2pDLFFBQVEsRUFBRSxPQUFPLE1BQU07TUFDdkIsY0FBYyxFQUFFLE9BQU8sWUFBWTtNQUduQyxTQUFTLEVBQUUsT0FBTyxFQUFFO01BQ3BCLFFBQVEsRUFBRSxPQUFPLE1BQU0sTUFBTTtNQUM3QixXQUFXLEVBQUUsT0FBTyxNQUFNLFNBQVM7S0FDdkM7S0FDQSxXQUFXO0lBQ2YsQ0FBQztHQUNMLENBQUM7RUFDTDtDQUNKO0NBRUEsU0FBUztFQUNMLEtBQUssS0FBSyxRQUFRLFNBQVMsUUFBUSxRQUFRLEtBQUs7RUFFaEQsS0FBSyxHQUFHLFNBQVMsT0FBTztHQUNwQixPQUFPLEtBQUs7R0FDWixRQUFRLEtBQUssS0FBSztHQUNsQixPQUFPO0VBQ1gsQ0FBQztFQUNELEtBQUssS0FBSyxLQUFLO0NBQ25CO0FBQ0o7QUFFQSxJQUFNQyxXQUFvQjs7Ozs7Ozs7Ozs7QUFZMUIsSUFBTUMsYUFBc0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuSDVCLElBQWEsUUFBYixNQUFtQjtDQUNmLFlBQ0ksSUFDQSxFQUVJLHVCQUFPLElBQUksYUFBYSxFQUFFLEdBQzFCLFdBQVcsSUFBSSxTQUFTLEVBQUUsR0FDMUIsUUFFTjtFQUNFLEtBQUssS0FBSztFQUNWLE1BQU0sY0FBYztFQUNwQixLQUFLLFNBQVMsQ0FBQztFQUNmLEtBQUssV0FBVztFQUNoQixLQUFLLGFBQWEsWUFBWSxTQUFTO0VBSXZDLEtBQUssT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLLEtBQUssS0FBSyxJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxVQUFVLENBQUMsQ0FBQyxJQUFJLEtBQUssR0FBRyxDQUFDO0VBRzdGLEtBQUssU0FBUyxJQUFJLGFBQWEsS0FBSyxhQUFhLENBQUM7RUFDbEQsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssWUFBWSxLQUFLO0dBQ3RDLE1BQU0sSUFBSyxJQUFJLEtBQUssT0FBUSxLQUFLO0dBQ2pDLE1BQU0sSUFBSSxLQUFLLE1BQU0sSUFBSSxLQUFLLElBQUksSUFBSSxLQUFLO0dBQzNDLEtBQUssT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDO0VBQ2pDO0VBR0EsTUFBTSxvQkFBb0I7R0FDdEIsSUFBSSxZQUFZLFdBQVcsS0FBSyxPQUFPLEtBQUssT0FBTyxHQUMvQyxPQUFPO1FBQ0o7SUFDSCxNQUFNLElBQUksSUFBSSxhQUFhLEtBQUssT0FBTyxLQUFLLE9BQU8sQ0FBQztJQUNwRCxFQUFFLElBQUksV0FBVztJQUNqQixPQUFPO0dBQ1g7RUFDSixFQUFBLENBQUc7RUFHSCxLQUFLLFVBQVUsRUFDWCxPQUFPLElBQUksUUFBUSxJQUFJO0dBQ25CLE9BQU87R0FDUCxRQUFRLEdBQUc7R0FDWCxNQUFNLEdBQUc7R0FDVCxRQUFRLEdBQUc7R0FDWCxnQkFBZ0IsR0FBRyxTQUFTLFdBQVcsR0FBRyxVQUFVLEdBQUc7R0FDdkQsT0FBTyxHQUFHO0dBQ1YsT0FBTyxHQUFHO0dBQ1YsaUJBQWlCO0dBQ2pCLFdBQVcsR0FBRztHQUNkLFdBQVcsR0FBRztHQUNkLE9BQU8sS0FBSztHQUNaLE9BQU87RUFDWCxDQUFDLEVBQ0w7RUFHQSxNQUFNLFVBQVU7R0FDWixPQUFPLEtBQUs7R0FDWixRQUFRLEtBQUs7R0FDYixNQUFNLFFBQVEsR0FBRyxjQUFjLEdBQUcsU0FBUyxXQUFXLHlCQUF5QixDQUFDO0dBQ2hGLFFBQVEsR0FBRztHQUNYLGdCQUFnQixHQUFHLFNBQVMsV0FBWSxTQUFTLEdBQUcsUUFBUSxHQUFHLFVBQVUsR0FBRyxVQUFXLEdBQUc7R0FDMUYsV0FBVyxHQUFHO0dBQ2QsT0FBTztHQUNQLGlCQUFpQjtFQUNyQjtFQUVBLEtBQUssTUFBTTtHQUNQLE1BQU0sSUFBSSxhQUFhLElBQUksT0FBTztHQUNsQyxPQUFPLElBQUksYUFBYSxJQUFJLE9BQU87R0FDbkMsWUFBWTtJQUNSLElBQUksT0FBTyxLQUFLLElBQUk7SUFDcEIsS0FBSyxJQUFJLE9BQU8sS0FBSyxJQUFJO0lBQ3pCLEtBQUssSUFBSSxRQUFRO0lBQ2pCLEtBQUssUUFBUSxRQUFRLEtBQUssSUFBSSxLQUFLO0dBQ3ZDO0VBQ0o7Q0FDSjtDQUVBLFFBQVEsRUFBRSxTQUFTQyxpQkFBZSxXQUFXQyxtQkFBaUIsV0FBVyxDQUFDLEdBQUcsaUJBQWlCLFFBQVEsVUFBVSxTQUFTLENBQUMsR0FBRztFQUN6SCxTQUFTLGtCQUFrQixLQUFLO0VBQ2hDLE1BQU0sVUFBVSxJQUFJLFFBQVEsS0FBSyxJQUFJO0dBQUU7R0FBUTtHQUFVO0VBQVMsQ0FBQztFQUduRSxNQUFNLE9BQU87R0FDVCxNQUFBLElBSGEsS0FBSyxLQUFLLElBQUk7SUFBRSxVQUFVLEtBQUs7SUFBVTtHQUFRLENBRzNEO0dBQ0g7R0FDQTtHQUNBO0dBQ0E7RUFDSjtFQUVBLEtBQUssT0FBTyxLQUFLLElBQUk7RUFDckIsT0FBTztDQUNYO0NBRUEsU0FBUztFQUdMLEtBRjJCLE9BQU8sUUFBUSxTQUFTLEtBQUssT0FFNUMsQ0FBQyxDQUFDLFNBQVMsTUFBTSxNQUFNO0dBQy9CLEtBQUssR0FBRyxTQUFTLE9BQU87SUFDcEIsT0FBTyxLQUFLO0lBQ1osUUFBUSxLQUFLLElBQUk7SUFDakIsT0FBTztHQUNYLENBQUM7R0FDRCxLQUFLLElBQUksS0FBSztFQUNsQixDQUFDO0NBQ0w7QUFDSjtBQUVBLElBQU1ELGtCQUEyQjs7Ozs7Ozs7Ozs7QUFZakMsSUFBTUMsb0JBQTZCOzs7Ozs7Ozs7Ozs7QUMzSG5DLElBQU0sc0JBQXNCLElBQUksS0FBSztBQUVyQyxJQUFhLFdBQWIsTUFBc0I7Q0FDbEIsWUFDSSxJQUNBLEVBQ0ksUUFDQSxTQUFTQyxpQkFDVCxXQUFXQyxtQkFDWCxXQUFXLENBQUMsR0FDWixhQUFhLENBQUMsS0FFcEI7RUFDRSxLQUFLLEtBQUs7RUFDVixLQUFLLFNBQVM7RUFDZCxLQUFLLFFBQVEsT0FBTztFQUdwQixLQUFLLFdBQVcsSUFBSSxhQUFhLEtBQUssUUFBUSxJQUFJLENBQUM7RUFDbkQsS0FBSyxPQUFPLElBQUksYUFBYSxLQUFLLFFBQVEsSUFBSSxDQUFDO0VBQy9DLEtBQUssT0FBTyxJQUFJLGFBQWEsS0FBSyxRQUFRLElBQUksQ0FBQztFQUMvQyxNQUFNLE9BQU8sSUFBSSxhQUFhLEtBQUssUUFBUSxJQUFJLENBQUM7RUFDaEQsTUFBTSxLQUFLLElBQUksYUFBYSxLQUFLLFFBQVEsSUFBSSxDQUFDO0VBQzlDLE1BQU0sUUFBUSxJQUFJLGFBQWEsS0FBSyxRQUFRLEtBQUssSUFBSSxDQUFDO0VBR3RELEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLE9BQU8sS0FBSztHQUNqQyxLQUFLLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUM7R0FDdkIsTUFBTSxJQUFJLEtBQUssS0FBSyxRQUFRO0dBQzVCLEdBQUcsSUFBSTtJQUFDO0lBQUc7SUFBRztJQUFHO0dBQUMsR0FBRyxJQUFJLENBQUM7R0FFMUIsSUFBSSxNQUFNLEtBQUssUUFBUSxHQUFHO0dBQzFCLE1BQU0sTUFBTSxJQUFJO0dBQ2hCLE1BQU0sSUFBSTtJQUFDLE1BQU07SUFBRyxNQUFNO0lBQUcsTUFBTTtHQUFDLElBQUksTUFBTSxLQUFLLENBQUM7R0FDcEQsTUFBTSxJQUFJO0lBQUMsTUFBTTtJQUFHLE1BQU07SUFBRyxNQUFNO0dBQUMsSUFBSSxNQUFNLEtBQUssQ0FBQztFQUN4RDtFQUVBLE1BQU0sV0FBWSxLQUFLLFdBQVcsSUFBSSxTQUNsQyxJQUNBLE9BQU8sT0FBTyxZQUFZO0dBQ3RCLFVBQVU7SUFBRSxNQUFNO0lBQUcsTUFBTSxLQUFLO0dBQVM7R0FDekMsTUFBTTtJQUFFLE1BQU07SUFBRyxNQUFNLEtBQUs7R0FBSztHQUNqQyxNQUFNO0lBQUUsTUFBTTtJQUFHLE1BQU0sS0FBSztHQUFLO0dBQ2pDLE1BQU07SUFBRSxNQUFNO0lBQUcsTUFBTTtHQUFLO0dBQzVCLElBQUk7SUFBRSxNQUFNO0lBQUcsTUFBTTtHQUFHO0dBQ3hCLE9BQU87SUFBRSxNQUFNO0lBQUcsTUFBTTtHQUFNO0VBQ2xDLENBQUMsQ0FDTDtFQUdBLEtBQUssZUFBZTtFQUVwQixJQUFJLENBQUMsU0FBUyxhQUFhLEtBQUssYUFBYSxTQUFTLGNBQWMsRUFBRSxPQUFPLElBQUksS0FBSyxFQUFFO0VBQ3hGLElBQUksQ0FBQyxTQUFTLE1BQU0sS0FBSyxNQUFNLFNBQVMsT0FBTyxFQUFFLE9BQU8sRUFBRTtFQUMxRCxJQUFJLENBQUMsU0FBUyxZQUFZLEtBQUssWUFBWSxTQUFTLGFBQWEsRUFBRSxPQUFPLEVBQUU7RUFDNUUsSUFBSSxDQUFDLFNBQVMsUUFBUSxLQUFLLFFBQVEsU0FBUyxTQUFTLEVBQUUsT0FBTyxJQUFJLE1BQU0sTUFBTSxFQUFFO0VBQ2hGLElBQUksQ0FBQyxTQUFTLFFBQVEsS0FBSyxRQUFRLFNBQVMsU0FBUyxFQUFFLE9BQU8sRUFBRTtFQUdoRSxLQUFLLE9BQU87RUFFWixNQUFNLFVBQVcsS0FBSyxVQUFVLElBQUksUUFBUSxJQUFJO0dBQzVDO0dBQ0E7R0FDQTtFQUNKLENBQUM7RUFFRCxLQUFLLE9BQU8sSUFBSSxLQUFLLElBQUk7R0FBRTtHQUFVO0VBQVEsQ0FBQztDQUNsRDtDQUVBLGlCQUFpQjtFQUNiLEtBQUssT0FBTyxTQUFTLEdBQUcsTUFBTTtHQUMxQixFQUFFLFFBQVEsS0FBSyxVQUFVLElBQUksSUFBSSxDQUFDO0dBQ2xDLEVBQUUsUUFBUSxLQUFLLFVBQVUsSUFBSSxJQUFJLElBQUksQ0FBQztHQUV0QyxJQUFJLENBQUMsR0FBRztJQUVKLElBQUksS0FBSyxDQUFDLENBQUMsQ0FDTixJQUFJLEtBQUssT0FBTyxJQUFJLEVBQUUsQ0FBQyxDQUN2QixJQUFJLENBQUM7SUFDVixJQUFJLFFBQVEsS0FBSyxNQUFNLElBQUksSUFBSSxDQUFDO0lBQ2hDLElBQUksUUFBUSxLQUFLLE1BQU0sSUFBSSxJQUFJLElBQUksQ0FBQztHQUN4QyxPQUFPO0lBQ0gsRUFBRSxRQUFRLEtBQUssT0FBTyxJQUFJLEtBQUssSUFBSSxDQUFDO0lBQ3BDLEVBQUUsUUFBUSxLQUFLLE9BQU8sSUFBSSxLQUFLLElBQUksSUFBSSxDQUFDO0dBQzVDO0dBRUEsSUFBSSxNQUFNLEtBQUssT0FBTyxTQUFTLEdBQUc7SUFFOUIsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUNOLElBQUksS0FBSyxPQUFPLElBQUksRUFBRSxDQUFDLENBQ3ZCLElBQUksQ0FBQztJQUNWLElBQUksUUFBUSxLQUFLLE1BQU0sSUFBSSxJQUFJLENBQUM7SUFDaEMsSUFBSSxRQUFRLEtBQUssTUFBTSxJQUFJLElBQUksSUFBSSxDQUFDO0dBQ3hDLE9BQU87SUFDSCxFQUFFLFFBQVEsS0FBSyxPQUFPLElBQUksS0FBSyxJQUFJLENBQUM7SUFDcEMsRUFBRSxRQUFRLEtBQUssT0FBTyxJQUFJLEtBQUssSUFBSSxJQUFJLENBQUM7R0FDNUM7RUFDSixDQUFDO0VBRUQsS0FBSyxTQUFTLFdBQVcsU0FBUyxjQUFjO0VBQ2hELEtBQUssU0FBUyxXQUFXLEtBQUssY0FBYztFQUM1QyxLQUFLLFNBQVMsV0FBVyxLQUFLLGNBQWM7Q0FDaEQ7Q0FHQSxTQUFTO0VBRUwsSUFBSSxLQUFLLFlBQVksS0FBSyxXQUFXLE1BQU0sSUFBSSxLQUFLLEdBQUcsT0FBTyxPQUFPLEtBQUssR0FBRyxPQUFPLE1BQU07RUFDMUYsSUFBSSxLQUFLLEtBQUssS0FBSyxJQUFJLFFBQVEsS0FBSyxHQUFHLFNBQVM7Q0FDcEQ7QUFDSjtBQUVBLElBQU1ELGtCQUEyQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFtRGpDLElBQU1DLG9CQUE2Qjs7Ozs7Ozs7Ozs7Ozs7QUN2S25DLElBQWEsU0FBYixNQUFvQjtDQUNoQixZQUFZLElBQUksRUFBRSxRQUFRLElBQUksT0FBTyxFQUFFLEdBQUcsUUFBUSxNQUFNLFNBQVMsU0FBUztFQUN0RSxLQUFLLEtBQUs7RUFFVixLQUFLLFFBQVE7RUFFYixLQUFLLFNBQVMsSUFBSSxhQUFhLElBQUk7R0FBRTtHQUFPO0VBQU8sQ0FBQztFQUNwRCxLQUFLLGdCQUFnQixFQUFFLE9BQU8sS0FBSyxPQUFPLFFBQVE7RUFFbEQsS0FBSyxlQUFlLElBQUksUUFBUSxJQUFJO0dBQ2hDLFFBQVE7R0FDUixVQUFVO0dBQ1YsVUFBVTtFQUNkLENBQUM7RUFFRCxLQUFLLGFBQWEsQ0FBQztDQUN2QjtDQUVBLElBQUksRUFDQSxNQUNBLFVBQVUsTUFDVixPQUFPLE1BQ1AsU0FBUyxlQUNULFdBQVcsaUJBQ1gsb0JBQW9CLDBCQUNwQixjQUFjLG9CQUNkLGlCQUFpQixhQUNsQjtFQUVDLElBQUksV0FBVyxDQUFDLEtBQUssUUFBUSxTQUFTLG9CQUFvQjtHQUN0RCxLQUFLLFFBQVEsU0FBUyxxQkFBcUIsRUFBRSxPQUFPLEtBQUssTUFBTSxpQkFBaUI7R0FDaEYsS0FBSyxRQUFRLFNBQVMsZUFBZSxFQUFFLE9BQU8sS0FBSyxNQUFNLFdBQVc7R0FDcEUsS0FBSyxRQUFRLFNBQVMsa0JBQWtCLEtBQUs7RUFDakQ7RUFFQSxJQUFJLENBQUMsTUFBTTtFQUNYLEtBQUssV0FBVyxLQUFLLElBQUk7RUFHekIsS0FBSyxlQUFlLEtBQUs7RUFHekIsSUFBSSxLQUFLLGNBQWM7RUFHdkIsSUFBSSxXQUFXLGlCQUFpQixhQUFhLGlCQUFpQjtHQUMxRCxLQUFLLGVBQWUsS0FBSztHQUN6QjtFQUNKO0VBR0EsS0FBSyxlQUFlLElBQUksUUFBUSxLQUFLLElBQUk7R0FDckM7R0FDQTtHQUNBLFVBQVU7RUFDZCxDQUFDO0NBQ0w7Q0FFQSxRQUFRLEVBQUUsUUFBUSxNQUFNLFNBQVMsU0FBUztFQUN0QyxLQUFLLFNBQVMsSUFBSSxhQUFhLEtBQUssSUFBSTtHQUFFO0dBQU87RUFBTyxDQUFDO0VBQ3pELEtBQUssY0FBYyxRQUFRLEtBQUssT0FBTztDQUMzQztDQUVBLE9BQU8sRUFBRSxTQUFTO0VBR2QsTUFBTSxVQUFVLFNBQVM7R0FDckIsSUFBSSxDQUFDLEtBQUssTUFBTTtHQUNoQixJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVyxRQUFRLElBQUksR0FDL0IsS0FBSyxVQUFVLEtBQUs7UUFDakI7SUFDSCxLQUFLLG9CQUFvQixLQUFLO0lBQzlCLEtBQUssVUFBVTtHQUNuQjtFQUNKLENBQUM7RUFHRCxLQUFLLEdBQUcsU0FBUyxPQUFPO0dBQ3BCO0dBQ0EsUUFBUSxLQUFLO0dBQ2IsUUFBUSxLQUFLO0VBQ2pCLENBQUM7RUFHRCxNQUFNLFVBQVUsU0FBUztHQUNyQixJQUFJLENBQUMsS0FBSyxNQUFNO0dBQ2hCLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFXLFFBQVEsSUFBSSxHQUMvQixLQUFLLFVBQVUsS0FBSztRQUVwQixLQUFLLFVBQVUsS0FBSztFQUU1QixDQUFDO0NBQ0w7QUFDSjtBQUVBLElBQU0sZ0JBQTJCOzs7Ozs7Ozs7OztBQVlqQyxJQUFNLGtCQUE2Qjs7Ozs7Ozs7Ozs7Ozs7O0FDMUduQyxJQUFhLGFBQWIsY0FBZ0MsUUFBUTtDQUNwQyxZQUFZLElBQUksRUFBRSxRQUFRLFFBQVEsR0FBRyxlQUFlLFFBQVEsR0FBRyxlQUFlLGFBQWEsR0FBRyxXQUFXLGNBQWMsQ0FBQyxHQUFHO0VBQ3ZILE1BQU0sSUFBSTtHQUNOLGlCQUFpQjtHQUNqQjtHQUNBO0dBQ0E7R0FDQTtHQUNBO0VBQ0osQ0FBQztFQUVELElBQUksUUFBUSxPQUFPLEtBQUssWUFBWSxNQUFNO0NBQzlDO0NBRUEsWUFBWSxRQUFRO0VBQ2hCLE1BQU0sTUFBTSxJQUFJLHdCQUF3QixNQUFNO0VBQzlDLElBQUksUUFBUSxzQkFBc0I7RUFHbEMsS0FBSyxRQUFRLElBQUk7RUFDakIsS0FBSyxpQkFBaUIsSUFBSTtFQUMxQixJQUFJLElBQUksdUJBQXVCLEdBQ3ZCO09BQUEsS0FBSyxjQUFjLEtBQUssR0FBRyxRQUFRLEtBQUssWUFBWSxLQUFLLEdBQUc7RUFBQSxPQUVoRSxJQUFJLEtBQUssY0FBYyxLQUFLLEdBQUcsdUJBQXVCLEtBQUssWUFBWSxLQUFLLEdBQUc7Q0FLdkY7QUFDSjtBQUVBLFNBQVMsd0JBQXdCLFFBQVE7Q0FDckMsTUFBTSxVQUFVO0VBQUM7RUFBTTtFQUFNO0VBQU07RUFBTTtFQUFNO0VBQU07RUFBTTtFQUFNO0VBQU07RUFBTTtFQUFNO0NBQUk7Q0FDdkYsTUFBTSxLQUFLLElBQUksV0FBVyxRQUFRLEdBQUcsRUFBRTtDQUN2QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxRQUFRLEtBQUssSUFBSSxHQUFHLE9BQU8sUUFBUSxJQUFJLE9BQU8sUUFBUSxNQUFNLDZCQUE2QjtDQUdoSCxNQUFNLE9BQU8sWUFBWTtDQUN6QixNQUFNLE9BQU8sSUFBSSxTQUFTLFFBQVEsSUFBSSxLQUFLLElBQUk7Q0FDL0MsTUFBTSxlQUFlLEtBQUssVUFBVSxHQUFHLElBQUksTUFBTTtDQUVqRCxJQURlLEtBQUssVUFBVSxJQUFJLE1BQU0sWUFDL0IsTUFBTSxHQUFHLE9BQU8sUUFBUSxLQUFLLDZDQUE2QztDQUNuRixLQUFLLG1CQUFtQixLQUFLLFVBQVUsSUFBSSxNQUFNLFlBQVk7Q0FDN0QsSUFBSSxRQUFRLEtBQUssVUFBVSxJQUFJLE1BQU0sWUFBWTtDQUNqRCxJQUFJLFNBQVMsS0FBSyxVQUFVLElBQUksTUFBTSxZQUFZO0NBQ2xELEtBQUssZ0JBQWdCLEtBQUssVUFBVSxLQUFLLE1BQU0sWUFBWTtDQUMzRCxLQUFLLHVCQUF1QixLQUFLLElBQUksR0FBRyxLQUFLLFVBQVUsS0FBSyxNQUFNLFlBQVksQ0FBQztDQUMvRSxNQUFNLHNCQUFzQixLQUFLLFVBQVUsS0FBSyxNQUFNLFlBQVk7Q0FFbEUsS0FBSyxVQUFVLENBQUM7Q0FDaEIsSUFBSSxTQUFTLEtBQWM7Q0FDM0IsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLEtBQUssc0JBQXNCLFNBQVM7RUFDNUQsTUFBTSxZQUFZLElBQUksV0FBVyxRQUFRLFFBQVEsQ0FBQyxDQUFDLENBQUM7RUFDcEQsVUFBVTtFQUNWLEtBQUssSUFBSSxPQUFPLEdBQUcsT0FBTyxLQUFLLGVBQWUsUUFBUTtHQUNsRCxNQUFNLE9BQU8sSUFBSSxXQUFXLFFBQVEsUUFBUSxTQUFTO0dBQ3JELEtBQUssUUFBUSxLQUFLO0lBQUU7SUFBTTtJQUFPO0dBQU8sQ0FBQztHQUN6QyxVQUFVO0dBQ1YsVUFBVSxLQUFNLFlBQVksS0FBSztFQUNyQztFQUNBLFFBQVEsU0FBUztFQUNqQixTQUFTLFVBQVU7Q0FDdkI7QUFDSjs7O0FDaEVBLElBQUksUUFBUSxDQUFDO0FBQ2IsSUFBTSxzQkFBc0IsQ0FBQztBQUU3QixJQUFhLGdCQUFiLE1BQTJCO0NBQ3ZCLE9BQU8sS0FDSCxJQUNBLEVBQ0ksS0FhQSxRQUFRLEdBQUcsZUFDWCxRQUFRLEdBQUcsZUFDWCxhQUFhLEdBR2IsU0FBUyxHQUFHLE1BQ1osaUJBQWlCLFFBQ2pCLGtCQUFrQixNQUNsQixZQUFZLGtCQUFrQixHQUFHLHdCQUF3QixHQUFHLFFBQzVELFlBQVksR0FBRyxRQUNmLG1CQUFtQixPQUNuQixrQkFBa0IsR0FDbEIsUUFBUSxTQUNSLENBQUMsR0FDUDtFQUNFLE1BQU0sVUFBVSxLQUFLLHVCQUF1QixFQUFFO0VBQzlDLElBQUksTUFBTTtFQUdWLElBQUksT0FBTyxRQUFRLFVBQ2YsTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsWUFBWTtFQUt6RCxJQUFJLE9BQU8sUUFBUSxVQUNWO1FBQUEsTUFBTSxRQUFRLEtBQ2YsSUFBSSxRQUFRLFNBQVMsS0FBSyxZQUFZLENBQUMsR0FBRztJQUN0QyxNQUFNLEtBQUssWUFBWTtJQUN2QixNQUFNLElBQUk7SUFDVjtHQUNKOztFQUtSLE1BQU0sVUFBVSxNQUFNLFFBQVEsUUFBUSxhQUFhLFNBQVMsaUJBQWlCLGtCQUFrQixZQUFZLFlBQVksbUJBQW1CLGtCQUFrQixRQUFRLEdBQUcsU0FBUztFQUdoTCxJQUFJLE1BQU0sVUFBVSxPQUFPLE1BQU07RUFFakMsSUFBSTtFQUNKLFFBQVEsS0FBUjtHQUNJLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztJQUVELFVBQVUsSUFBSSxXQUFXLElBQUk7S0FDekI7S0FDQTtLQUNBO0tBQ0E7S0FDQTtLQUNBO0lBQ0osQ0FBQztJQUNELFFBQVEsU0FBUyxLQUFLLFFBQVEsS0FBSyxPQUFPO0lBQzFDO0dBQ0osS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztJQUNELFVBQVUsSUFBSSxRQUFRLElBQUk7S0FDdEI7S0FDQTtLQUNBO0tBQ0E7S0FDQTtLQUNBO0tBQ0E7S0FDQTtLQUNBO0tBQ0E7S0FDQTtJQUNKLENBQUM7SUFDRCxRQUFRLFNBQVMsS0FBSyxVQUFVLElBQUksS0FBSyxTQUFTLEtBQUs7SUFDdkQ7R0FDSjtJQUNJLFFBQVEsS0FBSyw4QkFBOEI7SUFDM0MsVUFBVSxJQUFJLFFBQVEsRUFBRTtFQUNoQztFQUVBLFFBQVEsTUFBTTtFQUNkLE1BQU0sV0FBVztFQUNqQixPQUFPO0NBQ1g7Q0FFQSxPQUFPLHVCQUF1QixJQUFJO0VBQzlCLElBQUksb0JBQW9CLFFBQVEsT0FBTztFQUV2QyxNQUFNLGFBQWE7R0FDZixPQUFPLEdBQUcsU0FBUyxhQUFhLGdDQUFnQyxLQUFLLEdBQUcsU0FBUyxhQUFhLHVDQUF1QztHQUNySSxNQUFNLEdBQUcsU0FBUyxhQUFhLCtCQUErQjtHQUU5RCxNQUFNLEdBQUcsU0FBUyxhQUFhLCtCQUErQjtHQUM5RCxNQUFNLEdBQUcsU0FBUyxhQUFhLCtCQUErQjtHQUM5RCxLQUFLLEdBQUcsU0FBUyxhQUFhLDhCQUE4QjtFQUNoRTtFQUVBLEtBQUssTUFBTSxPQUFPLFlBQVksSUFBSSxXQUFXLE1BQU0sb0JBQW9CLEtBQUssR0FBRztFQUcvRSxvQkFBb0IsS0FBSyxPQUFPLE9BQU8sTUFBTTtFQUU3QyxPQUFPO0NBQ1g7Q0FFQSxPQUFPLFFBQVEsS0FBSyxTQUFTO0VBQ3pCLE9BQU8sTUFBTSxHQUFHLENBQUMsQ0FDWixNQUFNLFFBQVEsSUFBSSxZQUFZLENBQUMsQ0FBQyxDQUNoQyxNQUFNLFdBQVcsUUFBUSxZQUFZLE1BQU0sQ0FBQztDQUNyRDtDQUVBLE9BQU8sVUFBVSxJQUFJLEtBQUssU0FBUyxPQUFPO0VBQ3RDLE9BQU8sWUFBWSxLQUFLLEtBQUssQ0FBQyxDQUFDLE1BQU0sV0FBVztHQUU1QyxJQUFJLENBQUMsR0FBRyxTQUFTLGFBQWEsQ0FBQyxXQUFXLE9BQU8sS0FBSyxLQUFLLENBQUMsV0FBVyxPQUFPLE1BQU0sSUFBSTtJQUNwRixJQUFJLFFBQVEsaUJBQWlCLFFBQVEsa0JBQWtCO0lBQ3ZELElBQUksUUFBUSxjQUFjLEdBQUcsdUJBQXVCLFFBQVEsWUFBWSxHQUFHO0lBQzNFLElBQUksUUFBUSxVQUFVLEdBQUcsUUFBUSxRQUFRLFFBQVEsUUFBUSxRQUFRLEdBQUc7R0FDeEU7R0FFQSxRQUFRLFFBQVE7R0FHaEIsUUFBUSxpQkFBaUI7SUFDckIsSUFBSSxPQUFPLE9BQU8sT0FBTyxNQUFNO0lBQy9CLFFBQVEsV0FBVztHQUN2QjtHQUVBLE9BQU87RUFDWCxDQUFDO0NBQ0w7Q0FFQSxPQUFPLGFBQWE7RUFDaEIsUUFBUSxDQUFDO0NBQ2I7QUFDSjtBQUVBLFNBQVMsV0FBVyxPQUFPO0NBRXZCLE9BQU8sS0FBSyxLQUFLLEtBQUssSUFBSSxNQUFNO0FBQ3BDO0FBRUEsU0FBUyxZQUFZLEtBQUssT0FBTztDQUM3QixPQUFPLElBQUksU0FBUyxTQUFTLFdBQVc7RUFDcEMsSUFBSSxvQkFBb0IsR0FDcEIsTUFBTSxLQUFLLEVBQUUsTUFBTSxPQUFPLENBQUMsQ0FBQyxDQUN2QixNQUFNLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUNyQixNQUFNLE1BQU0sa0JBQWtCLEdBQUc7R0FBRSxrQkFBa0IsUUFBUSxVQUFVO0dBQVEsa0JBQWtCO0VBQU8sQ0FBQyxDQUFDLENBQUMsQ0FDM0csS0FBSyxPQUFPLENBQUMsQ0FDYixPQUFPLFFBQVEsT0FBTyxHQUFHLENBQUM7T0FDNUI7R0FDSCxNQUFNLE1BQU0sSUFBSSxNQUFNO0dBRXRCLElBQUksY0FBYztHQUNsQixJQUFJLE1BQU07R0FDVixJQUFJLFdBQVcsRUFBRSxXQUFXLE9BQU8sR0FBRyxLQUFLLGdCQUFnQjtHQUMzRCxJQUFJLGVBQWUsUUFBUSxHQUFHO0VBQ2xDO0NBQ0osQ0FBQztBQUNMO0FBRUEsU0FBUyxzQkFBc0I7Q0FFM0IsSUFBSSxDQURhLFVBQVUsVUFBVSxZQUFZLENBQUMsQ0FBQyxTQUFTLFFBQ2hELEdBQUcsT0FBTztDQUN0QixJQUFJO0VBQ0E7Q0FDSixTQUFTLEdBQUc7RUFDUixPQUFPO0NBQ1g7Q0FDQSxPQUFPO0FBQ1g7OztBQ3BNQSxJQUFNLDJCQUEyQixJQUFJLEtBQUs7QUFDMUMsSUFBTSwyQkFBMkIsSUFBSSxLQUFLO0FBQzFDLElBQU0sMkJBQTJCLElBQUksS0FBSztBQUMxQyxJQUFNLDJCQUEyQixJQUFJLEtBQUs7QUFFMUMsSUFBTSwyQkFBMkIsSUFBSSxLQUFLO0FBQzFDLElBQU0sMkJBQTJCLElBQUksS0FBSztBQUMxQyxJQUFNLDJCQUEyQixJQUFJLEtBQUs7QUFDMUMsSUFBTSwyQkFBMkIsSUFBSSxLQUFLO0FBRTFDLElBQWEsZ0JBQWIsTUFBMkI7Q0FDdkIsWUFBWSxNQUFNLFNBQVMsR0FBRztFQUMxQixLQUFLLE9BQU87RUFDWixLQUFLLFVBQVU7RUFDZixLQUFLLFNBQVM7RUFHZCxLQUFLLE9BQU87RUFHWixLQUFLLFlBQVksS0FBSyxRQUFRLEdBQUcsRUFBRSxZQUFZLEtBQUssSUFBSSxHQUFHLE1BQU0sRUFBRSxHQUFHLFFBQVE7RUFFOUUsS0FBSyxVQUFVLEtBQUssUUFBUSxHQUFHLEVBQUUsWUFBWSxLQUFLLElBQUksR0FBRyxNQUFNLE1BQU0sU0FBUyxFQUFFLEdBQUcsQ0FBQztFQUNwRixLQUFLLFdBQVcsS0FBSyxVQUFVLEtBQUs7Q0FDeEM7Q0FFQSxPQUFPLGNBQWMsR0FBRyxPQUFPO0VBQzNCLE1BQU0sU0FBUyxRQUFRLElBQUksS0FBSyxTQUFTO0VBQ3pDLE1BQU0sVUFBVSxDQUFDLEtBQUssV0FDaEIsS0FDQyxLQUFLLE9BQU8sS0FBSyxVQUFVLEtBQUssV0FBVyxLQUFLLElBQUksS0FBSyxTQUFTLEtBQUssV0FBVyxJQUFLLEtBQUssS0FBSztFQUV4RyxLQUFLLEtBQUssU0FBUyxFQUFFLE1BQU0sV0FBVyxlQUFlLE9BQU8sYUFBYTtHQUNyRSxJQUFJLENBQUMsS0FBSyxVQUFVO0lBQ2hCLElBQUksTUFBTTtJQUNWLElBQUksT0FBTztJQUNYLElBQUksY0FBYyxjQUFjO0tBQzVCLE1BQU07S0FDTixPQUFPO0lBQ1g7SUFDQSxJQUFJLFVBQVUsUUFBUSxDQUFDO0lBQ3ZCLElBQUksU0FBUyxHQUFHLEtBQUssVUFBVSxDQUFDLE1BQU0sS0FBSyxNQUFNO1NBQzVDLEtBQUssVUFBVSxDQUFDLEtBQUssS0FBSyxNQUFNO0lBQ3JDO0dBQ0o7R0FHQSxNQUFNLFlBQ0YsS0FBSyxJQUNELEdBQ0EsTUFBTSxXQUFXLE1BQU0sSUFBSSxPQUFPLENBQ3RDLElBQUk7R0FDUixNQUFNLFlBQVksWUFBWTtHQUc5QixJQUFJLFNBQVMsVUFBVSxNQUFNLGVBQWUsTUFBTSxhQUFhLE1BQU07R0FDckUsSUFBSSxrQkFBa0IsUUFBUSxRQUFRO0dBRXRDLElBQUksVUFBVTtHQUNkLElBQUksVUFBVTtHQUNkLElBQUksVUFBVTtHQUNkLElBQUksVUFBVTtHQUNkLElBQUksT0FBTztHQUVYLElBQUksY0FBYyxjQUFjO0lBQzVCLFVBQVU7SUFDVixVQUFVO0lBQ1YsVUFBVTtJQUNWLFVBQVU7SUFDVixPQUFPO0dBQ1g7R0FFQSxJQUFJLGtCQUFrQixlQUFlO0lBRWpDLFFBQVEsVUFBVSxRQUFRLFlBQVksT0FBTyxJQUFJLE9BQU8sQ0FBQztJQUN6RCxRQUFRLFVBQVUsUUFBUSxZQUFZLE9BQU8sSUFBSSxPQUFPLENBQUM7SUFDekQsUUFBUSxVQUFVLFFBQVEsWUFBWSxPQUFPLElBQUksT0FBTyxDQUFDO0lBQ3pELFFBQVEsVUFBVSxRQUFRLFlBQVksT0FBTyxJQUFJLE9BQU8sQ0FBQztJQUd6RCxVQUFVLEtBQUssdUJBQXVCLE9BQU8sU0FBUyxTQUFTLFNBQVMsT0FBTztJQUMvRSxJQUFJLFNBQVMsR0FBRyxRQUFRLFVBQVU7R0FDdEMsT0FBTztJQUVILFFBQVEsVUFBVSxRQUFRLFlBQVksSUFBSTtJQUMxQyxRQUFRLFVBQVUsUUFBUSxZQUFZLElBQUk7SUFHMUMsSUFBSSxTQUFTLEdBQUcsUUFBUSxNQUFNLFNBQVMsS0FBSztTQUN2QyxRQUFRLEtBQUssU0FBUyxLQUFLO0dBQ3BDO0dBR0EsSUFBSSxTQUFTLEdBQUcsS0FBSyxVQUFVLENBQUMsTUFBTSxTQUFTLE1BQU07UUFDaEQsS0FBSyxVQUFVLENBQUMsS0FBSyxTQUFTLE1BQU07RUFDN0MsQ0FBQztDQUNMO0NBRUEsdUJBQXVCLEdBQUcsU0FBUyxTQUFTLFNBQVMsU0FBUztFQUMxRCxNQUFNLEtBQUssSUFBSTtFQUNmLE1BQU0sS0FBSyxLQUFLO0VBRWhCLE1BQU0sS0FBSyxJQUFJLEtBQUssSUFBSTtFQUN4QixNQUFNLEtBQUssS0FBSztFQUNoQixNQUFNLEtBQUssSUFBSTtFQUNmLE1BQU0sS0FBSyxLQUFLLEtBQUs7RUFFckIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsUUFBUSxLQUNoQyxRQUFRLEtBQUssS0FBSyxRQUFRLEtBQUssTUFBTSxJQUFJLEtBQUssUUFBUSxLQUFLLEtBQUssUUFBUSxLQUFLLEtBQUssSUFBSSxRQUFRO0VBR2xHLE9BQU87Q0FDWDtBQUNKOzs7QUNoSEEsSUFBTSwyQkFBMkIsSUFBSSxLQUFLO0FBQzFDLElBQU0sMkJBQTJCLElBQUksS0FBSztBQUUxQyxJQUFhLFdBQWIsY0FBOEIsS0FBSztDQUMvQixZQUFZLElBQUksRUFBRSxVQUFVLFVBQVUsU0FBUyxPQUFPLEdBQUcsY0FBYyxDQUFDLEdBQUc7RUFDdkUsTUFBTSxJQUFJO0dBQUU7R0FBVTtHQUFTO0VBQUssQ0FBQztFQUNyQyxLQUFLLFdBQVc7RUFDaEIsS0FBSyxVQUFVO0VBQ2YsS0FBSyxrQkFBa0I7Q0FDM0I7Q0FFQSxvQkFBb0I7RUFDaEIsSUFBSSxDQUFDLEtBQUssU0FBUyxPQUFPLFFBQVE7RUFDbEMsTUFBTSxPQUFPLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxHQUFHLEtBQUssS0FBSyxLQUFLLElBQUksS0FBSyxLQUFLLEtBQUssU0FBUyxPQUFPLFNBQVMsQ0FBQyxDQUFDLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztFQUNoSCxLQUFLLGVBQWUsSUFBSSxhQUFhLE9BQU8sT0FBTyxDQUFDO0VBQ3BELEtBQUssa0JBQWtCO0VBQ3ZCLEtBQUssY0FBYyxJQUFJLFFBQVEsS0FBSyxJQUFJO0dBQ3BDLE9BQU8sS0FBSztHQUNaLGlCQUFpQjtHQUNqQixNQUFNLEtBQUssR0FBRztHQUNkLGdCQUFnQixLQUFLLEdBQUcsU0FBUyxXQUFXLEtBQUssR0FBRyxVQUFVLEtBQUssR0FBRztHQUN0RSxXQUFXLEtBQUssR0FBRztHQUNuQixXQUFXLEtBQUssR0FBRztHQUNuQixPQUFPO0dBQ1AsT0FBTztFQUNYLENBQUM7Q0FDTDtDQUVBLGlCQUFpQjtFQUViLEtBQUssU0FBUyxPQUFPLFNBQVMsTUFBTSxNQUFNO0dBRXRDLFNBQVMsU0FBUyxLQUFLLGFBQWEsS0FBSyxXQUFXO0dBQ3BELEtBQUssYUFBYSxJQUFJLFVBQVUsSUFBSSxFQUFFO0VBQzFDLENBQUM7RUFDRCxLQUFLLFlBQVksY0FBYztFQUUvQixLQUFLLFFBQVEsU0FBUyxZQUFZLFFBQVEsS0FBSztFQUMvQyxLQUFLLFFBQVEsU0FBUyxnQkFBZ0IsUUFBUSxLQUFLO0NBQ3ZEO0NBRUEsS0FBSyxFQUFFLFdBQVcsQ0FBQyxHQUFHO0VBQ2xCLElBQUksQ0FBQyxLQUFLLFFBQVEsU0FBUyxhQUN2QixPQUFPLE9BQU8sS0FBSyxRQUFRLFVBQVU7R0FDakMsYUFBYSxFQUFFLE9BQU8sS0FBSyxZQUFZO0dBQ3ZDLGlCQUFpQixFQUFFLE9BQU8sS0FBSyxnQkFBZ0I7RUFDbkQsQ0FBQztFQUdMLEtBQUssZUFBZTtFQUlwQixNQUFNLGVBQWUsS0FBSztFQUMxQixLQUFLLGNBQWM7RUFFbkIsTUFBTSxLQUFLLEVBQUUsT0FBTyxDQUFDO0VBR3JCLEtBQUssY0FBYztDQUN2QjtBQUNKOzs7QUM3REEsSUFBYSxnQkFBYixjQUFtQyxLQUFLO0NBQ3BDLFlBQVksR0FBRyxNQUFNO0VBQ2pCLE1BQU0sR0FBRyxJQUFJO0VBR2IsS0FBSyxnQkFBZ0I7RUFDckIsS0FBSyxrQkFBa0I7Q0FDM0I7Q0FFQSxpQkFBaUI7RUFDYixLQUFLLHFCQUFxQjtFQUMxQixLQUFLLDhCQUE4QjtFQUNuQyxLQUFLLHFCQUFxQjtFQUMxQixLQUFLLHNCQUFzQjtFQUMzQixLQUFLLHFCQUFxQjtFQUcxQixJQUFJLENBQUMsS0FBSyxTQUFTLFdBQVcsZ0JBQzFCLFFBQVEsTUFBTSxRQUFRLEtBQUssT0FBTyxJQUFJLEtBQUssS0FBSyxNQUFNLEdBQUcseURBQXlEO0VBR3RILE1BQU0sYUFBYSxLQUFLLFNBQVMsV0FBVyxlQUFlO0VBQzNELEtBQUsscUJBQXFCLENBQUM7RUFDM0IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxXQUFXLFFBQVEsS0FBSyxJQUFJLEtBQUs7R0FDeEQsTUFBTSxZQUFZLElBQUksVUFBVTtHQUNoQyxVQUFVLFFBQVE7R0FDbEIsVUFBVSxPQUFPLFVBQVUsWUFBWSxDQUFDO0dBQ3hDLFVBQVUsVUFBVTtHQUNwQixLQUFLLG1CQUFtQixLQUFLLFNBQVM7R0FFdEMsVUFBVSxVQUFVLEtBQUssTUFBTTtFQUNuQztFQUNBLEtBQUsscUJBQXFCLEtBQUssbUJBQW1CO0VBR2xELElBQUksQ0FBQyxDQUFDLEtBQUssU0FBUyxXQUFXLHFCQUFxQjtHQUNoRCxNQUFNLGVBQWUsS0FBSyxTQUFTLFdBQVcsb0JBQW9CO0dBQ2xFLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksYUFBYSxRQUFRLEtBQUssR0FBRyxLQUNwRCxLQUFLLG1CQUFtQixFQUFFLENBQUMsZUFBZSxJQUFJLEtBQUssQ0FBQyxDQUFDLFVBQVUsY0FBYyxDQUFDO0VBRXRGO0VBRUEsS0FBSyx1QkFBdUIsRUFBRSxhQUFhO0dBRXZDLEtBQUsscUJBQXFCLENBQUM7R0FDM0IsS0FBSyxtQkFBbUIsU0FBUyxjQUFjO0lBQzNDLElBQUksQ0FBQyxPQUFPLHNCQUFzQixNQUFNLFVBQVUsV0FBVyxHQUFHO0lBQ2hFLEtBQUssbUJBQW1CLEtBQUssU0FBUztHQUMxQyxDQUFDO0dBR0QsS0FBSyxtQkFBbUIsU0FBUyxXQUFXLE1BQU07SUFDOUMsVUFBVSxPQUFPLFFBQVEsS0FBSyxTQUFTLFdBQVcsZUFBZSxNQUFNLElBQUksRUFBRTtJQUc3RSxJQUFJLFVBQVUsY0FBYztLQUN4QixVQUFVLGFBQWEsUUFBUSxLQUFLLFNBQVMsV0FBVyxvQkFBb0IsTUFBTSxJQUFJLENBQUM7S0FDdkYsS0FBSyxTQUFTLFdBQVcsb0JBQW9CLGNBQWM7SUFDL0Q7R0FDSixDQUFDO0dBQ0QsS0FBSyxTQUFTLGlCQUFpQixLQUFLLG1CQUFtQjtHQUN2RCxLQUFLLFNBQVMsV0FBVyxlQUFlLGNBQWM7RUFDMUQ7RUFFQSxLQUFLLGVBQWUsS0FBSyxtQkFBbUI7Q0FDaEQ7Q0FFQSxvQkFBb0I7RUFDaEIsS0FBSyxnQkFBZ0IsS0FBSyxtQkFBbUI7RUFDN0MsS0FBSyxTQUFTLGlCQUFpQixLQUFLO0VBQ3BDLEtBQUssbUJBQW1CLFNBQVMsV0FBVyxNQUFNO0dBQzlDLFVBQVUsT0FBTyxRQUFRLEtBQUssU0FBUyxXQUFXLGVBQWUsTUFBTSxJQUFJLEVBQUU7R0FHN0UsSUFBSSxVQUFVLGNBQWM7SUFDeEIsVUFBVSxhQUFhLFFBQVEsS0FBSyxTQUFTLFdBQVcsb0JBQW9CLE1BQU0sSUFBSSxDQUFDO0lBQ3ZGLEtBQUssU0FBUyxXQUFXLG9CQUFvQixjQUFjO0dBQy9EO0VBQ0osQ0FBQztFQUNELEtBQUssU0FBUyxXQUFXLGVBQWUsY0FBYztDQUMxRDtBQUNKOzs7QUNsRUEsSUFBTSxhQUFhO0NBQ2YsTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sY0FBYztDQUNkLGFBQWE7Q0FDYixjQUFjO0FBQ2xCO0FBRUEsSUFBTSxZQUFZO0NBQ2QsUUFBUTtDQUNSLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtBQUNWO0FBRUEsSUFBTSxhQUFhO0NBQ2YsVUFBVTtDQUNWLFFBQVE7Q0FDUixTQUFTO0NBQ1QsWUFBWTtDQUNaLFlBQVk7Q0FDWixTQUFTO0NBQ1QsV0FBVztDQUNYLFVBQVU7QUFDZDtBQUVBLElBQU0sYUFBYTtDQUNmLGFBQWE7Q0FDYixVQUFVO0NBQ1YsT0FBTztBQUNYO0FBRUEsSUFBYSxhQUFiLE1BQXdCO0NBQ3BCLE9BQU8sZ0JBQWdCLFNBQVM7RUFDNUIsS0FBSyxlQUFlO0NBQ3hCO0NBRUEsT0FBTyxnQkFBZ0IsU0FBUztFQUM1QixLQUFLLGVBQWU7Q0FDeEI7Q0FFQSxhQUFhLEtBQUssSUFBSSxLQUFLO0VBQ3ZCLE1BQU0sTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJO0VBR3BELE1BQU0sT0FBTyxNQUFNLEtBQUssVUFBVSxHQUFHO0VBRXJDLE9BQU8sS0FBSyxNQUFNLElBQUksTUFBTSxHQUFHO0NBQ25DO0NBRUEsYUFBYSxNQUFNLElBQUksTUFBTSxLQUFLO0VBQzlCLElBQUksS0FBSyxVQUFVLEtBQUEsS0FBYSxLQUFLLE1BQU0sUUFBUSxLQUFLLEdBQ3BELFFBQVEsS0FBSyxpREFBaUQ7RUFFbEUsSUFBSSxLQUFLLG9CQUFvQixTQUFTLDRCQUE0QixLQUFLLENBQUMsS0FBSyxjQUN6RSxRQUFRLEtBQUssK0ZBQStGO0VBRWhILElBQUksS0FBSyxvQkFBb0IsU0FBUyxvQkFBb0IsS0FBSyxDQUFDLEtBQUssY0FDakUsUUFBUSxLQUFLLHVGQUF1RjtFQUd4RyxNQUFNLFVBQVUsTUFBTSxLQUFLLFlBQVksTUFBTSxHQUFHO0VBR2hELEdBQUcsU0FBUyxnQkFBZ0IsSUFBSTtFQUdoQyxNQUFNLGNBQWMsS0FBSyxpQkFBaUIsSUFBSSxNQUFNLE9BQU87RUFHM0QsTUFBTSxTQUFTLE1BQU0sS0FBSyxZQUFZLElBQUksTUFBTSxLQUFLLFdBQVc7RUFFaEUsTUFBTSxXQUFXLEtBQUssY0FBYyxJQUFJLE1BQU0sTUFBTTtFQUdwRCxNQUFNLFlBQVksS0FBSyxlQUFlLElBQUksTUFBTSxRQUFRO0VBR3hELE1BQU0sUUFBUSxLQUFLLFdBQVcsSUFBSSxNQUFNLFdBQVc7RUFHbkQsTUFBTSxTQUFTLE1BQU0sS0FBSyxZQUFZLElBQUksTUFBTSxhQUFhLFdBQVcsS0FBSztFQUc3RSxNQUFNLENBQUMsT0FBTyxXQUFXLEtBQUssV0FBVyxJQUFJLE1BQU0sUUFBUSxPQUFPLE1BQU07RUFHeEUsS0FBSyxjQUFjLE9BQU8sS0FBSztFQUcvQixNQUFNLGFBQWEsS0FBSyxnQkFBZ0IsSUFBSSxNQUFNLE9BQU8sV0FBVztFQUdwRSxNQUFNLFNBQVMsS0FBSyxZQUFZLE1BQU0sS0FBSztFQUMzQyxNQUFNLFFBQVEsT0FBTyxLQUFLO0VBRzFCLE1BQU0sU0FBUyxLQUFLLFlBQVksSUFBSSxNQUFNLE9BQU8sTUFBTTtFQUd2RCxLQUFLLElBQUksSUFBSSxNQUFNLFFBQVEsS0FBSyxHQUFHLEtBQUssSUFBSSxDQUFDLE1BQU0sSUFBSSxNQUFNLE9BQU8sR0FBRyxDQUFDO0VBRXhFLE9BQU87R0FDSCxNQUFNO0dBQ047R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0VBQ0o7Q0FDSjtDQUVBLE9BQU8sVUFBVSxLQUFLO0VBQ2xCLE9BQU8sTUFBTSxLQUFLLEVBQUUsTUFBTSxPQUFPLENBQUMsQ0FBQyxDQUM5QixNQUFNLFFBQVEsSUFBSSxZQUFZLENBQUMsQ0FBQyxDQUNoQyxNQUFNLFNBQVM7R0FDWixNQUFNLGNBQWMsSUFBSSxZQUFZO0dBQ3BDLElBQUksWUFBWSxPQUFPLElBQUksV0FBVyxNQUFNLEdBQUcsQ0FBQyxDQUFDLE1BQU0sUUFDbkQsT0FBTyxLQUFLLFVBQVUsSUFBSTtRQUUxQixPQUFPLEtBQUssTUFBTSxZQUFZLE9BQU8sSUFBSSxDQUFDO0VBRWxELENBQUM7Q0FDVDtDQUdBLE9BQU8sVUFBVSxLQUFLO0VBRWxCLE1BQU0sU0FBUyxJQUFJLFlBQVksS0FBSyxHQUFHLENBQUM7RUFDeEMsSUFBSSxPQUFPLE9BQU8sWUFDZCxNQUFNLElBQUksTUFBTSxxQkFBcUI7T0FDbEMsSUFBSSxPQUFPLE9BQU8sR0FDckIsTUFBTSxJQUFJLE1BQU0scUNBQXFDLE9BQU8sR0FBRyxHQUFHO0VBR3RFLE1BQU0sa0JBQWtCLElBQUksWUFBWSxLQUFLLElBQUksQ0FBQztFQUNsRCxNQUFNLGlCQUFpQjtFQUN2QixNQUFNLGlCQUFpQixnQkFBZ0I7RUFDdkMsSUFBSSxnQkFBZ0IsT0FBTyxZQUN2QixNQUFNLElBQUksTUFBTSx3QkFBd0I7RUFJNUMsTUFBTSxXQUFXLElBQUksWUFBWSxDQUFDLENBQUMsT0FBTyxJQUFJLE1BQU0sZ0JBQWdCLGlCQUFpQixjQUFjLENBQUM7RUFDcEcsTUFBTSxPQUFPLEtBQUssTUFBTSxRQUFRO0VBRWhDLElBQUksaUJBQWlCLG1CQUFtQixJQUFJLFlBQVksT0FBTztFQUUvRCxNQUFNLG9CQUFvQixJQUFJLFlBQVksS0FBSyxpQkFBaUIsZ0JBQWdCLENBQUM7RUFDakYsSUFBSSxrQkFBa0IsT0FBTyxTQUN6QixNQUFNLElBQUksTUFBTSx3QkFBd0I7RUFHNUMsTUFBTSxtQkFBbUIsaUJBQWlCLGlCQUFpQjtFQUMzRCxNQUFNLG1CQUFtQixrQkFBa0I7RUFDM0MsTUFBTSxTQUFTLElBQUksTUFBTSxrQkFBa0IsbUJBQW1CLGdCQUFnQjtFQUU5RSxLQUFLLFFBQVEsRUFBRSxDQUFDLFNBQVM7RUFDekIsT0FBTztDQUNYO0NBR0EsT0FBTyxXQUFXLEtBQUssS0FBSztFQUV4QixJQUFJLE9BQU8sUUFBUSxZQUFZLFFBQVEsSUFBSSxPQUFPO0VBR2xELElBQUksZ0JBQWdCLEtBQUssR0FBRyxLQUFLLE1BQU0sS0FBSyxHQUFHLEdBQzNDLE1BQU0sSUFBSSxRQUFRLDJCQUEyQixJQUFJO0VBSXJELElBQUksbUJBQW1CLEtBQUssR0FBRyxHQUFHLE9BQU87RUFHekMsSUFBSSxnQkFBZ0IsS0FBSyxHQUFHLEdBQUcsT0FBTztFQUd0QyxJQUFJLGFBQWEsS0FBSyxHQUFHLEdBQUcsT0FBTztFQUduQyxPQUFPLE1BQU07Q0FDakI7Q0FFQSxPQUFPLFlBQVksTUFBTSxLQUFLO0VBQzFCLElBQUksQ0FBQyxLQUFLLFNBQVMsT0FBTztFQUMxQixPQUFPLFFBQVEsSUFDWCxLQUFLLFFBQVEsS0FBSyxXQUFXO0dBRXpCLElBQUksT0FBTyxRQUFRLE9BQU8sT0FBTztHQUNqQyxNQUFNLE1BQU0sS0FBSyxXQUFXLE9BQU8sS0FBSyxHQUFHO0dBQzNDLE9BQU8sTUFBTSxLQUFLLEVBQUUsTUFBTSxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sUUFBUSxJQUFJLFlBQVksQ0FBQztFQUN2RSxDQUFDLENBQ0w7Q0FDSjtDQUVBLE9BQU8saUJBQWlCLElBQUksTUFBTSxTQUFTO0VBQ3ZDLElBQUksQ0FBQyxLQUFLLGFBQWEsT0FBTztFQUM5QixNQUFNLGNBQWMsS0FBSztFQUV6QixLQUFLLFVBQ0QsS0FBSyxPQUFPLFNBQVMsRUFBRSxpQkFBaUI7R0FDcEMsV0FBVyxTQUFTLEVBQUUsWUFBWSxTQUFTLGlCQUFpQjtJQUV4RCxLQUFLLE1BQU0sUUFBUSxZQUFZO0tBQzNCLE1BQU0sV0FBVyxLQUFLLFVBQVUsV0FBVztLQUMzQyxJQUFJLFNBQVMsZUFBZSxLQUFBLEtBQWEsQ0FBQyxDQUFDLFlBRW5DO1VBQUEsV0FBVyw0QkFBNEI7T0FDdkMsU0FBUyxhQUFhLFdBQVcsMkJBQTJCO09BQzVELFlBQVksU0FBUyxXQUFXLENBQUMsVUFBVTtNQUMvQzs7S0FFSixZQUFZLFNBQVMsV0FBVyxDQUFDLGNBQWM7SUFDbkQ7SUFFQSxJQUFJLFlBQVksS0FBQSxHQUFXO0tBQ3ZCLE1BQU0sV0FBVyxLQUFLLFVBQVU7S0FDaEMsSUFBSSxTQUFTLGVBQWUsS0FBQSxLQUFhLENBQUMsQ0FBQyxZQUVuQztVQUFBLFdBQVcsNEJBQTRCO09BQ3ZDLFNBQVMsYUFBYSxXQUFXLDJCQUEyQjtPQUM1RCxZQUFZLFNBQVMsV0FBVyxDQUFDLFVBQVU7TUFDL0M7O0tBRUosWUFBWSxTQUFTLFdBQVcsQ0FBQyxjQUFjO0tBRy9DLFlBQVksU0FBUyxXQUFXLENBQUMsU0FBUyxHQUFHO0lBQ2pEO0dBQ0osQ0FBQztFQUNMLENBQUM7RUFHTCxLQUFLLFVBQVUsU0FBUyxFQUFFLFlBQVksaUJBQWlCLG9CQUFvQjtHQUN2RSxJQUFJLG9CQUFvQixLQUFBLEdBQVc7R0FDbkMsWUFBWSxnQkFBZ0IsQ0FBQyxnQkFBZ0I7RUFDakQsQ0FBQztFQUdELEtBQUssVUFDRCxLQUFLLE9BQU8sU0FBUyxFQUFFLEtBQUssWUFBWSxpQkFBaUIsZUFBZTtHQUNwRSxJQUFJLG9CQUFvQixLQUFBLEdBQVc7R0FDbkMsWUFBWSxnQkFBZ0IsQ0FBQyxXQUFXO0VBQzVDLENBQUM7RUFHTCxZQUFZLFNBRUosRUFDSSxRQUFRLGFBQ1IsYUFBYSxHQUNiLFlBQ0EsWUFDQSxTQUFTLEdBQUcsY0FDWixNQUNBLFlBQ0EsUUFFQSxlQUNBLFVBQ0EsYUFDQSxXQUVKLE1BQ0M7R0FDRCxZQUFZLEVBQUUsQ0FBQyxPQUFPLFFBQVEsWUFBWSxDQUFDLE1BQU0sWUFBWSxhQUFhLFVBQVU7R0FFcEYsSUFBSSxDQUFDLGVBQWUsU0FBUztHQUU3QixNQUFNLFNBQVMsR0FBRyxhQUFhO0dBQy9CLEdBQUcsV0FBVyxRQUFRLE1BQU07R0FDNUIsR0FBRyxTQUFTLE1BQU0sY0FBYztHQUNoQyxHQUFHLFdBQVcsUUFBUSxZQUFZLEVBQUUsQ0FBQyxNQUFNLEdBQUcsV0FBVztHQUN6RCxZQUFZLEVBQUUsQ0FBQyxTQUFTO0VBQzVCLENBQ0o7RUFFQSxPQUFPO0NBQ1g7Q0FFQSxPQUFPLFlBQVksSUFBSSxNQUFNLEtBQUssYUFBYTtFQUMzQyxJQUFJLENBQUMsS0FBSyxRQUFRLE9BQU87RUFDekIsT0FBTyxRQUFRLElBQ1gsS0FBSyxPQUFPLElBQUksT0FBTyxFQUFFLEtBQUssWUFBWSxpQkFBaUIsVUFBVSxXQUFXO0dBQzVFLElBQUksYUFBYSxjQUFjO0lBQzNCLE1BQU0sRUFBRSxTQUFTLFlBQVk7SUFFN0IsT0FBTyxNQURhLEtBQUssYUFBYSxhQUFhLElBQUk7R0FFM0Q7R0FHQSxNQUFNLFFBQVEsSUFBSSxNQUFNO0dBQ3hCLE1BQU0sT0FBTztHQUNiLElBQUksS0FDQSxNQUFNLE1BQU0sS0FBSyxXQUFXLEtBQUssR0FBRztRQUNqQyxJQUFJLG9CQUFvQixLQUFBLEdBQVc7SUFDdEMsTUFBTSxFQUFFLFNBQVMsWUFBWTtJQUM3QixNQUFNLE9BQU8sSUFBSSxLQUFLLENBQUMsSUFBSSxHQUFHLEVBQUUsTUFBTSxTQUFTLENBQUM7SUFDaEQsTUFBTSxNQUFNLElBQUksZ0JBQWdCLElBQUk7R0FDeEM7R0FDQSxNQUFNLFFBQVEsSUFBSSxTQUFTLFFBQVE7SUFDL0IsTUFBTSxlQUFlLElBQUk7R0FDN0IsQ0FBQztHQUNELE9BQU87RUFDWCxDQUFDLENBQ0w7Q0FDSjtDQUVBLE9BQU8sY0FBYyxJQUFJLE1BQU0sUUFBUTtFQUNuQyxJQUFJLENBQUMsS0FBSyxVQUFVLE9BQU87RUFDM0IsT0FBTyxLQUFLLFNBQVMsS0FBSyxnQkFBZ0IsS0FBSyxjQUFjLElBQUksTUFBTSxRQUFRLFdBQVcsQ0FBQztDQUMvRjtDQUVBLE9BQU8sY0FBYyxJQUFJLE1BQU0sUUFBUSxFQUFFLFNBQVMsY0FBYyxRQUFRLGFBQWEsTUFBTSxZQUFZLFVBQVU7RUFDN0csSUFBSSxnQkFBZ0IsS0FBQSxLQUFhLENBQUMsQ0FBQyxZQUFZO0dBRTNDLElBQUksV0FBVyxrQkFBa0IsY0FBYyxXQUFXLGlCQUFpQjtHQUczRSxJQUFJLFdBQVcsb0JBQW9CLGNBQWMsV0FBVyxtQkFBbUI7RUFDbkY7RUFFQSxNQUFNLFFBQVEsT0FBTztFQUNyQixJQUFJLE1BQU0sU0FBUyxPQUFPLE1BQU07RUFFaEMsTUFBTSxVQUFVO0dBQ1osT0FBTztHQUNQLE9BQU8sR0FBRztHQUNWLE9BQU8sR0FBRztFQUNkO0VBQ0EsTUFBTSxVQUFVLGlCQUFpQixLQUFBLElBQVksS0FBSyxTQUFTLGdCQUFnQjtFQUMzRSxJQUFJLFNBQ0E7R0FBQztHQUFhO0dBQWE7R0FBUztFQUFPLENBQUMsQ0FBQyxTQUFTLFNBQVM7R0FDM0QsSUFBSSxRQUFRLE9BQU8sUUFBUSxRQUFRLFFBQVE7RUFDL0MsQ0FBQztFQUlMLElBQUksTUFBTSxTQUFTO0dBQ2YsUUFBUSxRQUFRO0dBQ2hCLFFBQVEsaUJBQWlCLE1BQU07R0FDL0IsSUFBSSxNQUFNLHFCQUFxQjtJQUMzQixRQUFRLGtCQUFrQjtJQUMxQixJQUFJLE1BQU0sU0FBUyxHQUFHLEtBQUssWUFBWSxHQUFHO0dBQzlDO0dBQ0EsTUFBTSxVQUFVLElBQUksUUFBUSxJQUFJLE9BQU87R0FDdkMsUUFBUSxPQUFPO0dBQ2YsTUFBTSxVQUFVO0dBQ2hCLE9BQU87RUFDWDtFQUVBLE1BQU0sVUFBVSxJQUFJLFFBQVEsSUFBSSxPQUFPO0VBQ3ZDLFFBQVEsT0FBTztFQUNmLE1BQU0sVUFBVTtFQUNoQixNQUFNLE1BQU0sV0FBVztHQUNuQixRQUFRLFFBQVE7RUFDcEIsQ0FBQztFQUVELE9BQU87Q0FDWDtDQUVBLE9BQU8sZUFBZSxJQUFJLE1BQU0sVUFBVTtFQUN0QyxJQUFJLENBQUMsS0FBSyxXQUFXLE9BQU87RUFDNUIsT0FBTyxLQUFLLFVBQVUsS0FDakIsRUFDRyxNQUNBLFlBQ0EsUUFDQSx1QkFBdUIsQ0FBQyxHQUN4QixlQUNBLGtCQUNBLGlCQUNBLGlCQUFpQjtHQUFDO0dBQUc7R0FBRztFQUFDLEdBQ3pCLFlBQVksVUFDWixjQUFjLElBQ2QsY0FBYyxZQUNaO0dBQ0YsTUFBTSxFQUNGLGtCQUFrQjtJQUFDO0lBQUc7SUFBRztJQUFHO0dBQUMsR0FDN0Isa0JBQ0EsaUJBQWlCLEdBQ2pCLGtCQUFrQixHQUNsQiw2QkFHQTtHQUVKLElBQUksa0JBQ0EsaUJBQWlCLFVBQVUsU0FBUyxpQkFBaUI7R0FHekQsSUFBSSxlQUNBLGNBQWMsVUFBVSxTQUFTLGNBQWM7R0FJbkQsSUFBSSwwQkFDQSx5QkFBeUIsVUFBVSxTQUFTLHlCQUF5QjtHQUd6RSxJQUFJLGtCQUNBLGlCQUFpQixVQUFVLFNBQVMsaUJBQWlCO0dBSXpELElBQUksaUJBQ0EsZ0JBQWdCLFVBQVUsU0FBUyxnQkFBZ0I7R0FJdkQsT0FBTztJQUNIO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtHQUNKO0VBQ0osQ0FDSjtDQUNKO0NBRUEsT0FBTyxXQUFXLElBQUksTUFBTSxhQUFhO0VBQ3JDLElBQUksQ0FBQyxLQUFLLE9BQU8sT0FBTztFQUN4QixPQUFPLEtBQUssTUFBTSxLQUNiLEVBQ0cscUJBQ0EsVUFDQSxhQUlFO0dBQ0YsT0FBTztJQUNILHFCQUFxQixLQUFLLGNBQWMscUJBQXFCLE1BQU0sV0FBVztJQUM5RTtJQUNBO0dBQ0o7RUFDSixDQUNKO0NBQ0o7Q0FFQSxPQUFPLFlBQVksSUFBSSxNQUFNLGFBQWEsV0FBVyxPQUFPO0VBQ3hELElBQUksQ0FBQyxLQUFLLFFBQVEsT0FBTztFQUN6QixPQUFPLFFBQVEsSUFDWCxLQUFLLE9BQU8sSUFDUixPQUNJLEVBQ0ksWUFDQSxTQUNBLE1BQ0EsWUFDQSxTQUFTLENBQUMsS0FFZCxjQUNDO0dBSUQsSUFBSSxlQUFlO0dBQ25CLElBQUksY0FBYyxDQUFDO0dBQ25CLElBQUksYUFBYTtHQUNqQixLQUFLLFNBQ0QsS0FBSyxNQUFNLFNBQVMsRUFBRSxNQUFNLE1BQU0sYUFBYTtJQUMzQyxJQUFJLFNBQVMsV0FBVztLQUNwQjtLQUNBLElBQUksU0FBUyxLQUFBLEdBQVcsWUFBWSxLQUFLLElBQUk7S0FDN0MsSUFBSSxVQUFVLE9BQU8sdUJBQXVCLGFBQWE7SUFDN0Q7R0FDSixDQUFDO0dBSUwsSUFBSSxDQUhVLENBQUMsWUFBWSxRQUdmO0lBQ1IsYUFBYSxNQUFNLFFBQVEsSUFDdkIsWUFBWSxJQUFJLE9BQU8sY0FBYztLQUNqQyxRQUFRLE1BQU0sS0FBSyxnQkFBZ0IsSUFBSSxZQUFZLE1BQU0sYUFBYSxXQUFXLEdBQUcsVUFBVSxFQUFBLENBQUcsS0FBSyxFQUFFLFVBQVUsU0FBUyxXQUFXO01BQ2xJLE1BQU0sT0FBTyxJQUFJLFNBQVMsSUFBSTtPQUFFLFVBQVUsTUFBTTtPQUFZO09BQVU7T0FBUztNQUFLLENBQUM7TUFDckYsS0FBSyxPQUFPO01BQ1osS0FBSyxTQUFTO01BQ2QsSUFBSSxZQUFZLEtBQUssYUFBYTtNQUVsQyxLQUFLLGdCQUFnQjtNQUNyQixPQUFPO0tBQ1gsQ0FBQztJQUNMLENBQUMsQ0FDTDtJQUVBLFdBQVcsZ0JBQWdCO0lBQzNCLFdBQVcsZUFBZTtHQUM5QixPQUNJLGNBQWMsTUFBTSxLQUFLLGdCQUFnQixJQUFJLFlBQVksTUFBTSxhQUFhLFdBQVcsY0FBYyxVQUFVLEVBQUEsQ0FBRyxLQUFLLEVBQUUsVUFBVSxTQUFTLFdBQVc7SUFHbkosTUFBTSxPQUFPLEtBRFcsU0FBUyxXQUFXLGlCQUFpQixnQkFBZ0IsTUFDNUMsSUFBSTtLQUFFO0tBQVU7S0FBUztJQUFLLENBQUM7SUFDaEUsS0FBSyxPQUFPO0lBQ1osS0FBSyxTQUFTO0lBQ2QsSUFBSSxZQUFZLEtBQUssYUFBYTtJQUVsQyxLQUFLLGVBQWU7SUFDcEIsT0FBTztHQUNYLENBQUM7R0FHTCxPQUFPO0lBQ0g7SUFDQTtJQUNBO0dBQ0o7RUFDSixDQUNKLENBQ0o7Q0FDSjtDQUVBLE9BQU8sZ0JBQWdCLElBQUksWUFBWSxNQUFNLGFBQWEsV0FBVyxjQUFjLFlBQVk7RUFDM0YsT0FBTyxRQUFRLElBQ1gsV0FBVyxJQUNQLE9BQU8sRUFDSCxZQUNBLFNBQ0EsVUFBVSxlQUNWLE9BQU8sR0FDUCxTQUNBLFlBQ0EsYUFDRTtHQUVGLE1BQU0sVUFBVSxJQUFJLGNBQWMsRUFBRTtHQUNwQyxJQUFJLGtCQUFrQixLQUFBLEdBQ2xCLFFBQVEsZUFBZSxVQUFVO0dBR3JDLE1BQU0sV0FBVyxJQUFJLFNBQVMsRUFBRTtHQUNoQyxJQUFJLFFBQVEsU0FBUyxTQUFTO0dBQzlCLElBQUksWUFBWSxTQUFTLGFBQWE7R0FHdEMsSUFBSSxjQUFjLFdBQVcsNEJBQTRCO0lBQ3JELE1BQU0sa0JBQWtCLFdBQVcsMkJBQTJCO0lBQzlELE1BQU0sbUJBQW1CLFdBQVcsMkJBQTJCO0lBQy9ELE1BQU0sZUFBZSxDQUFDO0lBQ3RCLE1BQU0sbUJBQW1CLENBQUM7SUFDMUIsTUFBTSx1QkFBdUIsQ0FBQztJQUM5QixNQUFNLHlCQUF5QixDQUFDO0lBRWhDLEtBQUssTUFBTSxRQUFRLFlBQVk7S0FDM0IsTUFBTSxXQUFXLEtBQUssVUFBVSxXQUFXO0tBQzNDLE1BQU0sZ0JBQWdCLFdBQVc7S0FDakMsYUFBYSxpQkFBaUIsaUJBQWlCO0tBQy9DLGlCQUFpQixpQkFBaUIsU0FBUztLQUMzQyxxQkFBcUIsaUJBQWlCLFdBQVcsU0FBUyxjQUFjLENBQUM7S0FDekUsdUJBQXVCLGlCQUFpQixTQUFTLGVBQWU7SUFDcEU7SUFFQSxNQUFNLEVBQUUsU0FBUyxZQUFZO0lBQzdCLE1BQU0sZUFBZSxNQUFNLEtBQUssYUFBYSxlQUFlLE1BQU07S0FDOUQsY0FBYztLQUNkLGdCQUFnQjtJQUNwQixDQUFDO0lBR0QsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGFBQWEsV0FBVyxRQUFRLEtBQUs7S0FDckQsTUFBTSxTQUFTLGFBQWEsV0FBVztLQUN2QyxNQUFNLE9BQU8sT0FBTztLQUNwQixNQUFNLE9BQU8sT0FBTztLQUNwQixNQUFNLE9BQU8sT0FBTztLQUNwQixNQUFNLE9BQU8saUJBQWlCO0tBQzlCLE1BQU0sYUFBYSx1QkFBdUI7S0FHMUMsTUFBTSxTQUFTLEdBQUcsYUFBYTtLQUMvQixHQUFHLFdBQVcsR0FBRyxjQUFjLE1BQU07S0FDckMsR0FBRyxTQUFTLE1BQU0sY0FBYztLQUNoQyxHQUFHLFdBQVcsR0FBRyxjQUFjLE1BQU0sR0FBRyxXQUFXO0tBRW5ELFNBQVMsYUFBYSxNQUFNO01BQ3hCO01BQ0E7TUFDQTtNQUNBO01BQ0E7S0FDSixDQUFDO0lBQ0w7SUFHQSxJQUFJLGFBQWEsT0FBTztLQUNwQixNQUFNLE9BQU8sYUFBYSxNQUFNO0tBQ2hDLE1BQU0sT0FBTyxhQUFhLE1BQU07S0FHaEMsTUFBTSxTQUFTLEdBQUcsYUFBYTtLQUMvQixHQUFHLFdBQVcsR0FBRyxzQkFBc0IsTUFBTTtLQUM3QyxHQUFHLFNBQVMsTUFBTSxjQUFjO0tBQ2hDLEdBQUcsV0FBVyxHQUFHLHNCQUFzQixNQUFNLEdBQUcsV0FBVztLQUUzRCxTQUFTLGFBQWEsU0FBUztNQUMzQjtNQUNBO01BQ0EsTUFBTTtNQUNOLFlBQVk7TUFDWjtLQUNKLENBQUM7SUFDTDtHQUNKLE9BQU87SUFFSCxLQUFLLE1BQU0sUUFBUSxZQUNmLFNBQVMsYUFBYSxXQUFXLE9BQU8sS0FBSyxjQUFjLFdBQVcsT0FBTyxNQUFNLFdBQVcsQ0FBQztJQUluRyxJQUFJLFlBQVksS0FBQSxHQUNaLFNBQVMsYUFBYSxTQUFTLEtBQUssY0FBYyxTQUFTLE1BQU0sV0FBVyxDQUFDO0dBRXJGO0dBSUEsSUFBSSxlQUFlLEdBQ2YsU0FBUyxhQUFhLGtCQUFrQjtJQUNwQyxXQUFXO0lBQ1gsTUFBTTtJQUNOLE1BQU0sSUFBSSxhQUFhLGVBQWUsRUFBRTtHQUM1QyxDQUFDO0dBS0wsSUFBSSxZQUNBLFNBQVMsYUFBYSx1QkFBdUI7SUFDekMsV0FBVztJQUNYLE1BQU07SUFDTixNQUFNLElBQUksYUFBYSxlQUFlLENBQUM7R0FDM0MsQ0FBQztHQUdMLE9BQU87SUFDSDtJQUNBO0lBQ0E7R0FDSjtFQUNKLENBQ0osQ0FDSjtDQUNKO0NBRUEsT0FBTyxjQUFjLE9BQU8sTUFBTSxhQUFhO0VBSTNDLE1BQU0sRUFDRixZQUFZLGlCQUNaLGFBQWEsR0FDYixlQUNBLGFBQWEsT0FDYixPQUNBLE1BQ0EsS0FDQSxLQUNBLFdBSUEsS0FBSyxVQUFVO0VBRW5CLE1BQU0sRUFDRixNQUNBLFFBQ0EsWUFBWSxtQkFBbUIsR0FFL0IsYUFBYSxHQUNiLFdBSUEsWUFBWTtFQUVoQixNQUFNLE9BQU8sVUFBVTtFQUd2QixNQUFNLFlBQVksV0FBVztFQUU3QixNQUFNLGtCQUFrQixhQURILFVBQVU7RUFFL0IsTUFBTSxnQkFBZ0IsQ0FBQyxDQUFDLGNBQWMsb0JBQW9CO0VBRTFELElBQUk7RUFHSixJQUFJLGVBQWU7R0FFZixNQUFNLFlBQVksSUFBSSxVQUFVLE1BQU0sVUFBVTtHQUtoRCxlQUFlLElBQUksVUFBVSxRQUFRLElBQUk7R0FHekMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE9BQU8sS0FBSztJQUM1QixNQUFNLFFBQVEsa0JBQWtCO0lBQ2hDLE1BQU0sTUFBTSxRQUFRO0lBQ3BCLGFBQWEsSUFBSSxVQUFVLE1BQU0sT0FBTyxHQUFHLEdBQUcsSUFBSSxJQUFJO0dBQzFEO0VBQ0osT0FFSSxlQUFlLElBQUksVUFBVSxNQUFNLFlBQVksUUFBUSxJQUFJO0VBSS9ELE9BQU87R0FDSCxNQUFNO0dBQ047R0FDQSxNQUFNO0dBQ047R0FDQTtHQUNBLFFBQVE7R0FDUixRQUFRO0dBQ1I7R0FDQTtHQUNBO0VBQ0o7Q0FDSjtDQUVBLE9BQU8sV0FBVyxJQUFJLE1BQU0sUUFBUSxPQUFPLFFBQVE7RUFDL0MsSUFBSSxDQUFDLEtBQUssT0FBTyxPQUFPO0VBQ3hCLE1BQU0sVUFBVSxDQUFDO0VBQ2pCLE1BQU0sUUFBUSxLQUFLLE1BQU0sS0FDcEIsRUFDRyxRQUNBLFVBQ0EsTUFBTSxXQUNOLFFBQ0EsTUFBTSxXQUNOLFVBQ0EsT0FDQSxhQUNBLFNBQ0EsTUFDQSxZQUNBLGFBQ0U7R0FDRixNQUFNLFdBQVcsV0FBVyxLQUFBO0dBRTVCLE1BQU0sT0FBTyxXQUFXLElBQUksT0FBTyxFQUFFLElBQUksSUFBSSxVQUFVO0dBRXZELElBQUksVUFBVTtJQUVWLE1BQU0sYUFBYSxLQUFLLFFBQVE7SUFDaEMsSUFBSSxXQUFXLFNBQVMsZUFBZTtLQUNuQyxNQUFNLEVBQUUsTUFBTSxLQUFLLE9BQU8sTUFBTSxNQUFNLFFBQVEsV0FBVztLQUN6RCxLQUFLLFlBQVk7TUFBRSxLQUFLLE9BQU8sTUFBTSxLQUFLO01BQUs7TUFBTTtLQUFJLENBQUM7SUFDOUQsT0FBTztLQUNILE1BQU0sRUFBRSxNQUFNLE1BQU0sT0FBTyxNQUFNLE1BQU0sUUFBUSxXQUFXO0tBQzFELEtBQUssYUFBYTtNQUFFO01BQU07TUFBSyxNQUFNLENBQUM7TUFBTSxPQUFPO01BQU0sS0FBSyxDQUFDO01BQU0sUUFBUTtLQUFLLENBQUM7SUFDdkY7SUFDQSxRQUFRLEtBQUssSUFBSTtHQUNyQjtHQUVBLElBQUksTUFBTSxLQUFLLE9BQU87R0FDdEIsSUFBSSxRQUFRLEtBQUssU0FBUztHQUMxQixJQUFJLFlBQVksS0FBSyxhQUFhO0dBR2xDLElBQUksVUFBVSxPQUFPLG9CQUFvQixLQUFBLEdBQ3JDLE9BQU8sZ0JBQWdCLFVBQVUsS0FBSyxjQUFjLElBQUksTUFBTSxRQUFRLEVBQUUsUUFBUSxPQUFPLGdCQUFnQixNQUFNLENBQUM7R0FJbEgsSUFBSSxRQUFRO0lBQ1IsS0FBSyxPQUFPLEtBQUssTUFBTTtJQUN2QixLQUFLLFVBQVU7R0FDbkIsT0FBTztJQUNILElBQUksVUFBVSxLQUFLLFdBQVcsS0FBSyxRQUFRO0lBQzNDLElBQUksT0FBTyxLQUFLLE1BQU0sS0FBSyxLQUFLO0lBQ2hDLElBQUksYUFBYSxLQUFLLFNBQVMsS0FBSyxXQUFXO0lBQy9DLEtBQUssYUFBYTtHQUN0QjtHQUdBLElBQUksY0FBYztHQUNsQixJQUFJLGtCQUFrQjtHQUN0QixJQUFJLG9CQUFvQjtHQUN4QixJQUFJLFNBQVMsY0FBYyxLQUFBO0dBRzNCLElBQUksY0FBYyxLQUFBLEdBQVc7SUFDekIsSUFBSSxRQUFRO0tBQ1IsT0FBTyxVQUFVLENBQUMsV0FBVyxPQUFPLFVBQVUsQ0FBQyxXQUFXLGNBQWMsQ0FBQyxTQUFTLFNBQVM7TUFDdkYsSUFBSSxRQUFRLE9BQU8sT0FBTyxLQUFLLFFBQVEsTUFBTTtNQUM3QyxLQUFLLFVBQVUsSUFBSTtLQUN2QixDQUFDO0tBQ0QsT0FBTyxVQUFVLENBQUMsV0FBVztLQUU3QixJQUFJLE9BQU8sVUFBVSxDQUFDLFdBQVcsa0JBQWtCLE9BQU8sVUFBVSxDQUFDLFdBQVcsY0FBYztNQUMxRixPQUFPLE9BQU8sVUFBVSxDQUFDLFdBQVc7TUFDcEMsT0FBTyxPQUFPLFVBQVUsQ0FBQyxXQUFXO0tBQ3hDO0lBQ0osT0FDSSxPQUFPLFVBQVUsQ0FBQyxXQUFXLFNBQVMsU0FBUztLQUMzQyxJQUFJLFFBQVEsT0FBTyxPQUFPLEtBQUssUUFBUSxNQUFNO0tBRzdDLElBQUksS0FBSyxTQUFTLGFBQWE7TUFDM0IsY0FBYztNQUNkLElBQUksQ0FBQyxLQUFLLGVBQ04sS0FBSyxnQkFBZ0I7V0FFckIsa0JBQWtCO01BRXRCLElBQUksS0FBSyxTQUFTLFdBQVcsZ0JBQWdCO09BQ3pDLG9CQUFvQjtPQUNwQixLQUFLLE9BQU8sUUFBUSxLQUFLLFNBQVMsV0FBVyxlQUFlLE1BQU0sS0FBSyxnQkFBZ0IsRUFBRTtNQUM3RjtNQUVBLElBQUksS0FBSyxTQUFTLFdBQVcscUJBQ3pCLEtBQUssU0FBUyxXQUFXLG9CQUFvQixLQUFLLElBQUksT0FBTyx1QkFBdUIsS0FBSyxnQkFBZ0IsQ0FBQztNQUc5RyxLQUFLO01BRUwsSUFBSSxLQUFLLGtCQUFrQixLQUFLLGNBQWM7T0FFMUMsT0FBTyxLQUFLO09BQ1osT0FBTyxLQUFLO09BRVosSUFBSSxLQUFLLFNBQVMsV0FBVyxnQkFDekIsS0FBSyxTQUFTLFdBQVcsZUFBZSxjQUFjO09BRTFELElBQUksS0FBSyxTQUFTLFdBQVcscUJBQ3pCLEtBQUssU0FBUyxXQUFXLG9CQUFvQixjQUFjO01BRW5FO0tBQ0o7S0FHQSxJQUFJLGFBQ0k7VUFBQSxpQkFBaUIsS0FBSyxVQUFVLElBQUk7S0FBQSxPQUV4QyxLQUFLLFVBQVUsSUFBSTtJQUUzQixDQUFDO0dBRVQ7R0FHQSxJQUFJLG1CQUFtQjtJQUVuQixJQUFJLENBQUMsaUJBQWlCLE9BQU87SUFFN0IsS0FBSyxPQUFPLFNBQVM7SUFDckIsS0FBSyxVQUFVO0dBQ25CO0dBRUEsT0FBTztFQUNYLENBQ0o7RUFFQSxLQUFLLE1BQU0sU0FBUyxFQUFFLFdBQVcsQ0FBQyxLQUFLLE1BQU07R0FFekMsU0FBUyxTQUFTLGVBQWU7SUFDN0IsSUFBSSxDQUFDLE1BQU0sYUFBYTtJQUN4QixNQUFNLFdBQVcsQ0FBQyxVQUFVLE1BQU0sRUFBRTtHQUN4QyxDQUFDO0VBQ0wsQ0FBQztFQUdELE9BQU8sU0FBUyxFQUFFLGNBQWMsTUFBTTtHQUNsQyxXQUFXLFNBQVMsV0FBVyxNQUFNO0lBQ2pDLElBQUksVUFBVSxpQkFBaUIsVUFBVSxlQUFlO0dBQzVELENBQUM7RUFDTCxDQUFDO0VBRUQsT0FBTyxDQUFDLE9BQU8sT0FBTztDQUMxQjtDQUVBLE9BQU8sY0FBYyxPQUFPLE9BQU87RUFDL0IsSUFBSSxDQUFDLE9BQU87RUFDWixNQUFNLFNBQVMsU0FBUztHQUNwQixLQUFLLFNBQVMsS0FBSyxPQUFPLEtBQUssR0FBRyxVQUFVO0lBQ3hDLE1BQU0sUUFBUSxNQUFNO0lBQ3BCLE1BQU0sT0FBTztJQUNiLE1BQU0sY0FBYyxJQUFJLEtBQUssR0FBRyxLQUFLLG9CQUFvQixLQUFLLE1BQU0sUUFBUSxLQUFLLFFBQVEsS0FBSyxFQUFFLENBQUM7SUFDakcsT0FBTztHQUNYLENBQUM7R0FDRCxJQUFJLEtBQUssVUFBVSxLQUFLLFdBQVcsTUFBTSxLQUFLO0VBQ2xELENBQUM7Q0FDTDtDQUVBLE9BQU8sZ0JBQWdCLElBQUksTUFBTSxPQUFPLGFBQWE7RUFDakQsSUFBSSxDQUFDLEtBQUssWUFBWSxPQUFPO0VBQzdCLE9BQU8sS0FBSyxXQUFXLEtBRWYsRUFDSSxVQUNBLFVBQ0EsUUFJSixtQkFDQztHQTBDRCxPQUFPO0lBQ0g7SUFDQSxXQUFXLElBQUksY0EzQ04sU0FBUyxLQUNqQixFQUNHLFNBQVMsY0FDVCxhQUdFO0tBQ0YsTUFBTSxFQUNGLE9BQU8sWUFDUCxnQkFBZ0IsVUFDaEIsUUFBUSxnQkFHUixTQUFTO0tBRWIsTUFBTSxFQUNGLE1BQU0sV0FDTixTQUdBO0tBRUosTUFBTSxPQUFPLE1BQU07S0FDbkIsTUFBTSxZQUFZLFdBQVc7S0FDN0IsTUFBTSxRQUFRLEtBQUssY0FBYyxZQUFZLE1BQU0sV0FBVyxDQUFDLENBQUM7S0FDaEUsTUFBTSxTQUFTLEtBQUssY0FBYyxhQUFhLE1BQU0sV0FBVyxDQUFDLENBQUM7S0FHbEUsSUFBSSxDQUFDLEtBQUssWUFBWSxLQUFLLGFBQWEsQ0FBQztLQUN6QyxJQUFJLENBQUMsS0FBSyxXQUFXLFNBQVMsY0FBYyxHQUFHLEtBQUssV0FBVyxLQUFLLGNBQWM7S0FFbEYsT0FBTztNQUNIO01BQ0E7TUFDQTtNQUNBO01BQ0E7S0FDSjtJQUNKLENBSzZCLENBQUk7R0FDckM7RUFDSixDQUNKO0NBQ0o7Q0FFQSxPQUFPLFlBQVksTUFBTSxPQUFPO0VBQzVCLElBQUksQ0FBQyxLQUFLLFFBQVEsT0FBTztFQUN6QixPQUFPLEtBQUssT0FBTyxLQUNkLEVBQ0csT0FBTyxlQUFlLENBQUMsR0FDdkIsTUFDQSxZQUNBLGFBQ0U7R0FDRixNQUFNLFFBQVEsYUFBYSxRQUFRLEtBQUssTUFBTTtJQUUxQyxJQUFJLE1BQU0sSUFBSSxJQUFJLEtBQUssTUFBTSxFQUFFO0lBQy9CLE9BQU87R0FDWCxHQUFHLENBQUMsQ0FBQztHQUNMLE1BQU0sU0FBUztHQUNmLE9BQU87RUFDWCxDQUNKO0NBQ0o7Q0FFQSxPQUFPLFlBQVksSUFBSSxNQUFNLE9BQU8sUUFBUTtFQUN4QyxNQUFNLFNBQVM7R0FDWCxhQUFhLENBQUM7R0FDZCxPQUFPLENBQUM7R0FDUixNQUFNLENBQUM7RUFDWDtFQUdBLE9BQU8sU0FBUyxVQUFVLE1BQU0sU0FBUyxTQUFTLEtBQUssa0JBQWtCLENBQUMsQ0FBQztFQUczRSxNQUFNLGtCQUFrQixLQUFLLFlBQVkscUJBQXFCLFVBQVUsQ0FBQztFQUd6RSxNQUFNLFNBQVMsU0FBUztHQUNwQixJQUFJLENBQUMsTUFBTSxZQUFZLHFCQUFxQjtHQUM1QyxNQUFNLGFBQWEsS0FBSyxXQUFXLG9CQUFvQjtHQUN2RCxNQUFNLFlBQVksZ0JBQWdCO0dBQ2xDLE1BQU0sUUFBUTtJQUNWLE1BQU0sVUFBVSxRQUFRO0lBQ3hCLE9BQU8sRUFBRSxPQUFPLElBQUksS0FBSyxDQUFDLENBQUMsSUFBSSxVQUFVLFNBQVMsQ0FBQyxFQUFFO0dBQ3pEO0dBRUEsSUFBSSxVQUFVLGNBQWMsS0FBQSxHQUFXLE1BQU0sTUFBTSxNQUFNLFNBQVMsVUFBVSxTQUFTO0dBRXJGLFFBQVEsVUFBVSxNQUFsQjtJQUNJLEtBQUs7S0FDRCxNQUFNLFlBQVksRUFBRSxPQUFPLElBQUksS0FBSyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLEtBQUssV0FBVyxFQUFFO0tBQ2xGO0lBQ0osS0FBSztLQUNELE1BQU0sV0FBVyxFQUFFLE9BQU8sSUFBSSxLQUFLLENBQUMsQ0FBQyxhQUFhLEtBQUssV0FBVyxFQUFFO0tBQ3BFLE1BQU0sV0FBVyxFQUFFLE9BQU8sVUFBVSxNQUFNO0tBQzFDLE1BQU0sUUFBUSxFQUFFLE9BQU8sRUFBRTtLQUN6QjtJQUNKLEtBQUssUUFFRCxPQUFPLE9BQU8sT0FBTyxTQUFTO0dBRXRDO0dBRUEsT0FBTyxVQUFVLEtBQUssQ0FBQyxLQUFLLEtBQUs7RUFDckMsQ0FBQztFQUVELE9BQU87Q0FDWDtBQUNKOzs7QUNqaUNBLElBQUlDLE9BQUs7QUFFVCxJQUFhLGVBQWIsTUFBMEI7Q0FDdEIsWUFBWSxXQUFXO0VBQ25CLEtBQUssWUFBWSxLQUFLLFVBQVUsS0FBSyxJQUFJO0VBQ3pDLEtBQUssd0JBQVEsSUFBSSxJQUFJO0VBQ3JCLEtBQUssV0FBVyxTQUFTO0NBQzdCO0NBRUEsV0FBVyxXQUFXO0VBQ2xCLEtBQUssU0FBUyxJQUFJLE9BQU8sU0FBUztFQUNsQyxLQUFLLE9BQU8sWUFBWSxLQUFLO0NBQ2pDO0NBRUEsVUFBVSxFQUFFLFFBQVE7RUFDaEIsTUFBTSxFQUFFLElBQUksT0FBTyxhQUFhO0VBQ2hDLElBQUksT0FBTztHQUNQLFFBQVEsSUFBSSxPQUFPLEVBQUU7R0FDckI7RUFDSjtFQUNBLE1BQU0sa0JBQWtCLEtBQUssTUFBTSxJQUFJLEVBQUU7RUFDekMsS0FBSyxNQUFNLE9BQU8sRUFBRTtFQUNwQixnQkFBZ0IsUUFBUTtDQUM1QjtDQUVBLGVBQWUsUUFBUSxRQUFRO0VBQzNCO0VBQ0EsS0FBSyxPQUFPLFlBQVk7R0FDcEIsSUFBQTtHQUNBO0dBQ0E7RUFDSixDQUFDO0VBQ0QsSUFBSTtFQUNKLE1BQU0sVUFBVSxJQUFJLFNBQVMsUUFBUyxrQkFBa0IsR0FBSTtFQUM1RCxLQUFLLE1BQU0sSUFBSUEsTUFBSSxlQUFlO0VBQ2xDLE9BQU87Q0FDWDtBQUNKOzs7QUNyQ0EsSUFBSTtBQUNKLElBQUksS0FBSztBQUVULElBQWEsZUFBYixNQUEwQjtDQUN0QixZQUFZLFdBQVcsSUFBSTtFQUN2QixJQUFJLENBQUMsaUJBQWlCLGtCQUFrQixLQUFLLG1CQUFtQixFQUFFO0VBQ2xFLEtBQUssWUFBWSxLQUFLLFVBQVUsS0FBSyxJQUFJO0VBQ3pDLEtBQUssd0JBQVEsSUFBSSxJQUFJO0VBQ3JCLEtBQUssV0FBVyxTQUFTO0NBQzdCO0NBRUEsbUJBQW1CLEtBQUssU0FBUyxjQUFjLFFBQVEsQ0FBQyxDQUFDLFdBQVcsT0FBTyxHQUFHO0VBSTFFLElBQUksQ0FBQyxDQUFDLEdBQUcsYUFBYSwrQkFBK0IsR0FDakQsT0FBTztPQUNKLElBQUksQ0FBQyxDQUFDLEdBQUcsYUFBYSw4QkFBOEIsR0FDdkQsT0FBTztPQUNKLElBQUksQ0FBQyxDQUFDLEdBQUcsYUFBYSwrQkFBK0IsR0FDeEQsT0FBTztPQUNKLElBQUksQ0FBQyxDQUFDLEdBQUcsYUFBYSwrQkFBK0IsR0FDeEQsT0FBTztPQUNKLElBQUksQ0FBQyxDQUFDLEdBQUcsYUFBYSxnQ0FBZ0MsS0FBSyxDQUFDLENBQUMsR0FBRyxhQUFhLHVDQUF1QyxHQUN2SCxPQUFPO0VBSVgsT0FBTztDQUNYO0NBRUEsV0FBVyxXQUFXO0VBQ2xCLEtBQUssU0FBUyxJQUFJLE9BQU8sU0FBUztFQUNsQyxLQUFLLE9BQU8sWUFBWSxLQUFLO0NBQ2pDO0NBRUEsVUFBVSxFQUFFLFFBQVE7RUFDaEIsTUFBTSxFQUFFLElBQUksT0FBTyxVQUFVO0VBQzdCLElBQUksT0FBTztHQUNQLFFBQVEsSUFBSSxPQUFPLEVBQUU7R0FDckI7RUFDSjtFQUNBLE1BQU0saUJBQWlCLEtBQUssTUFBTSxJQUFJLEVBQUU7RUFDeEMsS0FBSyxNQUFNLE9BQU8sRUFBRTtFQUNwQixNQUFNLFVBQVU7RUFDaEIsZUFBZSxLQUFLO0NBQ3hCO0NBRUEsYUFBYSxRQUFRO0VBQ2pCO0VBQ0EsS0FBSyxPQUFPLFlBQVk7R0FDcEI7R0FDQTtHQUNBO0VBQ0osQ0FBQztFQUNELElBQUk7RUFDSixNQUFNLFVBQVUsSUFBSSxTQUFTLFFBQVMsaUJBQWlCLEdBQUk7RUFDM0QsS0FBSyxNQUFNLElBQUksSUFBSSxjQUFjO0VBQ2pDLE9BQU87Q0FDWDtBQUNKOzs7QUN2REEsSUFBYSxXQUFiLGNBQThCLEtBQUs7Q0FDL0IsWUFBWSxJQUFJLEVBQUUsVUFBVSxZQUFZLElBQUksTUFBTSxHQUFHLEtBQU0sRUFBRyxHQUFHLEdBQUcsY0FBYyxDQUFDLEdBQUc7RUFDbEYsTUFBTSxjQUFjLElBQUksUUFBUSxJQUFJO0dBQ2hDLFFBQUE7R0FDQSxVQUFBO0dBQ0EsVUFBVSxFQUFFLFdBQVcsRUFBRSxPQUFPLFVBQVUsRUFBRTtFQUNoRCxDQUFDO0VBRUQsTUFBTSxnQkFBZ0IsU0FBUyxXQUFXLFNBQVM7RUFDbkQsTUFBTSxVQUFVLENBQUM7RUFDakIsTUFBTSwwQkFBVSxJQUFJLElBQUk7RUFFeEIsU0FBUyxpQkFBaUIsS0FBSztHQUMzQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLEtBQUssR0FDakMsSUFBSSxxQkFBcUIsSUFBSSxLQUFLLEdBQUcsSUFBSSxJQUFJLEtBQUssR0FBRyxlQUFlLE9BQU8sR0FDdkUsUUFBUSxLQUFLLElBQUksSUFBSSxJQUFJLElBQUksRUFBRTtFQUczQztFQUVBLElBQUksU0FBUyxXQUFXLE9BQU87R0FDM0IsTUFBTSxRQUFRLFNBQVMsV0FBVyxNQUFNO0dBRXhDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSyxHQUduQyxpQkFBaUI7SUFDYixNQUFNO0lBQUksTUFBTSxJQUFJO0lBQ3BCLE1BQU0sSUFBSTtJQUFJLE1BQU0sSUFBSTtJQUN4QixNQUFNLElBQUk7SUFBSSxNQUFNO0dBQ3hCLENBQUM7RUFFVCxPQUFPO0dBQ0gsTUFBTSxjQUFjLEtBQUssTUFBTSxjQUFjLFNBQVMsQ0FBQztHQUV2RCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksYUFBYSxLQUFLLEdBQ2xDLGlCQUFpQjtJQUFDO0lBQUcsSUFBSTtJQUFHLElBQUk7SUFBRyxJQUFJO0lBQUcsSUFBSTtJQUFHO0dBQUMsQ0FBQztFQUUzRDtFQUVBLE1BQU0sZUFBZSxRQUFRLFNBQVMsUUFBUSxJQUFJLFlBQVksT0FBTyxJQUFJLElBQUksWUFBWSxPQUFPO0VBQ2hHLE1BQU0sZUFBZSxJQUFJLFNBQVMsSUFBSTtHQUNsQyxVQUFVLEVBQUUsR0FBRyxTQUFTLFdBQVcsU0FBUztHQUM1QyxPQUFPLEVBQUUsTUFBTSxhQUFhO0VBQ2hDLENBQUM7RUFFRCxNQUFNLElBQUk7R0FBRSxHQUFHO0dBQVcsTUFBTSxHQUFHO0dBQU8sVUFBVTtHQUFjLFNBQVM7RUFBWSxDQUFDO0NBQzVGO0FBQ0o7QUFHQSxTQUFTLHFCQUFxQixPQUFPLEtBQUssS0FBSyxTQUFTO0NBRXBELE1BQU0sUUFBUTtFQUNWLElBQUk7RUFBUSxJQUFJLFFBQVE7RUFBSSxJQUFJLFFBQVE7RUFDeEMsSUFBSTtFQUFNLElBQUksTUFBTTtFQUFJLElBQUksTUFBTTtDQUN0QyxDQUFDLENBQUMsS0FBSyxHQUFHO0NBSVYsTUFBTSxRQUFRO0VBQ1YsSUFBSTtFQUFNLElBQUksTUFBTTtFQUFJLElBQUksTUFBTTtFQUNsQyxJQUFJO0VBQVEsSUFBSSxRQUFRO0VBQUksSUFBSSxRQUFRO0NBQzVDLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FFVixNQUFNLFVBQVUsUUFBUTtDQUN4QixRQUFRLElBQUksS0FBSztDQUNqQixRQUFRLElBQUksS0FBSztDQUNqQixPQUFPLFFBQVEsT0FBTyxZQUFZO0FBQ3RDO0FBRUEsSUFBTUMsV0FBb0I7Ozs7Ozs7OztBQVUxQixJQUFNQyxhQUFzQjs7Ozs7Ozs7OztBQ2pGNUIsSUFBYSxhQUFiLGNBQWdDLEtBQUs7Q0FDakMsWUFDSSxJQUNBLEVBQ0ksT0FBTyxHQUNQLFlBQVksT0FDWixTQUFTLElBQUksS0FBSyxLQUFNLEtBQU0sR0FBSSxHQUNsQyxTQUFTLElBQUksS0FBSyxLQUFNLEtBQU0sR0FBSSxHQUNsQyxTQUFTLElBQUksS0FBSyxLQUFNLEtBQU0sR0FBSSxHQUNsQyxHQUFHLGNBQ0gsQ0FBQyxHQUNQO0VBQ0UsTUFBTSxJQUFJLFlBQVksQ0FBQyxPQUFPO0VBQzlCLE1BQU0sSUFBSTtFQUdWLE1BQU0sV0FBVyxJQUFJLGFBQWE7R0FDdkM7R0FBRztHQUFHO0dBQUk7R0FBRztHQUFHO0dBQ2hCO0dBQUc7R0FBRztHQUFJO0dBQUc7R0FBRztHQUNoQjtHQUFHO0dBQUc7R0FBSTtHQUFHO0dBQUc7RUFDakIsQ0FBQztFQUdLLE1BQU0sU0FBUyxJQUFJLGFBQWE7R0FDckMsR0FBRztHQUFTLEdBQUc7R0FDZixHQUFHO0dBQVMsR0FBRztHQUNmLEdBQUc7R0FBUyxHQUFHO0VBQ2hCLENBQUM7RUFFSyxNQUFNLFdBQVcsSUFBSSxTQUFTLElBQUk7R0FDOUIsVUFBVTtJQUFFLE1BQU07SUFBRyxNQUFNO0dBQVM7R0FDcEMsT0FBTztJQUFFLE1BQU07SUFBRyxNQUFNO0dBQU87RUFDbkMsQ0FBQztFQUVELE1BQU0sVUFBVSxJQUFJLFFBQVEsSUFBSTtHQUFFLFFBQUE7R0FBUSxVQUFBO0VBQVMsQ0FBQztFQUVwRCxNQUFNLElBQUk7R0FBRSxHQUFHO0dBQVcsTUFBTSxHQUFHO0dBQU87R0FBVTtFQUFRLENBQUM7Q0FDakU7QUFDSjtBQUVBLElBQU1DLFdBQW9COzs7Ozs7Ozs7Ozs7O0FBYzFCLElBQU1DLGFBQXNCOzs7Ozs7Ozs7O0FDdEQ1QixJQUFhLGFBQWIsY0FBZ0MsS0FBSztDQUNqQyxZQUFZLElBQUksRUFBRSxPQUFPLElBQUksWUFBWSxJQUFJLFFBQVEsSUFBSSxLQUFLLEtBQU0sS0FBTSxHQUFJLEdBQUcsR0FBRyxjQUFjLENBQUMsR0FBRztFQUNsRyxNQUFNLGVBQWUsT0FBTyxLQUFLLElBQUk7RUFDckMsTUFBTSxXQUFXLElBQUksYUFBYSxjQUFjLENBQUM7RUFFakQsTUFBTSxLQUFLLE9BQU87RUFDbEIsS0FBSyxJQUFJLElBQUksR0FBRyxLQUFLLFdBQVcsS0FBSztHQUVqQyxNQUFNLElBREksSUFBSSxZQUNBLE9BQU87R0FFckIsU0FBUyxJQUFJO0lBQUM7SUFBRztJQUFHLENBQUM7SUFBSTtJQUFHO0lBQUc7R0FBRSxHQUFHLElBQUksRUFBRTtHQUMxQyxTQUFTLElBQUk7SUFBQyxDQUFDO0lBQUk7SUFBRztJQUFHO0lBQUk7SUFBRztHQUFDLEdBQUcsSUFBSSxLQUFLLENBQUM7RUFDbEQ7RUFFQSxNQUFNLFdBQVcsSUFBSSxTQUFTLElBQUksRUFDOUIsVUFBVTtHQUFFLE1BQU07R0FBRyxNQUFNO0VBQVMsRUFDeEMsQ0FBQztFQUVELE1BQU0sVUFBVSxJQUFJLFFBQVEsSUFBSTtHQUM1QixRQUFBO0dBQ0EsVUFBQTtHQUNBLFVBQVUsRUFDTixPQUFPLEVBQUUsT0FBTyxNQUFNLEVBQzFCO0VBQ0osQ0FBQztFQUNELE1BQU0sSUFBSTtHQUFFLEdBQUc7R0FBVyxNQUFNLEdBQUc7R0FBTztHQUFVO0VBQVEsQ0FBQztDQUNqRTtBQUNKO0FBRUEsSUFBTUMsV0FBb0I7Ozs7Ozs7OztBQVUxQixJQUFNQyxhQUFzQjs7Ozs7Ozs7OztBQ3RDNUIsSUFBYSxzQkFBYixjQUF5QyxLQUFLO0NBQzFDLFlBQVksUUFBUSxFQUFFLE9BQU8sSUFBSyxRQUFRLElBQUksS0FBSyxLQUFNLEtBQU0sR0FBSSxHQUFHLEdBQUcsY0FBYyxDQUFDLEdBQUc7RUFDdkYsTUFBTSxLQUFLLE9BQU87RUFDbEIsTUFBTSxXQUFXLE9BQU8sU0FBUyxXQUFXLE9BQU87RUFDbkQsTUFBTSxpQkFBaUIsSUFBSSxhQUFhLFdBQVcsSUFBSSxDQUFDO0VBQ3hELE1BQU0sZUFBZSxJQUFJLGFBQWEsV0FBVyxJQUFJLENBQUM7RUFDdEQsTUFBTSxZQUFZLElBQUksYUFBYSxXQUFXLENBQUM7RUFFL0MsTUFBTSxhQUFhLE9BQU8sU0FBUyxXQUFXLE9BQU87RUFDckQsTUFBTSxlQUFlLE9BQU8sU0FBUyxXQUFXLFNBQVM7RUFDekQsTUFBTSxXQUFXLElBQUksYUFBYSxDQUFDLEdBQUcsSUFBSSxDQUFDO0VBRTNDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxVQUFVLEtBQUs7R0FDL0IsTUFBTSxLQUFLLElBQUk7R0FDZixNQUFNLEtBQUssSUFBSTtHQUdmLE1BQU0sT0FBTyxhQUFhLFNBQVMsSUFBSSxLQUFLLENBQUM7R0FDN0MsZUFBZSxJQUFJLE1BQU0sRUFBRTtHQUMzQixlQUFlLElBQUksTUFBTSxLQUFLLENBQUM7R0FFL0IsTUFBTSxPQUFPLFdBQVcsU0FBUyxJQUFJLEtBQUssQ0FBQztHQUMzQyxhQUFhLElBQUksTUFBTSxFQUFFO0dBQ3pCLGFBQWEsSUFBSSxNQUFNLEtBQUssQ0FBQztHQUU3QixVQUFVLElBQUksVUFBVSxJQUFJLENBQUM7RUFDakM7RUFFQSxNQUFNLFdBQVcsSUFBSSxTQUFTLElBQUk7R0FDOUIsVUFBVTtJQUFFLE1BQU07SUFBRyxNQUFNO0dBQWU7R0FDMUMsUUFBUTtJQUFFLE1BQU07SUFBRyxNQUFNO0dBQWE7R0FDdEMsTUFBTTtJQUFFLE1BQU07SUFBRyxNQUFNO0dBQVU7RUFDckMsQ0FBQztFQUVELE1BQU0sVUFBVSxJQUFJLFFBQVEsSUFBSTtHQUM1QixRQUFBO0dBQ0EsVUFBQTtHQUNBLFVBQVU7SUFDTixPQUFPLEVBQUUsT0FBTyxNQUFNO0lBQ3RCLG1CQUFtQixFQUFFLE9BQU8sSUFBSSxLQUFLLEVBQUU7SUFDdkMsbUJBQW1CLEVBQUUsT0FBTyxPQUFPLFlBQVk7R0FDbkQ7RUFDSixDQUFDO0VBRUQsTUFBTSxJQUFJO0dBQUUsR0FBRztHQUFXLE1BQU0sR0FBRztHQUFPO0dBQVU7RUFBUSxDQUFDO0VBRTdELEtBQUssU0FBUztDQUNsQjtDQUVBLEtBQUssS0FBSztFQUNOLEtBQUssUUFBUSxTQUFTLGtCQUFrQixNQUFNLGdCQUFnQixLQUFLLE9BQU8sV0FBVztFQUNyRixNQUFNLEtBQUssR0FBRztDQUNsQjtBQUNKO0FBRUEsSUFBTUMsV0FBb0I7Ozs7Ozs7Ozs7Ozs7Ozs7QUFpQjFCLElBQU1DLGFBQXNCOzs7Ozs7Ozs7O0FDeEU1QixJQUFNLHFCQUFxQixJQUFJLEtBQUs7QUFDcEMsSUFBTSxxQkFBcUIsSUFBSSxLQUFLO0FBQ3BDLElBQU0scUJBQXFCLElBQUksS0FBSztBQUNwQyxJQUFNLDBCQUEwQixJQUFJLEtBQUs7QUFDekMsSUFBTSwwQkFBMEIsSUFBSSxLQUFLO0FBRXpDLElBQWEsb0JBQWIsY0FBdUMsS0FBSztDQUN4QyxZQUFZLFFBQVEsRUFBRSxPQUFPLElBQUssUUFBUSxJQUFJLEtBQUssS0FBTSxLQUFNLEdBQUksR0FBRyxHQUFHLGNBQWMsQ0FBQyxHQUFHO0VBQ3ZGLE1BQU0sS0FBSyxPQUFPO0VBRWxCLE1BQU0sZUFBZSxPQUFPLFNBQVMsV0FBVyxTQUFTO0VBQ3pELE1BQU0sV0FBVyxJQUFJLGFBQWEsQ0FBQyxHQUFHLElBQUksQ0FBQztFQUUzQyxNQUFNLFlBQVksT0FBTyxTQUFTLFdBQVc7RUFDN0MsTUFBTSxXQUFXLGFBQWEsTUFBTSxVQUFVLEtBQUssTUFBTSxNQUFNO0VBQy9ELE1BQU0sY0FBYyxZQUFZLFVBQVUsS0FBSyxTQUFTLEtBQUssTUFBTSxhQUFhLFNBQVMsQ0FBQztFQUUxRixNQUFNLFdBQVcsS0FBSyxNQUFNLGNBQWMsQ0FBQztFQUMzQyxNQUFNLGlCQUFpQixJQUFJLGFBQWEsV0FBVyxJQUFJLENBQUM7RUFDeEQsTUFBTSxlQUFlLElBQUksYUFBYSxXQUFXLElBQUksQ0FBQztFQUN0RCxNQUFNLFlBQVksSUFBSSxhQUFhLFdBQVcsQ0FBQztFQUUvQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksYUFBYSxLQUFLLEdBQUc7R0FDckMsR0FBRyxVQUFVLGNBQWMsU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDO0dBQzlDLEdBQUcsVUFBVSxjQUFjLFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQztHQUM5QyxHQUFHLFVBQVUsY0FBYyxTQUFTLElBQUksQ0FBQyxJQUFJLENBQUM7R0FFOUMsUUFDSyxJQUFJLElBQUksRUFBRSxDQUFDLENBQ1gsSUFBSSxFQUFFLENBQUMsQ0FDUCxTQUFTLElBQUksQ0FBQztHQUVuQixHQUFHLElBQUksSUFBSSxFQUFFO0dBQ2IsR0FBRyxJQUFJLElBQUksRUFBRTtHQUNiLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxDQUFDLFVBQVU7R0FHaEMsTUFBTSxLQUFLLElBQUk7R0FDZixlQUFlLElBQUksU0FBUyxFQUFFO0dBQzlCLGVBQWUsSUFBSSxTQUFTLEtBQUssQ0FBQztHQUVsQyxhQUFhLElBQUksU0FBUyxFQUFFO0dBQzVCLGFBQWEsSUFBSSxTQUFTLEtBQUssQ0FBQztHQUNoQyxVQUFVLElBQUksVUFBVyxJQUFJLElBQUssQ0FBQztFQUN2QztFQUVBLE1BQU0sV0FBVyxJQUFJLFNBQVMsSUFBSTtHQUM5QixVQUFVO0lBQUUsTUFBTTtJQUFHLE1BQU07R0FBZTtHQUMxQyxRQUFRO0lBQUUsTUFBTTtJQUFHLE1BQU07R0FBYTtHQUN0QyxNQUFNO0lBQUUsTUFBTTtJQUFHLE1BQU07R0FBVTtFQUNyQyxDQUFDO0VBRUQsTUFBTSxVQUFVLElBQUksUUFBUSxJQUFJO0dBQzVCO0dBQ0E7R0FDQSxVQUFVO0lBQ04sT0FBTyxFQUFFLE9BQU8sTUFBTTtJQUN0QixtQkFBbUIsRUFBRSxPQUFPLElBQUksS0FBSyxFQUFFO0lBQ3ZDLG1CQUFtQixFQUFFLE9BQU8sT0FBTyxZQUFZO0dBQ25EO0VBQ0osQ0FBQztFQUVELE1BQU0sSUFBSTtHQUFFLEdBQUc7R0FBVyxNQUFNLEdBQUc7R0FBTztHQUFVO0VBQVEsQ0FBQztFQUU3RCxLQUFLLFNBQVM7Q0FDbEI7Q0FFQSxLQUFLLEtBQUs7RUFDTixLQUFLLFFBQVEsU0FBUyxrQkFBa0IsTUFBTSxnQkFBZ0IsS0FBSyxPQUFPLFdBQVc7RUFDckYsTUFBTSxLQUFLLEdBQUc7Q0FDbEI7QUFDSjtBQUVBLElBQU0sU0FBb0I7Ozs7Ozs7Ozs7Ozs7Ozs7QUFpQjFCLElBQU0sV0FBc0I7Ozs7Ozs7Ozs7QUM5RjVCLElBQWEsWUFBYixjQUErQixRQUFRO0NBQ25DLFlBQVksSUFBSSxNQUFNO0VBQ2xCLE1BQU0sSUFBSTtHQUNOLEdBQUc7R0FDSCxRQUFRLEdBQUc7R0FDWCxPQUFPLEtBQUssUUFBUSxLQUFLLFFBQVE7R0FDakMsUUFBUSxLQUFLLFNBQVMsS0FBSyxTQUFTO0VBQ3hDLENBQUM7RUFFRCxNQUFNLFFBQVEsSUFBSSxNQUFNO0VBQ3hCLE1BQU0sY0FBYztFQUNwQixNQUFNLE1BQU0sS0FBSztFQUVqQixNQUFNLGVBQWU7R0FDakIsSUFBSSxTQUFTLFNBQVMsY0FBYyxRQUFRO0dBQzVDLE9BQU8sUUFBUSxNQUFNO0dBQ3JCLE9BQU8sU0FBUyxNQUFNO0dBRXRCLElBQUksTUFBTSxPQUFPLFdBQVcsSUFBSTtHQUNoQyxJQUFJLE1BQU0sR0FBRyxFQUFFO0dBQ2YsSUFBSSxVQUFVLEdBQUcsQ0FBQyxNQUFNLE1BQU07R0FDOUIsSUFBSSxVQUFVLE9BQU8sR0FBRyxDQUFDO0dBQ3pCLE1BQU0sWUFBWSxJQUFJLGFBQWEsR0FBRyxHQUFHLE1BQU0sT0FBTyxNQUFNLE1BQU0sQ0FBQyxDQUFDO0dBRXBFLFNBQVM7R0FDVCxNQUFNO0dBQ04sSUFBSTtHQUVKLFFBQVEsS0FBSyxRQUFiO0lBQ0ksS0FBSyxHQUFHO0tBQ0osZUFBZTtLQUNmO0lBQ0osS0FBSyxHQUFHO0tBQ0osZUFBZTtLQUNmO0lBQ0osS0FBSyxHQUFHO0tBQ0osZUFBZTtLQUNmO0lBQ0osU0FDSSxlQUFlO0dBRXZCO0dBRUEsTUFBTSxZQUFZLEtBQUssUUFBUSxLQUFLLFNBQVMsS0FBSyxTQUFTO0dBQzNELE1BQU0sT0FBTyxLQUFLLFNBQVMsR0FBRyxnQkFBZ0IsSUFBSSxXQUFXLFNBQVMsSUFBSSxJQUFJLGFBQWEsU0FBUztHQUVwRyxJQUFJLGVBQWU7R0FFbkIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUM3QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEtBQzdCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLE9BQU8sS0FBSztJQUNqQyxJQUFJLFdBQVksSUFBSSxLQUFLLGFBQWMsS0FBSztJQUM1QyxJQUFJLFdBQVcsS0FBSyxNQUFNLElBQUksS0FBSyxVQUFVLEtBQUssS0FBSyxRQUFRLEtBQUssU0FBUyxLQUFLO0lBQ2xGLElBQUksUUFBUSxJQUFJLFlBQVksSUFBSSxNQUFNLFFBQVE7SUFPOUMsSUFBSSxRQUFRO0tBTEYsVUFBVSxRQUFRO0tBQ2xCLFVBQVUsUUFBUSxJQUFJO0tBQ3RCLFVBQVUsUUFBUSxJQUFJO0tBQ3RCLFVBQVUsUUFBUSxJQUFJO0lBRVQ7SUFFdkIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGNBQWMsS0FDOUIsSUFBSSxLQUFLLFNBQVMsS0FBSyxHQUFHLGVBQ3RCLEtBQUssa0JBQWtCLE1BQU07U0FFN0IsS0FBSyxrQkFBa0IsTUFBTSxLQUFLO0dBRzlDO0dBSVIsS0FBSyxRQUFRO0dBQ2IsS0FBSyxjQUFjO0VBQ3ZCO0NBQ0o7QUFDSiIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5LDEwLDExLDEyLDEzLDE0LDE1LDE2LDE3LDE4LDE5LDIwLDIxLDIyLDIzLDI0LDI1LDI2LDI3LDI4LDI5LDMwLDMxLDMyLDMzLDM0LDM1LDM2LDM3LDM4LDM5LDQwLDQxLDQyLDQzLDQ0LDQ1LDQ2LDQ3LDQ4LDQ5LDUwLDUxLDUyLDUzLDU0LDU1LDU2LDU3LDU4LDU5LDYwLDYxLDYyXX0=