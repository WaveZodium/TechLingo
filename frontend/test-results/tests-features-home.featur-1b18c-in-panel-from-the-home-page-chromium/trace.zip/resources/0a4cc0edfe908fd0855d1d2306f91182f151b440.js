import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/auth/AuthPanel.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=57280423";
import AuthForm from "/src/components/auth/AuthForm.tsx";
import "/src/styles/AuthPanel.css";
var _jsxFileName = "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/auth/AuthPanel.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=57280423";
var _s = $RefreshSig$();
export default function AuthPanel({ isOpen, onClose }) {
	_s();
	const [showRegister, setShowRegister] = useState(false);
	function handleClose() {
		setShowRegister(false);
		onClose();
	}
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [isOpen && /* @__PURE__ */ _jsxDEV("div", {
		className: "auth-panel__overlay",
		onClick: handleClose
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 18
	}, this), /* @__PURE__ */ _jsxDEV("aside", {
		className: `auth-panel ${isOpen ? "auth-panel--open" : ""}`,
		children: [
			/* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				className: "auth-panel__close",
				onClick: handleClose,
				"aria-label": "Close",
				children: "×"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(AuthForm, {
				isOpen,
				isRegisterMode: showRegister,
				onLoginSuccess: handleClose,
				onRegisterSuccess: () => setShowRegister(false)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "auth-panel__switch",
				children: /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => setShowRegister((prev) => !prev),
					children: /* @__PURE__ */ _jsxDEV("span", {
						className: "auth-panel__switch-text",
						children: showRegister ? "Already have an account? Login" : "Don't have an account? Create account"
					}, showRegister ? "login-switch" : "register-switch", false, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 22,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 19,
		columnNumber: 5
	}, this);
}
_s(AuthPanel, "GwikoEhyhC37de0VNQtyCHVsNtI=");
_c = AuthPanel;
var _c;
$RefreshReg$(_c, "AuthPanel");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/auth/AuthPanel.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/auth/AuthPanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/auth/AuthPanel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/auth/AuthPanel.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsT0FBTyxjQUFjO0FBQ3JCLE9BQU87Ozs7QUFPUCxlQUFlLFNBQVMsVUFBVSxFQUFFLFFBQVEsV0FBMkI7O0NBQ3JFLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEtBQUs7Q0FFdEQsU0FBUyxjQUFjO0VBQ3JCLGdCQUFnQixLQUFLO0VBQ3JCLFFBQVE7Q0FDVjtDQUVBLE9BQ0UsZ0RBQ0csVUFBVSx3QkFBQyxPQUFEO0VBQUssV0FBVTtFQUFzQixTQUFTO0NBQWM7Ozs7V0FFdkUsd0JBQUMsU0FBRDtFQUFPLFdBQVcsY0FBYyxTQUFTLHFCQUFxQjtZQUE5RDtHQUNFLHdCQUFDLFVBQUQ7SUFDRSxNQUFLO0lBQ0wsV0FBVTtJQUNWLFNBQVM7SUFDVCxjQUFXO2NBQ1o7R0FFTzs7Ozs7R0FFUix3QkFBQyxVQUFEO0lBQ1U7SUFDUixnQkFBZ0I7SUFDaEIsZ0JBQWdCO0lBQ2hCLHlCQUF5QixnQkFBZ0IsS0FBSztHQUMvQzs7Ozs7R0FFRCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsZUFBZSxpQkFBaUIsU0FBUyxDQUFDLElBQUk7ZUFFOUMsd0JBQUMsUUFBRDtNQUVFLFdBQVU7Z0JBRVQsZUFDRyxtQ0FDQTtLQUNBLEdBTkMsZUFBZSxpQkFBaUI7Ozs7WUFNakM7SUFDQTs7Ozs7R0FDTDs7Ozs7RUFDQTs7Ozs7U0FDUDs7Ozs7QUFFTiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBdXRoUGFuZWwudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBBdXRoRm9ybSBmcm9tIFwiLi9BdXRoRm9ybVwiO1xyXG5pbXBvcnQgXCIuLi8uLi9zdHlsZXMvQXV0aFBhbmVsLmNzc1wiO1xyXG5cclxuaW50ZXJmYWNlIEF1dGhQYW5lbFByb3BzIHtcclxuICBpc09wZW46IGJvb2xlYW47XHJcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXV0aFBhbmVsKHsgaXNPcGVuLCBvbkNsb3NlIH06IEF1dGhQYW5lbFByb3BzKSB7XHJcbiAgY29uc3QgW3Nob3dSZWdpc3Rlciwgc2V0U2hvd1JlZ2lzdGVyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgZnVuY3Rpb24gaGFuZGxlQ2xvc2UoKSB7XHJcbiAgICBzZXRTaG93UmVnaXN0ZXIoZmFsc2UpO1xyXG4gICAgb25DbG9zZSgpO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIHtpc09wZW4gJiYgPGRpdiBjbGFzc05hbWU9XCJhdXRoLXBhbmVsX19vdmVybGF5XCIgb25DbGljaz17aGFuZGxlQ2xvc2V9IC8+fVxyXG5cclxuICAgICAgPGFzaWRlIGNsYXNzTmFtZT17YGF1dGgtcGFuZWwgJHtpc09wZW4gPyBcImF1dGgtcGFuZWwtLW9wZW5cIiA6IFwiXCJ9YH0+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJhdXRoLXBhbmVsX19jbG9zZVwiXHJcbiAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDbG9zZX1cclxuICAgICAgICAgIGFyaWEtbGFiZWw9XCJDbG9zZVwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgw5dcclxuICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgPEF1dGhGb3JtXHJcbiAgICAgICAgICBpc09wZW49e2lzT3Blbn1cclxuICAgICAgICAgIGlzUmVnaXN0ZXJNb2RlPXtzaG93UmVnaXN0ZXJ9XHJcbiAgICAgICAgICBvbkxvZ2luU3VjY2Vzcz17aGFuZGxlQ2xvc2V9XHJcbiAgICAgICAgICBvblJlZ2lzdGVyU3VjY2Vzcz17KCkgPT4gc2V0U2hvd1JlZ2lzdGVyKGZhbHNlKX1cclxuICAgICAgICAvPlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtcGFuZWxfX3N3aXRjaFwiPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1JlZ2lzdGVyKChwcmV2KSA9PiAhcHJldil9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAga2V5PXtzaG93UmVnaXN0ZXIgPyBcImxvZ2luLXN3aXRjaFwiIDogXCJyZWdpc3Rlci1zd2l0Y2hcIn1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhdXRoLXBhbmVsX19zd2l0Y2gtdGV4dFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7c2hvd1JlZ2lzdGVyXHJcbiAgICAgICAgICAgICAgICA/IFwiQWxyZWFkeSBoYXZlIGFuIGFjY291bnQ/IExvZ2luXCJcclxuICAgICAgICAgICAgICAgIDogXCJEb24ndCBoYXZlIGFuIGFjY291bnQ/IENyZWF0ZSBhY2NvdW50XCJ9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2FzaWRlPlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG4iXX0=