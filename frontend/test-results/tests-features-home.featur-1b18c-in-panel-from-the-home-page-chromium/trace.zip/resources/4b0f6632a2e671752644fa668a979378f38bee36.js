import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/auth/ProtectedRoute.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { Navigate, Outlet } from "/node_modules/.vite/deps/react-router-dom.js?v=99106a80";
import { useAuth } from "/src/context/AuthContext.tsx";
var _jsxFileName = "C:/Users/abbas/Desktop/TechLingo/frontend/src/components/auth/ProtectedRoute.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=99106a80";
var _s = $RefreshSig$();
function ProtectedRoute() {
	_s();
	const { isAuth } = useAuth();
	if (!isAuth) {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/",
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 8,
			columnNumber: 12
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 10
	}, this);
}
_s(ProtectedRoute, "4IvvHjNqk9uxg5JB/wglGnzZQNc=", false, function() {
	return [useAuth];
});
_c = ProtectedRoute;
export default ProtectedRoute;
var _c;
$RefreshReg$(_c, "ProtectedRoute");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/auth/ProtectedRoute.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/abbas/Desktop/TechLingo/frontend/src/components/auth/ProtectedRoute.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/abbas/Desktop/TechLingo/frontend/src/components/auth/ProtectedRoute.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/abbas/Desktop/TechLingo/frontend/src/components/auth/ProtectedRoute.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLGNBQWM7QUFDakMsU0FBUyxlQUFlOzs7O0FBRXhCLFNBQVMsaUJBQWlCOztDQUN4QixNQUFNLEVBQUUsV0FBVyxRQUFRO0NBRTNCLElBQUksQ0FBQyxRQUFRO0VBQ1gsT0FBTyx3QkFBQyxVQUFEO0dBQVUsSUFBRztHQUFJO0VBQVM7Ozs7O0NBQ25DO0NBRUEsT0FBTyx3QkFBQyxRQUFELENBQVM7Ozs7O0FBQ2xCOzs7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUHJvdGVjdGVkUm91dGUudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5hdmlnYXRlLCBPdXRsZXQgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIi4uLy4uL2NvbnRleHQvQXV0aENvbnRleHRcIjtcclxuXHJcbmZ1bmN0aW9uIFByb3RlY3RlZFJvdXRlKCkge1xyXG4gIGNvbnN0IHsgaXNBdXRoIH0gPSB1c2VBdXRoKCk7XHJcblxyXG4gIGlmICghaXNBdXRoKSB7XHJcbiAgICByZXR1cm4gPE5hdmlnYXRlIHRvPVwiL1wiIHJlcGxhY2UgLz47XHJcbiAgfVxyXG5cclxuICByZXR1cm4gPE91dGxldCAvPjtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUHJvdGVjdGVkUm91dGU7XHJcbiJdfQ==