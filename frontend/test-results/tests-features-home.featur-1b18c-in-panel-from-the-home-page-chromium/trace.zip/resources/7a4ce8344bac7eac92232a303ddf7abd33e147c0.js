import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/auth/AuthForm.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=99106a80";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=99106a80";
import axios from "/node_modules/.vite/deps/axios.js?v=99106a80";
import { login as loginApi, register as registerApi } from "/src/api/authApi.ts";
import { useAuth } from "/src/context/AuthContext.tsx";
import AuthHeader from "/src/components/auth/AuthHeader.tsx";
import FormField from "/src/components/auth/FormField.tsx";
import PasswordField from "/src/components/auth/PasswordField.tsx";
var _jsxFileName = "C:/Users/abbas/Desktop/TechLingo/frontend/src/components/auth/AuthForm.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=99106a80";
var _s = $RefreshSig$();
export default function AuthForm({ isOpen, isRegisterMode, onLoginSuccess, onRegisterSuccess }) {
	_s();
	const [username, setUsername] = useState("");
	const [password, setPassword] = useState("");
	const [confirmPassword, setConfirmPassword] = useState("");
	const [infoMessage, setInfoMessage] = useState(null);
	const [isLoading, setIsLoading] = useState(false);
	const { login } = useAuth();
	const navigate = useNavigate();
	useEffect(() => {
		if (!isOpen) {
			setUsername("");
			setPassword("");
			setConfirmPassword("");
			setInfoMessage(null);
		}
	}, [isOpen]);
	useEffect(() => {
		if (isRegisterMode) {
			setInfoMessage(null);
		}
		if (!isRegisterMode) {
			setConfirmPassword("");
			setInfoMessage((currentMessage) => currentMessage?.type === "success" ? currentMessage : null);
		}
	}, [isRegisterMode]);
	async function handleSubmit(event) {
		event.preventDefault();
		setInfoMessage(null);
		if (isRegisterMode && password !== confirmPassword) {
			setInfoMessage({
				text: "Passwords do not match.",
				type: "error"
			});
			return;
		}
		setIsLoading(true);
		try {
			if (isRegisterMode) {
				await registerApi({
					username,
					password
				});
				setInfoMessage({
					text: "Account created! You can now log in.",
					type: "success"
				});
				onRegisterSuccess();
			} else {
				await loginApi({
					username,
					password
				});
				login();
				onLoginSuccess();
				navigate("/categories");
			}
		} catch (error) {
			if (axios.isAxiosError(error)) {
				setInfoMessage({
					text: error.response?.data?.errorMessage ?? (isRegisterMode ? "Registration failed." : "Login failed."),
					type: "error"
				});
			} else {
				setInfoMessage({
					text: "Something went wrong.",
					type: "error"
				});
			}
		} finally {
			setIsLoading(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "auth-form",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "auth-form__header-fade",
			children: /* @__PURE__ */ _jsxDEV(AuthHeader, {
				title: isRegisterMode ? "Create account" : "Login",
				subtitle: isRegisterMode ? "Create your account and start learning." : "Welcome back! Please login to your account."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 121,
				columnNumber: 9
			}, this)
		}, isRegisterMode ? "register-header" : "login-header", false, {
			fileName: _jsxFileName,
			lineNumber: 117,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("form", {
			onSubmit: handleSubmit,
			children: [
				/* @__PURE__ */ _jsxDEV(FormField, {
					id: "username",
					label: "Username",
					value: username,
					onChange: setUsername
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 132,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(PasswordField, {
					id: "password",
					label: "Password",
					value: password,
					onChange: setPassword
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 139,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: `auth-form__confirm ${isRegisterMode ? "auth-form__confirm--visible" : ""}`,
					"aria-hidden": !isRegisterMode,
					children: /* @__PURE__ */ _jsxDEV(PasswordField, {
						id: "confirm-password",
						label: "Confirm password",
						value: confirmPassword,
						onChange: setConfirmPassword,
						disabled: !isRegisterMode
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 152,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 146,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: `auth-form__message ${infoMessage ? `auth-form__message--${infoMessage.type}` : ""}`,
					"aria-live": "polite",
					children: infoMessage?.text
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 161,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					disabled: isLoading,
					children: /* @__PURE__ */ _jsxDEV("span", {
						className: "auth-form__button-text",
						children: isLoading ? isRegisterMode ? "Creating account..." : "Logging in..." : isRegisterMode ? "Create account" : "Login"
					}, `${isRegisterMode}-${isLoading}`, false, {
						fileName: _jsxFileName,
						lineNumber: 171,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 170,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 131,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 116,
		columnNumber: 5
	}, this);
}
_s(AuthForm, "NGt5nZrpCWMmuM5ENt+BhaHtfeg=", false, function() {
	return [useAuth, useNavigate];
});
_c = AuthForm;
var _c;
$RefreshReg$(_c, "AuthForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/auth/AuthForm.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/abbas/Desktop/TechLingo/frontend/src/components/auth/AuthForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/abbas/Desktop/TechLingo/frontend/src/components/auth/AuthForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/abbas/Desktop/TechLingo/frontend/src/components/auth/AuthForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLG1CQUFtQjtBQUU1QixPQUFPLFdBQVc7QUFFbEIsU0FBUyxTQUFTLFVBQVUsWUFBWSxtQkFBbUI7QUFHM0QsU0FBUyxlQUFlO0FBRXhCLE9BQU8sZ0JBQWdCO0FBQ3ZCLE9BQU8sZUFBZTtBQUN0QixPQUFPLG1CQUFtQjs7OztBQVMxQixlQUFlLFNBQVMsU0FBUyxFQUMvQixRQUNBLGdCQUNBLGdCQUNBLHFCQUNnQjs7Q0FDaEIsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEVBQUU7Q0FDM0MsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEVBQUU7Q0FDM0MsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxFQUFFO0NBQ3pELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUc1QixJQUFJO0NBQ2QsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsS0FBSztDQUVoRCxNQUFNLEVBQUUsVUFBVSxRQUFRO0NBQzFCLE1BQU0sV0FBVyxZQUFZO0NBRTdCLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxRQUFRO0dBQ1gsWUFBWSxFQUFFO0dBQ2QsWUFBWSxFQUFFO0dBQ2QsbUJBQW1CLEVBQUU7R0FDckIsZUFBZSxJQUFJO0VBQ3JCO0NBQ0YsR0FBRyxDQUFDLE1BQU0sQ0FBQztDQUVYLGdCQUFnQjtFQUNkLElBQUksZ0JBQWdCO0dBQ2xCLGVBQWUsSUFBSTtFQUNyQjtFQUVBLElBQUksQ0FBQyxnQkFBZ0I7R0FDbkIsbUJBQW1CLEVBQUU7R0FFckIsZ0JBQWdCLG1CQUNkLGdCQUFnQixTQUFTLFlBQVksaUJBQWlCLElBQ3hEO0VBQ0Y7Q0FDRixHQUFHLENBQUMsY0FBYyxDQUFDO0NBRW5CLGVBQWUsYUFBYSxPQUFxQztFQUMvRCxNQUFNLGVBQWU7RUFFckIsZUFBZSxJQUFJO0VBRW5CLElBQUksa0JBQWtCLGFBQWEsaUJBQWlCO0dBQ2xELGVBQWU7SUFBRSxNQUFNO0lBQTJCLE1BQU07R0FBUSxDQUFDO0dBQ2pFO0VBQ0Y7RUFFQSxhQUFhLElBQUk7RUFFakIsSUFBSTtHQUNGLElBQUksZ0JBQWdCO0lBQ2xCLE1BQU0sWUFBWTtLQUNoQjtLQUNBO0lBQ0YsQ0FBQztJQUVELGVBQWU7S0FDYixNQUFNO0tBQ04sTUFBTTtJQUNSLENBQUM7SUFFRCxrQkFBa0I7R0FDcEIsT0FBTztJQUNMLE1BQU0sU0FBUztLQUNiO0tBQ0E7SUFDRixDQUFDO0lBRUQsTUFBTTtJQUNOLGVBQWU7SUFFZixTQUFTLGFBQWE7R0FDeEI7RUFDRixTQUFTLE9BQU87R0FDZCxJQUFJLE1BQU0sYUFBNEIsS0FBSyxHQUFHO0lBQzVDLGVBQWU7S0FDYixNQUNFLE1BQU0sVUFBVSxNQUFNLGlCQUNyQixpQkFBaUIseUJBQXlCO0tBQzdDLE1BQU07SUFDUixDQUFDO0dBQ0gsT0FBTztJQUNMLGVBQWU7S0FBRSxNQUFNO0tBQXlCLE1BQU07SUFBUSxDQUFDO0dBQ2pFO0VBQ0YsVUFBVTtHQUNSLGFBQWEsS0FBSztFQUNwQjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsT0FBRDtHQUVFLFdBQVU7YUFFVix3QkFBQyxZQUFEO0lBQ0UsT0FBTyxpQkFBaUIsbUJBQW1CO0lBQzNDLFVBQ0UsaUJBQ0ksNENBQ0E7R0FFUDs7Ozs7RUFDRSxHQVhFLGlCQUFpQixvQkFBb0I7Ozs7U0FXdkMsR0FFTCx3QkFBQyxRQUFEO0dBQU0sVUFBVTthQUFoQjtJQUNFLHdCQUFDLFdBQUQ7S0FDRSxJQUFHO0tBQ0gsT0FBTTtLQUNOLE9BQU87S0FDUCxVQUFVO0lBQ1g7Ozs7O0lBRUQsd0JBQUMsZUFBRDtLQUNFLElBQUc7S0FDSCxPQUFNO0tBQ04sT0FBTztLQUNQLFVBQVU7SUFDWDs7Ozs7SUFFRCx3QkFBQyxPQUFEO0tBQ0UsV0FBVyxzQkFDVCxpQkFBaUIsZ0NBQWdDO0tBRW5ELGVBQWEsQ0FBQztlQUVkLHdCQUFDLGVBQUQ7TUFDRSxJQUFHO01BQ0gsT0FBTTtNQUNOLE9BQU87TUFDUCxVQUFVO01BQ1YsVUFBVSxDQUFDO0tBQ1o7Ozs7O0lBQ0U7Ozs7O0lBRUwsd0JBQUMsS0FBRDtLQUNFLFdBQVcsc0JBQ1QsY0FBYyx1QkFBdUIsWUFBWSxTQUFTO0tBRTVELGFBQVU7ZUFFVCxhQUFhO0lBQ2I7Ozs7O0lBRUgsd0JBQUMsVUFBRDtLQUFRLE1BQUs7S0FBUyxVQUFVO2VBQzlCLHdCQUFDLFFBQUQ7TUFFRSxXQUFVO2dCQUVULFlBQ0csaUJBQ0Usd0JBQ0Esa0JBQ0YsaUJBQ0UsbUJBQ0E7S0FDRixHQVZDLEdBQUcsZUFBZSxHQUFHOzs7O1lBVXRCO0lBQ0E7Ozs7O0dBQ0o7Ozs7O1VBQ0g7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkF1dGhGb3JtLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHR5cGUgeyBTdWJtaXRFdmVudCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcblxyXG5pbXBvcnQgeyBsb2dpbiBhcyBsb2dpbkFwaSwgcmVnaXN0ZXIgYXMgcmVnaXN0ZXJBcGkgfSBmcm9tIFwiLi4vLi4vYXBpL2F1dGhBcGlcIjtcclxuXHJcbmltcG9ydCB0eXBlIHsgRXJyb3JSZXNwb25zZSB9IGZyb20gXCIuLi8uLi90eXBlcy9hdXRoXCI7XHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiLi4vLi4vY29udGV4dC9BdXRoQ29udGV4dFwiO1xyXG5cclxuaW1wb3J0IEF1dGhIZWFkZXIgZnJvbSBcIi4vQXV0aEhlYWRlclwiO1xyXG5pbXBvcnQgRm9ybUZpZWxkIGZyb20gXCIuL0Zvcm1GaWVsZFwiO1xyXG5pbXBvcnQgUGFzc3dvcmRGaWVsZCBmcm9tIFwiLi9QYXNzd29yZEZpZWxkXCI7XHJcblxyXG5pbnRlcmZhY2UgQXV0aEZvcm1Qcm9wcyB7XHJcbiAgaXNPcGVuOiBib29sZWFuO1xyXG4gIGlzUmVnaXN0ZXJNb2RlOiBib29sZWFuO1xyXG4gIG9uTG9naW5TdWNjZXNzOiAoKSA9PiB2b2lkO1xyXG4gIG9uUmVnaXN0ZXJTdWNjZXNzOiAoKSA9PiB2b2lkO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBdXRoRm9ybSh7XHJcbiAgaXNPcGVuLFxyXG4gIGlzUmVnaXN0ZXJNb2RlLFxyXG4gIG9uTG9naW5TdWNjZXNzLFxyXG4gIG9uUmVnaXN0ZXJTdWNjZXNzLFxyXG59OiBBdXRoRm9ybVByb3BzKSB7XHJcbiAgY29uc3QgW3VzZXJuYW1lLCBzZXRVc2VybmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtjb25maXJtUGFzc3dvcmQsIHNldENvbmZpcm1QYXNzd29yZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbaW5mb01lc3NhZ2UsIHNldEluZm9NZXNzYWdlXSA9IHVzZVN0YXRlPHtcclxuICAgIHRleHQ6IHN0cmluZztcclxuICAgIHR5cGU6IFwiZXJyb3JcIiB8IFwic3VjY2Vzc1wiO1xyXG4gIH0gfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCB7IGxvZ2luIH0gPSB1c2VBdXRoKCk7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCFpc09wZW4pIHtcclxuICAgICAgc2V0VXNlcm5hbWUoXCJcIik7XHJcbiAgICAgIHNldFBhc3N3b3JkKFwiXCIpO1xyXG4gICAgICBzZXRDb25maXJtUGFzc3dvcmQoXCJcIik7XHJcbiAgICAgIHNldEluZm9NZXNzYWdlKG51bGwpO1xyXG4gICAgfVxyXG4gIH0sIFtpc09wZW5dKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChpc1JlZ2lzdGVyTW9kZSkge1xyXG4gICAgICBzZXRJbmZvTWVzc2FnZShudWxsKTtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWlzUmVnaXN0ZXJNb2RlKSB7XHJcbiAgICAgIHNldENvbmZpcm1QYXNzd29yZChcIlwiKTtcclxuXHJcbiAgICAgIHNldEluZm9NZXNzYWdlKChjdXJyZW50TWVzc2FnZSkgPT5cclxuICAgICAgICBjdXJyZW50TWVzc2FnZT8udHlwZSA9PT0gXCJzdWNjZXNzXCIgPyBjdXJyZW50TWVzc2FnZSA6IG51bGwsXHJcbiAgICAgICk7XHJcbiAgICB9XHJcbiAgfSwgW2lzUmVnaXN0ZXJNb2RlXSk7XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChldmVudDogU3VibWl0RXZlbnQ8SFRNTEZvcm1FbGVtZW50Pikge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuXHJcbiAgICBzZXRJbmZvTWVzc2FnZShudWxsKTtcclxuXHJcbiAgICBpZiAoaXNSZWdpc3Rlck1vZGUgJiYgcGFzc3dvcmQgIT09IGNvbmZpcm1QYXNzd29yZCkge1xyXG4gICAgICBzZXRJbmZvTWVzc2FnZSh7IHRleHQ6IFwiUGFzc3dvcmRzIGRvIG5vdCBtYXRjaC5cIiwgdHlwZTogXCJlcnJvclwiIH0pO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGlmIChpc1JlZ2lzdGVyTW9kZSkge1xyXG4gICAgICAgIGF3YWl0IHJlZ2lzdGVyQXBpKHtcclxuICAgICAgICAgIHVzZXJuYW1lLFxyXG4gICAgICAgICAgcGFzc3dvcmQsXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHNldEluZm9NZXNzYWdlKHtcclxuICAgICAgICAgIHRleHQ6IFwiQWNjb3VudCBjcmVhdGVkISBZb3UgY2FuIG5vdyBsb2cgaW4uXCIsXHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgb25SZWdpc3RlclN1Y2Nlc3MoKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBhd2FpdCBsb2dpbkFwaSh7XHJcbiAgICAgICAgICB1c2VybmFtZSxcclxuICAgICAgICAgIHBhc3N3b3JkLFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBsb2dpbigpO1xyXG4gICAgICAgIG9uTG9naW5TdWNjZXNzKCk7XHJcblxyXG4gICAgICAgIG5hdmlnYXRlKFwiL2NhdGVnb3JpZXNcIik7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGlmIChheGlvcy5pc0F4aW9zRXJyb3I8RXJyb3JSZXNwb25zZT4oZXJyb3IpKSB7XHJcbiAgICAgICAgc2V0SW5mb01lc3NhZ2Uoe1xyXG4gICAgICAgICAgdGV4dDpcclxuICAgICAgICAgICAgZXJyb3IucmVzcG9uc2U/LmRhdGE/LmVycm9yTWVzc2FnZSA/P1xyXG4gICAgICAgICAgICAoaXNSZWdpc3Rlck1vZGUgPyBcIlJlZ2lzdHJhdGlvbiBmYWlsZWQuXCIgOiBcIkxvZ2luIGZhaWxlZC5cIiksXHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0SW5mb01lc3NhZ2UoeyB0ZXh0OiBcIlNvbWV0aGluZyB3ZW50IHdyb25nLlwiLCB0eXBlOiBcImVycm9yXCIgfSk7XHJcbiAgICAgIH1cclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWZvcm1cIj5cclxuICAgICAgPGRpdlxyXG4gICAgICAgIGtleT17aXNSZWdpc3Rlck1vZGUgPyBcInJlZ2lzdGVyLWhlYWRlclwiIDogXCJsb2dpbi1oZWFkZXJcIn1cclxuICAgICAgICBjbGFzc05hbWU9XCJhdXRoLWZvcm1fX2hlYWRlci1mYWRlXCJcclxuICAgICAgPlxyXG4gICAgICAgIDxBdXRoSGVhZGVyXHJcbiAgICAgICAgICB0aXRsZT17aXNSZWdpc3Rlck1vZGUgPyBcIkNyZWF0ZSBhY2NvdW50XCIgOiBcIkxvZ2luXCJ9XHJcbiAgICAgICAgICBzdWJ0aXRsZT17XHJcbiAgICAgICAgICAgIGlzUmVnaXN0ZXJNb2RlXHJcbiAgICAgICAgICAgICAgPyBcIkNyZWF0ZSB5b3VyIGFjY291bnQgYW5kIHN0YXJ0IGxlYXJuaW5nLlwiXHJcbiAgICAgICAgICAgICAgOiBcIldlbGNvbWUgYmFjayEgUGxlYXNlIGxvZ2luIHRvIHlvdXIgYWNjb3VudC5cIlxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XHJcbiAgICAgICAgPEZvcm1GaWVsZFxyXG4gICAgICAgICAgaWQ9XCJ1c2VybmFtZVwiXHJcbiAgICAgICAgICBsYWJlbD1cIlVzZXJuYW1lXCJcclxuICAgICAgICAgIHZhbHVlPXt1c2VybmFtZX1cclxuICAgICAgICAgIG9uQ2hhbmdlPXtzZXRVc2VybmFtZX1cclxuICAgICAgICAvPlxyXG5cclxuICAgICAgICA8UGFzc3dvcmRGaWVsZFxyXG4gICAgICAgICAgaWQ9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICBsYWJlbD1cIlBhc3N3b3JkXCJcclxuICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cclxuICAgICAgICAgIG9uQ2hhbmdlPXtzZXRQYXNzd29yZH1cclxuICAgICAgICAvPlxyXG5cclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICBjbGFzc05hbWU9e2BhdXRoLWZvcm1fX2NvbmZpcm0gJHtcclxuICAgICAgICAgICAgaXNSZWdpc3Rlck1vZGUgPyBcImF1dGgtZm9ybV9fY29uZmlybS0tdmlzaWJsZVwiIDogXCJcIlxyXG4gICAgICAgICAgfWB9XHJcbiAgICAgICAgICBhcmlhLWhpZGRlbj17IWlzUmVnaXN0ZXJNb2RlfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxQYXNzd29yZEZpZWxkXHJcbiAgICAgICAgICAgIGlkPVwiY29uZmlybS1wYXNzd29yZFwiXHJcbiAgICAgICAgICAgIGxhYmVsPVwiQ29uZmlybSBwYXNzd29yZFwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtjb25maXJtUGFzc3dvcmR9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXRDb25maXJtUGFzc3dvcmR9XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXshaXNSZWdpc3Rlck1vZGV9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8cFxyXG4gICAgICAgICAgY2xhc3NOYW1lPXtgYXV0aC1mb3JtX19tZXNzYWdlICR7XHJcbiAgICAgICAgICAgIGluZm9NZXNzYWdlID8gYGF1dGgtZm9ybV9fbWVzc2FnZS0tJHtpbmZvTWVzc2FnZS50eXBlfWAgOiBcIlwiXHJcbiAgICAgICAgICB9YH1cclxuICAgICAgICAgIGFyaWEtbGl2ZT1cInBvbGl0ZVwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge2luZm9NZXNzYWdlPy50ZXh0fVxyXG4gICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e2lzTG9hZGluZ30+XHJcbiAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICBrZXk9e2Ake2lzUmVnaXN0ZXJNb2RlfS0ke2lzTG9hZGluZ31gfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJhdXRoLWZvcm1fX2J1dHRvbi10ZXh0XCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2lzTG9hZGluZ1xyXG4gICAgICAgICAgICAgID8gaXNSZWdpc3Rlck1vZGVcclxuICAgICAgICAgICAgICAgID8gXCJDcmVhdGluZyBhY2NvdW50Li4uXCJcclxuICAgICAgICAgICAgICAgIDogXCJMb2dnaW5nIGluLi4uXCJcclxuICAgICAgICAgICAgICA6IGlzUmVnaXN0ZXJNb2RlXHJcbiAgICAgICAgICAgICAgICA/IFwiQ3JlYXRlIGFjY291bnRcIlxyXG4gICAgICAgICAgICAgICAgOiBcIkxvZ2luXCJ9XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZm9ybT5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl19