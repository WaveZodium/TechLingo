import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/Navbar.tsx");const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import { Link, NavLink } from "/node_modules/.vite/deps/react-router-dom.js?v=99106a80";
import { useAuth } from "/src/context/AuthContext.tsx";
import logo from "/src/assets/TechlingoALTlogo.png?import";
import "/src/styles/Navbar.css";
var _jsxFileName = "C:/Users/abbas/Desktop/TechLingo/frontend/src/components/layout/Navbar.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=99106a80";
var _s = $RefreshSig$();
function Navbar({ onLoginClick }) {
	_s();
	const { isAuth, logoutUser } = useAuth();
	return /* @__PURE__ */ _jsxDEV("header", {
		className: "navbar",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "navbar__content",
			children: [
				/* @__PURE__ */ _jsxDEV(Link, {
					to: "/",
					className: "navbar__logo-link",
					"aria-label": "TechLingo home",
					children: /* @__PURE__ */ _jsxDEV("img", {
						src: logo,
						alt: "TechLingo",
						className: "navbar__logo"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 16,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("nav", {
					className: "navbar__links",
					children: [/* @__PURE__ */ _jsxDEV(NavLink, {
						to: "/",
						end: true,
						className: ({ isActive }) => `navbar__link ${isActive ? "navbar__link--active" : ""}`,
						children: "Home"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 20,
						columnNumber: 11
					}, this), isAuth && /* @__PURE__ */ _jsxDEV(_Fragment, { children: /* @__PURE__ */ _jsxDEV(NavLink, {
						to: "/categories",
						className: ({ isActive }) => `navbar__link ${isActive ? "navbar__link--active" : ""}`,
						children: "Categories"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 32,
						columnNumber: 15
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 31,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 19,
					columnNumber: 9
				}, this),
				isAuth ? /* @__PURE__ */ _jsxDEV("button", {
					onClick: logoutUser,
					className: "navbar__login",
					type: "button",
					children: [/* @__PURE__ */ _jsxDEV("svg", {
						className: "navbar__login-icon",
						viewBox: "0 0 24 24",
						"aria-hidden": "true",
						children: [/* @__PURE__ */ _jsxDEV("circle", {
							cx: "12",
							cy: "8",
							r: "4"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 51,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("path", { d: "M5 21v-2a7 7 0 0 1 14 0v2" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 52,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 46,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Logout" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 11
				}, this) : /* @__PURE__ */ _jsxDEV("button", {
					onClick: onLoginClick,
					className: "navbar__login",
					type: "button",
					children: [/* @__PURE__ */ _jsxDEV("svg", {
						className: "navbar__login-icon",
						viewBox: "0 0 24 24",
						"aria-hidden": "true",
						children: [/* @__PURE__ */ _jsxDEV("circle", {
							cx: "12",
							cy: "8",
							r: "4"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("path", { d: "M5 21v-2a7 7 0 0 1 14 0v2" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 69,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Login" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 5
	}, this);
}
_s(Navbar, "eFw3osGLcpYpHPvCXxPL+7eCxnk=", false, function() {
	return [useAuth];
});
_c = Navbar;
export default Navbar;
var _c;
$RefreshReg$(_c, "Navbar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/Navbar.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/abbas/Desktop/TechLingo/frontend/src/components/layout/Navbar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/abbas/Desktop/TechLingo/frontend/src/components/layout/Navbar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/abbas/Desktop/TechLingo/frontend/src/components/layout/Navbar.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxNQUFNLGVBQWU7QUFDOUIsU0FBUyxlQUFlO0FBQ3hCLE9BQU8sVUFBVTtBQUNqQixPQUFPOzs7O0FBTVAsU0FBUyxPQUFPLEVBQUUsZ0JBQTZCOztDQUM3QyxNQUFNLEVBQUUsUUFBUSxlQUFlLFFBQVE7Q0FDdkMsT0FDRSx3QkFBQyxVQUFEO0VBQVEsV0FBVTtZQUNoQix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsTUFBRDtLQUFNLElBQUc7S0FBSSxXQUFVO0tBQW9CLGNBQVc7ZUFDcEQsd0JBQUMsT0FBRDtNQUFLLEtBQUs7TUFBTSxLQUFJO01BQVksV0FBVTtLQUFnQjs7Ozs7SUFDdEQ7Ozs7O0lBRU4sd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFNBQUQ7TUFDRSxJQUFHO01BQ0g7TUFDQSxZQUFZLEVBQUUsZUFDWixnQkFBZ0IsV0FBVyx5QkFBeUI7Z0JBRXZEO0tBRVE7Ozs7ZUFFUixVQUNDLCtDQUNFLHdCQUFDLFNBQUQ7TUFDRSxJQUFHO01BQ0gsWUFBWSxFQUFFLGVBQ1osZ0JBQWdCLFdBQVcseUJBQXlCO2dCQUV2RDtLQUVROzs7O2NBQ1Q7Ozs7YUFFRDs7Ozs7O0lBRUosU0FDQyx3QkFBQyxVQUFEO0tBQVEsU0FBUztLQUFZLFdBQVU7S0FBZ0IsTUFBSztlQUE1RCxDQUNFLHdCQUFDLE9BQUQ7TUFDRSxXQUFVO01BQ1YsU0FBUTtNQUNSLGVBQVk7Z0JBSGQsQ0FLRSx3QkFBQyxVQUFEO09BQVEsSUFBRztPQUFLLElBQUc7T0FBSSxHQUFFO01BQUs7Ozs7Z0JBQzlCLHdCQUFDLFFBQUQsRUFBTSxHQUFFLDRCQUE2Qjs7OztjQUNsQzs7Ozs7ZUFFTCx3QkFBQyxRQUFELFlBQU0sU0FBWTs7OzthQUNaOzs7OztlQUVSLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsV0FBVTtLQUNWLE1BQUs7ZUFIUCxDQUtFLHdCQUFDLE9BQUQ7TUFDRSxXQUFVO01BQ1YsU0FBUTtNQUNSLGVBQVk7Z0JBSGQsQ0FLRSx3QkFBQyxVQUFEO09BQVEsSUFBRztPQUFLLElBQUc7T0FBSSxHQUFFO01BQUs7Ozs7Z0JBQzlCLHdCQUFDLFFBQUQsRUFBTSxHQUFFLDRCQUE2Qjs7OztjQUNsQzs7Ozs7ZUFFTCx3QkFBQyxRQUFELFlBQU0sUUFBVzs7OzthQUNYOzs7Ozs7R0FFUDs7Ozs7O0NBQ0M7Ozs7O0FBRVo7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJOYXZiYXIudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmssIE5hdkxpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIi4uLy4uL2NvbnRleHQvQXV0aENvbnRleHRcIjtcclxuaW1wb3J0IGxvZ28gZnJvbSBcIi4uLy4uL2Fzc2V0cy9UZWNobGluZ29BTFRsb2dvLnBuZ1wiO1xyXG5pbXBvcnQgXCIuLi8uLi9zdHlsZXMvTmF2YmFyLmNzc1wiO1xyXG5cclxuaW50ZXJmYWNlIE5hdmJhclByb3BzIHtcclxuICBvbkxvZ2luQ2xpY2s6ICgpID0+IHZvaWQ7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIE5hdmJhcih7IG9uTG9naW5DbGljayB9OiBOYXZiYXJQcm9wcykge1xyXG4gIGNvbnN0IHsgaXNBdXRoLCBsb2dvdXRVc2VyIH0gPSB1c2VBdXRoKCk7XHJcbiAgcmV0dXJuIChcclxuICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwibmF2YmFyXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibmF2YmFyX19jb250ZW50XCI+XHJcbiAgICAgICAgPExpbmsgdG89XCIvXCIgY2xhc3NOYW1lPVwibmF2YmFyX19sb2dvLWxpbmtcIiBhcmlhLWxhYmVsPVwiVGVjaExpbmdvIGhvbWVcIj5cclxuICAgICAgICAgIDxpbWcgc3JjPXtsb2dvfSBhbHQ9XCJUZWNoTGluZ29cIiBjbGFzc05hbWU9XCJuYXZiYXJfX2xvZ29cIiAvPlxyXG4gICAgICAgIDwvTGluaz5cclxuXHJcbiAgICAgICAgPG5hdiBjbGFzc05hbWU9XCJuYXZiYXJfX2xpbmtzXCI+XHJcbiAgICAgICAgICA8TmF2TGlua1xyXG4gICAgICAgICAgICB0bz1cIi9cIlxyXG4gICAgICAgICAgICBlbmRcclxuICAgICAgICAgICAgY2xhc3NOYW1lPXsoeyBpc0FjdGl2ZSB9KSA9PlxyXG4gICAgICAgICAgICAgIGBuYXZiYXJfX2xpbmsgJHtpc0FjdGl2ZSA/IFwibmF2YmFyX19saW5rLS1hY3RpdmVcIiA6IFwiXCJ9YFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIEhvbWVcclxuICAgICAgICAgIDwvTmF2TGluaz5cclxuXHJcbiAgICAgICAgICB7aXNBdXRoICYmIChcclxuICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICA8TmF2TGlua1xyXG4gICAgICAgICAgICAgICAgdG89XCIvY2F0ZWdvcmllc1wiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9eyh7IGlzQWN0aXZlIH0pID0+XHJcbiAgICAgICAgICAgICAgICAgIGBuYXZiYXJfX2xpbmsgJHtpc0FjdGl2ZSA/IFwibmF2YmFyX19saW5rLS1hY3RpdmVcIiA6IFwiXCJ9YFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIENhdGVnb3JpZXNcclxuICAgICAgICAgICAgICA8L05hdkxpbms+XHJcbiAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L25hdj5cclxuXHJcbiAgICAgICAge2lzQXV0aCA/IChcclxuICAgICAgICAgIDxidXR0b24gb25DbGljaz17bG9nb3V0VXNlcn0gY2xhc3NOYW1lPVwibmF2YmFyX19sb2dpblwiIHR5cGU9XCJidXR0b25cIj5cclxuICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm5hdmJhcl9fbG9naW4taWNvblwiXHJcbiAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxjaXJjbGUgY3g9XCIxMlwiIGN5PVwiOFwiIHI9XCI0XCIgLz5cclxuICAgICAgICAgICAgICA8cGF0aCBkPVwiTTUgMjF2LTJhNyA3IDAgMCAxIDE0IDB2MlwiIC8+XHJcbiAgICAgICAgICAgIDwvc3ZnPlxyXG5cclxuICAgICAgICAgICAgPHNwYW4+TG9nb3V0PC9zcGFuPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17b25Mb2dpbkNsaWNrfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJuYXZiYXJfX2xvZ2luXCJcclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJuYXZiYXJfX2xvZ2luLWljb25cIlxyXG4gICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8Y2lyY2xlIGN4PVwiMTJcIiBjeT1cIjhcIiByPVwiNFwiIC8+XHJcbiAgICAgICAgICAgICAgPHBhdGggZD1cIk01IDIxdi0yYTcgNyAwIDAgMSAxNCAwdjJcIiAvPlxyXG4gICAgICAgICAgICA8L3N2Zz5cclxuXHJcbiAgICAgICAgICAgIDxzcGFuPkxvZ2luPC9zcGFuPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2hlYWRlcj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBOYXZiYXI7XHJcbiJdfQ==