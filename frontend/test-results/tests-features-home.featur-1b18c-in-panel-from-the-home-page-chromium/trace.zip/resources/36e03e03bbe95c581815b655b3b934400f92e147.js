import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/auth/FormField.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/abbas/Desktop/TechLingo/frontend/src/components/auth/FormField.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=99106a80";
export default function FormField({ id, label, type = "text", value, onChange }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "auth-form__field",
		children: [/* @__PURE__ */ _jsxDEV("label", {
			htmlFor: id,
			children: label
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 18,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("input", {
			id,
			type,
			value,
			onChange: (event) => onChange(event.target.value),
			required: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 5
	}, this);
}
_c = FormField;
var _c;
$RefreshReg$(_c, "FormField");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/auth/FormField.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/abbas/Desktop/TechLingo/frontend/src/components/auth/FormField.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/abbas/Desktop/TechLingo/frontend/src/components/auth/FormField.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/abbas/Desktop/TechLingo/frontend/src/components/auth/FormField.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFRQSxlQUFlLFNBQVMsVUFBVSxFQUNoQyxJQUNBLE9BQ0EsT0FBTyxRQUNQLE9BQ0EsWUFDaUI7Q0FDakIsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsU0FBRDtHQUFPLFNBQVM7YUFBSztFQUFhOzs7O1lBRWxDLHdCQUFDLFNBQUQ7R0FDTTtHQUNFO0dBQ0M7R0FDUCxXQUFXLFVBQVUsU0FBUyxNQUFNLE9BQU8sS0FBSztHQUNoRDtFQUNEOzs7O1VBQ0U7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkZvcm1GaWVsZC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW50ZXJmYWNlIEZvcm1GaWVsZFByb3BzIHtcclxuICBpZDogc3RyaW5nO1xyXG4gIGxhYmVsOiBzdHJpbmc7XHJcbiAgdHlwZT86IHN0cmluZztcclxuICB2YWx1ZTogc3RyaW5nO1xyXG4gIG9uQ2hhbmdlOiAodmFsdWU6IHN0cmluZykgPT4gdm9pZDtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRm9ybUZpZWxkKHtcclxuICBpZCxcclxuICBsYWJlbCxcclxuICB0eXBlID0gXCJ0ZXh0XCIsXHJcbiAgdmFsdWUsXHJcbiAgb25DaGFuZ2UsXHJcbn06IEZvcm1GaWVsZFByb3BzKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1mb3JtX19maWVsZFwiPlxyXG4gICAgICA8bGFiZWwgaHRtbEZvcj17aWR9PntsYWJlbH08L2xhYmVsPlxyXG5cclxuICAgICAgPGlucHV0XHJcbiAgICAgICAgaWQ9e2lkfVxyXG4gICAgICAgIHR5cGU9e3R5cGV9XHJcbiAgICAgICAgdmFsdWU9e3ZhbHVlfVxyXG4gICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IG9uQ2hhbmdlKGV2ZW50LnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgcmVxdWlyZWRcclxuICAgICAgLz5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl19