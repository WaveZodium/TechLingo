import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/auth/AuthHeader.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"];var _jsxFileName = "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/auth/AuthHeader.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=57280423";
export default function AuthHeader({ title, subtitle }) {
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
		className: "auth-form__heading",
		children: [/* @__PURE__ */ _jsxDEV("svg", {
			className: "auth-form__heading-icon",
			viewBox: "0 0 24 24",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ _jsxDEV("circle", {
				cx: "12",
				cy: "8",
				r: "4"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("path", { d: "M5 21v-2a7 7 0 0 1 14 0v2" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 16,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 10,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("h2", { children: title }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV("p", {
		className: "auth-form__subtitle",
		children: subtitle
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 22,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 8,
		columnNumber: 5
	}, this);
}
_c = AuthHeader;
var _c;
$RefreshReg$(_c, "AuthHeader");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/auth/AuthHeader.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/auth/AuthHeader.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/auth/AuthHeader.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/components/auth/AuthHeader.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFLQSxlQUFlLFNBQVMsV0FBVyxFQUFFLE9BQU8sWUFBNkI7Q0FDdkUsT0FDRSxnREFDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsT0FBRDtHQUNFLFdBQVU7R0FDVixTQUFRO0dBQ1IsZUFBWTthQUhkLENBS0Usd0JBQUMsVUFBRDtJQUFRLElBQUc7SUFBSyxJQUFHO0lBQUksR0FBRTtHQUFLOzs7O2FBQzlCLHdCQUFDLFFBQUQsRUFBTSxHQUFFLDRCQUE2Qjs7OztXQUNsQzs7Ozs7WUFFTCx3QkFBQyxNQUFELFlBQUssTUFBVTs7OztVQUNaOzs7OztXQUVMLHdCQUFDLEtBQUQ7RUFBRyxXQUFVO1lBQXVCO0NBQVk7Ozs7U0FDaEQ7Ozs7O0FBRU4iLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXV0aEhlYWRlci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW50ZXJmYWNlIEF1dGhIZWFkZXJQcm9wcyB7XHJcbiAgdGl0bGU6IHN0cmluZztcclxuICBzdWJ0aXRsZTogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBdXRoSGVhZGVyKHsgdGl0bGUsIHN1YnRpdGxlIH06IEF1dGhIZWFkZXJQcm9wcykge1xyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtZm9ybV9faGVhZGluZ1wiPlxyXG4gICAgICAgIDxzdmdcclxuICAgICAgICAgIGNsYXNzTmFtZT1cImF1dGgtZm9ybV9faGVhZGluZy1pY29uXCJcclxuICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8Y2lyY2xlIGN4PVwiMTJcIiBjeT1cIjhcIiByPVwiNFwiIC8+XHJcbiAgICAgICAgICA8cGF0aCBkPVwiTTUgMjF2LTJhNyA3IDAgMCAxIDE0IDB2MlwiIC8+XHJcbiAgICAgICAgPC9zdmc+XHJcblxyXG4gICAgICAgIDxoMj57dGl0bGV9PC9oMj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJhdXRoLWZvcm1fX3N1YnRpdGxlXCI+e3N1YnRpdGxlfTwvcD5cclxuICAgIDwvPlxyXG4gICk7XHJcbn1cclxuIl19