import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/HomePage.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=57280423";
import { useOutletContext } from "/node_modules/.vite/deps/react-router-dom.js?v=57280423";
import heroImage from "/src/assets/productutanBox.png?import";
import "/src/styles/HomePage.css";
import { useAuth } from "/src/context/AuthContext.tsx";
var _jsxFileName = "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/pages/HomePage.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=57280423";
var _s = $RefreshSig$();
function HomePage() {
	_s();
	const { openAuthPanel } = useOutletContext();
	const { isAuth } = useAuth();
	const navigate = useNavigate();
	function handleGetStarted() {
		if (isAuth) {
			navigate("/categories");
		} else {
			openAuthPanel();
		}
	}
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "home",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "home__content",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "home__text",
				children: [
					/* @__PURE__ */ _jsxDEV("h1", {
						className: "home__title",
						children: [
							"Understand Internet Culture",
							/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 30,
								columnNumber: 13
							}, this),
							"and IT-Abbreviations."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 28,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "home__description",
						children: "TechLingo helps you understand internet culture, slang, and IT abbreviations in a simple and fun way."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "home__cta",
						onClick: handleGetStarted,
						children: [/* @__PURE__ */ _jsxDEV("span", { children: "Get started" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 44,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							"aria-hidden": "true",
							children: "→"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 45,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 39,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "home__image-wrapper",
				children: /* @__PURE__ */ _jsxDEV("img", {
					src: heroImage,
					alt: "TechLingo internet culture and IT abbreviations",
					className: "home__image"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 49,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 25,
		columnNumber: 5
	}, this);
}
_s(HomePage, "BT/k9WB6SrcrAFQnSjTyk5fgKEA=", false, function() {
	return [
		useOutletContext,
		useAuth,
		useNavigate
	];
});
_c = HomePage;
export default HomePage;
var _c;
$RefreshReg$(_c, "HomePage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/HomePage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/pages/HomePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/pages/HomePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/pages/HomePage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyx3QkFBd0I7QUFDakMsT0FBTyxlQUFlO0FBQ3RCLE9BQU87QUFDUCxTQUFTLGVBQWU7Ozs7QUFNeEIsU0FBUyxXQUFXOztDQUNsQixNQUFNLEVBQUUsa0JBQWtCLGlCQUFvQztDQUM5RCxNQUFNLEVBQUUsV0FBVyxRQUFRO0NBQzNCLE1BQU0sV0FBVyxZQUFZO0NBRTdCLFNBQVMsbUJBQW1CO0VBQzFCLElBQUksUUFBUTtHQUNWLFNBQVMsYUFBYTtFQUN4QixPQUFPO0dBQ0wsY0FBYztFQUNoQjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUNqQix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkO09BQTRCO09BRTFCLHdCQUFDLE1BQUQsQ0FBSzs7Ozs7T0FBQztNQUVKOzs7Ozs7S0FFSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBb0I7S0FHOUI7Ozs7O0tBRUgsd0JBQUMsVUFBRDtNQUNFLE1BQUs7TUFDTCxXQUFVO01BQ1YsU0FBUztnQkFIWCxDQUtFLHdCQUFDLFFBQUQsWUFBTSxjQUFpQjs7OztnQkFDdkIsd0JBQUMsUUFBRDtPQUFNLGVBQVk7aUJBQU87TUFBTzs7OztjQUMxQjs7Ozs7O0lBQ0w7Ozs7O2FBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxPQUFEO0tBQ0UsS0FBSztLQUNMLEtBQUk7S0FDSixXQUFVO0lBQ1g7Ozs7O0dBQ0U7Ozs7V0FDRjs7Ozs7O0NBQ0U7Ozs7O0FBRWI7Ozs7Ozs7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSG9tZVBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgdXNlT3V0bGV0Q29udGV4dCB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBoZXJvSW1hZ2UgZnJvbSBcIi4uL2Fzc2V0cy9wcm9kdWN0dXRhbkJveC5wbmdcIjtcclxuaW1wb3J0IFwiLi4vc3R5bGVzL0hvbWVQYWdlLmNzc1wiO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIi4uL2NvbnRleHQvQXV0aENvbnRleHRcIjtcclxuXHJcbnR5cGUgT3V0bGV0Q29udGV4dFR5cGUgPSB7XHJcbiAgb3BlbkF1dGhQYW5lbDogKCkgPT4gdm9pZDtcclxufTtcclxuXHJcbmZ1bmN0aW9uIEhvbWVQYWdlKCkge1xyXG4gIGNvbnN0IHsgb3BlbkF1dGhQYW5lbCB9ID0gdXNlT3V0bGV0Q29udGV4dDxPdXRsZXRDb250ZXh0VHlwZT4oKTtcclxuICBjb25zdCB7IGlzQXV0aCB9ID0gdXNlQXV0aCgpO1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuXHJcbiAgZnVuY3Rpb24gaGFuZGxlR2V0U3RhcnRlZCgpIHtcclxuICAgIGlmIChpc0F1dGgpIHtcclxuICAgICAgbmF2aWdhdGUoXCIvY2F0ZWdvcmllc1wiKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIG9wZW5BdXRoUGFuZWwoKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJob21lXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaG9tZV9fY29udGVudFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaG9tZV9fdGV4dFwiPlxyXG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cImhvbWVfX3RpdGxlXCI+XHJcbiAgICAgICAgICAgIFVuZGVyc3RhbmQgSW50ZXJuZXQgQ3VsdHVyZVxyXG4gICAgICAgICAgICA8YnIgLz5cclxuICAgICAgICAgICAgYW5kIElULUFiYnJldmlhdGlvbnMuXHJcbiAgICAgICAgICA8L2gxPlxyXG5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImhvbWVfX2Rlc2NyaXB0aW9uXCI+XHJcbiAgICAgICAgICAgIFRlY2hMaW5nbyBoZWxwcyB5b3UgdW5kZXJzdGFuZCBpbnRlcm5ldCBjdWx0dXJlLCBzbGFuZywgYW5kIElUXHJcbiAgICAgICAgICAgIGFiYnJldmlhdGlvbnMgaW4gYSBzaW1wbGUgYW5kIGZ1biB3YXkuXHJcbiAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaG9tZV9fY3RhXCJcclxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlR2V0U3RhcnRlZH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPHNwYW4+R2V0IHN0YXJ0ZWQ8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPuKGkjwvc3Bhbj5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhvbWVfX2ltYWdlLXdyYXBwZXJcIj5cclxuICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgc3JjPXtoZXJvSW1hZ2V9XHJcbiAgICAgICAgICAgIGFsdD1cIlRlY2hMaW5nbyBpbnRlcm5ldCBjdWx0dXJlIGFuZCBJVCBhYmJyZXZpYXRpb25zXCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaG9tZV9faW1hZ2VcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgSG9tZVBhZ2U7XHJcbiJdfQ==