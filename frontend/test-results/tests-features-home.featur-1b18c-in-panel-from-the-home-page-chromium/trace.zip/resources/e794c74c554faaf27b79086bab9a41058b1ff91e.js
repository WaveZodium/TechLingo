import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/QuizPage.tsx");const useEffect = __vite__cjsImport1_react["useEffect"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import "/src/styles/QuizPage.css";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=99106a80";
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=99106a80";
import { getQuestionsByCategory } from "/src/api/questionApi.ts";
var _jsxFileName = "C:/Users/abbas/Desktop/TechLingo/frontend/src/pages/QuizPage.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=99106a80";
var _s = $RefreshSig$();
function RobotAvatar() {
	return /* @__PURE__ */ _jsxDEV("span", {
		className: "robot-avatar",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ _jsxDEV("span", { className: "robot-antenna" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 12,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("span", {
			className: "robot-face",
			children: [
				/* @__PURE__ */ _jsxDEV("span", { className: "robot-eye robot-eye-left" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 14,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("span", { className: "robot-eye robot-eye-right" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("span", { className: "robot-mouth" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 16,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 13,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 5
	}, this);
}
_c = RobotAvatar;
function UserAvatar() {
	return /* @__PURE__ */ _jsxDEV("span", {
		className: "user-avatar",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ _jsxDEV("span", { className: "user-head" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("span", { className: "user-shoulders" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 24,
		columnNumber: 5
	}, this);
}
_c2 = UserAvatar;
function QuizPage() {
	_s();
	// Hämtar kategori-id från URL:en för att veta vilken kategoris frågor som ska visas.
	const { categoryId } = useParams();
	// Sparar frågorna som hämtas från backend.
	const [questions, setQuestions] = useState([]);
	const [currentQuestionIndex] = useState(0);
	// Håller reda på vilket svar användaren har valt.
	const [selectedAnswerId, setSelectedAnswerId] = useState(null);
	// Hanterar laddningsstatus och eventuella fel vid hämtning.
	const [isLoading, setIsLoading] = useState(true);
	const [error, setError] = useState(null);
	// Hämtar frågor på nytt när categoryId ändras.
	useEffect(() => {
		async function loadQuestions() {
			if (!categoryId) {
				setError("No category was selected.");
				setIsLoading(false);
				return;
			}
			try {
				// Hämtar alla frågor som tillhör den valda kategorin.
				const data = await getQuestionsByCategory(categoryId);
				setQuestions(data);
			} catch (error) {
				console.error("Failed to load questions:", error);
				setError("Could not load questions.");
			} finally {
				setIsLoading(false);
			}
		}
		loadQuestions();
	}, [categoryId]);
	// Loading visas medan frågorna hämtas från backend.
	if (isLoading) {
		return /* @__PURE__ */ _jsxDEV("main", {
			className: "quiz-page",
			children: /* @__PURE__ */ _jsxDEV("section", {
				className: "quiz-shell",
				children: /* @__PURE__ */ _jsxDEV("p", { children: "Loading questions..." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 74,
			columnNumber: 7
		}, this);
	}
	// kastar felmeddelande om hämtningen av frågor misslyckas.
	if (error) {
		return /* @__PURE__ */ _jsxDEV("main", {
			className: "quiz-page",
			children: /* @__PURE__ */ _jsxDEV("section", {
				className: "quiz-shell",
				children: /* @__PURE__ */ _jsxDEV("p", { children: error }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 86,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 85,
			columnNumber: 7
		}, this);
	}
	// Hanterar fallet där kategorin inte innehåller några frågor.
	if (questions.length === 0) {
		return /* @__PURE__ */ _jsxDEV("main", {
			className: "quiz-page",
			children: /* @__PURE__ */ _jsxDEV("section", {
				className: "quiz-shell",
				children: /* @__PURE__ */ _jsxDEV("p", { children: "No questions found for this category." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 98,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 97,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 96,
			columnNumber: 7
		}, this);
	}
	// Hämtar den fråga som ska visas just nu.
	const currentQuestion = questions[currentQuestionIndex];
	// Letar upp hela svarsalternativet utifrån det valda svarets id.
	const selectedAnswer = currentQuestion.options.find((option) => option.id === selectedAnswerId);
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "quiz-page",
		children: /* @__PURE__ */ _jsxDEV("section", {
			className: "quiz-shell",
			"aria-labelledby": "quiz-title",
			children: [
				/* @__PURE__ */ _jsxDEV("h1", {
					id: "quiz-title",
					style: {
						position: "absolute",
						width: 1,
						height: 1,
						overflow: "hidden",
						clip: "rect(0 0 0 0)"
					},
					children: "TechLingo quiz"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 115,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "conversation",
					"aria-live": "polite",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "message-row",
							children: [/* @__PURE__ */ _jsxDEV(RobotAvatar, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 130,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "bubble robot",
								children: currentQuestion.message
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 132,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 129,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "message-row",
							children: [/* @__PURE__ */ _jsxDEV(RobotAvatar, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 136,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "bubble robot",
								children: currentQuestion.prompt
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 138,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 135,
							columnNumber: 11
						}, this),
						selectedAnswer && /* @__PURE__ */ _jsxDEV("div", {
							className: "message-row user",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "bubble user",
								children: selectedAnswer.text
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 144,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(UserAvatar, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 146,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 143,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 128,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { className: "divider" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 151,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "answer-grid",
					role: "group",
					"aria-label": "Välj ett svar",
					children: currentQuestion.options.map((answer, index) => /* @__PURE__ */ _jsxDEV("button", {
						className: `answer-button${selectedAnswerId === answer.id ? " selected" : ""}`,
						onClick: () => setSelectedAnswerId(answer.id),
						type: "button",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "answer-letter",
							children: String.fromCharCode(65 + index)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 165,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: answer.text }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 169,
							columnNumber: 15
						}, this)]
					}, answer.id, true, {
						fileName: _jsxFileName,
						lineNumber: 156,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 153,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 114,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 113,
		columnNumber: 5
	}, this);
}
_s(QuizPage, "L/VwaUzlG7q0AHO6/076OSym/NY=", false, function() {
	return [useParams];
});
_c3 = QuizPage;
export default QuizPage;
var _c, _c2, _c3;
$RefreshReg$(_c, "RobotAvatar");
$RefreshReg$(_c2, "UserAvatar");
$RefreshReg$(_c3, "QuizPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/QuizPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/abbas/Desktop/TechLingo/frontend/src/pages/QuizPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/abbas/Desktop/TechLingo/frontend/src/pages/QuizPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/abbas/Desktop/TechLingo/frontend/src/pages/QuizPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTztBQUVQLFNBQVMsV0FBVyxnQkFBZ0I7QUFDcEMsU0FBUyxpQkFBaUI7QUFFMUIsU0FBUyw4QkFBOEI7Ozs7QUFHdkMsU0FBUyxjQUFjO0NBQ3JCLE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFdBQVU7RUFBZSxlQUFZO1lBQTNDLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsZ0JBQWlCOzs7O1lBQ2pDLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO2FBQWhCO0lBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsMkJBQTRCOzs7OztJQUM1Qyx3QkFBQyxRQUFELEVBQU0sV0FBVSw0QkFBNkI7Ozs7O0lBQzdDLHdCQUFDLFFBQUQsRUFBTSxXQUFVLGNBQWU7Ozs7O0dBQzNCOzs7OztVQUNGOzs7Ozs7QUFFVjs7QUFFQSxTQUFTLGFBQWE7Q0FDcEIsT0FDRSx3QkFBQyxRQUFEO0VBQU0sV0FBVTtFQUFjLGVBQVk7WUFBMUMsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxZQUFhOzs7O1lBQzdCLHdCQUFDLFFBQUQsRUFBTSxXQUFVLGlCQUFrQjs7OztVQUM5Qjs7Ozs7O0FBRVY7O0FBRUEsU0FBUyxXQUFXOzs7Q0FFbEIsTUFBTSxFQUFFLGVBQWUsVUFBVTs7Q0FHakMsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQXFCLENBQUMsQ0FBQztDQUN6RCxNQUFNLENBQUMsd0JBQXNELFNBQVMsQ0FBQzs7Q0FHdkUsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBd0IsSUFBSTs7Q0FHNUUsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsSUFBSTtDQUMvQyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQXdCLElBQUk7O0NBR3RELGdCQUFnQjtFQUNkLGVBQWUsZ0JBQWdCO0dBQzdCLElBQUksQ0FBQyxZQUFZO0lBQ2YsU0FBUywyQkFBMkI7SUFDcEMsYUFBYSxLQUFLO0lBQ2xCO0dBQ0Y7R0FFQSxJQUFJOztJQUVGLE1BQU0sT0FBTyxNQUFNLHVCQUF1QixVQUFVO0lBRXBELGFBQWEsSUFBSTtHQUNuQixTQUFTLE9BQU87SUFDZCxRQUFRLE1BQU0sNkJBQTZCLEtBQUs7SUFDaEQsU0FBUywyQkFBMkI7R0FDdEMsVUFBVTtJQUNSLGFBQWEsS0FBSztHQUNwQjtFQUNGO0VBRUEsY0FBYztDQUNoQixHQUFHLENBQUMsVUFBVSxDQUFDOztDQUdmLElBQUksV0FBVztFQUNiLE9BQ0Usd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFDZCx3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUNqQix3QkFBQyxLQUFELFlBQUcsdUJBQXVCOzs7OztHQUNuQjs7Ozs7RUFDTDs7Ozs7Q0FFVjs7Q0FHQSxJQUFJLE9BQU87RUFDVCxPQUNFLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO2FBQ2Qsd0JBQUMsV0FBRDtJQUFTLFdBQVU7Y0FDakIsd0JBQUMsS0FBRCxZQUFJLE1BQVM7Ozs7O0dBQ047Ozs7O0VBQ0w7Ozs7O0NBRVY7O0NBR0EsSUFBSSxVQUFVLFdBQVcsR0FBRztFQUMxQixPQUNFLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO2FBQ2Qsd0JBQUMsV0FBRDtJQUFTLFdBQVU7Y0FDakIsd0JBQUMsS0FBRCxZQUFHLHdDQUF3Qzs7Ozs7R0FDcEM7Ozs7O0VBQ0w7Ozs7O0NBRVY7O0NBR0EsTUFBTSxrQkFBa0IsVUFBVTs7Q0FHbEMsTUFBTSxpQkFBaUIsZ0JBQWdCLFFBQVEsTUFDNUMsV0FBVyxPQUFPLE9BQU8sZ0JBQzVCO0NBRUEsT0FDRSx3QkFBQyxRQUFEO0VBQU0sV0FBVTtZQUNkLHdCQUFDLFdBQUQ7R0FBUyxXQUFVO0dBQWEsbUJBQWdCO2FBQWhEO0lBQ0Usd0JBQUMsTUFBRDtLQUNFLElBQUc7S0FDSCxPQUFPO01BQ0wsVUFBVTtNQUNWLE9BQU87TUFDUCxRQUFRO01BQ1IsVUFBVTtNQUNWLE1BQU07S0FDUjtlQUNEO0lBRUc7Ozs7O0lBRUosd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBZSxhQUFVO2VBQXhDO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxhQUFELENBQWM7Ozs7aUJBRWQsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWdCLGdCQUFnQjtPQUFhOzs7O2VBQ3pEOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLGFBQUQsQ0FBYzs7OztpQkFFZCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZ0IsZ0JBQWdCO09BQVk7Ozs7ZUFDeEQ7Ozs7OztNQUdKLGtCQUNDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWUsZUFBZTtPQUFVOzs7O2lCQUV2RCx3QkFBQyxZQUFELENBQWE7Ozs7ZUFDVjs7Ozs7O0tBRUo7Ozs7OztJQUVMLHdCQUFDLE9BQUQsRUFBSyxXQUFVLFVBQVc7Ozs7O0lBRTFCLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQWMsTUFBSztLQUFRLGNBQVc7ZUFFbEQsZ0JBQWdCLFFBQVEsS0FBSyxRQUFRLFVBQ3BDLHdCQUFDLFVBQUQ7TUFDRSxXQUFXLGdCQUNULHFCQUFxQixPQUFPLEtBQUssY0FBYztNQUdqRCxlQUFlLG9CQUFvQixPQUFPLEVBQUU7TUFDNUMsTUFBSztnQkFOUCxDQVNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUNiLE9BQU8sYUFBYSxLQUFLLEtBQUs7TUFDM0I7Ozs7Z0JBRU4sd0JBQUMsUUFBRCxZQUFPLE9BQU8sS0FBVzs7OztjQUNuQjtRQVZELE9BQU87Ozs7WUFVTixDQUNUO0lBQ0U7Ozs7O0dBQ0U7Ozs7OztDQUNMOzs7OztBQUVWOzs7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUXVpelBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uL3N0eWxlcy9RdWl6UGFnZS5jc3NcIjtcclxuXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlUGFyYW1zIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuXHJcbmltcG9ydCB7IGdldFF1ZXN0aW9uc0J5Q2F0ZWdvcnkgfSBmcm9tIFwiLi4vYXBpL3F1ZXN0aW9uQXBpXCI7XHJcbmltcG9ydCB0eXBlIHsgUXVlc3Rpb24gfSBmcm9tIFwiLi4vdHlwZXMvcXVlc3Rpb25cIjtcclxuXHJcbmZ1bmN0aW9uIFJvYm90QXZhdGFyKCkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8c3BhbiBjbGFzc05hbWU9XCJyb2JvdC1hdmF0YXJcIiBhcmlhLWhpZGRlbj1cInRydWVcIj5cclxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicm9ib3QtYW50ZW5uYVwiIC8+XHJcbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJvYm90LWZhY2VcIj5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyb2JvdC1leWUgcm9ib3QtZXllLWxlZnRcIiAvPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJvYm90LWV5ZSByb2JvdC1leWUtcmlnaHRcIiAvPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJvYm90LW1vdXRoXCIgLz5cclxuICAgICAgPC9zcGFuPlxyXG4gICAgPC9zcGFuPlxyXG4gICk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIFVzZXJBdmF0YXIoKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzcGFuIGNsYXNzTmFtZT1cInVzZXItYXZhdGFyXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+XHJcbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInVzZXItaGVhZFwiIC8+XHJcbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInVzZXItc2hvdWxkZXJzXCIgLz5cclxuICAgIDwvc3Bhbj5cclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBRdWl6UGFnZSgpIHtcclxuICAvLyBIw6RtdGFyIGthdGVnb3JpLWlkIGZyw6VuIFVSTDplbiBmw7ZyIGF0dCB2ZXRhIHZpbGtlbiBrYXRlZ29yaXMgZnLDpWdvciBzb20gc2thIHZpc2FzLlxyXG4gIGNvbnN0IHsgY2F0ZWdvcnlJZCB9ID0gdXNlUGFyYW1zKCk7XHJcblxyXG4gIC8vIFNwYXJhciBmcsOlZ29ybmEgc29tIGjDpG10YXMgZnLDpW4gYmFja2VuZC5cclxuICBjb25zdCBbcXVlc3Rpb25zLCBzZXRRdWVzdGlvbnNdID0gdXNlU3RhdGU8UXVlc3Rpb25bXT4oW10pO1xyXG4gIGNvbnN0IFtjdXJyZW50UXVlc3Rpb25JbmRleCAvKiBzZXRDdXJyZW50UXVlc3Rpb25JbmRleCAqL10gPSB1c2VTdGF0ZSgwKTsgLy8gYWt0aXZlcmEgbsOkciBuYXZpZ2VyaW5nIG1lbGxhbiBmcsOlZ29yIGltcGxlbWVudGVyYXNcclxuXHJcbiAgLy8gSMOlbGxlciByZWRhIHDDpSB2aWxrZXQgc3ZhciBhbnbDpG5kYXJlbiBoYXIgdmFsdC5cclxuICBjb25zdCBbc2VsZWN0ZWRBbnN3ZXJJZCwgc2V0U2VsZWN0ZWRBbnN3ZXJJZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuXHJcbiAgLy8gSGFudGVyYXIgbGFkZG5pbmdzc3RhdHVzIG9jaCBldmVudHVlbGxhIGZlbCB2aWQgaMOkbXRuaW5nLlxyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG5cclxuICAvLyBIw6RtdGFyIGZyw6Vnb3IgcMOlIG55dHQgbsOkciBjYXRlZ29yeUlkIMOkbmRyYXMuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGFzeW5jIGZ1bmN0aW9uIGxvYWRRdWVzdGlvbnMoKSB7XHJcbiAgICAgIGlmICghY2F0ZWdvcnlJZCkge1xyXG4gICAgICAgIHNldEVycm9yKFwiTm8gY2F0ZWdvcnkgd2FzIHNlbGVjdGVkLlwiKTtcclxuICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG5cclxuICAgICAgdHJ5IHtcclxuICAgICAgICAvLyBIw6RtdGFyIGFsbGEgZnLDpWdvciBzb20gdGlsbGjDtnIgZGVuIHZhbGRhIGthdGVnb3Jpbi5cclxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgZ2V0UXVlc3Rpb25zQnlDYXRlZ29yeShjYXRlZ29yeUlkKTtcclxuXHJcbiAgICAgICAgc2V0UXVlc3Rpb25zKGRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gbG9hZCBxdWVzdGlvbnM6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRFcnJvcihcIkNvdWxkIG5vdCBsb2FkIHF1ZXN0aW9ucy5cIik7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGxvYWRRdWVzdGlvbnMoKTtcclxuICB9LCBbY2F0ZWdvcnlJZF0pO1xyXG5cclxuICAvLyBMb2FkaW5nIHZpc2FzIG1lZGFuIGZyw6Vnb3JuYSBow6RtdGFzIGZyw6VuIGJhY2tlbmQuXHJcbiAgaWYgKGlzTG9hZGluZykge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwicXVpei1wYWdlXCI+XHJcbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicXVpei1zaGVsbFwiPlxyXG4gICAgICAgICAgPHA+TG9hZGluZyBxdWVzdGlvbnMuLi48L3A+XHJcbiAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICA8L21haW4+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgLy8ga2FzdGFyIGZlbG1lZGRlbGFuZGUgb20gaMOkbXRuaW5nZW4gYXYgZnLDpWdvciBtaXNzbHlja2FzLlxyXG4gIGlmIChlcnJvcikge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwicXVpei1wYWdlXCI+XHJcbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicXVpei1zaGVsbFwiPlxyXG4gICAgICAgICAgPHA+e2Vycm9yfTwvcD5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgIDwvbWFpbj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICAvLyBIYW50ZXJhciBmYWxsZXQgZMOkciBrYXRlZ29yaW4gaW50ZSBpbm5laMOlbGxlciBuw6VncmEgZnLDpWdvci5cclxuICBpZiAocXVlc3Rpb25zLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwicXVpei1wYWdlXCI+XHJcbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicXVpei1zaGVsbFwiPlxyXG4gICAgICAgICAgPHA+Tm8gcXVlc3Rpb25zIGZvdW5kIGZvciB0aGlzIGNhdGVnb3J5LjwvcD5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgIDwvbWFpbj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICAvLyBIw6RtdGFyIGRlbiBmcsOlZ2Egc29tIHNrYSB2aXNhcyBqdXN0IG51LlxyXG4gIGNvbnN0IGN1cnJlbnRRdWVzdGlvbiA9IHF1ZXN0aW9uc1tjdXJyZW50UXVlc3Rpb25JbmRleF07XHJcblxyXG4gIC8vIExldGFyIHVwcCBoZWxhIHN2YXJzYWx0ZXJuYXRpdmV0IHV0aWZyw6VuIGRldCB2YWxkYSBzdmFyZXRzIGlkLlxyXG4gIGNvbnN0IHNlbGVjdGVkQW5zd2VyID0gY3VycmVudFF1ZXN0aW9uLm9wdGlvbnMuZmluZChcclxuICAgIChvcHRpb24pID0+IG9wdGlvbi5pZCA9PT0gc2VsZWN0ZWRBbnN3ZXJJZCxcclxuICApO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPG1haW4gY2xhc3NOYW1lPVwicXVpei1wYWdlXCI+XHJcbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInF1aXotc2hlbGxcIiBhcmlhLWxhYmVsbGVkYnk9XCJxdWl6LXRpdGxlXCI+XHJcbiAgICAgICAgPGgxXHJcbiAgICAgICAgICBpZD1cInF1aXotdGl0bGVcIlxyXG4gICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgcG9zaXRpb246IFwiYWJzb2x1dGVcIixcclxuICAgICAgICAgICAgd2lkdGg6IDEsXHJcbiAgICAgICAgICAgIGhlaWdodDogMSxcclxuICAgICAgICAgICAgb3ZlcmZsb3c6IFwiaGlkZGVuXCIsXHJcbiAgICAgICAgICAgIGNsaXA6IFwicmVjdCgwIDAgMCAwKVwiLFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICBUZWNoTGluZ28gcXVpelxyXG4gICAgICAgIDwvaDE+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udmVyc2F0aW9uXCIgYXJpYS1saXZlPVwicG9saXRlXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lc3NhZ2Utcm93XCI+XHJcbiAgICAgICAgICAgIDxSb2JvdEF2YXRhciAvPlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJidWJibGUgcm9ib3RcIj57Y3VycmVudFF1ZXN0aW9uLm1lc3NhZ2V9PC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lc3NhZ2Utcm93XCI+XHJcbiAgICAgICAgICAgIDxSb2JvdEF2YXRhciAvPlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJidWJibGUgcm9ib3RcIj57Y3VycmVudFF1ZXN0aW9uLnByb21wdH08L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBWaXNhciBhbnbDpG5kYXJlbnMgdmFsZGEgc3ZhciBpIGNoYXR0ZW4uICovfVxyXG4gICAgICAgICAge3NlbGVjdGVkQW5zd2VyICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZXNzYWdlLXJvdyB1c2VyXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJidWJibGUgdXNlclwiPntzZWxlY3RlZEFuc3dlci50ZXh0fTwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8VXNlckF2YXRhciAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGl2aWRlclwiIC8+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5zd2VyLWdyaWRcIiByb2xlPVwiZ3JvdXBcIiBhcmlhLWxhYmVsPVwiVsOkbGogZXR0IHN2YXJcIj5cclxuICAgICAgICAgIHsvKiBTa2FwYXIgZW4ga25hcHAgZsO2ciB2YXJqZSBzdmFyc2FsdGVybmF0aXYgc29tIGtvbW1lciBmcsOlbiBiYWNrZW5kLiAqL31cclxuICAgICAgICAgIHtjdXJyZW50UXVlc3Rpb24ub3B0aW9ucy5tYXAoKGFuc3dlciwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YGFuc3dlci1idXR0b24ke1xyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRBbnN3ZXJJZCA9PT0gYW5zd2VyLmlkID8gXCIgc2VsZWN0ZWRcIiA6IFwiXCJcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICBrZXk9e2Fuc3dlci5pZH1cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZEFuc3dlcklkKGFuc3dlci5pZCl9XHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7LyogT212YW5kbGFyIGluZGV4IDAsIDEsIDIsIDMgdGlsbCBib2tzdMOkdmVybmEgQSwgQiwgQywgRC4gKi99XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYW5zd2VyLWxldHRlclwiPlxyXG4gICAgICAgICAgICAgICAge1N0cmluZy5mcm9tQ2hhckNvZGUoNjUgKyBpbmRleCl9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICA8c3Bhbj57YW5zd2VyLnRleHR9PC9zcGFuPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L3NlY3Rpb24+XHJcbiAgICA8L21haW4+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUXVpelBhZ2U7XHJcbiJdfQ==