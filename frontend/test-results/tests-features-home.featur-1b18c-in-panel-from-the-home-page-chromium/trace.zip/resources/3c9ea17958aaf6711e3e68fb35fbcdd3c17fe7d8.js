import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/QuizPage.tsx");const useEffect = __vite__cjsImport1_react["useEffect"]; const useState = __vite__cjsImport1_react["useState"]; const useRef = __vite__cjsImport1_react["useRef"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport5_react_jsxDevRuntime["Fragment"];import "/src/styles/QuizPage.css";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=57280423";
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=57280423";
import { getCategories } from "/src/api/categoryApi.ts";
import { startQuiz, submitQuizAnswer, completeQuiz } from "/src/api/quizApi.ts";
var _jsxFileName = "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/pages/QuizPage.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=57280423";
var _s = $RefreshSig$();
function RobotAvatar() {
	return /* @__PURE__ */ _jsxDEV("span", {
		className: "robot-avatar",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ _jsxDEV("span", { className: "robot-antenna" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("span", {
			className: "robot-face",
			children: [
				/* @__PURE__ */ _jsxDEV("span", { className: "robot-eye robot-eye-left" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 17,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("span", { className: "robot-eye robot-eye-right" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 18,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("span", { className: "robot-mouth" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 19,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 16,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 5
	}, this);
}
_c = RobotAvatar;
function UserAvatar() {
	return /* @__PURE__ */ _jsxDEV("span", {
		className: "user-avatar",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ _jsxDEV("span", { className: "user-head" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("span", { className: "user-shoulders" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 29,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 27,
		columnNumber: 5
	}, this);
}
_c2 = UserAvatar;
function QuizPage() {
	_s();
	const { categoryId } = useParams();
	const [questions, setQuestions] = useState([]);
	const [quizName, setQuizName] = useState("Quiz");
	const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
	const [selectedAnswerId, setSelectedAnswerId] = useState(null);
	const [isLoading, setIsLoading] = useState(true);
	const [error, setError] = useState(null);
	const [answerResult, setAnswerResult] = useState(null);
	const [isSubmittingAnswer, setIsSubmittingAnswer] = useState(false);
	const [answerError, setAnswerError] = useState(null);
	const [score, setScore] = useState(0);
	const [sessionId, setSessionId] = useState(null);
	const [quizResult, setQuizResult] = useState(null);
	const [isCompletingQuiz, setIsCompletingQuiz] = useState(false);
	const startQuizPromiseRef = useRef(null);
	const startQuizCategoryRef = useRef(null);
	useEffect(() => {
		let ignore = false;
		async function loadQuestions() {
			if (!categoryId) {
				setError("No category was selected.");
				setIsLoading(false);
				return;
			}
			try {
				setIsLoading(true);
				setError(null);
				setQuestions([]);
				setQuizName("Quiz");
				setCurrentQuestionIndex(0);
				setSelectedAnswerId(null);
				setAnswerResult(null);
				setAnswerError(null);
				setIsSubmittingAnswer(false);
				setIsCompletingQuiz(false);
				setScore(0);
				setSessionId(null);
				setQuizResult(null);
				//för att inte start 2 quiz (strict mode)
				if (startQuizCategoryRef.current !== categoryId || !startQuizPromiseRef.current) {
					startQuizCategoryRef.current = categoryId;
					startQuizPromiseRef.current = startQuiz(categoryId);
				}
				const quiz = await startQuizPromiseRef.current;
				if (!ignore) {
					setSessionId(quiz.sessionId);
					setQuestions(quiz.questions);
				}
				try {
					const categories = await getCategories();
					const category = categories.find((item) => item.id === categoryId);
					if (!ignore && category) {
						setQuizName(category.name);
					}
				} catch (categoryError) {
					console.error("Failed to load quiz name:", categoryError);
				}
			} catch (error) {
				if (!ignore) {
					console.error("Failed to start quiz:", error);
					setError("Could not load questions.");
				}
			} finally {
				if (!ignore) {
					setIsLoading(false);
				}
			}
		}
		loadQuestions();
		return () => {
			ignore = true;
		};
	}, [categoryId]);
	if (isLoading) {
		return /* @__PURE__ */ _jsxDEV("main", {
			className: "quiz-page",
			children: /* @__PURE__ */ _jsxDEV("section", {
				className: "quiz-shell",
				children: /* @__PURE__ */ _jsxDEV("p", {
					className: "quiz-status",
					children: "Loading questions..."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 146,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 145,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 144,
			columnNumber: 7
		}, this);
	}
	if (error) {
		return /* @__PURE__ */ _jsxDEV("main", {
			className: "quiz-page",
			children: /* @__PURE__ */ _jsxDEV("section", {
				className: "quiz-shell",
				children: /* @__PURE__ */ _jsxDEV("p", {
					className: "quiz-status",
					children: error
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 156,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 155,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 154,
			columnNumber: 7
		}, this);
	}
	if (questions.length === 0) {
		return /* @__PURE__ */ _jsxDEV("main", {
			className: "quiz-page",
			children: /* @__PURE__ */ _jsxDEV("section", {
				className: "quiz-shell",
				children: /* @__PURE__ */ _jsxDEV("p", {
					className: "quiz-status",
					children: "No questions found for this category."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 166,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 165,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 164,
			columnNumber: 7
		}, this);
	}
	const currentQuestion = questions[currentQuestionIndex];
	const selectedAnswer = currentQuestion.options.find((option) => option.id === selectedAnswerId);
	const isLastQuestion = currentQuestionIndex === questions.length - 1;
	const handleAnswerClick = async (answerId) => {
		if (isSubmittingAnswer || answerResult || quizResult || !sessionId) {
			return;
		}
		setSelectedAnswerId(answerId);
		setAnswerResult(null);
		setAnswerError(null);
		setIsSubmittingAnswer(true);
		try {
			const result = await submitQuizAnswer(sessionId, {
				questionId: currentQuestion.id,
				answerId
			});
			setAnswerResult(result);
			setScore((currentScore) => currentScore + result.points);
		} catch (error) {
			console.error("Failed to submit answer:", error);
			setAnswerError("Could not check the answer.");
		} finally {
			setIsSubmittingAnswer(false);
		}
	};
	const handleNextQuestion = async () => {
		if (!answerResult || isCompletingQuiz) {
			return;
		}
		if (isLastQuestion) {
			if (!sessionId) {
				return;
			}
			try {
				setIsCompletingQuiz(true);
				setAnswerError(null);
				const result = await completeQuiz(sessionId);
				setQuizResult(result);
				setScore(result.quizScore);
			} catch (error) {
				console.error("Failed to complete quiz:", error);
				setAnswerError("Could not complete the quiz.");
			} finally {
				setIsCompletingQuiz(false);
			}
			return;
		}
		setCurrentQuestionIndex((currentIndex) => currentIndex + 1);
		setSelectedAnswerId(null);
		setAnswerResult(null);
		setAnswerError(null);
	};
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "quiz-page",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "quiz-placeholder",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "quiz-stat quiz-stat--name",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "quiz-stat-label",
						children: "Quiz"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 249,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("strong", { children: quizName }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 251,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 248,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { "aria-hidden": "true" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 254,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "quiz-stat-group",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "quiz-stat quiz-stat--question",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "quiz-stat-label",
							children: "Question"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 258,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("strong", { children: [
							currentQuestionIndex + 1,
							" / ",
							questions.length
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 260,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 257,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "quiz-stat quiz-stat--score",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "quiz-stat-label",
							children: "Score"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 266,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("strong", { children: score }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 268,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 265,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 256,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 247,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("section", {
			className: "quiz-shell",
			"aria-labelledby": "quiz-title",
			children: [
				/* @__PURE__ */ _jsxDEV("h1", {
					id: "quiz-title",
					className: "visually-hidden",
					children: "TechLingo quiz"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 274,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "conversation",
					"aria-live": "polite",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "message-row message-row--robot",
							children: [/* @__PURE__ */ _jsxDEV(RobotAvatar, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 280,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "message-content",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "message-sender",
									children: "TechLingo"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 283,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "bubble bubble--robot",
									children: currentQuestion.message
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 285,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 282,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 279,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "message-row message-row--robot",
							children: [/* @__PURE__ */ _jsxDEV(RobotAvatar, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 292,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "message-content",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "message-sender",
									children: "TechLingo"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 295,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "bubble bubble--robot",
									children: currentQuestion.prompt
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 297,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 294,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 291,
							columnNumber: 11
						}, this),
						selectedAnswer && /* @__PURE__ */ _jsxDEV("div", {
							className: "message-row message-row--user",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "message-content message-content--user",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "message-sender message-sender--user",
									children: "You"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 306,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "bubble bubble--user",
									children: selectedAnswer.text
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 308,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 305,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(UserAvatar, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 311,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 304,
							columnNumber: 13
						}, this),
						answerResult && /* @__PURE__ */ _jsxDEV("div", {
							className: "message-row message-row--robot",
							children: [/* @__PURE__ */ _jsxDEV(RobotAvatar, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 317,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "message-content",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "message-sender",
									children: "TechLingo"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 320,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "bubble bubble--robot",
									children: answerResult.isCorrect ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
										"Correct! You got",
										" ",
										/* @__PURE__ */ _jsxDEV("span", {
											className: "points",
											children: answerResult.points
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 326,
											columnNumber: 23
										}, this),
										" ",
										"points."
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 324,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
										"Not quite. The correct answer is \"",
										answerResult.correctAnswer,
										"\".",
										/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 334,
											columnNumber: 23
										}, this),
										"You got",
										" ",
										/* @__PURE__ */ _jsxDEV("span", {
											className: "points wrong",
											children: answerResult.points
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 336,
											columnNumber: 23
										}, this),
										" ",
										"points."
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 330,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 322,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 319,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 316,
							columnNumber: 13
						}, this),
						quizResult && /* @__PURE__ */ _jsxDEV("div", {
							className: "message-row message-row--robot",
							children: [/* @__PURE__ */ _jsxDEV(RobotAvatar, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 349,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "message-content",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "message-sender",
									children: "TechLingo"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 352,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "bubble bubble--robot",
									children: [
										"Quiz complete!",
										/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 356,
											columnNumber: 19
										}, this),
										"Quiz score: ",
										quizResult.quizScore,
										/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 358,
											columnNumber: 19
										}, this),
										"Total score: ",
										quizResult.totalScore
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 354,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 351,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 348,
							columnNumber: 13
						}, this),
						answerError && /* @__PURE__ */ _jsxDEV("div", {
							className: "message-row message-row--robot",
							children: [/* @__PURE__ */ _jsxDEV(RobotAvatar, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 367,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "message-content",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "message-sender",
									children: "TechLingo"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 370,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "bubble bubble--robot",
									children: answerError
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 372,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 369,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 366,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 278,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { className: "divider" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 378,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "answer-grid",
					role: "group",
					"aria-label": "Choose an answer",
					children: currentQuestion.options.map((answer, index) => /* @__PURE__ */ _jsxDEV("button", {
						className: `answer-button${selectedAnswerId === answer.id ? " selected" : ""}${answerResult?.correctAnswerId === answer.id ? " correct" : ""}${answerResult && !answerResult.isCorrect && selectedAnswerId === answer.id ? " incorrect" : ""}`,
						onClick: () => handleAnswerClick(answer.id),
						type: "button",
						disabled: isSubmittingAnswer || answerResult !== null || quizResult !== null,
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "answer-letter",
							children: String.fromCharCode(65 + index)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 403,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: answer.text }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 407,
							columnNumber: 15
						}, this)]
					}, answer.id, true, {
						fileName: _jsxFileName,
						lineNumber: 382,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 380,
					columnNumber: 9
				}, this),
				answerResult && !quizResult && /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: handleNextQuestion,
					disabled: isCompletingQuiz,
					children: isCompletingQuiz ? "Finishing..." : isLastQuestion ? "Finish quiz" : "Next question"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 413,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 273,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 246,
		columnNumber: 5
	}, this);
}
_s(QuizPage, "ueGX6X7A125X9ZMadpMkJs53XSI=", false, function() {
	return [useParams];
});
_c3 = QuizPage;
export default QuizPage;
var _c, _c2, _c3;
$RefreshReg$(_c, "RobotAvatar");
$RefreshReg$(_c2, "UserAvatar");
$RefreshReg$(_c3, "QuizPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/QuizPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/pages/QuizPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/pages/QuizPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/fredr/source/repos/Sysm9/Ämnesövergripande Projekt/TechLingo/frontend/src/pages/QuizPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTztBQUVQLFNBQVMsV0FBVyxVQUFVLGNBQWM7QUFDNUMsU0FBUyxpQkFBaUI7QUFFMUIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxXQUFXLGtCQUFrQixvQkFBb0I7Ozs7QUFJMUQsU0FBUyxjQUFjO0NBQ3JCLE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFdBQVU7RUFBZSxlQUFZO1lBQTNDLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsZ0JBQWlCOzs7O1lBRWpDLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO2FBQWhCO0lBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsMkJBQTRCOzs7OztJQUM1Qyx3QkFBQyxRQUFELEVBQU0sV0FBVSw0QkFBNkI7Ozs7O0lBQzdDLHdCQUFDLFFBQUQsRUFBTSxXQUFVLGNBQWU7Ozs7O0dBQzNCOzs7OztVQUNGOzs7Ozs7QUFFVjs7QUFFQSxTQUFTLGFBQWE7Q0FDcEIsT0FDRSx3QkFBQyxRQUFEO0VBQU0sV0FBVTtFQUFjLGVBQVk7WUFBMUMsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxZQUFhOzs7O1lBQzdCLHdCQUFDLFFBQUQsRUFBTSxXQUFVLGlCQUFrQjs7OztVQUM5Qjs7Ozs7O0FBRVY7O0FBRUEsU0FBUyxXQUFXOztDQUNsQixNQUFNLEVBQUUsZUFBZSxVQUFVO0NBRWpDLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFxQixDQUFDLENBQUM7Q0FFekQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLE1BQU07Q0FFL0MsTUFBTSxDQUFDLHNCQUFzQiwyQkFBMkIsU0FBUyxDQUFDO0NBRWxFLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQXdCLElBQUk7Q0FFNUUsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsSUFBSTtDQUUvQyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQXdCLElBQUk7Q0FFdEQsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQThCLElBQUk7Q0FFMUUsTUFBTSxDQUFDLG9CQUFvQix5QkFBeUIsU0FBUyxLQUFLO0NBRWxFLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUF3QixJQUFJO0NBRWxFLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxDQUFDO0NBRXBDLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUF3QixJQUFJO0NBRTlELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUE0QixJQUFJO0NBRXBFLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsS0FBSztDQUU5RCxNQUFNLHNCQUFzQixPQUE0QyxJQUFJO0NBQzVFLE1BQU0sdUJBQXVCLE9BQXNCLElBQUk7Q0FFdkQsZ0JBQWdCO0VBQ2QsSUFBSSxTQUFTO0VBRWIsZUFBZSxnQkFBZ0I7R0FDN0IsSUFBSSxDQUFDLFlBQVk7SUFDZixTQUFTLDJCQUEyQjtJQUNwQyxhQUFhLEtBQUs7SUFDbEI7R0FDRjtHQUVBLElBQUk7SUFDRixhQUFhLElBQUk7SUFDakIsU0FBUyxJQUFJO0lBRWIsYUFBYSxDQUFDLENBQUM7SUFDZixZQUFZLE1BQU07SUFFbEIsd0JBQXdCLENBQUM7SUFDekIsb0JBQW9CLElBQUk7SUFDeEIsZ0JBQWdCLElBQUk7SUFDcEIsZUFBZSxJQUFJO0lBRW5CLHNCQUFzQixLQUFLO0lBQzNCLG9CQUFvQixLQUFLO0lBRXpCLFNBQVMsQ0FBQztJQUNWLGFBQWEsSUFBSTtJQUNqQixjQUFjLElBQUk7O0lBR2xCLElBQ0UscUJBQXFCLFlBQVksY0FDakMsQ0FBQyxvQkFBb0IsU0FDckI7S0FDQSxxQkFBcUIsVUFBVTtLQUMvQixvQkFBb0IsVUFBVSxVQUFVLFVBQVU7SUFDcEQ7SUFFQSxNQUFNLE9BQU8sTUFBTSxvQkFBb0I7SUFFdkMsSUFBSSxDQUFDLFFBQVE7S0FDWCxhQUFhLEtBQUssU0FBUztLQUMzQixhQUFhLEtBQUssU0FBUztJQUM3QjtJQUVBLElBQUk7S0FDRixNQUFNLGFBQWEsTUFBTSxjQUFjO0tBRXZDLE1BQU0sV0FBVyxXQUFXLE1BQU0sU0FBUyxLQUFLLE9BQU8sVUFBVTtLQUVqRSxJQUFJLENBQUMsVUFBVSxVQUFVO01BQ3ZCLFlBQVksU0FBUyxJQUFJO0tBQzNCO0lBQ0YsU0FBUyxlQUFlO0tBQ3RCLFFBQVEsTUFBTSw2QkFBNkIsYUFBYTtJQUMxRDtHQUNGLFNBQVMsT0FBTztJQUNkLElBQUksQ0FBQyxRQUFRO0tBQ1gsUUFBUSxNQUFNLHlCQUF5QixLQUFLO0tBRTVDLFNBQVMsMkJBQTJCO0lBQ3RDO0dBQ0YsVUFBVTtJQUNSLElBQUksQ0FBQyxRQUFRO0tBQ1gsYUFBYSxLQUFLO0lBQ3BCO0dBQ0Y7RUFDRjtFQUVBLGNBQWM7RUFFZCxhQUFhO0dBQ1gsU0FBUztFQUNYO0NBQ0YsR0FBRyxDQUFDLFVBQVUsQ0FBQztDQUVmLElBQUksV0FBVztFQUNiLE9BQ0Usd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFDZCx3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUNqQix3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFjO0lBQXVCOzs7OztHQUMzQzs7Ozs7RUFDTDs7Ozs7Q0FFVjtDQUVBLElBQUksT0FBTztFQUNULE9BQ0Usd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFDZCx3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUNqQix3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFlO0lBQVM7Ozs7O0dBQzlCOzs7OztFQUNMOzs7OztDQUVWO0NBRUEsSUFBSSxVQUFVLFdBQVcsR0FBRztFQUMxQixPQUNFLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO2FBQ2Qsd0JBQUMsV0FBRDtJQUFTLFdBQVU7Y0FDakIsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBYztJQUF3Qzs7Ozs7R0FDNUQ7Ozs7O0VBQ0w7Ozs7O0NBRVY7Q0FFQSxNQUFNLGtCQUFrQixVQUFVO0NBRWxDLE1BQU0saUJBQWlCLGdCQUFnQixRQUFRLE1BQzVDLFdBQVcsT0FBTyxPQUFPLGdCQUM1QjtDQUVBLE1BQU0saUJBQWlCLHlCQUF5QixVQUFVLFNBQVM7Q0FFbkUsTUFBTSxvQkFBb0IsT0FBTyxhQUFxQjtFQUNwRCxJQUFJLHNCQUFzQixnQkFBZ0IsY0FBYyxDQUFDLFdBQVc7R0FDbEU7RUFDRjtFQUVBLG9CQUFvQixRQUFRO0VBQzVCLGdCQUFnQixJQUFJO0VBQ3BCLGVBQWUsSUFBSTtFQUNuQixzQkFBc0IsSUFBSTtFQUUxQixJQUFJO0dBQ0YsTUFBTSxTQUFTLE1BQU0saUJBQWlCLFdBQVc7SUFDL0MsWUFBWSxnQkFBZ0I7SUFDNUI7R0FDRixDQUFDO0dBRUQsZ0JBQWdCLE1BQU07R0FFdEIsVUFBVSxpQkFBaUIsZUFBZSxPQUFPLE1BQU07RUFDekQsU0FBUyxPQUFPO0dBQ2QsUUFBUSxNQUFNLDRCQUE0QixLQUFLO0dBRS9DLGVBQWUsNkJBQTZCO0VBQzlDLFVBQVU7R0FDUixzQkFBc0IsS0FBSztFQUM3QjtDQUNGO0NBRUEsTUFBTSxxQkFBcUIsWUFBWTtFQUNyQyxJQUFJLENBQUMsZ0JBQWdCLGtCQUFrQjtHQUNyQztFQUNGO0VBRUEsSUFBSSxnQkFBZ0I7R0FDbEIsSUFBSSxDQUFDLFdBQVc7SUFDZDtHQUNGO0dBRUEsSUFBSTtJQUNGLG9CQUFvQixJQUFJO0lBQ3hCLGVBQWUsSUFBSTtJQUVuQixNQUFNLFNBQVMsTUFBTSxhQUFhLFNBQVM7SUFFM0MsY0FBYyxNQUFNO0lBRXBCLFNBQVMsT0FBTyxTQUFTO0dBQzNCLFNBQVMsT0FBTztJQUNkLFFBQVEsTUFBTSw0QkFBNEIsS0FBSztJQUUvQyxlQUFlLDhCQUE4QjtHQUMvQyxVQUFVO0lBQ1Isb0JBQW9CLEtBQUs7R0FDM0I7R0FFQTtFQUNGO0VBRUEseUJBQXlCLGlCQUFpQixlQUFlLENBQUM7RUFFMUQsb0JBQW9CLElBQUk7RUFDeEIsZ0JBQWdCLElBQUk7RUFDcEIsZUFBZSxJQUFJO0NBQ3JCO0NBRUEsT0FDRSx3QkFBQyxRQUFEO0VBQU0sV0FBVTtZQUFoQixDQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWtCO0tBQVU7Ozs7ZUFFNUMsd0JBQUMsVUFBRCxZQUFTLFNBQWlCOzs7O2FBQ3ZCOzs7Ozs7SUFFTCx3QkFBQyxPQUFELEVBQUssZUFBWSxPQUFROzs7OztJQUV6Qix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBa0I7TUFBYzs7OztnQkFFaEQsd0JBQUMsVUFBRDtPQUNHLHVCQUF1QjtPQUFFO09BQUksVUFBVTtNQUNsQzs7OztjQUNMOzs7OztlQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWtCO01BQVc7Ozs7Z0JBRTdDLHdCQUFDLFVBQUQsWUFBUyxNQUFjOzs7O2NBQ3BCOzs7OzthQUNGOzs7Ozs7R0FDRjs7Ozs7WUFFTCx3QkFBQyxXQUFEO0dBQVMsV0FBVTtHQUFhLG1CQUFnQjthQUFoRDtJQUNFLHdCQUFDLE1BQUQ7S0FBSSxJQUFHO0tBQWEsV0FBVTtlQUFrQjtJQUU1Qzs7Ozs7SUFFSix3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUFlLGFBQVU7ZUFBeEM7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLGFBQUQsQ0FBYzs7OztpQkFFZCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFpQjtRQUFlOzs7O2tCQUVoRCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDWixnQkFBZ0I7UUFDZDs7OztnQkFDRjs7Ozs7ZUFDRjs7Ozs7O01BRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxhQUFELENBQWM7Ozs7aUJBRWQsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaUI7UUFBZTs7OztrQkFFaEQsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ1osZ0JBQWdCO1FBQ2Q7Ozs7Z0JBQ0Y7Ozs7O2VBQ0Y7Ozs7OztNQUVKLGtCQUNDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBc0M7UUFBUzs7OztrQkFFL0Qsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQXVCLGVBQWU7UUFBVTs7OztnQkFDNUQ7Ozs7O2lCQUVMLHdCQUFDLFlBQUQsQ0FBYTs7OztlQUNWOzs7Ozs7TUFHTixnQkFDQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLGFBQUQsQ0FBYzs7OztpQkFFZCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFpQjtRQUFlOzs7O2tCQUVoRCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDWixhQUFhLFlBQ1o7VUFBRTtVQUNpQjtVQUNqQix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBVSxhQUFhO1VBQWE7Ozs7O1VBQUU7VUFBSTtTQUUxRDs7OztvQkFFRjtVQUFFO1VBRUMsYUFBYTtVQUFjO1VBRTVCLHdCQUFDLE1BQUQsQ0FBSzs7Ozs7VUFBQztVQUNFO1VBQ1Isd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQ2IsYUFBYTtVQUNWOzs7OztVQUFFO1VBQUk7U0FFWjs7Ozs7UUFFRDs7OztnQkFDRjs7Ozs7ZUFDRjs7Ozs7O01BR04sY0FDQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLGFBQUQsQ0FBYzs7OztpQkFFZCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFpQjtRQUFlOzs7O2tCQUVoRCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUFzQztVQUVwQyx3QkFBQyxNQUFELENBQUs7Ozs7O1VBQUM7VUFDTyxXQUFXO1VBQ3hCLHdCQUFDLE1BQUQsQ0FBSzs7Ozs7VUFBQztVQUNRLFdBQVc7U0FDdEI7Ozs7O2dCQUNGOzs7OztlQUNGOzs7Ozs7TUFHTixlQUNDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsYUFBRCxDQUFjOzs7O2lCQUVkLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWlCO1FBQWU7Ozs7a0JBRWhELHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUF3QjtRQUFpQjs7OztnQkFDckQ7Ozs7O2VBQ0Y7Ozs7OztLQUVKOzs7Ozs7SUFFTCx3QkFBQyxPQUFELEVBQUssV0FBVSxVQUFXOzs7OztJQUUxQix3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUFjLE1BQUs7S0FBUSxjQUFXO2VBQ2xELGdCQUFnQixRQUFRLEtBQUssUUFBUSxVQUNwQyx3QkFBQyxVQUFEO01BQ0UsV0FBVyxnQkFDVCxxQkFBcUIsT0FBTyxLQUFLLGNBQWMsS0FFL0MsY0FBYyxvQkFBb0IsT0FBTyxLQUFLLGFBQWEsS0FFM0QsZ0JBQ0EsQ0FBQyxhQUFhLGFBQ2QscUJBQXFCLE9BQU8sS0FDeEIsZUFDQTtNQUdOLGVBQWUsa0JBQWtCLE9BQU8sRUFBRTtNQUMxQyxNQUFLO01BQ0wsVUFDRSxzQkFDQSxpQkFBaUIsUUFDakIsZUFBZTtnQkFsQm5CLENBcUJFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUNiLE9BQU8sYUFBYSxLQUFLLEtBQUs7TUFDM0I7Ozs7Z0JBRU4sd0JBQUMsUUFBRCxZQUFPLE9BQU8sS0FBVzs7OztjQUNuQjtRQWRELE9BQU87Ozs7WUFjTixDQUNUO0lBQ0U7Ozs7O0lBRUosZ0JBQWdCLENBQUMsY0FDaEIsd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxTQUFTO0tBQ1QsVUFBVTtlQUVULG1CQUNHLGlCQUNBLGlCQUNFLGdCQUNBO0lBQ0E7Ozs7O0dBRUg7Ozs7O1VBQ0w7Ozs7OztBQUVWOzs7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUXVpelBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uL3N0eWxlcy9RdWl6UGFnZS5jc3NcIjtcclxuXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZVJlZiB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VQYXJhbXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5cclxuaW1wb3J0IHsgZ2V0Q2F0ZWdvcmllcyB9IGZyb20gXCIuLi9hcGkvY2F0ZWdvcnlBcGlcIjtcclxuaW1wb3J0IHsgc3RhcnRRdWl6LCBzdWJtaXRRdWl6QW5zd2VyLCBjb21wbGV0ZVF1aXogfSBmcm9tIFwiLi4vYXBpL3F1aXpBcGlcIjtcclxuXHJcbmltcG9ydCB0eXBlIHsgQW5zd2VyUmVzdWx0LCBRdWVzdGlvbiwgUXVpelJlc3VsdCB9IGZyb20gXCIuLi90eXBlcy9xdWVzdGlvblwiO1xyXG5cclxuZnVuY3Rpb24gUm9ib3RBdmF0YXIoKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzcGFuIGNsYXNzTmFtZT1cInJvYm90LWF2YXRhclwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxyXG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJyb2JvdC1hbnRlbm5hXCIgLz5cclxuXHJcbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJvYm90LWZhY2VcIj5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyb2JvdC1leWUgcm9ib3QtZXllLWxlZnRcIiAvPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJvYm90LWV5ZSByb2JvdC1leWUtcmlnaHRcIiAvPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJvYm90LW1vdXRoXCIgLz5cclxuICAgICAgPC9zcGFuPlxyXG4gICAgPC9zcGFuPlxyXG4gICk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIFVzZXJBdmF0YXIoKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzcGFuIGNsYXNzTmFtZT1cInVzZXItYXZhdGFyXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+XHJcbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInVzZXItaGVhZFwiIC8+XHJcbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInVzZXItc2hvdWxkZXJzXCIgLz5cclxuICAgIDwvc3Bhbj5cclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBRdWl6UGFnZSgpIHtcclxuICBjb25zdCB7IGNhdGVnb3J5SWQgfSA9IHVzZVBhcmFtcygpO1xyXG5cclxuICBjb25zdCBbcXVlc3Rpb25zLCBzZXRRdWVzdGlvbnNdID0gdXNlU3RhdGU8UXVlc3Rpb25bXT4oW10pO1xyXG5cclxuICBjb25zdCBbcXVpek5hbWUsIHNldFF1aXpOYW1lXSA9IHVzZVN0YXRlKFwiUXVpelwiKTtcclxuXHJcbiAgY29uc3QgW2N1cnJlbnRRdWVzdGlvbkluZGV4LCBzZXRDdXJyZW50UXVlc3Rpb25JbmRleF0gPSB1c2VTdGF0ZSgwKTtcclxuXHJcbiAgY29uc3QgW3NlbGVjdGVkQW5zd2VySWQsIHNldFNlbGVjdGVkQW5zd2VySWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcblxyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuXHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuXHJcbiAgY29uc3QgW2Fuc3dlclJlc3VsdCwgc2V0QW5zd2VyUmVzdWx0XSA9IHVzZVN0YXRlPEFuc3dlclJlc3VsdCB8IG51bGw+KG51bGwpO1xyXG5cclxuICBjb25zdCBbaXNTdWJtaXR0aW5nQW5zd2VyLCBzZXRJc1N1Ym1pdHRpbmdBbnN3ZXJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBbYW5zd2VyRXJyb3IsIHNldEFuc3dlckVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG5cclxuICBjb25zdCBbc2NvcmUsIHNldFNjb3JlXSA9IHVzZVN0YXRlKDApO1xyXG5cclxuICBjb25zdCBbc2Vzc2lvbklkLCBzZXRTZXNzaW9uSWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcblxyXG4gIGNvbnN0IFtxdWl6UmVzdWx0LCBzZXRRdWl6UmVzdWx0XSA9IHVzZVN0YXRlPFF1aXpSZXN1bHQgfCBudWxsPihudWxsKTtcclxuXHJcbiAgY29uc3QgW2lzQ29tcGxldGluZ1F1aXosIHNldElzQ29tcGxldGluZ1F1aXpdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBzdGFydFF1aXpQcm9taXNlUmVmID0gdXNlUmVmPFJldHVyblR5cGU8dHlwZW9mIHN0YXJ0UXVpej4gfCBudWxsPihudWxsKTtcclxuICBjb25zdCBzdGFydFF1aXpDYXRlZ29yeVJlZiA9IHVzZVJlZjxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGxldCBpZ25vcmUgPSBmYWxzZTtcclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBsb2FkUXVlc3Rpb25zKCkge1xyXG4gICAgICBpZiAoIWNhdGVnb3J5SWQpIHtcclxuICAgICAgICBzZXRFcnJvcihcIk5vIGNhdGVnb3J5IHdhcyBzZWxlY3RlZC5cIik7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIHNldEVycm9yKG51bGwpO1xyXG5cclxuICAgICAgICBzZXRRdWVzdGlvbnMoW10pO1xyXG4gICAgICAgIHNldFF1aXpOYW1lKFwiUXVpelwiKTtcclxuXHJcbiAgICAgICAgc2V0Q3VycmVudFF1ZXN0aW9uSW5kZXgoMCk7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRBbnN3ZXJJZChudWxsKTtcclxuICAgICAgICBzZXRBbnN3ZXJSZXN1bHQobnVsbCk7XHJcbiAgICAgICAgc2V0QW5zd2VyRXJyb3IobnVsbCk7XHJcblxyXG4gICAgICAgIHNldElzU3VibWl0dGluZ0Fuc3dlcihmYWxzZSk7XHJcbiAgICAgICAgc2V0SXNDb21wbGV0aW5nUXVpeihmYWxzZSk7XHJcblxyXG4gICAgICAgIHNldFNjb3JlKDApO1xyXG4gICAgICAgIHNldFNlc3Npb25JZChudWxsKTtcclxuICAgICAgICBzZXRRdWl6UmVzdWx0KG51bGwpO1xyXG5cclxuICAgICAgICAvL2bDtnIgYXR0IGludGUgc3RhcnQgMiBxdWl6IChzdHJpY3QgbW9kZSlcclxuICAgICAgICBpZiAoXHJcbiAgICAgICAgICBzdGFydFF1aXpDYXRlZ29yeVJlZi5jdXJyZW50ICE9PSBjYXRlZ29yeUlkIHx8XHJcbiAgICAgICAgICAhc3RhcnRRdWl6UHJvbWlzZVJlZi5jdXJyZW50XHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICBzdGFydFF1aXpDYXRlZ29yeVJlZi5jdXJyZW50ID0gY2F0ZWdvcnlJZDtcclxuICAgICAgICAgIHN0YXJ0UXVpelByb21pc2VSZWYuY3VycmVudCA9IHN0YXJ0UXVpeihjYXRlZ29yeUlkKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IHF1aXogPSBhd2FpdCBzdGFydFF1aXpQcm9taXNlUmVmLmN1cnJlbnQ7XHJcblxyXG4gICAgICAgIGlmICghaWdub3JlKSB7XHJcbiAgICAgICAgICBzZXRTZXNzaW9uSWQocXVpei5zZXNzaW9uSWQpO1xyXG4gICAgICAgICAgc2V0UXVlc3Rpb25zKHF1aXoucXVlc3Rpb25zKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBjb25zdCBjYXRlZ29yaWVzID0gYXdhaXQgZ2V0Q2F0ZWdvcmllcygpO1xyXG5cclxuICAgICAgICAgIGNvbnN0IGNhdGVnb3J5ID0gY2F0ZWdvcmllcy5maW5kKChpdGVtKSA9PiBpdGVtLmlkID09PSBjYXRlZ29yeUlkKTtcclxuXHJcbiAgICAgICAgICBpZiAoIWlnbm9yZSAmJiBjYXRlZ29yeSkge1xyXG4gICAgICAgICAgICBzZXRRdWl6TmFtZShjYXRlZ29yeS5uYW1lKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChjYXRlZ29yeUVycm9yKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGxvYWQgcXVpeiBuYW1lOlwiLCBjYXRlZ29yeUVycm9yKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgaWYgKCFpZ25vcmUpIHtcclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gc3RhcnQgcXVpejpcIiwgZXJyb3IpO1xyXG5cclxuICAgICAgICAgIHNldEVycm9yKFwiQ291bGQgbm90IGxvYWQgcXVlc3Rpb25zLlwiKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgaWYgKCFpZ25vcmUpIHtcclxuICAgICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbG9hZFF1ZXN0aW9ucygpO1xyXG5cclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGlnbm9yZSA9IHRydWU7XHJcbiAgICB9O1xyXG4gIH0sIFtjYXRlZ29yeUlkXSk7XHJcblxyXG4gIGlmIChpc0xvYWRpbmcpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cInF1aXotcGFnZVwiPlxyXG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInF1aXotc2hlbGxcIj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInF1aXotc3RhdHVzXCI+TG9hZGluZyBxdWVzdGlvbnMuLi48L3A+XHJcbiAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICA8L21haW4+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgaWYgKGVycm9yKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJxdWl6LXBhZ2VcIj5cclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJxdWl6LXNoZWxsXCI+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJxdWl6LXN0YXR1c1wiPntlcnJvcn08L3A+XHJcbiAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICA8L21haW4+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgaWYgKHF1ZXN0aW9ucy5sZW5ndGggPT09IDApIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cInF1aXotcGFnZVwiPlxyXG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInF1aXotc2hlbGxcIj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInF1aXotc3RhdHVzXCI+Tm8gcXVlc3Rpb25zIGZvdW5kIGZvciB0aGlzIGNhdGVnb3J5LjwvcD5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgIDwvbWFpbj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBjb25zdCBjdXJyZW50UXVlc3Rpb24gPSBxdWVzdGlvbnNbY3VycmVudFF1ZXN0aW9uSW5kZXhdO1xyXG5cclxuICBjb25zdCBzZWxlY3RlZEFuc3dlciA9IGN1cnJlbnRRdWVzdGlvbi5vcHRpb25zLmZpbmQoXHJcbiAgICAob3B0aW9uKSA9PiBvcHRpb24uaWQgPT09IHNlbGVjdGVkQW5zd2VySWQsXHJcbiAgKTtcclxuXHJcbiAgY29uc3QgaXNMYXN0UXVlc3Rpb24gPSBjdXJyZW50UXVlc3Rpb25JbmRleCA9PT0gcXVlc3Rpb25zLmxlbmd0aCAtIDE7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFuc3dlckNsaWNrID0gYXN5bmMgKGFuc3dlcklkOiBzdHJpbmcpID0+IHtcclxuICAgIGlmIChpc1N1Ym1pdHRpbmdBbnN3ZXIgfHwgYW5zd2VyUmVzdWx0IHx8IHF1aXpSZXN1bHQgfHwgIXNlc3Npb25JZCkge1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0U2VsZWN0ZWRBbnN3ZXJJZChhbnN3ZXJJZCk7XHJcbiAgICBzZXRBbnN3ZXJSZXN1bHQobnVsbCk7XHJcbiAgICBzZXRBbnN3ZXJFcnJvcihudWxsKTtcclxuICAgIHNldElzU3VibWl0dGluZ0Fuc3dlcih0cnVlKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBzdWJtaXRRdWl6QW5zd2VyKHNlc3Npb25JZCwge1xyXG4gICAgICAgIHF1ZXN0aW9uSWQ6IGN1cnJlbnRRdWVzdGlvbi5pZCxcclxuICAgICAgICBhbnN3ZXJJZCxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBzZXRBbnN3ZXJSZXN1bHQocmVzdWx0KTtcclxuXHJcbiAgICAgIHNldFNjb3JlKChjdXJyZW50U2NvcmUpID0+IGN1cnJlbnRTY29yZSArIHJlc3VsdC5wb2ludHMpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBzdWJtaXQgYW5zd2VyOlwiLCBlcnJvcik7XHJcblxyXG4gICAgICBzZXRBbnN3ZXJFcnJvcihcIkNvdWxkIG5vdCBjaGVjayB0aGUgYW5zd2VyLlwiKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzU3VibWl0dGluZ0Fuc3dlcihmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlTmV4dFF1ZXN0aW9uID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCFhbnN3ZXJSZXN1bHQgfHwgaXNDb21wbGV0aW5nUXVpeikge1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGlzTGFzdFF1ZXN0aW9uKSB7XHJcbiAgICAgIGlmICghc2Vzc2lvbklkKSB7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcblxyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldElzQ29tcGxldGluZ1F1aXoodHJ1ZSk7XHJcbiAgICAgICAgc2V0QW5zd2VyRXJyb3IobnVsbCk7XHJcblxyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNvbXBsZXRlUXVpeihzZXNzaW9uSWQpO1xyXG5cclxuICAgICAgICBzZXRRdWl6UmVzdWx0KHJlc3VsdCk7XHJcblxyXG4gICAgICAgIHNldFNjb3JlKHJlc3VsdC5xdWl6U2NvcmUpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gY29tcGxldGUgcXVpejpcIiwgZXJyb3IpO1xyXG5cclxuICAgICAgICBzZXRBbnN3ZXJFcnJvcihcIkNvdWxkIG5vdCBjb21wbGV0ZSB0aGUgcXVpei5cIik7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNDb21wbGV0aW5nUXVpeihmYWxzZSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRDdXJyZW50UXVlc3Rpb25JbmRleCgoY3VycmVudEluZGV4KSA9PiBjdXJyZW50SW5kZXggKyAxKTtcclxuXHJcbiAgICBzZXRTZWxlY3RlZEFuc3dlcklkKG51bGwpO1xyXG4gICAgc2V0QW5zd2VyUmVzdWx0KG51bGwpO1xyXG4gICAgc2V0QW5zd2VyRXJyb3IobnVsbCk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxtYWluIGNsYXNzTmFtZT1cInF1aXotcGFnZVwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInF1aXotcGxhY2Vob2xkZXJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInF1aXotc3RhdCBxdWl6LXN0YXQtLW5hbWVcIj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInF1aXotc3RhdC1sYWJlbFwiPlF1aXo8L3NwYW4+XHJcblxyXG4gICAgICAgICAgPHN0cm9uZz57cXVpek5hbWV9PC9zdHJvbmc+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJxdWl6LXN0YXQtZ3JvdXBcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicXVpei1zdGF0IHF1aXotc3RhdC0tcXVlc3Rpb25cIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicXVpei1zdGF0LWxhYmVsXCI+UXVlc3Rpb248L3NwYW4+XHJcblxyXG4gICAgICAgICAgICA8c3Ryb25nPlxyXG4gICAgICAgICAgICAgIHtjdXJyZW50UXVlc3Rpb25JbmRleCArIDF9IC8ge3F1ZXN0aW9ucy5sZW5ndGh9XHJcbiAgICAgICAgICAgIDwvc3Ryb25nPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJxdWl6LXN0YXQgcXVpei1zdGF0LS1zY29yZVwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJxdWl6LXN0YXQtbGFiZWxcIj5TY29yZTwvc3Bhbj5cclxuXHJcbiAgICAgICAgICAgIDxzdHJvbmc+e3Njb3JlfTwvc3Ryb25nPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicXVpei1zaGVsbFwiIGFyaWEtbGFiZWxsZWRieT1cInF1aXotdGl0bGVcIj5cclxuICAgICAgICA8aDEgaWQ9XCJxdWl6LXRpdGxlXCIgY2xhc3NOYW1lPVwidmlzdWFsbHktaGlkZGVuXCI+XHJcbiAgICAgICAgICBUZWNoTGluZ28gcXVpelxyXG4gICAgICAgIDwvaDE+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udmVyc2F0aW9uXCIgYXJpYS1saXZlPVwicG9saXRlXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lc3NhZ2Utcm93IG1lc3NhZ2Utcm93LS1yb2JvdFwiPlxyXG4gICAgICAgICAgICA8Um9ib3RBdmF0YXIgLz5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVzc2FnZS1jb250ZW50XCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWVzc2FnZS1zZW5kZXJcIj5UZWNoTGluZ288L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYnViYmxlIGJ1YmJsZS0tcm9ib3RcIj5cclxuICAgICAgICAgICAgICAgIHtjdXJyZW50UXVlc3Rpb24ubWVzc2FnZX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lc3NhZ2Utcm93IG1lc3NhZ2Utcm93LS1yb2JvdFwiPlxyXG4gICAgICAgICAgICA8Um9ib3RBdmF0YXIgLz5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVzc2FnZS1jb250ZW50XCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWVzc2FnZS1zZW5kZXJcIj5UZWNoTGluZ288L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYnViYmxlIGJ1YmJsZS0tcm9ib3RcIj5cclxuICAgICAgICAgICAgICAgIHtjdXJyZW50UXVlc3Rpb24ucHJvbXB0fVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHtzZWxlY3RlZEFuc3dlciAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVzc2FnZS1yb3cgbWVzc2FnZS1yb3ctLXVzZXJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lc3NhZ2UtY29udGVudCBtZXNzYWdlLWNvbnRlbnQtLXVzZXJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1lc3NhZ2Utc2VuZGVyIG1lc3NhZ2Utc2VuZGVyLS11c2VyXCI+WW91PC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYnViYmxlIGJ1YmJsZS0tdXNlclwiPntzZWxlY3RlZEFuc3dlci50ZXh0fTwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8VXNlckF2YXRhciAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAge2Fuc3dlclJlc3VsdCAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVzc2FnZS1yb3cgbWVzc2FnZS1yb3ctLXJvYm90XCI+XHJcbiAgICAgICAgICAgICAgPFJvYm90QXZhdGFyIC8+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVzc2FnZS1jb250ZW50XCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtZXNzYWdlLXNlbmRlclwiPlRlY2hMaW5nbzwvc3Bhbj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJ1YmJsZSBidWJibGUtLXJvYm90XCI+XHJcbiAgICAgICAgICAgICAgICAgIHthbnN3ZXJSZXN1bHQuaXNDb3JyZWN0ID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICBDb3JyZWN0ISBZb3UgZ290e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicG9pbnRzXCI+e2Fuc3dlclJlc3VsdC5wb2ludHN9PC9zcGFuPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIHBvaW50cy5cclxuICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgTm90IHF1aXRlLiBUaGUgY29ycmVjdCBhbnN3ZXIgaXMgXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHthbnN3ZXJSZXN1bHQuY29ycmVjdEFuc3dlcn1cclxuICAgICAgICAgICAgICAgICAgICAgIFwiLlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICBZb3UgZ290e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicG9pbnRzIHdyb25nXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHthbnN3ZXJSZXN1bHQucG9pbnRzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIHBvaW50cy5cclxuICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAge3F1aXpSZXN1bHQgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lc3NhZ2Utcm93IG1lc3NhZ2Utcm93LS1yb2JvdFwiPlxyXG4gICAgICAgICAgICAgIDxSb2JvdEF2YXRhciAvPlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lc3NhZ2UtY29udGVudFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWVzc2FnZS1zZW5kZXJcIj5UZWNoTGluZ288L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJidWJibGUgYnViYmxlLS1yb2JvdFwiPlxyXG4gICAgICAgICAgICAgICAgICBRdWl6IGNvbXBsZXRlIVxyXG4gICAgICAgICAgICAgICAgICA8YnIgLz5cclxuICAgICAgICAgICAgICAgICAgUXVpeiBzY29yZToge3F1aXpSZXN1bHQucXVpelNjb3JlfVxyXG4gICAgICAgICAgICAgICAgICA8YnIgLz5cclxuICAgICAgICAgICAgICAgICAgVG90YWwgc2NvcmU6IHtxdWl6UmVzdWx0LnRvdGFsU2NvcmV9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHthbnN3ZXJFcnJvciAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVzc2FnZS1yb3cgbWVzc2FnZS1yb3ctLXJvYm90XCI+XHJcbiAgICAgICAgICAgICAgPFJvYm90QXZhdGFyIC8+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVzc2FnZS1jb250ZW50XCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtZXNzYWdlLXNlbmRlclwiPlRlY2hMaW5nbzwvc3Bhbj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJ1YmJsZSBidWJibGUtLXJvYm90XCI+e2Fuc3dlckVycm9yfTwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGl2aWRlclwiIC8+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5zd2VyLWdyaWRcIiByb2xlPVwiZ3JvdXBcIiBhcmlhLWxhYmVsPVwiQ2hvb3NlIGFuIGFuc3dlclwiPlxyXG4gICAgICAgICAge2N1cnJlbnRRdWVzdGlvbi5vcHRpb25zLm1hcCgoYW5zd2VyLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYW5zd2VyLWJ1dHRvbiR7XHJcbiAgICAgICAgICAgICAgICBzZWxlY3RlZEFuc3dlcklkID09PSBhbnN3ZXIuaWQgPyBcIiBzZWxlY3RlZFwiIDogXCJcIlxyXG4gICAgICAgICAgICAgIH0ke1xyXG4gICAgICAgICAgICAgICAgYW5zd2VyUmVzdWx0Py5jb3JyZWN0QW5zd2VySWQgPT09IGFuc3dlci5pZCA/IFwiIGNvcnJlY3RcIiA6IFwiXCJcclxuICAgICAgICAgICAgICB9JHtcclxuICAgICAgICAgICAgICAgIGFuc3dlclJlc3VsdCAmJlxyXG4gICAgICAgICAgICAgICAgIWFuc3dlclJlc3VsdC5pc0NvcnJlY3QgJiZcclxuICAgICAgICAgICAgICAgIHNlbGVjdGVkQW5zd2VySWQgPT09IGFuc3dlci5pZFxyXG4gICAgICAgICAgICAgICAgICA/IFwiIGluY29ycmVjdFwiXHJcbiAgICAgICAgICAgICAgICAgIDogXCJcIlxyXG4gICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgIGtleT17YW5zd2VyLmlkfVxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUFuc3dlckNsaWNrKGFuc3dlci5pZCl9XHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e1xyXG4gICAgICAgICAgICAgICAgaXNTdWJtaXR0aW5nQW5zd2VyIHx8XHJcbiAgICAgICAgICAgICAgICBhbnN3ZXJSZXN1bHQgIT09IG51bGwgfHxcclxuICAgICAgICAgICAgICAgIHF1aXpSZXN1bHQgIT09IG51bGxcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhbnN3ZXItbGV0dGVyXCI+XHJcbiAgICAgICAgICAgICAgICB7U3RyaW5nLmZyb21DaGFyQ29kZSg2NSArIGluZGV4KX1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgIDxzcGFuPnthbnN3ZXIudGV4dH08L3NwYW4+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHthbnN3ZXJSZXN1bHQgJiYgIXF1aXpSZXN1bHQgJiYgKFxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlTmV4dFF1ZXN0aW9ufVxyXG4gICAgICAgICAgICBkaXNhYmxlZD17aXNDb21wbGV0aW5nUXVpen1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2lzQ29tcGxldGluZ1F1aXpcclxuICAgICAgICAgICAgICA/IFwiRmluaXNoaW5nLi4uXCJcclxuICAgICAgICAgICAgICA6IGlzTGFzdFF1ZXN0aW9uXHJcbiAgICAgICAgICAgICAgICA/IFwiRmluaXNoIHF1aXpcIlxyXG4gICAgICAgICAgICAgICAgOiBcIk5leHQgcXVlc3Rpb25cIn1cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuICAgIDwvbWFpbj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBRdWl6UGFnZTtcclxuIl19